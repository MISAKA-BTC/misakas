//! **ADR-0087 — a position is bought from the curve and sold back to it.**
//!
//! The arithmetic of a class's model market, kept apart from the fold that applies it: the
//! constants, the constant-product curve over the reserve plus a virtual reserve, the fee split,
//! the sink script a buy's carrier pays into, and the message a sell is signed over. Everything
//! here is a pure function of its arguments so the fold, the RPC, the CLI's quote and the tests
//! read one arithmetic.
//!
//! **Amended by ADR-0090 (2026-09-05).** A position is a whole number — one unit, no fraction —
//! and a line's market opens only when a SEED of at least `PALW_MODEL_SEED_MIN_SOMPI_V1` is paid
//! into its sink: the seed becomes the reserve, fee-free, and nothing ever pays it out. The
//! curve is `msk_reserve × position_units = K` with `K` taken at each move from the row as it
//! stands (the product never falls); there is no virtual reserve. Every line opens with
//! `PALW_MODEL_POSITION_SUPPLY_V1` positions in the curve. The price at any moment is
//! `msk_reserve / position_units` and there is no other price.
//!
//! **Amended by ADR-0091 (2026-09-06).** The reward buys the pair: at a claim's `Final`,
//! `PALW_MODEL_BUYBACK_PERMILLE_V1` of its escrowed worker reward enters the reserve as the
//! chain's own move — no leg, no holder — and the positions the curve gives up for it are
//! RETIRED (`retired_units`: the chain's, for good; M1 counts them). The other 95 % is the
//! miner's. Where a line has no pair, or a closed one, the miner is paid in full.
//!
//! **Amended by ADR-0162 (2026-10-01): the pair opens on a virtual reserve.** Past
//! `Params::palw_model_virtual_v1` a line's market is open from the line's creation with no MSK in
//! it: the curve is `X × position_units` with `X = virtual_sompi + msk_reserve`, `virtual_sompi` the
//! row's own [`PALW_MODEL_MARKET_VIRTUAL_SOMPI_V2`] (10,000,000 MSK — a first price of 20 MSK), and
//! `K` taken from the row at every move as before. Nobody is ever paid out of `V`: a sell is paid
//! only out of the real reserve above the locked seed, so the arithmetic is exactly ADR-0090's with a
//! seed of `V` that nobody had to lock. The seed is optional — any amount, before the first trade,
//! locked for good, raising the floor `(V + seed) / supply`. A row opened before the fence has
//! `virtual_sompi == 0` and quotes, encodes and hashes exactly as it did.

use crate::Hash64;
use crate::tx::ScriptPublicKey;

/// ADR-0090 Decision 1: a position IS the unit — one, no fraction. The name survives so every
/// reader that multiplies by it keeps reading; the value is one.
pub const PALW_MODEL_POSITION_UNITS_V1: u64 = 1;
/// ADR-0090 Decision 1: five hundred thousand whole positions a line, fixed at the seed — a
/// network constant so no model is issued more room than another.
pub const PALW_MODEL_POSITION_SUPPLY_V1: u64 = 500_000;
/// The whole supply in units.
pub const PALW_MODEL_SUPPLY_UNITS_V1: u64 = PALW_MODEL_POSITION_SUPPLY_V1 * PALW_MODEL_POSITION_UNITS_V1;
/// ADR-0090 Decision 2 retired the virtual reserve; the constant is kept at zero so a reader
/// that still adds it adds nothing. The first price is `seed / supply` now.
pub const PALW_MODEL_MARKET_VIRTUAL_SOMPI_V1: u64 = 0;
/// **ADR-0162: the virtual reserve a line's market opens on past `Params::palw_model_virtual_v1`** —
/// 10,000,000 MSK, so the first of the 500,000 positions costs 20 MSK and the curve is as deep as a
/// pair seeded with ten million MSK. It prices and it never pays: no object pays a sompi of it to
/// anyone, because a sell is paid only out of the real reserve above the locked seed. The row
/// records the value it opened on (`PalwModelMarketV1::virtual_sompi`), so a later constant moves
/// no market that already exists.
pub const PALW_MODEL_MARKET_VIRTUAL_SOMPI_V2: u64 = 10_000_000 * 100_000_000;
/// ADR-0090 Decision 2: the least seed that opens a line's market — 100,000 MSK, every sompi of
/// which enters the curve, none of which any object ever pays out.
pub const PALW_MODEL_SEED_MIN_SOMPI_V1: u64 = 100_000 * 100_000_000;
/// **ADR-0120: the least seed once `Params::palw_model_seed_v2` is in force** — 1,000,000 MSK, ten
/// times ADR-0090's. Every sompi of it is locked in the line's sink for good, as before; what moves is
/// only the total at which the pair becomes a market.
pub const PALW_MODEL_SEED_MIN_SOMPI_V2: u64 = 1_000_000 * 100_000_000;

/// **The least seed in force** (ADR-0120): V2 once the fence is active at the payment's DAA, V1 before
/// it. The fold, the EVM window, the RPC and the CLI each ask this, so no two of them can hold one
/// payment to two floors.
pub const fn palw_model_seed_min_sompi(seed_v2_active: bool) -> u64 {
    if seed_v2_active { PALW_MODEL_SEED_MIN_SOMPI_V2 } else { PALW_MODEL_SEED_MIN_SOMPI_V1 }
}

/// **The least seed in force, with ADR-0162 over ADR-0120** — zero once `palw_model_virtual_v1` is in
/// force (no seed opens a market: every line's market is open from its creation, and a seed is
/// optional depth), else [`palw_model_seed_min_sompi`]. The virtual fence takes precedence over the
/// seed fence wherever both are armed; below the virtual fence nothing here moves.
pub const fn palw_model_seed_min_sompi_v2(seed_v2_active: bool, virtual_active: bool) -> u64 {
    if virtual_active { 0 } else { palw_model_seed_min_sompi(seed_v2_active) }
}
/// ADR-0091 Decision 1: the part of a claim's escrowed worker reward that buys from the pair of
/// the line the claim ran, in permille — the other 950 ‰ is named for the miner at `Final`.
pub const PALW_MODEL_BUYBACK_PERMILLE_V1: u64 = 50;
/// Fee on the MSK leg of every move, in permille: burned.
pub const PALW_MODEL_BURN_PERMILLE_V1: u64 = 50;
/// Fee on the MSK leg of every move, in permille: to the class's registrant (burned when the
/// class has none).
pub const PALW_MODEL_REGISTRANT_PERMILLE_V1: u64 = 10;
/// **ADR-0114: the owner's leg once `Params::palw_model_leg_v2` is in force** — fifty permille, the
/// size of the burn. A join then leaves 10 % of its MSK behind (5 % burned, 5 % to the line's owner)
/// and a leave does the same, so a round trip costs about a fifth of what went in, before the curve's
/// own slippage. Below the fence every move is quoted at `PALW_MODEL_REGISTRANT_PERMILLE_V1`, exactly
/// as before, so a chain that has not armed it keeps every row it had.
pub const PALW_MODEL_OWNER_LEG_PERMILLE_V2: u64 = 50;

/// **The fee schedule one move is quoted under** (ADR-0114): what its MSK leg burns and what it pays
/// the line's owner, in permille. Chosen by the fence at the move's own DAA and by nothing else — the
/// fold, the EVM window, the RPC and the CLI each ask [`PalwModelFeesV1::at`], so no two of them can
/// quote one move under two schedules.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwModelFeesV1 {
    pub burn_permille: u64,
    pub leg_permille: u64,
}

impl PalwModelFeesV1 {
    /// ADR-0087 Decision 4 as shipped: 5 % burned, 1 % to the owner.
    pub const V1: Self = Self { burn_permille: PALW_MODEL_BURN_PERMILLE_V1, leg_permille: PALW_MODEL_REGISTRANT_PERMILLE_V1 };
    /// ADR-0114: 5 % burned, 5 % to the owner.
    pub const V2: Self = Self { burn_permille: PALW_MODEL_BURN_PERMILLE_V1, leg_permille: PALW_MODEL_OWNER_LEG_PERMILLE_V2 };

    /// The schedule in force: V2 once ADR-0114's fence is active at the move's DAA, V1 before it.
    pub const fn at(leg_v2_active: bool) -> Self {
        if leg_v2_active { Self::V2 } else { Self::V1 }
    }
}
/// The sink script's tag: `OP_RETURN <tag> <class id>`.
pub const PALW_MODEL_SINK_TAG_V1: &[u8; 8] = b"MSKMDL01";
const OP_RETURN: u8 = 0x6a;
const OP_DATA8: u8 = 0x08;
const OP_DATA64: u8 = 0x40;
/// Domain of the message a sell is signed over.
pub const PALW_MODEL_SELL_SIGN_DOMAIN_V1: &[u8] = b"misaka-palw/model-market/sell/v1";
/// ML-DSA-87 context of a sell's signature, distinct from every other context on the chain.
pub const PALW_MODEL_SELL_MLDSA87_CONTEXT: &[u8] = b"misaka-palw-model-sell-v1";

/// **ADR-0094's field is DERIVED on read, not encoded, and the reason is a live network.**
///
/// `collection_root` borsh-serializes each row, so a field added to this struct changes the bytes
/// of EVERY existing market and therefore the state root — on a chain whose market is already open
/// that is a fork on the next block, and no fence can prevent it because the encoding never
/// consults one. A self-delimiting tail does not work either: a row is a value INSIDE a
/// `BTreeMap`, so a reader that peeks one byte past its row steals the next row's first byte.
///
/// The way out is that the field carries no information the row does not already hold:
///
/// * an OPEN market has `seed_pledged_sompi == seed_sompi` — `seed_v1` sets them equal,
///   `open_from_pledge_v1` sets the seed from the pledge, and an open market takes no further seed;
/// * a PLEDGED market has `seed_sompi == 0` and its whole reserve IS the pledge, because nothing
///   but instalments can have funded it before it opened.
///
/// So the encoding writes the pre-ADR-0094 fields exactly and the reader derives the pledge. The
/// bytes of every row an old node could produce are unchanged, byte for byte, and the invariant
/// that makes this sound is asserted on the way out rather than assumed.
///
/// **ADR-0162's `virtual_sompi` IS new information, and it rides behind a flag the row already
/// carries.** A market opened on the virtual reserve must remember the reserve it opened on — a row
/// opened before the fence has none, and a later constant must not reprice a market that exists — so
/// it cannot be derived the way the pledge is. It is written as a trailing `u64` that only a flagged
/// row has, and the flag is bit 1 of the `closed_to_buys` byte, which borsh writes as `0` or `1` and
/// which this encoding reads BEFORE the tail: the reader knows from inside the row whether a word
/// follows, so it never peeks past the row into the next `BTreeMap` entry. A row with
/// `virtual_sompi == 0` — every row any network holds below the fence — writes the byte `0`/`1` and
/// no tail, so its bytes, the state root over it, the carriage and every delta are unchanged. The
/// encoding is one-to-one: an unknown bit, or a flag whose word is zero, is refused.
const PALW_MODEL_MARKET_CLOSED_BIT: u8 = 0b01;
const PALW_MODEL_MARKET_VIRTUAL_BIT: u8 = 0b10;

impl borsh::BorshSerialize for PalwModelMarketV1 {
    fn serialize<W: std::io::Write>(&self, writer: &mut W) -> std::io::Result<()> {
        debug_assert_eq!(
            self.seed_pledged_sompi,
            palw_model_seed_pledged_of_v1(self.seed_sompi, self.msk_reserve, self.virtual_sompi),
            "ADR-0094's pledge must stay derivable or this encoding loses it"
        );
        self.opened_daa.serialize(writer)?;
        self.msk_reserve.serialize(writer)?;
        self.position_units.serialize(writer)?;
        self.sold_units.serialize(writer)?;
        self.burned_sompi.serialize(writer)?;
        self.registrant_paid_sompi.serialize(writer)?;
        let flags = if self.closed_to_buys { PALW_MODEL_MARKET_CLOSED_BIT } else { 0 }
            | if self.virtual_sompi > 0 { PALW_MODEL_MARKET_VIRTUAL_BIT } else { 0 };
        flags.serialize(writer)?;
        self.contributor_paid_sompi.serialize(writer)?;
        self.seed_sompi.serialize(writer)?;
        self.seeded_by.serialize(writer)?;
        self.buyback_sompi.serialize(writer)?;
        self.retired_units.serialize(writer)?;
        if self.virtual_sompi > 0 {
            self.virtual_sompi.serialize(writer)?;
        }
        Ok(())
    }
}

impl borsh::BorshDeserialize for PalwModelMarketV1 {
    fn deserialize_reader<R: std::io::Read>(reader: &mut R) -> std::io::Result<Self> {
        let opened_daa = u64::deserialize_reader(reader)?;
        let msk_reserve = u64::deserialize_reader(reader)?;
        let position_units = u64::deserialize_reader(reader)?;
        let sold_units = u64::deserialize_reader(reader)?;
        let burned_sompi = u64::deserialize_reader(reader)?;
        let registrant_paid_sompi = u64::deserialize_reader(reader)?;
        let flags = u8::deserialize_reader(reader)?;
        if flags & !(PALW_MODEL_MARKET_CLOSED_BIT | PALW_MODEL_MARKET_VIRTUAL_BIT) != 0 {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "a model market row's flag byte has an unknown bit"));
        }
        let closed_to_buys = flags & PALW_MODEL_MARKET_CLOSED_BIT != 0;
        let contributor_paid_sompi = u64::deserialize_reader(reader)?;
        let seed_sompi = u64::deserialize_reader(reader)?;
        let seeded_by = Hash64::deserialize_reader(reader)?;
        let buyback_sompi = u64::deserialize_reader(reader)?;
        let retired_units = u64::deserialize_reader(reader)?;
        let virtual_sompi = if flags & PALW_MODEL_MARKET_VIRTUAL_BIT != 0 {
            let value = u64::deserialize_reader(reader)?;
            if value == 0 {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::InvalidData,
                    "a model market row flags a virtual reserve of zero",
                ));
            }
            value
        } else {
            0
        };
        let seed_pledged_sompi = palw_model_seed_pledged_of_v1(seed_sompi, msk_reserve, virtual_sompi);
        Ok(Self {
            opened_daa,
            msk_reserve,
            position_units,
            sold_units,
            burned_sompi,
            registrant_paid_sompi,
            closed_to_buys,
            contributor_paid_sompi,
            seed_sompi,
            seeded_by,
            seed_pledged_sompi,
            buyback_sompi,
            retired_units,
            virtual_sompi,
        })
    }
}

/// **ADR-0094's pledge, derived from the fields that are encoded** — the one spelling the encoder's
/// assertion and the decoder share. An open market (`seed_sompi > 0`, or ADR-0162's virtual reserve)
/// has pledged exactly its seed; a row still collecting its floor has pledged its whole reserve.
const fn palw_model_seed_pledged_of_v1(seed_sompi: u64, msk_reserve: u64, virtual_sompi: u64) -> u64 {
    if seed_sompi > 0 || virtual_sompi > 0 { seed_sompi } else { msk_reserve }
}

/// One class's market row, as the fold holds it (Decision 1).
#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct PalwModelMarketV1 {
    pub opened_daa: u64,
    /// MSK the curve holds, in sompi — funded by sinks, drained by payouts, never a spendable output.
    pub msk_reserve: u64,
    /// Units still in the curve.
    pub position_units: u64,
    /// Units ever bought, cumulative (a sell does not reduce it).
    pub sold_units: u64,
    pub burned_sompi: u64,
    pub registrant_paid_sompi: u64,
    /// Set when the class left `Active`; sells continue, buys are refused (Decision 7).
    pub closed_to_buys: bool,
    /// ADR-0088 Decision 8: the part of the registrant leg paid to an adopted contributor.
    /// `registrant_paid_sompi` is the owner's total.
    pub contributor_paid_sompi: u64,
    /// ADR-0090 Decision 2: the MSK the market opened with — the floor the reserve never falls
    /// under (with every position back in the curve the product puts the reserve at the seed or
    /// above), and the number the site shows as "locked".
    pub seed_sompi: u64,
    /// ADR-0090 Decision 3: who paid the seed — a holder id kept for the record only; the
    /// seeder holds nothing and can move nothing. ADR-0094 Decision 3: with the seed paid in
    /// instalments this is the FIRST payer, the one who opened the pledge.
    pub seeded_by: Hash64,
    /// **ADR-0094 Decision 1: what this line has collected toward its floor.** A hundred thousand
    /// MSK does not fit in one post-quantum transaction (fifteen ML-DSA-87 inputs is the most the
    /// mass cap allows, about a fifth of the floor from mining income), so the seed arrives in
    /// several. Every sompi counted here is already in the line's sink and already locked; the
    /// market does not exist until this reaches `PALW_MODEL_SEED_MIN_SOMPI_V1`.
    pub seed_pledged_sompi: u64,
    /// ADR-0091 Decision 2: MSK the mining reward has put into the curve, cumulative — five
    /// percent of every model block's escrowed worker reward, entered at the claim's `Final`.
    pub buyback_sompi: u64,
    /// ADR-0091 Decision 4: the positions the reward's buys took out of the curve — the chain's,
    /// for good; no object sells them, and `position_units + Σ holders + retired_units = supply`.
    pub retired_units: u64,
    /// **ADR-0162: the virtual reserve this market opened on** — [`PALW_MODEL_MARKET_VIRTUAL_SOMPI_V2`]
    /// for a market opened past `Params::palw_model_virtual_v1`, zero for every market opened before
    /// it (ADR-0090's seeded pairs and ADR-0094's pledges keep their curve). The curve's `X` is
    /// `msk_reserve + virtual_sompi`; nothing ever pays a sompi of it out. Encoded behind a flag bit
    /// (see the `BorshSerialize` impl), so a row with zero here has the bytes it always had.
    #[serde(default)]
    pub virtual_sompi: u64,
}

impl PalwModelMarketV1 {
    /// **ADR-0094 Decision 1: a line that has been paid into but is not yet a market.** The
    /// collected total is in the reserve — it is in the sink, so it is locked — and the curve is
    /// empty: no positions, no price, and every move refused until [`Self::is_open`].
    pub fn pledge_v1(daa: u64, pledged_sompi: u64, first_payer: Hash64) -> Self {
        Self {
            opened_daa: daa,
            msk_reserve: pledged_sompi,
            position_units: 0,
            sold_units: 0,
            burned_sompi: 0,
            registrant_paid_sompi: 0,
            closed_to_buys: false,
            contributor_paid_sompi: 0,
            seed_sompi: 0,
            seeded_by: first_payer,
            seed_pledged_sompi: pledged_sompi,
            buyback_sompi: 0,
            retired_units: 0,
            virtual_sompi: 0,
        }
    }

    /// **ADR-0094 Decision 2: is this a market yet?** A row exists from the first payment; it is a
    /// market only once the collected total reached the floor, which is the one predicate every
    /// move consults. `seed_sompi` is set at that moment and never after, so it doubles as the
    /// record of what the pair opened with.
    ///
    /// **ADR-0162: a market that opened on the virtual reserve is open with no seed at all** — it was
    /// open from its line's creation, and a seed paid into it later is depth, not an opening.
    pub fn is_open(&self) -> bool {
        self.seed_sompi > 0 || self.virtual_sompi > 0
    }

    /// **ADR-0162: the curve's `X`** — the real reserve plus the virtual reserve the market opened
    /// on (zero for a market opened before the fence, so `X` is ADR-0090's reserve there).
    pub fn curve_x(&self) -> u128 {
        self.msk_reserve as u128 + self.virtual_sompi as u128
    }

    /// **ADR-0162: the positions holders have out of the curve** — the supply less the curve's and
    /// less what the reward retired (ADR-0091 M1). Zero for a row that is not a market.
    pub fn positions_out(&self) -> u64 {
        if !self.is_open() {
            return 0;
        }
        PALW_MODEL_SUPPLY_UNITS_V1.saturating_sub(self.position_units).saturating_sub(self.retired_units)
    }

    /// **ADR-0162 I-V3: the lowest price the curve can ever quote from this row** — the price with
    /// every holder's position back in the curve, `⌈K / (supply − retired)⌉ / (supply − retired)`.
    /// The product never falls and the retired never return, so this only rises; at the opening it is
    /// `(V + seed) / supply`. Zero for a row that is not a market.
    pub fn price_floor_sompi_per_position_v2(&self) -> u64 {
        if !self.is_open() {
            return 0;
        }
        let room = PALW_MODEL_SUPPLY_UNITS_V1.saturating_sub(self.retired_units) as u128;
        if room == 0 {
            return u64::MAX;
        }
        (self.k().div_ceil(room) / room).min(u64::MAX as u128) as u64
    }

    /// **ADR-0162 Decision 1: a line's market as it stands from the line's creation** — the whole
    /// supply in the curve, no MSK in it, `X = virtual_sompi`: open, with a first price of
    /// `virtual_sompi / supply`. `opened_daa` is the line's founding height, or the fence's for a line
    /// older than the fence. Nothing writes this row by itself: the fold writes it with the first move
    /// that changes it, and every reader synthesizes it until then (lazily, as ADR-0087 §7 learnt).
    pub fn open_virtual_v2(opened_daa: u64, virtual_sompi: u64) -> Self {
        Self {
            opened_daa,
            msk_reserve: 0,
            position_units: PALW_MODEL_SUPPLY_UNITS_V1,
            sold_units: 0,
            burned_sompi: 0,
            registrant_paid_sompi: 0,
            closed_to_buys: false,
            contributor_paid_sompi: 0,
            seed_sompi: 0,
            seeded_by: Hash64::default(),
            seed_pledged_sompi: 0,
            buyback_sompi: 0,
            retired_units: 0,
            virtual_sompi,
        }
    }

    /// **ADR-0162 Decision 3: a pledge that was collecting ADR-0094's floor when the fence crossed.**
    /// It opens on the virtual reserve with the whole pledge as its seed — every sompi of it already
    /// locked in the line's sink — and the first payer keeps the record. A row that is already a
    /// market is returned as it is.
    pub fn open_virtual_from_pledge_v2(&self, opened_daa: u64, virtual_sompi: u64) -> Self {
        if self.is_open() {
            return *self;
        }
        Self {
            opened_daa,
            position_units: PALW_MODEL_SUPPLY_UNITS_V1,
            seed_sompi: self.seed_pledged_sompi,
            seed_pledged_sompi: self.seed_pledged_sompi,
            virtual_sompi,
            ..*self
        }
    }

    /// What is still owed before this line is a market under ADR-0090's floor. Zero once it is one.
    pub fn seed_remaining_sompi(&self) -> u64 {
        self.seed_remaining_sompi_under(PALW_MODEL_SEED_MIN_SOMPI_V1)
    }

    /// What is still owed before this line is a market under `floor` (ADR-0120: the floor in force at
    /// the reader's height, [`palw_model_seed_min_sompi`]). Zero once it is one — an open market owes
    /// nothing whatever the floor is now.
    pub fn seed_remaining_sompi_under(&self, floor: u64) -> u64 {
        if self.is_open() { 0 } else { floor.saturating_sub(self.seed_pledged_sompi) }
    }

    /// ADR-0090 Decision 2: a market opens ONLY by a seed — the whole supply in the curve and the
    /// seed as the reserve, fee-free. There is no other opening. ADR-0094: `seed_sompi` is the
    /// WHOLE collected total, the crossing payment's excess included.
    pub fn seed_v1(opened_daa: u64, seed_sompi: u64, seeded_by: Hash64) -> Self {
        Self {
            opened_daa,
            msk_reserve: seed_sompi,
            position_units: PALW_MODEL_SUPPLY_UNITS_V1,
            sold_units: 0,
            burned_sompi: 0,
            registrant_paid_sompi: 0,
            closed_to_buys: false,
            contributor_paid_sompi: 0,
            seed_sompi,
            seeded_by,
            seed_pledged_sompi: seed_sompi,
            buyback_sompi: 0,
            retired_units: 0,
            virtual_sompi: 0,
        }
    }

    /// **ADR-0094 Decision 2: the payment that carries a pledge across the floor.** The reserve is
    /// the whole collected total, the supply enters the curve, and `seed_sompi` records what the
    /// pair opened with. The first payer keeps the record (Decision 3).
    pub fn open_from_pledge_v1(&self, daa: u64) -> Self {
        Self { opened_daa: daa, position_units: PALW_MODEL_SUPPLY_UNITS_V1, seed_sompi: self.seed_pledged_sompi, ..*self }
    }

    /// The product the next move must not fall under: the row's own `reserve × units` — ADR-0162:
    /// `(reserve + virtual) × units`, which is the same number for a market opened before the fence.
    pub fn k(&self) -> u128 {
        self.curve_x() * self.position_units as u128
    }

    pub fn price_sompi_per_position_v1(&self) -> u64 {
        // ADR-0094: a row that is still collecting its floor has no price — not an infinite one.
        // The two zero-unit cases are different facts: nothing has opened yet (no price), and a
        // curve that opened and has given up every position (a price no buy can reach).
        if !self.is_open() {
            return 0;
        }
        if self.position_units == 0 {
            return u64::MAX;
        }
        // ADR-0162: `(reserve + V) / units` — the virtual reserve prices, it is just never paid.
        let numerator = self.curve_x() * PALW_MODEL_POSITION_UNITS_V1 as u128;
        (numerator / self.position_units as u128).min(u64::MAX as u128) as u64
    }
}

/// The three-way split of a gross MSK leg (Decision 4): `burn`, `registrant`, `net`, exact —
/// `burn + registrant + net == gross` — with the rounding remainder on the net leg.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwModelFeeSplitV1 {
    pub gross: u64,
    pub burn: u64,
    pub registrant: u64,
    pub net: u64,
}

pub fn palw_model_fee_split_v1(gross: u64) -> PalwModelFeeSplitV1 {
    palw_model_fee_split_with(gross, PalwModelFeesV1::V1)
}

/// The same split under an explicit schedule (ADR-0114). The two legs are each rounded down, so the
/// remainder stays on the net leg and `burn + registrant + net == gross` under every schedule.
pub fn palw_model_fee_split_with(gross: u64, fees: PalwModelFeesV1) -> PalwModelFeeSplitV1 {
    debug_assert!(fees.burn_permille + fees.leg_permille <= 1000, "a schedule never takes more than the leg");
    let burn = ((gross as u128 * fees.burn_permille as u128) / 1000) as u64;
    let registrant = ((gross as u128 * fees.leg_permille as u128) / 1000) as u64;
    PalwModelFeeSplitV1 { gross, burn, registrant, net: gross - burn - registrant }
}

/// What a buy of `msk_in` sompi does to a market: the split of the gross leg and the units the
/// curve releases for the NET leg, `units_out = units − ⌈K / (reserve + V + net)⌉` (rounded so the
/// curve's product never falls below `K`). `None` when the market releases nothing.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwModelBuyQuoteV1 {
    pub fees: PalwModelFeeSplitV1,
    pub units_out: u64,
    pub after: PalwModelMarketV1,
}

pub fn palw_model_buy_quote_v1(market: &PalwModelMarketV1, msk_in: u64) -> Option<PalwModelBuyQuoteV1> {
    palw_model_buy_quote_with(market, msk_in, PalwModelFeesV1::V1)
}

/// [`palw_model_buy_quote_v1`] under the schedule the fence names at the move's DAA (ADR-0114).
pub fn palw_model_buy_quote_with(market: &PalwModelMarketV1, msk_in: u64, schedule: PalwModelFeesV1) -> Option<PalwModelBuyQuoteV1> {
    // ADR-0090: a row with no reserve is not a market (the fold never writes one; a reader may
    // synthesise one for a line that has no seed) — it quotes nothing rather than the whole curve.
    // ADR-0094: a row that has been paid into but has not reached its floor is not a market — it
    // has no positions and no price, and quoting one would invent both.
    // ADR-0162: the guard is on the curve's `X`, not the real reserve — a market opened on the
    // virtual reserve has no MSK in it at its opening and is a market all the same. Below the fence
    // `X` IS the reserve, so this is the same test there.
    if !market.is_open() || market.closed_to_buys || msk_in == 0 || market.position_units == 0 || market.curve_x() == 0 {
        return None;
    }
    let fees = palw_model_fee_split_with(msk_in, schedule);
    let k = market.k();
    let x_after = market.curve_x() + fees.net as u128;
    let units_after = k.div_ceil(x_after);
    let units_out = (market.position_units as u128).checked_sub(units_after)?;
    if units_out == 0 {
        return None;
    }
    let units_out = units_out as u64;
    let after = PalwModelMarketV1 {
        msk_reserve: market.msk_reserve.checked_add(fees.net)?,
        position_units: market.position_units - units_out,
        sold_units: market.sold_units.checked_add(units_out)?,
        burned_sompi: market.burned_sompi.checked_add(fees.burn)?,
        ..*market
    };
    // ADR-0090 P1, on the buy side too (audit M-12): the product never falls. A buy raises the
    // reserve, so the seed floor cannot be breached here — the product is the half that can, if the
    // rounding above is ever changed. Checked, not assumed.
    if after.k() < k {
        return None;
    }
    Some(PalwModelBuyQuoteV1 { fees, units_out, after })
}

/// What a sell of `units_in` does: the gross MSK leg the curve pays, `gross = (reserve + V) −
/// ⌈K / (units + units_in)⌉` (rounded so the curve's product never falls below `K`), and its split.
/// `None` when the curve pays nothing, or when it would pay more than the REAL reserve above the
/// locked seed — the virtual reserve (ADR-0162) and the seed (ADR-0090) are never paid out, and a
/// sell that would need either is refused whole, never filled in part (ADR-0087 M5).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwModelSellQuoteV1 {
    pub fees: PalwModelFeeSplitV1,
    pub after: PalwModelMarketV1,
}

pub fn palw_model_sell_quote_v1(market: &PalwModelMarketV1, units_in: u64) -> Option<PalwModelSellQuoteV1> {
    palw_model_sell_quote_with(market, units_in, PalwModelFeesV1::V1)
}

/// [`palw_model_sell_quote_v1`] under the schedule the fence names at the move's DAA (ADR-0114).
pub fn palw_model_sell_quote_with(
    market: &PalwModelMarketV1,
    units_in: u64,
    schedule: PalwModelFeesV1,
) -> Option<PalwModelSellQuoteV1> {
    if units_in == 0 || !market.is_open() {
        return None;
    }
    let k = market.k();
    let units_after = market.position_units as u128 + units_in as u128;
    // ADR-0091 Decision 4: the curve can hold at most the supply less what the reward retired.
    if units_after > (PALW_MODEL_SUPPLY_UNITS_V1 - market.retired_units) as u128 {
        return None;
    }
    let x_now = market.curve_x();
    let x_after = k.div_ceil(units_after);
    let gross = x_now.checked_sub(x_after)?;
    // **ADR-0162: a sell is paid only out of the real reserve above the locked seed** — never out of
    // `V`, which nobody paid in, and never out of the seed, which nobody may take out. The curve's
    // own rounding keeps `gross` inside that bound on every row the fold can reach (a seed is taken
    // only before the first trade, so the product at the opening already prices it in); this is the
    // checked refusal that keeps it so if the rounding ever changes. On a market opened before the
    // fence (`V = 0`) it is exactly ADR-0090's two checks — the old `.min(reserve)` never bound, since
    // `X` was the reserve, and `reserve − gross < seed` is `gross > reserve − seed`. A row whose
    // reserve is under its seed — a state the design says cannot exist — pays nothing at all.
    let payable = market.msk_reserve.checked_sub(market.seed_sompi)? as u128;
    if gross == 0 || gross > payable {
        return None;
    }
    let fees = palw_model_fee_split_with(gross as u64, schedule);
    let after = PalwModelMarketV1 {
        msk_reserve: market.msk_reserve - fees.gross,
        position_units: units_after as u64,
        burned_sompi: market.burned_sompi.checked_add(fees.burn)?,
        ..*market
    };
    // **ADR-0090 Decision 2's floor and ADR-0087 M2, as CHECKED refusals rather than emergent
    // properties of the rounding** (mainnet audit 2026-09-06, M-12).
    //
    // The coinbase mints a market payout with nothing withheld — that is ADR-0087 Decision 3's
    // design ("an accounting entry funded by sinks and drained by coinbase payouts") — and the ONLY
    // thing between it and a mint above the emission schedule is that the gross leg can never
    // exceed what was sunk. Today that holds by two accidents: the `.min(msk_reserve)` above, and
    // `div_ceil`'s rounding keeping the product from falling. Both were only ever asserted in a
    // unit test (`the_product_never_falls_and_the_seed_never_leaves`), never enforced, so a future
    // change to the rounding would move real money and no rule would object.
    //
    // `None` is a refusal, and a refusal is what ADR-0087 M5 says a protection does: "refuse, never
    // partially fill".
    if after.msk_reserve < market.seed_sompi {
        return None;
    }
    if after.k() < k {
        return None;
    }
    Some(PalwModelSellQuoteV1 { fees, after })
}

/// ADR-0091 Decision 1: the slice of an escrowed worker reward that buys from the pair —
/// `⌊escrow × 50 / 1000⌋`; the miner is named the rest.
pub fn palw_model_buyback_slice_v1(escrowed_reward: u64) -> u64 {
    ((escrowed_reward as u128 * PALW_MODEL_BUYBACK_PERMILLE_V1 as u128) / 1000) as u64
}

/// What the reward's slice does to a market (ADR-0091 Decision 2): the whole slice enters the
/// reserve — no leg — and the curve gives up `units − ⌈K / reserve′⌉` positions, which are
/// RETIRED, never held; a slice under one position's price gives up none and still raises the
/// price (the product rose). `None` where no pair takes it: a closed market, an unseeded row,
/// or nothing to add — the caller then names the whole escrow for the miner (Decision 3).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwModelBuybackQuoteV1 {
    pub slice: u64,
    pub retired: u64,
    pub after: PalwModelMarketV1,
}

pub fn palw_model_buyback_quote_v1(market: &PalwModelMarketV1, slice: u64) -> Option<PalwModelBuybackQuoteV1> {
    // ADR-0162: the guard is on the curve's `X` (a virtual market holds no MSK at its opening and
    // takes the reward all the same); below the fence `X` is the reserve, so it is the same test.
    if !market.is_open() || market.closed_to_buys || slice == 0 || market.position_units == 0 || market.curve_x() == 0 {
        return None;
    }
    let k = market.k();
    let reserve_after = market.msk_reserve.checked_add(slice)?;
    let units_after = k.div_ceil(market.curve_x() + slice as u128).min(market.position_units as u128) as u64;
    let retired = market.position_units - units_after;
    let after = PalwModelMarketV1 {
        msk_reserve: reserve_after,
        position_units: units_after,
        buyback_sompi: market.buyback_sompi.checked_add(slice)?,
        retired_units: market.retired_units.checked_add(retired)?,
        ..*market
    };
    Some(PalwModelBuybackQuoteV1 { slice, retired, after })
}

/// **ADR-0162 Decision 4: a seed paid into an open market before its first trade** — the whole
/// payment joins the real reserve AND the locked seed, fee-free, and no position is minted to anyone:
/// the curve's `X` grows, the product with it, and the floor `(V + seed) / supply` rises by
/// `msk_seed / supply`. The first payer stays the record (ADR-0094 Decision 3). Any amount; as many
/// payments as it takes (ADR-0094's instalments, with no floor to reach).
///
/// `None` — refused — once the market has had a trade (`sold_units > 0`): a seed paid while positions
/// are out raises their price, and their holders could sell part of the locked seed back out of the
/// curve. Only before the first trade is the product it sets one no holder can ever reach under,
/// which is what makes "locked for good" a property of the arithmetic and not a promise
/// (`a_late_seed_would_be_sold_out_of_the_curve_so_it_is_refused`). `None` too for a payment of
/// nothing, a row that is not a market, and an overflow.
pub fn palw_model_seed_deepen_v2(market: &PalwModelMarketV1, seeder: &Hash64, msk_seed: u64) -> Option<PalwModelMarketV1> {
    if !market.is_open() || market.sold_units > 0 || msk_seed == 0 {
        return None;
    }
    let msk_reserve = market.msk_reserve.checked_add(msk_seed)?;
    let seed_sompi = market.seed_sompi.checked_add(msk_seed)?;
    let seeded_by = if market.seeded_by == Hash64::default() { *seeder } else { market.seeded_by };
    let after = PalwModelMarketV1 { msk_reserve, seed_sompi, seed_pledged_sompi: seed_sompi, seeded_by, ..*market };
    // The product only grows: `X` rose and the curve's units did not move.
    debug_assert!(after.k() >= market.k());
    Some(after)
}

/// **ADR-0162 Decision 1: the market every surface reads for a line past `palw_model_virtual_v1`.**
/// A market already open keeps its row (an ADR-0090 pair opened before the fence keeps `V = 0` and
/// its curve); a pledge still collecting ADR-0094's floor opens on the virtual reserve with the
/// pledge as its seed; a line with no row has the market it had from its creation, `X = V`, the
/// whole supply in the curve. `opened_daa` is the line's founding height or the fence's, whichever is
/// later. One function, so the fold, the RPC, the EVM window and the CLI cannot open one line two
/// ways.
pub fn palw_model_market_in_force_v2(row: Option<&PalwModelMarketV1>, opened_daa: u64) -> PalwModelMarketV1 {
    match row {
        Some(market) if market.is_open() => *market,
        Some(pledge) => pledge.open_virtual_from_pledge_v2(opened_daa, PALW_MODEL_MARKET_VIRTUAL_SOMPI_V2),
        None => PalwModelMarketV1::open_virtual_v2(opened_daa, PALW_MODEL_MARKET_VIRTUAL_SOMPI_V2),
    }
}

/// The sink a buy's carrier pays into: `OP_RETURN <8-byte tag> <64-byte class id>`. Unspendable
/// by construction (the script returns early); the fold credits its value to the class's reserve.
pub fn palw_model_sink_spk_v1(class_id: &Hash64) -> ScriptPublicKey {
    let mut script = Vec::with_capacity(1 + 1 + 8 + 1 + 64);
    script.push(OP_RETURN);
    script.push(OP_DATA8);
    script.extend_from_slice(PALW_MODEL_SINK_TAG_V1);
    script.push(OP_DATA64);
    script.extend_from_slice(class_id.as_byte_slice());
    ScriptPublicKey::new(0, crate::tx::ScriptVec::from_slice(&script))
}

/// The class a sink script names, if it is one.
pub fn palw_model_sink_class_v1(spk: &ScriptPublicKey) -> Option<Hash64> {
    if spk.version() != 0 {
        return None;
    }
    let script = spk.script();
    if script.len() != 75
        || script[0] != OP_RETURN
        || script[1] != OP_DATA8
        || &script[2..10] != PALW_MODEL_SINK_TAG_V1
        || script[10] != OP_DATA64
    {
        return None;
    }
    let mut id = [0u8; 64];
    id.copy_from_slice(&script[11..75]);
    Some(Hash64::from_bytes(id))
}

/// **Lane sink (the 2026-09-25 Position review's #1): why a model sink output of `tx` is not bound**,
/// as `(output index, reason)`, or `None` when every one is (or `tx` pays none) — the activation
/// sink's rule ([`crate::palw_activation_pool_v1::palw_activation_sink_binding_refusal_v1`]) for the
/// market's `MSKMDL01` sink. A sink is bound iff `tx` is a lifecycle carrier whose payload decodes,
/// at the current wire version, to a `ModelBuy` or `ModelSeed` naming that output's index, the line
/// its script names and the value it holds. One carrier carries one object, so a second sink in the
/// same carrier is unbound by construction.
///
/// **The hole it closes.** The binding the extraction walk checks
/// ([`crate::palw_lifecycle_objects_v2::palw_model_buy_binds_its_carrier_v1`]) runs object → output
/// only: a sink no object names — a bare transfer to a sink, a carrier whose `msk_in` or line
/// disagrees with its sink, an out-of-range `sink_index`, an extra sink, a sink on a sell's (or any
/// other object's) carrier — is a valid output whose object (if any) the walk skips, so the MSK
/// leaves circulation with no reserve credited, no burn recorded and no P-B1 refund.
///
/// And, as the activation sink's F6 (i): a carrier that pays no P2PKH-ML-DSA-87 output is refused
/// too, because a buy or seed the fold refuses is paid back to the first such output (P-B1,
/// [`crate::palw_lifecycle_objects_v2::palw_model_carrier_refund_v1`]) and without one its sink would
/// keep the MSK with nobody to pay. Every carrier the shipped CLI builds pays its change at output 0.
///
/// Context-free (the transaction alone). Consensus asks it in the header context past
/// `Params::palw_model_sink_bound` (the containing block's DAA); the mempool asks it as standardness
/// on every network that declares the market (`check_transaction_standard`), where it binds no block.
pub fn palw_model_sink_binding_refusal_v1(tx: &crate::tx::Transaction) -> Option<(usize, &'static str)> {
    use crate::palw_lifecycle_objects_v2::{PALW_LIFECYCLE_TX_VERSION_V2, PalwLifecycleTxPayloadV2};
    use crate::palw_state_v2::PalwConsensusObjectV2;
    let mut sinks = tx
        .outputs
        .iter()
        .enumerate()
        .filter_map(|(i, output)| palw_model_sink_class_v1(&output.script_public_key).map(|line| (i, line)));
    let first = sinks.next()?;
    if tx.subnetwork_id != crate::subnets::SUBNETWORK_ID_PALW_LIFECYCLE {
        return Some((first.0, "a model sink rides only a lifecycle carrier"));
    }
    if !tx.outputs.iter().any(|output| crate::mldsa87_primitives::p2pkh_mldsa87_payload(&output.script_public_key).is_some()) {
        return Some((first.0, "a model sink's carrier pays no P2PKH-ML-DSA-87 output a refusal could be paid back to"));
    }
    let bound = match borsh::from_slice::<PalwLifecycleTxPayloadV2>(&tx.payload) {
        Ok(payload) if payload.version == PALW_LIFECYCLE_TX_VERSION_V2 => match payload.object {
            PalwConsensusObjectV2::ModelBuy { line_id, msk_in, sink_index, .. } => Some((sink_index as usize, line_id, msk_in)),
            PalwConsensusObjectV2::ModelSeed { line_id, msk_seed, sink_index, .. } => Some((sink_index as usize, line_id, msk_seed)),
            _ => None,
        },
        _ => None,
    };
    for (index, line) in std::iter::once(first).chain(sinks) {
        match bound {
            None => return Some((index, "a model sink's carrier carries no ModelBuy or ModelSeed")),
            Some((named, _, _)) if named != index => {
                return Some((index, "a model sink is not the output its carrier's ModelBuy or ModelSeed names"));
            }
            Some((_, named_line, _)) if named_line != line => {
                return Some((index, "a model sink names another line than its carrier's ModelBuy or ModelSeed"));
            }
            Some((_, _, amount)) if amount != tx.outputs[index].value => {
                return Some((index, "a model sink holds another amount than its carrier's ModelBuy or ModelSeed declares"));
            }
            Some(_) => {}
        }
    }
    None
}

/// **The holder is its key's id, and that id is not a payout payload** (M8): the 64-byte *unkeyed*
/// BLAKE2b of the ML-DSA-87 public key (`mldsa87_key_id`). It keys the holder's positions
/// (`(line, holder)`) and is what a sell's signature is checked against, and it stays exactly this
/// on every network, so no position, RPC query or signed sell changes meaning.
///
/// This used to say the id was "the same identity a bond pays and `p2pkh_mldsa87_spk` locks to". It
/// is not, and the difference is money: `OP_BLAKE2B_512` recomputes the *keyed* address payload at
/// spend time, so an output locked to this id is one no key can spend (the 2026-09-23 Position
/// route matrix, P-B4). What a sell pays to is [`palw_model_sell_net_payload_v1`].
pub fn palw_model_holder_of_pubkey_v1(pubkey: &[u8]) -> Hash64 {
    crate::mldsa87_primitives::mldsa87_key_id(pubkey)
}

/// **Where a carrier sell's net leg is paid: the seller's own P2PKH-ML-DSA-87 address** (the
/// 2026-09-23 Position route matrix, P-B4).
///
/// The keyed BLAKE2b-512 address payload of the key that signed the sell
/// (`kaspa_hashes::blake2b_512_address_payload`) — the payload the wallet puts in that key's
/// address, the one `OP_BLAKE2B_512` recomputes when the output is spent, and the kind of value a
/// bond's `payout_payload` already is. The fold pays this past `Params::palw_audit_2026_09_23`;
/// below it the net leg keeps its old payee, [`palw_model_holder_of_pubkey_v1`], byte for byte,
/// because testnet-11 armed the market before the fence existed.
///
/// Kept apart from the holder id on purpose. The id keys positions and the payload receives money,
/// and the two were one name for two hashes: that is the whole of P-B4.
pub fn palw_model_sell_net_payload_v1(pubkey: &[u8]) -> Hash64 {
    kaspa_hashes::blake2b_512_address_payload(pubkey)
}

/// The message a sell is signed over: the tag, **the network**, the line, the holder, the units,
/// the floor, **the position the holder is selling out of**, and **the score the authority dies at**.
///
/// **The last three are what stop it being a permanent bearer authorisation** (mainnet audit
/// 2026-09-06, M-11). As first written this message bound the sell to nothing but its own terms, so
/// a stranger could copy the public payload into a new transaction and re-fire it whenever the
/// holder held `units_in` again — a forced liquidation with no revocation and no expiry, on which
/// the line's owner collected 1 % every time. ADR-0087 M8 says "no other key can sell it"; nothing
/// made that true of the second firing.
///
/// * `network_domain` — every ADR-0088 registry message carries `palw_network_domain_v2`; this one
///   did not, so one signature was good on every chain that happened to share the line id.
/// * `held_units` — the holder's position at signing. The fold refuses unless the position still
///   stands at exactly that number, and the sell's own effect moves it, so **a signature is
///   consumed by the move it authorises**. It becomes re-usable only if the holder buys back to the
///   identical unit count, which is what `not_after_daa` then bounds. Statelessly single-use: no
///   nonce table, no new consensus row, nothing added to the state root.
/// * `not_after_daa` — the last DAA score at which the fold will honour it. An authority with an
///   end.
pub fn palw_model_sell_message_v1(
    network_domain: Hash64,
    class_id: &Hash64,
    holder: &Hash64,
    units_in: u64,
    min_msk_out: u64,
    held_units: u64,
    not_after_daa: u64,
) -> Vec<u8> {
    let mut m = Vec::with_capacity(32 + 64 + 64 + 64 + 32);
    m.extend_from_slice(PALW_MODEL_SELL_SIGN_DOMAIN_V1);
    m.extend_from_slice(network_domain.as_byte_slice());
    m.extend_from_slice(class_id.as_byte_slice());
    m.extend_from_slice(holder.as_byte_slice());
    m.extend_from_slice(&units_in.to_le_bytes());
    m.extend_from_slice(&min_msk_out.to_le_bytes());
    m.extend_from_slice(&held_units.to_le_bytes());
    m.extend_from_slice(&not_after_daa.to_le_bytes());
    m
}

/// **The longest a sell's authority may run** (audit M-11). A holder who signs for a window longer
/// than this is refused at acceptance, so "forever" is not expressible. 4,000 DAA — the same span
/// ADR-0088 Decision 2 gives a superseded version's grace (`PALW_VERSION_GRACE_DAA_V1`), so the
/// chain has one idea of "long enough to act, short enough to forget".
pub const PALW_MODEL_SELL_MAX_WINDOW_DAA_V1: u64 = 4_000;

/// What a block at `point_daa` may do with a sell that dies at `not_after_daa` (audit M-11).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PalwModelSellWindowV1 {
    /// The authority is live here.
    Live,
    /// The score is past the one the holder signed for.
    Expired,
    /// The window it names is longer than the chain honours; `daa` is the span it asked for.
    TooLong { daa: u64 },
}

/// **ADR-0087 M8's authority has an end, and the end is bounded** (mainnet audit 2026-09-06, M-11).
///
/// Both halves live here, in one function, so acceptance cannot ask one of them and a later reader
/// the other. `not_after_daa` is inclusive: the score the holder signed for is a score their sell
/// still fills at.
pub fn palw_model_sell_window_v1(point_daa: u64, not_after_daa: u64) -> PalwModelSellWindowV1 {
    if point_daa > not_after_daa {
        return PalwModelSellWindowV1::Expired;
    }
    let span = not_after_daa - point_daa;
    if span > PALW_MODEL_SELL_MAX_WINDOW_DAA_V1 {
        return PalwModelSellWindowV1::TooLong { daa: span };
    }
    PalwModelSellWindowV1::Live
}

#[cfg(test)]
mod tests {
    use super::*;

    const MSK: u64 = 100_000_000;

    fn seeded() -> PalwModelMarketV1 {
        PalwModelMarketV1::seed_v1(7, PALW_MODEL_SEED_MIN_SOMPI_V1, Hash64::from_u64_word(9))
    }

    /// ADR-0090 §4's worked table, from a market seeded with the least seed (100,000 MSK): two
    /// buys of 1,000 MSK, then the sell of everything bought. Whole positions, no virtual reserve,
    /// the product taken from the row at every move.
    #[test]
    fn the_adr_table_is_the_curves_arithmetic() {
        let m0 = seeded();
        assert_eq!(m0.msk_reserve, 100_000 * MSK, "the seed is the reserve, fee-free");
        assert_eq!(m0.position_units, 500_000, "five hundred thousand whole positions in the curve");
        assert_eq!(m0.price_sompi_per_position_v1(), MSK / 5, "the first position costs seed / supply = 0.2 MSK");
        let b1 = palw_model_buy_quote_v1(&m0, 1_000 * MSK).expect("a buy");
        assert_eq!(b1.fees.burn, 50 * MSK);
        assert_eq!(b1.fees.registrant, 10 * MSK);
        assert_eq!(b1.fees.net, 940 * MSK);
        assert_eq!(b1.units_out, 4_656, "940 MSK into a 100,000 MSK reserve releases 4,656 whole positions");
        assert_eq!(b1.after.msk_reserve, 100_940 * MSK);
        assert_eq!(b1.after.price_sompi_per_position_v1(), 20_377_757, "0.20377757 MSK a position");
        let b2 = palw_model_buy_quote_v1(&b1.after, 1_000 * MSK).expect("a second buy");
        assert_eq!(b2.units_out, 4_570, "the same MSK releases fewer positions at the higher price");
        assert_eq!(b2.after.msk_reserve, 101_880 * MSK);
        assert!(b2.after.price_sompi_per_position_v1() > b1.after.price_sompi_per_position_v1(), "buying raises the price");
        let held = b1.units_out + b2.units_out;
        let s = palw_model_sell_quote_v1(&b2.after, held).expect("the sell");
        assert_eq!(s.fees.gross, 187_988_976_000, "returning every position bought pays back 1,879.88976 MSK gross");
        assert_eq!(s.fees.net, 176_709_637_440, "1,767.0963744 MSK net: 12 % of the legs, the curve's rounding kept");
        assert_eq!(s.fees.burn + s.fees.registrant + s.fees.net, s.fees.gross, "the split is exact");
        assert_eq!(s.after.position_units, PALW_MODEL_SUPPLY_UNITS_V1, "everything bought is back in the curve");
        assert!(s.after.msk_reserve >= m0.seed_sompi, "and the reserve is at or above the seed: {}", s.after.msk_reserve);
        assert!(s.after.price_sompi_per_position_v1() < b2.after.price_sompi_per_position_v1(), "selling lowers the price");
        // M2 at the arithmetic layer: what went in is where the ADR says it is.
        let paid_in = 2_000 * MSK;
        let burned = s.after.burned_sompi;
        let registrant = b1.fees.registrant + b2.fees.registrant + s.fees.registrant;
        assert_eq!(
            paid_in + m0.seed_sompi,
            s.after.msk_reserve + s.fees.net + burned + registrant,
            "nothing is minted, nothing vanishes"
        );
    }

    /// ADR-0090 P1: the reserve never falls under the seed — the product never falls, and with
    /// every position in the curve the product is `seed × supply`. Tried at every size, both moves.
    #[test]
    fn the_product_never_falls_and_the_seed_never_leaves() {
        let mut m = seeded();
        let mut k = m.k();
        for msk_in in [1u64, 999, MSK, 37 * MSK, 1_000 * MSK, 123_456_789_012] {
            let Some(q) = palw_model_buy_quote_v1(&m, msk_in) else { continue };
            assert!(q.after.k() >= k, "buy {msk_in}: product {} < {k}", q.after.k());
            k = q.after.k();
            m = q.after;
        }
        let bought = PALW_MODEL_SUPPLY_UNITS_V1 - m.position_units;
        for units in [1u64, 12_345, bought / 3, bought / 2] {
            let Some(q) = palw_model_sell_quote_v1(&m, units) else { continue };
            assert!(q.after.k() >= k, "sell {units}: product {} < {k}", q.after.k());
            assert!(q.after.msk_reserve >= m.seed_sompi, "sell {units}: the reserve {} fell under the seed", q.after.msk_reserve);
            k = q.after.k();
            m = q.after;
        }
        // and the rest, so every position is back in the curve
        let rest = PALW_MODEL_SUPPLY_UNITS_V1 - m.position_units;
        let q = palw_model_sell_quote_v1(&m, rest).expect("the rest sells");
        assert!(q.after.k() >= k);
        m = q.after;
        assert_eq!(m.position_units, PALW_MODEL_SUPPLY_UNITS_V1);
        assert!(m.msk_reserve >= m.seed_sompi, "with every position back, the reserve is the seed or more: {}", m.msk_reserve);
    }

    /// **ADR-0090 Decision 2's floor is a refusal, not an observation** (mainnet audit 2026-09-06,
    /// M-12).
    ///
    /// The decision says "the reserve never falls under it [the seed]", and until this repair that
    /// was true only because `div_ceil`'s rounding and the `.min(msk_reserve)` cap happened to make
    /// it so — asserted in a test, enforced nowhere. The coinbase mints a market payout with
    /// nothing withheld, so a quote that pays out of the locked seed would move real money.
    ///
    /// The rows here are built BY HAND, at and below the floor, precisely because the curve cannot
    /// reach them today: a test that only re-runs the curve agrees with the curve, and would go on
    /// passing if a future rounding change let the reserve fall. The rule asserted is the ADR's
    /// sentence — a quote whose `after` breaks the floor or lowers the product does not exist —
    /// not the particular arithmetic that satisfies it.
    #[test]
    fn a_quote_that_would_break_the_floor_is_refused_not_returned() {
        let seed_sompi = PALW_MODEL_SEED_MIN_SOMPI_V1;
        // A row the curve DOES reach: some positions sold, the reserve above the seed. Selling them
        // all back returns the reserve to the seed exactly, and that is legal — the floor is a
        // ceiling on what may leave, not a margin.
        let at_the_floor = PalwModelMarketV1 { msk_reserve: seed_sompi, ..seeded() };
        assert_eq!(at_the_floor.msk_reserve, at_the_floor.seed_sompi);
        // With the reserve at the floor and every position already in the curve, nothing can leave.
        assert!(
            palw_model_sell_quote_v1(&at_the_floor, 1).is_none(),
            "a market holding only its seed pays nothing: units_after would exceed the supply"
        );

        // A row that HAS sold positions and sits at its floor: any sell would have to pay out of
        // the seed, so every sell is refused — at one unit and at the whole outstanding block.
        let outstanding = 10_000u64;
        let sold_at_the_floor = PalwModelMarketV1 {
            msk_reserve: seed_sompi,
            position_units: PALW_MODEL_SUPPLY_UNITS_V1 - outstanding,
            sold_units: outstanding,
            ..seeded()
        };
        for units in [1u64, 7, outstanding / 2, outstanding] {
            assert!(
                palw_model_sell_quote_v1(&sold_at_the_floor, units).is_none(),
                "sell of {units}: the reserve is the seed, so any payout comes out of the locked seed"
            );
        }

        // A row BELOW its floor — a state the design says cannot exist. Whatever put it there, no
        // quote may take it further down.
        let under_the_floor = PalwModelMarketV1 { msk_reserve: seed_sompi - 1, ..sold_at_the_floor };
        for units in [1u64, 7, outstanding] {
            assert!(palw_model_sell_quote_v1(&under_the_floor, units).is_none(), "sell of {units} from under the floor");
        }

        // ..and the refusal is about the FLOOR, not about selling: the same row with a reserve
        // above its seed quotes, and what it quotes still leaves the reserve at or above the seed.
        let above = PalwModelMarketV1 { msk_reserve: seed_sompi * 2, ..sold_at_the_floor };
        let q = palw_model_sell_quote_v1(&above, outstanding).expect("a market above its floor pays for a sell");
        assert!(q.after.msk_reserve >= above.seed_sompi, "and what it pays leaves the seed where ADR-0090 put it");
        assert!(q.after.k() >= above.k(), "ADR-0090 P1: the product never falls");
    }

    /// ADR-0090 Decision 1: a position is whole. A buy that would release less than one position
    /// releases nothing (refused at the fold), and the smallest buy that releases one releases
    /// exactly one.
    #[test]
    fn a_position_is_whole_and_a_dust_buy_releases_nothing() {
        let m0 = seeded();
        assert!(palw_model_buy_quote_v1(&m0, MSK / 10).is_none(), "0.1 MSK buys no whole position at 0.2 MSK each");
        let one = palw_model_buy_quote_v1(&m0, 22 * MSK / 100).expect("0.22 MSK buys one");
        assert_eq!(one.units_out, 1);
        assert_eq!(PALW_MODEL_POSITION_UNITS_V1, 1, "a position is the unit");
    }

    /// A buy and an immediate sell of what it bought returns 0.94² of the gross less slippage,
    /// and never more (M4).
    #[test]
    fn a_round_trip_pays_the_fees_twice_and_the_slippage_once() {
        let m0 = seeded();
        let b = palw_model_buy_quote_v1(&m0, 100 * MSK).expect("a buy");
        let s = palw_model_sell_quote_v1(&b.after, b.units_out).expect("the sell");
        assert!(s.fees.net <= 94 * 94 * MSK / 100, "at most 0.94² of the gross came back: {}", s.fees.net);
        assert!(s.fees.net > 80 * MSK, "and most of it did: {}", s.fees.net);
        assert_eq!(s.after.position_units, PALW_MODEL_SUPPLY_UNITS_V1);
    }

    /// **ADR-0114's schedule, as the ADR's worked table**: the same two buys of 1,000 MSK and the
    /// sell of everything bought, from the least seed, with the owner's leg at 5 %. Every number is
    /// the curve's own arithmetic; the V1 table above is untouched by the schedule existing.
    #[test]
    fn the_v2_schedule_pays_the_owner_five_percent_and_leaves_the_v1_table_alone() {
        assert_eq!(PalwModelFeesV1::at(false), PalwModelFeesV1::V1);
        assert_eq!(PalwModelFeesV1::at(true), PalwModelFeesV1::V2);
        assert_eq!(PalwModelFeesV1::V2, PalwModelFeesV1 { burn_permille: 50, leg_permille: 50 }, "5 % burned, 5 % to the owner");
        let m0 = seeded();
        let v1 = palw_model_buy_quote_v1(&m0, 1_000 * MSK).unwrap();
        assert_eq!(palw_model_buy_quote_with(&m0, 1_000 * MSK, PalwModelFeesV1::V1), Some(v1), "V1 through the new door is V1");
        let b1 = palw_model_buy_quote_with(&m0, 1_000 * MSK, PalwModelFeesV1::V2).expect("a buy");
        assert_eq!((b1.fees.burn, b1.fees.registrant, b1.fees.net), (50 * MSK, 50 * MSK, 900 * MSK));
        assert_eq!(b1.units_out, 4_459, "900 MSK into a 100,000 MSK reserve releases 4,459 whole positions");
        assert_eq!(b1.after.msk_reserve, 100_900 * MSK);
        assert_eq!(b1.after.price_sompi_per_position_v1(), 20_361_584);
        let b2 = palw_model_buy_quote_with(&b1.after, 1_000 * MSK, PalwModelFeesV1::V2).expect("a second buy");
        assert_eq!(b2.units_out, 4_381);
        assert_eq!(b2.after.msk_reserve, 101_800 * MSK);
        let held = b1.units_out + b2.units_out;
        let s = palw_model_sell_quote_with(&b2.after, held, PalwModelFeesV1::V2).expect("the sell");
        assert_eq!(s.fees.gross, 179_982_400_000);
        assert_eq!((s.fees.burn, s.fees.registrant, s.fees.net), (8_999_120_000, 8_999_120_000, 161_984_160_000));
        assert_eq!(s.fees.burn + s.fees.registrant + s.fees.net, s.fees.gross, "the split is exact");
        assert_eq!(s.after.msk_reserve, 10_000_017_600_000, "the reserve ends above the seed");
        let legs = b1.fees.registrant + b2.fees.registrant + s.fees.registrant;
        let burned = b1.fees.burn + b2.fees.burn + s.fees.burn;
        assert_eq!(
            2_000 * MSK + m0.seed_sompi,
            s.after.msk_reserve + s.fees.net + burned + legs,
            "M2: nothing minted, nothing vanishes"
        );
        // The round trip the ADR names: a join and a leave of what it bought return at most 0.9² of
        // the MSK — a fifth goes to the burn and the owner, and the slippage is on top.
        let b = palw_model_buy_quote_with(&m0, 100 * MSK, PalwModelFeesV1::V2).unwrap();
        let back = palw_model_sell_quote_with(&b.after, b.units_out, PalwModelFeesV1::V2).unwrap();
        assert!(back.fees.net <= 90 * 90 * MSK / 100, "at most 0.9² came back: {}", back.fees.net);
        assert_eq!(back.fees.net, 8_089_273_800, "80.892738 MSK of 100");
    }

    /// A closed market refuses buys and honours sells (M6, at this layer).
    #[test]
    fn a_closed_market_refuses_buys_and_honours_sells() {
        let m0 = seeded();
        let b = palw_model_buy_quote_v1(&m0, 10 * MSK).expect("a buy");
        let closed = PalwModelMarketV1 { closed_to_buys: true, ..b.after };
        assert!(palw_model_buy_quote_v1(&closed, 10 * MSK).is_none());
        assert!(palw_model_sell_quote_v1(&closed, b.units_out).is_some());
    }

    /// The sink script names its class and nothing else does.
    #[test]
    fn the_sink_script_names_its_class_and_is_an_early_return() {
        let class = Hash64::from_bytes([7u8; 64]);
        let spk = palw_model_sink_spk_v1(&class);
        assert_eq!(spk.script()[0], OP_RETURN);
        assert_eq!(palw_model_sink_class_v1(&spk), Some(class));
        let other = crate::mldsa87_primitives::p2pkh_mldsa87_spk(&[9u8; 64]);
        assert_eq!(palw_model_sink_class_v1(&other), None);
        let mut forged = spk.script().to_vec();
        forged[3] ^= 1;
        assert_eq!(palw_model_sink_class_v1(&ScriptPublicKey::new(0, crate::tx::ScriptVec::from_slice(&forged))), None);
    }

    /// **A sell signature authorises one sale, on one chain, out of one position, until one score**
    /// (mainnet audit 2026-09-06, M-11).
    ///
    /// ADR-0087 M8 is "no other key can sell it". The message as first written bound the domain,
    /// the line, the holder, the units and the floor — and nothing else — so a stranger could copy
    /// the public payload out of a mined transaction and re-fire it whenever the holder held
    /// `units_in` again. The rule this test states is that every input a replay would have to reuse
    /// is IN the signed bytes: change any one of the seven and the holder's signature no longer
    /// speaks for it.
    ///
    /// The three that were missing are asserted first, because those are the ones the old message
    /// would have passed this test without.
    #[test]
    fn a_sell_signature_authorises_one_sale_on_one_chain_and_then_dies() {
        let (c, h) = (Hash64::from_bytes([1u8; 64]), Hash64::from_bytes([2u8; 64]));
        let net_a = Hash64::from_bytes([3u8; 64]);
        let net_b = Hash64::from_bytes([4u8; 64]);
        let m = palw_model_sell_message_v1(net_a, &c, &h, 5, 6, 40, 1_000);

        // The three the audit found missing.
        assert_ne!(m, palw_model_sell_message_v1(net_b, &c, &h, 5, 6, 40, 1_000), "one chain: the network domain is signed");
        assert_ne!(m, palw_model_sell_message_v1(net_a, &c, &h, 5, 6, 41, 1_000), "one position: `held_units` is signed");
        assert_ne!(m, palw_model_sell_message_v1(net_a, &c, &h, 5, 6, 40, 1_001), "one window: `not_after_daa` is signed");

        // ..and the four it always had.
        assert_ne!(m, palw_model_sell_message_v1(net_a, &c, &h, 5, 7, 40, 1_000), "the floor is signed");
        assert_ne!(m, palw_model_sell_message_v1(net_a, &c, &h, 6, 6, 40, 1_000), "the size is signed");
        assert_ne!(m, palw_model_sell_message_v1(net_a, &h, &c, 5, 6, 40, 1_000), "the line and the holder are signed");
        assert!(m.starts_with(PALW_MODEL_SELL_SIGN_DOMAIN_V1), "and the tag says which message this is");

        // No two of the seven can be swapped for one another to reach the same bytes: every field
        // has a fixed offset, so the message is unambiguous rather than merely different.
        let all: Vec<Vec<u8>> = vec![
            m.clone(),
            palw_model_sell_message_v1(net_b, &c, &h, 5, 6, 40, 1_000),
            palw_model_sell_message_v1(net_a, &h, &c, 5, 6, 40, 1_000),
            palw_model_sell_message_v1(net_a, &c, &h, 6, 6, 40, 1_000),
            palw_model_sell_message_v1(net_a, &c, &h, 5, 7, 40, 1_000),
            palw_model_sell_message_v1(net_a, &c, &h, 5, 6, 41, 1_000),
            palw_model_sell_message_v1(net_a, &c, &h, 5, 6, 40, 1_001),
        ];
        for (i, a) in all.iter().enumerate() {
            assert_eq!(a.len(), m.len(), "every message is the same fixed length");
            for b in all.iter().skip(i + 1) {
                assert_ne!(a, b, "seven distinct commitments produce seven distinct messages");
            }
        }

        // The ceiling on the window is a real bound, not a comment: a holder cannot sign "forever".
        assert_eq!(PALW_MODEL_SELL_MAX_WINDOW_DAA_V1, 4_000, "the longest authority the chain honours");
    }

    /// **The window is inclusive at its end and bounded at its start** (mainnet audit 2026-09-06,
    /// M-11) — the two edges a holder and a miner disagree about if either is left to a comment.
    #[test]
    fn a_sell_authority_is_live_up_to_its_own_score_and_no_longer_than_the_ceiling() {
        let max = PALW_MODEL_SELL_MAX_WINDOW_DAA_V1;
        // The score the holder signed for is a score the sell still fills at.
        assert_eq!(palw_model_sell_window_v1(1_000, 1_000), PalwModelSellWindowV1::Live, "inclusive at the end");
        assert_eq!(palw_model_sell_window_v1(1_001, 1_000), PalwModelSellWindowV1::Expired, "and dead one score later");
        assert_eq!(palw_model_sell_window_v1(u64::MAX, 1_000), PalwModelSellWindowV1::Expired);

        // The longest window the chain honours is exactly the ceiling, and one past it is refused
        // wherever the block sits — so "forever" is not expressible at any height.
        assert_eq!(palw_model_sell_window_v1(500, 500 + max), PalwModelSellWindowV1::Live, "the legal maximum window");
        assert_eq!(
            palw_model_sell_window_v1(500, 500 + max + 1),
            PalwModelSellWindowV1::TooLong { daa: max + 1 },
            "one score longer is refused, and the refusal names the span asked for"
        );
        assert!(matches!(palw_model_sell_window_v1(0, u64::MAX), PalwModelSellWindowV1::TooLong { .. }), "no bearer instrument");
        assert_eq!(palw_model_sell_window_v1(0, 0), PalwModelSellWindowV1::Live, "and a window of zero is a window");
    }

    /// ADR-0091 §4's worked numbers: testnet-11's block (escrow 229,690,373 sompi) from the least
    /// seed — the slice, the miner's rest, one block, a day of blocks — and a block big enough
    /// to retire positions.
    #[test]
    fn the_reward_slice_is_worked_as_the_adr_table() {
        let escrow = 229_690_373u64;
        let slice = palw_model_buyback_slice_v1(escrow);
        assert_eq!(slice, 11_484_518, "five percent of the escrow, rounded down");
        assert_eq!(escrow - slice, 218_205_855, "the other ninety-five percent is the miner's");
        let m0 = seeded();
        let one = palw_model_buyback_quote_v1(&m0, slice).expect("a seeded, open market takes the slice");
        assert_eq!(one.after.msk_reserve, 10_000_011_484_518, "the whole slice is reserve, no leg");
        assert_eq!(
            (one.after.position_units, one.retired, one.after.retired_units),
            (500_000, 0, 0),
            "under one position's price: nothing retired"
        );
        assert_eq!(one.after.price_sompi_per_position_v1(), 20_000_022, "and the price rose anyway");
        assert_eq!(one.after.buyback_sompi, slice);
        assert!(one.after.k() > m0.k(), "the product rose");
        let mut m = m0;
        for _ in 0..720 {
            m = palw_model_buyback_quote_v1(&m, slice).unwrap().after;
        }
        assert_eq!(
            (m.msk_reserve, m.position_units, m.price_sompi_per_position_v1()),
            (10_008_268_852_960, 500_000, 20_016_537),
            "a day of such blocks"
        );
        assert_eq!(m.buyback_sompi, 720 * slice);
        // A network whose subsidy were 100 MSK a block: escrow 62 MSK, slice 3.1 MSK — 15 positions retire.
        let big = palw_model_buyback_slice_v1(62 * MSK);
        assert_eq!(big, 310_000_000);
        let q = palw_model_buyback_quote_v1(&m0, big).unwrap();
        assert_eq!((q.after.position_units, q.retired, q.after.retired_units), (499_985, 15, 15));
        assert_eq!(q.after.price_sompi_per_position_v1(), 20_001_220);
        assert_eq!(q.after.position_units + q.after.retired_units, PALW_MODEL_SUPPLY_UNITS_V1, "M1 with the retired counted");
        // No pair takes a slice where the market is closed, or there is nothing to add.
        assert!(palw_model_buyback_quote_v1(&PalwModelMarketV1 { closed_to_buys: true, ..m0 }, slice).is_none());
        assert!(palw_model_buyback_quote_v1(&m0, 0).is_none());
        assert!(
            palw_model_buyback_quote_v1(&PalwModelMarketV1::seed_v1(1, 0, Hash64::default()), slice).is_none(),
            "an unseeded row is not a market"
        );
    }

    /// ADR-0091 B6 / ADR-0090 P1 over the new move: buys, buybacks and sells in any order never
    /// lower the product, never take the reserve under the seed, and keep the supply whole with
    /// the retired positions counted.
    #[test]
    fn the_product_never_falls_under_the_reward_too() {
        let mut m = seeded();
        let mut k = m.k();
        let mut held = 0u64;
        for (i, x) in [1u64, 37 * MSK, 11_484_518, 1_000 * MSK, 31_000_000_000, 999, 250 * MSK, 5 * MSK].iter().enumerate() {
            if i % 2 == 0 {
                let q = palw_model_buyback_quote_v1(&m, *x).expect("the pair takes every slice");
                assert!(q.after.k() >= k, "buyback {x}: product fell");
                assert_eq!(q.after.position_units + q.retired, m.position_units, "what left the curve was retired");
                m = q.after;
            } else if let Some(q) = palw_model_buy_quote_v1(&m, *x) {
                held += q.units_out;
                m = q.after;
            }
            k = m.k();
            assert_eq!(m.position_units + held + m.retired_units, PALW_MODEL_SUPPLY_UNITS_V1, "M1 at every stop");
        }
        assert!(m.retired_units > 0, "the 310 MSK slice retired positions");
        let s = palw_model_sell_quote_v1(&m, held).expect("everything held sells");
        assert!(s.after.k() >= k);
        assert!(s.after.msk_reserve >= s.after.seed_sompi, "the reserve stays at or above the seed");
        assert_eq!(
            s.after.position_units + s.after.retired_units,
            PALW_MODEL_SUPPLY_UNITS_V1,
            "sold out: the curve plus the retired is the supply"
        );
        assert!(palw_model_sell_quote_v1(&s.after, 1).is_none(), "and nothing can sell a retired position back: the curve is full");
    }

    /// **The sell-net payee is the key's spendable payload, and the holder id is left as it was**
    /// (the 2026-09-23 Position route matrix, P-B4). A testnet-12 genesis bond card's
    /// `payout_payload` is a keyed address payload that genesis already pays, so it is the known
    /// spendable value for that card's key. The sell-net payload must be that value, and the holder
    /// id must not be: an output locked to the id is one `OP_BLAKE2B_512` never matches.
    #[test]
    fn the_sell_net_payload_is_the_keys_address_and_the_holder_id_is_not() {
        use crate::mldsa87_primitives::{mldsa87_key_id, p2pkh_mldsa87_spk};
        assert!(!crate::config::params::PALW_T12_GENESIS_BONDS.is_empty());
        for (n, card) in crate::config::params::PALW_T12_GENESIS_BONDS.iter().enumerate() {
            let paid = palw_model_sell_net_payload_v1(card.bond_pubkey);
            let holder = palw_model_holder_of_pubkey_v1(card.bond_pubkey);
            assert_eq!(paid.as_bytes(), card.payout_payload, "card {n}: the net leg goes where this key's bond is already paid");
            assert_eq!(paid, kaspa_hashes::blake2b_512_address_payload(card.bond_pubkey), "card {n}: the wallet's address payload");
            assert_eq!(holder, mldsa87_key_id(card.bond_pubkey), "card {n}: the holder id (the position key) did not move");
            assert_ne!(holder, paid, "card {n}: the id is not the payload");
            assert_ne!(p2pkh_mldsa87_spk(&holder.as_bytes()), p2pkh_mldsa87_spk(&paid.as_bytes()), "card {n}: two different locks");
        }
    }
}

/// **ADR-0162 — the pair opens on a virtual reserve: the arithmetic's half of the invariants.**
///
/// I-V1..I-V8 are stated in the ADR (§6). The fold's half — the gates, the late seed refused at the
/// fold, I-V9 and I-V10 — is `palw_state_v2::tests::model_market_virtual`. Every random sequence here
/// is drawn from a fixed seed by a splitmix64, so a failure names the case that reproduces it.
#[cfg(test)]
mod adr0162_virtual_reserve {
    use super::*;

    const MSK: u64 = 100_000_000;
    const V: u64 = PALW_MODEL_MARKET_VIRTUAL_SOMPI_V2;
    const SUPPLY: u64 = PALW_MODEL_SUPPLY_UNITS_V1;
    /// The worked table's schedule: no fee, so a row shows the curve's own arithmetic and nothing else.
    const FREE: PalwModelFeesV1 = PalwModelFeesV1 { burn_permille: 0, leg_permille: 0 };

    fn opened() -> PalwModelMarketV1 {
        PalwModelMarketV1::open_virtual_v2(7, V)
    }

    fn payer() -> Hash64 {
        Hash64::from_u64_word(0x5EED)
    }

    /// splitmix64 — a fixed stream per case, no dependency.
    struct Rng(u64);
    impl Rng {
        fn next(&mut self) -> u64 {
            self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
            let mut z = self.0;
            z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
            z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
            z ^ (z >> 31)
        }
        fn below(&mut self, n: u64) -> u64 {
            self.next() % n.max(1)
        }
        /// An amount spread over many orders of magnitude, from a sompi to `max`.
        fn amount(&mut self, max: u64) -> u64 {
            let digits = 1 + self.below(19) as u32;
            (self.next() % 10u64.saturating_pow(digits)).clamp(1, max)
        }
    }

    /// **ADR-0162 §4's worked table, and nothing in it is typed**: from the opening (`X = 10,000,000
    /// MSK`, 500,000 positions, no seed, no fee), A buys with 100,000 MSK, B with 1,000,000 MSK, A sells
    /// everything, B sells everything — and then the same four moves under ADR-0087's and ADR-0114's
    /// schedules. Every number is the curve's own arithmetic with its real rounding.
    #[test]
    fn the_adr_0162_table_is_the_virtual_curves_arithmetic() {
        let m0 = opened();
        assert!(m0.is_open(), "a market from its line's creation, with no MSK in it");
        assert_eq!((m0.msk_reserve, m0.position_units, m0.seed_sompi, m0.virtual_sompi), (0, SUPPLY, 0, V));
        assert_eq!(m0.price_sompi_per_position_v1(), 20 * MSK, "I-V9: the first quote is V / 500,000 = 20 MSK");
        assert_eq!(m0.price_floor_sompi_per_position_v2(), 20 * MSK, "and the floor starts at the price");
        let a = palw_model_buy_quote_with(&m0, 100_000 * MSK, FREE).expect("A's buy");
        assert_eq!(a.units_out, 4_950, "100,000 MSK into X = 10,000,000 MSK releases 4,950 whole positions");
        assert_eq!(a.after.price_sompi_per_position_v1(), 2_040_197_959);
        let b = palw_model_buy_quote_with(&a.after, 1_000_000 * MSK, FREE).expect("B's buy");
        assert_eq!(b.units_out, 44_599);
        assert_eq!(b.after.price_sompi_per_position_v1(), 2_464_196_993, "≈ 24.64 MSK");
        assert_eq!(b.after.msk_reserve, 1_100_000 * MSK, "the real reserve is what was paid in, and nothing else");
        let sa = palw_model_sell_quote_with(&b.after, a.units_out, FREE).expect("A sells everything");
        assert_eq!(sa.fees.gross, 12_065_190_897_692, "A is paid 120,651.90897692 MSK");
        assert_eq!(sa.after.price_sompi_per_position_v1(), 2_410_918_748);
        let sb = palw_model_sell_quote_with(&sa.after, b.units_out, FREE).expect("B sells everything");
        assert_eq!(sb.fees.gross, 97_933_589_102_307, "B is paid 979,335.89102307 MSK");
        assert_eq!(sb.after.position_units, SUPPLY, "every position is back in the curve");
        assert_eq!(sb.after.msk_reserve, 1_220_000_001, "and the real reserve ends at 12.2 MSK: the rounding's dust");
        assert_eq!(sb.after.price_sompi_per_position_v1(), 2_000_002_440, "the price is back at the floor, plus the dust");
        assert_eq!(sa.fees.gross + sb.fees.gross + sb.after.msk_reserve, 1_100_000 * MSK, "nobody was paid out of V");

        // The same four moves under both fee schedules: the curve is scale-free, so 94,000 MSK into
        // ten million releases ADR-0090 §4's 4,656 (940 into a hundred thousand).
        type Row = (PalwModelFeesV1, u64, u64, u64, u64, u64);
        let rows: [Row; 2] = [
            (PalwModelFeesV1::V1, 4_656, 42_198, 10_548_631_452_026, 86_644_931_315_975, 2_592_800_001),
            (PalwModelFeesV1::V2, 4_459, 40_581, 9_599_944_495_113, 79_498_183_504_888, 2_080_000_001),
        ];
        for (fees, a_units, b_units, a_net, b_net, dust) in rows {
            let a = palw_model_buy_quote_with(&m0, 100_000 * MSK, fees).unwrap();
            let b = palw_model_buy_quote_with(&a.after, 1_000_000 * MSK, fees).unwrap();
            assert_eq!((a.units_out, b.units_out), (a_units, b_units), "{fees:?}");
            let sa = palw_model_sell_quote_with(&b.after, a.units_out, fees).unwrap();
            let sb = palw_model_sell_quote_with(&sa.after, b.units_out, fees).unwrap();
            assert_eq!((sa.fees.net, sb.fees.net, sb.after.msk_reserve), (a_net, b_net, dust), "{fees:?}");
            let legs = a.fees.registrant + b.fees.registrant + sa.fees.registrant + sb.fees.registrant;
            let burned = a.fees.burn + b.fees.burn + sa.fees.burn + sb.fees.burn;
            assert_eq!(1_100_000 * MSK, sb.after.msk_reserve + sa.fees.net + sb.fees.net + burned + legs, "{fees:?}: M2");
        }
    }

    /// **The curve's depth at the opening** (ADR-0162 §5.4): the price is `X² / K`, so doubling it
    /// takes `(√2 − 1) × V` ≈ 4.14 M MSK, four times `V` = 10 M, ten times `(√10 − 1) × V` ≈ 21.6 M — net
    /// legs, no fee. The whole positions round each threshold up by a few dozen MSK: the curve keeps
    /// the fraction of a position a buy cannot be paid in.
    #[test]
    fn doubling_the_first_price_takes_four_million_msk_and_ten_times_it_takes_twenty_one() {
        let m0 = opened();
        let at = |net_msk: u64| palw_model_buy_quote_with(&m0, net_msk * MSK, FREE).unwrap().after.price_sompi_per_position_v1();
        assert!(at(4_142_100) < 40 * MSK && at(4_142_200) >= 40 * MSK, "2×: {} / {}", at(4_142_100), at(4_142_200));
        assert_eq!(at(10_000_000), 80 * MSK, "4× at exactly V: half the positions leave");
        assert!(at(21_622_700) < 200 * MSK && at(21_623_000) >= 200 * MSK, "10×: {} / {}", at(21_622_700), at(21_623_000));
    }

    /// **I-V4: a virtual market quotes every move exactly as ADR-0090's pair seeded with `S = V`**,
    /// because nobody is ever paid out of a seed either: the locked seed's one effect was its opener's
    /// permanent cost. Random buys, sells and reward slices, a pre-trade seed or none, under both
    /// schedules: every quote equal, every product equal, the real reserves `V` apart.
    #[test]
    fn a_virtual_market_quotes_every_move_as_a_pair_seeded_with_v() {
        for schedule in [PalwModelFeesV1::V1, PalwModelFeesV1::V2, FREE] {
            for case in 0..64u64 {
                let mut rng = Rng(case.wrapping_mul(0xA5A5) ^ schedule.leg_permille);
                let pre_seed = if case % 3 == 0 { 0 } else { rng.amount(5_000_000 * MSK) };
                let mut virt = opened();
                if pre_seed > 0 {
                    virt = palw_model_seed_deepen_v2(&virt, &payer(), pre_seed).expect("a seed before the first trade");
                }
                let mut seeded = PalwModelMarketV1::seed_v1(7, V + pre_seed, payer());
                let mut held = 0u64;
                for step in 0..48 {
                    let what = format!("case {case} step {step} {schedule:?}");
                    assert_eq!(virt.k(), seeded.k(), "{what}: one product");
                    assert_eq!(virt.msk_reserve + V, seeded.msk_reserve, "{what}: the reserves are V apart");
                    assert_eq!(virt.price_sompi_per_position_v1(), seeded.price_sompi_per_position_v1(), "{what}");
                    match rng.below(3) {
                        0 => {
                            let msk_in = rng.amount(3_000_000 * MSK);
                            let (qv, qs) = (
                                palw_model_buy_quote_with(&virt, msk_in, schedule),
                                palw_model_buy_quote_with(&seeded, msk_in, schedule),
                            );
                            assert_eq!(qv.map(|q| (q.units_out, q.fees)), qs.map(|q| (q.units_out, q.fees)), "{what}: buy {msk_in}");
                            if let (Some(qv), Some(qs)) = (qv, qs) {
                                held += qv.units_out;
                                (virt, seeded) = (qv.after, qs.after);
                            }
                        }
                        1 if held > 0 => {
                            let units = 1 + rng.below(held);
                            let (qv, qs) = (
                                palw_model_sell_quote_with(&virt, units, schedule),
                                palw_model_sell_quote_with(&seeded, units, schedule),
                            );
                            assert_eq!(qv.map(|q| q.fees), qs.map(|q| q.fees), "{what}: sell {units}");
                            if let (Some(qv), Some(qs)) = (qv, qs) {
                                held -= units;
                                (virt, seeded) = (qv.after, qs.after);
                            }
                        }
                        _ => {
                            let slice = rng.amount(50 * MSK);
                            let (qv, qs) = (palw_model_buyback_quote_v1(&virt, slice), palw_model_buyback_quote_v1(&seeded, slice));
                            assert_eq!(qv.map(|q| q.retired), qs.map(|q| q.retired), "{what}: reward slice {slice}");
                            if let (Some(qv), Some(qs)) = (qv, qs) {
                                (virt, seeded) = (qv.after, qs.after);
                            }
                        }
                    }
                }
            }
        }
    }

    /// The moves a random history is made of, and what each did, so the invariants can be summed.
    #[derive(Default)]
    struct Books {
        seeds: u128,
        net_in: u128,
        gross_out: u128,
        buyback_in: u128,
        held: u64,
        /// What the roundings can have added to the product: under `X′` for a buy and for a slice
        /// that retired positions (`⌈K / X′⌉` whole positions), under `units′` for a sell
        /// (`⌈K / units′⌉` sompi). A slice that retires nothing adds `slice × units` to the product
        /// exactly — that is the reward's, not the rounding's, and it is not counted here.
        slack: u128,
        moves: u128,
    }

    impl Books {
        /// I-V6's dust: the slack spread over the positions the curve can hold at the end, plus a
        /// sompi a move for the divisions — under one position's worth a move, at that move's price.
        fn dust(&self, room: u64) -> u128 {
            self.slack / room as u128 + self.moves + 1
        }
    }

    /// **I-V1, I-V2, I-V3, I-V5 and I-V6 over random histories, under both schedules.** A history
    /// pays its seeds first (ADR-0162 Decision 4: a seed is taken only before the first trade), then
    /// buys, sells and the reward's slices in any order, then sells every position still held.
    /// Checked at every stop: the real reserve never falls under the locked seed (I-V1); the sells'
    /// gross never exceeds the buys' net plus the slices — nobody is paid out of `V` or a seed (I-V2);
    /// the price is at or above the floor, the floor at or above `(V + seed) / supply` and never falls
    /// (I-V3); a position is whole and every rounding leaves the product at or above where it was
    /// (I-V5); conservation and M1 hold exactly. At the end, every position back (I-V6): the reserve
    /// is the seed, plus at least what the retired positions pin at the floor and at most the slices,
    /// plus less than one position's worth of dust a move.
    #[test]
    fn the_virtual_curve_holds_its_invariants_under_random_histories() {
        for schedule in [PalwModelFeesV1::V1, PalwModelFeesV1::V2] {
            for case in 0..96u64 {
                let mut rng = Rng(0xC0FFEE ^ case.wrapping_mul(0x1F1F_1F1F) ^ schedule.leg_permille);
                let mut m = opened();
                let mut books = Books::default();
                for _ in 0..rng.below(3) {
                    let s = rng.amount(20_000_000 * MSK);
                    m = palw_model_seed_deepen_v2(&m, &payer(), s).expect("a seed before the first trade is taken");
                    books.seeds += s as u128;
                }
                let static_floor = (V + m.seed_sompi) / SUPPLY;
                let mut floor = m.price_floor_sompi_per_position_v2();
                assert_eq!(floor, static_floor, "case {case}: at the opening the floor is (V + seed) / supply");
                let check = |m: &PalwModelMarketV1, books: &Books, floor: &mut u64, what: &str| {
                    assert!(m.msk_reserve >= m.seed_sompi, "{what}: I-V1");
                    assert!(books.gross_out <= books.net_in + books.buyback_in, "{what}: I-V2");
                    assert_eq!(
                        books.seeds + books.net_in + books.buyback_in,
                        m.msk_reserve as u128 + books.gross_out,
                        "{what}: conservation — what went in is the reserve or was paid out"
                    );
                    assert_eq!(m.position_units + books.held + m.retired_units, SUPPLY, "{what}: M1");
                    assert_eq!(m.positions_out(), books.held, "{what}: positions out");
                    let f = m.price_floor_sompi_per_position_v2();
                    assert!(f >= *floor && f >= static_floor, "{what}: I-V3 — the floor never falls ({f} < {})", *floor);
                    assert!(m.price_sompi_per_position_v1() >= f, "{what}: I-V3 — the price is never under the floor");
                    *floor = f;
                };
                let mut traded = false;
                for step in 0..80 {
                    let what = format!("{schedule:?} case {case} step {step}");
                    let k = m.k();
                    match rng.below(4) {
                        0 | 1 => {
                            let msk_in = rng.amount(4_000_000 * MSK);
                            if let Some(q) = palw_model_buy_quote_with(&m, msk_in, schedule) {
                                assert!(q.units_out >= 1 && q.after.k() >= k, "{what}: I-V5 on a buy");
                                assert_eq!(q.after.msk_reserve, m.msk_reserve + q.fees.net, "{what}: the net leg is the reserve's");
                                books.net_in += q.fees.net as u128;
                                books.held += q.units_out;
                                books.slack += q.after.curve_x();
                                books.moves += 1;
                                m = q.after;
                                traded = true;
                            }
                        }
                        2 if books.held > 0 => {
                            let units = 1 + rng.below(books.held);
                            let q = palw_model_sell_quote_with(&m, units, schedule).expect("a held position always sells");
                            assert!(q.after.k() >= k, "{what}: I-V5 on a sell");
                            assert!(q.fees.gross <= m.msk_reserve - m.seed_sompi, "{what}: I-V2 per move");
                            books.gross_out += q.fees.gross as u128;
                            books.held -= units;
                            books.slack += q.after.position_units as u128;
                            books.moves += 1;
                            m = q.after;
                        }
                        _ => {
                            let slice = rng.amount(2_000 * MSK);
                            let q = palw_model_buyback_quote_v1(&m, slice).expect("an open market takes every slice");
                            assert!(q.after.k() >= k, "{what}: I-V5 on a reward slice");
                            books.buyback_in += slice as u128;
                            if q.retired > 0 {
                                books.slack += q.after.curve_x();
                            }
                            books.moves += 1;
                            m = q.after;
                        }
                    }
                    if traded {
                        assert_eq!(palw_model_seed_deepen_v2(&m, &payer(), MSK), None, "{what}: I-V7 — no seed after the first trade");
                    }
                    check(&m, &books, &mut floor, &what);
                }
                if books.held > 0 {
                    let q = palw_model_sell_quote_with(&m, books.held, schedule).expect("everything held sells");
                    books.gross_out += q.fees.gross as u128;
                    books.slack += q.after.position_units as u128;
                    books.moves += 1;
                    books.held = 0;
                    m = q.after;
                    check(&m, &books, &mut floor, &format!("{schedule:?} case {case} sold out"));
                }
                // I-V6: every position back in the curve.
                assert_eq!(m.position_units + m.retired_units, SUPPLY);
                let reserve = m.msk_reserve as u128;
                let seed = m.seed_sompi as u128;
                let room = (SUPPLY - m.retired_units) as u128;
                let pinned = (V as u128 + seed) * m.retired_units as u128 / room;
                let dust = books.dust(SUPPLY - m.retired_units);
                assert!(reserve >= seed + pinned, "case {case}: the retired positions pin {pinned} of the slices in the reserve");
                assert!(
                    reserve <= seed + books.buyback_in + dust,
                    "case {case}: the reserve {reserve} is the seed {seed}, the slices {} and dust under {dust}",
                    books.buyback_in
                );
                if books.buyback_in == 0 {
                    assert!(reserve - seed <= dust, "case {case}: with no slice, what is left is dust alone");
                }
            }
        }
    }

    /// **I-V7: a seed after the first trade is refused, and this is the extraction it prevents.** A
    /// late seed raises the price of positions already out, so their holders sell part of it back out
    /// of the curve: here A, who paid 100,000 MSK, would be paid 131,521.45 MSK instead of 120,651.91,
    /// and B — the other holder — could then not leave at all, because the curve would have to pay out
    /// 99,085.80 MSK of the locked seed to let them. The row with the late seed is built BY HAND,
    /// because the function the fold calls refuses to build it.
    #[test]
    fn a_late_seed_would_be_sold_out_of_the_curve_so_it_is_refused() {
        let a = palw_model_buy_quote_with(&opened(), 100_000 * MSK, FREE).unwrap();
        let b = palw_model_buy_quote_with(&a.after, 1_000_000 * MSK, FREE).unwrap();
        let traded = b.after;
        assert_eq!(palw_model_seed_deepen_v2(&traded, &payer(), 1_000_000 * MSK), None, "refused: positions are out");
        assert_eq!(palw_model_seed_deepen_v2(&a.after, &payer(), MSK), None, "refused after a single trade too");
        let fair = palw_model_sell_quote_with(&traded, a.units_out, FREE).unwrap().fees.gross;
        assert_eq!(fair, 12_065_190_897_692);
        // What the seed would have done, had it been taken.
        let late = 1_000_000 * MSK;
        let seeded = PalwModelMarketV1 {
            msk_reserve: traded.msk_reserve + late,
            seed_sompi: traded.seed_sompi + late,
            seed_pledged_sompi: traded.seed_sompi + late,
            ..traded
        };
        let a_out = palw_model_sell_quote_with(&seeded, a.units_out, FREE).expect("A's sell still fits above the seed");
        assert_eq!(a_out.fees.gross, 13_152_145_032_619, "A is paid 131,521.45 MSK for what was worth 120,651.91");
        assert_eq!(a_out.fees.gross - fair, 1_086_954_134_927, "10,869.54 MSK of the late seed's price, taken out by A");
        // B now holds positions the curve values above everything it may pay without the seed.
        let x = a_out.after.curve_x();
        let units_after = a_out.after.position_units as u128 + b.units_out as u128;
        let wants = x - a_out.after.k().div_ceil(units_after);
        let payable = (a_out.after.msk_reserve - a_out.after.seed_sompi) as u128;
        assert_eq!((wants, payable), (106_756_434_967_380, 96_847_854_967_381));
        assert!(wants > payable, "B could only leave by being paid out of the locked seed");
        assert_eq!(palw_model_sell_quote_with(&a_out.after, b.units_out, FREE), None, "so B's sell is refused, whole");
        // Unguarded, the reserve would end 99,085.80 MSK under the seed that was "locked for good".
        assert_eq!(a_out.after.seed_sompi as u128 - (a_out.after.msk_reserve as u128 - wants), 9_908_579_999_999);
        // Before the first trade the same seed is safe: no position is out for anyone to sell it to.
        let early = palw_model_seed_deepen_v2(&opened(), &payer(), late).expect("taken before the first trade");
        assert_eq!((early.msk_reserve, early.seed_sompi, early.seeded_by), (late, late, payer()));
        assert_eq!(early.price_floor_sompi_per_position_v2(), (V + late) / SUPPLY, "it raised the floor by seed / supply");
        let again = palw_model_seed_deepen_v2(&early, &Hash64::from_u64_word(2), 3 * MSK).expect("as many payments as it takes");
        assert_eq!((again.seed_sompi, again.seeded_by), (late + 3 * MSK, payer()), "and the first payer stays the record");
        assert_eq!(palw_model_seed_deepen_v2(&early, &payer(), 0), None, "a payment of nothing is no seed");
    }

    /// **I-V8 at the arithmetic layer: with no virtual reserve every quote is ADR-0090's, byte for
    /// byte.** The pre-ADR-0162 quote functions are kept here verbatim — their `X` is the reserve and
    /// a market is a seed — and compared with the live ones on random rows that every pre-fence
    /// network can hold: seeded at either least seed, traded, slices taken, closed, sold out, and a
    /// hand-built row under its floor.
    #[test]
    fn with_no_virtual_reserve_every_quote_is_the_adr_0090_quote() {
        mod reference {
            use super::super::*;
            fn k(m: &PalwModelMarketV1) -> u128 {
                m.msk_reserve as u128 * m.position_units as u128
            }
            pub fn buy(market: &PalwModelMarketV1, msk_in: u64, schedule: PalwModelFeesV1) -> Option<PalwModelBuyQuoteV1> {
                if market.seed_sompi == 0
                    || market.closed_to_buys
                    || msk_in == 0
                    || market.position_units == 0
                    || market.msk_reserve == 0
                {
                    return None;
                }
                let fees = palw_model_fee_split_with(msk_in, schedule);
                let k0 = k(market);
                let units_after = k0.div_ceil(market.msk_reserve as u128 + fees.net as u128);
                let units_out = (market.position_units as u128).checked_sub(units_after)?;
                if units_out == 0 {
                    return None;
                }
                let units_out = units_out as u64;
                let after = PalwModelMarketV1 {
                    msk_reserve: market.msk_reserve.checked_add(fees.net)?,
                    position_units: market.position_units - units_out,
                    sold_units: market.sold_units.checked_add(units_out)?,
                    burned_sompi: market.burned_sompi.checked_add(fees.burn)?,
                    ..*market
                };
                (k(&after) >= k0).then_some(PalwModelBuyQuoteV1 { fees, units_out, after })
            }
            pub fn sell(market: &PalwModelMarketV1, units_in: u64, schedule: PalwModelFeesV1) -> Option<PalwModelSellQuoteV1> {
                if units_in == 0 || market.seed_sompi == 0 {
                    return None;
                }
                let k0 = k(market);
                let units_after = market.position_units as u128 + units_in as u128;
                if units_after > (PALW_MODEL_SUPPLY_UNITS_V1 - market.retired_units) as u128 {
                    return None;
                }
                let gross = (market.msk_reserve as u128).checked_sub(k0.div_ceil(units_after))?.min(market.msk_reserve as u128);
                if gross == 0 {
                    return None;
                }
                let fees = palw_model_fee_split_with(gross as u64, schedule);
                let after = PalwModelMarketV1 {
                    msk_reserve: market.msk_reserve - fees.gross,
                    position_units: units_after as u64,
                    burned_sompi: market.burned_sompi.checked_add(fees.burn)?,
                    ..*market
                };
                (after.msk_reserve >= market.seed_sompi && k(&after) >= k0).then_some(PalwModelSellQuoteV1 { fees, after })
            }
            pub fn buyback(market: &PalwModelMarketV1, slice: u64) -> Option<PalwModelBuybackQuoteV1> {
                if market.seed_sompi == 0
                    || market.closed_to_buys
                    || slice == 0
                    || market.position_units == 0
                    || market.msk_reserve == 0
                {
                    return None;
                }
                let reserve_after = market.msk_reserve.checked_add(slice)?;
                let units_after = k(market).div_ceil(reserve_after as u128).min(market.position_units as u128) as u64;
                let retired = market.position_units - units_after;
                let after = PalwModelMarketV1 {
                    msk_reserve: reserve_after,
                    position_units: units_after,
                    buyback_sompi: market.buyback_sompi.checked_add(slice)?,
                    retired_units: market.retired_units.checked_add(retired)?,
                    ..*market
                };
                Some(PalwModelBuybackQuoteV1 { slice, retired, after })
            }
        }
        let mut compared = 0u64;
        for schedule in [PalwModelFeesV1::V1, PalwModelFeesV1::V2] {
            for case in 0..48u64 {
                let mut rng = Rng(0x0090 ^ case.wrapping_mul(0x3141_5926) ^ schedule.leg_permille);
                let seed = if case % 2 == 0 { PALW_MODEL_SEED_MIN_SOMPI_V1 } else { PALW_MODEL_SEED_MIN_SOMPI_V2 };
                let mut m = PalwModelMarketV1::seed_v1(3, seed + rng.amount(seed), payer());
                let mut held = 0u64;
                for step in 0..64 {
                    let what = format!("{schedule:?} case {case} step {step}");
                    assert_eq!(m.virtual_sompi, 0);
                    let msk_in = rng.amount(500_000 * MSK);
                    let units = 1 + rng.below(held.max(1) * 2);
                    let slice = rng.amount(40 * MSK);
                    let (b, rb) = (palw_model_buy_quote_with(&m, msk_in, schedule), reference::buy(&m, msk_in, schedule));
                    let (s, rs) = (palw_model_sell_quote_with(&m, units, schedule), reference::sell(&m, units, schedule));
                    let (r, rr) = (palw_model_buyback_quote_v1(&m, slice), reference::buyback(&m, slice));
                    assert_eq!(b, rb, "{what}: buy {msk_in}");
                    assert_eq!(s, rs, "{what}: sell {units}");
                    assert_eq!(r, rr, "{what}: slice {slice}");
                    let under = PalwModelMarketV1 { msk_reserve: m.seed_sompi.saturating_sub(1), ..m };
                    assert_eq!(
                        palw_model_sell_quote_with(&under, units, schedule),
                        reference::sell(&under, units, schedule),
                        "{what}"
                    );
                    let closed = PalwModelMarketV1 { closed_to_buys: true, ..m };
                    assert_eq!(palw_model_buy_quote_with(&closed, msk_in, schedule), None, "{what}");
                    assert_eq!(reference::buy(&closed, msk_in, schedule), None, "{what}");
                    compared += 3;
                    match rng.below(3) {
                        0 => {
                            if let Some(q) = b {
                                held += q.units_out;
                                m = q.after;
                            }
                        }
                        1 => {
                            if let Some(q) = s
                                && units <= held
                            {
                                held -= units;
                                m = q.after;
                            }
                        }
                        _ => {
                            if let Some(q) = r {
                                m = q.after;
                            }
                        }
                    }
                }
            }
        }
        assert!(compared > 10_000, "the comparison ran: {compared}");
        // A pledge and the reader's empty row quote nothing, on either side.
        for row in [PalwModelMarketV1::pledge_v1(5, 4 * MSK, payer()), PalwModelMarketV1::seed_v1(5, 0, Hash64::default())] {
            assert_eq!(palw_model_buy_quote_with(&row, MSK, PalwModelFeesV1::V1), reference::buy(&row, MSK, PalwModelFeesV1::V1));
            assert_eq!(palw_model_buy_quote_with(&row, MSK, PalwModelFeesV1::V1), None);
            assert_eq!(palw_model_buyback_quote_v1(&row, MSK), None);
            assert_eq!(row.price_sompi_per_position_v1(), 0, "no market, no price");
        }
    }

    /// **I-V8 in the bytes: a row with no virtual reserve encodes exactly as it always did**, so the
    /// state root over every market any network holds today, its carriage and its deltas do not move;
    /// a row with one carries it behind bit 1 of the flag byte and a trailing word, round-trips, and
    /// sits beside other rows in a map without disturbing them; and the encoding is one-to-one.
    #[test]
    fn a_row_without_a_virtual_reserve_has_the_bytes_it_always_had() {
        fn legacy(m: &PalwModelMarketV1) -> Vec<u8> {
            let mut v = Vec::new();
            for word in [m.opened_daa, m.msk_reserve, m.position_units, m.sold_units, m.burned_sompi, m.registrant_paid_sompi] {
                v.extend_from_slice(&word.to_le_bytes());
            }
            v.push(u8::from(m.closed_to_buys));
            for word in [m.contributor_paid_sompi, m.seed_sompi] {
                v.extend_from_slice(&word.to_le_bytes());
            }
            v.extend_from_slice(m.seeded_by.as_byte_slice());
            for word in [m.buyback_sompi, m.retired_units] {
                v.extend_from_slice(&word.to_le_bytes());
            }
            v
        }
        let seeded = PalwModelMarketV1::seed_v1(9, PALW_MODEL_SEED_MIN_SOMPI_V2, payer());
        let traded = palw_model_buy_quote_with(&seeded, 1_234 * MSK, PalwModelFeesV1::V2).unwrap().after;
        let closed = PalwModelMarketV1 { closed_to_buys: true, ..traded };
        let pledged = PalwModelMarketV1::pledge_v1(4, 77 * MSK, payer());
        for row in [seeded, traded, closed, pledged] {
            let bytes = borsh::to_vec(&row).unwrap();
            assert_eq!(bytes, legacy(&row), "a pre-fence row's bytes are the pre-fence encoding");
            assert_eq!(borsh::from_slice::<PalwModelMarketV1>(&bytes).unwrap(), row, "and decode to the same row");
        }
        let virt = palw_model_buy_quote_with(&opened(), 5_000 * MSK, PalwModelFeesV1::V1).unwrap().after;
        let virt_closed = PalwModelMarketV1 { closed_to_buys: true, ..virt };
        for (row, flags) in [(virt, 0b10u8), (virt_closed, 0b11u8)] {
            let bytes = borsh::to_vec(&row).unwrap();
            let mut want = legacy(&row);
            want[48] = flags;
            want.extend_from_slice(&V.to_le_bytes());
            assert_eq!(bytes, want, "the flag bit, and the virtual reserve as the trailing word");
            assert_eq!(borsh::from_slice::<PalwModelMarketV1>(&bytes).unwrap(), row);
        }
        let map: std::collections::BTreeMap<Hash64, PalwModelMarketV1> =
            [(Hash64::from_u64_word(1), virt), (Hash64::from_u64_word(2), seeded), (Hash64::from_u64_word(3), virt_closed)].into();
        assert_eq!(
            borsh::from_slice::<std::collections::BTreeMap<Hash64, PalwModelMarketV1>>(&borsh::to_vec(&map).unwrap()).unwrap(),
            map
        );
        // One-to-one: an unknown bit, or a flag whose word is zero, is refused.
        let mut unknown = borsh::to_vec(&seeded).unwrap();
        unknown[48] = 0b100;
        assert!(borsh::from_slice::<PalwModelMarketV1>(&unknown).is_err());
        let mut zero_word = borsh::to_vec(&seeded).unwrap();
        zero_word[48] = 0b10;
        zero_word.extend_from_slice(&0u64.to_le_bytes());
        assert!(borsh::from_slice::<PalwModelMarketV1>(&zero_word).is_err());
    }

    /// **ADR-0162 Decision 1 and 3: the market every surface reads past the fence.** A line with no
    /// row has its opening; a pledge that was collecting ADR-0094's floor opens on `V` with the pledge
    /// as its seed; and an ADR-0090 pair seeded under ADR-0120's floor before the fence keeps `V = 0`
    /// and quotes, after the fence, exactly what it quoted before it.
    #[test]
    fn a_pair_seeded_before_the_fence_quotes_after_it_exactly_as_before() {
        let fresh = palw_model_market_in_force_v2(None, 900);
        assert_eq!(fresh, PalwModelMarketV1::open_virtual_v2(900, V));
        assert_eq!(fresh.price_sompi_per_position_v1(), 20 * MSK);
        let pledge = PalwModelMarketV1::pledge_v1(5, 250_000 * MSK, payer());
        let opened_pledge = palw_model_market_in_force_v2(Some(&pledge), 900);
        assert!(opened_pledge.is_open());
        assert_eq!(
            (opened_pledge.msk_reserve, opened_pledge.seed_sompi, opened_pledge.seeded_by, opened_pledge.opened_daa),
            (250_000 * MSK, 250_000 * MSK, payer(), 900),
            "the pledge is the seed, locked as it already was, and the first payer is still the record"
        );
        assert_eq!(opened_pledge.price_sompi_per_position_v1(), (V + 250_000 * MSK) / SUPPLY);
        let before = PalwModelMarketV1::seed_v1(40, PALW_MODEL_SEED_MIN_SOMPI_V2, payer());
        let before = palw_model_buy_quote_with(&before, 20_000 * MSK, PalwModelFeesV1::V2).unwrap().after;
        let after = palw_model_market_in_force_v2(Some(&before), 900);
        assert_eq!(after, before, "the row is the row: V stays 0");
        for msk_in in [MSK, 777 * MSK, 50_000 * MSK] {
            assert_eq!(
                palw_model_buy_quote_with(&after, msk_in, PalwModelFeesV1::V2),
                palw_model_buy_quote_with(&before, msk_in, PalwModelFeesV1::V2)
            );
        }
        assert_eq!(after.price_sompi_per_position_v1(), before.price_sompi_per_position_v1());
        assert_eq!(after.price_floor_sompi_per_position_v2(), before.price_floor_sompi_per_position_v2());
        assert!(
            after.price_floor_sompi_per_position_v2() >= PALW_MODEL_SEED_MIN_SOMPI_V2 / SUPPLY,
            "its floor is its seed's, plus the dust its buy left in the curve"
        );
    }
}
