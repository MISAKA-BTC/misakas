//! **ADR-0135 — the permissionless model registry: a model is data, its profile is derived, its
//! panel proves readiness, and its lifecycle is a state machine.** Shadow: nothing consensus
//! reads yet; the types and functions here are the rule set Protocol Upgrade A arms.
//!
//! What changes from ADR-0133: nothing a human measures enters consensus. A registrant submits a
//! [`PalwModelManifestV1`] (graph root, artifact root and bytes, the canonical job, the
//! quantization, the runtime version) and a registration bond; every node derives the same
//! [`PalwDerivedProfileV1`] from the manifest's *work* — the verification compute the graph costs
//! (ADR-0131's economic compute of the draw job) and the artifact's bytes — against one set of
//! global reference constants ([`PalwRegistryGlobalsV1`]); panels prove readiness with evidence,
//! not declarations ([`PalwReadinessEvidenceV1`]); the class walks a lifecycle
//! ([`PalwModelLifecycleV1`]) whose every transition is a function of chain-visible facts; and a
//! class's claim cadence comes from a global compute budget over its economic compute
//! ([`palw_admission_claims_per_span_v1`]), so no share is set by anyone. Wall-clock p99s are
//! telemetry: they say whether the derived profile is being met, never what it is.
//!
//! A model expressible by the supported tensor kernels (matmul, attention, MoE, GDN, norms, …)
//! registers without a fork. An unsupported operation (`PalwManifestVerdictV1::UnsupportedOp`)
//! requires a reviewed kernel extension and protocol activation before registration (ADR-0172).

use crate::Hash64;
use crate::palw_verification_profile_v1::{PALW_SEAT_COUNT_V1, PALW_SPAN_MS_V1};
use std::collections::BTreeMap;

pub const PALW_MODEL_REGISTRY_VERSION_V1: u16 = 1;

/// **What a registrant submits.** No window, no reward, no share: those are derived.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwModelManifestV1 {
    pub graph_ir_root: Hash64,
    pub artifact_root: Hash64,
    pub artifact_bytes: u64,
    pub canonical_prefill_tokens: u32,
    pub canonical_decode_tokens: u32,
    pub quantization_format: u8,
    pub runtime_version: u16,
}

/// **What the graph costs, derived by every node from the manifest's graph** (ADR-0131's economic
/// compute): the compute of the job a seat replays to verify one claim, and the working set the
/// replay touches (the artifact whole for a dense model, the resident experts for a mixture).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub struct PalwModelWorkV1 {
    pub verification_ccu: u128,
    pub economic_ccu_per_claim: u128,
    pub artifact_bytes: u64,
    pub working_set_bytes: u64,
    /// Whether every op of the graph is supported by the tensor kernels at `runtime_version`.
    pub ops_supported: bool,
}

/// **The global reference every model is measured against** — consensus constants once Protocol
/// Upgrade A is armed, the same for every class; changed only by a fence, never per model.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwRegistryGlobalsV1 {
    /// MAC-equivalents a reference seat verifies in one execution span.
    pub reference_work_per_span: u128,
    /// Bytes a reference seat pages in from storage in one span.
    pub reference_bytes_per_span: u64,
    pub safety_permille: u32,
    pub io_safety_permille: u32,
    /// Spans allowed for a receipt to propagate and be carried.
    pub receipt_allowance_spans: u32,
    pub seat_count: u16,
    /// Ready seats beyond the panel a class must have before it is live.
    pub spare_seats: u16,
    pub utilization_permille: u32,
    /// Probation: the probe claims a class must finalize with none failing.
    pub probation_claims: u32,
    /// Epochs a limited class must run at target before it is `Active`.
    pub stable_epochs: u32,
    /// The registration bond: a base per span of verification burden.
    pub registration_bond_per_span_sompi: u64,
    /// The compute a span's claims may cost the network, all classes together.
    pub budget_ccu_per_span: u128,
    /// Free collateral a ready seat must hold, as a multiple of the class's seat exposure.
    pub readiness_collateral_multiple: u32,
    /// How recently a seat's probe verification must have succeeded, in spans.
    pub readiness_probe_max_age_spans: u32,
    /// **How long a readiness-V2 row stands, in spans** — the horizon
    /// [`palw_readiness_max_age_daa_v1`] reads past `Params::palw_readiness_v2`. The constant carries
    /// [`PALW_READINESS_V2_MAX_AGE_SPANS_V1`] (eight), which is every network's without
    /// `Params::palw_readiness_v2_max_age_spans`; a network's fold is handed its own through
    /// [`palw_registry_globals_of_bundle_v1`] (testnet-12: twenty-four — user decision 2026-09-25,
    /// readiness capacity option (a)). A global because it is one: the same for every class, set once
    /// at genesis, never per model.
    pub readiness_v2_max_age_spans: u32,
}

/// The reference the fleet measured (ADR-0133): 4 G MAC-eq/s → 2.4 T a span; 1 GB/s → 600 GB a
/// span; ×2 / ×2; one span of receipt allowance; five seats plus two spare; 70 %; ten probe
/// claims; three stable epochs; 1,000 MSK a span of burden; a budget of one dense-tier claim's
/// attempted compute a span times ten; three exposures of free collateral; a probe within 30 spans.
pub const PALW_REGISTRY_GLOBALS_V1: PalwRegistryGlobalsV1 = PalwRegistryGlobalsV1 {
    reference_work_per_span: 4_000_000_000 * (PALW_SPAN_MS_V1 as u128) / 1_000,
    reference_bytes_per_span: 1_000_000_000 * PALW_SPAN_MS_V1 / 1_000,
    safety_permille: 2_000,
    io_safety_permille: 2_000,
    receipt_allowance_spans: 1,
    seat_count: PALW_SEAT_COUNT_V1,
    spare_seats: 2,
    utilization_permille: 700,
    probation_claims: 10,
    stable_epochs: 3,
    registration_bond_per_span_sompi: 1_000 * 100_000_000,
    budget_ccu_per_span: 10 * 166_204_342_272,
    readiness_collateral_multiple: 3,
    readiness_probe_max_age_spans: 30,
    readiness_v2_max_age_spans: PALW_READINESS_V2_MAX_AGE_SPANS_V1,
};

/// **The globals a network's registry fold is handed** — [`PALW_REGISTRY_GLOBALS_V1`] with the two
/// numbers a network sets: the panel's seat count (the bundle's panel params, not the constant's: a
/// devnet with three-seat panels needs five ready seats, testnet-11 seven) and the readiness-V2
/// horizon (`Params::palw_readiness_v2_max_age_spans`, through the bundle's mirror,
/// [`crate::palw_state_v2::PalwStateParamsV2::readiness_v2_max_age_spans_v1`]). The virtual
/// processor builds its fold from this and nothing else, so the ready-seat count, ADR-0147's jury,
/// the draw's policy, the registry read the RPC serves, the node's re-prove duty and the M1
/// escalation — every reader of `fold.globals` — take the one horizon.
pub fn palw_registry_globals_of_bundle_v1(bundle: &crate::palw_mode_v2::PalwConsensusParamsV2) -> PalwRegistryGlobalsV1 {
    PalwRegistryGlobalsV1 {
        seat_count: bundle.panel.seat_count(),
        readiness_v2_max_age_spans: bundle.state.readiness_v2_max_age_spans_v1(),
        ..PALW_REGISTRY_GLOBALS_V1
    }
}

/// A manifest is refused before it is a class.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PalwManifestVerdictV1 {
    Valid,
    /// The graph names an op unsupported at this runtime version: a kernel extension must be
    /// implemented, reviewed and activated before registration.
    UnsupportedOp,
    EmptyArtifact,
    EmptyJob,
    ZeroWork,
}

pub fn palw_manifest_verdict_v1(manifest: &PalwModelManifestV1, work: &PalwModelWorkV1) -> PalwManifestVerdictV1 {
    if !work.ops_supported {
        PalwManifestVerdictV1::UnsupportedOp
    } else if manifest.artifact_bytes == 0 || work.artifact_bytes == 0 {
        PalwManifestVerdictV1::EmptyArtifact
    } else if manifest.canonical_prefill_tokens == 0 {
        PalwManifestVerdictV1::EmptyJob
    } else if work.verification_ccu == 0 || work.economic_ccu_per_claim == 0 {
        PalwManifestVerdictV1::ZeroWork
    } else {
        PalwManifestVerdictV1::Valid
    }
}

/// **The derived profile.** Every field a function of the manifest's work and the globals; no
/// field a registrant states, no field a human measures.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub struct PalwDerivedProfileV1 {
    pub version: u16,
    pub verification_window_spans: u32,
    pub artifact_prefetch_spans: u32,
    pub max_inflight_claims: u32,
    pub required_ready_seats: u32,
    pub registration_bond_sompi: u64,
    /// The claims a span the class may accept under the global budget, in thousandths.
    pub admission_claims_per_span_milli: u64,
}

fn ceil_div_u128(a: u128, b: u128) -> u128 {
    if b == 0 { 0 } else { a.div_ceil(b) }
}

/// `⌈safety × work / reference⌉` + the receipt allowance, one span at least.
pub fn palw_verification_window_spans_v1(work: &PalwModelWorkV1, g: &PalwRegistryGlobalsV1) -> u32 {
    let spans = ceil_div_u128(
        work.verification_ccu.saturating_mul(g.safety_permille.max(1_000) as u128),
        g.reference_work_per_span.saturating_mul(1_000),
    );
    (spans.max(1) + g.receipt_allowance_spans as u128).min(u32::MAX as u128) as u32
}

/// `⌈io_safety × bytes / reference_bytes⌉`, zero for a model with nothing to page.
pub fn palw_artifact_prefetch_spans_v1(work: &PalwModelWorkV1, g: &PalwRegistryGlobalsV1) -> u32 {
    if work.artifact_bytes == 0 {
        return 0;
    }
    let spans = ceil_div_u128(
        (work.artifact_bytes as u128).saturating_mul(g.io_safety_permille.max(1_000) as u128),
        (g.reference_bytes_per_span as u128).saturating_mul(1_000),
    );
    spans.max(1).min(u32::MAX as u128) as u32
}

/// The seats a class needs before it is live.
///
/// **Two questions wore one name here, and on a heavy class they give answers four orders of
/// magnitude apart.** *Possession*: how many seats must have proved they hold the artifact before
/// the class may admit anything — the panel plus the spare, because that is who verifies a claim.
/// *Capacity*: how many seats it would take to sustain one claim a span — `seat_count` whole
/// replays divided by what one seat offers in a span. The shipped rule returned the larger, so a
/// class heavier than the fleet was REFUSED rather than admitted rarely: the held 2M Qwen2.5 row,
/// whose canonical job is `n_ctx / 8 = 262,143` prefill by ADR-0103 Decision 14, prices one replay
/// at 1,998 reference seat-spans and so asked for 9,992 ready seats against a seven-bond network.
/// No number of possession proofs reaches it and `Prefetching` never ends.
///
/// Past `possession_gate` (`Params::palw_seat_gate_possession`) this returns the possession
/// question only, and the capacity question moves to where it was always expressed —
/// [`palw_max_inflight_claims_v1`] and [`palw_admission_claims_per_span_v1`], which now divide the
/// work by the seats that EXIST rather than by the seats the refusal imagined. That is ADR-0133
/// §7's own answer to this case: "0.05 claims a span on seven — at which point the class's share,
/// not its price, is the answer". It admits no claim a seat has not proved it can verify; it only
/// stops a heavy class from being refused for arithmetic about hosts nobody has.
pub fn palw_required_ready_seats_v1(work: &PalwModelWorkV1, g: &PalwRegistryGlobalsV1, possession_gate: bool) -> u32 {
    let floor = g.seat_count as u128 + g.spare_seats as u128;
    if possession_gate {
        return floor.min(u32::MAX as u128) as u32;
    }
    let per_claim = work.verification_ccu.saturating_mul(g.seat_count as u128);
    let offered_per_seat = g.reference_work_per_span.saturating_mul(g.utilization_permille.min(1_000) as u128) / 1_000;
    let for_one_a_span = ceil_div_u128(per_claim, offered_per_seat.max(1));
    floor.max(for_one_a_span).min(u32::MAX as u128) as u32
}

/// Little's law at the target utilization over the required seats: the claims that may be in
/// flight over the window, one at least.
///
/// Past `possession_gate` the seat count this divides by is the possession floor — the seats a
/// class actually has — so a class whose replay outruns its panel gets `1`, and the panel is never
/// committed to more claims at once than it can hold.
pub fn palw_max_inflight_claims_v1(work: &PalwModelWorkV1, g: &PalwRegistryGlobalsV1, possession_gate: bool) -> u32 {
    let window = palw_verification_window_spans_v1(work, g) as u128;
    let seats = palw_required_ready_seats_v1(work, g, possession_gate) as u128;
    let offered = seats
        .saturating_mul(window)
        .saturating_mul(g.reference_work_per_span)
        .saturating_mul(g.utilization_permille.min(1_000) as u128)
        / 1_000;
    let per_claim = work.verification_ccu.saturating_mul(g.seat_count as u128).max(1);
    (offered / per_claim).clamp(1, u32::MAX as u128) as u32
}

/// **Admission without a share**: the claims a span the global budget affords this class,
/// `budget / economic compute a claim` — a heavy class claims rarely and is paid much per claim, a
/// light class often and little, and the budget is what is constant. Capped at what the window
/// can hold (`max_inflight / window`). In thousandths.
pub fn palw_admission_claims_per_span_v1(work: &PalwModelWorkV1, g: &PalwRegistryGlobalsV1, possession_gate: bool) -> u64 {
    if work.economic_ccu_per_claim == 0 {
        return 0;
    }
    let by_budget = g.budget_ccu_per_span.saturating_mul(1_000) / work.economic_ccu_per_claim;
    let inflight = palw_max_inflight_claims_v1(work, g, possession_gate) as u128;
    let by_capacity = inflight.saturating_mul(1_000) / palw_verification_window_spans_v1(work, g).max(1) as u128;
    let rate = by_budget.min(by_capacity);
    // **A rate of zero here is the UNIT running out, not the network refusing.** Both terms are
    // thousandths, and the held 2M row's honest rate is 0.357‰ — one claim per 2,799 spans by the
    // window, and about the same by the budget, because one such claim costs the network's whole
    // verification budget for those spans. Thousandths cannot say that, so both floor to `0`, and
    // a class admitting `0‰` holds no share, is never drawn, is never probed, and therefore can
    // never leave `Probation` — the refusal the seat gate just stopped making, made again one
    // field over.
    //
    // Past the fence the rate is at least the smallest the unit can express. It cannot over-commit
    // the panel: `max_inflight_claims` is `1` for exactly these classes, so a second claim is
    // refused until the first is Final, and the verification window — not the rate — is what
    // paces them. (Past the work target the class gate judges by the panel room. Past
    // `palw_audit_2026_09_23` it ALSO holds a class to this cap, and counts its claims to Final,
    // when the class's window is at least 1,000 spans: ADR-0152's C7,
    // `crate::palw_work_target_v1::palw_panel_held_to_final_v1`, from the 2026-09-24 audit #4
    // review. A rate that floors to zero by the window has `window > 1,000 × max_inflight_claims`,
    // so the sentence holds for those classes too. A class whose rate floors by the budget alone and
    // whose window is shorter is released at licence and paced by the room.) A class with no work,
    // or one the panel cannot hold a single claim of, still admits nothing.
    if possession_gate && inflight > 0 {
        return rate.max(1).min(u64::MAX as u128) as u64;
    }
    rate.min(u64::MAX as u128) as u64
}

/// The whole profile.
pub fn palw_derive_profile_v1(work: &PalwModelWorkV1, g: &PalwRegistryGlobalsV1, possession_gate: bool) -> PalwDerivedProfileV1 {
    let verification_window_spans = palw_verification_window_spans_v1(work, g);
    PalwDerivedProfileV1 {
        version: PALW_MODEL_REGISTRY_VERSION_V1,
        verification_window_spans,
        artifact_prefetch_spans: palw_artifact_prefetch_spans_v1(work, g),
        max_inflight_claims: palw_max_inflight_claims_v1(work, g, possession_gate),
        required_ready_seats: palw_required_ready_seats_v1(work, g, possession_gate),
        registration_bond_sompi: g.registration_bond_per_span_sompi.saturating_mul(verification_window_spans as u64),
        admission_claims_per_span_milli: palw_admission_claims_per_span_v1(work, g, possession_gate),
    }
}

/// **How many spans late a possession proof may land** (ADR-0135 §7, found by the devnet drill):
/// a proof names the span it was made for; the carrier that brings it waits in mempools and for a
/// block, and on a devnet with two-DAA spans that wait was several spans. A proof up to this many
/// spans old is taken, and the row it writes is dated at the NAMED span's first DAA — so a late
/// proof is exactly as fresh as when it was made, a replayed one renews nothing, and the readiness
/// age (thirty spans) bounds the rest.
pub const PALW_READINESS_LANDING_SPANS_V1: u64 = 8;

/// The same allowance in DAA, for a network whose spans are short: a carrier's wait is blocks and
/// minutes, not spans, and on a devnet with two-DAA spans eight spans were sixteen minutes — a
/// chain of eight receipts ahead of the proof took longer. The allowance is the larger of the two
/// (`max(8 spans, 40 DAA / span)`): on testnet-11's five-DAA spans it is the eight spans, on the
/// devnet twenty.
pub const PALW_READINESS_LANDING_DAA_V1: u64 = 40;

/// How many spans late a proof may land at `span_daa` DAA a span.
pub fn palw_readiness_landing_spans_v1(span_daa: u64) -> u64 {
    PALW_READINESS_LANDING_SPANS_V1.max(PALW_READINESS_LANDING_DAA_V1 / span_daa.max(1))
}

/// **The single lottery's class targets, from admission alone** (ADR-0132 S, ADR-0133 §9a Fence 2):
/// each class's share of draws is its admitted claims a span over every class's, in permille —
/// no share is set by anyone, and a class whose admission is zero holds no share.
pub fn palw_class_shares_from_admission_v1(admissions_milli: &[(Hash64, u64)]) -> Vec<(Hash64, u16)> {
    let total: u128 = admissions_milli.iter().map(|(_, a)| *a as u128).sum();
    admissions_milli
        .iter()
        .map(|(class, a)| (*class, if total == 0 { 0 } else { ((*a as u128).saturating_mul(1_000) / total).min(1_000) as u16 }))
        .collect()
}

/// **What a seat proves before it counts as ready for a class** — none of it a declaration.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct PalwReadinessEvidenceV1 {
    /// The seat's held artifact root equals the manifest's.
    pub artifact_root_matches: bool,
    /// Every chunk of the artifact's manifest is held (a possession proof over the root).
    pub all_chunks_held: bool,
    /// The seat's node is synced, mining-eligible and not held (`participation_allowed`).
    pub participation_ok: bool,
    pub free_collateral_sompi: u128,
    /// The span of the seat's last successful canonical probe verification on this class, if any.
    pub last_probe_ok_span: Option<u64>,
}

impl PalwReadinessEvidenceV1 {
    /// Ready: root matched, chunks held, participating, collateral for `readiness_collateral_multiple`
    /// seat exposures, and a probe verified within `readiness_probe_max_age_spans`.
    pub fn is_ready(&self, seat_exposure_sompi: u128, now_span: u64, g: &PalwRegistryGlobalsV1) -> bool {
        let collateral_needed = seat_exposure_sompi.saturating_mul(g.readiness_collateral_multiple as u128);
        let probe_fresh =
            self.last_probe_ok_span.is_some_and(|at| now_span.saturating_sub(at) <= g.readiness_probe_max_age_spans as u64);
        self.artifact_root_matches
            && self.all_chunks_held
            && self.participation_ok
            && self.free_collateral_sompi >= collateral_needed
            && probe_fresh
    }
}

/// **The lifecycle.** Every transition a function of chain-visible facts.
#[derive(Clone, Copy, Debug, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub enum PalwModelLifecycleV1 {
    Registered,
    Prefetching,
    Probation {
        probes_passed: u32,
    },
    ActiveLimited {
        stable_epochs: u32,
    },
    Active,
    /// A class whose panel cannot be drawn or whose utilization passed one: its own new claims
    /// hold; nothing else stops.
    Held,
    /// **Registered is not eligible** (ADR-0145 §7, the 2026-09-19 audit's F3). A class a
    /// registrant bought exists, may be inspected, benchmarked and run in shadow — and earns no
    /// sompi and no unit of fork-choice weight — until the chain has seen a seat the registrant
    /// does NOT hold ready to verify it. Only then does it enter the ordinary walk at
    /// `Prefetching`. Written only past `Params::palw_admission_independence`; below the fence
    /// nothing constructs it and every existing row keeps the state it was written with.
    ///
    /// **It is last in this enum although it is first in the lifecycle**, and that is deliberate:
    /// the enum is borsh, its discriminants are chain bytes, and inserting a variant ahead of
    /// `Registered` would renumber every row already written — the exact failure that made a main
    /// build unable to sync testnet-11 from genesis on 2026-09-10. The order a reader wants lives
    /// in `palw_lifecycle_step_v1` and in this doc, never in the tag.
    Candidate,
    /// **RFC-0007 Part IV.2: staged onboarding** (spec 18; written only past `Params::palw_capped_onboarding_v1`). A class that has
    /// not seated a panel's worth of holders yet but shows a DA certificate produces **capped** (the weight cap and
    /// `capped_admission_permille`) with **provisional** rewards (a claim's escrow is paid only at `Final`, and a capped claim reaches
    /// a panel only once the holders are seated), and its claims are re-verified by the holders inside a window. **Appended last**,
    /// for `Candidate`'s reason: the enum is borsh and its discriminants are chain bytes. Its place in the walk is between
    /// `Prefetching` and `Probation`.
    Capped {
        /// The DAA of the span boundary that stepped the class into `Capped`.
        since_daa: u64,
    },
}

impl PalwModelLifecycleV1 {
    /// Whether the class accepts new claims at all.
    ///
    /// `Candidate` is absent from this list for the reason it exists: a registration is existence,
    /// not eligibility. The list is positive — states that DO admit — so a state added later
    /// admits nothing until someone writes it here on purpose.
    pub fn admits_claims(&self) -> bool {
        matches!(self, Self::Probation { .. } | Self::ActiveLimited { .. } | Self::Active | Self::Capped { .. })
    }
    /// The fraction of the derived admission the state allows, in permille: probation runs the
    /// probe claims only, limited activation a tenth, `Active` all of it.
    /// The cadence a state admits, in permille of the derived admission: probation at a twentieth
    /// (a class must be able to produce the claims that probe it — at zero it could never leave
    /// probation), limited activation at a tenth, activation in full, everything else nothing.
    pub fn admission_permille(&self) -> u32 {
        match self {
            Self::Probation { .. } => 50,
            Self::ActiveLimited { .. } => 100,
            Self::Active => 1_000,
            // RFC-0007 Part IV.2: `capped_admission_permille`.
            Self::Capped { .. } => crate::palw_mesh_v1::PALW_CAPPED_ADMISSION_PERMILLE_V1,
            _ => 0,
        }
    }
}

/// What the chain sees of a class at a span boundary.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct PalwLifecycleObservationV1 {
    pub manifest: PalwManifestVerdictV1Flag,
    pub ready_seats: u32,
    /// **RFC-0002 Part II Proposal A (`palw_class_seating`): the independence floor holds** — `|(Ready ∩ Base) \ {registrant}| ≥
    /// independent_floor` (`PalwClassSeatingV1::independence_floor_met`). `true` below the fence (so no existing transition
    /// moves), where `ready_seats` is also the bond count it always was; past it `ready_seats` is the number of distinct READY
    /// operators and a class enters `Probation` (from `Prefetching` or `Held`), and graduates from it, only with this true.
    pub independence_floor_met: bool,
    pub probes_passed_this_span: u32,
    pub probes_failed_this_span: u32,
    pub utilization_permille: u32,
    pub collateral_ok: bool,
    /// ADR-0132 Upgrade C: the class's cap utilization is at or under the fence's ceiling (`true`
    /// where the economic payout is dormant: nothing prices it). A class over it is not stepped to
    /// `Active` and an `Active` one falls back to a tenth — "not activatable", as a rule.
    pub cap_ok: bool,
    /// **ADR-0133 §11.3 (fail-closed):** the class's derived verification window
    /// (`verification_window_spans × span_daa`) fits inside the network's receipt deadline
    /// (`window_receipt`). A class that needs longer to replay than a claim is given to be replayed
    /// in would void every claim it accepted; it is HELD, never ACTIVE, until a class-specific
    /// receipt deadline (its own fence, not built) or a wider global window admits it.
    pub window_fits_receipt: bool,
    /// Whether this span ran at or under the target utilization with no held claim.
    pub span_stable: bool,
    /// **ADR-0147: the class's admission jury sat at this boundary and a majority of it holds the
    /// class** (past `Params::palw_admission_independence`).
    ///
    /// The jury is `seat_count` operators drawn from the NETWORK's base-class population — not
    /// from the class's own — by a lottery whose seed is the execution lane's anchor of the span
    /// before, over bonds registered before that span began, on the audit schedule
    /// ([`palw_admission_audit_due_v1`]). A juror counts when one of its bonds is READY for the
    /// class by the registry's own five-clause predicate. So the registrant passes alone only by
    /// holding a majority of a jury the network drew, which it does with the probability that its
    /// share of the network's operator lottery wins a majority of `seat_count` draws — once per
    /// audit, not once per span.
    ///
    /// Read ONLY by the `Candidate` arm — a state nothing writes below the fence — so every other
    /// transition is the one it was before this field existed, and a caller that leaves it `false`
    /// (the `Default`) can never turn an admitted class back. `false` for a genesis class by
    /// construction: the fold never puts one in `Candidate`.
    pub admission_jury_seated: bool,
    /// **RFC-0007 Part IV.2: a `Prefetching` class may step to `Capped`** — past `Params::palw_capped_onboarding_v1`, its ready seats do
    /// not fill a panel, a DA certificate stands for it, and the capped classes together would stay within `w_cap`. Read ONLY by the
    /// `Prefetching` arm, so a caller that leaves it `false` (the `Default`, every network without the fence) steps exactly as before.
    pub capped_entry: bool,
}

/// **ADR-0147: how often a `Candidate` class meets an admission jury**, in execution spans — one
/// epoch's worth, at least one span.
///
/// The jury is a lottery, and a lottery that may be re-run every span is passed by waiting: at a
/// five-DAA span a registrant whose share wins the jury one time in a thousand would be admitted
/// in under an hour and a half. The rate the chain CAN bound is how often the draw is taken, and
/// the epoch is the unit this chain already budgets everything else in (ADR-0039 D5). Stateless on
/// purpose: an audit falls on the spans whose index is a multiple of the period, so no row records
/// the last one and none can be written or rewound to run another.
pub fn palw_admission_audit_period_spans_v1(epoch_length: u64, span_daa: u64) -> u64 {
    (epoch_length / span_daa.max(1)).max(1)
}

/// [`palw_admission_audit_period_spans_v1`] with the network's explicit period
/// (`Params::palw_admission_audit_period_daa`, the 2026-09-23 standard of 100 DAA) where it sets
/// one: that many DAA in spans, at least one span. `None` is the one-epoch period, byte for byte.
pub fn palw_admission_audit_period_spans_v2(epoch_length: u64, span_daa: u64, period_daa: Option<u64>) -> u64 {
    match period_daa {
        Some(period) => (period / span_daa.max(1)).max(1),
        None => palw_admission_audit_period_spans_v1(epoch_length, span_daa),
    }
}

/// Whether the span a boundary opens is an audit span ([`palw_admission_audit_period_spans_v1`]).
/// Span zero never is: the jury's seed is the anchor of the span before, and there is none.
pub fn palw_admission_audit_due_v1(span_now: u64, period_spans: u64) -> bool {
    span_now > 0 && span_now.is_multiple_of(period_spans.max(1))
}

/// A strict majority of the jury: `seats / 2 + 1`, which is the panel's own quorum shape
/// (`2·quorum > seat_count`) at its smallest.
pub fn palw_admission_jury_quorum_v1(seats: u16) -> u16 {
    seats / 2 + 1
}

pub const PALW_ADMISSION_JURY_SEED_DOMAIN: &[u8] = b"misaka-palw/admission-jury/seed/v1";

/// **ADR-0147: the admission jury's seed** — the class, the audit span, and the execution lane's
/// seed anchor of the span before (its chain block and its attempt's execution commitment).
///
/// The anchor is ADR-0130's randomness, and the reason it is used here rather than a block hash:
/// re-rolling it costs a winning inference, where a boundary block's own hash can be re-rolled by
/// its producer for the price of a header. The population the jury is drawn from is cut before the
/// anchor's span began, so no bond in it was registered by a party that had seen the seed.
pub fn palw_admission_jury_seed_v1(class_id: &Hash64, span: u64, anchor_block: &Hash64, execution_key: &Hash64) -> Hash64 {
    let mut state = keyed64(PALW_ADMISSION_JURY_SEED_DOMAIN);
    state.update(class_id.as_byte_slice());
    state.update(&span.to_le_bytes());
    state.update(anchor_block.as_byte_slice());
    state.update(execution_key.as_byte_slice());
    finish64(state)
}

/// **ADR-0147's jury seed without the anchor's block hash** (ADR-0152-adjacent: Activation Pool, the
/// fix round's F2) — `H(domain ‖ class ‖ span ‖ anchor execution key)`, under its own domain.
///
/// [`palw_admission_jury_seed_v1`] hashes the anchor's chain block as well, and ADR-0130's own
/// argument for the lane (`PalwExecSeedAnchorV1`) is that a block hash is not seed material: every
/// nonce of the header's bucket and every timestamp gives the same winning draw and a different
/// hash, so the anchor's producer re-rolls it for free. Measured on the review's probe (P1): five
/// colluding operators of twenty seat a jury majority on 7.24 % of free re-rolls — and once the
/// Activation Pool pays drawn jurors, choosing the jury is choosing the payees. Past
/// `Params::palw_activation_pool` the jury is drawn from this seed; moving it costs another
/// execution that wins its draw. Below the fence the v1 seed, byte for byte.
pub const PALW_ADMISSION_JURY_SEED_V2_DOMAIN: &[u8] = b"misaka-palw/admission-jury/seed/v2";

pub fn palw_admission_jury_seed_v2(class_id: &Hash64, span: u64, execution_key: &Hash64) -> Hash64 {
    let mut state = keyed64(PALW_ADMISSION_JURY_SEED_V2_DOMAIN);
    state.update(class_id.as_byte_slice());
    state.update(&span.to_le_bytes());
    state.update(execution_key.as_byte_slice());
    finish64(state)
}

/// `PalwManifestVerdictV1`, as a flag the observation carries (`Valid` or not).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum PalwManifestVerdictV1Flag {
    #[default]
    Invalid,
    Valid,
}

/// One step of the lifecycle at a span boundary.
pub fn palw_lifecycle_step_v1(
    state: PalwModelLifecycleV1,
    obs: &PalwLifecycleObservationV1,
    profile: &PalwDerivedProfileV1,
    g: &PalwRegistryGlobalsV1,
) -> PalwModelLifecycleV1 {
    use PalwModelLifecycleV1::*;
    let panel_drawable = obs.ready_seats >= g.seat_count as u32;
    let ready_enough = obs.ready_seats >= profile.required_ready_seats && obs.collateral_ok && obs.independence_floor_met;
    // ADR-0133 §11.3: a class whose replay does not fit the receipt deadline is treated as
    // overloaded for ever — it admits nothing, and it re-enters Probation only once it fits.
    let overloaded = obs.utilization_permille >= 1_000 || !obs.window_fits_receipt;
    match state {
        // **The one transition a registrant cannot make alone** (ADR-0147, audit F3). A class
        // leaves `Candidate` when a jury the NETWORK drew — `seat_count` operators of the
        // liveness floor's population, not of the class's — finds a majority of itself holding
        // the class. Not when the registrant says it is ready, and not when the registrant's own
        // seats prove possession: the class's own population is a set the registrant fills first,
        // and for a model nobody else runs it fills it entirely. Until then the class exists and
        // admits nothing.
        //
        // It rejoins the ordinary walk exactly where a registration used to start, so nothing
        // downstream of `Prefetching` learns a new state: the manifest verdict still decides
        // whether there is any work to prefetch for, and `Registered` still means "no work derived
        // from the graph", which independence cannot cure.
        Candidate => {
            if !obs.admission_jury_seated {
                Candidate
            } else if obs.manifest == PalwManifestVerdictV1Flag::Valid {
                Prefetching
            } else {
                Registered
            }
        }
        Registered => {
            if obs.manifest == PalwManifestVerdictV1Flag::Valid {
                Prefetching
            } else {
                Registered
            }
        }
        Prefetching => {
            if ready_enough {
                Probation { probes_passed: 0 }
            } else if obs.capped_entry && !panel_drawable {
                // The caller writes the DAA (the step knows no clock).
                Capped { since_daa: 0 }
            } else {
                Prefetching
            }
        }
        // **RFC-0007 Part IV.2**: a capped class returns to the ordinary walk — at `Probation`, where `Prefetching` would have put it —
        // once holders are seated (`ready_enough`); not before, and never to `Held`: a capped class has no panel to lose.
        Capped { since_daa } => {
            if ready_enough && panel_drawable { Probation { probes_passed: 0 } } else { Capped { since_daa } }
        }
        Probation { probes_passed } => {
            if !panel_drawable || overloaded {
                Held
            } else if obs.probes_failed_this_span > 0 {
                Probation { probes_passed: 0 }
            } else {
                let passed = probes_passed.saturating_add(obs.probes_passed_this_span);
                if passed >= g.probation_claims && ready_enough {
                    ActiveLimited { stable_epochs: 0 }
                } else {
                    Probation { probes_passed: passed }
                }
            }
        }
        ActiveLimited { stable_epochs } => {
            if !panel_drawable || overloaded {
                Held
            } else if obs.span_stable {
                let stable = stable_epochs.saturating_add(1);
                // ADR-0132 Upgrade C: a cap-saturated class keeps its stable count but is not
                // activated — it admits at a tenth until the rate, the target or the escrow moves.
                if stable >= g.stable_epochs && obs.cap_ok { Active } else { ActiveLimited { stable_epochs: stable } }
            } else {
                ActiveLimited { stable_epochs: 0 }
            }
        }
        Active => {
            if !panel_drawable || overloaded {
                Held
            } else if !obs.cap_ok {
                ActiveLimited { stable_epochs: 0 }
            } else {
                Active
            }
        }
        Held => {
            if ready_enough && !overloaded {
                Probation { probes_passed: 0 }
            } else {
                Held
            }
        }
    }
}

/// **V05: how many DISTINCT producer bonds a probation's failed probes must name before it resets.**
///
/// A failed probe is a void the producer is charged for (`CourtFraud`, `CourtDefault`,
/// `ProducerWithholding`, `CourtHeldVerdict`). One bond's own failures say something about that
/// producer, not about the class: counted alone they let any holder of a claimable bond reset a
/// class's probation (seven to eight hours on testnet-12) with one fraud or one unanswered DA
/// request, and an honest producer that lost its capture reset it by crashing. Two distinct bonds
/// are the smallest evidence that is about the class. (Two bonds of one operator are two bonds: the
/// bond is what the claim names and what the chain can attribute; an operator splitting its
/// collateral pays a second bond's floor and a second claim's escrow for the second failure.)
pub const PALW_PROBATION_RESET_DISTINCT_BONDS_V1: usize = 2;

/// **V03(2) / V05: what a class's probation remembers across a span step** — rooted, one row per
/// class, present only while non-empty (`registry_probation/v1`, a Some-only root block). Written
/// only on spans lane F1's fence governs (`Params::palw_registry_resilience`,
/// `PalwStateParamsV2::registry_resilience_governs_span_v1`), so a chain below it never holds one.
#[derive(Clone, Debug, Default, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub struct PalwProbationMemoryV1 {
    /// **V03(2): the probation progress a readiness hold keeps** — `Some(p)` only while the class is
    /// `Held` after leaving `Probation { probes_passed: p }` (this span's passes included) because its
    /// ready seats could not fill a panel; its return is `Probation { probes_passed: p }`. A failed
    /// probation (V05) zeroes it; nothing else does.
    pub held_probes_passed: Option<u32>,
    /// **V05: the producer bonds a failed probe of this class was attributed to during the current
    /// probation** (`Probation`, or the readiness hold that keeps it) — sorted, unique, at most
    /// [`PALW_PROBATION_RESET_DISTINCT_BONDS_V1`] (a second distinct bond is already the reset; a third
    /// adds nothing). Cleared by the reset it causes and whenever the class leaves the probation.
    pub failed_bonds: Vec<crate::palw_state_v2::PalwBondKeyV2>,
}

impl PalwProbationMemoryV1 {
    /// Nothing remembered: the row is absent.
    pub fn is_empty(&self) -> bool {
        self.held_probes_passed.is_none() && self.failed_bonds.is_empty()
    }

    /// V05: note a failed probe of `bond` (sorted insert, unique, capped at the reset's count).
    pub fn note_failed_bond(&mut self, bond: crate::palw_state_v2::PalwBondKeyV2) -> bool {
        if self.failed_bonds.len() >= PALW_PROBATION_RESET_DISTINCT_BONDS_V1 {
            return false;
        }
        match self.failed_bonds.binary_search(&bond) {
            Ok(_) => false,
            Err(at) => {
                self.failed_bonds.insert(at, bond);
                true
            }
        }
    }

    /// V05: have failed probes of enough distinct producer bonds been seen to reset the probation?
    pub fn probation_failed(&self) -> bool {
        self.failed_bonds.len() >= PALW_PROBATION_RESET_DISTINCT_BONDS_V1
    }

    /// Is the class in the probation this memory belongs to — `Probation`, or `Held` with the
    /// readiness hold's kept progress? Only then does a failed probe name its bond here.
    pub fn in_probation(&self, state: PalwModelLifecycleV1) -> bool {
        matches!(state, PalwModelLifecycleV1::Probation { .. })
            || (matches!(state, PalwModelLifecycleV1::Held) && self.held_probes_passed.is_some())
    }
}

/// **One lifecycle step on a span lane F1's fence governs** (the 2026-09-25 pre-launch sweep's
/// V03(2) and V05) — [`palw_lifecycle_step_v1`] with the class's [`PalwProbationMemoryV1`], returning
/// the next state and the memory to keep. The exact rule, and only where it differs from v1:
///
/// * **A probation fails** when `memory.probation_failed()` — failed probes attributed to at least
///   [`PALW_PROBATION_RESET_DISTINCT_BONDS_V1`] distinct producer bonds since the probation began
///   (V05) — never on `obs.probes_failed_this_span` alone. A failed probation returns
///   `Probation { 0 }` (as v1's failure did) and forgets its bonds.
/// * **`Probation { p }` → `Held` for readiness** (ready seats below the panel, not overloaded)
///   keeps `p + probes_passed_this_span` — or 0 if the probation failed — as `held_probes_passed`, and
///   keeps its failed bonds (V03(2)). Held because overloaded (`utilization`, or a window that does
///   not fit the receipt deadline) keeps nothing, as v1.
/// * **`Held` with kept progress `k`** returns, when ready enough and not overloaded, to
///   `Probation { k }` (0 if the probation failed meanwhile) with its failed bonds; otherwise it stays
///   `Held` with `k` (0 if failed). Passes while `Held` are not added: the kept progress is the one
///   the class had.
/// * **`Probation { p }`, drawable and not failed**, counts its passes exactly as v1 (a single bond's
///   failures no longer stop it), keeping its failed bonds; graduating to `ActiveLimited` forgets
///   them.
/// * **Every other state** steps as v1 and remembers nothing: a probation entered from `Prefetching`
///   or from a `Held` without kept progress (an `Active` class's hold) starts at 0 with no failed
///   bond.
pub fn palw_lifecycle_step_resilient_v1(
    state: PalwModelLifecycleV1,
    obs: &PalwLifecycleObservationV1,
    profile: &PalwDerivedProfileV1,
    g: &PalwRegistryGlobalsV1,
    memory: &PalwProbationMemoryV1,
) -> (PalwModelLifecycleV1, PalwProbationMemoryV1) {
    use PalwModelLifecycleV1::*;
    let panel_drawable = obs.ready_seats >= g.seat_count as u32;
    let ready_enough = obs.ready_seats >= profile.required_ready_seats && obs.collateral_ok && obs.independence_floor_met;
    let overloaded = obs.utilization_permille >= 1_000 || !obs.window_fits_receipt;
    let failed = memory.probation_failed();
    // The failed bonds survive a step only inside the probation, and never the reset they caused.
    let keep_bonds = |next: PalwModelLifecycleV1, held: Option<u32>| PalwProbationMemoryV1 {
        held_probes_passed: held,
        failed_bonds: if failed { Vec::new() } else { memory.failed_bonds.clone() },
    }
    .with_state(next);
    match state {
        Probation { probes_passed } => {
            if overloaded {
                (Held, PalwProbationMemoryV1::default())
            } else if !panel_drawable {
                let kept = if failed { 0 } else { probes_passed.saturating_add(obs.probes_passed_this_span) };
                keep_bonds(Held, Some(kept))
            } else if failed {
                (Probation { probes_passed: 0 }, PalwProbationMemoryV1::default())
            } else {
                let passed = probes_passed.saturating_add(obs.probes_passed_this_span);
                if passed >= g.probation_claims && ready_enough {
                    (ActiveLimited { stable_epochs: 0 }, PalwProbationMemoryV1::default())
                } else {
                    keep_bonds(Probation { probes_passed: passed }, None)
                }
            }
        }
        Held if memory.held_probes_passed.is_some() => {
            let kept = if failed { 0 } else { memory.held_probes_passed.unwrap_or(0) };
            if ready_enough && !overloaded {
                keep_bonds(Probation { probes_passed: kept }, None)
            } else {
                keep_bonds(Held, Some(kept))
            }
        }
        other => (palw_lifecycle_step_v1(other, obs, profile, g), PalwProbationMemoryV1::default()),
    }
}

impl PalwProbationMemoryV1 {
    /// Pair a memory with the state it was kept for (a helper of [`palw_lifecycle_step_resilient_v1`]).
    fn with_state(self, state: PalwModelLifecycleV1) -> (PalwModelLifecycleV1, PalwProbationMemoryV1) {
        (state, self)
    }
}

// ---- Protocol Upgrade A: what the fold stores and reads ---------------------------------------

/// **The work of a registered class, read off the carriage its registration rode** (ADR-0067: a
/// class is chain data; the `admission` carriage holds the graph profile and the canonical job).
/// `verification_ccu` is the economic compute of the canonical job a seat replays to verify one
/// claim (ADR-0131's cost table over the graph); `economic_ccu_per_claim` is the compute of ONE
/// draw (the prefill draw job) — the cadence step multiplies it by the class's expected draws a
/// claim (Q32, from its live target), so the profile follows the target and the graph, never a
/// declaration. `artifact_bytes` is an estimate from the graph's dense weights (two bytes a weight
/// at the per-token dense MAC count), used only for the prefetch allowance — **never for admission,
/// the bond, the window or the inflight cap** (those read the compute); a manifest that carries the
/// bytes is V2's, and until then no rule may start reading this field.
pub fn palw_model_work_from_carriage_v1(
    profile: &crate::palw_step::PalwShapeProfileV3,
    canonical: &crate::palw_v2::PalwJobContextV2,
) -> Option<PalwModelWorkV1> {
    use crate::palw_economic_compute_v1::{
        PALW_ECONOMIC_COST_TABLE_V1, palw_attempt_economic_compute_v1, palw_economic_shape_v1, palw_job_economic_compute_v1,
    };
    let table = &PALW_ECONOMIC_COST_TABLE_V1;
    let verification_ccu = palw_job_economic_compute_v1(profile, canonical, table).ok()?;
    let draw = palw_attempt_economic_compute_v1(profile, canonical, true, table).ok()?;
    let shape = palw_economic_shape_v1(profile, table).ok()?;
    let body = shape.body_at(0);
    let artifact_bytes = body.dense_matmul.saturating_add(body.routed_experts).saturating_mul(2).min(u64::MAX as u128) as u64;
    Some(PalwModelWorkV1 {
        verification_ccu,
        economic_ccu_per_claim: draw,
        artifact_bytes,
        working_set_bytes: artifact_bytes,
        ops_supported: verification_ccu > 0,
    })
}

/// **The shipped classes' work, from the typed catalog every node compiles** — the floor, the
/// Qwen3.6 hybrid, the Qwen2.5 A16 graph-v5 row and the Qwen3.8-27B row, each with the canonical
/// job its registration prices — for the genesis classes no bundle registration describes (a genesis
/// class carries no admission carriage; its profile is the catalog's, of which the bundle holds only
/// a root). A function of the binary, so every node running it derives the same works.
pub fn palw_rc_typed_class_works_v1() -> BTreeMap<Hash64, PalwModelWorkV1> {
    use crate::palw_base0_profile::{PALW_RC_BASE0_CANONICAL, PALW_RC_BASE0_GEOMETRY, base0_profile_v1, rc_job_context};
    use crate::palw_context_ladder::palw_a16_context_row_profile_v5;
    use crate::palw_qwen25_profile::{QWEN25_A16_GRAPH_V5_N_CTX, qwen25_a16_graph_v5_canonical_v1};
    use crate::palw_qwen36_profile::qwen36_geometry_artifact_eps;
    use crate::palw_qwen36_profile::{QWEN36_35B_A3B, QWEN36_RC_CANONICAL, QWEN38_27B, qwen36_profile_v2};
    let mut rows: Vec<(crate::palw_step::PalwShapeProfileV3, (u32, u32))> = Vec::with_capacity(4);
    if let Ok(floor) = base0_profile_v1(PALW_RC_BASE0_GEOMETRY) {
        rows.push((floor, PALW_RC_BASE0_CANONICAL));
    }
    if let Ok(hybrid) = qwen36_profile_v2(qwen36_geometry_artifact_eps(QWEN36_35B_A3B)) {
        rows.push((hybrid, QWEN36_RC_CANONICAL));
    }
    if let Ok(dense) = palw_a16_context_row_profile_v5(QWEN25_A16_GRAPH_V5_N_CTX) {
        rows.push((dense, qwen25_a16_graph_v5_canonical_v1()));
    }
    if let Ok(unit) = qwen36_profile_v2(qwen36_geometry_artifact_eps(QWEN38_27B)) {
        rows.push((unit, QWEN36_RC_CANONICAL));
    }
    rows.into_iter()
        .filter_map(|(profile, (prefill, decode))| {
            let canonical = rc_job_context(&profile, prefill, decode);
            palw_model_work_from_carriage_v1(&profile, &canonical).map(|work| (profile.shape_profile_id(), work))
        })
        .collect()
}

/// **The genesis classes' work**, from the registrations the bundle's genesis carries — every node
/// derives the bundle from `Params`, so this map is a function of the ruleset, not of a store.
pub fn palw_genesis_model_works_v1(objects: &[crate::palw_state_v2::PalwConsensusObjectV2]) -> BTreeMap<Hash64, PalwModelWorkV1> {
    let mut out = BTreeMap::new();
    for object in objects {
        if let crate::palw_state_v2::PalwConsensusObjectV2::ClassRegistered { class_id, admission: Some(carriage), .. } = object
            && let Some(work) = palw_model_work_from_carriage_v1(&carriage.profile, &carriage.canonical)
        {
            out.insert(*class_id, work);
        }
    }
    out
}

/// **The profile a lifecycle row carries this span**: the stored work with the class's expected
/// draws a claim (Q32) folded into the economic compute a claim costs.
pub fn palw_lifecycle_profile_v1(
    work: &PalwModelWorkV1,
    expected_attempts_q32: u128,
    g: &PalwRegistryGlobalsV1,
    possession_gate: bool,
) -> PalwDerivedProfileV1 {
    let per_claim = crate::palw_economic_compute_v1::palw_attempted_compute_q32_per_claim_v1(
        expected_attempts_q32.max(crate::palw_economic_compute_v1::PALW_EXPECTED_ATTEMPTS_Q32_ONE_V1),
        work.economic_ccu_per_claim,
    );
    palw_derive_profile_v1(&PalwModelWorkV1 { economic_ccu_per_claim: per_claim, ..*work }, g, possession_gate)
}

/// **A class's row in the registry** — the state machine's position, the work its registration
/// derived, the profile of the last span, and the counters the lifecycle reads.
#[derive(Clone, Debug, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub struct PalwModelLifecycleRowV1 {
    pub state: PalwModelLifecycleV1,
    pub work: PalwModelWorkV1,
    pub profile: PalwDerivedProfileV1,
    /// The span the current state was entered at.
    pub since_span: u64,
    /// Finals and faults of the class's claims since the state was entered (probation reads them).
    pub probes_passed: u32,
    pub probes_failed: u32,
    /// Finals and faults of the span being stepped, cleared at every boundary.
    pub probes_passed_this_span: u32,
    pub probes_failed_this_span: u32,
    /// The last boundary's reading, kept so a reader (op 186) sees what the step saw.
    pub ready_seats: u32,
    pub inflight_claims: u32,
    pub utilization_permille: u32,
    pub admission_milli: u64,
    /// ADR-0132 Upgrade C: the class's cap utilization at the last boundary, in permille of the
    /// escrow (`attempted × rate / escrow`); `0` where nothing priced it (the payout fence dormant,
    /// or no subsidy at the boundary block). Over the fence's ceiling the class is not activatable.
    pub cap_utilization_permille: u32,
    /// **The share the registry priced the class's target for** (ADR-0135 §7, the devnet drill's
    /// seventh finding), `0` until the registry has seated it. A registration copies the floor's
    /// target (op 180's terms), a price for the floor's draw rate and not the class's; ADR-0076
    /// says a class being seated is a class being priced, and the activation edge already prices a
    /// weightless class from its share and its counted work. The registry's admission is the same
    /// event: at the first governed boundary a class holds a nonzero share in an admitted state, its
    /// target is `attempt_target_seed_v1(share, pwu)` and this records the share. Once — from there
    /// the class DAA owns the target, and a share the registry moves later is measured by the
    /// retarget against the history the class then has. The floor is never priced here.
    pub priced_share_permille: u16,
}

/// **A seat's readiness for a class**: the last possession proof this bond opened for the class
/// (ADR-0135 Decision 4). Fresh while `proved_daa` is within the readiness age; the probe half of
/// readiness is the seat's last `Valid` receipt on the class, read off the claims.
#[derive(Clone, Copy, Debug, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub struct PalwSeatReadinessRowV1 {
    pub proved_daa: u64,
    pub proved_span: u64,
    pub leaf_index: u32,
    /// **Which evidence wrote this row** (H-6, ADR-0133 §11.2): `1` for a V1 proof — one leaf of a
    /// contiguous eight-leaf window — and `2` for a `SeatReadinessProvedV2` multiproof over leaves
    /// drawn from the whole artifact. Past `Params::palw_readiness_v2` only a V2 row counts a seat
    /// ready, so a V1 row ages out instead of standing in for possession it never showed.
    pub proof_version: u8,
    /// How many leaves the proof opened (1 for V1).
    pub chunks: u32,
}

/// **What the fold is handed when the registry is active at a block** (`PalwTransitionExtrasV1`):
/// the globals, the span clock, and the genesis classes' work (the classes registered before the
/// fence, whose carriages the state never stored).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwModelRegistryFoldV1 {
    pub globals: PalwRegistryGlobalsV1,
    pub span_daa: u64,
    pub genesis_works: BTreeMap<Hash64, PalwModelWorkV1>,
    /// **The activation grace** (ADR-0135 §7): proofs are refused below the fence, so at activation
    /// no seat is ready and every live class would be HELD at the first boundary. Until this DAA
    /// (the fence plus one readiness age) the rows open and proofs are taken but no row is stepped
    /// and the draw keeps judging by declaration; from it the registry governs. `0` = no grace.
    pub grace_until_daa: u64,
    /// **The admission-audit period in DAA** (`Params::palw_admission_audit_period_daa`). `None`
    /// is ADR-0147's one-epoch period ([`palw_admission_audit_period_spans_v1`]), byte for byte.
    pub admission_audit_period_daa: Option<u64>,
    /// **`Params::palw_readiness_v2` at the fold's DAA — which rule a readiness row's freshness is
    /// judged by** ([`palw_readiness_row_is_fresh_v1`]). The fold itself reads
    /// `PalwTransitionExtrasV1::readiness_v2_active`, resolved at the same DAA from the same fence;
    /// this copy is for the readers that hold only the fold — the registry read the RPC serves
    /// (`readySeatsNow`, each seat's `fresh`), so they judge a row the way the fold counts it.
    pub readiness_v2_active: bool,
    /// **Lane maturity-ext (post-launch, 2026-09-26): ADR-0065 D1 where the registry counts a bond**
    /// — `Some` only where `Params::palw_bond_maturity_early` is active at the fold's DAA
    /// ([`palw_bond_maturity_fold_v1`]). Past it a non-genesis bond is not a ready seat (the ready
    /// count, the panel room, the `NoCapablePanel` test, the Activation Pool's (a)) and not in an
    /// admission jury's population until its own window has run, by the draw's own arithmetic. `None`
    /// — every shipped preset, testnet-12 included, and every DAA below the fence — is the registry
    /// byte for byte as released. Carried on the fold rather than on the extras beside it so the
    /// readers that hold only the fold (the RPC's `readySeatsNow`, op 186's room) ask the one
    /// predicate ([`palw_seat_not_ready_reason_net_v1`]) the chain asks.
    pub bond_maturity: Option<PalwBondMaturityFoldV1>,
}

// ---- lane maturity-ext (post-launch, 2026-09-26): ADR-0065 D1 on the registry and the jury ------
/// **ADR-0065 D1 as the registry reads it** (lane maturity-ext, user decision 2026-09-26: "apply it
/// under the same DAA-500 fence"). Lane maturity (`Params::palw_bond_maturity_early`) brought D1
/// forward for the PANEL DRAW; a bond the draw may not seat was still counted as a ready seat
/// toward a class's `ready ≥ k` thresholds, and still drawn onto ADR-0147's admission jury (whose
/// only cutoff was "registered before the seeding span"). A seat that registered minutes ago could
/// hold a class out of `Held`, or vote a `Candidate` in.
///
/// Past the same fence this is the draw's rule, asked at the EVALUATING block's DAA (the lifecycle
/// step's and the jury's `ctx.daa_score` — the block the answer is folded in, the way the draw asks
/// it at the anchor it is a function of): `palw_bond_maturity`'s window, widened by the second
/// clock exactly as the processor's `palw_bond_maturity_window_at` widens it, one subtraction. A
/// genesis bond (registered at the genesis DAA, 0 on every shipped genesis) is mature at every DAA.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwBondMaturityFoldV1 {
    /// `Params::palw_bond_maturity`'s window (1,000 DAA on testnet-12) — the one window; the fence
    /// has none of its own.
    pub window_daa: u64,
    /// The second clock's RAW depth at the fold's DAA (`Params::palw_settled_anchor_depth` where
    /// `palw_audit_2026_09_23` is active, else `None`) — the processor's `palw_settled_anchor_depth_at`,
    /// before the liveness escape, which [`Self::registered_by_daa`] applies on the state it judges.
    pub settled_anchor_depth: Option<u64>,
}

impl PalwBondMaturityFoldV1 {
    /// **The latest registration DAA that counts at `now_daa`** — the draw's floor
    /// (`palw_seat_maturity_floor_v1` over `palw_bond_maturity_window_v2`) with `now_daa` as the
    /// anchor: `now_daa − window`, the window widened so the floor is no later than the second
    /// clock's (`palw_settled_anchor_floor_daa_v1` at the escaped depth), saturating at 0.
    pub fn registered_by_daa(&self, state: &crate::palw_state_v2::PalwChainStateV2, window_court: u64, now_daa: u64) -> u64 {
        let depth =
            crate::palw_state_v2::palw_second_clock_depth_v1(self.settled_anchor_depth, state.recent_anchor_daas(), now_daa, window_court);
        let settled = depth.and_then(|depth| crate::palw_panel_v2::palw_settled_anchor_floor_daa_v1(state, now_daa, depth));
        let window = crate::palw_panel_v2::palw_bond_maturity_window_v2(now_daa, self.window_daa, settled);
        crate::palw_panel_v2::palw_seat_maturity_floor_v1(now_daa, Some(window)).unwrap_or(0)
    }

    /// Whether `bond` counts at `now_daa`: registered at or before [`Self::registered_by_daa`] — the
    /// draw's `registered_daa <= by`.
    pub fn admits(
        &self,
        state: &crate::palw_state_v2::PalwChainStateV2,
        window_court: u64,
        bond: &crate::palw_state_v2::PalwBondStateV2,
        now_daa: u64,
    ) -> bool {
        bond.registered_daa <= self.registered_by_daa(state, window_court, now_daa)
    }
}

/// **[`PalwModelRegistryFoldV1::bond_maturity`] at `daa`, resolved in one place** for the processor
/// (`palw_model_registry_fold_at`) and `Params` ([`crate::config::params::Params::palw_bond_maturity_registry_fold_at`]):
/// `Some` iff lane maturity's fence (`early`, mode-folded, `never()` already dropped) is active at
/// `daa` AND `palw_bond_maturity` is scheduled (whose window it reads; `validate_palw_v2` refuses the
/// fence without it). Keyed on the early fence ALONE, not on `palw_bond_maturity`'s own height: the
/// release never applied D1 to the registry, so testnet-12 as shipped keeps its registry past 1,000
/// byte for byte, and armed the rule holds from the fence on, across 1,000, with one window.
pub fn palw_bond_maturity_fold_v1(
    maturity: Option<crate::config::params::PalwBondMaturityV1>,
    early: Option<crate::config::params::ForkActivation>,
    settled_anchor_depth: Option<u64>,
    daa: u64,
) -> Option<PalwBondMaturityFoldV1> {
    let maturity = maturity?;
    early.filter(|fence| fence.is_active(daa))?;
    Some(PalwBondMaturityFoldV1 { window_daa: maturity.window_daa, settled_anchor_depth })
}
// ---- end lane maturity-ext ------------------------------------------------------------------------

impl PalwModelRegistryFoldV1 {
    /// Whether the registry governs (steps rows, judges by evidence) at `daa_score`.
    pub fn governs_at(&self, daa_score: u64) -> bool {
        daa_score >= self.grace_until_daa
    }

    /// The readiness age this fold judges a row by, in DAA ([`palw_readiness_max_age_daa_v1`]).
    pub fn readiness_max_age_daa(&self) -> u64 {
        palw_readiness_max_age_daa_v1(self.span_daa, &self.globals, self.readiness_v2_active)
    }

    /// Is `row` fresh at `now_daa` under this fold's rule ([`palw_readiness_row_is_fresh_v1`])?
    pub fn readiness_row_is_fresh(&self, row: &PalwSeatReadinessRowV1, now_daa: u64) -> bool {
        palw_readiness_row_is_fresh_v1(row, now_daa, self.span_daa, &self.globals, self.readiness_v2_active)
    }

    /// One readiness age past the fence: the grace every activation gets.
    pub fn grace_until_v1(activation_daa: u64, span_daa: u64, globals: &PalwRegistryGlobalsV1) -> u64 {
        activation_daa.saturating_add((globals.readiness_probe_max_age_spans as u64).saturating_mul(span_daa.max(1)))
    }
}

/// **How long a readiness row stands, in DAA — the one rule** (the 2026-09-24 readiness-age sweep).
/// Past `Params::palw_readiness_v2` a row stands for the globals' `readiness_v2_max_age_spans` (the
/// challenge rotates every span, and the rotation has to bite): eight spans on every network but
/// testnet-12, which arms `Params::palw_readiness_v2_max_age_spans` at genesis with twenty-four (user
/// decision 2026-09-25, readiness capacity option (a)); before it, for the globals'
/// `readiness_probe_max_age_spans` (thirty). The configured horizon is an INPUT here, never a second
/// copy of this rule: every judge of a row — the fold's count, ADR-0147's jury, the draw, the RPC,
/// the panel view, the node's half-age duty and the M1 escalation's `max − 2` — reaches it through
/// `g`.
pub fn palw_readiness_max_age_daa_v1(span_daa: u64, g: &PalwRegistryGlobalsV1, readiness_v2: bool) -> u64 {
    let spans = if readiness_v2 { g.readiness_v2_max_age_spans } else { g.readiness_probe_max_age_spans };
    (spans as u64).saturating_mul(span_daa.max(1))
}

/// **Is a readiness row fresh at `now_daa` — the ONE predicate** every judge of a row asks: the
/// fold's ready-seat count and ADR-0147's jury (`model_registry_seat_is_ready`), the registry read
/// the RPC serves (`readySeatsNow`, each seat's `fresh` and `not_ready_reason`), the panel view and
/// — past `Params::palw_audit_2026_09_23` — the panel draw ([`PalwReadinessPolicyV1`]). Past
/// readiness V2 a V1 (one-leaf) row is not fresh at any age, and a V2 row stands
/// [`palw_readiness_max_age_daa_v1`]; before it, any row stands the thirty-span V1 age.
///
/// Found by the sweep: the draw and the RPC counted a row fresh for the V1 age (30 DAA on
/// testnet-12's one-DAA spans) while the registry's count used the V2 age (8), so the RPC reported
/// more ready seats than the registry counted, and the draw seated bonds the registry held out.
pub fn palw_readiness_row_is_fresh_v1(
    row: &PalwSeatReadinessRowV1,
    now_daa: u64,
    span_daa: u64,
    g: &PalwRegistryGlobalsV1,
    readiness_v2: bool,
) -> bool {
    if readiness_v2 && row.proof_version < 2 {
        return false; // a one-leaf proof is not possession past the fence
    }
    now_daa.saturating_sub(row.proved_daa) <= palw_readiness_max_age_daa_v1(span_daa, g, readiness_v2)
}

/// **The draw's readiness policy** under the registry: a seat may judge a class only with a
/// possession proof no older than `max_age_daa` at `now_daa` (the base class stays open to every
/// bond, as before — every node runs it).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwReadinessPolicyV1 {
    pub now_daa: u64,
    pub max_age_daa: u64,
    pub base_class_id: Hash64,
    /// **Whether the draw judges a row by the readiness-V2 rule** — the one the registry counts by
    /// ([`palw_readiness_row_is_fresh_v1`]): a V1 row never, a V2 row for the globals'
    /// `readiness_v2_max_age_spans` (eight spans; twenty-four on testnet-12). Set only past
    /// `Params::palw_audit_2026_09_23` AND `Params::palw_readiness_v2` at the anchor, so on every
    /// network without the audit fence (testnet-11) the draw keeps its old rule byte for byte: any
    /// row, for `max_age_daa` (the V1 age).
    pub readiness_v2: bool,
    /// **Lane MU (ADR-0173, `palw_audit_1004_v1`): the draw reads a seat's possession of the claim's own ROOT** (`claim_roots`, the
    /// founding root when absent) instead of its row for the class. `false` below the fence, which is the draw before it existed.
    pub root_keyed: bool,
}

impl PalwReadinessPolicyV1 {
    /// The policy at `anchor_daa` under `fold`: `readiness_v2` is the caller's resolution of the
    /// two fences above, and `max_age_daa` follows it through the one age rule.
    pub fn at(fold: &PalwModelRegistryFoldV1, anchor_daa: u64, base_class_id: Hash64, readiness_v2: bool) -> Self {
        Self {
            now_daa: anchor_daa,
            max_age_daa: palw_readiness_max_age_daa_v1(fold.span_daa, &fold.globals, readiness_v2),
            base_class_id,
            readiness_v2,
            root_keyed: false,
        }
    }

    /// Lane MU (ADR-0173): the same policy, root-keyed where `palw_audit_1004_v1` is in force at the anchor.
    pub fn with_root_keyed(mut self, root_keyed: bool) -> Self {
        self.root_keyed = root_keyed;
        self
    }

    /// May a seat whose row for the class is `row` judge it under this policy? Below the V2 rule,
    /// exactly the old test (`now - proved <= max_age_daa`, any version).
    pub fn admits(&self, row: &PalwSeatReadinessRowV1) -> bool {
        if self.readiness_v2 && row.proof_version < 2 {
            return false;
        }
        self.now_daa.saturating_sub(row.proved_daa) <= self.max_age_daa
    }
}

/// One opening per proof, capped: an artifact leaf is a tensor row range and rides the object
/// chunk carriage above a block's payload, so the cap bounds what a proof may ask the chain to carry.
pub const PALW_READINESS_OPENING_MAX_BYTES_V1: usize = 8 << 20;
/// The challenge names `width` consecutive leaves from a seeded start; the prover opens ONE of
/// them (V1: a leaf may be large, so the prover picks the one it can carry). A holder of the whole
/// artifact answers every span; a holder of a fraction fails a span with the fraction it lacks.
pub const PALW_READINESS_CHALLENGE_WIDTH_V1: u32 = 8;
pub const PALW_SEAT_READINESS_V1_DOMAIN: &[u8] = b"misaka-palw/seat-readiness-v1/message/v1";
pub const PALW_SEAT_READINESS_V1_CHALLENGE_DOMAIN: &[u8] = b"misaka-palw/seat-readiness-v1/challenge/v1";
pub const PALW_SEAT_READINESS_V1_MLDSA87_CONTEXT: &[u8] = b"misaka-palw/seat-readiness-v1/mldsa87/v1";

/// **ADR-0133 §11.2 / H-6: the leaves a V2 possession proof opens.** Sixteen, drawn independently
/// from the WHOLE artifact rather than from one contiguous window of eight — a seat holding a
/// fraction `f` of the artifact answers a challenge with probability `f¹⁶`, so possession is what is
/// shown rather than reach. Capped at the inventory's own size for a small artifact.
pub const PALW_READINESS_V2_CHUNKS_V1: u32 = 16;
/// **How fresh a V2 row must be to count a seat ready**, in execution spans — the DEFAULT horizon,
/// every network's without `Params::palw_readiness_v2_max_age_spans` (the globals carry the one a
/// network's fold is handed: [`PalwRegistryGlobalsV1::readiness_v2_max_age_spans`]). The challenge
/// already rotates every span (the seed carries it); this is what makes the rotation bite — a proof
/// stands for eight spans, not the thirty a V1 row was given.
pub const PALW_READINESS_V2_MAX_AGE_SPANS_V1: u32 = 8;
/// **testnet-12's readiness-V2 horizon, in spans** (user decision 2026-09-25, readiness capacity
/// option (a); `Params::palw_readiness_v2_max_age_spans`). A V2 proof is ~48.9 KB — ~195,508
/// transient mass, two a block — and at one block a DAA the integration owner's network model (eight
/// seats × two genesis classes, the real scheduler) kept about 6.4 of sixteen rows fresh on empty
/// blocks and 2.7–4.2 in a DA storm at eight spans, against the ten both classes need to stay out of
/// HELD. Twenty-four spans (24 DAA on testnet-12's one-DAA spans) is the longer horizon the user
/// chose; the node re-proves at half of it (12) and escalates from `24 − 2`.
pub const PALW_READINESS_V2_MAX_AGE_SPANS_T12_V1: u32 = 24;
/// **The longest readiness-V2 horizon a network may configure, in spans**: the V1 age
/// (`PALW_REGISTRY_GLOBALS_V1.readiness_probe_max_age_spans`, thirty). A V2 row exists to make
/// possession bite harder than the one-leaf row it replaced; a horizon past the V1 age would make
/// the multiproof row the longer licence of the two. The shortest is the default,
/// [`PALW_READINESS_V2_MAX_AGE_SPANS_V1`]: a horizon never shortens below today's, so the half-age
/// duty (due past `max / 2`) always comes before the M1 escalation (from `max − 2`) — at eight, age
/// 5 before age 6; at 24, age 13 before age 22.
pub const PALW_READINESS_V2_MAX_AGE_SPANS_MAX_V1: u32 = PALW_REGISTRY_GLOBALS_V1.readiness_probe_max_age_spans;
/// **The frame a V2 proof carries besides its operands**: the Merkle siblings, the ML-DSA-87
/// signature and the object's own framing. 32 KiB covers sixteen paths of a tree up to 2^27 leaves
/// (16 x 27 x 64 = 27,648) plus a 4,627-byte signature; the shipped A16 class measures 19,789.
pub const PALW_READINESS_V2_FRAME_BYTES_V1: usize = 32 << 10;
/// **The largest leaf a possession proof may open.** An inventory row above this cannot be proved
/// and its class cannot seat — said here, once, so an artifact builder has a number to refuse at
/// rather than a chain that silently never admits the class. The shipped A16 class's largest row is
/// 35,840 bytes (p50 1,536, mean 4,204).
pub const PALW_READINESS_V2_LEAF_MAX_BYTES_V1: usize = 40 << 10;
/// **The operand budget one challenge spends**, derived from the carrier and nothing else:
/// `PALW_OBJECT_CHUNK_MAX_BYTES` is what one transaction carries, the frame and one maximal leaf
/// are what a proof must have room for beside the budget, and what is left is the budget. The
/// prover opens the drawn leaves, in the draw's own order, until the bytes reach it — so a class
/// whose rows are small is sampled in many places and one whose rows are large in few, and either
/// proof fits the carrier that takes it to the chain.
pub const PALW_READINESS_V2_BUDGET_BYTES_V1: usize =
    crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES - PALW_READINESS_V2_FRAME_BYTES_V1 - PALW_READINESS_V2_LEAF_MAX_BYTES_V1;
/// **The bytes a V2 proof's opened operands may carry in total.** The budget plus the one leaf that
/// may cross it — the worst case the stop rule admits, and with the frame it is exactly one
/// carrier. It was `1 << 20` (ten carriers) and derived from nothing: a seat built proofs no
/// transaction could hold, four spans in eight for the shipped class, and the seat then proved
/// nothing at all in those spans — silently, because a carrier refusal is not a chain event.
pub const PALW_READINESS_V2_OPERAND_MAX_BYTES_V1: usize = PALW_READINESS_V2_BUDGET_BYTES_V1 + PALW_READINESS_V2_LEAF_MAX_BYTES_V1;
/// The effective one-carrier ceiling for the first readiness-V2 producer. Its logical operand
/// bound was 1 MiB, but a block could only carry one 100 KB lifecycle object. Blocks mined before
/// the carrier-bounded form shipped contain complete sixteen-leaf proofs below this real ceiling.
/// Those historical proofs must keep their original meaning when a node replays or IBDs the chain;
/// otherwise an upgrade changes already-accepted PALW state.
pub const PALW_READINESS_V2_LEGACY_FULL_CHALLENGE_OPERAND_MAX_BYTES_V1: usize = crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES;

/// Whether a proof is the only historical V2 form which may exceed the current one-carrier
/// operand ceiling. It is deliberately narrow: exactly the old full sixteen-leaf challenge,
/// bounded by its former ceiling. New proofs always use the carrier-bounded prefix rule.
pub fn palw_readiness_v2_is_legacy_full_challenge_v1(opened_count: usize, operand_bytes: usize) -> bool {
    opened_count == PALW_READINESS_V2_CHUNKS_V1 as usize
        && operand_bytes > PALW_READINESS_V2_OPERAND_MAX_BYTES_V1
        && operand_bytes <= PALW_READINESS_V2_LEGACY_FULL_CHALLENGE_OPERAND_MAX_BYTES_V1
}
pub const PALW_SEAT_READINESS_V2_DOMAIN: &[u8] = b"misaka-palw/seat-readiness-v2/message/v1";
pub const PALW_SEAT_READINESS_V2_CHALLENGE_DOMAIN: &[u8] = b"misaka-palw/seat-readiness-v2/challenge/v1";
pub const PALW_SEAT_READINESS_V2_MLDSA87_CONTEXT: &[u8] = b"misaka-palw/seat-readiness-v2/mldsa87/v1";

fn keyed64(domain: &[u8]) -> blake2b_simd::State {
    blake2b_simd::Params::new().hash_length(64).key(domain).to_state()
}
fn finish64(state: blake2b_simd::State) -> Hash64 {
    let mut out = [0u8; 64];
    out.copy_from_slice(state.finalize().as_bytes());
    Hash64::from_bytes(out)
}

/// **What this build believes a V2 possession proof IS**, as a value two operators can compare.
///
/// `consensus_params_id` hashes the fence's HEIGHT and never the rule the fence turns on
/// (`params.rs`: "ADR-0133 §11.2 readiness V2: the height only, Some-only"), so a build carrying
/// one possession rule and a build carrying another are the same network by fork-id and different
/// networks the moment the fence fires. That is the shape this tree calls a silent fork, and the
/// 2026-09-20 rule change — sixteen leaves became the prefix a carrier's budget buys — is one:
/// nothing in the identity moved, because nothing in `Params` moved.
///
/// It cannot be fixed by hashing this into the identity (that would re-mint every network that has
/// the fence scheduled, for a rule none of them has run yet). What it can do is be VISIBLE: the
/// node prints this beside its fingerprint, so "are we running the same possession rule" is a
/// question two operators can answer by reading two lines, before the height rather than after it.
pub fn palw_readiness_v2_rule_tag_v1() -> Hash64 {
    let mut state = keyed64(b"misaka-palw/seat-readiness-v2/rule-tag/v1");
    state.update(&(PALW_READINESS_V2_CHUNKS_V1 as u64).to_le_bytes());
    state.update(&(PALW_READINESS_V2_BUDGET_BYTES_V1 as u64).to_le_bytes());
    state.update(&(PALW_READINESS_V2_LEAF_MAX_BYTES_V1 as u64).to_le_bytes());
    state.update(&(PALW_READINESS_V2_FRAME_BYTES_V1 as u64).to_le_bytes());
    state.update(&(PALW_READINESS_V2_OPERAND_MAX_BYTES_V1 as u64).to_le_bytes());
    state.update(&(PALW_READINESS_V2_LEGACY_FULL_CHALLENGE_OPERAND_MAX_BYTES_V1 as u64).to_le_bytes());
    finish64(state)
}

/// **The challenge seed of (class, bond, span)**: every node derives it, the prover cannot choose it.
pub fn palw_readiness_challenge_seed_v1(class_id: &Hash64, bond: &[u8], span: u64) -> Hash64 {
    let mut state = keyed64(PALW_SEAT_READINESS_V1_CHALLENGE_DOMAIN);
    state.update(class_id.as_byte_slice());
    state.update(&(bond.len() as u64).to_le_bytes());
    state.update(bond);
    state.update(&span.to_le_bytes());
    finish64(state)
}

/// **The leaves the challenge names**: `(start, width)` over `leaf_count`, wrapping.
/// **ADR-0133 §11.2: the V2 challenge — `k` leaves of the whole artifact, for this (class, bond,
/// span).** Independent draws from the full range, de-duplicated by advancing the counter, returned
/// in ascending order. A function of the chain alone: the seed is
/// [`palw_readiness_v2_challenge_seed_v1`], so the prover, every validator and the court draw the
/// same set, and no seat learns its leaves before the span it must prove them in.
pub fn palw_readiness_v2_leaves_v1(seed: &Hash64, leaf_count: u32) -> Vec<u32> {
    let mut picked = palw_readiness_v2_draw_v1(seed, leaf_count);
    picked.sort_unstable();
    picked
}

/// **The same challenge, in the order it was drawn** — which is the order the proof opens in.
///
/// The set alone cannot say how much of it a proof owes: the operands have to fit one carrier
/// (`PALW_READINESS_V2_OPERAND_MAX_BYTES_V1`), so the prover opens a PREFIX of this order and stops
/// at [`PALW_READINESS_V2_BUDGET_BYTES_V1`]. A sorted set would let a prover choose which leaves to
/// count as "the prefix", and choosing is the one thing a possession challenge must not allow.
pub fn palw_readiness_v2_draw_v1(seed: &Hash64, leaf_count: u32) -> Vec<u32> {
    if leaf_count == 0 {
        return Vec::new();
    }
    let want = PALW_READINESS_V2_CHUNKS_V1.min(leaf_count) as usize;
    let mut picked: Vec<u32> = Vec::with_capacity(want);
    // A bounded walk: every draw either adds a leaf or collides, and a collision costs one counter
    // step. `want ≤ leaf_count`, so the walk terminates well inside the cap.
    let cap = (want as u64).saturating_mul(64).saturating_add(256);
    let mut counter = 0u64;
    while picked.len() < want && counter < cap {
        let mut state = keyed64(PALW_SEAT_READINESS_V2_CHALLENGE_DOMAIN);
        state.update(seed.as_byte_slice());
        state.update(&counter.to_le_bytes());
        let digest = finish64(state);
        let bytes = digest.as_bytes();
        let word = u64::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7]]);
        let leaf = (word % leaf_count as u64) as u32;
        if !picked.contains(&leaf) {
            picked.push(leaf);
        }
        counter += 1;
    }
    picked
}

/// **What a V2 proof owes the challenge** (ADR-0133 §11.2, as the carrier bounds it): the opened
/// leaves are the first `m` of `draw`, in draw order, where `m` is the FEWEST leaves whose bytes
/// reach [`PALW_READINESS_V2_BUDGET_BYTES_V1`] — or the whole draw where it never does.
///
/// Every clause is decided from what the proof itself carries, which is what makes it a rule and
/// not a request: the draw is the chain's, the prefix is the draw's, and the two byte conditions
/// are read off the operands. A prover that stops early carries less than the budget with leaves
/// left in the draw; one that stops late carries a prefix whose last leaf was not needed. Neither
/// is accepted, so the only proof that verifies is the one the challenge named.
///
/// `opened` is `(leaf_index, operand_bytes)` as the proof carries it, in any order.
pub fn palw_readiness_v2_opening_is_the_challenge_v1(draw: &[u32], opened: &[(u32, usize)]) -> Result<(), String> {
    if opened.is_empty() {
        return Err(format!("the proof opens no leaf; this span's challenge names {}", draw.len()));
    }
    if opened.len() > draw.len() {
        return Err(format!("the proof opens {} leaves; this span's challenge names {}", opened.len(), draw.len()));
    }
    let prefix = &draw[..opened.len()];
    let mut carried: Vec<u32> = opened.iter().map(|(index, _)| *index).collect();
    carried.sort_unstable();
    let mut wanted: Vec<u32> = prefix.to_vec();
    wanted.sort_unstable();
    if carried != wanted {
        return Err(format!(
            "the proof opens {carried:?}; this span's challenge names {wanted:?} (the first {} of {draw:?})",
            opened.len()
        ));
    }
    let size = |leaf: u32| opened.iter().find(|(index, _)| *index == leaf).map(|(_, bytes)| *bytes).unwrap_or(0);
    let mut total = 0usize;
    for (index, bytes) in opened {
        if *bytes > PALW_READINESS_V2_LEAF_MAX_BYTES_V1 {
            return Err(format!(
                "leaf {index} carries {bytes} bytes and no leaf above {PALW_READINESS_V2_LEAF_MAX_BYTES_V1} can ride a proof"
            ));
        }
        total = total.saturating_add(*bytes);
    }
    if total > PALW_READINESS_V2_OPERAND_MAX_BYTES_V1 {
        return Err(format!(
            "the proof carries {total} bytes of operands, above the {PALW_READINESS_V2_OPERAND_MAX_BYTES_V1} one carrier holds"
        ));
    }
    // The last leaf of the PREFIX is the one the budget had to reach for; without it the proof is
    // under budget, or the leaf was not needed and the prover opened more than the challenge asked.
    let last = *prefix.last().expect("a non-empty prefix has a last leaf");
    if total.saturating_sub(size(last)) >= PALW_READINESS_V2_BUDGET_BYTES_V1 {
        return Err(format!(
            "the proof opens {} leaves and its first {} already carry {} bytes, at or above the {PALW_READINESS_V2_BUDGET_BYTES_V1}              the challenge budgets — a leaf it did not owe",
            opened.len(),
            opened.len() - 1,
            total - size(last)
        ));
    }
    if total < PALW_READINESS_V2_BUDGET_BYTES_V1 && opened.len() < draw.len() {
        return Err(format!(
            "the proof carries {total} bytes, under the {PALW_READINESS_V2_BUDGET_BYTES_V1} the challenge budgets, and the draw              still names {} more leaves",
            draw.len() - opened.len()
        ));
    }
    Ok(())
}

/// The V2 challenge's seed: the class, the bond and the span, under the V2 domain (so a V1 seed is
/// never a V2 seed, whatever a relayer replays).
pub fn palw_readiness_v2_challenge_seed_v1(class_id: &Hash64, bond: &[u8], span: u64) -> Hash64 {
    let mut state = keyed64(PALW_SEAT_READINESS_V2_CHALLENGE_DOMAIN);
    state.update(class_id.as_byte_slice());
    state.update(&(bond.len() as u64).to_le_bytes());
    state.update(bond);
    state.update(&span.to_le_bytes());
    finish64(state)
}

/// **What a V2 proof's signature covers**: the network, the bond, the class, the span, the
/// inventory's size and **the bytes it opened** — the last of which V1's message omitted, so one
/// seat's published opening could be re-signed by another bond that never held the data.
pub fn palw_seat_readiness_message_v2(
    network_domain: Hash64,
    bond: &[u8],
    class_id: &Hash64,
    span: u64,
    proof: &crate::palw_artifact::PalwArtifactMultiproofV1,
) -> Hash64 {
    let mut state = keyed64(PALW_SEAT_READINESS_V2_DOMAIN);
    state.update(network_domain.as_byte_slice());
    state.update(&(bond.len() as u64).to_le_bytes());
    state.update(bond);
    state.update(class_id.as_byte_slice());
    state.update(&span.to_le_bytes());
    state.update(&proof.leaf_count.to_le_bytes());
    state.update(&(proof.opened.len() as u64).to_le_bytes());
    for (index, operand) in &proof.opened {
        state.update(&index.to_le_bytes());
        state.update(crate::palw_artifact::artifact_leaf_v1(operand).as_byte_slice());
    }
    finish64(state)
}

pub fn palw_readiness_window_v1(seed: &Hash64, leaf_count: u32) -> (u32, u32) {
    if leaf_count == 0 {
        return (0, 0);
    }
    let bytes = seed.as_bytes();
    let word = u64::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7]]);
    ((word % leaf_count as u64) as u32, PALW_READINESS_CHALLENGE_WIDTH_V1.min(leaf_count))
}

/// Whether `leaf_index` is inside the window `(start, width)` of a `leaf_count`-leaf inventory.
pub fn palw_readiness_window_contains_v1(start: u32, width: u32, leaf_count: u32, leaf_index: u32) -> bool {
    if leaf_count == 0 || width == 0 || leaf_index >= leaf_count {
        return false;
    }
    let offset = (leaf_index as u64 + leaf_count as u64 - start as u64) % leaf_count as u64;
    offset < width as u64
}

/// **What a seat signs** to prove readiness: the network, its bond, the class, the span and the
/// leaf it opened — so a relayer cannot volunteer another bond's collateral for a class.
pub fn palw_seat_readiness_message_v1(network_domain: Hash64, bond: &[u8], class_id: &Hash64, span: u64, leaf_index: u32) -> Hash64 {
    let mut state = keyed64(PALW_SEAT_READINESS_V1_DOMAIN);
    state.update(network_domain.as_byte_slice());
    state.update(&(bond.len() as u64).to_le_bytes());
    state.update(bond);
    state.update(class_id.as_byte_slice());
    state.update(&span.to_le_bytes());
    state.update(&leaf_index.to_le_bytes());
    finish64(state)
}

/// ADR-0135 manifest V2: the domain of the registrant's byte-count commitment.
pub const PALW_CLASS_MANIFEST_V2_DOMAIN: &[u8] = b"misaka-palw/class-manifest-v2/message/v1";
/// ADR-0135 manifest V2: the ML-DSA-87 context the registrant signs the commitment under.
pub const PALW_CLASS_MANIFEST_V2_MLDSA87_CONTEXT: &[u8] = b"misaka-palw/class-manifest-v2/mldsa87/v1";

/// **ADR-0135 manifest V2: what the registrant signs when it commits the artifact's byte count.**
/// The network domain, the registrant bond, the class and the count — nothing else, so a
/// signature is good for exactly one (class, count) on one chain, and a re-measured file is a new
/// signature rather than a replay.
pub fn palw_class_manifest_message_v2(network_domain: Hash64, bond: &[u8], class_id: &Hash64, artifact_bytes: u64) -> Hash64 {
    let mut state = keyed64(PALW_CLASS_MANIFEST_V2_DOMAIN);
    state.update(network_domain.as_byte_slice());
    state.update(&(bond.len() as u64).to_le_bytes());
    state.update(bond);
    state.update(class_id.as_byte_slice());
    state.update(&artifact_bytes.to_le_bytes());
    finish64(state)
}

/// **The shares the registry writes** (ADR-0135 Decision 5): each class's admission over every
/// class's, in permille, with the base class holding the remainder and never less than its floor.
/// A class with zero admission holds zero; the table always sums to 1,000.
pub fn palw_registry_shares_v1(
    admissions_milli: &[(Hash64, u64)],
    base_class: Hash64,
    base_floor_permille: u16,
) -> BTreeMap<Hash64, u16> {
    let floor = base_floor_permille.min(1_000) as u32;
    let room = 1_000u32 - floor;
    let others: Vec<(Hash64, u64)> = admissions_milli.iter().copied().filter(|(id, _)| *id != base_class).collect();
    let total: u128 = others.iter().map(|(_, a)| *a as u128).sum();
    let mut out = BTreeMap::new();
    let mut given = 0u32;
    for (id, a) in &others {
        let share = if total == 0 { 0 } else { ((*a as u128).saturating_mul(room as u128) / total).min(room as u128) as u32 };
        // A class that admits anything holds at least one permille: a target exists only for a share.
        let share = if *a > 0 && room > 0 { share.max(1) } else { share };
        given = given.saturating_add(share);
        out.insert(*id, share as u16);
    }
    out.insert(base_class, (1_000u32.saturating_sub(given)).max(floor) as u16);
    out
}

/// **What op 186 answers**: the registry as the tip state holds it.
#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct PalwModelRegistryReadV1 {
    /// ADR-0137 (shadow): the work target and the panel's replay budget, where the shadow folds.
    pub work_target: Option<PalwWorkTargetReadV1>,
    pub tip_daa: u64,
    /// The fence's height, if scheduled, and whether it is in force at the tip.
    pub fence_daa: Option<u64>,
    pub active: bool,
    /// The registry governs from here (the fence plus one readiness age); before it rows open and
    /// proofs are taken but nothing is stepped or judged by evidence.
    pub grace_until_daa: u64,
    pub span_daa: u64,
    pub globals: Option<PalwRegistryGlobalsV1>,
    /// **The readiness age the registry judges a row by now, in DAA** — the one rule
    /// ([`palw_readiness_max_age_daa_v1`]): readiness V2's horizon past its fence (eight spans;
    /// twenty-four on testnet-12), the globals' thirty before it; 0 without a registry fold. A seat's proof `expires` this long after it was
    /// dated, and what a reader prints as "the readiness age" is this, not the globals' V1 number.
    pub readiness_max_age_daa: u64,
    pub classes: Vec<PalwModelRegistryClassReadV1>,
    pub readiness: Vec<PalwSeatReadinessReadV1>,
    /// **Lane MU (ADR-0173): the possession rows of the roots a class holds besides its registered one** — empty below the fence.
    pub root_readiness: Vec<PalwSeatRootReadinessReadV1>,
    pub bonds: Vec<PalwRegistryBondReadV1>,
    /// Rowed classes by state: (active, active_limited, probation, prefetching, registered, held).
    pub counts: [u32; 6],
    /// **Whether the fold judges a claim by `panel_room` at the tip** (ADR-0137 D5: the work target
    /// in force and the registry past its grace) — otherwise by `max_inflight_claims`. A producer's
    /// pre-check must ask the question the gate asks (2026-09-24 DoS audit review of #11).
    pub panel_room_enforced: bool,
    /// Whether `inflight_now` and `panel_room` count free-prompt claims in flight, as the class gate
    /// does past `palw_audit_2026_09_23` ([`crate::palw_state_v2::palw_inflight_claims_counted_v1`]).
    pub free_prompts_counted: bool,
}

/// Why a row is where it is, from its last boundary's reading.
pub fn palw_lifecycle_reason_v1(row: &PalwModelLifecycleRowV1, is_base_class: bool, g: &PalwRegistryGlobalsV1) -> String {
    palw_lifecycle_reason_v2(row, is_base_class, g, true, None)
}

/// [`palw_lifecycle_reason_v1`] under the rule in force: `utilization_gates` is `false` past
/// `palw_audit_2026_09_23` (2026-09-24 audit #4), where utilization no longer holds a class, so
/// a `Held` row with its seats is held for its window or its readiness — never "overloaded" by
/// a utilization reading, which past the fence only the room check acts on. `window_fits` is the
/// class's verification window against its receipt deadline, where the reader can ask it.
pub fn palw_lifecycle_reason_v2(
    row: &PalwModelLifecycleRowV1,
    is_base_class: bool,
    g: &PalwRegistryGlobalsV1,
    utilization_gates: bool,
    window_fits: Option<bool>,
) -> String {
    if is_base_class {
        return "base class: always active, never gated".to_string();
    }
    let seats = g.seat_count as u32;
    match row.state {
        PalwModelLifecycleV1::Candidate => {
            "candidate: registered, and not admitted — no seat outside the registrant's own identity has proved it is ready to \
             verify this class"
                .to_string()
        }
        PalwModelLifecycleV1::Registered => "no work derived from the graph (the kernel support boundary): never admits".to_string(),
        PalwModelLifecycleV1::Prefetching => {
            format!("ready {} < {} required (seats prove possession to be counted)", row.ready_seats, row.profile.required_ready_seats)
        }
        PalwModelLifecycleV1::Probation { probes_passed } => {
            format!("probing: {probes_passed}/{} finals passed, {} failed since entry", g.probation_claims, row.probes_failed)
        }
        PalwModelLifecycleV1::ActiveLimited { stable_epochs } => {
            if stable_epochs >= g.stable_epochs {
                format!(
                    "at a tenth: cap-saturated ({} ‰ of the escrow at the rate; not activatable above the ceiling)",
                    row.cap_utilization_permille
                )
            } else {
                format!("stable {stable_epochs}/{} spans at a tenth", g.stable_epochs)
            }
        }
        PalwModelLifecycleV1::Active => "admitting in full".to_string(),
        PalwModelLifecycleV1::Capped { since_daa } => format!(
            "capped since DAA {since_daa}: producing under the mesh at {} ‰ of its admission with provisional rewards, until {} holders \
             are seated and re-verify every capped claim",
            crate::palw_mesh_v1::PALW_CAPPED_ADMISSION_PERMILLE_V1,
            row.profile.required_ready_seats
        ),
        PalwModelLifecycleV1::Held => {
            if row.ready_seats < seats {
                // **The number the DECISION used, said to be that** (audit 2026-09-19). The row's
                // `ready_seats` is what the rule read when it held the class; the readout beside
                // this line reports `readySeatsNow`, recomputed. Both are honest and they disagree
                // the moment seats come back, so an operator reading "ready 0" next to "8" cannot
                // tell whether the class is stuck or recovering. Naming the reading is the whole
                // fix; this repository already has the rule that a status must carry its provenance.
                format!(
                    "held: {} seats were ready when it was held, {seats} are needed for a panel (recovers through probation once \
                     {} are ready — compare readySeatsNow for what is ready right now)",
                    row.ready_seats, row.profile.required_ready_seats
                )
            } else if utilization_gates {
                format!("held: overloaded ({} ‰ utilization at {} in flight)", row.utilization_permille, row.inflight_claims)
            } else {
                // Past the fence a class holding its panel seats is held for its window, its
                // readiness, or both — each named when the reader can tell, never a utilization.
                let short = row.ready_seats < row.profile.required_ready_seats;
                let window = || {
                    format!(
                        "its verification window ({} spans) does not fit the receipt deadline — replay would outrun every claim it \
                         admitted",
                        row.profile.verification_window_spans
                    )
                };
                let seats = || {
                    format!(
                        "{} seats were ready, {} are required to re-enter probation (compare readySeatsNow)",
                        row.ready_seats, row.profile.required_ready_seats
                    )
                };
                match (window_fits, short) {
                    (Some(false), true) => format!("held: {}; and {}", window(), seats()),
                    (Some(false), false) => format!("held: {}", window()),
                    (_, true) => format!("held: {}", seats()),
                    (Some(true), false) => "held: seats and window are back; it re-enters probation at the next boundary".to_string(),
                    (None, false) => format!("held: {} (or its readiness lapsed at the boundary)", window()),
                }
            }
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwModelRegistryClassReadV1 {
    /// ADR-0137 (shadow): the class's economic compute a claim (its CCU), `CCU / W` in permille,
    /// the expected forwards a win (Q32), the ticket the work target would set beside the class
    /// target the shipped rule sets, the panel room in this class's claims, and the reader's share
    /// of finalized work over ten and a hundred epochs.
    pub economic_ccu_per_claim: u128,
    pub work_ratio_permille: u32,
    pub expected_forwards_q32: u128,
    pub work_ticket_target: u128,
    pub class_target: u128,
    pub panel_room: u64,
    pub final_work_share_10_permille: u16,
    pub final_work_share_100_permille: u16,
    pub class_id: Hash64,
    pub artifact_root: Hash64,
    /// **Lane MU (ADR-0173, `palw_audit_1004_v1`): the roots the class has in force NOW** (registered root, line versions in force,
    /// previews, superseded roots inside their grace) — empty below the fence, where possession is per class. A seat proves
    /// possession of each root it holds.
    pub roots_in_force: Vec<Hash64>,
    pub is_base_class: bool,
    pub row: Option<PalwModelLifecycleRowV1>,
    /// Ready seats and claims in flight read NOW (the row keeps the last boundary's reading).
    pub ready_seats_now: u32,
    /// **RFC-0002 Part II Proposal A: the class's seating NOW** (executor-less: nothing excluded), `None` below
    /// `palw_class_seating`, for the base class and for a registry that is not in force — what the RPC's `blocking`
    /// (`INDEPENDENT_OPERATORS`, `have / need`) and the class's licensable share are served from.
    pub seating: Option<crate::palw_state_v2::PalwClassSeatingV1>,
    pub inflight_now: u32,
    pub share_permille: Option<u16>,
    /// Claims of the class voided as `NoCapablePanel` (the capacity's failure, counted).
    pub no_capable_panel_voids: u32,
    /// Why the row is where it is, from its last reading: `ready {n} < {seats} for a panel`,
    /// `overloaded`, `ready {n} < {required} required`, `probing {passed}/{needed}`, `stable
    /// {n}/{needed}`, `admitting`, `base class`, `no work (kernel support boundary)` — for an operator to tell
    /// a HELD by the rule from a HELD by a fault.
    pub reason: String,
}

/// A bond as the registry sees it now: whether it could count as a ready seat if it held a fresh
/// proof — the seat's own pre-check before it spends a fee on one.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwRegistryBondReadV1 {
    pub bond: crate::palw_state_v2::PalwBondKeyV2,
    pub active: bool,
    pub above_floor: bool,
    pub free_collateral_sompi: u128,
    pub needed_collateral_sompi: u128,
}

/// **Lane MU (ADR-0173): a seat's possession row of one non-founding root.**
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwSeatRootReadinessReadV1 {
    pub bond: crate::palw_state_v2::PalwBondKeyV2,
    pub class_id: Hash64,
    pub root: Hash64,
    pub row: PalwSeatReadinessRowV1,
    pub fresh: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwSeatReadinessReadV1 {
    pub bond: crate::palw_state_v2::PalwBondKeyV2,
    pub class_id: Hash64,
    pub row: PalwSeatReadinessRowV1,
    pub fresh: bool,
    /// Why the seat does not count as ready now, if it does not: `stale`, `bond inactive`,
    /// `below floor`, `collateral short` — and, past lane maturity's fence, `immature`
    /// ([`PALW_SEAT_NOT_READY_IMMATURE_V1`]); empty while it counts.
    pub not_ready_reason: String,
}

/// **Lane maturity-ext (post-launch, 2026-09-26): the not-ready reason of a bond ADR-0065 D1 does not
/// count yet** — past `Params::palw_bond_maturity_early`, registered after
/// [`PalwBondMaturityFoldV1::registered_by_daa`] at the evaluating DAA. The panel view maps it to
/// `BOND_IMMATURE`.
pub const PALW_SEAT_NOT_READY_IMMATURE_V1: &str = "immature";

/// Why a seat with a proof does not count as ready for a class now, or `None` while it does —
/// under the fold's own freshness rule ([`PalwModelRegistryFoldV1::readiness_v2_active`]).
pub fn palw_seat_not_ready_reason_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    bond_key: &crate::palw_state_v2::PalwBondKeyV2,
    row: &PalwSeatReadinessRowV1,
    now_daa: u64,
    fold: &PalwModelRegistryFoldV1,
) -> Option<&'static str> {
    palw_seat_not_ready_reason_under_v1(state, params, bond_key, row, now_daa, fold, fold.readiness_v2_active)
}

/// **The registry's five-clause ready predicate, spelled once** (ADR-0135 Decision 4): active,
/// above the floor, a FRESH possession proof ([`palw_readiness_row_is_fresh_v1`] under
/// `readiness_v2`), and free collateral for the readiness multiple of the network's floor. `None`
/// is ready; otherwise the first clause that fails. The fold's `model_registry_seat_is_ready` (the
/// ready-seat count and ADR-0147's jury) is `row present && this is None`, with `readiness_v2` from
/// its extras; the RPC's `readySeatsNow` and each seat's reason are this with the fold's copy — so
/// the chain and the RPC cannot count two different numbers of ready seats again.
///
/// Past lane maturity's fence (`PalwModelRegistryFoldV1::bond_maturity`, 2026-09-26) a sixth clause
/// sits after the floor: the bond is mature by ADR-0065 D1 at `now_daa` (`immature` otherwise). It
/// rides the fold, so every reader above asks it without a new argument.
pub fn palw_seat_not_ready_reason_under_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    bond_key: &crate::palw_state_v2::PalwBondKeyV2,
    row: &PalwSeatReadinessRowV1,
    now_daa: u64,
    fold: &PalwModelRegistryFoldV1,
    readiness_v2: bool,
) -> Option<&'static str> {
    palw_seat_not_ready_reason_net_v1(state, params, bond_key, row, now_daa, fold, readiness_v2, params.bond_collateral_is_net_v1())
}

/// [`palw_seat_not_ready_reason_under_v1`] with the free-collateral arithmetic's fence spelled out
/// (`palw_bond_free_collateral_v1`, review of the 2026-09-24 DoS audit #12): the fold passes its
/// block's `audit_2026_09_23_active`, a view the bundle's copy of the same fence
/// ([`crate::palw_state_v2::PalwStateParamsV2::bond_collateral_is_net_v1`]).
#[allow(clippy::too_many_arguments)]
pub fn palw_seat_not_ready_reason_net_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    bond_key: &crate::palw_state_v2::PalwBondKeyV2,
    row: &PalwSeatReadinessRowV1,
    now_daa: u64,
    fold: &PalwModelRegistryFoldV1,
    readiness_v2: bool,
    collateral_is_net: bool,
) -> Option<&'static str> {
    let floor = params.min_collateral_sompi();
    let needed = (floor as u128).saturating_mul(fold.globals.readiness_collateral_multiple as u128);
    let Some(bond) = state.bond(bond_key) else { return Some("bond missing") };
    if !matches!(bond.status, crate::palw_state_v2::PalwBondStatusV2::Active) {
        return Some("bond inactive");
    }
    if !crate::palw_state_v2::palw_bond_may_take_work_v2(bond, floor) {
        return Some("below floor");
    }
    // Lane maturity-ext (post-launch, 2026-09-26): past `palw_bond_maturity_early` a bond the draw
    // may not seat yet is not a ready seat either — ADR-0065 D1 at the evaluating DAA. `None` below
    // the fence and on every shipped preset: the clause is not asked.
    if let Some(maturity) = fold.bond_maturity
        && !maturity.admits(state, params.window_court(), bond, now_daa)
    {
        return Some(PALW_SEAT_NOT_READY_IMMATURE_V1);
    }
    if !palw_readiness_row_is_fresh_v1(row, now_daa, fold.span_daa, &fold.globals, readiness_v2) {
        return Some("stale");
    }
    let held = state.reserved_exposure(bond_key).saturating_add(state.registration_exposure(bond_key));
    // The fold's arithmetic, fence and all (`palw_bond_free_collateral_v1`, review of #12).
    let free = crate::palw_state_v2::palw_bond_free_collateral_v1(bond, held, collateral_is_net);
    if free < needed {
        return Some("collateral short");
    }
    None
}

// ---------------------------------------------------------------------------------------------
// RFC-0004 §6.3/§6.7 (spec 17 §17.7.1): the readiness of a composite class
// ---------------------------------------------------------------------------------------------

/// **Why a seat that holds a composite's adapter is not ready for the composite**: it is not ready for the
/// parent the composite rests on, or for one of that parent's own ancestors (spec 17 §17.7.1). A seat that
/// executes a composite holds the parent's artifact AND the adapter section (RFC-0004 §6.7: it fetches only
/// the adapter), so a readiness row for the adapter alone is no evidence it can replay.
pub const PALW_SEAT_NOT_READY_PARENT_V1: &str = "parent not ready";

/// The longest chain of composite classes a seat's readiness follows (a composite over a composite over …).
/// A class whose ancestry is longer is one no seat is ready for: the walk is bounded, so the predicate is.
pub const PALW_COMPOSITE_READINESS_MAX_DEPTH_V1: usize = 8;

/// **The classes a seat must also be ready for before it is ready for `class_id`**, nearest first: the
/// parent of a composite class, and — when that parent is itself a composite — its parent, and so on.
/// Empty for every class without a composite record, which is every class on a chain that accepted no
/// composite candidate (the record is written only past `palw_improvement_v1`). `None` when the chain of
/// composites is deeper than [`PALW_COMPOSITE_READINESS_MAX_DEPTH_V1`].
pub fn palw_composite_ancestry_v1(state: &crate::palw_state_v2::PalwChainStateV2, class_id: &Hash64) -> Option<Vec<Hash64>> {
    let mut chain = Vec::new();
    let mut class = *class_id;
    while let Some(record) = state.improvement_composite_class(&class) {
        if chain.len() >= PALW_COMPOSITE_READINESS_MAX_DEPTH_V1 {
            return None;
        }
        chain.push(record.parent_class);
        class = record.parent_class;
    }
    Some(chain)
}

/// **[`palw_seat_not_ready_reason_net_v1`] for one class**: the five clauses over the seat's row for the class,
/// and — for a composite class (past `palw_improvement_v1`) — the parent clause: the seat's own row for every
/// ancestor of the class must pass the same five clauses ([`PALW_SEAT_NOT_READY_PARENT_V1`] otherwise). The
/// ONE readiness predicate: the fold's ready-seat count and the Candidate jury, the registry read, and the
/// ready count of the panel room ask it. Identical to the class-blind predicate for every class without a
/// composite record.
#[allow(clippy::too_many_arguments)]
pub fn palw_seat_class_not_ready_reason_net_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    bond_key: &crate::palw_state_v2::PalwBondKeyV2,
    class_id: &Hash64,
    row: &PalwSeatReadinessRowV1,
    now_daa: u64,
    fold: &PalwModelRegistryFoldV1,
    readiness_v2: bool,
    collateral_is_net: bool,
) -> Option<&'static str> {
    let own = palw_seat_not_ready_reason_net_v1(state, params, bond_key, row, now_daa, fold, readiness_v2, collateral_is_net);
    if own.is_some() || !params.improve_active_at(now_daa) {
        return own;
    }
    let Some(ancestry) = palw_composite_ancestry_v1(state, class_id) else { return Some(PALW_SEAT_NOT_READY_PARENT_V1) };
    for ancestor in ancestry {
        let ready = state.seat_readiness(bond_key, &ancestor).is_some_and(|parent_row| {
            palw_seat_not_ready_reason_net_v1(state, params, bond_key, parent_row, now_daa, fold, readiness_v2, collateral_is_net)
                .is_none()
        });
        if !ready {
            return Some(PALW_SEAT_NOT_READY_PARENT_V1);
        }
    }
    None
}

/// [`palw_seat_class_not_ready_reason_net_v1`] under the fold's own freshness rule and the ruleset's
/// collateral arithmetic — [`palw_seat_not_ready_reason_v1`] for one class.
pub fn palw_seat_class_not_ready_reason_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    bond_key: &crate::palw_state_v2::PalwBondKeyV2,
    class_id: &Hash64,
    row: &PalwSeatReadinessRowV1,
    now_daa: u64,
    fold: &PalwModelRegistryFoldV1,
) -> Option<&'static str> {
    palw_seat_class_not_ready_reason_net_v1(
        state,
        params,
        bond_key,
        class_id,
        row,
        now_daa,
        fold,
        fold.readiness_v2_active,
        params.bond_collateral_is_net_v1(),
    )
}

/// The seats ready for a class now (ADR-0135 Decision 4), as the fold counts them — through the
/// one predicate ([`palw_seat_not_ready_reason_under_v1`]) under the fold's freshness rule. It
/// used the thirty-span V1 age and took V1 rows past readiness V2, so on testnet-12 the RPC's
/// `readySeatsNow` counted seats the registry did not.
pub fn palw_model_registry_ready_seats_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    class_id: &Hash64,
    now_daa: u64,
    fold: &PalwModelRegistryFoldV1,
) -> u32 {
    let mut ready = 0u32;
    for (bond_key, _) in state.bonds_iter() {
        let Some(row) = state.seat_readiness_class_v1(params, bond_key, class_id, now_daa) else { continue };
        if palw_seat_class_not_ready_reason_v1(state, params, bond_key, class_id, row, now_daa, fold).is_none() {
            ready = ready.saturating_add(1);
        }
    }
    ready
}

/// **ADR-0152 SW-9: op 186's ready count for a class's panel room** — the bonds
/// [`palw_model_registry_ready_seats_v1`] counts, handed to
/// [`crate::palw_state_v2::palw_panel_room_ready_count_v1`]: their number below `palw_rcore_plus`
/// (and for a C7 class past it, or a class without a row), `ready_eff` over their operators' capped
/// weights past it — the one decision the fold's `panel_rate_v1` / `panel_room_v1` read, so op 186's
/// `panel_room` and the fold's gate agree (T91). `ready_seats_now` stays the bond count.
pub fn palw_model_registry_room_ready_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    class_id: &Hash64,
    now_daa: u64,
    fold: &PalwModelRegistryFoldV1,
) -> u32 {
    let ready = state
        .bonds_iter()
        .filter(|(bond_key, _)| {
            state.seat_readiness_class_v1(params, bond_key, class_id, now_daa).is_some_and(|row| {
                palw_seat_class_not_ready_reason_v1(state, params, bond_key, class_id, row, now_daa, fold).is_none()
            })
        })
        .map(|(_, bond)| bond);
    match state.model_lifecycle(class_id) {
        Some(row) => crate::palw_state_v2::palw_panel_room_ready_count_v1(params, row, now_daa, fold.globals.seat_count as u64, ready),
        None => ready.count().min(u32::MAX as usize) as u32,
    }
}

/// [`palw_model_registry_inflight_v1`], and past `palw_audit_2026_09_23` (`count_free_prompts`)
/// the class's free-prompt claims in flight too, in whole jobs of their quanta — the count the
/// fold's class gate reads ([`crate::palw_state_v2::palw_inflight_claims_counted_v1`]).
pub fn palw_model_registry_inflight_v2(
    state: &crate::palw_state_v2::PalwChainStateV2,
    class_id: &Hash64,
    count_free_prompts: bool,
    quanta_per_job: u32,
) -> u32 {
    let (mut attempts, mut fp_claims, mut fp_quanta) = (0u64, 0u64, 0u64);
    for (_, claim) in state.claims_iter() {
        if claim.class_id != *class_id || claim.phase.is_terminal() {
            continue;
        }
        match &claim.source {
            crate::palw_state_v2::PalwClaimSourceV2::Attempt => attempts = attempts.saturating_add(1),
            crate::palw_state_v2::PalwClaimSourceV2::FreePrompt { quanta, .. } => {
                fp_claims = fp_claims.saturating_add(1);
                fp_quanta = fp_quanta.saturating_add(*quanta as u64);
            }
        }
    }
    crate::palw_state_v2::palw_inflight_claims_counted_v1(attempts, fp_claims, fp_quanta, quanta_per_job as u64, count_free_prompts)
}

/// Attempt claims of a class still in flight (accepted and not terminal).
pub fn palw_model_registry_inflight_v1(state: &crate::palw_state_v2::PalwChainStateV2, class_id: &Hash64) -> u32 {
    state
        .claims_iter()
        .filter(|(_, claim)| {
            claim.class_id == *class_id
                && matches!(claim.source, crate::palw_state_v2::PalwClaimSourceV2::Attempt)
                && !claim.phase.is_terminal()
        })
        .count()
        .min(u32::MAX as usize) as u32
}

/// The registry read of a tip state.
/// ADR-0137 (shadow): what op 186 prints of the work target — the state's shadow row, the rate it
/// was floored with, the panel's in-flight replay and the budget's horizon.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwWorkTargetReadV1 {
    pub target: crate::palw_work_target_v1::PalwWorkTargetV2,
    pub rate_sompi_per_giga: u64,
    pub panel_inflight_replay: u128,
    pub panel_horizon_spans: u64,
    pub final_work_epochs: u64,
}

pub fn palw_model_registry_read_v1(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    tip_daa: u64,
    fence_daa: Option<u64>,
    fold: Option<&PalwModelRegistryFoldV1>,
    work: Option<&crate::palw_work_target_v1::PalwWorkTargetFoldV1>,
) -> PalwModelRegistryReadV1 {
    palw_model_registry_read_v2(state, params, tip_daa, fence_daa, fold, work, false, false)
}

/// [`palw_model_registry_read_v1`] asking the gate's questions (2026-09-24 DoS audit review of
/// #11): `count_free_prompts` past `palw_audit_2026_09_23` (the in-flight count and the panel's
/// replay then include free-prompt claims as the fold's gate counts them), and
/// `panel_room_enforced` where the fold judges by room rather than by the inflight cap. With both
/// `false` this is v1.
#[allow(clippy::too_many_arguments)]
pub fn palw_model_registry_read_v2(
    state: &crate::palw_state_v2::PalwChainStateV2,
    params: &crate::palw_state_v2::PalwStateParamsV2,
    tip_daa: u64,
    fence_daa: Option<u64>,
    fold: Option<&PalwModelRegistryFoldV1>,
    work: Option<&crate::palw_work_target_v1::PalwWorkTargetFoldV1>,
    count_free_prompts: bool,
    panel_room_enforced: bool,
) -> PalwModelRegistryReadV1 {
    use crate::palw_work_target_v1 as wt;
    let per_job = params.fp_quanta_per_canonical_job();
    let inflight_of = |class_id: &Hash64| -> u32 {
        if count_free_prompts {
            palw_model_registry_inflight_v2(state, class_id, true, per_job)
        } else {
            palw_model_registry_inflight_v1(state, class_id)
        }
    };
    let base = params.base_class_id();
    // ADR-0137 (shadow): every class's CCU (the fold's works, else its row's), the network-wide
    // in-flight replay, the budget's common horizon (the shortest admitted window) and the
    // reader's shares — computed once, read per class below.
    let shadow = state.work_target_shadow().copied();
    let g = fold.map(|f| f.globals).unwrap_or(PALW_REGISTRY_GLOBALS_V1);
    let ccu_of = |class_id: &Hash64| -> u128 {
        work.and_then(|w| w.works.get(class_id))
            .map(|w| w.economic_ccu_per_claim)
            .or_else(|| state.model_lifecycle(class_id).map(|row| row.work.economic_ccu_per_claim))
            .unwrap_or(0)
    };
    let seat_count = g.seat_count as u128;
    let panel_inflight_replay: u128 = state
        .classes_iter()
        .filter(|(id, _)| **id != base)
        .map(|(id, _)| (inflight_of(id) as u128).saturating_mul(ccu_of(id)).saturating_mul(seat_count))
        .fold(0u128, u128::saturating_add);
    let panel_horizon_spans = state
        .model_lifecycles_iter()
        .filter(|(id, row)| **id != base && row.state.admission_permille() > 0)
        .map(|(_, row)| row.profile.verification_window_spans as u64)
        .min()
        .unwrap_or(1)
        .max(1);
    // **2026-09-24 audit #4: past `palw_audit_2026_09_23` (`count_free_prompts`) the room is a
    // rate** — the fold's own demand ([`crate::palw_state_v2::palw_panel_demand_scaled_read_v1`]),
    // each class over its own window. The network readout is then the demand A SPAN over a horizon
    // of one span, so `panel_inflight_replay / (per_span × panel_horizon_spans)` stays the
    // utilization it always meant, and no class's window stands in for another's.
    let rate_rule = count_free_prompts;
    // ADR-0160 F-R: past `palw_capacity_verify_room` the fold prices the panel's replay at `k = 2`
    // and the measured speed; this read prices it the same way so op 186 shows the room the gate reads.
    let room_v2 = params.capacity_room_active_at(tip_daa);
    let pricing = crate::palw_verify_capacity_v1::palw_replay_pricing_v1(room_v2, &g);
    let (owed, terms) = if rate_rule {
        crate::palw_state_v2::palw_panel_demand_read_v1(state, params, pricing.replicas.min(u32::MAX as u128) as u32)
    } else {
        Default::default()
    };
    // Stage 1 (rcore/cap-s1): past F-R the fold holds the measured room under ρ × the shipped room
    // (`panel_rate_v1`'s clamp), so the readout reads the shipped demand beside it.
    let shipped_demand = (rate_rule && room_v2)
        .then(|| crate::palw_state_v2::palw_panel_demand_read_v1(state, params, u32::from(g.seat_count)));
    let rho = u128::from(crate::palw_weight_cap_v1::palw_capacity_rho_at_v1(params, tip_daa));
    let (panel_inflight_replay, panel_horizon_spans) = if rate_rule {
        (terms.values().copied().fold(0u128, u128::saturating_add).div_ceil(wt::PALW_PANEL_DEMAND_SCALE_V1), 1)
    } else {
        (panel_inflight_replay, panel_horizon_spans)
    };
    let shares_10 = state.final_work_shares_v1(10);
    let shares_100 = state.final_work_shares_v1(100);
    let share_of =
        |shares: &[(Hash64, u16)], class_id: &Hash64| shares.iter().find(|(id, _)| id == class_id).map(|(_, s)| *s).unwrap_or(0);
    let classes = state
        .classes_iter()
        .map(|(class_id, record)| PalwModelRegistryClassReadV1 {
            economic_ccu_per_claim: ccu_of(class_id),
            work_ratio_permille: shadow.map(|t| wt::palw_work_ratio_permille_v1(ccu_of(class_id), t.work)).unwrap_or(0),
            expected_forwards_q32: shadow.map(|t| wt::palw_expected_forwards_q32_v1(ccu_of(class_id), t.work)).unwrap_or(0),
            work_ticket_target: shadow.map(|t| wt::palw_work_ticket_target_v1(ccu_of(class_id), t.work)).unwrap_or(0),
            class_target: state.class_target(class_id).map(|t| t.target).unwrap_or(0),
            roots_in_force: if params.audit_1004_active_at(tip_daa) { state.class_roots_in_force(class_id, tip_daa) } else { Vec::new() },
            panel_room: if *class_id == base {
                0
            } else {
                // ADR-0152 SW-9: the fold's room count — `ready_eff` past `palw_rcore_plus` outside C7.
                let ready = fold.map(|f| palw_model_registry_room_ready_v1(state, params, class_id, tip_daa, f)).unwrap_or(0) as u128;
                let per_span = if room_v2 {
                    ready.saturating_mul(pricing.per_seat_per_span)
                } else {
                    ready.saturating_mul(g.reference_work_per_span).saturating_mul(g.utilization_permille.min(1_000) as u128) / 1_000
                };
                if rate_rule {
                    let room = crate::palw_state_v2::palw_panel_room_read_v1(
                        state,
                        params,
                        class_id,
                        per_span,
                        ccu_of(class_id).saturating_mul(if room_v2 { pricing.replicas } else { seat_count }),
                        &owed,
                        &terms,
                    );
                    match &shipped_demand {
                        Some((shipped_owed, shipped_terms)) => room.min(crate::palw_state_v2::palw_panel_room_read_v1(
                            state,
                            params,
                            class_id,
                            crate::palw_state_v2::palw_panel_shipped_per_span_v1(ready, &g).saturating_mul(rho),
                            ccu_of(class_id).saturating_mul(seat_count),
                            shipped_owed,
                            shipped_terms,
                        )),
                        None => room,
                    }
                } else {
                    wt::palw_panel_room_v1(
                        per_span,
                        panel_horizon_spans,
                        panel_inflight_replay,
                        ccu_of(class_id).saturating_mul(seat_count),
                    )
                }
            },
            final_work_share_10_permille: share_of(&shares_10, class_id),
            final_work_share_100_permille: share_of(&shares_100, class_id),
            class_id: *class_id,
            artifact_root: record.artifact_root,
            is_base_class: *class_id == base,
            row: state.model_lifecycle(class_id).cloned(),
            ready_seats_now: fold.map(|f| palw_model_registry_ready_seats_v1(state, params, class_id, tip_daa, f)).unwrap_or(0),
            seating: match (fold, params.class_seating_terms_at(tip_daa)) {
                (Some(f), Some(terms)) if *class_id != base => {
                    crate::palw_state_v2::palw_class_seating_v1(state, params, f, class_id, None, tip_daa, terms, true)
                }
                _ => None,
            },
            inflight_now: inflight_of(class_id),
            share_permille: state.class_share_permille(class_id),
            reason: match (state.model_lifecycle(class_id), fold) {
                (Some(row), Some(f)) => palw_lifecycle_reason_v2(
                    row,
                    *class_id == base,
                    &f.globals,
                    !rate_rule,
                    Some(
                        (row.profile.verification_window_spans as u64).saturating_mul(f.span_daa.max(1))
                            <= params.receipt_window_for_claim_v1(
                                state,
                                class_id,
                                crate::palw_class_verify_deadline_v1::PalwClaimVerifyShapeV1::Attempt,
                                tip_daa,
                            ),
                    ),
                ),
                (Some(_), None) => "the registry is not in force".to_string(),
                (None, _) => "no row (registered before the fence without a carriage): never gated".to_string(),
            },
            no_capable_panel_voids: state
                .claims_iter()
                .filter(|(_, c)| {
                    c.class_id == *class_id
                        && matches!(
                            c.phase,
                            crate::palw_state_v2::PalwClaimPhaseV2::Voided {
                                reason: crate::palw_state_v2::PalwVoidReasonV2::NoCapablePanel,
                                ..
                            }
                        )
                })
                .count()
                .min(u32::MAX as usize) as u32,
        })
        .collect();
    let readiness = state
        .seat_readiness_iter()
        .map(|((bond, class_id), row)| PalwSeatReadinessReadV1 {
            bond: *bond,
            class_id: *class_id,
            row: *row,
            fresh: fold.is_some_and(|f| f.readiness_row_is_fresh(row, tip_daa)),
            not_ready_reason: fold
                .and_then(|f| palw_seat_class_not_ready_reason_v1(state, params, bond, class_id, row, tip_daa, f))
                .unwrap_or("")
                .to_string(),
        })
        .collect();
    let root_readiness = if params.audit_1004_active_at(tip_daa) {
        state
            .seat_root_readiness_iter()
            .map(|((bond, class_id, root), row)| PalwSeatRootReadinessReadV1 {
                bond: *bond,
                class_id: *class_id,
                root: *root,
                row: *row,
                fresh: fold.is_some_and(|f| f.readiness_row_is_fresh(row, tip_daa)),
            })
            .collect()
    } else {
        Vec::new()
    };
    let bonds = fold
        .map(|f| {
            let floor = params.min_collateral_sompi();
            let needed = (floor as u128).saturating_mul(f.globals.readiness_collateral_multiple as u128);
            state
                .bonds_iter()
                .map(|(key, bond)| {
                    let held = state.reserved_exposure(key).saturating_add(state.registration_exposure(key));
                    PalwRegistryBondReadV1 {
                        bond: *key,
                        active: matches!(bond.status, crate::palw_state_v2::PalwBondStatusV2::Active),
                        above_floor: crate::palw_state_v2::palw_bond_may_take_work_v2(bond, floor),
                        free_collateral_sompi: crate::palw_state_v2::palw_bond_free_collateral_v1(
                            bond,
                            held,
                            params.bond_collateral_is_net_v1(),
                        ),
                        needed_collateral_sompi: needed,
                    }
                })
                .collect()
        })
        .unwrap_or_default();
    let mut counts = [0u32; 6];
    for (_, row) in state.model_lifecycles_iter() {
        let slot = match row.state {
            PalwModelLifecycleV1::Active => 0,
            PalwModelLifecycleV1::ActiveLimited { .. } => 1,
            PalwModelLifecycleV1::Probation { .. } => 2,
            PalwModelLifecycleV1::Prefetching => 3,
            PalwModelLifecycleV1::Registered => 4,
            PalwModelLifecycleV1::Held => 5,
            // **A `Candidate` is counted where an operator already looks for "on chain and
            // admitting nothing".** A seventh slot would widen `counts` and with it the RPC row
            // (`classes_registered` and its five siblings are named fields), which is a wire break
            // for a state that cannot exist below a dormant fence. The distinction an operator
            // needs is in the class's own reason line, which names independence by name.
            PalwModelLifecycleV1::Candidate => 4,
            // RFC-0007 Part IV.2: a `Capped` class is counted with the classes still gathering holders.
            PalwModelLifecycleV1::Capped { .. } => 3,
        };
        counts[slot] += 1;
    }
    PalwModelRegistryReadV1 {
        work_target: shadow.map(|target| PalwWorkTargetReadV1 {
            target,
            rate_sompi_per_giga: work.map(|w| w.rate_sompi_per_giga).unwrap_or(0),
            panel_inflight_replay,
            panel_horizon_spans,
            final_work_epochs: state.final_work_iter().count() as u64,
        }),
        tip_daa,
        fence_daa,
        active: fold.is_some(),
        grace_until_daa: fold.map(|f| f.grace_until_daa).unwrap_or(0),
        span_daa: fold.map(|f| f.span_daa).unwrap_or(0),
        globals: fold.map(|f| f.globals),
        readiness_max_age_daa: fold.map(|f| f.readiness_max_age_daa()).unwrap_or(0),
        classes,
        readiness,
        root_readiness,
        bonds,
        counts,
        panel_room_enforced,
        free_prompts_counted: count_free_prompts,
    }
}

/// **When a seat's node should submit a fresh possession proof** (the node's duty, ADR-0135 §7):
/// when the chain holds no proof of this bond for the class, or the one it holds is older than
/// half the readiness age (so a proof lands before the old one goes stale), and never twice in
/// one span. Pure, so the node's cadence is testable: a restart re-reads the chain's row and does
/// not re-send what is fresh.
/// **A class registered before the registry fence never gets a lifecycle row** (ADR-0135 with the
/// 2026-09-18 audit's C-1: the fold's works come from the chain and the build, never from a node's
/// own carriage store), so a node that would register a class on a chain whose registry fence is
/// scheduled but not yet in force must WAIT for the fence — the object it would send is a class
/// with a share and no row, which the work target then refuses for ever ("no row"). `true` while
/// the registration must wait.
pub fn palw_registration_waits_for_registry_v1(registry_fence: Option<crate::config::params::ForkActivation>, daa_score: u64) -> bool {
    registry_fence.is_some_and(|fence| fence != crate::config::params::ForkActivation::never() && !fence.is_active(daa_score))
}

/// **How many DAA a registration's carrier may take to land** — the window before the admission-
/// independence fence in which a node does not build one (see
/// [`palw_registration_waits_for_fences_v2`]). A carrier is accepted by the next chain block that
/// merges it; ten DAA is several blocks on every preset, and a carrier that lands later still is
/// caught by the panel's own retry, which rebuilds it on the terms then in force.
pub const PALW_REGISTRATION_LANDING_MARGIN_DAA_V1: u64 = 10;

/// [`palw_registration_waits_for_registry_v1`], and **the admission-independence fence too**
/// (ADR-0147 §2.4 at the entrance; the 2026-09-20 Studio economy drill).
///
/// Below `palw_admission_independence` a post-genesis registration must take the minimum grantable
/// share, past it exactly 0‰ — registration buys existence, cadence is earned — and the gate reads
/// the fence at the block that ACCEPTS the carrier. A registration built in the last blocks before
/// the fence therefore carries a share the fence refuses when the carrier lands past it. The drill
/// that armed the registry and the bundle at one height found exactly that: the node registered the
/// moment the registry opened, the object was dropped "registers at 1‰", and the panel's retry only
/// came 200 DAA later. So the node also waits while the independence fence is scheduled and the
/// chain is within [`PALW_REGISTRATION_LANDING_MARGIN_DAA_V1`] below it, and registers once the
/// fence is in force — when the terms say 0‰ and the gate agrees.
pub fn palw_registration_waits_for_fences_v2(
    registry_fence: Option<crate::config::params::ForkActivation>,
    independence_fence: Option<crate::config::params::ForkActivation>,
    daa_score: u64,
) -> bool {
    if palw_registration_waits_for_registry_v1(registry_fence, daa_score) {
        return true;
    }
    independence_fence.is_some_and(|fence| {
        fence != crate::config::params::ForkActivation::never()
            && !fence.is_active(daa_score)
            && daa_score.saturating_add(PALW_REGISTRATION_LANDING_MARGIN_DAA_V1) >= fence.daa_score()
    })
}

pub fn palw_readiness_duty_due_v1(
    row: Option<&PalwSeatReadinessRowV1>,
    now_daa: u64,
    span_now: u64,
    last_submitted_span: Option<u64>,
    span_daa: u64,
    g: &PalwRegistryGlobalsV1,
) -> bool {
    palw_readiness_duty_due_v2(row, now_daa, span_now, last_submitted_span, span_daa, g, false)
}

/// **ADR-0133 §11.2: the same question past readiness V2.** The chain stops counting a V1 row the
/// moment the fence bites and gives a V2 row its V2 horizon instead of thirty — so a seat that asked
/// the old question would sit on a fresh-looking V1 row while the registry counted it out, lose its
/// seat, and take the class's panel with it. Past the fence a V1 row is always due, and a V2 row is
/// due at half the V2 window — half of the globals' `readiness_v2_max_age_spans`, the same number the
/// registry judges the row by: past 4 DAA on eight-span networks, past 12 on testnet-12 (user
/// decision 2026-09-25, readiness capacity option (a)).
pub fn palw_readiness_duty_due_v2(
    row: Option<&PalwSeatReadinessRowV1>,
    now_daa: u64,
    span_now: u64,
    last_submitted_span: Option<u64>,
    span_daa: u64,
    g: &PalwRegistryGlobalsV1,
    readiness_v2: bool,
) -> bool {
    if last_submitted_span == Some(span_now) {
        return false;
    }
    let age_daa = palw_readiness_max_age_daa_v1(span_daa, g, readiness_v2);
    match row {
        None => true,
        Some(row) if readiness_v2 && row.proof_version < 2 => true, // a one-leaf row counts for nothing now
        Some(row) => now_daa.saturating_sub(row.proved_daa) > age_daa / 2,
    }
}

#[cfg(test)]
mod tests {

    #[test]
    fn a_registration_waits_for_a_scheduled_registry_fence_and_never_for_an_absent_one() {
        use crate::config::params::ForkActivation;
        assert!(!palw_registration_waits_for_registry_v1(None, 5), "no fence: nothing to wait for");
        assert!(!palw_registration_waits_for_registry_v1(Some(ForkActivation::never()), 5), "never: nothing to wait for");
        assert!(palw_registration_waits_for_registry_v1(Some(ForkActivation::new(20)), 19), "scheduled, not yet: wait");
        assert!(!palw_registration_waits_for_registry_v1(Some(ForkActivation::new(20)), 20), "in force: go");
        assert!(!palw_registration_waits_for_registry_v1(Some(ForkActivation::always()), 0), "always: go");
    }

    /// The Studio economy drill's finding: with the registry and the bundle at one height, the node
    /// registered the moment the registry opened, on the pre-independence share, and the carrier
    /// landed past the independence fence, which refused it. A registration is not built within a
    /// landing margin below the independence fence, and is built once the fence is in force.
    #[test]
    fn a_registration_is_not_built_where_its_carrier_could_land_on_the_other_side_of_independence() {
        use crate::config::params::ForkActivation;
        let registry = Some(ForkActivation::new(30));
        let independence = Some(ForkActivation::new(30));
        let margin = PALW_REGISTRATION_LANDING_MARGIN_DAA_V1;
        assert!(palw_registration_waits_for_fences_v2(registry, independence, 29), "the registry is not open yet");
        assert!(!palw_registration_waits_for_fences_v2(registry, independence, 30), "both in force: build on the 0 permille terms");
        // The registry open well before the bundle: register freely, until the margin before it.
        let registry = Some(ForkActivation::new(20));
        let independence = Some(ForkActivation::new(100));
        assert!(!palw_registration_waits_for_fences_v2(registry, independence, 25), "far from the fence: the carrier lands before it");
        assert!(!palw_registration_waits_for_fences_v2(registry, independence, 100 - margin - 1));
        assert!(palw_registration_waits_for_fences_v2(registry, independence, 100 - margin), "inside the landing margin: wait");
        assert!(palw_registration_waits_for_fences_v2(registry, independence, 99), "the last block before the fence: wait");
        assert!(!palw_registration_waits_for_fences_v2(registry, independence, 100), "the fence in force: build");
        // No independence fence scheduled: the registry is the only thing waited for.
        assert!(!palw_registration_waits_for_fences_v2(registry, None, 99));
        assert!(!palw_registration_waits_for_fences_v2(registry, Some(ForkActivation::never()), 99));
    }
    use super::*;
    use crate::palw_execution_lane_v1::{PalwExecFinalV1, palw_execution_schedule_snapshot_v1};
    use crate::palw_state_v2::PalwBondKeyV2;
    use crate::tx::{TransactionId, TransactionOutpoint};

    const G: PalwRegistryGlobalsV1 = PALW_REGISTRY_GLOBALS_V1;
    fn h(n: u64) -> Hash64 {
        Hash64::from_u64_word(n)
    }
    fn manifest(bytes: u64, prefill: u32) -> PalwModelManifestV1 {
        PalwModelManifestV1 {
            graph_ir_root: h(1),
            artifact_root: h(2),
            artifact_bytes: bytes,
            canonical_prefill_tokens: prefill,
            canonical_decode_tokens: 1,
            quantization_format: 1,
            runtime_version: 3,
        }
    }
    fn work(verification_ccu: u128, economic: u128, bytes: u64) -> PalwModelWorkV1 {
        PalwModelWorkV1 {
            verification_ccu,
            economic_ccu_per_claim: economic,
            artifact_bytes: bytes,
            working_set_bytes: bytes,
            ops_supported: true,
        }
    }
    /// The live classes as ADR-0131/0132 measured them, and a Kimi-class stand-in.
    fn dense() -> PalwModelWorkV1 {
        work(83_102_171_136, 166_204_342_272, 800 << 20)
    }
    fn hybrid() -> PalwModelWorkV1 {
        work(18_055_200_736, 36_110_401_472, 24 << 30)
    }
    fn kimi() -> PalwModelWorkV1 {
        work(1_000_000_000_000, 2_000_000_000_000, 300 << 30)
    }

    /// **The profile is a function of the manifest's work and the globals, and of nothing a human
    /// measured or a registrant stated.** Two nodes derive one profile; the dense tier is one span
    /// of verification (35 ms of the reference's 600 s) plus the receipt allowance, the hybrid the
    /// same, the Kimi stand-in `⌈2 × 1 T / 2.4 T⌉ = 1` + 1 spans of verification but two spans of
    /// prefetch for 300 GiB, seven ready seats, a bond of 2,000 MSK, and an admission of 8.3 claims
    /// a span under a budget of ten dense-tier claims' attempted compute.
    #[test]
    fn adr0133_a_class_whose_replay_does_not_fit_the_receipt_deadline_is_held_never_active() {
        // **§11.3, fail-closed.** The observation says the derived window is wider than the
        // network's receipt deadline: from every admitting state the class goes to Held, and Held
        // stays Held however ready its seats are, until the window fits again.
        use PalwModelLifecycleV1::*;
        let work = PalwModelWorkV1 {
            verification_ccu: 2_000_000_000_000,
            economic_ccu_per_claim: 1_000_000_000_000,
            ops_supported: true,
            ..Default::default()
        };
        let k = palw_lifecycle_profile_v1(&work, 1 << 32, &G, false);
        let obs = |fits: bool, state_ok: bool| PalwLifecycleObservationV1 {
            manifest: PalwManifestVerdictV1Flag::Valid,
            ready_seats: 7,
            independence_floor_met: true,
            probes_passed_this_span: 1,
            probes_failed_this_span: 0,
            utilization_permille: 300,
            collateral_ok: state_ok,
            cap_ok: true,
            window_fits_receipt: fits,
            span_stable: true,
            // ADR-0145 §7: the `Candidate` arm's only input, and this fixture starts past it.
            admission_jury_seated: false, capped_entry: false, };
        for from in [Probation { probes_passed: 9 }, ActiveLimited { stable_epochs: 9 }, Active] {
            assert_eq!(palw_lifecycle_step_v1(from, &obs(false, true), &k, &G), Held, "{from:?}: does not fit → Held");
        }
        assert_eq!(palw_lifecycle_step_v1(Held, &obs(false, true), &k, &G), Held, "Held stays Held while it does not fit");
        assert_eq!(
            palw_lifecycle_step_v1(Held, &obs(true, true), &k, &G),
            Probation { probes_passed: 0 },
            "…and re-enters Probation once it fits"
        );
        assert_eq!(palw_lifecycle_step_v1(Active, &obs(true, true), &k, &G), Active, "a fitting window changes nothing");
    }

    #[test]
    fn adr0135_the_profile_is_derived_from_work_alone() {
        let a = palw_derive_profile_v1(&dense(), &G, false);
        let b = palw_derive_profile_v1(&dense(), &G, false);
        assert_eq!(a, b, "deterministic");
        assert_eq!((a.verification_window_spans, a.artifact_prefetch_spans, a.required_ready_seats), (2, 1, 7));
        assert_eq!(a.registration_bond_sompi, 2 * 1_000 * 100_000_000);
        assert_eq!(a.admission_claims_per_span_milli, 10_000, "the budget is ten of its own claims a span");
        let k = palw_derive_profile_v1(&kimi(), &G, false);
        assert_eq!(k.verification_window_spans, 2, "2 × 1 T MAC-eq is under one reference span (2.4 T), plus the allowance");
        assert_eq!(k.artifact_prefetch_spans, 2, "2 × 300 GiB at 600 GB a span");
        assert_eq!(k.required_ready_seats, 7);
        assert!(k.max_inflight_claims < a.max_inflight_claims);
        assert_eq!(k.admission_claims_per_span_milli, 831, "the budget affords 0.83 Kimi claims a span: rare and dear");
        // A registrant's declaration changes nothing: the manifest carries no window and no rate,
        // and a heavier graph gets a wider window from the same code.
        let heavier = work(10_000_000_000_000, 20_000_000_000_000, 300 << 30);
        assert!(palw_derive_profile_v1(&heavier, &G, false).verification_window_spans > k.verification_window_spans);
        assert_eq!(
            palw_derive_profile_v1(&heavier, &G, false).verification_window_spans,
            9 + 1,
            "2 × 10 T over 2.4 T a span: nine, plus the allowance"
        );
        assert!(
            palw_derive_profile_v1(&heavier, &G, false).required_ready_seats > 7,
            "one such claim a span at 70 % needs more than seven seats"
        );
    }

    /// **The manifest is judged before it is a class, and unsupported kernels are one verdict.**
    #[test]
    fn adr0135_a_manifest_is_judged_and_kernel_support_is_a_verdict() {
        assert_eq!(palw_manifest_verdict_v1(&manifest(1, 7), &dense()), PalwManifestVerdictV1::Valid);
        let alien = PalwModelWorkV1 { ops_supported: false, ..dense() };
        assert_eq!(
            palw_manifest_verdict_v1(&manifest(1, 7), &alien),
            PalwManifestVerdictV1::UnsupportedOp,
            "an unsupported operation requires a kernel extension before registration"
        );
        assert_eq!(palw_manifest_verdict_v1(&manifest(0, 7), &dense()), PalwManifestVerdictV1::EmptyArtifact);
        assert_eq!(palw_manifest_verdict_v1(&manifest(1, 0), &dense()), PalwManifestVerdictV1::EmptyJob);
        assert_eq!(palw_manifest_verdict_v1(&manifest(1, 7), &work(0, 0, 1)), PalwManifestVerdictV1::ZeroWork);
    }

    /// **A possession proof owes the challenge a prefix, and the carrier decides how long it is**
    /// (the 2026-09-20 measurement: sixteen leaves of the shipped A16 class serialized to 184,037
    /// bytes against a 100,000-byte carrier, so four spans in eight proved nothing).
    ///
    /// The rule is decided from the proof alone, which is what makes stopping early and stopping
    /// late both refusals rather than preferences.
    #[test]
    fn a_possession_proof_opens_the_prefix_the_budget_buys() {
        let draw = [7u32, 3, 9, 1, 5];
        let budget = PALW_READINESS_V2_BUDGET_BYTES_V1;
        // Four leaves of a quarter-budget each: the fourth is the one that reaches it, so the
        // proof owes exactly four — the draw's first four, whatever order they are carried in.
        let quarter = budget / 4 + 1;
        let four: Vec<(u32, usize)> = vec![(1, quarter), (3, quarter), (7, quarter), (9, quarter)];
        palw_readiness_v2_opening_is_the_challenge_v1(&draw, &four).expect("the prefix that reaches the budget");

        // Three of them are under budget while the draw still names leaves: stopping there is a
        // seat proving less than it was asked for.
        let three: Vec<(u32, usize)> = vec![(3, quarter), (7, quarter), (9, quarter)];
        let why = palw_readiness_v2_opening_is_the_challenge_v1(&draw, &three).expect_err("under budget with leaves left");
        assert!(why.contains("under the"), "{why}");

        // Five of them: the fifth was not owed, and a proof that opens what it likes is a proof
        // that chooses its own challenge.
        let five: Vec<(u32, usize)> = vec![(1, quarter), (3, quarter), (5, quarter), (7, quarter), (9, quarter)];
        let why = palw_readiness_v2_opening_is_the_challenge_v1(&draw, &five).expect_err("one leaf too many");
        assert!(why.contains("did not owe"), "{why}");

        // The right NUMBER of leaves, from the wrong place in the draw.
        let wrong: Vec<(u32, usize)> = vec![(1, quarter), (3, quarter), (5, quarter), (7, quarter)];
        let why = palw_readiness_v2_opening_is_the_challenge_v1(&draw, &wrong).expect_err("not the draw's prefix");
        assert!(why.contains("challenge names"), "{why}");

        // One leaf big enough to reach the budget by itself ends the prefix at one.
        let one: Vec<(u32, usize)> = vec![(7, budget)];
        palw_readiness_v2_opening_is_the_challenge_v1(&draw, &one).expect("a leaf that fills the budget alone");

        // A draw that never reaches the budget is owed whole — the small-artifact case.
        let crumbs: Vec<(u32, usize)> = draw.iter().map(|leaf| (*leaf, 8usize)).collect();
        palw_readiness_v2_opening_is_the_challenge_v1(&draw, &crumbs).expect("the whole draw, under budget");
        let short: Vec<(u32, usize)> = crumbs[..4].to_vec();
        assert!(palw_readiness_v2_opening_is_the_challenge_v1(&draw, &short).is_err(), "four of five, under budget");

        // A row no carrier could take is refused by the leaf ceiling, not by the total.
        let huge: Vec<(u32, usize)> = vec![(7, PALW_READINESS_V2_LEAF_MAX_BYTES_V1 + 1)];
        let why = palw_readiness_v2_opening_is_the_challenge_v1(&draw, &huge).expect_err("a leaf above the ceiling");
        assert!(why.contains("can ride a proof"), "{why}");

        // Nothing opened proves nothing.
        assert!(palw_readiness_v2_opening_is_the_challenge_v1(&draw, &[]).is_err());
    }

    /// **The rule the fingerprint cannot see has a value of its own.** Change any ceiling and the
    /// tag moves; the network identity does not, which is exactly why the node prints it.
    #[test]
    fn the_possession_rule_has_a_tag_an_operator_can_compare() {
        let tag = palw_readiness_v2_rule_tag_v1();
        assert_eq!(tag, palw_readiness_v2_rule_tag_v1(), "the same build answers the same value");
        // The numbers it is made of are the ones a reader would have to compare by hand.
        let mut state = keyed64(b"misaka-palw/seat-readiness-v2/rule-tag/v1");
        for n in [
            PALW_READINESS_V2_CHUNKS_V1 as u64,
            PALW_READINESS_V2_BUDGET_BYTES_V1 as u64,
            PALW_READINESS_V2_LEAF_MAX_BYTES_V1 as u64,
            PALW_READINESS_V2_FRAME_BYTES_V1 as u64,
            PALW_READINESS_V2_OPERAND_MAX_BYTES_V1 as u64,
            PALW_READINESS_V2_LEGACY_FULL_CHALLENGE_OPERAND_MAX_BYTES_V1 as u64,
        ] {
            state.update(&n.to_le_bytes());
        }
        assert_eq!(tag, finish64(state));
    }

    /// **The ceilings are the carrier's, by arithmetic.** `1 << 20` was ten carriers and derived
    /// from nothing; these three add up to exactly what one transaction holds, and the draw's own
    /// order is what a prefix can be taken from.
    #[test]
    fn the_readiness_ceilings_are_derived_from_the_carrier() {
        assert_eq!(
            PALW_READINESS_V2_OPERAND_MAX_BYTES_V1 + PALW_READINESS_V2_FRAME_BYTES_V1,
            crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES,
            "the operands and the frame must be exactly one carrier"
        );
        assert_eq!(PALW_READINESS_V2_OPERAND_MAX_BYTES_V1, PALW_READINESS_V2_BUDGET_BYTES_V1 + PALW_READINESS_V2_LEAF_MAX_BYTES_V1);
        assert!(PALW_READINESS_V2_BUDGET_BYTES_V1 > 0, "a budget the frame and one leaf have eaten buys no possession at all");
        // The sorted set is the draw's own leaves and nothing else: the two readers see one
        // challenge, one in the order it was drawn and one in the order a proof carries it.
        let seed = Hash64::from_u64_word(0x5EED);
        let mut sorted = palw_readiness_v2_draw_v1(&seed, 10_000);
        sorted.sort_unstable();
        assert_eq!(sorted, palw_readiness_v2_leaves_v1(&seed, 10_000));
        assert_eq!(palw_readiness_v2_draw_v1(&seed, 10_000).len(), PALW_READINESS_V2_CHUNKS_V1 as usize);
    }

    /// **Readiness is evidence, not a declaration.** A seat that only says "I have it" is not
    /// ready; one with the root, the chunks, participation, collateral and a fresh probe is; the
    /// probe goes stale; the collateral must cover three exposures.
    #[test]
    fn adr0135_readiness_is_evidence_not_a_declaration() {
        let exposure = 5 * 6_630_544u128;
        let declared_only = PalwReadinessEvidenceV1 { artifact_root_matches: true, ..Default::default() };
        assert!(!declared_only.is_ready(exposure, 100, &G));
        let ready = PalwReadinessEvidenceV1 {
            artifact_root_matches: true,
            all_chunks_held: true,
            participation_ok: true,
            free_collateral_sompi: exposure * 3,
            last_probe_ok_span: Some(90),
        };
        assert!(ready.is_ready(exposure, 100, &G));
        assert!(
            !PalwReadinessEvidenceV1 { participation_ok: false, ..ready }.is_ready(exposure, 100, &G),
            "an IBD-held node is not a seat"
        );
        assert!(!PalwReadinessEvidenceV1 { free_collateral_sompi: exposure * 3 - 1, ..ready }.is_ready(exposure, 100, &G));
        assert!(!ready.is_ready(exposure, 90 + 31, &G), "a probe older than thirty spans has gone stale");
        assert!(
            !PalwReadinessEvidenceV1 { all_chunks_held: false, ..ready }.is_ready(exposure, 100, &G),
            "a partial artifact is not held"
        );
    }

    /// **The lifecycle walks on facts, and a held class stops only itself.** A registered class
    /// prefetches once its manifest is valid, enters probation when seven seats prove ready,
    /// activates limited after ten passed probes with none failed, activates after three stable
    /// epochs, and is held the span its panel cannot be drawn — while a second class in the same
    /// network, on its own facts, stays `Active`, and the lane schedules exactly the classes with a
    /// `Final`. Recovery returns through probation.
    #[test]
    fn adr0135_the_lifecycle_walks_on_facts_and_a_held_class_stops_only_itself() {
        use PalwModelLifecycleV1::*;
        let k = palw_derive_profile_v1(&kimi(), &G, false);
        let q = palw_derive_profile_v1(&dense(), &G, false);
        let calm = |ready: u32| PalwLifecycleObservationV1 {
            manifest: PalwManifestVerdictV1Flag::Valid,
            ready_seats: ready,
            independence_floor_met: true,
            probes_passed_this_span: 0,
            probes_failed_this_span: 0,
            utilization_permille: 300,
            collateral_ok: true,
            cap_ok: true,
            window_fits_receipt: true,
            span_stable: true,
            // Every fixture below this line walks a class that is already past `Candidate`, and
            // `admission_jury_seated` is read by that one arm: `false` here says so, and says that
            // nothing else in the lifecycle learned to read it.
            admission_jury_seated: false, capped_entry: false, };
        let mut s = Registered;
        s = palw_lifecycle_step_v1(s, &PalwLifecycleObservationV1 { manifest: PalwManifestVerdictV1Flag::Invalid, ..calm(0) }, &k, &G);
        assert_eq!(s, Registered, "an invalid manifest never leaves registration");
        s = palw_lifecycle_step_v1(s, &calm(0), &k, &G);
        assert_eq!(s, Prefetching);
        s = palw_lifecycle_step_v1(s, &calm(6), &k, &G);
        assert_eq!(s, Prefetching, "six ready seats are not the seven the profile needs");
        s = palw_lifecycle_step_v1(s, &calm(7), &k, &G);
        assert_eq!(s, Probation { probes_passed: 0 });
        assert!(
            !s.admits_claims() || s.admission_permille() == 50,
            "probation admits a twentieth: the claims that probe it must exist"
        );
        s = palw_lifecycle_step_v1(s, &PalwLifecycleObservationV1 { probes_passed_this_span: 4, ..calm(7) }, &k, &G);
        s = palw_lifecycle_step_v1(
            s,
            &PalwLifecycleObservationV1 { probes_passed_this_span: 4, probes_failed_this_span: 1, ..calm(7) },
            &k,
            &G,
        );
        assert_eq!(s, Probation { probes_passed: 0 }, "a failed probe restarts probation");
        for _ in 0..3 {
            s = palw_lifecycle_step_v1(s, &PalwLifecycleObservationV1 { probes_passed_this_span: 4, ..calm(7) }, &k, &G);
        }
        assert_eq!(s, ActiveLimited { stable_epochs: 0 });
        assert_eq!(s.admission_permille(), 100);
        for _ in 0..3 {
            s = palw_lifecycle_step_v1(s, &calm(7), &k, &G);
        }
        assert_eq!(s, Active);
        assert_eq!(s.admission_permille(), 1_000);
        // Two operators go: four ready seats cannot draw a panel of five — Kimi is held.
        let held = palw_lifecycle_step_v1(s, &calm(4), &k, &G);
        assert_eq!(held, Held);
        assert!(!held.admits_claims());
        // …and the dense tier, on its own facts, is untouched.
        let mut qs = Active;
        qs = palw_lifecycle_step_v1(qs, &calm(7), &q, &G);
        assert_eq!(qs, Active, "another class's outage is not this class's");
        // The lane: only the class with Finals holds permits.
        let finals = vec![PalwExecFinalV1 {
            domain: h(1),
            bond: PalwBondKeyV2(TransactionOutpoint::new(TransactionId::from_u64_word(1), 0)),
            operator_id: h(11),
            claim_id: h(100),
            execution_root: h(7),
            credit: 1,
            accepted_blue_score: 0,
        }];
        let snapshot = palw_execution_schedule_snapshot_v1(3, &finals);
        assert!(snapshot.domains.iter().any(|d| d.domain == h(1)) && snapshot.domains.iter().all(|d| d.domain != h(2)));
        // Recovery: seats return → probation again, never straight to Active.
        let back = palw_lifecycle_step_v1(held, &calm(7), &k, &G);
        assert_eq!(back, Probation { probes_passed: 0 });
        // Overload holds too, even with seats.
        assert_eq!(
            palw_lifecycle_step_v1(Active, &PalwLifecycleObservationV1 { utilization_permille: 1_000, ..calm(9) }, &k, &G),
            Held
        );
    }

    /// **The 2026-09-25 pre-launch sweep's V03(2) and V05, the rule stated as a table**
    /// ([`palw_lifecycle_step_resilient_v1`]): a readiness hold keeps the probation's progress and
    /// returns to it; a hold for load keeps nothing; one bond's failed probes never reset a
    /// probation, two distinct bonds' do (in `Probation` and in the readiness hold alike); an
    /// `Active` class's hold returns to `Probation { 0 }` as before; and the memory never outlives
    /// the probation it belongs to.
    #[test]
    fn v03_v05_a_readiness_hold_keeps_the_probation_and_only_two_bonds_reset_it() {
        use PalwModelLifecycleV1::*;
        let k = palw_derive_profile_v1(&kimi(), &G, false);
        assert_eq!((G.seat_count, k.required_ready_seats), (5, 7), "the premise: a panel of five, seven to return");
        let calm = |ready: u32, passed: u32, failed: u32| PalwLifecycleObservationV1 {
            manifest: PalwManifestVerdictV1Flag::Valid,
            ready_seats: ready,
            independence_floor_met: true,
            probes_passed_this_span: passed,
            probes_failed_this_span: failed,
            utilization_permille: 300,
            collateral_ok: true,
            cap_ok: true,
            window_fits_receipt: true,
            span_stable: failed == 0,
            admission_jury_seated: false, capped_entry: false, };
        let bond = |n: u64| PalwBondKeyV2(TransactionOutpoint::new(TransactionId::from_u64_word(n), 0));
        let none = PalwProbationMemoryV1::default();
        let step = |s, o: &PalwLifecycleObservationV1, m: &PalwProbationMemoryV1| palw_lifecycle_step_resilient_v1(s, o, &k, &G, m);

        // V03(2): Probation{4} with two passes this span, then the seats fall below the panel → Held
        // keeping 6; still short → still Held with 6; seven ready again → Probation{6}, not {0}.
        let (held, m1) = step(Probation { probes_passed: 4 }, &calm(4, 2, 0), &none);
        assert_eq!((held, m1.held_probes_passed), (Held, Some(6)), "the readiness hold keeps the progress, this span's passes in");
        let (still, m2) = step(Held, &calm(6, 3, 0), &m1);
        assert_eq!((still, m2.held_probes_passed), (Held, Some(6)), "passes while held are not added; the kept count stays");
        let (back, m3) = step(Held, &calm(7, 0, 0), &m2);
        assert_eq!(back, Probation { probes_passed: 6 }, "the return is the probation as it was");
        assert!(m3.is_empty(), "nothing left to remember once back in probation with no failures");
        // v1 on the same walk restarts at 0 — the amplification V03 names.
        assert_eq!(palw_lifecycle_step_v1(Held, &calm(7, 0, 0), &k, &G), Probation { probes_passed: 0 });
        // A hold for load keeps nothing: overloaded → Held → Probation{0}.
        let overloaded = PalwLifecycleObservationV1 { window_fits_receipt: false, ..calm(4, 2, 0) };
        let (held, m) = step(Probation { probes_passed: 4 }, &overloaded, &none);
        assert_eq!((held, m.is_empty()), (Held, true), "a hold for load keeps no progress");
        assert_eq!(step(Held, &calm(7, 0, 0), &m).0, Probation { probes_passed: 0 });
        // An Active class's readiness hold returns to Probation{0}, as before.
        let (held, m) = step(Active, &calm(4, 0, 0), &none);
        assert_eq!((held, m.is_empty()), (Held, true));
        assert_eq!(step(Held, &calm(7, 0, 0), &m).0, Probation { probes_passed: 0 });

        // V05: one bond's failures — however many — do not reset; the passes still count.
        let mut one = PalwProbationMemoryV1::default();
        assert!(one.note_failed_bond(bond(3)));
        assert!(!one.note_failed_bond(bond(3)), "the same bond twice is one bond");
        assert!(!one.probation_failed());
        let (p, m) = step(Probation { probes_passed: 4 }, &calm(7, 2, 5), &one);
        assert_eq!(p, Probation { probes_passed: 6 }, "one bond's failures do not reset the probation");
        assert_eq!(m.failed_bonds, vec![bond(3)], "and are remembered for the rest of the probation");
        // v1 on the same span resets.
        assert_eq!(palw_lifecycle_step_v1(Probation { probes_passed: 4 }, &calm(7, 2, 5), &k, &G), Probation { probes_passed: 0 });
        // A second distinct bond resets it, and the reset forgets both.
        let mut two = m.clone();
        assert!(two.note_failed_bond(bond(1)));
        let mut sorted = vec![bond(3), bond(1)];
        sorted.sort();
        assert_eq!(two.failed_bonds, sorted, "sorted");
        assert!(!two.note_failed_bond(bond(9)), "capped at the reset's two");
        assert!(two.probation_failed());
        let (p, m) = step(Probation { probes_passed: 6 }, &calm(7, 1, 1), &two);
        assert_eq!((p, m.is_empty()), (Probation { probes_passed: 0 }, true), "two distinct bonds reset the probation");
        // The same inside the readiness hold: one bond keeps the progress, two zero it.
        let held_one = PalwProbationMemoryV1 { held_probes_passed: Some(6), failed_bonds: vec![bond(3)] };
        let (h, m) = step(Held, &calm(4, 0, 1), &held_one);
        assert_eq!((h, m.held_probes_passed), (Held, Some(6)));
        assert_eq!(step(Held, &calm(7, 0, 0), &m).0, Probation { probes_passed: 6 });
        let held_two = PalwProbationMemoryV1 { held_probes_passed: Some(6), failed_bonds: sorted.clone() };
        let (h, m) = step(Held, &calm(4, 0, 0), &held_two);
        assert_eq!((h, m.held_probes_passed, m.failed_bonds.len()), (Held, Some(0), 0), "a failed probation zeroes the kept count");
        assert_eq!(step(Held, &calm(7, 0, 0), &m).0, Probation { probes_passed: 0 });
        // Probation → Held with one failed bond carries the bond into the hold.
        let (h, m) = step(Probation { probes_passed: 4 }, &calm(4, 0, 0), &one);
        assert_eq!((h, m.held_probes_passed, m.failed_bonds.clone()), (Held, Some(4), vec![bond(3)]));
        // Graduation forgets the probation's failed bonds.
        let (a, m) = step(Probation { probes_passed: 9 }, &calm(7, 1, 0), &one);
        assert_eq!((a, m.is_empty()), (ActiveLimited { stable_epochs: 0 }, true));
        // The memory belongs to the probation only.
        assert!(none.in_probation(Probation { probes_passed: 0 }));
        assert!(!none.in_probation(Held), "a hold without kept progress is not a probation");
        assert!(held_one.in_probation(Held));
        assert!(!held_one.in_probation(Active));
    }

    /// **No share is set by anyone.** The single lottery's targets follow admission: the dense
    /// tier and the hybrid at the live compute split the draws by their admitted claims a span,
    /// a Kimi-class registered beside them takes the slice its rarity affords, and a class whose
    /// admission is zero holds nothing; the budget is what stays constant.
    #[test]
    fn adr0135_shares_follow_admission_and_no_one_sets_them() {
        let (d, hy, k) = (
            palw_derive_profile_v1(&dense(), &G, false),
            palw_derive_profile_v1(&hybrid(), &G, false),
            palw_derive_profile_v1(&kimi(), &G, false),
        );
        assert!(hy.admission_claims_per_span_milli > d.admission_claims_per_span_milli, "the lighter claim is admitted more often");
        let two = palw_class_shares_from_admission_v1(&[
            (h(1), d.admission_claims_per_span_milli),
            (h(2), hy.admission_claims_per_span_milli),
        ]);
        let three = palw_class_shares_from_admission_v1(&[
            (h(1), d.admission_claims_per_span_milli),
            (h(2), hy.admission_claims_per_span_milli),
            (h(3), k.admission_claims_per_span_milli),
        ]);
        let sum = |v: &[(Hash64, u16)]| v.iter().map(|(_, s)| *s as u32).sum::<u32>();
        assert!((998..=1_000).contains(&sum(&two)) && (998..=1_000).contains(&sum(&three)));
        assert!(three[2].1 < three[0].1 && three[2].1 > 0, "Kimi's slice: rare, not nothing: {:?}", three);
        assert!(three[0].1 < two[0].1, "a new class takes its slice from everyone in proportion");
        let with_zero = palw_class_shares_from_admission_v1(&[(h(1), 1_000), (h(2), 0)]);
        assert_eq!(with_zero, vec![(h(1), 1_000), (h(2), 0)]);
        // The budget in compute is what is conserved: Σ admission × economic compute ≈ budget.
        let spent: u128 = [(&dense(), d), (&hybrid(), hy), (&kimi(), k)]
            .iter()
            .map(|(w, p)| w.economic_ccu_per_claim.saturating_mul(p.admission_claims_per_span_milli as u128) / 1_000)
            .sum();
        assert!(spent <= 3 * G.budget_ccu_per_span, "each class spends at most the budget; a global cap then scales them");
    }

    /// **The readiness age is one rule** (the 2026-09-24 readiness-age sweep). Past readiness V2 a
    /// V1 row is never fresh and a V2 row stands eight spans; before it any row stands thirty. The
    /// draw's policy asks the same rule only when its caller resolved both the 2026-09-23 audit
    /// fence and readiness V2 — and on testnet-11 that resolution is false at every height, so its
    /// draw is the old one byte for byte: any row, the thirty-span age.
    #[test]
    fn the_readiness_age_is_one_rule_and_testnet_11s_draw_keeps_the_old_one() {
        use crate::config::params::Params;
        use crate::network::{NetworkId, NetworkType};
        let g = PALW_REGISTRY_GLOBALS_V1;
        let span = 5u64;
        let row = |proved_daa: u64, proof_version: u8| PalwSeatReadinessRowV1 {
            proved_daa,
            proved_span: proved_daa / span,
            leaf_index: 0,
            proof_version,
            chunks: 1,
        };
        let v1_age = g.readiness_probe_max_age_spans as u64 * span;
        let v2_age = PALW_READINESS_V2_MAX_AGE_SPANS_V1 as u64 * span;
        assert_eq!((palw_readiness_max_age_daa_v1(span, &g, false), palw_readiness_max_age_daa_v1(span, &g, true)), (v1_age, v2_age));
        let now = 10_000;
        // Before readiness V2: any row, the V1 age.
        assert!(palw_readiness_row_is_fresh_v1(&row(now - v1_age, 1), now, span, &g, false));
        assert!(!palw_readiness_row_is_fresh_v1(&row(now - v1_age - 1, 2), now, span, &g, false));
        // Past it: a V1 row at no age, a V2 row for eight spans.
        assert!(!palw_readiness_row_is_fresh_v1(&row(now, 1), now, span, &g, true), "a one-leaf proof is not possession");
        assert!(palw_readiness_row_is_fresh_v1(&row(now - v2_age, 2), now, span, &g, true));
        assert!(!palw_readiness_row_is_fresh_v1(&row(now - v2_age - 1, 2), now, span, &g, true), "nine spans is stale");

        // The draw's policy: below the flag, exactly the struct and the test the processor built
        // before the sweep; past it, the registry's rule.
        let fold = |readiness_v2_active: bool| PalwModelRegistryFoldV1 {
            globals: g,
            span_daa: span,
            genesis_works: BTreeMap::new(),
            grace_until_daa: 0,
            admission_audit_period_daa: None,
            readiness_v2_active,
            bond_maturity: None,
        };
        let base = Hash64::from_u64_word(1);
        for fold_v2 in [false, true] {
            let old = PalwReadinessPolicyV1::at(&fold(fold_v2), now, base, false);
            assert_eq!(old, PalwReadinessPolicyV1 { now_daa: now, max_age_daa: v1_age, base_class_id: base, readiness_v2: false, root_keyed: false });
            for (proved, version) in [(now, 1), (now - v2_age - 1, 1), (now - v1_age, 1), (now - v1_age - 1, 1), (now - v2_age - 1, 2)]
            {
                assert_eq!(
                    old.admits(&row(proved, version)),
                    now.saturating_sub(proved) <= v1_age,
                    "below the flag the draw's test is `now - proved <= V1 age`, whatever the row's version"
                );
            }
            let new = PalwReadinessPolicyV1::at(&fold(fold_v2), now, base, true);
            assert_eq!(new.max_age_daa, v2_age);
            for (proved, version) in [(now, 1), (now - v2_age, 2), (now - v2_age - 1, 2), (now - v1_age, 1)] {
                assert_eq!(
                    new.admits(&row(proved, version)),
                    palw_readiness_row_is_fresh_v1(&row(proved, version), now, span, &g, true)
                );
            }
        }

        // The flag the processor resolves (`palw_audit_2026_09_23_at && palw_readiness_v2_at`):
        // false on testnet-11 at every height — its draw does not move — and true on testnet-12.
        let t11 = Params::from(NetworkId::with_suffix(NetworkType::Testnet, 11));
        let t12 = Params::from(NetworkId::with_suffix(NetworkType::Testnet, 12));
        let flag = |p: &Params, daa: u64| p.palw_audit_2026_09_23_active_at(daa) && p.palw_readiness_v2_at(daa);
        for daa in [0, 5_999, 6_000, 6_001, 6_100, 7_000, 7_001, 100_000, u64::MAX / 2] {
            assert!(!flag(&t11, daa), "testnet-11 at {daa}: the draw keeps the V1 readiness rule");
        }
        assert!(flag(&t12, 0) && flag(&t12, 1_000_000), "testnet-12: the draw judges rows as its registry counts them");
    }

    /// **The readiness-V2 horizon is an input of the one rule, and every judge of a row follows it**
    /// (user decision 2026-09-25, readiness capacity option (a)). At the default eight spans and at
    /// testnet-12's twenty-four, on one-DAA spans: a V2 row stands exactly the horizon and not a DAA
    /// more — for the rule, the fold's own question and the draw's policy alike; a V1 row still never
    /// counts; the V1 age is untouched; and the node's duty is due past half the horizon (4, then 12).
    #[test]
    fn the_readiness_v2_horizon_is_an_input_every_judge_of_a_row_follows() {
        let span = 1u64;
        let now = 1_000u64;
        let row = |proved_daa: u64, proof_version: u8| PalwSeatReadinessRowV1 {
            proved_daa,
            proved_span: proved_daa / span,
            leaf_index: 0,
            proof_version,
            chunks: 16,
        };
        let base = Hash64::from_u64_word(1);
        for (spans, duty) in [(PALW_READINESS_V2_MAX_AGE_SPANS_V1, 4u64), (PALW_READINESS_V2_MAX_AGE_SPANS_T12_V1, 12)] {
            let g = PalwRegistryGlobalsV1 { readiness_v2_max_age_spans: spans, ..PALW_REGISTRY_GLOBALS_V1 };
            let age = spans as u64;
            assert_eq!(palw_readiness_max_age_daa_v1(span, &g, true), age, "{spans}: the horizon, in DAA");
            assert_eq!(palw_readiness_max_age_daa_v1(span, &g, false), 30, "{spans}: the V1 age does not move");
            let fold = PalwModelRegistryFoldV1 {
                globals: g,
                span_daa: span,
                genesis_works: BTreeMap::new(),
                grace_until_daa: 0,
                admission_audit_period_daa: None,
                readiness_v2_active: true,
                bond_maturity: None,
            };
            let policy = PalwReadinessPolicyV1::at(&fold, now, base, true);
            assert_eq!(fold.readiness_max_age_daa(), age);
            for (at_age, fresh) in [(age, true), (age + 1, false)] {
                let r = row(now - at_age, 2);
                assert_eq!(palw_readiness_row_is_fresh_v1(&r, now, span, &g, true), fresh, "{spans}: age {at_age}");
                assert_eq!(fold.readiness_row_is_fresh(&r, now), fresh, "{spans}: the fold's own question, age {at_age}");
                assert_eq!(policy.admits(&r), fresh, "{spans}: the draw's policy, age {at_age}");
            }
            assert!(!fold.readiness_row_is_fresh(&row(now, 1), now), "{spans}: a one-leaf row never counts");
            // The node's duty: due past half the horizon, not at it.
            let r = row(now, 2);
            assert!(!palw_readiness_duty_due_v2(Some(&r), now + duty, now + duty, None, span, &g, true), "{spans}: at {duty}");
            assert!(palw_readiness_duty_due_v2(Some(&r), now + duty + 1, now + duty + 1, None, span, &g, true), "{spans}: past it");
        }
        // The bounds a network may configure: never below the default, never past the V1 age.
        assert_eq!(PALW_READINESS_V2_MAX_AGE_SPANS_MAX_V1, PALW_REGISTRY_GLOBALS_V1.readiness_probe_max_age_spans);
        const {
            assert!(PALW_READINESS_V2_MAX_AGE_SPANS_V1 <= PALW_READINESS_V2_MAX_AGE_SPANS_T12_V1);
            assert!(PALW_READINESS_V2_MAX_AGE_SPANS_T12_V1 <= PALW_READINESS_V2_MAX_AGE_SPANS_MAX_V1);
        }
    }

    #[test]
    fn adr0135_the_node_proves_when_the_chain_has_no_fresh_proof_and_never_twice_a_span() {
        let g = PALW_REGISTRY_GLOBALS_V1;
        let span = 5;
        assert!(palw_readiness_duty_due_v1(None, 1_000, 200, None, span, &g), "no proof on the chain: due");
        assert!(!palw_readiness_duty_due_v1(None, 1_000, 200, Some(200), span, &g), "already sent this span");
        let fresh = PalwSeatReadinessRowV1 { proved_daa: 990, proved_span: 198, leaf_index: 3, proof_version: 1, chunks: 1 };
        assert!(!palw_readiness_duty_due_v1(Some(&fresh), 1_000, 200, None, span, &g), "a fresh proof is not repeated");
        let half = PalwSeatReadinessRowV1 {
            proved_daa: 1_000 - (g.readiness_probe_max_age_spans as u64 * span) / 2 - 1,
            proved_span: 0,
            leaf_index: 3,
            proof_version: 1,
            chunks: 1,
        };
        assert!(
            palw_readiness_duty_due_v1(Some(&half), 1_000, 200, None, span, &g),
            "past half the age: renewed before it goes stale"
        );
        assert!(!palw_readiness_duty_due_v1(Some(&half), 1_000, 200, Some(200), span, &g));
    }

    /// **ADR-0132 Upgrade C / ADR-0133 Fence 3: a cap-saturated class is not activatable.** The
    /// stable count keeps running; the full share does not come, and an active class over the
    /// ceiling falls back to a tenth. Probation still exits to a tenth: the cap gates the full
    /// share only.
    #[test]
    fn adr0132_a_cap_saturated_class_is_not_activated_and_an_active_one_falls_to_a_tenth() {
        use PalwModelLifecycleV1::*;
        let k = palw_derive_profile_v1(&kimi(), &G, false);
        let obs = |cap_ok: bool| PalwLifecycleObservationV1 {
            manifest: PalwManifestVerdictV1Flag::Valid,
            ready_seats: 7,
            independence_floor_met: true,
            probes_passed_this_span: 0,
            probes_failed_this_span: 0,
            utilization_permille: 300,
            collateral_ok: true,
            cap_ok,
            window_fits_receipt: true,
            span_stable: true,
            // Every fixture below this line walks a class that is already past `Candidate`, and
            // `admission_jury_seated` is read by that one arm: `false` here says so, and says that
            // nothing else in the lifecycle learned to read it.
            admission_jury_seated: false, capped_entry: false, };
        assert_eq!(
            palw_lifecycle_step_v1(ActiveLimited { stable_epochs: 2 }, &obs(true), &k, &G),
            Active,
            "three stable spans activate"
        );
        assert_eq!(
            palw_lifecycle_step_v1(ActiveLimited { stable_epochs: 2 }, &obs(false), &k, &G),
            ActiveLimited { stable_epochs: 3 },
            "…unless the class is cap-saturated: it keeps counting and stays at a tenth"
        );
        assert_eq!(
            palw_lifecycle_step_v1(ActiveLimited { stable_epochs: 9 }, &obs(false), &k, &G),
            ActiveLimited { stable_epochs: 10 }
        );
        assert_eq!(
            palw_lifecycle_step_v1(Active, &obs(false), &k, &G),
            ActiveLimited { stable_epochs: 0 },
            "an active class over the ceiling falls back to a tenth"
        );
        assert_eq!(palw_lifecycle_step_v1(Active, &obs(true), &k, &G), Active);
        assert_eq!(
            palw_lifecycle_step_v1(Probation { probes_passed: 10 }, &obs(false), &k, &G),
            ActiveLimited { stable_epochs: 0 },
            "probation still exits to a tenth: the cap gates the full share only"
        );
    }

    /// **The typed catalog describes the four shipped rows to the registry**, each with a non-zero
    /// draw and verification compute — the works testnet-11's genesis classes get, since no bundle
    /// registration carries a carriage for them.
    #[test]
    fn adr0135_the_typed_catalog_describes_the_shipped_rows() {
        let works = palw_rc_typed_class_works_v1();
        let ids: Vec<String> = works.keys().map(|id| id.to_string()[..16].to_string()).collect();
        for expected in ["f1c5635c6e47e96e", "5bd9ae3d91df8065", "4277d84f7d91528c", "2705b8f65f7ba54a"] {
            assert!(ids.contains(&expected.to_string()), "{expected} is described; have {ids:?}");
        }
        for (id, work) in &works {
            assert!(work.ops_supported && work.economic_ccu_per_claim > 0 && work.verification_ccu > 0, "{id}: {work:?}");
        }
        assert_eq!(works, palw_rc_typed_class_works_v1(), "a function of the binary alone");
    }

    /// The landing allowance is eight spans or forty DAA, whichever is more: testnet-11's five-DAA
    /// spans keep the eight, a two-DAA devnet gets twenty, a one-DAA fixture forty.
    #[test]
    fn adr0135_the_landing_allowance_is_the_larger_of_eight_spans_and_forty_daa() {
        assert_eq!(palw_readiness_landing_spans_v1(5), 8);
        assert_eq!(palw_readiness_landing_spans_v1(10), 8);
        assert_eq!(palw_readiness_landing_spans_v1(2), 20);
        assert_eq!(palw_readiness_landing_spans_v1(1), 40);
        assert_eq!(palw_readiness_landing_spans_v1(0), 40, "a zero span is read as one");
    }
}
