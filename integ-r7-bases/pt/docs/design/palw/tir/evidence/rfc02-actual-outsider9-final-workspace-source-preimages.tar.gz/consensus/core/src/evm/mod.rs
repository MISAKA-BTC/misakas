//! kaspa-pq Selected-Parent EVM Lane (ADR-0020) — consensus type surface
//! (design v0.4, `docs/misaka-evm-design-v0.4.md`).
//!
//! This module carries the **types only** for the EVM execution lane: the
//! block-body [`EvmExecutionPayload`] (bounded system ops + EIP-2718 user txs),
//! the executor-output [`EvmExecutionHeader`] (whose keyed BLAKE2b-512 digest
//! becomes `Header::evm_commitment_root`), the UTXO↔EVM op types
//! ([`EvmSystemOp`]/[`DepositClaim`]/[`WithdrawOp`]),
//! and the small EVM-domain newtypes ([`EvmAddress`], [`EvmBloom`],
//! [`EvmU256`]). The executor itself (revm) lands in the `kaspa-evm` crate
//! behind the `evm` cargo feature; nothing here pulls revm or secp256k1.
//!
//! Design alignment (v0.4 §3/§4): execution is **mergeset delayed acceptance**
//! — `EvmResult(B) = exec(state(selected_parent(B)), B.system_ops,
//! AcceptedEvmTxs(B))` where `AcceptedEvmTxs(B)` is the mergeset's payload txs
//! in canonical order; a block's OWN user payload is data committed by
//! `Header::evm_payload_hash` and is executed by its selected child. The L1
//! header carries exactly two EVM commitments (`evm_payload_hash` +
//! `evm_commitment_root`); the full execution metadata lives here in the block
//! body. An EVM result is a pure function of the block's parents + its own
//! system ops, so it is computed once and never re-executed on a virtual reorg
//! (§2.2 / §10).

mod u256;
pub use u256::*;

mod log_index;
pub use log_index::*;

/// ADR-0089: the contract between the fold and the EVM's window and hand.
pub mod model_market;
mod state_diff;
pub use state_diff::*;

use crate::tx::{ScriptPublicKey, TransactionOutpoint};
use borsh::{BorshDeserialize, BorshSerialize};
use kaspa_hashes::{EvmH256, Hash64, blake2b_512_keyed};
use kaspa_utils::{
    hex::{FromHex, ToHex},
    mem_size::MemSizeEstimator,
    serde_impl_deser_fixed_bytes_ref, serde_impl_ser_fixed_bytes_ref,
};
use serde::{Deserialize, Serialize};
use std::{
    fmt::{Debug, Display, Formatter},
    mem::size_of,
    str::{self, FromStr},
};

// ---------------------------------------------------------------------------
// Frozen EVM-lane constants (ADR-0020 §"Spec freeze"). Network-tunable values
// (activation height) live on `Params`; these are protocol-wide constants.
// ---------------------------------------------------------------------------

/// Ratio between one UTXO atomic unit (sompi, 8 decimals) and the EVM native
/// unit (wei, 18 decimals): `10^(18-8) = 10^10`. A deposit of `amount_sompi`
/// credits `amount_sompi * EVM_NATIVE_SCALE` wei; a withdrawal must be an exact
/// multiple of this scale, else the precompile reverts (design §7/§8/§9.1).
pub const EVM_NATIVE_SCALE: u64 = 10_000_000_000;

/// MISAKA EVM chain id (testnet target). Deliberately distinct from every
/// public Ethereum network so `eth_chainId` can never collide with mainnet
/// (1) or common testnets. `0x4D534B` spells "MSK". Frozen in ADR-0020; the
/// mainnet id will be a different value chosen at mainnet launch. EIP-155
/// replay protection is mandatory (design §4.4).
pub const EVM_CHAIN_ID: u64 = 0x4D_53_4B;

/// Reserved system-predeploy address for **WMISAKA** (the WETH9-equivalent
/// wrapped-native ERC-20 used by v2/v3 DEX pools, design §19.3). A normal EVM
/// contract (not a precompile) deployed into the activation state; carried here
/// so the executor and RPC agree on the canonical wrapped-native address.
pub const WMISAKA_ADDRESS: EvmAddress = EvmAddress::from_bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xF0, 0x01]);

/// Reserved precompile address for `MISAKA_WITHDRAW` (EVM → UTXO, design §8.1).
/// User-input failures here revert the tx (block stays valid, §8.2); only a
/// producer commitment/diff mismatch makes a block invalid.
pub const MISAKA_WITHDRAW_PRECOMPILE: EvmAddress =
    EvmAddress::from_bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xF0, 0x02]);

/// Reserved precompile address for `MLDSA87_VERIFY` (PREA design v1.1 §9 / FSL
/// §4.3). A pure post-quantum signature-verify precompile (ML-DSA-87, FIPS 204):
/// it changes no state and moves no value, so it is reachable from any frame
/// (incl. `STATICCALL`). The call is **version-discriminated** (`input[0]`):
/// `0x01` = FSL generic Hash64 verify; `0x02` = PREA key-bound root authorization
/// (additionally binds the pubkey to its UTXO address payload). Any malformed
/// input, wrong length, unknown version, key-payload mismatch, or invalid
/// signature returns the 32-byte ABI `false` (never panics, never reverts).
/// ACTIVATION-FENCED + INERT until `evm_f003_mldsa_verify_activation_daa_score`
/// (u64::MAX on every network); below the fence the handler is not registered, so
/// a call to this address behaves exactly as a call to an empty account today
/// (byte-identical execution, genesis/state-root unchanged).
pub const MISAKA_MLDSA_VERIFY_PRECOMPILE: EvmAddress =
    EvmAddress::from_bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xF0, 0x03]);

/// The EVM genesis state root — the `parent_state_root` of the first EVM block.
/// With no system predeploys this is the canonical empty Merkle-Patricia-Trie
/// root `keccak256(rlp(()))` (= `alloy_trie::EMPTY_ROOT_HASH`); the P2 executor
/// asserts an empty block reproduces it. When the WMISAKA predeploy lands
/// (design §19.3, P5+) this becomes the post-predeploy state root.
pub const EVM_GENESIS_STATE_ROOT: EvmH256 = EvmH256::from_bytes([
    0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99,
    0x6c, 0xad, 0xc0, 0x01, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21,
]);

// --- Domain separators (design v0.4 §4.1). Frozen once testnet activates. ---

/// Keyed-BLAKE2b-512 domain for the L1 `evm_commitment_root` over the full
/// [`EvmExecutionHeader`] (design v0.4 §4.1 normative key).
pub const MISAKA_EVM_COMMITMENT_CONTEXT: &[u8] = b"EvmCommitment64";
/// Keyed-BLAKE2b-512 domain for the L1 `evm_payload_hash` over the borsh
/// encoding of the block's own [`EvmExecutionPayload`] (design v0.4 §4.1).
pub const MISAKA_EVM_PAYLOAD_HASH_CONTEXT: &[u8] = b"EvmPayload64";
/// Keyed-BLAKE2b-256 domain for `EvmExecutionHeader::system_ops_root`.
pub const MISAKA_EVM_SYSTEM_OPS_CONTEXT: &[u8] = b"MISAKA_EVM_SYSTEM_OPS_V2";
/// Keyed-BLAKE2b-256 domain for `EvmExecutionHeader::withdrawals_root`.
pub const MISAKA_EVM_WITHDRAWAL_CONTEXT: &[u8] = b"MISAKA_EVM_WITHDRAWAL_V2";
/// Keyed-BLAKE2b-256 domain for `EvmExecutionHeader::deposit_claim_queue_root`.
pub const MISAKA_EVM_DEPOSIT_CLAIM_CONTEXT: &[u8] = b"MISAKA_EVM_DEPOSIT_CLAIM_V2";
/// Keyed-BLAKE2b-512 domain for withdrawal synthetic-outpoint txids (P4, §8.3).
/// MUST stay separate from the normal transaction-id domain so a synthetic
/// outpoint can never collide with a real txid.
pub const MISAKA_EVM_SYNTHETIC_OUTPOINT_CONTEXT: &[u8] = b"MISAKA_EVM_SYNTHETIC_OUTPOINT_V2";
/// Keyed-BLAKE2b-256 domain for the EVM `prevrandao` derivation (design §4.3).
pub const MISAKA_EVM_PREVRANDAO_CONTEXT: &[u8] = b"MISAKA_EVM_PREVRANDAO_V2";

// --- Bounded deposit-claim / system-gas limits (design §7.3 / §15.2). ---
// Enforced in P4 when DepositClaim validation lands; defined here so the
// limits are frozen with the rest of the spec.

/// Max `DepositClaim` system ops per EVM block.
pub const MAX_DEPOSIT_CLAIMS_PER_EVM_BLOCK: usize = 256;
/// Max total serialized `DepositClaim` bytes per EVM block.
pub const MAX_DEPOSIT_CLAIM_BYTES_PER_EVM_BLOCK: usize = 64 * 1024;
/// System gas charged to `gas_used` per applied deposit claim (design §7.4).
pub const SYSTEM_DEPOSIT_GAS_PER_CLAIM: u64 = 25_000;
/// Max total system gas (deposit claims + future system ops) per EVM block.
pub const MAX_SYSTEM_GAS_PER_EVM_BLOCK: u64 = 10_000_000;

// --- EVM block gas schedule + EIP-1559 base fee (design §5; P2 freeze). ---
// The design's per-second gas targeting (§5.2: `G_target_sec × τ_sc` from
// `W_eff/BPS`) is a documented pre-activation refinement. P2 freezes a fixed
// block gas limit so the gas schedule and base-fee update are deterministic and
// independently verifiable by every node (the values feed the committed
// `EvmExecutionHeader`). Refining before activation is not a hard fork (the lane
// is `u64::MAX`-inert until deploy); changing them after activation is.

/// EVM block gas limit (frozen). `gas_target = EVM_GAS_LIMIT / EVM_ELASTICITY_MULTIPLIER`.
pub const EVM_GAS_LIMIT: u64 = 30_000_000;
/// EIP-1559 elasticity multiplier: `gas_limit = EVM_ELASTICITY_MULTIPLIER × gas_target`.
pub const EVM_ELASTICITY_MULTIPLIER: u64 = 2;
/// EIP-1559 base-fee max change denominator (≤ `1/8` change per EVM block).
pub const EVM_BASE_FEE_MAX_CHANGE_DENOMINATOR: u64 = 8;
/// Base fee (wei) of the first EVM block (1 gwei). Base fee is burned, never paid
/// to the block coinbase (design §9.2), and accumulates in `evm_burn_accumulator`.
pub const EVM_INITIAL_BASE_FEE: u64 = 1_000_000_000;

// --- v0.4 two-stage caps (design §7, D4). ---
// Inclusion-side: a DAG block's own payload size, checked at body validation
// (class-1 admission). Execution-side: the accepted-gas budget of one chain
// block's mergeset acceptance, applied as a deterministic prefix-take over
// `AcceptedEvmTxs(B)` by declared tx gas_limit (over-cap txs are class-5
// skipped; nonce unchanged, re-acceptable later). Numeric freeze before
// activation = open decision O13 (per-second G_limit derivation + measured
// propagation, design §14.3); changing them pre-activation is not a hard fork.

/// Max serialized `EvmExecutionPayload` bytes per DAG block (inclusion cap).
pub const MAX_EVM_PAYLOAD_BYTES_PER_DAG_BLOCK: usize = 128 * 1024;
/// Max accepted user-tx gas per chain block (execution cap) = `G_limit_block`
/// (design §5.1: kept equal to the EVM block gas limit, audit AH-2).
pub const MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK: u64 = EVM_GAS_LIMIT;

/// **ADR-0139 (O13 decided): the execution lane's gas throughput scales with the lane, one budget a
/// round.** Every permitted round block a chain block merges buys this much more accepted user gas
/// for that chain block, on top of `MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK` (the base a chain block
/// had before the lane). Sized from the 2026-09-18 benchmark (`o13_bench_execution_gas_per_second`):
/// execution is not the bound (174 M gas/s of signed transfers, 6 G gas/s of storage writes in
/// memory on the build host), propagation is not (0.005 bytes of transaction per gas — 15 KB/s at
/// this rate); **state growth is** — a fresh account or slot costs ~20 k gas and writes ~100 bytes,
/// so 3 M gas a second is ≤ 15 KB/s of new state, ~1.3 GB a day at full load, the growth a
/// testnet host absorbs. Derived from the round INDEX the round block carries (consensus data),
/// never from a clock.
pub const EVM_ROUND_GAS_BUDGET_V1: u64 = 3_000_000;
/// **The ceiling on one chain block's accepted user gas, whatever it merges.** 120 rounds of one
/// anchor (120 s) at the round budget, plus the base: 390 M gas is ~2 MB of transactions to
/// propagate at the anchor cadence and ~10 s of execution on a slow host at 35 M gas/s.
pub const EVM_CHAIN_BLOCK_GAS_CEILING_V1: u64 = MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK + 120 * EVM_ROUND_GAS_BUDGET_V1;

/// **How many round budgets a chain block bought** (ADR-0139): the number of DISTINCT rounds among
/// the permits its round blocks used. Distinct is the whole rule — two blocks of the SAME round buy
/// one budget, whatever their permit indices, so a producer cannot inflate a chain block's gas by
/// filling one round with blocks. The permits come from the merging block's own verdicts, which
/// already refuse a permit twice (`round_permit_used`) and an equivocation.
pub fn evm_distinct_permitted_rounds_v1(uses: &[crate::palw_execution_lane_v1::PalwExecPermitUseV1]) -> u64 {
    uses.iter().map(|u| u.round).collect::<std::collections::BTreeSet<u64>>().len() as u64
}

/// **The accepted-user-gas cap of one chain block** (ADR-0139). `None` where the execution lane is
/// not in force at the block's DAA — the cap a chain block always had. `Some(rounds)` — the number
/// of DISTINCT permitted rounds among the round blocks it merges — buys one round budget each,
/// under the ceiling. Deterministic in the round indices the merged envelopes carry.
pub fn evm_user_gas_cap_v1(permitted_rounds: Option<u64>) -> u64 {
    match permitted_rounds {
        None => MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
        Some(rounds) => MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK
            .saturating_add(rounds.saturating_mul(EVM_ROUND_GAS_BUDGET_V1))
            .min(EVM_CHAIN_BLOCK_GAS_CEILING_V1),
    }
}

// --- F002 withdraw precompile (design §9.3). ---

/// Fixed gas charged by a successful (or user-fault-reverted) `F002` withdraw
/// call, on top of the carrying tx's intrinsic gas. Frozen at activation.
pub const F002_WITHDRAW_GAS: u64 = 9_000;
/// Max `WithdrawOp`s an accepting chain block may MATERIALIZE (audit M-03): each
/// withdraw adds a synthetic UTXO output + MuHash/index/script work that the flat
/// F002 EVM gas under-prices, so the count of L1-materialized withdrawals must be
/// independently bounded (mirrors the deposit-claim per-block cap). ENFORCEMENT IS
/// FENCED + NOT YET WIRED — see `evm_f002_withdraw_cap_activation_daa_score` and
/// `docs/adr/0020-…` / the executor note: the safe enforcement is a per-tx class-2
/// skip once the block's withdraw count would exceed this cap (transact-without-
/// commit so the skipped tx's state never commits), implemented + supply-invariant-
/// tested as a dedicated activation, NOT a rushed change. Inert until activated.
pub const MAX_WITHDRAWALS_PER_EVM_BLOCK: usize = 256;
/// Max byte length of the destination `ScriptPublicKey` SCRIPT a withdraw may
/// name (the standard ML-DSA P2PKH script is 69 bytes; this is a sanity bound,
/// the class check is the real gate).
pub const MAX_WITHDRAW_SCRIPT_BYTES: usize = 128;

// --- F003 MLDSA87_VERIFY precompile (PREA design v1.1 §9 / FSL §4.3). ---
//
// P0-0 FROZEN VALUES (proposed; benchmark-confirm on a low-end no-SIMD reference
// image before activation — these are inert under u64::MAX and so freely tunable
// until the activation DAA is set; changing them AFTER activation is a hard fork).
// The gas charge is the PRIMARY deterministic bound: one ML-DSA-87 portable
// verify is ~tens of µs, so a flat per-call gas calibrated so that
// `block_gas / F003_VERIFY_GAS ≈ MAX_MLDSA_VERIFY_PER_EVM_BLOCK` bounds the
// per-block verify CPU even though the precompile is reachable from inner frames
// (the named count caps below DOCUMENT that gas-implied ceiling).

/// F003 input version tags (`input[0]`). 0x01 = FSL generic Hash64 verify;
/// 0x02 = PREA key-bound root authorization.
pub const F003_VERSION_FSL_GENERIC: u8 = 0x01;
pub const F003_VERSION_PREA_ROOT: u8 = 0x02;

/// F003 version-0x01 (FSL generic) fixed input length (exact-match; any other ⇒
/// ABI `false`): `version(1) ‖ pubkey(2592) ‖ message_hash64(64) ‖ signature(4627)`.
/// The caller supplies the 64-byte digest (FSL computes its own fact digest).
pub const F003_INPUT_LEN_FSL: usize = 1 + 2592 + 64 + 4627; // 7284

/// F003 version-0x02 (PREA root) FIXED-PREFIX length (design v1.1 §9.3 option B):
/// `version(1) ‖ expected_key_payload64(64) ‖ pubkey(2592) ‖ signature(4627)`,
/// FOLLOWED by a variable `op_preimage` (1..=`F003_MAX_PREA_PREIMAGE_BYTES`). F003
/// itself computes `message_hash64 = keyed_blake2b_512(F003_PREA_OP_MLDSA87_CONTEXT,
/// op_preimage)` so an on-chain caller (the PQ smart account `executeRoot`) does NOT
/// need keyed-BLAKE2b-512 in the EVM: it just passes the canonical operation bytes
/// it is about to execute, and the ML-DSA signature is verified over the full-PQ
/// Hash64 digest of exactly those bytes — binding the signature to the operation.
pub const F003_PREA_PREFIX_LEN: usize = 1 + 64 + 2592 + 4627; // 7284
/// Max `op_preimage` bytes for an F003 version-0x02 call. Bounds the keyed-BLAKE2b
/// work + the input size (with the prefix, ≤ ~23.6 KiB/call); generous for an op's
/// target/value/calldata. Frozen at activation.
pub const F003_MAX_PREA_PREIMAGE_BYTES: usize = 16 * 1024;

/// Fixed gas charged by an F003 call (any version, success OR fail-closed-false),
/// on top of the carrying tx's calldata + intrinsic gas. Set so the gas-implied
/// per-block verify count (`EVM_GAS_LIMIT / F003_VERIFY_GAS` = 60) stays at or
/// under `MAX_MLDSA_VERIFY_PER_EVM_BLOCK`; ~conservative vs the ~tens-of-µs
/// portable verify (deliberately over-priced — root operations are infrequent and
/// under-pricing is the real risk). Charged BEFORE dispatch so a malformed flood
/// pays the same. Frozen at activation.
pub const F003_VERIFY_GAS: u64 = 500_000;

/// Documented gas-implied per-block ceiling on F003 verifies (the gas charge is
/// the enforcing mechanism: `EVM_GAS_LIMIT / F003_VERIFY_GAS = 60 ≤ 64`, and the
/// ~7.3 KB calldata cost lowers it further). Named so monitoring + a future
/// explicit counter (if benchmarks demand a sub-gas bound) have a single source.
pub const MAX_MLDSA_VERIFY_PER_EVM_BLOCK: usize = 64;
/// Documented gas-implied per-tx ceiling on F003 verifies (a tx doing this many
/// verifies costs ~`8 × F003_VERIFY_GAS` = 4M gas; tx/block gas bounds it).
pub const MAX_MLDSA_VERIFY_PER_TX: usize = 8;
/// Documented per-block ceiling on total F003 auth input bytes (a v0x02 call is
/// `F003_PREA_PREFIX_LEN + op_preimage`; this bounds the aggregate across a block
/// independently of the per-verify count cap, and is also bounded by calldata gas).
pub const MAX_MLDSA_AUTH_BYTES_PER_EVM_BLOCK: usize = 512 * 1024;

/// F003 version-0x02 (PREA root) ML-DSA-87 signing context — the `ctx` domain
/// separator. Distinct from every other ML-DSA-87 context (att/unbond/takeover/
/// audit-ckpt/tx/address) so a UTXO/attestation/tx signature can never be
/// cross-protocol-replayed as an EVM root authorization, and vice versa.
pub const F003_PREA_ROOT_MLDSA87_CONTEXT: &[u8] = b"misaka-pq-evm-v1/root/mldsa87";
/// F003 version-0x02 keyed-BLAKE2b-512 domain key for the OP-PREIMAGE digest
/// (design v1.1 §9.3 option B): `message_hash64 = keyed_blake2b_512(this,
/// op_preimage)`, then ML-DSA-87-verified under `F003_PREA_ROOT_MLDSA87_CONTEXT`.
/// A distinct domain from the address-payload key and the ML-DSA contexts so an
/// op digest can never collide with an address payload or be reinterpreted.
pub const F003_PREA_OP_MLDSA87_CONTEXT: &[u8] = b"misaka-pq-evm-v1/op/mldsa87";
/// F003 version-0x01 (FSL generic) ML-DSA-87 signing context. Reserved for the
/// Fact Settlement Layer (FSL v0.3 §4.3) generic Hash64 verification; the FSL
/// spec adopts THIS context as the canonical one for `0xF003` version 0x01.
pub const F003_FSL_VERIFY_MLDSA87_CONTEXT: &[u8] = b"misaka-pq-fsl-v1/verify/mldsa87";

/// `synthetic_withdrawal_txid` (design §9.3): the deterministic txid of the
/// synthetic UTXO output materializing one `WithdrawOp` in the accepting block
/// B's own UTXO diff. Keyed under the FROZEN
/// [`MISAKA_EVM_SYNTHETIC_OUTPOINT_CONTEXT`] domain — deliberately separate
/// from the real transaction-id domain so a synthetic outpoint can never
/// collide with a real txid. Preimage (frozen byte order):
/// `evm_tx_hash(32) ‖ op_index(4 LE) ‖ from(20) ‖ amount_sompi(8 LE)
///  ‖ spk_version(2 LE) ‖ script_len(4 LE) ‖ script(script_len)`.
///
/// Keyed by the WITHDRAWING EVM TX's keccak256 hash — NOT the accepting block
/// hash. The block hash includes the nonce and `utxo_commitment`, and the
/// synthetic output is itself part of `utxo_commitment`: a block-hash key is
/// CIRCULAR — the producer could never compute its own commitment before
/// mining (found live: the first real withdraw-bearing template self-
/// disqualified). The tx-hash key is pre-mining-stable.
///
/// The preimage ALSO binds the full materialized content `(from, amount_sompi,
/// destination script)` — not just `evm_tx_hash ‖ op_index`. The earlier
/// "withdraw content is fixed by the SIGNED tx itself" assumption holds only
/// for a top-level `EOA → F002` call; F002 is also reachable via an INNER
/// contract `CALL` (the intercept matches any frame targeting F002), so a
/// single signed tx routed through a contract can withdraw a branch-dependent
/// `(amount, script)` (the contract may read `NUMBER`/`TIMESTAMP`/`COINBASE`/
/// `PREVRANDAO`/`BASEFEE` or selected-parent state, all of which differ per
/// accepting block). The same tx can be accepted in more than one chain block
/// (`EvmTxLocations.accepted_in` allows side branches), so without binding the
/// content two acceptances would share an outpoint but carry DIFFERENT UTXO
/// content — corrupting reorg / mempool / indexer / descendant-spend semantics.
/// Content-addressing makes identical withdraws share an outpoint (as a real
/// txid would) while divergent ones can never collide. (Audit F1.)
pub fn synthetic_withdrawal_txid(
    evm_tx_hash: EvmH256,
    op_index: u32,
    from: EvmAddress,
    amount_sompi: u64,
    script_public_key: &ScriptPublicKey,
) -> Hash64 {
    let script = script_public_key.script();
    let mut preimage = Vec::with_capacity(32 + 4 + EVM_ADDRESS_SIZE + 8 + 2 + 4 + script.len());
    preimage.extend_from_slice(&evm_tx_hash.as_bytes());
    preimage.extend_from_slice(&op_index.to_le_bytes());
    preimage.extend_from_slice(&from.as_bytes()); // bind the debited EVM account
    preimage.extend_from_slice(&amount_sompi.to_le_bytes()); // bind the paid-out amount
    preimage.extend_from_slice(&script_public_key.version().to_le_bytes()); // bind the destination spk version
    preimage.extend_from_slice(&(script.len() as u32).to_le_bytes()); // length-prefix the variable-length script (no ambiguity)
    preimage.extend_from_slice(script); // bind the destination script bytes
    blake2b_512_keyed(MISAKA_EVM_SYNTHETIC_OUTPOINT_CONTEXT, &preimage)
}

// ---------------------------------------------------------------------------
// EvmAddress — 20-byte Ethereum account address.
// ---------------------------------------------------------------------------

/// Width of an [`EvmAddress`] in bytes.
pub const EVM_ADDRESS_SIZE: usize = 20;

/// A 20-byte Ethereum account address (the `evm_coinbase` / `to` surface).
#[derive(Clone, Copy, Eq, PartialEq, Ord, PartialOrd, Hash, Default, BorshSerialize, BorshDeserialize)]
pub struct EvmAddress([u8; EVM_ADDRESS_SIZE]);

serde_impl_ser_fixed_bytes_ref!(EvmAddress, EVM_ADDRESS_SIZE);
serde_impl_deser_fixed_bytes_ref!(EvmAddress, EVM_ADDRESS_SIZE);

impl EvmAddress {
    #[inline(always)]
    pub const fn from_bytes(bytes: [u8; EVM_ADDRESS_SIZE]) -> Self {
        EvmAddress(bytes)
    }

    #[inline(always)]
    pub const fn as_bytes(self) -> [u8; EVM_ADDRESS_SIZE] {
        self.0
    }

    #[inline(always)]
    pub fn is_zero(&self) -> bool {
        self.0 == [0u8; EVM_ADDRESS_SIZE]
    }
}

impl From<[u8; EVM_ADDRESS_SIZE]> for EvmAddress {
    fn from(value: [u8; EVM_ADDRESS_SIZE]) -> Self {
        EvmAddress(value)
    }
}

impl AsRef<[u8; EVM_ADDRESS_SIZE]> for EvmAddress {
    #[inline(always)]
    fn as_ref(&self) -> &[u8; EVM_ADDRESS_SIZE] {
        &self.0
    }
}

impl AsRef<[u8]> for EvmAddress {
    #[inline(always)]
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

impl Display for EvmAddress {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        let mut hex = [0u8; EVM_ADDRESS_SIZE * 2];
        faster_hex::hex_encode(&self.0, &mut hex).expect("twice the input size");
        f.write_str(unsafe { str::from_utf8_unchecked(&hex) })
    }
}

impl Debug for EvmAddress {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "EvmAddress({self})")
    }
}

impl FromStr for EvmAddress {
    type Err = faster_hex::Error;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let s = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")).unwrap_or(s);
        let mut bytes = [0u8; EVM_ADDRESS_SIZE];
        faster_hex::hex_decode(s.as_bytes(), &mut bytes)?;
        Ok(EvmAddress(bytes))
    }
}

// Required by the `serde_impl_*_fixed_bytes_ref!` macros (hex string in
// human-readable encoders, raw bytes in compact ones).
impl ToHex for EvmAddress {
    fn to_hex(&self) -> String {
        self.to_string()
    }
}

impl FromHex for EvmAddress {
    type Error = faster_hex::Error;
    fn from_hex(hex_str: &str) -> Result<Self, Self::Error> {
        Self::from_str(hex_str)
    }
}

impl MemSizeEstimator for EvmAddress {}

// ---------------------------------------------------------------------------
// EvmBloom — 256-byte logs bloom filter.
// ---------------------------------------------------------------------------

/// Width of an [`EvmBloom`] in bytes (Ethereum logs bloom).
pub const EVM_BLOOM_SIZE: usize = 256;

/// A 256-byte Ethereum logs bloom filter.
#[derive(Clone, Copy, BorshSerialize, BorshDeserialize)]
pub struct EvmBloom([u8; EVM_BLOOM_SIZE]);

// `EvmBloom` is 256 bytes; the `serde_impl_*_fixed_bytes_ref!` macros bottom out
// on serde's fixed-array impls (which only cover N ≤ 32), so hand-roll serde: a
// hex string in human-readable encoders (JSON/RPC), raw bytes otherwise
// (bincode/compact). borsh is handled by the derive above (no array cap).
impl Serialize for EvmBloom {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        if serializer.is_human_readable() { serializer.serialize_str(&self.to_hex()) } else { serializer.serialize_bytes(&self.0) }
    }
}

impl<'de> Deserialize<'de> for EvmBloom {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        if deserializer.is_human_readable() {
            let s = <String as serde::Deserialize>::deserialize(deserializer)?;
            EvmBloom::from_hex(&s).map_err(serde::de::Error::custom)
        } else {
            struct BloomVisitor;
            impl<'de> serde::de::Visitor<'de> for BloomVisitor {
                type Value = EvmBloom;
                fn expecting(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
                    write!(f, "a {EVM_BLOOM_SIZE}-byte EVM logs bloom")
                }
                fn visit_bytes<E: serde::de::Error>(self, v: &[u8]) -> Result<EvmBloom, E> {
                    let arr: [u8; EVM_BLOOM_SIZE] = v.try_into().map_err(E::custom)?;
                    Ok(EvmBloom(arr))
                }
                fn visit_seq<A: serde::de::SeqAccess<'de>>(self, mut seq: A) -> Result<EvmBloom, A::Error> {
                    let mut arr = [0u8; EVM_BLOOM_SIZE];
                    for (i, slot) in arr.iter_mut().enumerate() {
                        *slot = seq.next_element()?.ok_or_else(|| serde::de::Error::invalid_length(i, &self))?;
                    }
                    Ok(EvmBloom(arr))
                }
            }
            deserializer.deserialize_bytes(BloomVisitor)
        }
    }
}

impl EvmBloom {
    #[inline(always)]
    pub const fn from_bytes(bytes: [u8; EVM_BLOOM_SIZE]) -> Self {
        EvmBloom(bytes)
    }

    #[inline(always)]
    pub const fn as_bytes(&self) -> &[u8; EVM_BLOOM_SIZE] {
        &self.0
    }
}

// `[u8; 256]` does not implement `Default` (std only covers N <= 32), so hand-roll.
impl Default for EvmBloom {
    #[inline]
    fn default() -> Self {
        EvmBloom([0u8; EVM_BLOOM_SIZE])
    }
}

impl PartialEq for EvmBloom {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.0 == other.0
    }
}
impl Eq for EvmBloom {}

impl From<[u8; EVM_BLOOM_SIZE]> for EvmBloom {
    fn from(value: [u8; EVM_BLOOM_SIZE]) -> Self {
        EvmBloom(value)
    }
}

impl Debug for EvmBloom {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "EvmBloom([0x{:02x}{:02x}{:02x}{:02x}…; {} bytes])", self.0[0], self.0[1], self.0[2], self.0[3], EVM_BLOOM_SIZE)
    }
}

impl AsRef<[u8]> for EvmBloom {
    #[inline(always)]
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

impl AsRef<[u8; EVM_BLOOM_SIZE]> for EvmBloom {
    #[inline(always)]
    fn as_ref(&self) -> &[u8; EVM_BLOOM_SIZE] {
        &self.0
    }
}

impl ToHex for EvmBloom {
    fn to_hex(&self) -> String {
        let mut hex = vec![0u8; EVM_BLOOM_SIZE * 2];
        faster_hex::hex_encode(&self.0, &mut hex).expect("twice the input size");
        // SAFETY: hex_encode only writes ASCII hex digits.
        unsafe { String::from_utf8_unchecked(hex) }
    }
}

impl FromHex for EvmBloom {
    type Error = faster_hex::Error;
    fn from_hex(hex_str: &str) -> Result<Self, Self::Error> {
        let hex_str = hex_str.strip_prefix("0x").or_else(|| hex_str.strip_prefix("0X")).unwrap_or(hex_str);
        let mut bytes = [0u8; EVM_BLOOM_SIZE];
        faster_hex::hex_decode(hex_str.as_bytes(), &mut bytes)?;
        Ok(EvmBloom(bytes))
    }
}

impl MemSizeEstimator for EvmBloom {}

// ---------------------------------------------------------------------------
// UTXO ↔ EVM op types (design §7 / §8). Types only this pass; the bounded
// validation + UTXO-diff materialization land in P4.
// ---------------------------------------------------------------------------

/// A bounded, producer-selected, consensus-validated EVM system op carried in
/// `EvmExecutionPayload::system_ops` (design §3.1 / §7.3). The op ordering is
/// the payload order, committed by `system_ops_root`.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub enum EvmSystemOp {
    /// Claim an `EVM_DEPOSIT_LOCK` UTXO output and credit the EVM account
    /// (design §7.3). The lock is consumed in the same block's UTXO diff (P4).
    DepositClaim(DepositClaim),
    /// **ADR-0089 Decision 6: a settlement the selected parent's fold decided**, carried by the
    /// producer and validated equal to the list derived from that fold; the settling block burns a
    /// filled buy's escrow into a sink output, refunds a refused one, credits a filled sell.
    MarketSettle(model_market::PalwEvmSettlementV1),
}

impl MemSizeEstimator for EvmSystemOp {}

/// Claims a previously-locked deposit (an unspent `EVM_DEPOSIT_LOCK` output in
/// the `selected_parent(B)` UTXO view) and credits the EVM account (design §7.3).
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct DepositClaim {
    /// The `EVM_DEPOSIT_LOCK` output being claimed.
    pub deposit_outpoint: TransactionOutpoint,
    /// EVM account credited `(amount_sompi − claim_tip_sompi) × EVM_NATIVE_SCALE`
    /// wei. MUST equal the lock output's recorded address.
    pub evm_address: EvmAddress,
    /// Sompi amount. MUST equal the lock output's value.
    pub amount_sompi: u64,
    /// The claim-inclusion incentive (audit AH-1, v0.4 §9.2): credited as
    /// `claim_tip_sompi × EVM_NATIVE_SCALE` wei to the ACCEPTING block's
    /// declared `evm_coinbase`. MUST equal the lock output's recorded tip
    /// (≤ `amount_sompi`, consensus-validated).
    pub claim_tip_sompi: u64,
}

impl MemSizeEstimator for DepositClaim {}

/// A successful withdrawal emitted by the F002 precompile (design §8.1). The
/// executor materializes one synthetic UTXO output per `WithdrawOp` in the
/// block's UTXO diff (P4, §8.3). User-input failures do **not** emit a
/// `WithdrawOp` (they revert the tx, §8.2).
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct WithdrawOp {
    /// Receipt index of the accepted/executed EVM tx that emitted this op (its
    /// position among the block's RECEIPTS, i.e. accepted txs only — NOT the
    /// index within the source payload `transactions`, which differs whenever a
    /// tx ahead of it was skipped, classes 2/3/5). audit #7. The synthetic-UTXO
    /// key is `evm_tx_hash + op_index`, so this field is metadata for
    /// RPC/index/explorer, never a consensus key.
    pub receipt_index: u32,
    /// Index of this op within that tx (a tx may withdraw more than once).
    pub op_index: u32,
    /// keccak256 hash of the withdrawing EVM tx — the [`synthetic_withdrawal_txid`]
    /// key (pre-mining-stable, unlike the accepting block hash; see that fn).
    pub evm_tx_hash: EvmH256,
    /// EVM account debited.
    pub from: EvmAddress,
    /// Destination UTXO script (consensus script-rule validated; failure ⇒ revert).
    pub script_public_key: ScriptPublicKey,
    /// Sompi paid out (= `amount_wei / EVM_NATIVE_SCALE`, exact multiple required).
    pub amount_sompi: u64,
}

impl MemSizeEstimator for WithdrawOp {}

// The `EVM_DEPOSIT_LOCK` UTXO output is represented on the wire by the raw-`u64`
// script encoding parsed into `kaspa_txscript::script_class::EvmDepositLockFields`
// (timeout uses `u64::MAX` = never refundable). A separate in-memory mirror struct
// here previously diverged (an `Option<u64>` timeout) and was never constructed,
// serialized, or read — removed (audit INFO-a) to keep one representation.

// ---------------------------------------------------------------------------
// EvmExecutionPayload — the block-body EVM unit (design §3.1).
// ---------------------------------------------------------------------------

/// The EVM execution payload carried in a block body, separate from the UTXO
/// `transactions` because UTXO txs are DAG-inclusive-accepted while EVM txs are
/// executed via mergeset delayed acceptance (design v0.4 §3): a block's own
/// `transactions` are pure DATA — they are NOT part of this block's own
/// `EvmResult`; they are accepted/executed by the chain block whose mergeset
/// includes this block (its selected child, for a chain block). Only
/// `system_ops` (producer-selected, validated against `selected_parent(B)`)
/// execute in this block itself. Pre-activation blocks (header version &lt;
/// `EVM_HEADER_VERSION`) MUST carry the [`Default`] (empty) payload.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmExecutionPayload {
    /// Bounded, producer-selected system ops (deposit claims), applied before
    /// the accepted user txs and committed by `system_ops_root` in their
    /// payload order. Unlike `transactions`, these execute in THIS block.
    pub system_ops: Vec<EvmSystemOp>,
    /// EIP-2718 typed-transaction bytes, in payload order. Data-only here;
    /// executed by the accepting chain block (design v0.4 §3.1).
    pub transactions: Vec<Vec<u8>>,
    /// The producer's declared EVM coinbase (design v0.4 §8.2): receives the
    /// priority fees of THIS payload's txs when they are accepted (wherever
    /// that happens), and is the `COINBASE`/`block.coinbase` value of the EVM
    /// block this block forms when it is a chain block.
    pub evm_coinbase: EvmAddress,
    /// Optional miner extra data (consensus-rule length-capped at activation).
    pub extra_data: Vec<u8>,
}

/// kaspa-pq EVM Lane v0.4 (§15 step 6 / §16): the producer-side inputs for the
/// node's OWN template payload — the mempool-selected raw EIP-2718 txs plus the
/// miner's declared EVM coinbase (`--evm-fee-recipient`, §8.2: receives the
/// priority fees of this payload's txs when they are accepted). `Default` = no
/// candidates + zero coinbase = the empty pre-§16 payload.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct EvmTemplateData {
    pub evm_coinbase: EvmAddress,
    pub transactions: Vec<Vec<u8>>,
    /// §9.2 producer-selected deposit claims (resolved + pre-validated by the
    /// node from submitted lock outpoints). The VSP template path re-validates
    /// each against the live selected-parent claim view before committing, so a
    /// stale claim is dropped rather than invalidating the node's own block.
    pub system_ops: Vec<DepositClaim>,
}

impl EvmExecutionPayload {
    /// An EVM-inert payload (`== Default`): no system ops, no txs, no extra
    /// data, zero coinbase. Pre-activation blocks must satisfy this.
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.system_ops.is_empty() && self.transactions.is_empty() && self.extra_data.is_empty() && self.evm_coinbase.is_zero()
    }

    /// The canonical commitment encoding of this payload (borsh, design v0.4
    /// §4.1) — the byte string [`payload_hash_of_bytes`] digests and the D4
    /// inclusion-side size cap measures.
    #[inline]
    pub fn payload_bytes(&self) -> Vec<u8> {
        borsh::to_vec(self).expect("EvmExecutionPayload borsh serialization is infallible")
    }

    /// `EvmPayloadHash(B)` (design v0.4 §4.1) — keyed BLAKE2b-512 under
    /// [`MISAKA_EVM_PAYLOAD_HASH_CONTEXT`] over this payload's borsh encoding,
    /// carried in `Header::evm_payload_hash`. The DATA commitment: it binds the
    /// payload bytes a producer includes, independent of who later accepts and
    /// executes them. Pure (no revm), so every build can verify it at body
    /// validation.
    #[inline]
    pub fn payload_hash(&self) -> Hash64 {
        payload_hash_of_bytes(&self.payload_bytes())
    }
}

/// [`EvmExecutionPayload::payload_hash`] over pre-serialized payload bytes
/// (lets body validation serialize once for both the size cap and the digest).
#[inline]
pub fn payload_hash_of_bytes(bytes: &[u8]) -> Hash64 {
    blake2b_512_keyed(MISAKA_EVM_PAYLOAD_HASH_CONTEXT, bytes)
}

/// **Bridge audit BR-1 (2026-09-25; node-only): is a delivered EVM payload the one the block id
/// commits to?** The block id is the header hash. A v2+ header commits to its payload only through
/// `evm_payload_hash`; a pre-v2 header commits to "no payload", and its two EVM header fields are
/// outside its hash preimage, so they must be zero (`NonZeroEvmHeaderFieldsBeforeActivation`).
///
/// A body that fails this is a bad DELIVERY of the block, not a verdict on the block id: whoever
/// relays a body first chooses these bytes. P2P relay, IBD body download and RPC `submitBlock`
/// refuse such a delivery before consensus (the peer is blamed), and the body processor never
/// persists `StatusInvalid` for the matching rule errors. It is exactly the check
/// `check_evm_payload` runs first, so it accepts every body consensus accepts.
pub fn evm_payload_matches_header(header: &crate::header::Header, payload: &EvmExecutionPayload) -> bool {
    if header.version < crate::constants::EVM_HEADER_VERSION {
        return payload.is_empty() && header.evm_payload_hash == Hash64::default() && header.evm_commitment_root == Hash64::default();
    }
    header.evm_payload_hash == payload.payload_hash()
}

impl MemSizeEstimator for EvmExecutionPayload {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
            + self.transactions.capacity() * size_of::<Vec<u8>>()
            + self.transactions.iter().map(|t| t.capacity()).sum::<usize>()
            + self.system_ops.capacity() * size_of::<EvmSystemOp>()
            + self.extra_data.capacity()
    }
}

// ---------------------------------------------------------------------------
// EvmExecutionHeader — executor output, committed via evm_commitment_root.
// ---------------------------------------------------------------------------

/// The consensus-committed EVM execution header (design §3.2). Its keyed
/// BLAKE2b-512 digest under [`MISAKA_EVM_COMMITMENT_CONTEXT`] is carried in
/// `Header::evm_commitment_root`; the verifier re-executes, rebuilds this
/// header, and checks the digest. The current L1 block hash and current EVM
/// block hash are intentionally **absent** (they would be a circular
/// dependency, design §4.2); only ancestor-derived values appear.
///
/// **FROZEN FIELD ORDER (hard fork to change once testnet activates):** the
/// commitment preimage is this struct's borsh encoding in declared order
/// ([`EvmExecutionHeader::commitment_preimage`]). All fields are fixed-width, so
/// borsh is a deterministic concatenation. Never reorder, remove, or change the
/// width of a field below after activation.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmExecutionHeader {
    /// `EvmStateRoot(selected_parent(B))` — the parent EVM state this block executed against.
    pub parent_state_root: EvmH256,
    /// keccak256 MPT state root after applying system ops + user txs.
    pub state_root: EvmH256,
    /// keccak256 MPT root over the executed `transactions`.
    pub transactions_root: EvmH256,
    /// keccak256 MPT root over the per-tx receipts.
    pub receipts_root: EvmH256,
    /// MISAKA keyed root over the ordered `system_ops` (`MISAKA_EVM_SYSTEM_OPS_V2`).
    pub system_ops_root: EvmH256,
    /// MISAKA keyed root over the ordered `WithdrawOp`s (`MISAKA_EVM_WITHDRAWAL_V2`).
    pub withdrawals_root: EvmH256,
    /// MISAKA keyed root over the applied deposit-claim queue (`MISAKA_EVM_DEPOSIT_CLAIM_V2`).
    pub deposit_claim_queue_root: EvmH256,
    /// Ethereum logs bloom over all receipts' logs.
    pub logs_bloom: EvmBloom,
    pub gas_used: u64,
    pub gas_limit: u64,
    /// EIP-1559 base fee (wei). 32-byte to match Ethereum `uint256`; the
    /// executor converts to/from `alloy_primitives::U256`.
    pub base_fee_per_gas: EvmU256,
    /// Selected-parent-tree height: `evm_number(selected_parent) + 1` (§5.2).
    pub evm_number: u64,
    /// Non-decreasing EVM logical time `max(header_ts_sec, parent_ts)` (design
    /// v0.4 §5.3, D6 — replaced the v0.2 strict-monotone clamp; consecutive EVM
    /// blocks may share a timestamp).
    pub evm_timestamp_sec: u64,
    pub evm_chain_id: u64,
    /// The accepting block's declared `evm_coinbase` — the `COINBASE` opcode
    /// value of this EVM block (design v0.4 §8.2, audit AM-3). Priority fees
    /// route per-tx to each PAYLOAD block's coinbase, not (necessarily) here.
    pub coinbase: EvmAddress,
    /// Accepted-and-executed user txs in this block's mergeset acceptance
    /// (skips excluded; class-4 executed failures included). (v0.4 §4.2)
    pub accepted_tx_count: u32,
    /// Deterministically skipped user txs (classes 2/3/5). Statistics only —
    /// skips leave no other trace in the execution result. (v0.4 §4.2/§6)
    pub skipped_tx_count: u32,
    /// Total native (wei) balance held across ALL EVM accounts after this
    /// block — the O(1) supply-invariant accumulator (v0.4 §9.1, audit AM-5):
    /// `total(B) = total(parent) + deposits(B) − withdrawals(B) − burn(B)`.
    ///
    /// Past `Params::evm_bridge_ledger_activation_daa_score` this is the **bridge ledger**: the
    /// same identity (plus market credits, less market escrow burns), CHECKED, and a user tx that
    /// would take it below zero is skipped — so it bounds what the L1 materializes by what the L1
    /// bridged in, not by what the EVM's balances say. Below the fence it saturates.
    pub evm_total_native_balance: EvmU256,
    /// Cumulative EVM basefee burn up to and including this block (design §9.2).
    pub evm_burn_accumulator: EvmU256,
}

impl EvmExecutionHeader {
    /// The canonical commitment preimage = the borsh encoding of this header in
    /// declared field order. All fields are fixed-width, so borsh is a stable,
    /// deterministic concatenation (design §3.2 `SCALE(EvmExecutionHeader)`).
    #[inline]
    pub fn commitment_preimage(&self) -> Vec<u8> {
        borsh::to_vec(self).expect("EvmExecutionHeader borsh serialization is infallible")
    }

    /// `evm_commitment_root(B)` (design §3.2) — keyed BLAKE2b-512 over the
    /// canonical preimage under [`MISAKA_EVM_COMMITMENT_CONTEXT`], producing the
    /// 64-byte digest carried in `Header::evm_commitment_root`. Pure (no revm),
    /// so a non-`evm` build can still recompute/verify the L1 field.
    #[inline]
    pub fn commitment_root(&self) -> Hash64 {
        blake2b_512_keyed(MISAKA_EVM_COMMITMENT_CONTEXT, &self.commitment_preimage())
    }
}

impl MemSizeEstimator for EvmExecutionHeader {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
    }
}

// ---------------------------------------------------------------------------
// Executor output (design §6 / §11.1). Returned by the `kaspa-evm` executor
// (P2) and persisted across the EVM stores (P3). Not consensus-committed
// directly — the committed digest is `header.commitment_root()`.
// ---------------------------------------------------------------------------

/// A single EVM log entry.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmLog {
    pub address: EvmAddress,
    pub topics: Vec<EvmH256>,
    pub data: Vec<u8>,
}

impl MemSizeEstimator for EvmLog {}

/// A per-transaction EVM receipt. `succeeded == false` for a user-caused
/// failure (revert / out-of-gas / bad nonce) — which is NOT block-invalid
/// (design §6.3 / §8.2); gas is still consumed.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmReceipt {
    pub succeeded: bool,
    pub cumulative_gas_used: u64,
    pub gas_used: u64,
    pub logs: Vec<EvmLog>,
}

impl MemSizeEstimator for EvmReceipt {}

/// The full output of executing one block's EVM lane. The committed
/// `header.commitment_root()` equals the L1 `Header::evm_commitment_root`; the
/// rest is store/RPC data and the UTXO-diff source for P4.
/// Per-candidate outcome of one acceptance run (§6.1), parallel to the input
/// `AcceptedEvmTxs(B)` order. Store/RPC data ONLY — outcomes never enter the
/// commitment preimage (the committed surface is `EvmExecutionHeader`), so the
/// receipt/lookup indexes can evolve without a fork.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub enum EvmCandidateOutcome {
    /// Executed: `receipt_index` points into `EvmExecutionResult::receipts`.
    Accepted { receipt_index: u32 },
    /// Deterministically skipped with the §6.1 class (2 = acceptance-invalid
    /// [subsumes 3], 5 = over-cap prefix-take).
    Skipped { class: u8 },
}

impl MemSizeEstimator for EvmCandidateOutcome {}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmExecutionResult {
    pub header: EvmExecutionHeader,
    pub receipts: Vec<EvmReceipt>,
    /// Withdrawal ops in receipt/log order → synthetic UTXO outputs (P4).
    pub withdrawals: Vec<WithdrawOp>,
    /// Deposit claims applied this block → consumed lock outputs (P4).
    pub applied_deposit_claims: Vec<DepositClaim>,
    /// §16: per-candidate outcomes, parallel to the acceptance input order
    /// (feeds the tx-lookup index; NOT part of the commitment).
    pub candidate_outcomes: Vec<EvmCandidateOutcome>,
    /// **ADR-0089 Decision 5: the actions the writer queued in this block**, scanned from its
    /// `ActionQueued` logs in log order and handed to the same block's PALW transition. Transient:
    /// never stored, never part of the commitment (the logs are), so the persisted layout is the
    /// one every shipped build reads.
    #[borsh(skip)]
    #[serde(skip)]
    pub market_actions: Vec<model_market::PalwEvmMarketActionV1>,
}

impl MemSizeEstimator for EvmExecutionResult {}

/// The receipts row of one ACCEPTING chain block (§16, store prefix 203):
/// receipts in accepted order plus the parallel Ethereum tx hashes (so
/// `eth_getTransactionReceipt` can return `transactionHash` without re-reading
/// payloads). Store/RPC data only — never part of the commitment.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmBlockReceipts {
    pub receipts: Vec<EvmReceipt>,
    pub tx_hashes: Vec<EvmH256>,
}

impl MemSizeEstimator for EvmBlockReceipts {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
            + self.tx_hashes.capacity() * size_of::<EvmH256>()
            + self.receipts.capacity() * size_of::<EvmReceipt>()
            + self
                .receipts
                .iter()
                .map(|r| r.logs.iter().map(|l| l.data.capacity() + l.topics.capacity() * 32).sum::<usize>())
                .sum::<usize>()
    }
}

/// The tx-lookup row (§16, store prefix 204): where a tx hash was SEEN
/// (payload blocks, DA visibility), where it was ACCEPTED (executing chain
/// blocks — side branches allowed, the reader resolves canonicality against
/// the current chain), and the most recent skip class when never accepted
/// (informational, §6.1). All vecs are bounded at write time.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmTxLocations {
    /// Payload blocks carrying the raw tx (bounded; inclusion ≠ execution).
    pub included_in: Vec<Hash64>,
    /// `(accepting chain block, receipt index)` per acceptance (bounded).
    pub accepted_in: Vec<(Hash64, u32)>,
    /// §6.1 class of the most recent skip, while never accepted (2 or 5).
    pub last_skip_class: Option<u8>,
}

impl MemSizeEstimator for EvmTxLocations {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>() + self.included_in.capacity() * size_of::<Hash64>() + self.accepted_in.capacity() * (size_of::<Hash64>() + 4)
    }
}

/// Write-time bounds for [`EvmTxLocations`] (DoS caps on a single row).
pub const MAX_TX_LOCATION_INCLUSIONS: usize = 16;
pub const MAX_TX_LOCATION_ACCEPTANCES: usize = 8;

/// RPC raw-tx record (prefix 217, audit R-2): the raw EIP-2718 bytes of an EVM
/// tx keyed by its hash, plus the payload block that carried it. Lets
/// `eth_getTransactionByHash`/`getTransactionReceipt` resolve the tx WITHOUT the
/// bounded `EvmTxLocations.included_in` scan (which evicts past 16 inclusions).
/// Store/RPC data only — never part of a commitment.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmRawTx {
    /// The canonical EIP-2718 transaction bytes (`keccak256` ⇒ the tx-hash key).
    pub raw: Vec<u8>,
    /// The payload block that carried the tx (DA visibility / §7.1 origin).
    pub payload_block: Hash64,
}

impl MemSizeEstimator for EvmRawTx {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>() + self.raw.capacity()
    }
}

// ---------------------------------------------------------------------------
// EvmTraceReplayBodyV1 (design §11.2, store prefix 219) — the per-accepting-block
// deterministic REPLAY PLAN for `debug_traceTransaction`. Store/RPC/replay data
// ONLY; never part of any commitment (the committed surface is
// `EvmExecutionHeader`), so it can evolve without a fork.
// ---------------------------------------------------------------------------

/// The L1-header-derived inputs to the EVM env derivation (`kaspa_evm::env::derive_env`)
/// that the trace store must carry. The other two `derive_env` inputs — the
/// `selected_parent`'s committed `EvmExecutionHeader` (prefix 201) and the
/// `selected_parent` hash — are fetched/held separately, so a replay re-derives the
/// env through the *identical* production code path (EIP-1559 base fee from the
/// parent header, keyed-BLAKE2b prevrandao). Holding the raw inputs rather than a
/// materialized env means a trace can never diverge from the committed execution by
/// an env-reconstruction bug. Design §11.2 `EvmReplayEnv`.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmReplayEnv {
    /// `B.header.timestamp` in milliseconds (the EVM logical-clock input).
    pub header_timestamp_ms: u64,
    /// `B.header.blue_work` big-endian bytes (prevrandao input, frozen order).
    pub blue_work_be: Vec<u8>,
    /// `B.header.daa_score` (prevrandao input + the activation-fence selector).
    pub daa_score: u64,
    /// The accepting block's declared `evm_coinbase` — the `COINBASE` opcode value
    /// and the deposit-claim tip recipient (design §8.2). NOT the per-tx priority
    /// fee recipient, which is [`EvmReplayTx::payload_coinbase`].
    pub coinbase: EvmAddress,
}

impl MemSizeEstimator for EvmReplayEnv {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>() + self.blue_work_be.capacity()
    }
}

/// One acceptance candidate of an accepting block, in the exact order the executor
/// saw it (`AcceptedEvmTxs(B)` pre-prefix-take). A replay feeds the FULL candidate
/// list — accepted AND deterministically-skipped — to `execute_block_evm` so the
/// gas pool (v1 strict prefix-take / v2 sequential) reproduces the identical
/// accept/skip/gas decisions, and therefore the identical pre-state for the traced
/// tx. Storing only the accepted txs would be fragile against the gas-pool
/// semantics (e.g. v1 class-2 budget consumption). Design §11.2 `EvmExecutedTxReplay`,
/// extended to carry the recorded outcome and the skipped candidates.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmReplayTx {
    /// keccak256 of `raw` — the `debug_traceTransaction` lookup key.
    pub tx_hash: EvmH256,
    /// The canonical EIP-2718 transaction bytes (self-contained, so a trace does
    /// not depend on the raw-tx index at prefix 217, which is keyed by tx hash and
    /// not pruned with this block).
    pub raw: Vec<u8>,
    /// `evm_coinbase` of the payload block that carried this tx — the recipient of
    /// this tx's priority fee (design §8.1, D3).
    pub payload_coinbase: EvmAddress,
    /// The payload (DAG) block that carried the tx (§7.1 origin; returned to
    /// callers as the `misakaOriginatingPayloadBlock` trace extension, §11.4).
    pub originating_payload_block: Hash64,
    /// The deterministic outcome the accepting block recorded for this candidate
    /// (`Accepted{receipt_index}` / `Skipped{class}`). The replay reproduces this
    /// from scratch and cross-checks it; a divergence is a `replay mismatch`.
    pub outcome: EvmCandidateOutcome,
}

impl MemSizeEstimator for EvmReplayTx {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>() + self.raw.capacity()
    }
}

/// The per-accepting-block deterministic REPLAY PLAN for `debug_traceTransaction`
/// (design §11.2), keyed in the store by the accepting L1 `BlockHash` (so the
/// accepting block is NOT duplicated in the value). The committed receipt-hash list
/// alone cannot reproduce an exact re-execution; this captures the precise ordered
/// acceptance the chain block performed — its env inputs, its own `system_ops`, and
/// the full acceptance-candidate list — so the RPC layer can replay it against the
/// selected parent's committed post-state WITHOUT re-deriving the mergeset (a
/// consensus-sensitive operation). Store/RPC/replay data ONLY — never part of any
/// commitment. The `V1` suffix is the format version: a later format is a new type
/// read alongside this one.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmTraceReplayBodyV1 {
    /// `selected_parent(B)` block hash — the block whose committed EVM post-state
    /// is the replay PRE-state (loaded from `EvmStateDiff`/prefix 206) and whose
    /// committed `EvmExecutionHeader` (prefix 201) is the `derive_env` parent. Also
    /// the frozen prevrandao preimage input.
    pub selected_parent: Hash64,
    /// The L1-header-derived env inputs (§11.2).
    pub env: EvmReplayEnv,
    /// The accepting block's own `system_ops` (deposit claims), applied before the
    /// user txs in payload order — exactly `EvmExecutionPayload::system_ops`.
    pub system_ops: Vec<EvmSystemOp>,
    /// The full ordered acceptance-candidate list (accepted + skipped), parallel to
    /// the executor's acceptance input.
    pub txs: Vec<EvmReplayTx>,
}

impl MemSizeEstimator for EvmTraceReplayBodyV1 {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
            + self.env.blue_work_be.capacity()
            + self.system_ops.capacity() * size_of::<EvmSystemOp>()
            + self.txs.capacity() * size_of::<EvmReplayTx>()
            + self.txs.iter().map(|t| t.raw.capacity()).sum::<usize>()
    }
}

// ---------------------------------------------------------------------------
// §12 Archive / Historical state — checkpoint + diff v2 (design §12.3). The
// per-block full snapshot (`EvmStateSnapshot`, prefix 206) is the hot/reorg-window
// representation; for long-term retention an archive node stores compact forward
// DIFFS between consecutive canonical blocks plus periodic full CHECKPOINTS, and
// reconstructs any historical state by seeding the nearest ancestor checkpoint and
// replaying diffs forward (design §12.4). Code bytes are content-addressed
// (`code_hash → code`) so a diff/checkpoint carries only the hash. All RPC/archive
// data — never part of any commitment.
// ---------------------------------------------------------------------------

/// The non-storage core of an EVM account (the fields outside the storage trie).
/// `code_hash == KECCAK_EMPTY` ⇒ no code; the code bytes live in the
/// content-addressed code store keyed by this hash (design §12.3).
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountCore {
    pub nonce: u64,
    pub balance: EvmU256,
    pub code_hash: EvmH256,
}

impl MemSizeEstimator for AccountCore {}

/// A single storage-slot transition within a block (design §12.3). `before`/`after`
/// are the slot values; a freshly-set slot has `before == 0`, a cleared slot has
/// `after == 0`.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct StorageChange {
    pub slot: EvmU256,
    pub before: EvmU256,
    pub after: EvmU256,
}

impl MemSizeEstimator for StorageChange {}

/// One account's change across a block (design §12.3). `before = None` ⇒ the account
/// did not exist before (created); `after = None` ⇒ it was destroyed (self-destruct);
/// `storage_changes` lists only the slots whose value changed.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountChange {
    pub address: EvmAddress,
    pub before: Option<AccountCore>,
    pub after: Option<AccountCore>,
    pub storage_changes: Vec<StorageChange>,
}

impl MemSizeEstimator for AccountChange {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>() + self.storage_changes.capacity() * size_of::<StorageChange>()
    }
}

/// The forward state DIFF of one canonical block over its parent (design §12.3,
/// store prefix 220). Applying a block's diff to its parent's reconstructed state
/// yields the block's state; an archive node stores one per canonical block and a
/// `recent` node GCs them past its retention window. RPC/archive data only — never
/// part of any commitment.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmStateDiffV2 {
    /// The canonical L1 block this diff is for.
    pub block: Hash64,
    /// `selected_parent(block)` — the diff is relative to this parent's state.
    pub parent: Hash64,
    pub account_changes: Vec<AccountChange>,
}

impl MemSizeEstimator for EvmStateDiffV2 {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
            + self.account_changes.capacity() * size_of::<AccountChange>()
            + self.account_changes.iter().map(|c| c.storage_changes.capacity() * size_of::<StorageChange>()).sum::<usize>()
    }
}

/// A periodic full-state CHECKPOINT (design §12.3, store prefix 221) — the anchor a
/// historical reconstruction seeds from before replaying forward diffs. Written
/// every N canonical blocks (initial 2,048) and at each pruning-point advance. The
/// `compressed_snapshot` is an opaque compressed encoding of the full state at
/// `block`; `checksum` guards it; `state_root` must match the block's committed EVM
/// state root (a mismatch is data corruption, design §12.4). RPC/archive data only.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmStateCheckpointV1 {
    pub block: Hash64,
    pub evm_number: u64,
    pub state_root: EvmH256,
    pub compressed_snapshot: Vec<u8>,
    pub checksum: [u8; 32],
}

impl MemSizeEstimator for EvmStateCheckpointV1 {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>() + self.compressed_snapshot.capacity()
    }
}

/// A node's EVM state-history retention mode (design §12.2, `--evm-history-mode`).
/// Controls how far back historical state queries / traces can serve; RPC block,
/// tx, receipt and log history are kept independently (design §12.1). Default
/// [`Self::Recent`].
/// **ADR-0109 Decision 1 — one row of the node-local deposit-lock index**: an `EVM_DEPOSIT_LOCK`
/// output currently in the virtual UTXO set, reduced to what a claim for it needs. Derived from the
/// virtual UTXO diff and never declared (ADR-0109 SA-2); read only by the template path, which
/// re-validates the claim it makes from it against the same view (`prepare_deposit_claims`, SA-1).
/// Node-local: nothing on the wire and no commitment carries it.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmDepositLockRecord {
    pub evm_address: EvmAddress,
    pub amount_sompi: u64,
    pub claim_tip_sompi: u64,
    /// First DAA score at which the refund path opens; a claim is valid strictly below it.
    pub timeout_daa_score: u64,
    /// `UtxoEntry::block_daa_score` of the lock output — the template claims oldest first.
    pub block_daa_score: u64,
}

impl EvmDepositLockRecord {
    /// The claim this lock is — the same fields the `submitEvmDepositClaim` RPC derives from the
    /// live lock, so an indexed claim and a submitted one for the same outpoint are equal.
    pub fn claim(&self, deposit_outpoint: TransactionOutpoint) -> DepositClaim {
        DepositClaim {
            deposit_outpoint,
            evm_address: self.evm_address,
            amount_sompi: self.amount_sompi,
            claim_tip_sompi: self.claim_tip_sompi,
        }
    }
}

impl MemSizeEstimator for EvmDepositLockRecord {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
    }
}

/// **ADR-0109 Decision 2 — what a stale DNS-finality anchor does to the EVM lane on this node.**
/// Node policy, never block validity: a block built either way validates on every node.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum EvmBridgeFinalityPolicy {
    /// The producer includes deposit claims, EVM transactions and its EVM coinbase whatever the
    /// anchor's distance, and the claim RPC queues whatever the distance; a reader who wants the
    /// two-resource-confirmed state asks the eth RPC for the `safe` tag, which is the DNS-confirmed
    /// anchor (Decision 4). The default on every network.
    #[default]
    Label,
    /// The behaviour before ADR-0109: an empty EVM payload and a refused claim RPC while the anchor
    /// is unconfirmed or farther below the sink than `dns_bridge_max_anchor_distance_blue_score`.
    Pause,
}

impl EvmBridgeFinalityPolicy {
    /// Parse the `--evm-bridge-finality` value; `None` for an unknown string.
    pub fn from_str_opt(s: &str) -> Option<Self> {
        match s.to_ascii_lowercase().as_str() {
            "label" => Some(Self::Label),
            "pause" => Some(Self::Pause),
            _ => None,
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Label => "label",
            Self::Pause => "pause",
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "lowercase")]
pub enum EvmHistoryMode {
    /// Latest state plus only the reorg/trace minimum window.
    Head,
    /// Latest plus a configurable recent canonical history (the recommended default).
    #[default]
    Recent,
    /// All canonical state history since EVM activation (full diff/checkpoint retention).
    Archive,
}

impl EvmHistoryMode {
    /// Parse the `--evm-history-mode` value; `None` for an unknown string.
    pub fn from_str_opt(s: &str) -> Option<Self> {
        match s.to_ascii_lowercase().as_str() {
            "head" => Some(Self::Head),
            "recent" => Some(Self::Recent),
            "archive" => Some(Self::Archive),
            _ => None,
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Head => "head",
            Self::Recent => "recent",
            Self::Archive => "archive",
        }
    }

    /// §12 retention policy — whether this mode WRITES the per-block archive
    /// diff/checkpoint (prefixes 220/221). `head` keeps no long-term state history
    /// (its reorg/trace window is served by the hot snapshot + trace stores), so
    /// it writes none; `recent` and `archive` write them.
    pub fn writes_state_history(self) -> bool {
        !matches!(self, Self::Head)
    }

    /// §12 retention policy — whether a pruned block's EVM header + diff +
    /// checkpoint are PRESERVED past pruning so its state stays reconstructable
    /// ([`crate::api::ConsensusApi::reconstruct_evm_state_at`]). Only `archive`;
    /// `head`/`recent` reclaim them with the block. (The content-addressed code
    /// store is never per-block pruned in any mode — its entries are shared.)
    pub fn retains_state_history_past_pruning(self) -> bool {
        matches!(self, Self::Archive)
    }
}

/// A canonical-resolved receipt view (§16 `eth_getTransactionReceipt`
/// semantics): the ACCEPTING chain block currently on the selected chain, its
/// EVM number, and the executed receipt. `None` upstream = the tx is not
/// accepted under the current chain (it may be included-but-skipped, pending,
/// or on an orphaned branch — `EvmTxLocations` tells which).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EvmTxReceiptView {
    pub accepting_block: Hash64,
    pub evm_number: u64,
    pub receipt_index: u32,
    /// Block-global index of this receipt's FIRST log = the sum of log counts of
    /// all receipts before it in the accepting block. The eth-rpc adapter renders
    /// each log's `logIndex` as `log_index_offset + i` so a receipt's `logIndex`
    /// matches `eth_getLogs` (audit H-05 — both must be block-global).
    pub log_index_offset: u32,
    pub receipt: EvmReceipt,
}

/// A canonical-resolved EVM "block" for the eth-rpc adapter (§16
/// `eth_getBlockByNumber` / `eth_getBlockByHash`): the executed header, the
/// accepting L1 block hash (its first 32 bytes are the eth-rpc `blockHash`), and
/// the block's accepted tx hashes (in accepted order). Store/RPC data only —
/// never part of a commitment.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EvmBlockResponse {
    pub header: EvmExecutionHeader,
    pub l1_hash: Hash64,
    pub tx_hashes: Vec<EvmH256>,
    /// RPC §7.3 `size`: the byte length of the block's accepted transaction data
    /// (sum of raw EIP-2718 tx bytes; was hardcoded `0x0`). 0 for an empty block.
    pub encoded_size: u64,
}

/// One resolved EVM log for `eth_getLogs` (§16): the log plus its canonical
/// block/tx context. `block_l1_hash`'s first 32 bytes are the eth-rpc `blockHash`.
/// Store/RPC data only — never part of a commitment.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EvmLogEntry {
    pub address: EvmAddress,
    pub topics: Vec<EvmH256>,
    pub data: Vec<u8>,
    pub block_number: u64,
    pub block_l1_hash: Hash64,
    pub tx_hash: EvmH256,
    /// Receipt index = transaction index within the accepting block.
    pub tx_index: u32,
    /// Log index within the accepting block (across all its receipts).
    pub log_index: u32,
}

// ---------------------------------------------------------------------------
// EvmStateSnapshot — persisted full EVM account state (design §11, P3).
// ---------------------------------------------------------------------------

/// One account in a persisted EVM state snapshot. Secp-free + borsh, so the
/// consensus stores (P3, prefix 206) can persist EVM state without pulling revm:
/// the `evm`-feature executor converts `EvmAccountSnapshot <-> revm AccountInfo`
/// at its boundary. `storage` is sorted by slot (deterministic encoding).
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmAccountSnapshot {
    pub address: EvmAddress,
    pub nonce: u64,
    pub balance: EvmU256,
    pub code_hash: EvmH256,
    /// Account bytecode (empty for an EOA).
    pub code: Vec<u8>,
    /// Non-zero storage slots, sorted by slot key.
    pub storage: Vec<(EvmU256, EvmU256)>,
}

impl MemSizeEstimator for EvmAccountSnapshot {}

// ---------------------------------------------------------------------------
// C-01 state backend (design v0.1, Stage 1): the flat latest-canonical state.
// One row per account in the CURRENT canonical state (NOT per block), so storage
// is O(state) instead of the per-block snapshot's O(state × blocks). Code is
// content-addressed (prefix 222, by `code_hash`) — NOT inlined here. RPC/state
// data only; the committed `state_root` is recomputed from these rows and must be
// byte-identical to the snapshot path (consensus-NEUTRAL — never a fork).
// ---------------------------------------------------------------------------

/// One account in the flat latest-canonical state (C-01 Stage 1). Mirrors an
/// [`EvmAccountSnapshot`] minus the inlined `code` (resolved via the
/// content-addressed code store by `core.code_hash`). `storage` is the account's
/// non-zero slots, sorted by slot (deterministic borsh).
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct FlatAccount {
    pub core: AccountCore,
    pub storage: Vec<(EvmU256, EvmU256)>,
}

impl MemSizeEstimator for FlatAccount {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>() + self.storage.capacity() * size_of::<(EvmU256, EvmU256)>()
    }
}

impl FlatAccount {
    /// Build from a canonical [`EvmAccountSnapshot`] (drops the inlined code; the
    /// `code_hash` already identifies it in the content-addressed store).
    pub fn from_snapshot(a: &EvmAccountSnapshot) -> Self {
        Self { core: AccountCore { nonce: a.nonce, balance: a.balance, code_hash: a.code_hash }, storage: a.storage.clone() }
    }

    /// Materialize a canonical [`EvmAccountSnapshot`] at `address`, resolving the
    /// code bytes via `code_resolver` (empty for an EOA). Used to rebuild a full
    /// snapshot / seed the executor.
    pub fn to_snapshot(&self, address: EvmAddress, code: Vec<u8>) -> EvmAccountSnapshot {
        EvmAccountSnapshot {
            address,
            nonce: self.core.nonce,
            balance: self.core.balance,
            code_hash: self.core.code_hash,
            code,
            storage: self.storage.clone(),
        }
    }
}

/// The flat state's current canonical pointer (C-01 Stage 1, prefix 231): the
/// block whose committed `state_root` the flat rows currently materialize. Updated
/// atomically with the flat-store writes; a reorg re-bases the flat store and this
/// pointer together. Store/state data only.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmLatestStatePtr {
    pub canonical_head: Hash64,
    pub state_root: EvmH256,
}

impl MemSizeEstimator for EvmLatestStatePtr {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
    }
}

/// C-01 Stage 1 (S7, audit H-03): the result of an O(1) flat point-lookup of one
/// account at the canonical head, the fast path for `eth_getBalance` /
/// `getTransactionCount` / `getCode` / `getStorageAt` that avoids materializing the
/// whole state (the full-state RPC read H-03 flags).
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum FlatHeadAccount {
    /// The flat store is NOT materialized at the current canonical head (the latest
    /// pointer is absent or stale — e.g. the shadow state backend is disabled, or a
    /// re-base is mid-flight, or a flat-store read hiccupped). The caller must fall
    /// back to the authoritative full-snapshot path; the flat fast path is never
    /// authoritative on its own.
    Stale,
    /// The flat store IS at the current head; the account at the queried address
    /// (`None` = the account does not exist at head). Byte-identical to what the
    /// authoritative snapshot path returns (the shadow differential guarantees it).
    AtHead(Option<EvmAccountSnapshot>),
}

/// A full EVM account-state snapshot after a block (design §11.1). P3 stores one
/// per block hash to seed the executor for the block's selected children; a later
/// phase replaces this O(state) form with an incremental persistent trie.
/// Accounts are sorted by address (deterministic encoding). The empty snapshot is
/// the EVM genesis state (root = `EVM_GENESIS_STATE_ROOT`).
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct EvmStateSnapshot {
    pub accounts: Vec<EvmAccountSnapshot>,
}

impl EvmStateSnapshot {
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.accounts.is_empty()
    }
}

impl MemSizeEstimator for EvmStateSnapshot {
    // Implemented (not the panicking default) so the P3 store is safe under any
    // cache policy — the documented validator-attestation crash was a Vec-valued
    // store left on the default `unimplemented!()` estimator.
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
            + self.accounts.capacity() * size_of::<EvmAccountSnapshot>()
            + self.accounts.iter().map(|a| a.code.capacity() + a.storage.capacity() * size_of::<(EvmU256, EvmU256)>()).sum::<usize>()
    }
}

/// The three canonical EVM head pointers (design §10.3 / §11.1). A virtual reorg
/// only updates these — it never re-executes (design §2.3 / §10.1). `latest` =
/// virtual selected-chain head; `safe` = a blue_work-threshold ancestor;
/// `finalized` = the finality / pruning / DNS anchor. (P3 persists them; the
/// blue_work / finality selection lands with the hot-path hook.)
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize, BorshSerialize, BorshDeserialize)]
#[serde(rename_all = "camelCase")]
pub struct CanonicalEvmHeads {
    pub latest: Hash64,
    pub safe: Hash64,
    pub finalized: Hash64,
}

impl CanonicalEvmHeads {
    /// Zero is the legacy row's absent-pointer encoding; the RFC-0012 snapshot exposes Option.
    pub fn safe_head(self) -> Option<Hash64> { (self.safe != Hash64::default()).then_some(self.safe) }
    pub fn finalized_head(self) -> Option<Hash64> { (self.finalized != Hash64::default()).then_some(self.finalized) }
    pub fn latest_head(self) -> Option<Hash64> { (self.latest != Hash64::default()).then_some(self.latest) }
}

impl MemSizeEstimator for CanonicalEvmHeads {
    fn estimate_mem_bytes(&self) -> usize {
        size_of::<Self>()
    }
}

#[cfg(test)]
mod adr0139_gas_cap_tests {
    use super::*;

    fn use_at(span: u64, round: u64, permit_index: u16) -> crate::palw_execution_lane_v1::PalwExecPermitUseV1 {
        crate::palw_execution_lane_v1::PalwExecPermitUseV1 { span, round, permit_index }
    }

    #[test]
    fn one_round_buys_one_budget_however_many_blocks_or_permits_it_carries() {
        // **The inflation question.** A producer that fills one round with blocks, or takes several
        // permit indices of one round, buys ONE budget: the count is over distinct rounds.
        assert_eq!(evm_distinct_permitted_rounds_v1(&[]), 0, "nothing merged, nothing bought");
        assert_eq!(evm_distinct_permitted_rounds_v1(&[use_at(1, 7, 0)]), 1);
        assert_eq!(evm_distinct_permitted_rounds_v1(&[use_at(1, 7, 0), use_at(1, 7, 1)]), 1, "two permits of one round: one");
        assert_eq!(
            evm_distinct_permitted_rounds_v1(&[use_at(1, 7, 0), use_at(1, 7, 1), use_at(1, 7, 2), use_at(2, 7, 0)]),
            1,
            "…and one round across two spans is still one round"
        );
        assert_eq!(evm_distinct_permitted_rounds_v1(&[use_at(1, 7, 0), use_at(1, 8, 0)]), 2, "two rounds: two");
        // A gap in the rounds buys nothing extra: 7 and 9 are two rounds, not three.
        assert_eq!(evm_distinct_permitted_rounds_v1(&[use_at(1, 7, 0), use_at(1, 9, 0)]), 2, "a missing round is not a budget");
        // Order does not matter, and a repeated entry counts once.
        let mut many: Vec<_> = (0..200u64).map(|i| use_at(1, i % 5, (i % 3) as u16)).collect();
        many.reverse();
        assert_eq!(evm_distinct_permitted_rounds_v1(&many), 5, "200 uses over 5 rounds buy 5 budgets");
        assert_eq!(
            evm_user_gas_cap_v1(Some(evm_distinct_permitted_rounds_v1(&many))),
            MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK + 5 * EVM_ROUND_GAS_BUDGET_V1,
            "and the cap follows the distinct count, not the block count"
        );
    }

    #[test]
    fn the_cap_is_the_base_below_the_lane_and_one_budget_a_permitted_round_under_the_ceiling() {
        assert_eq!(evm_user_gas_cap_v1(None), MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK, "no lane: the cap a chain block always had");
        assert_eq!(evm_user_gas_cap_v1(Some(0)), MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK, "a lane that merged no round: the base");
        assert_eq!(evm_user_gas_cap_v1(Some(1)), MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK + EVM_ROUND_GAS_BUDGET_V1);
        assert_eq!(evm_user_gas_cap_v1(Some(120)), EVM_CHAIN_BLOCK_GAS_CEILING_V1, "one anchor of rounds reaches the ceiling exactly");
        assert_eq!(evm_user_gas_cap_v1(Some(121)), EVM_CHAIN_BLOCK_GAS_CEILING_V1, "…and nothing buys past it");
        assert_eq!(evm_user_gas_cap_v1(Some(u64::MAX)), EVM_CHAIN_BLOCK_GAS_CEILING_V1, "saturating, never wrapping");
        assert!(EVM_ROUND_GAS_BUDGET_V1 * 10 <= MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK, "a round is a tenth of a base block or less");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Bridge audit BR-1: the ingress predicate accepts exactly the payload the block id commits
    /// to — the empty payload with zero (hash-invisible) EVM fields on a pre-v2 header, the hashed
    /// payload on v2 — and the block id itself never moves with the payload.
    #[test]
    fn br1_evm_payload_matches_header_is_the_id_commitment() {
        let v1 = crate::header::Header::from_precomputed_hash(Hash64::from_u64_word(1), vec![]);
        assert!(v1.version < crate::constants::EVM_HEADER_VERSION);
        let empty = EvmExecutionPayload::default();
        let foreign = EvmExecutionPayload { extra_data: vec![1], ..Default::default() };
        assert!(evm_payload_matches_header(&v1, &empty));
        assert!(!evm_payload_matches_header(&v1, &foreign), "v1: any payload is a delivery fault");
        let mut v1_fields = v1.clone();
        v1_fields.evm_commitment_root = Hash64::from_bytes([3; 64]);
        assert!(!evm_payload_matches_header(&v1_fields, &empty), "v1: hash-invisible EVM fields must be zero");
        let mut v1_fields = v1.clone();
        v1_fields.evm_payload_hash = empty.payload_hash();
        assert!(!evm_payload_matches_header(&v1_fields, &empty), "v1: even the empty payload's hash is a stray field");

        let mut v2 = v1.clone();
        v2.version = crate::constants::EVM_HEADER_VERSION;
        let v2 = v2.with_evm_payload_hash(foreign.payload_hash());
        assert!(evm_payload_matches_header(&v2, &foreign));
        assert!(!evm_payload_matches_header(&v2, &empty), "v2: a payload that misses the hash is a delivery fault");
        let v2_empty = v2.clone().with_evm_payload_hash(empty.payload_hash());
        assert!(evm_payload_matches_header(&v2_empty, &empty));
        assert_ne!(v2.hash, v2_empty.hash, "v2: the payload hash is in the id, so the id names one payload");
    }

    /// PREA P0-1: the F003 ML-DSA-87 signing contexts must be domain-separated from
    /// the UTXO address-payload key and every other ML-DSA-87 context, or a
    /// UTXO/attestation/tx signature could be cross-protocol-replayed as an EVM root
    /// authorization (the C-02 class). Also pins the frozen byte values + layout.
    #[test]
    fn f003_contexts_are_domain_separated_and_layout_frozen() {
        assert_eq!(F003_PREA_ROOT_MLDSA87_CONTEXT, b"misaka-pq-evm-v1/root/mldsa87");
        assert_eq!(F003_FSL_VERIFY_MLDSA87_CONTEXT, b"misaka-pq-fsl-v1/verify/mldsa87");
        // distinct from each other …
        assert_ne!(F003_PREA_ROOT_MLDSA87_CONTEXT, F003_FSL_VERIFY_MLDSA87_CONTEXT);
        // … and from the UTXO address-payload key + the tx/attestation contexts.
        assert_ne!(F003_PREA_ROOT_MLDSA87_CONTEXT, kaspa_hashes::MLDSA87_ADDRESS_CONTEXT);
        assert_ne!(F003_FSL_VERIFY_MLDSA87_CONTEXT, kaspa_hashes::MLDSA87_ADDRESS_CONTEXT);
        assert_ne!(F003_PREA_ROOT_MLDSA87_CONTEXT, &b"kaspa-pq-v2/tx/mldsa87"[..]);
        assert_ne!(F003_PREA_ROOT_MLDSA87_CONTEXT, &b"kaspa-pq-v1/att/mldsa87"[..]);
        // the op-preimage digest domain is distinct from the root + address contexts.
        assert_eq!(F003_PREA_OP_MLDSA87_CONTEXT, b"misaka-pq-evm-v1/op/mldsa87");
        assert_ne!(F003_PREA_OP_MLDSA87_CONTEXT, F003_PREA_ROOT_MLDSA87_CONTEXT);
        assert_ne!(F003_PREA_OP_MLDSA87_CONTEXT, kaspa_hashes::MLDSA87_ADDRESS_CONTEXT);
        // frozen input layout (version-discriminated).
        assert_eq!(F003_INPUT_LEN_FSL, 1 + 2592 + 64 + 4627);
        assert_eq!(F003_PREA_PREFIX_LEN, 1 + 64 + 2592 + 4627);
        assert_ne!(F003_VERSION_FSL_GENERIC, F003_VERSION_PREA_ROOT);
        // the precompile address is 0x…F003 (distinct from F001 WMISAKA / F002 withdraw).
        assert_eq!(MISAKA_MLDSA_VERIFY_PRECOMPILE.as_bytes()[19], 0x03);
        assert_eq!(MISAKA_MLDSA_VERIFY_PRECOMPILE.as_bytes()[18], 0xF0);
    }

    #[test]
    fn empty_payload_is_empty_and_default() {
        let p = EvmExecutionPayload::default();
        assert!(p.is_empty());
        assert_eq!(p, EvmExecutionPayload::default());
        // A non-empty payload (any of the four fields) is detected.
        let p2 = EvmExecutionPayload { transactions: vec![vec![1, 2, 3]], ..Default::default() };
        assert!(!p2.is_empty());
        let p3 = EvmExecutionPayload {
            system_ops: vec![EvmSystemOp::DepositClaim(DepositClaim {
                deposit_outpoint: TransactionOutpoint::default(),
                evm_address: EvmAddress::default(),
                amount_sompi: 1,
                claim_tip_sompi: 0,
            })],
            ..Default::default()
        };
        assert!(!p3.is_empty());
    }

    /// EVM audit C3: the per-block deposit-claim BYTE and SYSTEM-GAS bounds are
    /// enforced via the COUNT cap (`check_evm_payload` rejects >
    /// `MAX_DEPOSIT_CLAIMS_PER_EVM_BLOCK` ops) — that implication only holds
    /// while a claim's serialized size is fixed and the products stay under the
    /// byte/gas consts. This test pins the implication: if `DepositClaim` ever
    /// grows (or goes variable-length), or the caps drift, it fails and the
    /// byte/gas bounds must become EXPLICIT body-validation rules.
    #[test]
    fn claim_count_cap_subsumes_byte_and_system_gas_bounds() {
        let max_claim = EvmSystemOp::DepositClaim(DepositClaim {
            deposit_outpoint: TransactionOutpoint::new(Hash64::from_bytes([0xFF; 64]), u32::MAX),
            evm_address: EvmAddress::from_bytes([0xFF; 20]),
            amount_sompi: u64::MAX,
            claim_tip_sompi: u64::MAX,
        });
        let min_claim = EvmSystemOp::DepositClaim(DepositClaim {
            deposit_outpoint: TransactionOutpoint::default(),
            evm_address: EvmAddress::default(),
            amount_sompi: 0,
            claim_tip_sompi: 0,
        });
        let max_size = borsh::to_vec(&max_claim).unwrap().len();
        // Fixed-width: extreme and default claims serialize to the same length,
        // so `count cap × size` is exact, not an estimate.
        assert_eq!(
            max_size,
            borsh::to_vec(&min_claim).unwrap().len(),
            "DepositClaim went variable-length: make the byte bound an explicit rule"
        );

        // Count cap ⇒ byte bound.
        assert!(
            MAX_DEPOSIT_CLAIMS_PER_EVM_BLOCK * max_size <= MAX_DEPOSIT_CLAIM_BYTES_PER_EVM_BLOCK,
            "256 maximal claims ({} B each) exceed MAX_DEPOSIT_CLAIM_BYTES_PER_EVM_BLOCK: enforce the byte bound explicitly",
            max_size
        );
        // Count cap ⇒ system-gas bound.
        assert!(
            (MAX_DEPOSIT_CLAIMS_PER_EVM_BLOCK as u64) * SYSTEM_DEPOSIT_GAS_PER_CLAIM <= MAX_SYSTEM_GAS_PER_EVM_BLOCK,
            "256 claims exceed MAX_SYSTEM_GAS_PER_EVM_BLOCK: enforce the gas bound explicitly"
        );
        // And a count-cap-maximal payload still fits the §7 payload byte cap.
        let payload = EvmExecutionPayload {
            system_ops: (0..MAX_DEPOSIT_CLAIMS_PER_EVM_BLOCK).map(|_| max_claim.clone()).collect(),
            ..Default::default()
        };
        assert!(payload.payload_bytes().len() <= MAX_EVM_PAYLOAD_BYTES_PER_DAG_BLOCK);
    }

    #[test]
    fn payload_hash_is_deterministic_domain_separated_and_field_sensitive() {
        // v0.4 §4.1: the payload DATA commitment carried in `Header::evm_payload_hash`.
        let p = EvmExecutionPayload::default();
        let h_empty = p.payload_hash();
        assert_eq!(h_empty, p.payload_hash(), "deterministic");
        assert_ne!(h_empty, Hash64::default(), "a keyed digest, not the zero default");
        // Every field participates: txs and the declared evm_coinbase.
        let p_tx = EvmExecutionPayload { transactions: vec![vec![1, 2, 3]], ..Default::default() };
        assert_ne!(p_tx.payload_hash(), h_empty);
        let p_cb = EvmExecutionPayload { evm_coinbase: EvmAddress::from_bytes([0xFE; 20]), ..Default::default() };
        assert_ne!(p_cb.payload_hash(), h_empty);
        // Domain separation from the execution commitment (b"EvmPayload64" vs
        // b"EvmCommitment64"): the two roots can never alias.
        assert_ne!(h_empty, EvmExecutionHeader::default().commitment_root());
    }

    #[test]
    fn execution_header_defaults_and_genesis_state_root() {
        let h = EvmExecutionHeader::default();
        assert_eq!(h.evm_number, 0);
        assert!(h.state_root.is_zero());
        assert_eq!(h.logs_bloom, EvmBloom::default());
        assert_eq!(h.base_fee_per_gas, EvmU256::ZERO);
        // The pinned genesis state root is the canonical empty-trie root.
        assert_eq!(EVM_GENESIS_STATE_ROOT.to_string(), "56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421");
    }

    #[test]
    fn commitment_root_is_deterministic_and_field_sensitive() {
        let mut h = EvmExecutionHeader { evm_chain_id: EVM_CHAIN_ID, gas_used: 21_000, ..Default::default() };
        let c1 = h.commitment_root();
        // Same inputs ⇒ identical commitment.
        assert_eq!(c1, h.clone().commitment_root());
        // Domain-separated 64-byte digest, not the all-zero default.
        assert_ne!(c1, Hash64::default());
        // Any field change ⇒ different commitment.
        h.gas_used = 21_001;
        assert_ne!(c1, h.commitment_root());
    }

    /// §22 / §12-Phase-7 guard: the consensus `EvmReceipt` borsh encoding is
    /// CONSENSUS-CRITICAL — the v1 `receipts_root` (pre-typed-receipt fence) is a
    /// keccak-MPT over `borsh(EvmReceipt)`, so any field add/remove/reorder would
    /// silently change every below-fence block's `receipts_root` (a hard fork
    /// disguised as a refactor; design §22 forbids adding a per-receipt bloom to
    /// the consensus receipt). This pins the exact bytes + byte-stable roundtrip.
    /// If it fails you are about to fork: re-pin ONLY with explicit intent.
    #[test]
    fn evm_receipt_borsh_byte_stable() {
        let r = EvmReceipt {
            succeeded: true,
            cumulative_gas_used: 0x1234,
            gas_used: 0x0fff,
            logs: vec![EvmLog {
                address: EvmAddress::from_bytes([0xAB; 20]),
                topics: vec![EvmH256::from_bytes([0x11; 32]), EvmH256::from_bytes([0x22; 32])],
                data: vec![0xde, 0xad, 0xbe, 0xef],
            }],
        };
        let bytes = borsh::to_vec(&r).unwrap();
        // byte-stable roundtrip (a layout change breaks re-encode identity).
        assert_eq!(r, borsh::from_slice::<EvmReceipt>(&bytes).unwrap());
        assert_eq!(bytes, borsh::to_vec(&borsh::from_slice::<EvmReceipt>(&bytes).unwrap()).unwrap());
        // Pinned encoding: succeeded(1) | cumulative_gas_used(8 LE) | gas_used(8 LE)
        // | logs len(4 LE)=1 | [ address(20) | topics len(4)=2 | 0x11*32 | 0x22*32
        // | data len(4)=4 | deadbeef ].
        // borsh: succeeded(1) | cumulative_gas_used(8 LE) | gas_used(8 LE) | logs len(4 LE) |
        // [ address(20) | topics len(4) | 0x11*32 | 0x22*32 | data len(4) | deadbeef ].
        let expect = "013412000000000000ff0f00000000000001000000abababababababababababababababababababab020000001111111111111111111111111111111111111111111111111111111111111111222222222222222222222222222222222222222222222222222222222222222204000000deadbeef";
        assert_eq!(faster_hex::hex_string(&bytes), expect, "EvmReceipt borsh layout changed — this is a CONSENSUS FORK");
    }

    #[test]
    fn bloom_serde_roundtrip() {
        let mut bytes = [0u8; EVM_BLOOM_SIZE];
        bytes[0] = 0xAB;
        bytes[255] = 0xCD;
        let bloom = EvmBloom::from_bytes(bytes);
        let j = serde_json::to_string(&bloom).unwrap();
        assert_eq!(bloom, serde_json::from_str::<EvmBloom>(&j).unwrap());
        let b = borsh::to_vec(&bloom).unwrap();
        assert_eq!(b.len(), EVM_BLOOM_SIZE);
        assert_eq!(bloom, borsh::from_slice::<EvmBloom>(&b).unwrap());
    }

    fn sample_trace_body() -> EvmTraceReplayBodyV1 {
        EvmTraceReplayBodyV1 {
            selected_parent: Hash64::from_bytes([7u8; 64]),
            env: EvmReplayEnv {
                header_timestamp_ms: 1_700_000_000_123,
                blue_work_be: vec![0x01, 0x02, 0x03, 0x04],
                daa_score: 4_242_424,
                coinbase: EvmAddress::from_bytes([0xAB; EVM_ADDRESS_SIZE]),
            },
            system_ops: vec![EvmSystemOp::DepositClaim(DepositClaim {
                deposit_outpoint: TransactionOutpoint::new(Hash64::from_bytes([9u8; 64]), 3),
                evm_address: EvmAddress::from_bytes([0xCD; EVM_ADDRESS_SIZE]),
                amount_sompi: 1_000_000,
                claim_tip_sompi: 1_000,
            })],
            txs: vec![
                EvmReplayTx {
                    tx_hash: EvmH256::from_bytes([0x11; 32]),
                    raw: vec![0x02, 0xde, 0xad, 0xbe, 0xef],
                    payload_coinbase: EvmAddress::from_bytes([0x01; EVM_ADDRESS_SIZE]),
                    originating_payload_block: Hash64::from_bytes([0x22; 64]),
                    outcome: EvmCandidateOutcome::Accepted { receipt_index: 0 },
                },
                // A skipped candidate is retained so the replay reproduces the exact
                // gas-pool accept/skip decisions (NOT just the accepted prefix).
                EvmReplayTx {
                    tx_hash: EvmH256::from_bytes([0x33; 32]),
                    raw: vec![0x02, 0xca, 0xfe],
                    payload_coinbase: EvmAddress::from_bytes([0x02; EVM_ADDRESS_SIZE]),
                    originating_payload_block: Hash64::from_bytes([0x44; 64]),
                    outcome: EvmCandidateOutcome::Skipped { class: 2 },
                },
            ],
        }
    }

    /// The replay body must borsh-roundtrip byte-stably (it is a DB store value at
    /// prefix 219) and serde-roundtrip (RPC introspection).
    #[test]
    fn trace_replay_body_roundtrips() {
        let body = sample_trace_body();
        let bytes = borsh::to_vec(&body).unwrap();
        assert_eq!(body, borsh::from_slice::<EvmTraceReplayBodyV1>(&bytes).unwrap());
        // Byte-stability: re-encoding the decoded value yields the same bytes.
        assert_eq!(bytes, borsh::to_vec(&borsh::from_slice::<EvmTraceReplayBodyV1>(&bytes).unwrap()).unwrap());
        let json = serde_json::to_string(&body).unwrap();
        assert_eq!(body, serde_json::from_str::<EvmTraceReplayBodyV1>(&json).unwrap());
    }

    /// C-01 Stage 1: FlatAccount / EvmLatestStatePtr borsh+serde roundtrip + the
    /// snapshot⇄flat conversion (drop code on the way in, restore on the way out).
    #[test]
    fn flat_account_roundtrips_and_converts() {
        let snap = EvmAccountSnapshot {
            address: EvmAddress::from_bytes([0xAB; 20]),
            nonce: 7,
            balance: EvmU256::from_u128(123),
            code_hash: EvmH256::from_bytes([0x22; 32]),
            code: vec![0xde, 0xad],
            storage: vec![(EvmU256::from_u128(1), EvmU256::from_u128(9))],
        };
        let flat = FlatAccount::from_snapshot(&snap);
        assert_eq!(flat.core.code_hash, snap.code_hash);
        assert_eq!(flat.storage, snap.storage);
        // borsh byte-stable + serde roundtrip.
        let bytes = borsh::to_vec(&flat).unwrap();
        assert_eq!(flat, borsh::from_slice::<FlatAccount>(&bytes).unwrap());
        assert_eq!(bytes, borsh::to_vec(&borsh::from_slice::<FlatAccount>(&bytes).unwrap()).unwrap());
        assert_eq!(flat, serde_json::from_str::<FlatAccount>(&serde_json::to_string(&flat).unwrap()).unwrap());
        // Restore the canonical snapshot (code resolved externally by code_hash).
        assert_eq!(flat.to_snapshot(snap.address, snap.code.clone()), snap);

        let ptr = EvmLatestStatePtr { canonical_head: Hash64::from_bytes([5; 64]), state_root: EvmH256::from_bytes([6; 32]) };
        let pb = borsh::to_vec(&ptr).unwrap();
        assert_eq!(ptr, borsh::from_slice::<EvmLatestStatePtr>(&pb).unwrap());
        assert!(flat.estimate_mem_bytes() >= size_of::<FlatAccount>());
    }

    /// The body preserves the FULL ordered candidate list (accepted + skipped) and
    /// the receipt-index mapping, which the trace lookup relies on.
    #[test]
    fn trace_replay_body_preserves_candidate_order_and_outcomes() {
        let body = sample_trace_body();
        assert_eq!(body.txs.len(), 2);
        assert_eq!(body.txs[0].outcome, EvmCandidateOutcome::Accepted { receipt_index: 0 });
        assert_eq!(body.txs[1].outcome, EvmCandidateOutcome::Skipped { class: 2 });
        // The accepted candidate is locatable by its recorded receipt_index.
        let target = body.txs.iter().find(|t| matches!(t.outcome, EvmCandidateOutcome::Accepted { receipt_index: 0 }));
        assert_eq!(target.unwrap().tx_hash, EvmH256::from_bytes([0x11; 32]));
    }

    /// `MemSizeEstimator` must be a real implementation (a panicking default crashes
    /// a validator under a cache policy — see the EvmStateSnapshot note).
    #[test]
    fn trace_replay_body_mem_size_is_real() {
        let body = sample_trace_body();
        let est = body.estimate_mem_bytes();
        // At least the struct itself plus the two txs' raw payloads + blue_work.
        assert!(est >= size_of::<EvmTraceReplayBodyV1>() + 5 + 3 + 4, "estimate too small: {est}");
    }

    /// §12 state-history: the diff/checkpoint records must borsh-roundtrip byte-stably
    /// (they are DB store values at prefixes 220/221) and serde-roundtrip (RPC).
    #[test]
    fn state_diff_v2_roundtrips() {
        let diff = EvmStateDiffV2 {
            block: Hash64::from_bytes([1u8; 64]),
            parent: Hash64::from_bytes([2u8; 64]),
            account_changes: vec![AccountChange {
                address: EvmAddress::from_bytes([0xAA; EVM_ADDRESS_SIZE]),
                before: None, // created
                after: Some(AccountCore { nonce: 1, balance: EvmU256::from(1000u64), code_hash: EvmH256::from_bytes([3u8; 32]) }),
                storage_changes: vec![StorageChange {
                    slot: EvmU256::from(0u64),
                    before: EvmU256::from(0u64),
                    after: EvmU256::from(42u64),
                }],
            }],
        };
        let bytes = borsh::to_vec(&diff).unwrap();
        assert_eq!(diff, borsh::from_slice::<EvmStateDiffV2>(&bytes).unwrap());
        assert_eq!(bytes, borsh::to_vec(&borsh::from_slice::<EvmStateDiffV2>(&bytes).unwrap()).unwrap());
        let json = serde_json::to_string(&diff).unwrap();
        assert_eq!(diff, serde_json::from_str::<EvmStateDiffV2>(&json).unwrap());
        // The mem estimate accounts for the nested storage_changes.
        assert!(diff.estimate_mem_bytes() >= size_of::<EvmStateDiffV2>());
    }

    #[test]
    fn state_checkpoint_v1_roundtrips() {
        let cp = EvmStateCheckpointV1 {
            block: Hash64::from_bytes([7u8; 64]),
            evm_number: 2_048,
            state_root: EvmH256::from_bytes([9u8; 32]),
            compressed_snapshot: vec![0xde, 0xad, 0xbe, 0xef],
            checksum: [0x11; 32],
        };
        let bytes = borsh::to_vec(&cp).unwrap();
        assert_eq!(cp, borsh::from_slice::<EvmStateCheckpointV1>(&bytes).unwrap());
        let json = serde_json::to_string(&cp).unwrap();
        assert_eq!(cp, serde_json::from_str::<EvmStateCheckpointV1>(&json).unwrap());
    }

    /// §12.2 history mode parses case-insensitively, defaults to `recent`, and
    /// rejects unknown values.
    #[test]
    fn history_mode_parse_and_default() {
        assert_eq!(EvmHistoryMode::default(), EvmHistoryMode::Recent);
        assert_eq!(EvmHistoryMode::from_str_opt("HEAD"), Some(EvmHistoryMode::Head));
        assert_eq!(EvmHistoryMode::from_str_opt("Archive"), Some(EvmHistoryMode::Archive));
        assert_eq!(EvmHistoryMode::from_str_opt("recent"), Some(EvmHistoryMode::Recent));
        assert_eq!(EvmHistoryMode::from_str_opt("bogus"), None);
        assert_eq!(EvmHistoryMode::Archive.as_str(), "archive");
        // borsh-stable (it may be persisted in node config / future state-meta).
        let b = borsh::to_vec(&EvmHistoryMode::Archive).unwrap();
        assert_eq!(EvmHistoryMode::Archive, borsh::from_slice::<EvmHistoryMode>(&b).unwrap());
    }

    #[test]
    fn history_mode_retention_policy() {
        // §12 writer gate: head writes no diffs; recent/archive do.
        assert!(!EvmHistoryMode::Head.writes_state_history());
        assert!(EvmHistoryMode::Recent.writes_state_history());
        assert!(EvmHistoryMode::Archive.writes_state_history());
        // §12 prune gate: only archive preserves header+diff+checkpoint past pruning.
        assert!(EvmHistoryMode::Archive.retains_state_history_past_pruning());
        assert!(!EvmHistoryMode::Recent.retains_state_history_past_pruning());
        assert!(!EvmHistoryMode::Head.retains_state_history_past_pruning());
    }
}
