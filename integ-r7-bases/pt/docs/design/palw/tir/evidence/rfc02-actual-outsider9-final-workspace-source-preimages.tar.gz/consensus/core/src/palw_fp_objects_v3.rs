//! From accepted transactions to consensus objects (ADR-0044 Unit C, item 3).
//!
//! One chain block's accepted free-prompt commitment transactions become the
//! `FreePromptCommitted` objects its PALW transition folds — in the block's deterministic
//! acceptance order, because the transition's ordering IS consensus.
//!
//! # What this layer decides, and what it refuses to decide
//!
//! It decides SHAPE and PRICE from facts the transaction carries: the payload decodes, the
//! carried prompt is the one the commitment binds, the CU is the bundle's price for the executed
//! shape, and the quanta/pwu derivation is the bundle's. All of that is a pure function of the
//! transaction and the ruleset, so every node computes it identically.
//!
//! It does NOT decide anything requiring chain state — that the executor's bond exists and is
//! Active, that its key is the carried key, that the class is registered and unfrozen. Those are
//! the transition's own referential checks (it refuses an object naming an absent bond or a
//! frozen class) and admission's. Splitting it this way keeps the extraction a pure function that
//! a test can drive without a chain.
//!
//! # Why a malformed carrier is SKIPPED, not fatal
//!
//! A transaction whose payload does not decode, or whose price does not check, contributes no
//! object — it does not reject the block. That mirrors `palw_carriage_records_from_accepted_txs`
//! beside it, and it is the right shape here for a specific reason: transaction-level validity is
//! the transaction validator's job (a network running this ruleset rejects such a transaction at
//! acceptance), while this walk must be a total function of whatever DID get accepted. A walk
//! that could panic or reject on a peer-supplied payload would be a remote denial of service
//! wearing a consensus rule's clothes.
//!
//! The skipped-object count is returned so a caller can log it: silently dropping a carrier that
//! a peer thought was valid is exactly the "reads as nothing" failure ADR-0042 Decision 5 warns
//! about, and the count is how an operator sees it happening.

use crate::palw_freeprompt_v3::{PalwFpCommitmentTxPayloadV3, PalwFreePromptParamsV3, palw_fp_decode_controls_offered_v1};
use crate::palw_state_v2::{PalwBondKeyV2, PalwConsensusObjectV2};
use crate::subnets::SUBNETWORK_ID_PALW_FP_COMMITMENT;
use crate::tx::Transaction;
use crate::{BlockHash, Hash64};

/// What one block's extraction produced.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct PalwFpExtractionV3 {
    /// The objects, in acceptance order.
    pub objects: Vec<PalwConsensusObjectV3Carrier>,
    /// Carriers routed to the free-prompt subnetwork that produced no object, and why — for the
    /// log line that keeps a silent drop from being silent.
    pub skipped: Vec<(crate::tx::TransactionId, &'static str)>,
}

/// An extracted object plus the transaction that carried it, so a caller can attribute it.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwConsensusObjectV3Carrier {
    pub carrier: crate::tx::TransactionId,
    pub object: PalwConsensusObjectV2,
}

/// Extract one chain block's free-prompt objects.
///
/// `network_domain` is the network's own (see `palw_network_domain_v2`); a payload naming another
/// network produces nothing here, exactly as it would be refused at admission.
pub fn palw_fp_objects_from_accepted_txs_v3<V>(
    txs: &[Transaction],
    network_domain: Hash64,
    // Kept on the signature so every caller still hands the walk the bundle it reads under; the
    // price it used to derive from these params is the transition's now (ADR-0074 Decision 5).
    freeprompt: &PalwFreePromptParamsV3,
    accepted_block: BlockHash,
    // ADR-0081 Decision 3's form, `Params::palw_prompt_ids_form_v1()` — genesis-only, so this
    // height-free entry can carry it exactly.
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    // **The ML-DSA-87 verifier, and it is not optional.** Without it this walk turned any
    // stranger's 0x4a transaction into a claim bound to any bond outpoint it named — including the
    // genesis premine bond, a published constant — because the commitment's signature was checked
    // on no path in the tree. Taking it as an argument rather than leaving it to a caller is what
    // makes "somebody else verifies it" unrepresentable; the previous arrangement said exactly that
    // in a doc comment, and nobody did.
    verify_mldsa87: V,
) -> PalwFpExtractionV3
where
    V: Fn(&[u8], &[u8], &[u8], &[u8]) -> bool,
{
    // `false`: this entry cannot resolve a height, so it answers the ADR-0077 Decision 16 arming
    // the way every build answered it before the fence existed. A caller that holds the block's
    // DAA score calls [`palw_fp_objects_from_accepted_txs_under_v3`] instead.
    palw_fp_objects_from_accepted_txs_under_v3(txs, network_domain, freeprompt, accepted_block, false, prompt_ids_form, verify_mldsa87)
}

/// The same walk **under this block's `PanelDa` arming** (ADR-0077 Decision 16).
///
/// `panel_da_armed` is `Params::palw_panel_da_at(block_daa)` — the accepting block's own DAA
/// score, not the node's tip, for the reason every rule on this lane is candidate-scoped: two
/// nodes folding the same block must fold it identically however far either has synced.
///
/// A separate entry rather than a parameter on the old one so the processor's switch to it is a
/// one-line, reviewable change, and so a caller that has NOT switched keeps refusing mode 2
/// rather than silently acquiring it.
pub fn palw_fp_objects_from_accepted_txs_under_v3<V>(
    txs: &[Transaction],
    network_domain: Hash64,
    freeprompt: &PalwFreePromptParamsV3,
    accepted_block: BlockHash,
    panel_da_armed: bool,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    verify_mldsa87: V,
) -> PalwFpExtractionV3
where
    V: Fn(&[u8], &[u8], &[u8], &[u8]) -> bool,
{
    // No bundle in scope, so no ladder: the structural top, exactly as the door uses it. A caller
    // that holds the bundle calls [`palw_fp_objects_from_accepted_txs_under_ruleset_v3`].
    palw_fp_objects_from_accepted_txs_under_ruleset_v3(
        txs,
        network_domain,
        freeprompt,
        accepted_block,
        panel_da_armed,
        crate::palw_freeprompt_v3::PALW_FP_STRUCTURAL_WORK_LEAVES_CAP,
        // No bundle-resolved fence either, and the caps are a RULESET rule: a caller with no
        // height cannot be stricter than the walk (ADR-0044 D9; mainnet audit 2026-09-06, L-2).
        false,
        prompt_ids_form,
        verify_mldsa87,
    )
}

/// The same walk **under this ruleset's ladder** (ADR-0082 Decision 1).
///
/// `max_step_leaf_count` is `PalwCourtParamsV2::max_step_leaf_count` off the bundle the accepting
/// block is folded under — `2^26` on every shipped preset. It is the ONE place a free-prompt
/// commitment meets the number its network's court can actually prosecute to: a claim whose
/// `work_leaves` is past the ladder has a step index no dissection can reach, so crediting it
/// would be weight for work nobody can be convicted over. A carrier that fails it is SKIPPED, like
/// every other refusal in this walk, so a peer's payload can never reject the block.
///
/// A separate entry rather than a parameter on the old one, for the reason the `_under_v3` split
/// gives: a caller that has not switched keeps the weaker structural bound rather than silently
/// acquiring a stricter rule it did not ask for.
///
/// `ruleset_caps_armed` is `Params::palw_fp_ruleset_caps` resolved at the accepting block's DAA
/// (ADR-0044 Decision 9; mainnet audit 2026-09-06, L-2). Past it the two caps the ruleset
/// ADVERTISES — `max_prompt_tokens` and `max_decode_tokens`, already hashed into
/// `palw_ruleset_id_v2` — are read off the bundle this walk already holds and a carrier above
/// either is SKIPPED like every other refusal here. `false` on every shipped preset, where the
/// walk behaves byte for byte as it did before the fence existed.
#[allow(clippy::too_many_arguments)]
pub fn palw_fp_objects_from_accepted_txs_under_ruleset_v3<V>(
    txs: &[Transaction],
    network_domain: Hash64,
    freeprompt: &PalwFreePromptParamsV3,
    accepted_block: BlockHash,
    panel_da_armed: bool,
    max_step_leaf_count: u64,
    ruleset_caps_armed: bool,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    verify_mldsa87: V,
) -> PalwFpExtractionV3
where
    V: Fn(&[u8], &[u8], &[u8], &[u8]) -> bool,
{
    palw_fp_objects_from_accepted_txs_under_held_v3(
        txs,
        network_domain,
        freeprompt,
        accepted_block,
        panel_da_armed,
        max_step_leaf_count,
        ruleset_caps_armed,
        false,
        prompt_ids_form,
        verify_mldsa87,
    )
}

/// The same walk **under ADR-0103's regime** (Decision 4: the ids never ride above one standard
/// transaction).
///
/// `held_armed` is `Params::palw_held_context` resolved at the accepting block's DAA. Past it a
/// `PublicDa` carrier whose ids are more than one standard transaction's bytes is SKIPPED by name,
/// like every refusal here: such a prompt commits under `PanelDa` (which the regime's assembly
/// requires) and its ids are served under the root, never carried. `false` is the ruleset walk byte
/// for byte — and on every shipped network the rule could not fire anyway, since no admitted
/// prompt there reaches 30,000 ids.
#[allow(clippy::too_many_arguments)]
pub fn palw_fp_objects_from_accepted_txs_under_held_v3<V>(
    txs: &[Transaction],
    network_domain: Hash64,
    freeprompt: &PalwFreePromptParamsV3,
    accepted_block: BlockHash,
    panel_da_armed: bool,
    max_step_leaf_count: u64,
    ruleset_caps_armed: bool,
    held_armed: bool,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    verify_mldsa87: V,
) -> PalwFpExtractionV3
where
    V: Fn(&[u8], &[u8], &[u8], &[u8]) -> bool,
{
    palw_fp_objects_from_accepted_txs_by_class_v1(
        txs,
        network_domain,
        freeprompt,
        accepted_block,
        panel_da_armed,
        |_| PalwFpClassCapsV1 {
            step_ladder: max_step_leaf_count,
            held: false,
            derived_work: PalwFpDerivedWorkCapV1::Declared,
            logits_q24: true,
            prefix_state_armed: false,
            prefix_inherit_armed: false, prefix_inherit_class_safe: false,
            constraint_armed: false,
            constraint_v2_armed: false,
            tokenizer: crate::palw_fp_tokenizer_v1::PalwFpTokenizerRuleV1::Dormant,
        },
        ruleset_caps_armed,
        held_armed,
        prompt_ids_form,
        // The pre-V4 entries: a caller that holds no decode-rules height admits V3 jobs only,
        // which is what every one of them admitted before RFC-0001 §A.
        crate::palw_freeprompt_v3::PalwFpDecodeRulesV1::Dormant,
        verify_mldsa87,
    )
}

/// **What the walk bounds ONE commitment by, from its class** (ADR-0119 Decision 5).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwFpClassCapsV1<'a> {
    /// The class's step ladder: the network's, or a held class's recorded `2^40`.
    pub step_ladder: u64,
    /// A class under the held regime — whose prompt cap, where the ruleset caps are armed, is the
    /// regime's (`PALW_FP_HELD_MAX_PROMPT_TOKENS_V1`) rather than the frame-bounded advertised one.
    pub held: bool,
    /// **ADR-0145 §5: whether this walk prices the class's work or believes it.**
    pub derived_work: PalwFpDerivedWorkCapV1<'a>,
    /// **Does the class commit its logits in Q24** (RFC-0001 §A.3's unit)? `true` for every legacy
    /// class (K = 24 integer kernels) and for any class registered past the fence that guarantees Q24
    /// by construction (RFC-0003 §I.3); `false` for an IR or generative class registered before it,
    /// whose logit unit is its lowerer's and declared nowhere. A V4 job asking such a class for the
    /// temperature, a frequency or presence penalty, or a logit bias is skipped by name
    /// ([`crate::palw_freeprompt_v3::palw_fp_decode_controls_offered_v1`]); greedy selection, the
    /// repeat penalty, stop sequences and constraints are offered to every class.
    pub logits_q24: bool,
    /// **RFC-0001 §2.6 stage 2: whether `Params::palw_fp_prefix_state` is in force at the accepting block** — a
    /// prefix-state claim (FP job version 11) is skipped by name where it is not.
    pub prefix_state_armed: bool,
    /// **RFC-0001 §2.6 stage 2b: whether `Params::palw_fp_prefix_inherit` is in force at the accepting block** — an
    /// inherited-prefix claim (FP job version 12) is skipped by name where it is not.
    pub prefix_inherit_armed: bool,
    /// **RFC-0001 stage 2b: whether the class's leaves are inheritance-safe**
    /// ([`crate::palw_fp_prefix_v1::palw_fp_prefix_inherit_class_safe_v1`]) — an inherited-prefix claim (FP job version 12)
    /// naming any other class is skipped by name.
    pub prefix_inherit_class_safe: bool,
    /// **ADR-0096 Decision 8: whether `Params::palw_fp_decode_constraint` is in force at the accepting block** — a
    /// constrained claim (FP job version 6) is skipped by name where it is not.
    pub constraint_armed: bool,
    /// **RFC-0001 §2.5: whether `Params::palw_fp_constraint_v2` is in force at the accepting block** — a constraint of
    /// the second form is skipped by name where it is not.
    pub constraint_v2_armed: bool,
    /// **RFC-0001 §2.9: the class's tokenizer listing under `Params::palw_fp_tokenizer_match`**
    /// ([`crate::palw_fp_tokenizer_v1::PalwFpTokenizerRuleV1`]).
    pub tokenizer: crate::palw_fp_tokenizer_v1::PalwFpTokenizerRuleV1,
}

/// **ADR-0145 §5, as the walk sees it** — three states, not two, because "the fence is dormant"
/// and "the fence is armed and this class published no graph" are different facts with different
/// fixes, and collapsing them would tell an operator whose class is simply unpublished that the
/// lane is off.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PalwFpDerivedWorkCapV1<'a> {
    /// Below `Params::palw_fp_derived_work`. The walk carries `work_leaves` exactly as it always
    /// has — the executor's own number, which the audit of 2026-09-19 filed as F2 and which this
    /// variant exists to keep byte-identical until the fence fires.
    Declared,
    /// Past the fence, with the class's published graph in hand. The walk recomputes the run's
    /// leaves from the graph and the commitment's own two token counts and SKIPS a carrier that
    /// disagrees.
    ///
    /// Skipped and not rejected, like every other refusal in this walk: a peer's payload must
    /// never be able to invalidate the block that carried it. The transition refuses the same
    /// commitment by name if one ever reaches it, which is the backstop for a caller that did not
    /// come through this entry.
    Derived(&'a crate::palw_step::PalwShapeProfileV3),
    /// Past the fence, with no graph published for this class. Every commitment of it is skipped:
    /// a claim the chain cannot price is a claim it must not credit, and the fix is one
    /// permissionless `ClassLaneCertified` naming the class (see
    /// `PalwStateV2Error::FreePromptClassHasNoWorkProfile`).
    Unpublished,
}

/// The walk **with each commitment bounded by its own class** (ADR-0119 Decision 5).
///
/// `class_caps` is the accepting block's parent state read by class id
/// (`PalwChainStateV2::class_step_ladder_v1` / `class_is_held_v1`): a class under the held regime
/// recorded its own ladder when it registered, and a commitment of it is bounded by that ladder and
/// the regime's prompt cap, while every other class's commitment is bounded exactly as before. The
/// class is read off the commitment's own job, so the bound a commitment meets is a function of the
/// commitment and the chain, never of the carrier.
#[allow(clippy::too_many_arguments)]
pub fn palw_fp_objects_from_accepted_txs_by_class_v1<'a, V, C>(
    txs: &[Transaction],
    network_domain: Hash64,
    freeprompt: &PalwFreePromptParamsV3,
    _accepted_block: BlockHash,
    panel_da_armed: bool,
    class_caps: C,
    ruleset_caps_armed: bool,
    held_armed: bool,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    decode_rules: crate::palw_freeprompt_v3::PalwFpDecodeRulesV1,
    verify_mldsa87: V,
) -> PalwFpExtractionV3
where
    V: Fn(&[u8], &[u8], &[u8], &[u8]) -> bool,
    C: Fn(&Hash64) -> PalwFpClassCapsV1<'a>,
{
    let mut out = PalwFpExtractionV3::default();
    for tx in txs {
        if tx.subnetwork_id != SUBNETWORK_ID_PALW_FP_COMMITMENT {
            continue;
        }
        let id = tx.id();
        let payload: PalwFpCommitmentTxPayloadV3 = match borsh::from_slice(&tx.payload) {
            Ok(payload) => payload,
            Err(_) => {
                out.skipped.push((id, "payload does not decode"));
                continue;
            }
        };
        // The same stateless rules a peer applies — re-run here rather than assumed, because this
        // walk must be total over whatever was accepted — at the bounds of the commitment's CLASS.
        let caps = class_caps(&payload.commitment.job.class_id);
        let ruleset_caps = ruleset_caps_armed.then(|| {
            let prompt_cap =
                if caps.held { crate::palw_freeprompt_v3::PALW_FP_HELD_MAX_PROMPT_TOKENS_V1 } else { freeprompt.max_prompt_tokens() };
            (prompt_cap, freeprompt.max_decode_tokens())
        });
        // **RFC-0001 §2.6 stage 2: a prefix-state claim (FP job version 11) is judged on its V4 stand-in** — every rule
        // below runs on the same payload at version 7 with no tail — and carries its state to the fold; every other payload
        // is its own view and names no state.
        let (view, consumed_state) = match crate::palw_fp_prefix_v1::palw_fp_prefix_walk_view_v1(&payload, caps.prefix_state_armed, caps.prefix_inherit_armed) {
            Ok(v) => v,
            Err(why) => {
                out.skipped.push((id, why));
                continue;
            }
        };
        // **RFC-0001 stage 2b admission: a version-12 claim only over a class whose leaves are inheritance-safe.**
        if payload.commitment.job.is_prefix_inherit() && !caps.prefix_inherit_class_safe {
            out.skipped.push((id, crate::palw_fp_prefix_v1::PALW_FP_PREFIX_INHERIT_CLASS_REFUSAL_V1));
            continue;
        }
        // **ADR-0096 Decision 7: a constrained claim (FP job version 6) is judged on its V3 stand-in** — a constrained job
        // is a V3 job, so its view meets the V3 rule whatever the decode-rules fence says.
        let constrained = payload.commitment.job.is_constraint();
        let view = if constrained {
            match crate::palw_fp_constraint_job_v1::palw_fp_constraint_walk_view_v1(&payload, caps.constraint_armed, caps.constraint_v2_armed) {
                Ok(v) => v,
                Err(why) => {
                    out.skipped.push((id, why));
                    continue;
                }
            }
        } else {
            view
        };
        // **RFC-0001 §2.9: the job's tokenizer is its class's listed one** (a class that lists none is not asked).
        if let Err(why) = caps.tokenizer.check(&payload.commitment.job.tokenizer_id) {
            out.skipped.push((id, why));
            continue;
        }
        // RFC-0001 §A.4 at the ACCEPTING block: below `Params::palw_fp_decode_rules` a V3 job only,
        // from it a V4 job only — a V3 claim accepted before the fence stays what it was.
        if view
            .validate_stateless_under_ruleset_v4(
                network_domain,
                panel_da_armed,
                caps.step_ladder,
                ruleset_caps,
                prompt_ids_form,
                if constrained { crate::palw_freeprompt_v3::PalwFpDecodeRulesV1::Dormant } else { decode_rules },
            )
            .is_err()
        {
            out.skipped.push((id, "payload is not stateless-admissible"));
            continue;
        }
        // **RFC-0001 §A.3's unit, RFC-0003 §I.3's convention**: the temperature, the frequency and
        // presence penalties and the logit bias are measured in the class's logit units (Q24). A class
        // that does not commit its logits in a declared Q24 unit (an IR or generative class registered
        // before the fence that guarantees it) is offered the unit-free controls only; a job asking it
        // for one is skipped, by name — and skipped, not rejected, like every refusal in this walk. A
        // job with no V4 tail asks for nothing here, so below `palw_fp_decode_rules` nothing moves.
        if palw_fp_decode_controls_offered_v1(&payload.commitment.job, caps.logits_q24).is_err() {
            out.skipped.push((
                id,
                "a decode control in the class's logit unit (temperature, frequency/presence penalty, logit bias) on a class that does not commit Q24 logits",
            ));
            continue;
        }
        // **ADR-0103 Decision 4: the ids never ride above one standard transaction.**
        if held_armed && palw_fp_public_ids_exceed_one_transaction_v1(&payload) {
            out.skipped.push((id, "the held regime carries no prompt above one standard transaction: commit it under PanelDa"));
            continue;
        }
        // Who authored this commitment. Skipped rather than fatal, for the reason this whole walk
        // is total over whatever was accepted: rejecting a peer-supplied payload here would be a
        // remote denial of service wearing a consensus rule's clothes.
        if payload.validate_signature_v3(&verify_mldsa87).is_err() {
            out.skipped.push((id, "commitment signature does not verify under the carried key"));
            continue;
        }
        // **ADR-0145 §5: past the fence, the leaves are DERIVED here and a disagreement is
        // skipped.**
        //
        // The audit of 2026-09-19 filed this as F2: `work_leaves` was the executor's own field and
        // nothing in the acceptance path recomputed it — `an_inflated_work_leaf_count_rides_and_the_walk_carries_it`
        // below multiplied it by ten and asserted the walk still passed. It still does below the
        // fence, and it must: this walk decides what a block ALREADY ACCEPTED contributes, so a
        // rule it applies at a height the chain has passed would re-price history.
        //
        // The derivation is the enumeration `palw_step` already performs for the seat and the
        // court, over the graph the class published and the two token counts the commitment
        // itself carries — both inside the claim id, so neither can move after the fact.
        match class_caps(&payload.commitment.job.class_id).derived_work {
            PalwFpDerivedWorkCapV1::Declared => {}
            PalwFpDerivedWorkCapV1::Unpublished => {
                out.skipped.push((id, "the class has published no shape profile, so this commitment's work cannot be derived"));
                continue;
            }
            PalwFpDerivedWorkCapV1::Derived(profile) => {
                let commitment = &payload.commitment;
                match crate::palw_step::step_leaf_count_of_tokens_capped_v1(
                    profile,
                    commitment.job.prompt_tokens,
                    commitment.decode_tokens_executed,
                    caps.step_ladder,
                ) {
                    Ok(derived) if derived == commitment.work_leaves => {}
                    Ok(_) => {
                        out.skipped.push((id, "the declared work leaves are not the leaves the class's graph counts for this run"));
                        continue;
                    }
                    Err(_) => {
                        out.skipped.push((id, "the class's graph cannot enumerate this run's leaves at the class's ladder"));
                        continue;
                    }
                }
            }
        }
        // **Priced by the TRANSITION, against the class's own canonical job** (ADR-0074
        // Decision 5). Extraction holds no class state, so it carries the leaves and the facts
        // the work identity is made of; the state derives quanta and pwu where the class rule
        // lives, and refuses sub-quantum work there with a readable reason.
        let commitment = &payload.commitment;
        out.objects.push(PalwConsensusObjectV3Carrier {
            carrier: id,
            object: PalwConsensusObjectV2::FreePromptCommitted {
                // ADR-0152 v3.1 J-1 (F1): the commitment's job pin, which the claim records as its identity.
                job_pin: crate::palw_fp_execution_v3::palw_fp_job_pin_v1(&payload.commitment),
                eval: None,
                claim: payload.claim_id(),
                class_id: commitment.job.class_id,
                bond: PalwBondKeyV2(commitment.job.executor_bond),
                executor_pubkey: commitment.job.executor_pubkey.clone(),
                work_leaves: commitment.work_leaves,
                prompt_token_ids_hash: commitment.job.prompt_token_ids_hash,
                // **ADR-0145 §5/§6: the two execution facts the walk used to drop.**
                //
                // `prompt_tokens` is the job's own, already checked equal to the carried list's
                // length by `validate_stateless_under_ruleset_v3` above; the ids are the list
                // itself, and they are empty under the two modes that carry none. Together with
                // `decode_tokens_executed` they are the whole job context a leaf count reads
                // (`palw_step::kv_aux_leaf_count` reads the same pair and nothing else), so past
                // the derived-work fence the transition can recompute `work_leaves` instead of
                // believing it — and recompute WHICH PREFIX of the prompt this bond has already
                // been paid for, instead of asking the executor.
                //
                // Carried at every height. The object never leaves the node that built it and is
                // hashed into nothing, so this is not a rule change; the rule is in the
                // transition, behind the fence, where a height can be resolved.
                prompt_tokens: commitment.job.prompt_tokens,
                prompt_token_ids: payload.prompt_token_ids.clone(),
                decode_tokens_executed: commitment.decode_tokens_executed,
                trace_root: commitment.trace_root,
                output_root: commitment.output_root,
                // The DA obligations and the court binding travel WITH the claim: the panel and
                // the court read them off the state record.
                //
                // **TWO of the three DA fields, and the third is carried by nothing** (mainnet
                // audit 2026-09-06 M-3). `trace_manifest_root` is not among these fields and is
                // not on `PalwClaimStateV2` either, so no court, no seat and no transition on this
                // lane ever reads it — the attempt lane pins it to a value the panel replays, and
                // this lane's is `fp_trace_manifest_root_v3` over the per-chunk EVENT digests,
                // which the chain does not hold and cannot recompute. Giving it an obligation
                // means carrying it here and giving the DA court something to bind a disclosure
                // to, which is a `PALW_STATE_V2_VERSION` move belonging to the record's owner.
                // Recorded rather than repaired, and pinned by
                // `the_free_prompt_lanes_trace_manifest_root_is_carried_by_nothing` below so the
                // gap can neither widen nor close silently.
                execution_root: commitment.execution_root,
                trace_chunk_count: commitment.trace_chunk_count,
                trace_retention_daa: commitment.trace_retention_daa,
                // ADR-0145 §6: a V3 payload that names no prefix-STATE is genesis. The object
                // is hashed into nothing; the rule that prices KvReused sits in the transition
                // past `palw_fp_derived_work`. A later payload version that carries the object
                // is how Studio names a local cache on the wire.
                consumed_prefix_state: consumed_state,
            },
        });
    }
    out
}

/// **Do this carrier's ids ride past one standard transaction?** (ADR-0103 Decision 4.) Four bytes
/// an id against `PALW_STANDARD_TX_BYTES` — the D4 wall's own arithmetic (`C × 4`), one spelling
/// for the walk and for a builder that wants the walk's answer before it signs.
pub fn palw_fp_public_ids_exceed_one_transaction_v1(payload: &PalwFpCommitmentTxPayloadV3) -> bool {
    (payload.prompt_token_ids.len() as u64).saturating_mul(4) > crate::palw_mode_v2::PALW_STANDARD_TX_BYTES
}

pub fn validate_palw_fp_commitment_tx_under_v3(
    payload: &[u8],
    panel_da_admissible: bool,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
) -> Result<(), crate::palw_freeprompt_v3::PalwFpV3Error> {
    let payload: PalwFpCommitmentTxPayloadV3 =
        borsh::from_slice(payload).map_err(|_| crate::palw_freeprompt_v3::PalwFpV3Error::PayloadUndecodable)?;
    payload.validate_shape_under_v3(panel_da_admissible, prompt_ids_form)
}

/// **The isolation door's work-leaves cap** (ADR-0119 Decision 6): the structural
/// `PALW_FP_STRUCTURAL_WORK_LEAVES_CAP` (`2^32`) on a ruleset that declares no held regime, and the
/// regime's ladder (`2^40`) on one that does — a held class's job at `2^21` positions is `≈2^38`
/// leaves. Isolation holds no class and no height, so it asks the height-free question, exactly as
/// the model market's sink does (ADR-0087 D6, audit M-9); the header-context door refuses a
/// commitment past the structural cap below the fence ([`palw_fp_work_leaves_before_the_regime_v1`]),
/// so a build that schedules the regime has the transaction validity of one that does not carry it
/// at every height before the fence. The walk still bounds each commitment by its CLASS.
pub fn palw_fp_isolation_work_leaves_cap_v1(held_declared: bool) -> u64 {
    if held_declared {
        crate::palw_state_chunk_map::PALW_HELD_STEP_LADDER_V1
    } else {
        crate::palw_freeprompt_v3::PALW_FP_STRUCTURAL_WORK_LEAVES_CAP
    }
}

/// [`validate_palw_fp_commitment_tx_under_v3`] at a stated work-leaves cap
/// ([`palw_fp_isolation_work_leaves_cap_v1`]).
pub fn validate_palw_fp_commitment_tx_under_v4(
    payload: &[u8],
    panel_da_admissible: bool,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    work_leaves_cap: u64,
) -> Result<(), crate::palw_freeprompt_v3::PalwFpV3Error> {
    let payload: PalwFpCommitmentTxPayloadV3 =
        borsh::from_slice(payload).map_err(|_| crate::palw_freeprompt_v3::PalwFpV3Error::PayloadUndecodable)?;
    payload.validate_shape_under_ruleset_v3(panel_da_admissible, work_leaves_cap, None, prompt_ids_form)
}

/// [`validate_palw_fp_commitment_tx_under_v4`] **under the decode rules' height-free door**
/// (RFC-0001 §A.4): `decode_rules` is [`crate::palw_freeprompt_v3::PalwFpDecodeRulesV1::door`] of
/// `Params::palw_fp_decode_rules_fence` — `Dormant` on every ruleset that does not carry the
/// fence, so a V4 job is refused there exactly as a build without V4 refuses its bytes, and
/// `Scheduled` where it is carried, leaving the height to [`palw_fp_job_version_refusal_v1`].
pub fn validate_palw_fp_commitment_tx_under_v5(
    payload: &[u8],
    panel_da_admissible: bool,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    work_leaves_cap: u64,
    decode_rules: crate::palw_freeprompt_v3::PalwFpDecodeRulesV1,
) -> Result<(), crate::palw_freeprompt_v3::PalwFpV3Error> {
    let payload: PalwFpCommitmentTxPayloadV3 =
        borsh::from_slice(payload).map_err(|_| crate::palw_freeprompt_v3::PalwFpV3Error::PayloadUndecodable)?;
    payload.validate_shape_under_ruleset_v4(panel_da_admissible, work_leaves_cap, None, prompt_ids_form, decode_rules)
}

/// **The header-context half of the decode-rules door** (RFC-0001 §A.4): at the containing block's
/// height, which job version does this commitment carry that the height does not admit? A V4 job
/// below `Params::palw_fp_decode_rules`, or a V3 job at or past it — `Some(why)`; `None` for an
/// admissible version and for bytes that do not decode (isolation refused those already). With
/// the isolation door's `Scheduled` answer this makes a build that schedules the fence and one that
/// does not agree on every transaction below the fence.
pub fn palw_fp_job_version_refusal_v1(
    payload: &[u8],
    decode_rules: crate::palw_freeprompt_v3::PalwFpDecodeRulesV1,
) -> Option<&'static str> {
    let payload: PalwFpCommitmentTxPayloadV3 = borsh::from_slice(payload).ok()?;
    match payload.commitment.job.version {
        crate::palw_freeprompt_v3::PALW_FP_V4_VERSION if !decode_rules.admits_v4() => {
            Some("an FP Job V4 commitment below Params::palw_fp_decode_rules")
        }
        crate::palw_freeprompt_v3::PALW_FP_V3_VERSION if !decode_rules.admits_v3() => {
            Some("a new FP Job V3 commitment at or past Params::palw_fp_decode_rules — from the fence every new job is V4")
        }
        _ => None,
    }
}

/// **The header-context half of the door** (ADR-0119 Decision 6): the work leaves a commitment
/// declares, when they are past the structural cap — `Some(work_leaves)` is a commitment that only
/// the held regime's ladder admits, which the containing block's DAA must be past the fence for.
/// `None` for anything else, including bytes that do not decode (isolation refused those already).
pub fn palw_fp_work_leaves_before_the_regime_v1(payload: &[u8]) -> Option<u64> {
    let payload: PalwFpCommitmentTxPayloadV3 = borsh::from_slice(payload).ok()?;
    let leaves = payload.commitment.work_leaves;
    (leaves > crate::palw_freeprompt_v3::PALW_FP_STRUCTURAL_WORK_LEAVES_CAP).then_some(leaves)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::constants::TX_VERSION;
    use crate::palw_freeprompt_v3::{
        PALW_FP_PRIVACY_PUBLIC_DA, PALW_FP_V3_VERSION, PalwFpStopReasonV3, PalwFreePromptCommitmentV3, PalwFreePromptJobV3,
        fp_trace_manifest_v3,
    };
    use crate::subnets::{SUBNETWORK_ID_NATIVE, SUBNETWORK_ID_PALW_COMMITMENT};
    use crate::tx::{Transaction, TransactionId, TransactionOutpoint};
    use kaspa_hashes::Hash64 as H;

    fn h64(v: u64) -> Hash64 {
        H::from_u64_word(v)
    }

    fn net() -> Hash64 {
        h64(0x4E)
    }

    fn freeprompt() -> PalwFreePromptParamsV3 {
        crate::palw_fp_devnet_v3::palw_fp_devnet_bundle_for_tests(h64(1), h64(0xCA7), h64(0xC0757)).unwrap().freeprompt
    }

    /// A commitment whose CU earns real quanta under the devnet bundle.
    fn payload(prompt_tokens: u32, decode: u32) -> PalwFpCommitmentTxPayloadV3 {
        let ids: Vec<u32> = (0..prompt_tokens).collect();
        let job = PalwFreePromptJobV3 {
            version: PALW_FP_V3_VERSION,
            network_domain: net(),
            class_id: h64(1),
            executor_bond: TransactionOutpoint { transaction_id: TransactionId::from_u64_word(7), index: 0 },
            executor_pubkey: vec![7; 32],
            operator_id: h64(0xE0),
            anchor_block: h64(0xA0),
            anchor_daa: 5_000,
            job_nonce: [0x11; 32],
            tokenizer_id: h64(0x70),
            prompt_token_ids_hash: crate::palw_v2::prompt_token_ids_hash_v2(&ids),
            prompt_tokens,
            decode_token_limit: decode.max(1) + 1,
            max_context_tokens: 4_096,
            privacy_mode: PALW_FP_PRIVACY_PUBLIC_DA,
            prompt_mode: crate::palw_freeprompt_v3::PALW_FP_PROMPT_MODE_USER,
            sampling_seed: crate::palw_decode_select_v2::PALW_DECODE_SEED_GREEDY,
            temperature_q: crate::palw_decode_select_v2::PALW_DECODE_TEMPERATURE_GREEDY,
            decode: None,
            tail: None,
        };
        let events: Vec<Hash64> = (0..decode as u64).map(|i| h64(i + 1)).collect();
        let (manifest_root, chunk_count, _) = fp_trace_manifest_v3(h64(0xB1), &events);
        let commitment = PalwFreePromptCommitmentV3 {
            trace_root: h64(0x7A),
            output_root: h64(0x0B),
            execution_root: h64(0x4E),
            schedule_root: h64(0x5C),
            decode_tokens_executed: decode,
            stop_reason: PalwFpStopReasonV3::EndOfGeneration,
            work_leaves: (prompt_tokens as u64 + decode as u64) * 64,
            trace_manifest_root: manifest_root,
            trace_chunk_count: chunk_count,
            trace_retention_daa: 505_000,
            job,
        };
        PalwFpCommitmentTxPayloadV3 {
            version: PALW_FP_V3_VERSION,
            commitment,
            prompt_token_ids: ids,
            signature: vec![0x5A; crate::mldsa87_primitives::MLDSA87_SIGNATURE_LEN],
        }
    }

    fn tx(subnetwork: crate::subnets::SubnetworkId, payload_bytes: Vec<u8>) -> Transaction {
        Transaction::new(TX_VERSION, vec![], vec![], 0, subnetwork, 0, payload_bytes)
    }

    /// **RFC-0001 §A.4 at the walk: V3 below the decode-rules fence, V4 from it.** The accepting
    /// block's rule decides which of the two a carrier may open a claim with, so a V3 claim accepted
    /// before the fence is state and a new one past it is skipped, and a V4 commitment below the
    /// fence opens nothing; the door helpers answer the same way.
    #[test]
    fn the_walk_admits_one_job_version_per_side_of_the_decode_rules_fence() {
        use crate::palw_decode_pipeline_v4::DecodeConfigV4;
        use crate::palw_freeprompt_v3::PalwFpDecodeRulesV1;
        let v3 = payload(8, 4);
        let mut v4 = payload(8, 4);
        v4.commitment.job =
            v4.commitment.job.clone().into_v4(DecodeConfigV4 { stop_sequences: vec![vec![3]], ..DecodeConfigV4::NOOP });
        let walk = |p: &PalwFpCommitmentTxPayloadV3, rules: PalwFpDecodeRulesV1| {
            palw_fp_objects_from_accepted_txs_by_class_v1(
                &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(p).unwrap())],
                net(),
                &freeprompt(),
                crate::BlockHash::default(),
                false,
                |_| PalwFpClassCapsV1 {
                    step_ladder: 1 << 26,
                    held: false,
                    derived_work: PalwFpDerivedWorkCapV1::Declared,
                    logits_q24: true,
            prefix_state_armed: false,
            prefix_inherit_armed: false, prefix_inherit_class_safe: false,
            constraint_armed: false,
            constraint_v2_armed: false,
            tokenizer: crate::palw_fp_tokenizer_v1::PalwFpTokenizerRuleV1::Dormant,
                },
                false,
                false,
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                rules,
                |_, _, _, _| true,
            )
            .objects
            .len()
        };
        assert_eq!(walk(&v3, PalwFpDecodeRulesV1::Dormant), 1);
        assert_eq!(walk(&v4, PalwFpDecodeRulesV1::Dormant), 0, "no V4 claim below the fence");
        assert_eq!(walk(&v4, PalwFpDecodeRulesV1::Active), 1, "a V4 claim from the fence");
        assert_eq!(walk(&v3, PalwFpDecodeRulesV1::Active), 0, "no NEW V3 claim past the fence");
        // A V4 claim's id is the commitment's, which holds the V4 job — decode config and all.
        let mut moved = v4.clone();
        moved.commitment.job.decode.as_mut().unwrap().stop_sequences = vec![vec![4]];
        assert_ne!(moved.claim_id(), v4.claim_id());
        // The doors: isolation by the ruleset's schedule, the header context by the height.
        let (b3, b4) = (borsh::to_vec(&v3).unwrap(), borsh::to_vec(&v4).unwrap());
        let door = |bytes: &[u8], rules| {
            validate_palw_fp_commitment_tx_under_v5(bytes, false, crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat, 1 << 32, rules)
        };
        assert!(door(&b3, PalwFpDecodeRulesV1::Dormant).is_ok());
        assert_eq!(door(&b4, PalwFpDecodeRulesV1::Dormant), Err(crate::palw_freeprompt_v3::PalwFpV3Error::DecodeRulesNotArmed));
        assert!(door(&b4, PalwFpDecodeRulesV1::Scheduled).is_ok() && door(&b3, PalwFpDecodeRulesV1::Scheduled).is_ok());
        assert!(palw_fp_job_version_refusal_v1(&b4, PalwFpDecodeRulesV1::Dormant).is_some());
        assert!(palw_fp_job_version_refusal_v1(&b3, PalwFpDecodeRulesV1::Active).is_some());
        assert!(palw_fp_job_version_refusal_v1(&b4, PalwFpDecodeRulesV1::Active).is_none());
        assert!(palw_fp_job_version_refusal_v1(&b3, PalwFpDecodeRulesV1::Dormant).is_none());
        assert!(palw_fp_job_version_refusal_v1(&[0xFF; 4], PalwFpDecodeRulesV1::Active).is_none(), "isolation's to refuse");
    }

    /// **RFC-0001 §A.3's unit, RFC-0003 §I.3's convention, at the walk.** The temperature, the
    /// frequency and presence penalties and the logit bias are measured in the class's logit units
    /// (Q24). A class that does not commit its logits in Q24 — an IR or generative class registered
    /// before the fence that guarantees it — is offered greedy selection, the repeat penalty, stop
    /// sequences and constraints; a job asking it for a unit-dependent control is skipped by name, and
    /// the same job is extracted for a class that does. Below the decode-rules fence there is no V4 job
    /// and nothing here fires.
    #[test]
    fn a_class_that_does_not_commit_q24_logits_is_offered_only_the_unit_free_controls() {
        use crate::palw_decode_pipeline_v4::DecodeConfigV4;
        use crate::palw_freeprompt_v3::PalwFpDecodeRulesV1;
        let with = |temperature_q: u32, decode: DecodeConfigV4| {
            let mut p = payload(8, 4);
            p.commitment.job = p.commitment.job.clone().into_v4(decode);
            p.commitment.job.temperature_q = temperature_q;
            if temperature_q != 0 {
                p.commitment.job.sampling_seed = [0x33; 32];
            }
            p
        };
        let walk = |p: &PalwFpCommitmentTxPayloadV3, logits_q24: bool| {
            let out = palw_fp_objects_from_accepted_txs_by_class_v1(
                &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(p).unwrap())],
                net(),
                &freeprompt(),
                crate::BlockHash::default(),
                false,
                |_| PalwFpClassCapsV1 {
                    step_ladder: 1 << 26,
                    held: false,
                    derived_work: PalwFpDerivedWorkCapV1::Declared,
                    logits_q24,
            prefix_state_armed: false,
            prefix_inherit_armed: false, prefix_inherit_class_safe: false,
            constraint_armed: false,
            constraint_v2_armed: false,
            tokenizer: crate::palw_fp_tokenizer_v1::PalwFpTokenizerRuleV1::Dormant,
                },
                false,
                false,
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                PalwFpDecodeRulesV1::Active,
                |_, _, _, _| true,
            );
            (out.objects.len(), out.skipped)
        };
        let unit_free = [
            ("greedy, no controls", with(0, DecodeConfigV4::NOOP)),
            ("the repeat penalty", with(0, DecodeConfigV4 { repeat_penalty_q: 98_304, penalty_window: 6, ..DecodeConfigV4::NOOP })),
            ("a stop sequence", with(0, DecodeConfigV4 { stop_sequences: vec![vec![3]], ..DecodeConfigV4::NOOP })),
        ];
        let unit_dependent = [
            ("the temperature", with(1 << 24, DecodeConfigV4::NOOP)),
            ("the frequency penalty", with(0, DecodeConfigV4 { frequency_penalty_q: 1 << 23, penalty_window: 4, ..DecodeConfigV4::NOOP })),
            ("the presence penalty", with(0, DecodeConfigV4 { presence_penalty_q: -(1 << 22), penalty_window: 4, ..DecodeConfigV4::NOOP })),
            ("a logit bias", with(0, DecodeConfigV4 { logit_bias: vec![(3, 1 << 24)], ..DecodeConfigV4::NOOP })),
        ];
        for (what, p) in &unit_free {
            assert_eq!(walk(p, false).0, 1, "{what} is offered to a class with no declared unit");
            assert_eq!(walk(p, true).0, 1, "{what} is offered to every class");
        }
        for (what, p) in &unit_dependent {
            let (n, skipped) = walk(p, false);
            assert_eq!(n, 0, "{what} is not offered to a class with no declared unit");
            assert_eq!(skipped.len(), 1, "{what}: skipped with a reason, never silently dropped");
            assert!(skipped[0].1.contains("logit unit"), "{what}: {}", skipped[0].1);
            assert_eq!(walk(p, true).0, 1, "{what} is offered to a class that commits Q24 logits");
        }
        // The named predicate says which control, first by the order the RFC lists them.
        use crate::palw_freeprompt_v3::{PalwFpV3Error, palw_fp_decode_controls_offered_v1, palw_fp_unit_dependent_control_v1};
        let names: Vec<_> = unit_dependent.iter().map(|(_, p)| palw_fp_unit_dependent_control_v1(&p.commitment.job)).collect();
        assert_eq!(names, [Some("temperature_q"), Some("frequency_penalty_q"), Some("presence_penalty_q"), Some("logit_bias")]);
        assert!(unit_free.iter().all(|(_, p)| palw_fp_unit_dependent_control_v1(&p.commitment.job).is_none()));
        assert_eq!(
            palw_fp_decode_controls_offered_v1(&unit_dependent[0].1.commitment.job, false),
            Err(PalwFpV3Error::DecodeControlNeedsQ24Logits { control: "temperature_q" })
        );
        assert_eq!(palw_fp_decode_controls_offered_v1(&unit_dependent[0].1.commitment.job, true), Ok(()));
        // A V3 job asks for nothing here: below the fence the lane is exactly as it was.
        assert_eq!(palw_fp_unit_dependent_control_v1(&payload(8, 4).commitment.job), None);
    }

    /// **A commitment nobody signed for creates no claim** (launch blockers §4).
    ///
    /// `validate_stateless_v3`'s own doc said "the signature is verified by the caller" and there
    /// was no caller: `PalwFreePromptCommitmentEnvelopeV3::validate_signature_v3` had no use
    /// anywhere in the tree — the one call site of that method name is the SPEND envelope's. So a
    /// 0x4a transaction from any stranger created a claim bound to any bond outpoint it named,
    /// including the genesis premine bond pinned in `params.rs`, and the walk dropped
    /// `executor_pubkey` on the way.
    ///
    /// The verifier is an ARGUMENT now, so "somebody else checks it" is no longer expressible.
    #[test]
    fn a_commitment_whose_signature_does_not_verify_creates_no_claim() {
        let fp = freeprompt();
        let p = payload(96, 256);
        let carrier = tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap());

        // A verifier that answers honestly — this fixture carries no real signature.
        let refused = palw_fp_objects_from_accepted_txs_v3(
            std::slice::from_ref(&carrier),
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| false,
        );
        assert!(refused.objects.is_empty(), "an unsigned commitment must not become a claim");
        assert_eq!(refused.skipped.len(), 1, "and it is SKIPPED with a reason, not silently dropped");
        assert!(refused.skipped[0].1.contains("signature"), "got {}", refused.skipped[0].1);

        // The same carrier with a verifier that accepts still becomes exactly one object, so the
        // refusal above is the signature and nothing else.
        assert_eq!(
            palw_fp_objects_from_accepted_txs_v3(
                &[carrier],
                net(),
                &fp,
                h64(1),
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                |_, _, _, _| true
            )
            .objects
            .len(),
            1
        );
    }

    /// **ADR-0119 Decision 5: a commitment is bounded by its CLASS's ladder.** A held class recorded
    /// the regime's `2^40` when it registered, so its commitment of `2^27` leaves — past the network's
    /// `2^26` — is extracted, while the same commitment of a class that recorded nothing is skipped
    /// exactly as before, and past `2^40` both are skipped. The class is read off the commitment's
    /// own job, never off the carrier.
    #[test]
    fn a_held_class_commitment_is_bounded_by_its_own_ladder_and_every_other_by_the_networks() {
        let fp = freeprompt();
        let walk = |work_leaves: u64, held: bool| {
            let mut p = payload(96, 256);
            p.commitment.work_leaves = work_leaves;
            palw_fp_objects_from_accepted_txs_by_class_v1(
                &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap())],
                net(),
                &fp,
                h64(1),
                false,
                |class_id| {
                    assert_eq!(*class_id, h64(1), "the class is the commitment's own");
                    PalwFpClassCapsV1 {
                        step_ladder: if held { crate::palw_state_chunk_map::PALW_HELD_STEP_LADDER_V1 } else { 1 << 26 },
                        held,
                        // This test is about ADR-0119's ladder, so ADR-0145's derivation is off:
                        // its fixture's `work_leaves` is a bare power of two chosen to sit either
                        // side of a ladder, which no graph would ever count.
                        derived_work: PalwFpDerivedWorkCapV1::Declared,
                        logits_q24: true,
                        prefix_state_armed: false,
                        prefix_inherit_armed: false, prefix_inherit_class_safe: false,
            constraint_armed: false,
            constraint_v2_armed: false,
                        tokenizer: crate::palw_fp_tokenizer_v1::PalwFpTokenizerRuleV1::Dormant,
                    }
                },
                false,
                true,
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                crate::palw_freeprompt_v3::PalwFpDecodeRulesV1::Dormant,
                |_, _, _, _| true,
            )
        };
        assert_eq!(walk(1 << 27, true).objects.len(), 1, "a held class's job past the network's ladder");
        let shipped = walk(1 << 27, false);
        assert!(shipped.objects.is_empty() && shipped.skipped.len() == 1, "every other class's is skipped as before");
        assert!(walk((1 << 40) + 1, true).objects.is_empty(), "…and nothing passes the regime's own ladder");
        assert_eq!(walk(1 << 20, false).objects.len(), 1, "inside the network's ladder both are extracted");
    }

    /// **ADR-0119 Decision 6: the isolation door admits the regime's ladder only where the regime
    /// is declared**, and says which commitments the header-context door must hold to the
    /// structural cap below the fence.
    #[test]
    fn the_isolation_door_admits_the_regimes_ladder_only_where_the_regime_is_declared() {
        let at = |work_leaves: u64| {
            let mut p = payload(96, 256);
            p.commitment.work_leaves = work_leaves;
            borsh::to_vec(&p).unwrap()
        };
        let form = crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat;
        let wide = at(1 << 33);
        assert_eq!(palw_fp_isolation_work_leaves_cap_v1(false), crate::palw_freeprompt_v3::PALW_FP_STRUCTURAL_WORK_LEAVES_CAP);
        assert!(validate_palw_fp_commitment_tx_under_v4(&wide, false, form, palw_fp_isolation_work_leaves_cap_v1(false)).is_err());
        validate_palw_fp_commitment_tx_under_v4(&wide, false, form, palw_fp_isolation_work_leaves_cap_v1(true))
            .expect("a ruleset that declares the regime admits a held job's leaves at the door");
        assert_eq!(palw_fp_work_leaves_before_the_regime_v1(&wide), Some(1 << 33), "…which the header door holds below the fence");
        let narrow = at(1 << 20);
        validate_palw_fp_commitment_tx_under_v4(&narrow, false, form, palw_fp_isolation_work_leaves_cap_v1(false)).expect("inside");
        assert_eq!(palw_fp_work_leaves_before_the_regime_v1(&narrow), None);
        assert_eq!(palw_fp_work_leaves_before_the_regime_v1(b"junk"), None, "bytes isolation refused are not this door's");
    }

    /// **ADR-0103 Decision 4: under the held regime the ids never ride above one standard
    /// transaction.** A PublicDa carrier one id past `PALW_STANDARD_TX_BYTES / 4` is skipped by name
    /// under the fence and credited without it (the rule is dormant, and on a shipped network it
    /// could not fire); one AT the line is credited under both.
    #[test]
    fn under_the_held_regime_public_ids_past_one_transaction_are_skipped_by_name() {
        let fp = freeprompt();
        let line = (crate::palw_mode_v2::PALW_STANDARD_TX_BYTES / 4) as u32;
        let walk = |p: &PalwFpCommitmentTxPayloadV3, held: bool| {
            let mut p = p.clone();
            p.commitment.job.max_context_tokens = p.commitment.job.prompt_tokens + p.commitment.job.decode_token_limit;
            palw_fp_objects_from_accepted_txs_under_held_v3(
                &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap())],
                net(),
                &fp,
                h64(1),
                false,
                crate::palw_freeprompt_v3::PALW_FP_STRUCTURAL_WORK_LEAVES_CAP,
                false,
                held,
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                |_, _, _, _| true,
            )
        };
        let at_line = payload(line, 4);
        let past = payload(line + 1, 4);
        assert!(!palw_fp_public_ids_exceed_one_transaction_v1(&at_line));
        assert!(palw_fp_public_ids_exceed_one_transaction_v1(&past));
        assert_eq!(walk(&at_line, true).objects.len(), 1, "at the line the ids fit one transaction");
        assert_eq!(walk(&past, false).objects.len(), 1, "dormant, the walk is the ruleset walk");
        let held = walk(&past, true);
        assert!(held.objects.is_empty());
        assert!(held.skipped[0].1.contains("PanelDa"), "{:?}", held.skipped);
    }

    /// The signed message is the claim id under the commitment's own context, and the key it is
    /// checked against is the CARRIED one — whether that key is the named bond's is the stateful
    /// side's question, against the candidate-chain bond record.
    #[test]
    fn the_commitment_signature_is_checked_over_the_claim_id_in_its_own_context() {
        let fp = freeprompt();
        let p = payload(96, 256);
        let seen = std::cell::RefCell::new(Vec::new());
        let _ = palw_fp_objects_from_accepted_txs_v3(
            &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap())],
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |key, message, _sig, context| {
                seen.borrow_mut().push((key.to_vec(), message.to_vec(), context.to_vec()));
                true
            },
        );
        let seen = seen.into_inner();
        assert_eq!(seen.len(), 1, "the verifier was consulted exactly once");
        assert_eq!(seen[0].0, p.commitment.job.executor_pubkey, "under the carried key");
        assert_eq!(seen[0].1, p.claim_id().as_byte_slice(), "over the claim id");
        assert_eq!(seen[0].2, crate::palw_freeprompt_v3::PALW_FP_V3_MLDSA87_COMMITMENT_CONTEXT, "in its own domain");
    }

    /// The happy path: an accepted commitment becomes exactly one object, priced by the bundle    /// The happy path: an accepted commitment becomes exactly one object carrying the leaves the
    /// transition prices against the class's own job (ADR-0074 Decision 5) — never a price.
    #[test]
    fn an_accepted_commitment_becomes_one_object_carrying_its_leaves() {
        let fp = freeprompt();
        let p = payload(96, 256);
        let expected_claim = p.claim_id();

        let extracted = palw_fp_objects_from_accepted_txs_v3(
            &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap())],
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert_eq!(extracted.objects.len(), 1);
        assert!(extracted.skipped.is_empty());
        match &extracted.objects[0].object {
            PalwConsensusObjectV2::FreePromptCommitted {
                claim,
                class_id,
                bond,
                work_leaves,
                decode_tokens_executed,
                trace_root,
                output_root,
                ..
            } => {
                assert_eq!(*claim, expected_claim);
                assert_eq!(*class_id, h64(1));
                assert_eq!(bond.0.transaction_id, TransactionId::from_u64_word(7));
                assert_eq!((*work_leaves, *decode_tokens_executed), (p.commitment.work_leaves, 256));
                assert_eq!(*trace_root, h64(0x7A));
                assert_eq!(*output_root, h64(0x0B));
            }
            other => panic!("expected a free-prompt object, got {other:?}"),
        }
    }

    /// **The third DA field is carried by nothing, and that is pinned rather than repaired**
    /// (ADR-0072 Decision 8; mainnet audit 2026-09-06 M-3).
    ///
    /// `trace_retention_daa` and `trace_chunk_count` reach the state record and are given the
    /// chain's own values past `Params::palw_fp_da_pins`. `trace_manifest_root` reaches nothing:
    /// it is inside `fp_claim_id_v3`, so moving it renames the claim, and it is inside NOTHING
    /// else — the extracted object is otherwise byte-identical. This is the "pin the limitation,
    /// not just the behaviour" form: it PASSES today, because today the field carries no
    /// obligation, and it fails the day someone carries it, forcing them to decide what obligation
    /// it then bears.
    #[test]
    fn the_free_prompt_lanes_trace_manifest_root_is_carried_by_nothing() {
        let fp = freeprompt();
        let extract = |p: &PalwFpCommitmentTxPayloadV3| {
            palw_fp_objects_from_accepted_txs_v3(
                &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(p).unwrap())],
                net(),
                &fp,
                h64(1),
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                |_, _, _, _| true,
            )
        };
        let honest = payload(96, 256);
        let mut substituted = honest.clone();
        substituted.commitment.trace_manifest_root = h64(0xDEAD);
        assert_ne!(
            substituted.commitment.trace_manifest_root, honest.commitment.trace_manifest_root,
            "the fixture must actually move the field"
        );

        let a = extract(&honest);
        let b = extract(&substituted);
        assert_eq!((a.objects.len(), b.objects.len()), (1, 1), "both are admissible commitments");
        // The claim id DOES move, because the field is inside `fp_claim_id_v3` — which is the only
        // thing on this lane that reads it.
        let (mut object_a, mut object_b) = (a.objects[0].object.clone(), b.objects[0].object.clone());
        let (
            PalwConsensusObjectV2::FreePromptCommitted { claim: claim_a, .. },
            PalwConsensusObjectV2::FreePromptCommitted { claim: claim_b, .. },
        ) = (&mut object_a, &mut object_b)
        else {
            panic!("both extractions produce a free-prompt commitment");
        };
        assert_ne!(claim_a, claim_b, "the manifest root is inside the claim id, so it names the claim");
        // …and with the name normalised away, nothing else differs: no field of the consensus
        // object carries the manifest root, so no rule downstream can be about it.
        *claim_b = *claim_a;
        assert_eq!(
            object_a, object_b,
            "no field of the extracted object carries `trace_manifest_root` — if this fails, the field now travels and \
             something must decide what obligation it bears (ADR-0072 Decision 8)"
        );
    }

    /// A leaf count above the ladder is refused outright by the stateless rule, so it never
    /// becomes an object at all (a count within the ladder is the seats' to verify against the
    /// capture — ADR-0074 Decision 5).
    ///
    /// **The cap is the RULESET's, and the walk that has one is the one that applies it**
    /// (ADR-0082 Decision 1). This asked the arming-free entry about `PALW_STEP_MAX_LEAVES + 1`,
    /// which pinned the executor's `2^22` as the chain's ladder on a `2^26` network; the
    /// `_under_ruleset_v3` walk below is where the number lives now.
    #[test]
    fn a_leaf_count_above_the_cap_never_becomes_an_object() {
        let fp = freeprompt();
        let mut p = payload(96, 256);
        p.commitment.work_leaves = crate::palw_freeprompt_v3::PALW_FP_STRUCTURAL_WORK_LEAVES_CAP + 1;
        let extracted = palw_fp_objects_from_accepted_txs_v3(
            &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap())],
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert!(extracted.objects.is_empty());
        assert_eq!(
            extracted.skipped,
            vec![(tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap()).id(), "payload is not stateless-admissible")]
        );
    }

    /// Every skip reason is reachable and NAMED, so an operator can see a carrier being dropped:
    /// undecodable bytes and a foreign network. (Sub-quantum work is the transition's refusal,
    /// where the class's quantum lives — ADR-0074 Decision 5.)
    #[test]
    fn every_skip_reason_is_named() {
        let fp = freeprompt();

        let junk = tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, vec![0xFF; 32]);
        let out = palw_fp_objects_from_accepted_txs_v3(
            std::slice::from_ref(&junk),
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert_eq!(out.skipped, vec![(junk.id(), "payload does not decode")]);

        let foreign = tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&payload(96, 256)).unwrap());
        let out = palw_fp_objects_from_accepted_txs_v3(
            std::slice::from_ref(&foreign),
            h64(0x99),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert_eq!(out.skipped, vec![(foreign.id(), "payload is not stateless-admissible")], "a foreign network's payload");
    }

    /// Only the free-prompt subnetwork is read, and acceptance ORDER is preserved — the
    /// transition's ordering is consensus, so the extraction must not reorder or interleave.
    #[test]
    fn only_this_subnetwork_is_read_and_order_is_preserved() {
        let fp = freeprompt();
        let first = payload(96, 256);
        let second = payload(128, 192);
        let txs = vec![
            tx(SUBNETWORK_ID_NATIVE, vec![]),
            tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&first).unwrap()),
            // A V2-lineage carriage id is a different band with a different validator — reading
            // it here would hand one band's payload to the other band's rules.
            tx(SUBNETWORK_ID_PALW_COMMITMENT, borsh::to_vec(&first).unwrap()),
            tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&second).unwrap()),
        ];
        let out = palw_fp_objects_from_accepted_txs_v3(
            &txs,
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert_eq!(out.objects.len(), 2, "two free-prompt carriers, and only those");
        assert!(out.skipped.is_empty());
        let claims: Vec<Hash64> = out
            .objects
            .iter()
            .map(|c| match c.object {
                PalwConsensusObjectV2::FreePromptCommitted { claim, .. } => claim,
                _ => unreachable!(),
            })
            .collect();
        assert_eq!(claims, vec![first.claim_id(), second.claim_id()], "acceptance order is preserved");
    }

    /// **The door in front of the walk (0x4a's routing).**
    ///
    /// Admission is context-free, so it is deliberately WEAKER than the walk: it must never
    /// reject a carrier the walk would have credited, and everything it lets through that the
    /// walk refuses is skipped with a named reason rather than credited. Both directions are
    /// asserted, because only one of them is safe to get wrong.
    #[test]
    fn admission_never_refuses_what_the_walk_would_credit() {
        let fp = freeprompt();

        // A payload the walk credits is admitted.
        let good = borsh::to_vec(&payload(96, 256)).unwrap();
        assert!(validate_palw_fp_commitment_tx_under_v3(&good, false, crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat).is_ok());
        assert_eq!(
            palw_fp_objects_from_accepted_txs_v3(
                &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, good)],
                net(),
                &fp,
                h64(1),
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                |_, _, _, _| true
            )
            .objects
            .len(),
            1
        );

        // Undecodable bytes are refused at the door — the one shape failure that needs no
        // parameters at all.
        assert_eq!(
            validate_palw_fp_commitment_tx_under_v3(&[0xFF; 32], false, crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat),
            Err(crate::palw_freeprompt_v3::PalwFpV3Error::PayloadUndecodable)
        );

        // A shape failure the walk would skip is refused at the door instead, which is the same
        // answer reached earlier.
        let mut zero_decode = payload(96, 256);
        zero_decode.commitment.decode_tokens_executed = 0;
        assert!(
            validate_palw_fp_commitment_tx_under_v3(
                &borsh::to_vec(&zero_decode).unwrap(),
                false,
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat
            )
            .is_err()
        );

        // The two checks the door CANNOT run: a foreign network domain and an inflated price.
        // Both are admitted here — this node has no bundle in isolation — and both are skipped by
        // the walk, never credited. That is the deliberate asymmetry, pinned so a later "tighten
        // the door" edit has to argue with it.
        let foreign = borsh::to_vec(&payload(96, 256)).unwrap();
        assert!(
            validate_palw_fp_commitment_tx_under_v3(&foreign, false, crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat).is_ok(),
            "the door cannot know whose network this is"
        );
        let out = palw_fp_objects_from_accepted_txs_v3(
            &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, foreign)],
            h64(0x99),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert!(out.objects.is_empty(), "but the walk knows, and credits nothing");
        assert_eq!(out.skipped.len(), 1);

        // An inflated leaf count WITHIN the cap passes the door and the walk alike: neither holds
        // the capture, and the price is verified by the seats against it (ADR-0074 Decision 5).
        // Above the cap, the door itself refuses — that much it can know.
        //
        // **This is the assertion the 2026-09-19 reward audit filed as F2, and it is still
        // correct — below ADR-0145's derived-work fence.** Past that fence the walk holds the
        // class's published graph and refuses the same carrier by name; both behaviours and the
        // reason they coexist are pinned in
        // `ten_times_the_work_leaves_rides_below_the_fence_and_the_walk_refuses_it_past_it`. The
        // door's own answer never changes: it holds no graph at any height.
        let mut inflated = payload(96, 256);
        inflated.commitment.work_leaves *= 10;
        let inflated = borsh::to_vec(&inflated).unwrap();
        assert!(
            validate_palw_fp_commitment_tx_under_v3(&inflated, false, crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat).is_ok(),
            "the door cannot price without the capture"
        );
        let out = palw_fp_objects_from_accepted_txs_v3(
            &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, inflated)],
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert_eq!(out.objects.len(), 1, "and the walk carries the leaves for the seats to judge");
        let mut above = payload(96, 256);
        above.commitment.work_leaves = crate::palw_freeprompt_v3::PALW_FP_STRUCTURAL_WORK_LEAVES_CAP + 1;
        assert!(
            validate_palw_fp_commitment_tx_under_v3(
                &borsh::to_vec(&above).unwrap(),
                false,
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat
            )
            .is_err(),
            "the cap the door does know"
        );
    }

    /// **The ladder the network froze is the walk's, and the door is never stricter than it**
    /// (ADR-0082 Decision 1).
    ///
    /// The graph-v5 dense 512 row's canonical job counts more leaves than the executor's `2^22`,
    /// and the RC bundle admits the class at `2^26`. Both facts are asserted here against one
    /// commitment: transaction isolation admits it (the door holds no bundle, so it bounds at the
    /// structural top), the ruleset walk credits it at `2^26`, and a ruleset that froze `2^22`
    /// skips it by name. Before this, the door refused the carrier and no block could hold one.
    #[test]
    fn the_walk_bounds_a_commitment_at_the_rulesets_ladder_and_the_door_never_narrower() {
        let fp = freeprompt();
        let mut wide = payload(96, 256);
        wide.commitment.work_leaves = crate::palw_step::PALW_STEP_MAX_LEAVES + 1;
        let bytes = borsh::to_vec(&wide).unwrap();
        assert!(
            validate_palw_fp_commitment_tx_under_v3(&bytes, false, crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat).is_ok(),
            "isolation must not refuse a carrier the 2^26 walk would credit — that is the one direction the door may not fail in"
        );
        let carrier = tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, bytes);
        let at_rc = palw_fp_objects_from_accepted_txs_under_ruleset_v3(
            std::slice::from_ref(&carrier),
            net(),
            &fp,
            h64(1),
            false,
            crate::palw_fp_devnet_v3::COURT_MAX_STEP_LEAVES,
            false,
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert_eq!(at_rc.objects.len(), 1, "the shipped ruleset's 2^26 ladder admits it: {:?}", at_rc.skipped);
        let at_executor_constant = palw_fp_objects_from_accepted_txs_under_ruleset_v3(
            std::slice::from_ref(&carrier),
            net(),
            &fp,
            h64(1),
            false,
            crate::palw_step::PALW_STEP_MAX_LEAVES,
            false,
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        assert!(at_executor_constant.objects.is_empty(), "a ruleset that froze 2^22 refuses it");
        assert_eq!(at_executor_constant.skipped, vec![(carrier.id(), "payload is not stateless-admissible")]);
    }

    // ---- ADR-0145 §5: past the fence the walk prices the run instead of believing it ----

    /// The floor's own graph, and a payload whose class IS that graph — because past the fence a
    /// class id is not a name, it is the commitment to the graph the work is derived from.
    fn floor_profile() -> crate::palw_step::PalwShapeProfileV3 {
        crate::palw_base0_profile::base0_profile_v1(crate::palw_base0_profile::PALW_RC_BASE0_GEOMETRY).expect("the floor's profile")
    }

    /// A payload of `profile`'s class whose `work_leaves` is the number the graph actually counts
    /// for the run it declares. Everything else is `payload`'s.
    fn derived_payload(
        profile: &crate::palw_step::PalwShapeProfileV3,
        prompt_tokens: u32,
        decode: u32,
    ) -> PalwFpCommitmentTxPayloadV3 {
        let mut p = payload(prompt_tokens, decode);
        p.commitment.job.class_id = profile.shape_profile_id();
        p.commitment.work_leaves =
            crate::palw_step::step_leaf_count_of_tokens_capped_v1(profile, prompt_tokens, decode, 1 << 26).expect("inside the ladder");
        p
    }

    /// **The 2026-09-19 reward audit's F2, inverted into a regression fixture.**
    ///
    /// The audit's evidence for "the free-prompt lane's work is a self-report" was this repo's own
    /// test: `admission_never_refuses_what_the_walk_would_credit` multiplies `work_leaves`
    /// by ten and asserts the walk still credits the carrier. That assertion is still there and
    /// still passes, and BOTH are correct at once — which is the thing to understand before
    /// changing either.
    ///
    /// Below the fence the walk holds no graph. It cannot count leaves, so it carries the
    /// executor's number and the seats judge it; a walk that refused what it cannot check would be
    /// refusing on a guess. Past the fence the walk holds the class's published graph, so it
    /// counts, and a carrier whose number is not the graph's answer is SKIPPED — skipped, not
    /// rejected, because this walk must stay total over whatever a block already accepted (a
    /// refusal that invalidated the block would be a remote denial of service wearing a consensus
    /// rule's clothes).
    ///
    /// So the old assertion is "what a node that cannot price does" and this one is "what a node
    /// that can price does", and the fence is exactly the difference between them.
    #[test]
    fn ten_times_the_work_leaves_rides_below_the_fence_and_the_walk_refuses_it_past_it() {
        let fp = freeprompt();
        let profile = floor_profile();
        let class = profile.shape_profile_id();
        let honest = derived_payload(&profile, 96, 8);
        let mut inflated = honest.clone();
        inflated.commitment.work_leaves *= 10;

        let walk = |p: &PalwFpCommitmentTxPayloadV3, derived: PalwFpDerivedWorkCapV1<'_>| {
            palw_fp_objects_from_accepted_txs_by_class_v1(
                &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(p).unwrap())],
                net(),
                &fp,
                h64(1),
                false,
                |class_id| {
                    assert_eq!(*class_id, class, "the class is the commitment's own");
                    PalwFpClassCapsV1 { step_ladder: 1 << 26, held: false, derived_work: derived, logits_q24: true, prefix_state_armed: false, prefix_inherit_armed: false, prefix_inherit_class_safe: false, constraint_armed: false, constraint_v2_armed: false, tokenizer: crate::palw_fp_tokenizer_v1::PalwFpTokenizerRuleV1::Dormant }
                },
                false,
                true,
                crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
                crate::palw_freeprompt_v3::PalwFpDecodeRulesV1::Dormant,
                |_, _, _, _| true,
            )
        };

        // Below the fence: both ride, and the inflated one rides exactly as the audit found it.
        assert_eq!(walk(&honest, PalwFpDerivedWorkCapV1::Declared).objects.len(), 1);
        assert_eq!(
            walk(&inflated, PalwFpDerivedWorkCapV1::Declared).objects.len(),
            1,
            "a walk that cannot count leaves carries the executor's number — the F2 behaviour, kept below the fence"
        );

        // Past it: the honest one rides and the inflated one is skipped BY NAME.
        assert_eq!(walk(&honest, PalwFpDerivedWorkCapV1::Derived(&profile)).objects.len(), 1, "the graph's own answer is admitted");
        let refused = walk(&inflated, PalwFpDerivedWorkCapV1::Derived(&profile));
        assert!(refused.objects.is_empty(), "ten times the leaves is not what the graph counts");
        assert_eq!(refused.skipped.len(), 1, "and it is skipped with a reason, not silently dropped");
        assert!(refused.skipped[0].1.contains("work leaves"), "got {}", refused.skipped[0].1);

        // Understating is refused by the same equality, in the same place. Equality and not a
        // bound: an under-declared claim is still a claim whose price nobody derived, and one
        // rule with two directions is one rule to keep true.
        let mut understated = honest.clone();
        understated.commitment.work_leaves -= 1;
        assert!(walk(&understated, PalwFpDerivedWorkCapV1::Derived(&profile)).objects.is_empty());

        // And a class that has published no graph has every commitment of it skipped: a claim the
        // chain cannot price is a claim it must not credit. That is the whole cost of arming the
        // fence, and it is recoverable by one permissionless `ClassLaneCertified`.
        let unpublished = walk(&honest, PalwFpDerivedWorkCapV1::Unpublished);
        assert!(unpublished.objects.is_empty());
        assert!(unpublished.skipped[0].1.contains("shape profile"), "got {}", unpublished.skipped[0].1);
    }

    /// **The two execution facts the walk used to drop now reach the object** (ADR-0145 §5/§6).
    ///
    /// Without them the transition holds one half of the job context a leaf count reads and none
    /// of the prompt the cache rule reads, which is precisely why `palw_fp_decode_rules` could
    /// never be armed: its refusal names "the object carries no prompt_tokens". They are carried
    /// at every height, because the object never leaves the node that built it.
    #[test]
    fn the_walk_carries_the_prompt_length_and_the_prompt_itself() {
        let fp = freeprompt();
        let p = payload(96, 8);
        let out = palw_fp_objects_from_accepted_txs_v3(
            &[tx(SUBNETWORK_ID_PALW_FP_COMMITMENT, borsh::to_vec(&p).unwrap())],
            net(),
            &fp,
            h64(1),
            crate::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
            |_, _, _, _| true,
        );
        let crate::palw_state_v2::PalwConsensusObjectV2::FreePromptCommitted { prompt_tokens, prompt_token_ids, .. } =
            &out.objects[0].object
        else {
            panic!("the walk produced something else")
        };
        assert_eq!(*prompt_tokens, 96, "the job's own committed length");
        assert_eq!(prompt_token_ids.len(), 96, "and the ids the payload's validation already bound to it");
        assert_eq!(prompt_token_ids, &(0..96u32).collect::<Vec<_>>());
    }
}
