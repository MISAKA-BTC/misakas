//! kaspa-pq Phase 8 (PR-8.3): Layer 0 PoW finalizer + difficulty-lift
//! helpers.
//!
//! See [ADR-0007](../../docs/adr/0007-layered-pow.md). This module
//! contains the **consensus-critical, frozen** half of the Layered
//! PoW:
//!
//! 1. The BLAKE2b-512 keyed finalizer with
//!    [`POW_FINALIZER_DOMAIN`] as the key
//!    (`b"kaspa-pq-pow-v1"`).
//! 2. The 512-bit comparison domain, exposed as
//!    `Uint512`/`Uint576` operations re-exported from
//!    `kaspa_math`.
//! 3. The difficulty-lift helper that maps an upstream 256-bit
//!    target into the kaspa-pq 512-bit comparison domain
//!    (`target_512 = target_256 << 256`; see the ADR for the
//!    block-finding-probability preservation proof).
//!
//! The module is intentionally self-contained: it does **not**
//! reach into the consensus PoW validator yet. The wiring step
//! (PR-8.6) plugs `pow_finalizer_blake2b_512` into the actual
//! `verify_pow` path and consumes `header.pow_algo_id`
//! (introduced in PR-8.4).
//!
//! `algo_id` semantics: the Layer-1 tag is selected by
//! `header.pow_algo_id`. Defined ids:
//!   - `1` [`POW_ALGO_ID_KHEAVYHASH`] — Phase 1 kHeavyHash matrix.
//!   - `2` [`POW_ALGO_ID_ARGON2ID`] — Phase 2 memory-hard Argon2id
//!     (superseded; still *verifiable* for historical pruning
//!     proofs, but no live network selects it).
//!   - `3` [`POW_ALGO_ID_BLAKE2B_SHA3`] — Phase 3 compute-only
//!     BLAKE2b-512 ∥ SHA3-512 (the active testnet/mainnet algo).
//!   - `4` [`POW_ALGO_ID_PALW_LLM`] — Phase 4 PALW deterministic
//!     pinned-LLM inference (the active devnet algo; the mining
//!     work is one greedy Qwen3.5-2B transcript per attempt).
//! There is **no** mixed-`algo_id` difficulty arithmetic;
//! transitions are hard cut-offs at a specific DAA score, and a
//! header must declare exactly the id its network mandates
//! ([`required_algo_id`] / [`check_algo_id`]).

use blake2b_simd::Params;
use kaspa_hashes::{Hash, Hash64};
use kaspa_math::{Uint256, Uint512, Uint576};
use sha3::{Digest, Sha3_512};

/// BLAKE2b key for the Layer 0 PoW finalizer. Matches the
/// existing `crypto/hashes/src/hashers.rs` pattern of using a
/// short ASCII domain tag as the BLAKE2b key for cross-context
/// hash separation.
pub const POW_FINALIZER_DOMAIN: &[u8] = b"kaspa-pq-pow-v1";

/// Output width of the Layer 0 finalizer in bytes. Compared
/// against a 512-bit (`Uint512`) target.
pub const POW_FINALIZER_BYTES: usize = 64;

/// kaspa-pq Phase 1 Layer 1 algorithm id (the only one valid in
/// Phase 1).
///
/// Semantically: "this header's L1 tag is the upstream
/// `cSHAKE256("HeavyHash")` 32-byte digest, unchanged". Future
/// `algo_id` values introduce ASIC-hard L1 variants and ship in
/// their own hard-fork ADRs.
pub const POW_ALGO_ID_KHEAVYHASH: u8 = 1;

/// Maximum byte length of an L1 tag accepted by the Layer 0
/// finalizer. Acts as a defensive upper bound so a future
/// `algo_id` cannot accidentally inflate header validation cost
/// past a reasonable budget — actual lengths are fixed per
/// `algo_id` and validated up-stack.
pub const POW_L1_TAG_MAX_BYTES: usize = 256;

/// Domain-separator key for the algo_id = 1 (kHeavyHash) seed
/// derivation. kaspa-pq Phase 9 (PR-9.3) — see ADR-0008
/// §"algo_id = 1 (kHeavyHash) seed derivation".
///
/// The upstream kHeavyHash signature takes a 32-byte seed; the
/// kaspa-pq Phase 1 path derives that seed from the 64-byte
/// pre-PoW hash via a dedicated keyed BLAKE2b-256 so the 32-byte
/// seed cannot be substituted for any other 32-byte digest in the
/// system.
pub const POW_L1_KHEAVYHASH_V1_SEED_DOMAIN: &[u8] = b"kaspa-pq-l1-kheavyhash-v1-seed";

/// kaspa-pq Phase 2 Layer 1 algorithm id: **memory-hard Argon2id** (ADR-0007 §"Phase 2").
/// Replaces kHeavyHash on the networks where it is activated (testnet/mainnet) to compress the
/// GPU↔ASIC performance gap and prevent kHeavyHash/BLAKE2b ASICs (incl. Kaspa's) from being
/// reused against this chain. The Layer 0 BLAKE2b-512 finalizer is unchanged; only the Layer 1
/// tag computation differs.
pub const POW_ALGO_ID_ARGON2ID: u8 = 2;

/// Argon2id Layer-1 parameters (`algo_id = 2`). Memory cost is the ASIC-resistance lever; it is
/// paid per *hash attempt* by miners (millions/s → memory-bandwidth bound), while a verifier runs
/// it exactly once per block header (negligible). 16 MiB, 1 pass, 1 lane, 32-byte tag.
pub const POW_L1_ARGON2ID_M_COST_KIB: u32 = 16 * 1024;
pub const POW_L1_ARGON2ID_T_COST: u32 = 1;
pub const POW_L1_ARGON2ID_P_COST: u32 = 1;
pub const POW_L1_ARGON2ID_OUT_BYTES: usize = 32;
/// Domain separator (BLAKE2b key) for the algo_id = 2 Argon2id password + salt derivation.
pub const POW_L1_ARGON2ID_V1_DOMAIN: &[u8] = b"kaspa-pq-l1-argon2id-v1";

/// Reserved identifier for retired pinned-LLM PoW. Execution is removed; do not reuse the id.
pub const POW_ALGO_ID_PALW_LLM: u8 = 4;

/// Reserved identifier for retired Ollama PoW. Execution is removed; do not reuse the id.
pub const POW_ALGO_ID_PALW_OLLAMA: u8 = 5;

/// ADR-0042 Decision 3d: the V2 committed-attempt PoW.
///
/// Distinct from `POW_ALGO_ID_PALW_LLM` (4) and `POW_ALGO_ID_PALW_OLLAMA` (5) **so no pre-V2 node
/// can mistake a V2 block for a legacy algo-4 one.** Their L1 tags mean opposite things: algo-4's
/// is the inference itself, V2's is an expansion of the commitment root, and a node applying the
/// wrong reading would accept a block whose work it never checked.
///
/// Reusing 4 and changing its meaning was the alternative, and it is worse for the reason a new
/// genesis makes cheap to avoid: the RC starts from its own genesis, so nothing is owed a
/// compatibility shim, and an id that means two things across a fork is a permanent hazard for a
/// saving of one byte.
pub const POW_ALGO_ID_PALW_COMMITTED_V2: u8 = 6;

/// ADR-0044 Decision 6: the free-prompt **receipt-spend** block.
///
/// Distinct from [`POW_ALGO_ID_PALW_COMMITTED_V2`] (6) because their L1 tags mean different
/// things — 6's is `Expand(commitment_root)` of a fresh chain-challenge attempt (one new ticket
/// costs one new inference), 7's is `Expand(spend_id)` of a **certified** free-prompt quantum
/// (the inference already happened, was audited through the claim lattice, and reached `Final`;
/// the block admission is hashes, signatures, a beacon fact and a set lookup — no model, ever).
/// An id meaning two things across block kinds is the fork hazard a byte of id space is cheap
/// to avoid.
///
/// Like 6 before PR-10: **known, and demanded or accepted by nothing.** No fork flag returns it,
/// [`required_algo_id_for_mode`] never yields it (a `ConsensusV2` network demands 6 exclusively
/// until the FP bundle's wiring swaps the seam to the two-id set), and it is deliberately absent
/// from [`check_algo_id_known`] — the pruning-proof path must not accept a header whose tag this
/// binary cannot yet derive, because "accepted but unverifiable" downstream of that gate is the
/// remote-crash shape the unknown-algo-id P0 already exhibited once.
pub const POW_ALGO_ID_PALW_RECEIPT_V3: u8 = 7;

/// **ADR-0072 §3 option (b) — the execution-priced attempt lane, reached by activation.**
///
/// [`POW_ALGO_ID_PALW_COMMITTED_V2`] (6) and this id run the SAME rule in this binary: both tag
/// `Expand(execution_commitment_v3)`, both carry a `PalwAttemptEnvelopeV2`, both buy chain
/// position. So why a second id at all?
///
/// Because on a network that cannot re-mint, 6 has HISTORY, and that history was drawn under the
/// pre-ADR-0072 rule — a fresh ticket per nonce off `commitment_root_v2`. Mainnet's path to this
/// ADR is a fence, not a genesis (2026-08-27 doctrine), so one binary has to validate both sides
/// of it. The two sides need two ids, and the reason is not tidiness:
///
/// **`pow_algo_id` is inside the Layer-0 digest** (see the finalizer call in `kaspa_pow`, which
/// passes `self.pow_algo_id` into `finalize_layer0_512`). So an attempt solved for the old lane
/// produces a DIFFERENT digest when re-announced on the new one — it is not a losing candidate in
/// the new lottery, it is not a candidate at all. Cross-lane replay is refused by construction
/// rather than by a version field a producer fills in, which is ADR-0072 SA-4 and is what
/// `a_valid_old_lane_attempt_is_not_a_candidate_in_the_new_lane` pins.
///
/// **Not accepted anywhere until a network arms `Params::palw_attempt_activation`.** The bundle's
/// `accepts_algo_id` does not name it — a V2 bundle's two ids are 6 and 7 — so it reaches
/// acceptance only through the fence that the header processor ORs in, exactly as the heartbeat
/// lane does. Every shipped preset leaves that fence `None`, so today no network accepts an
/// algo-9 header and no producer builds one.
pub const POW_ALGO_ID_PALW_EXEC_V3: u8 = 9;

/// **Which attempt lane is open at a position, and what an envelope on it must say** (ADR-0072
/// SA-3/SA-4).
///
/// The one value that answers both halves of the fence, so they cannot drift: an activation that
/// opened a new algo id while leaving the version check un-fenced is exactly the defect ADR-0072
/// §3's Decision 7 analysis found ("a node on this build refuses every version-5 envelope, which is
/// every attempt block the chain already holds — a fresh node cannot validate the history it is
/// asked to sync").
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PalwAttemptLaneV1 {
    /// **No activation fence on this network.** The attempt lane is algo-6 carrying the current
    /// envelope, at every height — which is what every shipped preset does, and what testnet-11
    /// and devnet have done since they were re-minted onto ADR-0072's rule.
    Unfenced,
    /// **Armed, and this position is BELOW the fence.** The attempt lane is algo-6 carrying the
    /// legacy envelope: the history a fenced network is keeping. Algo-9 is not a lane here.
    LegacyArm,
    /// **Armed, and this position is at or above the fence.** The attempt lane is algo-9 carrying
    /// the current envelope. Algo-6 is no longer a lane: an old-lane block at a post-fence height
    /// is refused by id, before anything reads its version.
    ExecutionArm,
}

impl PalwAttemptLaneV1 {
    /// Resolve from a fence: `None` = un-armed network, `Some(active)` = armed, and whether this
    /// position is past it. Kept as an `Option<bool>` rather than a `ForkActivation` so this
    /// module stays free of `config` — the resolver that reads `Params` is
    /// `Params::palw_attempt_lane_at`.
    #[inline]
    pub fn from_fence(fence_active: Option<bool>) -> Self {
        match fence_active {
            None => Self::Unfenced,
            Some(false) => Self::LegacyArm,
            Some(true) => Self::ExecutionArm,
        }
    }

    /// The one algo id that carries the attempt lane here.
    #[inline]
    pub fn attempt_algo_id(self) -> u8 {
        match self {
            Self::Unfenced | Self::LegacyArm => POW_ALGO_ID_PALW_COMMITTED_V2,
            Self::ExecutionArm => POW_ALGO_ID_PALW_EXEC_V3,
        }
    }

    /// The envelope version admissible on that lane — **the fenced version check** (SA-3). Below
    /// the fence the chain's own history is legacy-versioned and must still validate; at and above
    /// it, only the current version is.
    #[inline]
    pub fn attempt_version(self) -> u16 {
        match self {
            Self::Unfenced | Self::ExecutionArm => crate::palw_attempt_v2::PALW_ATTEMPT_V2_VERSION,
            Self::LegacyArm => crate::palw_attempt_v2::PALW_ATTEMPT_V2_VERSION_PRE_ADR_0072,
        }
    }

    /// Is `algo_id` the attempt lane open HERE? Answers only about the two attempt ids — the
    /// receipt lane (7) and the heartbeat lane (8) are other fences' business and this must not
    /// speak for them.
    #[inline]
    pub fn admits_attempt_algo_id(self, algo_id: u8) -> bool {
        !is_palw_attempt_algo_id(algo_id) || algo_id == self.attempt_algo_id()
    }
}

/// The two ids that can carry a `PalwAttemptEnvelopeV2`, across the fence. Exactly one of them is
/// a lane at any position; [`PalwAttemptLaneV1::admits_attempt_algo_id`] says which.
#[inline]
pub fn is_palw_attempt_algo_id(algo_id: u8) -> bool {
    algo_id == POW_ALGO_ID_PALW_COMMITTED_V2 || algo_id == POW_ALGO_ID_PALW_EXEC_V3
}

/// **Does a header of this algorithm buy position in the chain?**
///
/// A receipt header's digest is free to re-roll: nothing in it costs anything to produce, so any
/// position it buys is bought with a signature. Two things are position — the pruning-proof
/// hierarchy (block LEVEL) and the fork-choice weight (blue WORK) — and both must answer no, for
/// the same reason. They used to answer separately, and only the level half said no; a receipt
/// block still added `calc_work(bits)` to its descendants' blue work, which is reorg weight minted
/// out of signatures.
///
/// The lane's real meter is the quantum ticket (ADR-0044 Decision 6), which draws against a beacon
/// derived from the candidate's own chain — so it can only run on a chain candidate and cannot gate
/// DAG entry at all. A merged-but-never-candidate receipt block never faces it, which is why the
/// answer here may not be "the ticket handles it".
///
/// **The heartbeat lane is deliberately NOT here, and the distinction is load-bearing.** It answers
/// no to one of the two purchases and yes to the other, so it needs its own predicate — see
/// [`algo_id_derives_no_block_level`].
#[inline]
pub fn algo_id_carries_no_chain_position(algo_id: u8) -> bool {
    // ADR-0125: a round block buys neither — it is never blue and never a selected parent, so no
    // block's blue work or level may be minted out of the lane's signatures either.
    algo_id == POW_ALGO_ID_PALW_RECEIPT_V3 || algo_id == POW_ALGO_ID_PALW_ROUND_V1
}

/// **Block LEVEL only** — the pruning-proof hierarchy, without the fork-choice half.
///
/// [`algo_id_carries_no_chain_position`] answers both questions at once because for the receipt
/// lane both answers are the same. For the heartbeat lane they are NOT, and reading one predicate
/// for both is a bug I made and this comment exists to stop:
///
/// * **Level: zero.** A heartbeat's target is a network constant, so its digest is not priced by
///   anything that scales — a lucky solve lands far under a FIXED target as often as under a hard
///   one, and `calc_level_from_pow_512` would read that luck as hierarchy. A lane meant to keep a
///   stopped chain ticking must not also buy pruning-proof structure at 2²⁴ hashes a go.
/// * **Blue work: ε, not zero.** Zero is right for the receipt lane because all chain weight comes
///   from the attempt lane. It is WRONG here: the regime this lane exists for is total bonded
///   collapse, where every block is a heartbeat, and with zero work every such branch ties at the
///   selected parent's weight and nothing orders them. `ε × n` orders the longer chain first,
///   which is the whole of ADR-0060 Decision 1.2.
///
/// Folding the heartbeat into the shared predicate makes the ghostdag arm return 0 before the ε
/// arm is ever reached — the two arms are in that order — so the lane silently stops weighing
/// anything and a collapsed chain cannot pick a tip.
#[inline]
pub fn algo_id_derives_no_block_level(algo_id: u8) -> bool {
    algo_id_carries_no_chain_position(algo_id) || algo_id == POW_ALGO_ID_HEARTBEAT_V1
}

/// **Is a header of this algorithm priced by `header.bits`?** — the difficulty window's question
/// (ADR-0083 Decision 1).
///
/// `bits` is the one field the global difficulty window retargets, and the retarget assumes every
/// row it counts was produced against `bits`: that is what makes "rows per second" a measurement
/// of the work the network is putting in. The heartbeat lane is the exception, by ADR-0066
/// Decision 1: its target is the network constant `2⁻²⁴` (the `target_512` arm of
/// `kaspa_pow::State::new`), so its rows cost the same whatever `bits` says. Counted as ordinary
/// rows they measure the number of heartbeat EMITTERS, not work — five emitters on the two-minute
/// cadence read as a chain running three times too fast, and the retarget tightened testnet-11's
/// `bits` by ×320 in 826 blocks while the heartbeats never noticed (Relaunch 5f, 2026-09-04).
/// That is ADR-0066's F1 re-entering through the row COUNT after Decision 1 took the lane's
/// PRICE out of `bits`.
///
/// The attempt lanes (6, 9) compare a digest against `bits` through the Layer-0 finalizer and the
/// hash lanes (1–3) directly. **This used to say the receipt lane (7) does too, and it does not**
/// (mainnet audit, 2026-09-05): `check_pow_layer0` returns `true` unconditionally for lane 7 —
/// ADR-0044 Decision 6, a receipt's digest is identity-binding and its work is the certified quantum
/// it spends — so a receipt row costs the same whatever `bits` says, exactly as a heartbeat row
/// does. Counted as a priced row it measures how fast quanta are being spent, not work, and a
/// producer holding a stock of certified quanta could tighten every attempt lane's `bits` off its
/// own chain: ADR-0066's F1 again, through the lane this doctrine forgot. The corrected predicate is
/// [`algo_id_is_priced_by_bits_v2`]; this one is kept, byte for byte, as the rule every block before
/// `Params::palw_receipt_rows_unpriced` was judged under.
#[inline]
pub fn algo_id_is_priced_by_bits(algo_id: u8) -> bool {
    // ADR-0125: a round block never enters a window at all (it is outside the DAA set), and its
    // target is a constant besides — no algo-10 header predates the id, so this moves no history.
    algo_id != POW_ALGO_ID_HEARTBEAT_V1 && algo_id != POW_ALGO_ID_PALW_ROUND_V1
}

/// **ADR-0083 Decision 1's predicate, as the decision states it**: a row counts iff its lane
/// compares a digest against `header.bits`. The heartbeat lane (8) has a constant target; the
/// receipt lane (7) has no target at all (`check_pow_layer0` admits every receipt digest). Every
/// other lane is priced. In force past `Params::palw_receipt_rows_unpriced`.
#[inline]
pub fn algo_id_is_priced_by_bits_v2(algo_id: u8) -> bool {
    algo_id != POW_ALGO_ID_HEARTBEAT_V1 && algo_id != POW_ALGO_ID_PALW_RECEIPT_V3 && algo_id != POW_ALGO_ID_PALW_ROUND_V1
}

/// **Is a header of this algorithm priced by `header.bits` past the single lottery?** (ADR-0132 S,
/// `Params::palw_single_lottery`.)
///
/// Past that fence an attempt header's Layer-0 digest is not compared to `bits` at all — the class
/// ticket is the whole lottery, and the digest exists to bind the header to the execution that won
/// it. A row nothing prices may not price the window: counting it would measure a cadence the
/// class tickets set against a target no block pays, and the retarget would walk `bits` without
/// bound in whichever direction the models happened to produce. The receipt lane's own arm
/// ([`algo_id_is_priced_by_bits_v2`]) is the same rule for the same reason, one fence earlier.
#[inline]
pub fn algo_id_is_priced_by_bits_v3(algo_id: u8) -> bool {
    algo_id_is_priced_by_bits_v2(algo_id) && !is_palw_attempt_algo_id(algo_id)
}

/// kaspa-pq Phase 3 Layer 1 algorithm id: **compute-only BLAKE2b-512 ∥ SHA3-512** (ADR-0007 §"Phase 3").
///
/// Replaces Argon2id (`algo_id = 2`) on the networks where it is activated (testnet/mainnet) to make
/// header verification ~10^4× cheaper, which is the IBD/catch-up bottleneck under a memory-hard PoW
/// (a verifier runs the Layer-1 tag once per header). The trade-off is explicit and accepted: the PoW
/// is no longer memory-hard, so GPU/FPGA/ASIC acceleration is possible — the chain's safety leans on
/// the two-dimensional (PoW × stake) DNS finality overlay (ADR-0009) rather than PoW egalitarianism.
/// The Layer-0 BLAKE2b-512 finalizer is unchanged; only the Layer-1 tag differs.
pub const POW_ALGO_ID_BLAKE2B_SHA3: u8 = 3;

/// **ADR-0066 Decision 1: the heartbeat lane's own algorithm id.**
///
/// The lane used to share `POW_ALGO_ID_BLAKE2B_SHA3` (3) and be told apart by a triple gate —
/// `id == 3 && ConsensusV2 && PALW_HEARTBEAT_LANE_ENABLED`. Three things had to agree for a rule to
/// apply, so a rule could be reached by two of them and missed by the third. Its own id collapses
/// all three into one observable, and buys two more properties outright:
///
/// * a solved algo-3 header from a HASH network can never be replayed as a heartbeat, because the
///   Layer-0 digest binds `pow_algo_id`; and
/// * the id becomes the fence's own observable — `Params::palw_heartbeat` decides whether this id
///   is accepted at all, so "is the lane open" is a params question rather than a `const bool` a
///   rebuild could change without moving any fingerprint.
///
/// **Its Layer-1 tag is algo-3's**, deliberately: the lane is a self-verifying hash lane and wants
/// exactly that tag. Only the id and the target differ, and the id is inside the digest, so the two
/// lanes cannot borrow each other's solutions.
pub const POW_ALGO_ID_HEARTBEAT_V1: u8 = 8;

/// **The heartbeat lane's price, as a work exponent — a network CONSTANT, never `header.bits`.**
///
/// This is the whole of ADR-0066 Decision 1. The first implementation retargeted the lane inside
/// `header.bits`, which is the field the global difficulty window averages: a window of heartbeat
/// rows demanded work 33,554,432, no bonded block could re-enter it, and the chain became
/// heartbeat-only and recoverable only by re-mint. A fixed target cannot feed back on itself.
///
/// 2²⁴ hash evaluations is a couple of seconds of one CPU: a legitimate miner pays it once per
/// interval, a sibling-flooder pays it per block. `Params::palw_heartbeat`'s `work_log2` must equal
/// this or `validate_palw_v2` refuses to start — the fence declares the price it believes it is
/// arming, and a binary that cannot compute that price says so at boot rather than at block one.
pub const PALW_HEARTBEAT_WORK_LOG2: u32 = 24;

/// **How many heartbeat blocks one mergeset may hold — ADR-0066 F3a's bound, as a network
/// CONSTANT.** (ADR-0068 Phase 1.)
///
/// The slot rule bounds the CHAIN (one heartbeat per interval behind its selected parent) and the
/// fixed price bounds nothing but the header rate: siblings share one selected parent, one
/// admissible timestamp and one price, so nothing bounded how many of them the DAG accepts — that
/// is finding 3a, recorded open when the lane landed. The bound that closes it is placed where
/// `mergeset_size_limit` already lives: a valid block's mergeset (selected parent included) may
/// carry at most this many heartbeat-lane members, so sibling floods are absorbed at a bounded
/// rate instead of wholesale, and a flood older than the merge depth is simply never merged.
/// Four is one heartbeat-parent chain slot plus three siblings of healing headroom: a partition
/// that ran on the clock heals a foreign heartbeat chain at three per block, while an honest
/// steady state (one heartbeat per interval) never sees two.
///
/// `Params::palw_heartbeat`'s `max_per_mergeset` must equal this or `validate_palw_v2` refuses to
/// start — same stance, same reason as `work_log2` above.
pub const PALW_HEARTBEAT_MAX_PER_MERGESET: u64 = 4;

/// **The attempt lane's fork-choice work, as a work exponent — a network CONSTANT, never
/// `calc_work(header.bits)`.** ADR-0066 Decision 3 (finding F2), staged there and closed here
/// (ADR-0068 Phase 1).
///
/// On a `ConsensusV2` network the hash target is not the throttle — the class lottery is — so
/// `header.bits` sits at `MAX_DIFFICULTY_TARGET` and `calc_work` prices every bonded block at
/// **2**. Against `HEARTBEAT_BLUE_WORK_EPSILON = 1` that is parity for two sibling heartbeats per
/// layer (~280 kH/s), which is finding F2: ε was never too large, the other side of the
/// comparison was too small. Under the fence, an attempt-lane block's blue work is this constant
/// instead: 2²⁰, so a bonded block outweighs a million heartbeats again and the ε ordering among
/// heartbeat-only branches (total collapse) is undisturbed.
///
/// **A constant, deliberately NOT the envelope's claimed pwu.** The claim is verified against
/// class state (target, per-inference cost) and class state lives on the selected chain — at
/// GHOSTDAG time there is only the header. A claim-derived work would let a shape-valid header
/// that never faces the lottery mint fork-choice weight with a number; a constant keeps the
/// spam/honest ratio exactly where it is today (parity at work 2, parity at work 2²⁰) while
/// fixing the one ratio F2 is about. Per-CLASS weight (a QWEN36 block vs a floor block) is not
/// this layer's job either: that is the pwu-verified PALW chain weight (`safe(C)`, ADR-0058),
/// which only counts what the chain actually checked.
///
/// `Params::palw_attempt_work`'s `work_log2` must equal this or `validate_palw_v2` refuses to
/// start — the fence declares the price it believes it is arming.
pub const PALW_ATTEMPT_BLUE_WORK_LOG2: u32 = 20;

/// **ADR-0125: the execution lane's algorithm id — a round block.**
///
/// A round block is a fee-only block of the execution lane: it carries transactions beside the
/// PALW chain and is never part of it. It is never a selected parent, never blue, never counted in
/// the DAA score and never priced by `bits`, so every window, retarget and depth the chain reads
/// is what it would be without the lane. Its admission is a permit — a bond drawn for the round
/// from the schedule the chain derives out of finalized attempts — carried in `palw_commitment` as
/// a signed [`crate::palw_execution_lane_v1::PalwExecEnvelopeV1`], and its PoW is a fixed
/// network-constant target ([`PALW_ROUND_WORK_LOG2`]) that only prices a header's existence.
///
/// **Its Layer-1 tag is algo-3's**, as the heartbeat's is: a self-verifying hash lane. The id is
/// inside the Layer-0 digest, so a solution for one lane is never a solution for another.
///
/// Accepted only past `Params::palw_execution_lane`, which the header processor ORs in exactly as
/// it does the heartbeat lane. No shipped preset arms it.
pub const POW_ALGO_ID_PALW_ROUND_V1: u8 = 10;

/// **The round lane's price, as a work exponent — a network CONSTANT, never `header.bits`.**
///
/// 2¹⁶ hash evaluations are a few milliseconds of one core, so a permit holder pays it inside its
/// one-second round even at the lane's widest stage. It does not meter the lane — the permit does
/// — it makes every round block cost something to exist, so a header that is not worth a few
/// milliseconds is not worth relaying either.
pub const PALW_ROUND_WORK_LOG2: u32 = 16;

/// **The attempt lane's Layer-0 TARGET, as a network constant** (ADR-0071 Decision 1).
///
/// [`PALW_ATTEMPT_BLUE_WORK_LOG2`] took the lane's fork-choice WEIGHT off `header.bits`. This takes
/// its PRICE off the same field, and the reason is the one ADR-0066 already wrote down for the
/// heartbeat lane: `bits` is what the difficulty window averages, so any lane priced by it is a
/// lane whose cost the chain's own history feeds back into.
///
/// For the attempt lane the feedback does not show up in fork choice — the weight is already a
/// constant — it shows up in **admission**. `bits` sets the global target, and a V2 network's
/// throttle is supposed to be the per-class ticket lottery against `state.class_target`, which is
/// chain state. Left window-derived, `bits` hardens whenever blocks arrive faster than the cadence
/// and a bonded producer must then buy its block with hashing, which is exactly what a network
/// whose work is inference must not require.
///
/// The value is the ambient V2 target — `MAX_DIFFICULTY_TARGET` in compact form, which is what
/// every V2 genesis already carries (`PALW_RC_GENESIS`, `DEVNET_GENESIS`). Asserted against the
/// constant rather than typed twice, in this module's tests.
pub const PALW_V2_ATTEMPT_BITS: u32 = 0x207fffff;

/// Output width of the algo_id = 3 Layer-1 tag: BLAKE2b-512 (64) ∥ SHA3-512 (64) = 128 bytes. Within
/// [`POW_L1_TAG_MAX_BYTES`] (256), so the Layer-0 finalizer accepts it.
pub const POW_L1_BLAKE2B_SHA3_OUT_BYTES: usize = 128;
/// Domain separator for the algo_id = 3 BLAKE2b-512 ∥ SHA3-512 Layer-1 tag. Used as the BLAKE2b key
/// for the first half and as an explicit prefix for the (un-keyed) SHA3-512 second half.
pub const POW_L1_BLAKE2B_SHA3_V1_DOMAIN: &[u8] = b"kaspa-pq-l1-blake2b-sha3-v1";

/// Errors returned by Layer 0 helpers.
#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum PowLayer0Error {
    #[error("kaspa-pq Layer 0: L1 tag length {0} exceeds POW_L1_TAG_MAX_BYTES = {POW_L1_TAG_MAX_BYTES}")]
    L1TagTooLong(usize),
    #[error("kaspa-pq Layer 0: pow_algo_id = {0} is unrecognised or wrong for this network's active PoW phase")]
    UnknownAlgoId(u8),
    /// The PALW (`algo_id = 4`) Layer-1 tag needs the pinned LLM worker and it is not usable in
    /// this process — `PALW_WORKER`/`MISAKA_PALW_GGUF` unset, the binary missing, or a wasm build.
    /// Carries an operator-actionable reason; validating a PALW header without a worker is a node
    /// configuration error, not a bad block.
    #[error("PALW Layer-1 unavailable: {0}")]
    PalwUnavailable(String),
    /// The PALW worker ran but did not produce a usable projection (non-zero exit, timeout, or an
    /// unparseable/short document). Deterministic-compute contract means a *disagreeing* projection
    /// simply yields a tag that fails the target; this variant is for runs that yielded no tag.
    #[error("PALW worker failed: {0}")]
    PalwWorkerFailed(String),
    /// MISAKA ADR-0038: a non-PALW header carries `palw_commitment` bytes. The field is
    /// hash-invisible on non-PALW algo ids (see `hashing::header::write_header_preimage`), so
    /// non-empty bytes there would be block-hash malleability — two distinct serialized blocks
    /// with one identity. Structural refusal, independent of any activation fence.
    #[error("non-PALW header (algo_id = {algo_id}) carries {got} palw_commitment bytes; must be empty")]
    NonPalwHeaderCarriesPalwCommitment { algo_id: u8, got: usize },
    /// MISAKA ADR-0038: a PALW header's `palw_commitment` exceeds the wire cap.
    #[error("palw_commitment is {got} bytes, above the cap {cap}")]
    PalwCommitmentTooLong { got: usize, cap: usize },
    /// **ADR-0072 SA-4: an attempt header on the wrong side of the activation fence.**
    ///
    /// Exactly one of the two attempt ids is a lane at any position, and the fence decides which.
    /// This is the refusal an old-lane block gets when it is replayed past the fence — by ID,
    /// before its envelope's version is read, which is why the two cannot be confused: a producer
    /// chooses the version field and does not choose which lottery `pow_algo_id` puts it in.
    #[error("attempt header carries algo_id {algo_id}, but the open attempt lane at this height is {open}")]
    PalwAttemptLaneClosed { algo_id: u8, open: u8 },
    /// MISAKA ADR-0038: a PALW header carries a `palw_commitment` while **nothing in the PoW
    /// path binds it** — the same malleability as
    /// [`Self::NonPalwHeaderCarriesPalwCommitment`], reached from the other side.
    ///
    /// On a PALW header the commitment is *identity*-visible and *PoW*-invisible (it is a
    /// function of the winning nonce, so it cannot sit in the pre-PoW preimage without
    /// circularity). Until some PoW-path digest consumes it, those two facts compose into:
    /// one PoW solution mints unlimited distinct valid block identities. The field is
    /// therefore refused non-empty until the binding exists — see
    /// [`check_palw_commitment_shape_at`] for the exact precondition to relax this.
    #[error(
        "PALW header (algo_id = {algo_id}) carries {got} palw_commitment bytes, but no PoW-path digest binds them yet; must be empty"
    )]
    PalwCommitmentNotYetBound { algo_id: u8, got: usize },
    /// ADR-0038 Decision A is installed and the header's commitment is not a commitment.
    #[error("PALW header (algo_id = {algo_id}) carries a palw_commitment that is not a well-formed PBC1 commitment: {reason}")]
    PalwCommitmentMalformed { algo_id: u8, reason: String },
    /// ADR-0042 Decision 3a: an algo-6 header reached the finalizer without a decodable V2
    /// attempt envelope in `palw_commitment`. The envelope IS what the committed-V2 PoW prices
    /// — its absence means there is no work to check, so the header cannot be valid. Total
    /// error, never a panic: the pruning-proof path computes PoW on peer-supplied headers
    /// before any shape gate has run.
    #[error("PALW-V2 header (algo_id = 6) carries no decodable attempt envelope; the PoW has nothing to price")]
    PalwV2AttemptMissing,
    /// The algo-7 counterpart (ADR-0044 Decision 6): a V3-lineage header reached the finalizer
    /// without the carriage its tag expands. Same posture as `PalwV2AttemptMissing` — the shape
    /// gate refuses such a header up-stack, so reaching here means a caller skipped it, and a
    /// failed PoW is the answer rather than an `expect` on absent data.
    #[error("PALW header (algo_id = {0}) carries no decodable carriage for its lane's tag")]
    PalwCarriageMissing(u8),
    /// ADR-0042 Decision 3a: the carried attempt's `challenge` is not the one this header
    /// position derives — the envelope was mined for a different (pre_pow_hash, timestamp,
    /// nonce, class, bond). Refused by the finalizer arm itself so that EVERY path that
    /// computes PoW refuses a re-mounted attempt, including proof paths that never reach
    /// stateful admission.
    #[error("PALW-V2 attempt's carried challenge is not the one this header position derives")]
    PalwV2ChallengeMismatch,
}

/// MISAKA ADR-0038: the PALW family of Layer-1 algo ids — the ids whose headers carry (and
/// hash) a `palw_commitment`, and the gate `hashing::header::write_header_preimage` reads.
#[inline]
/// The V2-LINEAGE ids: the attempt lane and the receipt lane. Distinct from
/// [`is_palw_algo_id`], which is the whole PALW family including the V1 lineage — these are the
/// two ids that carry a `PalwChainStateV2`, and the ones the state root's preimage gate reads.
pub fn is_palw_v2_algo_id(algo_id: u8) -> bool {
    // ADR-0072 SA-4: the execution-priced attempt lane is the SAME lineage as 6 — it carries a
    // `PalwChainStateV2` and commits a state root — so it must be in this set from the moment the
    // id exists, or a `palw_state_root` on an algo-9 header would be hash-invisible and stuffable.
    is_palw_attempt_algo_id(algo_id) || algo_id == POW_ALGO_ID_PALW_RECEIPT_V3
}

pub fn is_palw_algo_id(algo_id: u8) -> bool {
    algo_id == POW_ALGO_ID_PALW_LLM
        || algo_id == POW_ALGO_ID_PALW_OLLAMA
        || is_palw_attempt_algo_id(algo_id)
        || algo_id == POW_ALGO_ID_PALW_RECEIPT_V3
        // ADR-0125: a round block carries its permit envelope in `palw_commitment`, which must be
        // identity-visible (and shape-checked) exactly as every other PALW carriage is.
        || algo_id == POW_ALGO_ID_PALW_ROUND_V1
}

/// MISAKA ADR-0038: wire cap for `Header::palw_commitment` — the PBC1 envelope (4 magic +
/// borsh body incl. one ML-DSA-87 signature ≈ 4.9 KB) with headroom, far below anything that
/// could stress header relay, and small enough that a spam candidate cannot smuggle bulk data.
pub const PALW_COMMITMENT_MAX_BYTES: usize = 8192;

/// The shape rule on the **un-fenced** lane — a test-only convenience, kept because most of the
/// crate's shape assertions are about a network with no ADR-0072 fence. The rule itself is
/// documented on [`check_palw_commitment_shape_at`], which is the one every pipeline calls.
///
/// # This entry point IS a lane, and the crate boundary is what says so
///
/// `Unfenced` is not a neutral default — it is "algo-6 is the attempt lane at every height", which
/// is a consensus statement about the position. Spelled as an omitted argument it is invisible,
/// and a pipeline gate that omitted it refused algo-9 by id: `check_palw_block_admission_v1` took
/// this entry point, its live caller is the UTXO validator, and on a network armed at genesis
/// every chain candidate was disqualified with `PalwAttemptLaneClosed { algo_id: 9, open: 6 }`
/// before anything decoded. Two earlier gates (the relay carriage dispatch, the pruning proof) had
/// the same shape and were threaded; this one was invisible to the sweep that found them because
/// the file never names an algo-id constant at all.
///
/// So the fix is not a comment: **no consensus gate can reach this function any more.** It is
/// `#[cfg(test)]`, and every remaining caller is a test inside `kaspa-consensus-core`. A pipeline
/// in `kaspa-consensus`, `kaspa-pow` or `kaspad` must call [`check_palw_commitment_shape_at`] and
/// name the lane it means — the compiler, not a reviewer, is what enforces that. (`pub(crate)`
/// alone was not enough: the dead-code lint immediately reported the function unused in a non-test
/// build, which is the fact this attribute now states.)
#[cfg(test)]
#[inline]
pub(crate) fn check_palw_commitment_shape(algo_id: u8, palw_commitment: &[u8], bound: bool) -> Result<(), PowLayer0Error> {
    // An un-fenced network is what every shipped preset is, so this is the same function it always
    // was; the fenced entry point below is what an armed network calls.
    check_palw_commitment_shape_at(algo_id, palw_commitment, bound, PalwAttemptLaneV1::Unfenced)
}

/// MISAKA ADR-0038: structural shape rule for `Header::palw_commitment`, enforced wherever
/// header shape is validated (alongside [`check_algo_id`]) and NOT behind any activation
/// fence:
///
/// * non-PALW `algo_id` → the field MUST be empty. It is hash-invisible there, and a
///   hash-invisible non-empty field is block-hash malleability (two serialized blocks, one
///   identity) — a relay/dedup poison, refused at the door.
/// * PALW V1 `algo_id` (4 / 5) → the field MUST **also** be empty, for now. See below.
/// * `POW_ALGO_ID_PALW_COMMITTED_V2` (6) → the field is REQUIRED, and required to decode as a
///   [`crate::palw_attempt_v2::PalwAttemptEnvelopeV2`]. V2's binding is intrinsic — the finalizer
///   tag is `Expand(commitment_root_v2)` — so the empty-until-bound reasoning below does not
///   apply to it, and neither does the `bound` fence (that fence is V1's rebinding decision).
///
/// # Why the PALW side is empty-only until the PoW binds it
///
/// The first draft of this rule allowed any length up to [`PALW_COMMITMENT_MAX_BYTES`] on a
/// PALW header, reasoning that requiring a commitment is an activation decision rather than a
/// shape rule. That is true of *requiring* one. It is not true of *permitting* one, and the
/// permission was the bug (mainnet-readiness re-audit, 2026-08-17, blocker 4):
///
/// * `hashing::header` writes the commitment into the **block-identity** digest only, and
///   passes `Exclude` on every PoW-path digest — correctly, because the commitment is a
///   function of the winning nonce and cannot enter the pre-PoW preimage without circularity
///   (the algo-4 seed already consumes `pre_pow_hash`).
/// * Nothing in `consensus/pow` reads `palw_commitment` — the PoW path still derives its
///   Layer-1 tag from the inference, not from this field.
///
/// Compose those and the field is identity-visible, PoW-invisible and content-unchecked:
/// **one PoW solution mints unlimited distinct valid block identities**, each a separate DAG
/// entry. That is the same defect the non-PALW arm above refuses, arrived at from the other
/// direction, and it was live and unfenced on every PALW network.
///
/// Empty-only is a stronger containment than an activation fence would be, and deliberately so:
/// a fence is a switch somebody can flip before the binding exists, whereas an unrepresentable
/// state cannot be flipped at all. Honest nodes lose nothing — no mining path populates this
/// field (its only non-test writers are the p2p and RPC *deserializers*, i.e. untrusted peer
/// input), so this rule rejects exactly the attack and nothing else.
///
/// **Precondition to relax this**: some PoW-path digest must consume the commitment, so that
/// altering it invalidates the solution. Under ADR-0038 Decision A that is the ticket rebinding
/// — the Layer-1 tag must be derived from the committed root rather than re-run inference — at
/// which point this arm becomes "must decode as PBC1", the digest gate in `hashing::header`
/// opens with it, and the two land together behind one activation fence. Relaxing it before
/// then re-opens the malleability.
///
/// # The attempt lane travels with the POSITION (ADR-0072 SA-3/SA-4)
///
/// Two things move with `lane`, and both had to, or the fence would be half a fence:
///
/// * **which attempt id is a lane at all** — an algo-6 header at a post-fence height is refused
///   here by ID, before its version is read, and an algo-9 header below the fence likewise. That
///   is SA-4's "by algo id, not merely by version", enforced at the shape gate rather than left to
///   the Layer-0 digest to notice (the digest refuses it too — `pow_algo_id` is inside it — but a
///   named refusal beats an unexplained PoW failure);
/// * **which envelope version that lane admits** — SA-3. Below the fence the chain's own
///   pre-ADR-0072 history must validate, and it is version
///   [`crate::palw_attempt_v2::PALW_ATTEMPT_V2_VERSION_PRE_ADR_0072`].
pub fn check_palw_commitment_shape_at(
    algo_id: u8,
    palw_commitment: &[u8],
    bound: bool,
    lane: PalwAttemptLaneV1,
) -> Result<(), PowLayer0Error> {
    // **A-2 uniformity: no form added after the live build is in force on this entry point** — it reads every such form's bytes as
    // the live testnet-12 build (int-12, `0b1c11b87`) reads them. A pipeline that holds the header's height names the forms in force
    // there through [`check_palw_commitment_shape_with_forms_at`].
    check_palw_commitment_shape_with_forms_at(algo_id, palw_commitment, bound, lane, |_| false)
}

/// **A-2 uniformity for header carriages: the `palw_commitment` forms added after the live testnet-12 build, each owned by a fence.**
///
/// The live build's shape gate has no arm for these forms, so it refuses their headers (a `PFS4` carriage on an algo-7 header is read
/// as a `PFS3` one and fails its magic). A build that admits the form's shape at a height where its fence is not in force accepts —
/// on every path that runs only this gate, the pruning proof's included — a header the live build refuses: a split before the fence.
/// So below its fence a form is read exactly as the live build reads it, and past it the form's own rules apply.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum PalwHeaderFormFenceV1 {
    /// RFC-0009's `PFS4` receipt carriage (a V4 public-redemption spend) on an algo-7 header — `Params::palw_receipt_spend_v4`.
    ReceiptSpendV4,
    /// RFC-0008 v2's `PXE2` EXEC envelope on an algo-10 header — `Params::palw_exec_payload_v2` (only on a `ConsensusV2` network).
    ExecPayloadV2,
}

impl PalwHeaderFormFenceV1 {
    /// Every owned form. A form added here needs its `HeaderForm` row in
    /// `crate::palw_lifecycle_objects_v2::PALW_A2_KIND_FENCE_TABLE_V1`, which the table test reconciles.
    pub const ALL: [Self; 2] = [Self::ReceiptSpendV4, Self::ExecPayloadV2];

    /// The `Params` field the form's fence is resolved from.
    pub const fn params_field(self) -> &'static str {
        match self {
            Self::ReceiptSpendV4 => "palw_receipt_spend_v4",
            Self::ExecPayloadV2 => "palw_exec_payload_v2",
        }
    }
}

/// Which owned form a header's carriage is, if any (`None`: a form the live build knows, judged as it judges it at every height).
pub fn palw_header_form_owner_v1(algo_id: u8, palw_commitment: &[u8]) -> Option<PalwHeaderFormFenceV1> {
    if algo_id == POW_ALGO_ID_PALW_RECEIPT_V3 && crate::palw_receipt_v4::palw_receipt_v4_carriage_is_v4(palw_commitment) {
        return Some(PalwHeaderFormFenceV1::ReceiptSpendV4);
    }
    (algo_id == POW_ALGO_ID_PALW_ROUND_V1 && crate::palw_exec_v2::PalwExecV2Envelope::is_v2_carriage(palw_commitment))
        .then_some(PalwHeaderFormFenceV1::ExecPayloadV2)
}

/// **The header forms' owning fences, resolved once from `Params`** (`Params::palw_header_form_fences_v1`) and handed to every gate
/// that holds a header's height: the header processor, the pruning proof and the UTXO validator's block admission. `Default` is every
/// fence unarmed — the live build's reading.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct PalwHeaderFormFencesV1 {
    pub receipt_spend_v4: Option<crate::config::params::ForkActivation>,
    pub exec_payload_v2: Option<crate::config::params::ForkActivation>,
}

impl PalwHeaderFormFencesV1 {
    /// Is `form`'s fence in force at `daa_score` (`never()` read as absence)?
    pub fn in_force_at(&self, form: PalwHeaderFormFenceV1, daa_score: u64) -> bool {
        match form {
            PalwHeaderFormFenceV1::ReceiptSpendV4 => self.receipt_spend_v4,
            PalwHeaderFormFenceV1::ExecPayloadV2 => self.exec_payload_v2,
        }
        .is_some_and(|activation| activation != crate::config::params::ForkActivation::never() && activation.is_active(daa_score))
    }
}

impl crate::config::params::Params {
    /// The header forms' owning fences ([`PalwHeaderFormFencesV1`]).
    pub fn palw_header_form_fences_v1(&self) -> PalwHeaderFormFencesV1 {
        PalwHeaderFormFencesV1 {
            receipt_spend_v4: self.palw_receipt_spend_v4_fence(),
            exec_payload_v2: self.palw_exec_payload_v2_fence(),
        }
    }
}

/// RFC-0008 v2's spelling of [`check_palw_commitment_shape_with_forms_at`]: only the `PXE2` form, in force where `exec_v2_active`.
pub fn check_palw_commitment_shape_exec_at(
    algo_id: u8,
    palw_commitment: &[u8],
    bound: bool,
    lane: PalwAttemptLaneV1,
    exec_v2_active: bool,
) -> Result<(), PowLayer0Error> {
    check_palw_commitment_shape_with_forms_at(algo_id, palw_commitment, bound, lane, |form| {
        exec_v2_active && form == PalwHeaderFormFenceV1::ExecPayloadV2
    })
}

/// [`check_palw_commitment_shape_at`] with the owned header forms in force at the header's position named by `form_in_force` —
/// below its fence a form is the live build's malformed carriage (its cap, its decode, its refusal), past it the form's own.
pub fn check_palw_commitment_shape_with_forms_at(
    algo_id: u8,
    palw_commitment: &[u8],
    bound: bool,
    lane: PalwAttemptLaneV1,
    form_in_force: impl Fn(PalwHeaderFormFenceV1) -> bool,
) -> Result<(), PowLayer0Error> {
    let form = palw_header_form_owner_v1(algo_id, palw_commitment).filter(|form| form_in_force(*form));
    if !is_palw_algo_id(algo_id) {
        // Unconditional, fence or no fence: a non-PALW header's commitment is hash-INVISIBLE
        // (`write_header_preimage` length-prefixes it only for PALW ids), so a non-empty one is
        // block-hash malleability. This arm never relaxes.
        if !palw_commitment.is_empty() {
            return Err(PowLayer0Error::NonPalwHeaderCarriesPalwCommitment { algo_id, got: palw_commitment.len() });
        }
        return Ok(());
    }
    // The cap is checked first so an oversized payload reports the cap it broke rather than the
    // binding rule — the two errors mean different things to an operator.
    // RFC-0009: a `PFS4` receipt carriage (two signatures and two keys) has its own, larger cap. Every other carriage — including a `PFS3`
    // receipt — keeps the 8,192-byte one, so the set of acceptable payloads below `palw_receipt_spend_v4` is unchanged (a `PFS4` header is
    // refused by name at the header stage until the fence opens).
    // A2U: only where the form's fence is in force; below it the cap is the live build's, as is every other byte of the gate.
    let cap = if form == Some(PalwHeaderFormFenceV1::ReceiptSpendV4) {
        crate::palw_receipt_v4::PALW_COMMITMENT_MAX_BYTES_V4
    } else if form == Some(PalwHeaderFormFenceV1::ExecPayloadV2) {
        crate::palw_exec_v2::PALW_EXEC_V2_MAX_ENVELOPE_BYTES
    } else {
        PALW_COMMITMENT_MAX_BYTES
    };
    if palw_commitment.len() > cap {
        return Err(PowLayer0Error::PalwCommitmentTooLong { got: palw_commitment.len(), cap });
    }
    // The V2-lineage lanes carry their OWN objects under their own magics, and they carry them
    // ALWAYS — not behind the V1 fence (ADR-0042 Decision 1 removed that machine, and ADR-0044
    // kept its lesson). No fence parameter is consulted here because none is needed: an algo-6
    // or algo-7 header only exists on a network whose mode demands that id, which
    // `check_algo_id_for_mode` decided up-stack. What the finalizer expands is exactly what this
    // gate insists is present and well-formed, so "tagged but unvalidated" is unrepresentable.
    if is_palw_attempt_algo_id(algo_id) {
        // ADR-0072 SA-4: the wrong side of the fence is not a lane. Checked before the envelope is
        // decoded, so an old-lane block replayed past the fence is refused for what it IS rather
        // than for what it says about itself.
        if !lane.admits_attempt_algo_id(algo_id) {
            return Err(PowLayer0Error::PalwAttemptLaneClosed { algo_id, open: lane.attempt_algo_id() });
        }
        // The field is REQUIRED and required to be a V2 envelope: an attempt header without one
        // carries no work to price, and the finalizer refuses it as `PalwV2AttemptMissing`
        // anyway; failing HERE names the shape defect (wrong magic, truncated body, zero pwu…)
        // instead of a digest mismatch.
        let envelope = crate::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(palw_commitment)
            .map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() })?;
        return envelope
            .validate_shape_v2_at_version(lane.attempt_version())
            .map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() });
    }
    if algo_id == POW_ALGO_ID_PALW_RECEIPT_V3 {
        // RFC-0009: the magic says which receipt carriage this is; both are the receipt lane's, and a payload of neither is malformed.
        // A2U: a `PFS4` carriage is the V4 one only where `palw_receipt_spend_v4` is in force; below it, it is read as the live build
        // reads it — a `PFS3` decode, refused for its magic.
        if form == Some(PalwHeaderFormFenceV1::ReceiptSpendV4) {
            return crate::palw_receipt_v4::PalwReceiptSpendEnvelopeV4::decode(palw_commitment)
                .map(|_| ())
                .map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() });
        }
        return crate::palw_freeprompt_v3::PalwReceiptSpendEnvelopeV3::decode(palw_commitment)
            .map(|_| ())
            .map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() });
    }
    if algo_id == POW_ALGO_ID_PALW_ROUND_V1 {
        // RFC-0008 v2: where the fence is in force the magic says which envelope this is; both are the lane's, and a payload of
        // neither is malformed. Shape only — that a `PXR1` one is refused past the fence is the stateless carriage check's.
        if form == Some(PalwHeaderFormFenceV1::ExecPayloadV2) {
            return crate::palw_exec_v2::PalwExecV2Envelope::decode(palw_commitment)
                .and_then(|envelope| envelope.validate_shape())
                .map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() });
        }
        // ADR-0125: the permit envelope is REQUIRED — a round block without one names no permit.
        // Shape only here; the round, the signature and the network are the stateless carriage
        // check's, and whether the bond holds the permit is the merging block's.
        return crate::palw_execution_lane_v1::PalwExecEnvelopeV1::decode(palw_commitment)
            .and_then(|envelope| envelope.validate_shape())
            .map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() });
    }
    if !bound {
        // ADR-0038 Decision A is not installed on this network at this DAA, so the field stays
        // shut. That refusal was never a placeholder: the field IS hash-visible on a PALW header,
        // so bytes nothing validates would let one inference mint distinct blocks.
        if !palw_commitment.is_empty() {
            return Err(PowLayer0Error::PalwCommitmentNotYetBound { algo_id, got: palw_commitment.len() });
        }
        return Ok(());
    }
    // Bound: the commitment is required, and must be a commitment rather than arbitrary bytes.
    // Bound: the commitment is required, and must be a commitment rather than arbitrary bytes.
    // Emptiness falls out of the decoder (no PBC1 magic), which is the right error to report —
    // "this is not a commitment", not "this is the wrong length".
    let commitment = crate::palw_block_commitment::PalwBlockCommitmentV1::decode(palw_commitment)
        .map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() })?;
    // Shape only. Whether `pwu_claim` equals its derivation from the class's DAA target, and
    // whether `executor_bond_outpoint` names an Active bond, are stateful questions this pure
    // function cannot ask — they belong to `validate_against_class_v1` and to the bond check, at
    // the consumer entry that holds that state. Decision A's other clauses are still unwired.
    commitment.validate_shape().map_err(|e| PowLayer0Error::PalwCommitmentMalformed { algo_id, reason: e.to_string() })
}

/// Validate that an `algo_id` is recognised by this binary at
/// Phase 1. Rejects everything except `POW_ALGO_ID_KHEAVYHASH`.
#[inline]
pub fn check_algo_id_phase1(algo_id: u8) -> Result<(), PowLayer0Error> {
    if algo_id == POW_ALGO_ID_KHEAVYHASH { Ok(()) } else { Err(PowLayer0Error::UnknownAlgoId(algo_id)) }
}

/// **V2 is deliberately absent from this cascade** (ADR-0042 Decision 1). Its activation is not a
/// sixth boolean beside the others — the ADR's whole point is that a ruleset with five independently
/// flippable switches is the defect, since a human flips them in the wrong order. `PalwConsensusMode`
/// carries the V2 ruleset whole or not at all, and the arm that returns
/// [`POW_ALGO_ID_PALW_COMMITTED_V2`] lands with it in PR-10. Until then this function can never
/// return it, which is what makes the id inert on every shipped network while its semantics exist.
///
/// The Layer-1 algorithm a header MUST declare, given which PoW forks are active at the header's
/// DAA score. The PALW-Ollama fork (`algo_id = 5`) supersedes everything where activated; then
/// the PALW worker fork (`algo_id = 4`); then the Phase-3 BLAKE2b-512 ∥ SHA3-512 fork
/// (`algo_id = 3`); otherwise the Phase-1 `algo_id = 1` (kHeavyHash). This is a hard cut-off —
/// there is no mixed-algo arithmetic. (Argon2id, `algo_id = 2`, is the superseded Phase-2
/// algorithm: still *verifiable* via [`check_algo_id_known`] for historical pruning proofs, but
/// no live network selects it.)
#[inline]
pub fn required_algo_id(palw_ollama_active: bool, palw_llm_active: bool, blake2b_sha3_active: bool) -> u8 {
    if palw_ollama_active {
        POW_ALGO_ID_PALW_OLLAMA
    } else if palw_llm_active {
        POW_ALGO_ID_PALW_LLM
    } else if blake2b_sha3_active {
        POW_ALGO_ID_BLAKE2B_SHA3
    } else {
        POW_ALGO_ID_KHEAVYHASH
    }
}

/// Validate a header's `algo_id` against the network's PoW state: it must equal
/// [`required_algo_id`]. Rejects both unknown ids and the *wrong-but-known* id (e.g. a miner trying
/// the cheap kHeavyHash on a BLAKE2b-SHA3 or PALW network, or vice-versa).
#[inline]
pub fn check_algo_id(
    algo_id: u8,
    palw_ollama_active: bool,
    palw_llm_active: bool,
    blake2b_sha3_active: bool,
) -> Result<(), PowLayer0Error> {
    if algo_id == required_algo_id(palw_ollama_active, palw_llm_active, blake2b_sha3_active) {
        Ok(())
    } else {
        Err(PowLayer0Error::UnknownAlgoId(algo_id))
    }
}

/// The algorithm a header MUST declare, with the V2 mode consulted FIRST (ADR-0042 Decision 1,
/// PR-08 seam).
///
/// `mode_required` is [`crate::palw_mode_v2::PalwConsensusMode::required_algo_id`]: `Some(6)`
/// exactly on a `ConsensusV2` network, `None` on `Disabled` / `LegacyTn11` — which is **every**
/// network that exists today. So on every shipped preset this is `required_algo_id(...)`
/// unchanged, byte for byte; only a network carrying the whole atomic V2 bundle demands the
/// committed-V2 id, and it does so exclusively — a V2 network accepts nothing else, and the V1
/// cascade is not consulted for it. This is the one place "does this network demand V2" is
/// decided, so a site cannot answer it a second, drifting way.
#[inline]
pub fn required_algo_id_for_mode(
    mode_required: Option<u8>,
    palw_ollama_active: bool,
    palw_llm_active: bool,
    blake2b_sha3_active: bool,
) -> u8 {
    mode_required.unwrap_or_else(|| required_algo_id(palw_ollama_active, palw_llm_active, blake2b_sha3_active))
}

/// [`check_algo_id`], with the V2 mode consulted first via [`required_algo_id_for_mode`]. The
/// validation processors and the pruning-proof gate call THIS, so the mode's demand and the
/// header's declaration are compared in one place.
#[inline]
pub fn check_algo_id_for_mode(
    algo_id: u8,
    mode_required: Option<u8>,
    palw_ollama_active: bool,
    palw_llm_active: bool,
    blake2b_sha3_active: bool,
) -> Result<(), PowLayer0Error> {
    check_algo_id_for_mode_accepting(algo_id, mode_required, None, palw_ollama_active, palw_llm_active, blake2b_sha3_active)
}

/// [`check_algo_id_for_mode`], asking the network what it ACCEPTS rather than what it demands.
///
/// A V2 bundle admits two lanes — the committed attempt and the free-prompt receipt spend — and a
/// gate comparing against `required_algo_id` alone refused every block on the second. The two
/// questions are genuinely different and both are needed: a PRODUCER building an attempt must
/// declare `required_algo_id`, while a VALIDATOR deciding whether a header may exist must ask
/// `accepts_algo_id`. Conflating them is what left the receipt lane unenterable on a network whose
/// own bundle said it was open.
///
/// `mode_accepts` is [`crate::palw_mode_v2::PalwConsensusMode::accepts_algo_id`]. `None` — every
/// non-V2 preset, and any caller that has not been given the mode — falls through to the exact
/// single-id comparison this function had before, byte for byte.
pub fn check_algo_id_for_mode_accepting(
    algo_id: u8,
    mode_required: Option<u8>,
    mode_accepts: Option<bool>,
    palw_ollama_active: bool,
    palw_llm_active: bool,
    blake2b_sha3_active: bool,
) -> Result<(), PowLayer0Error> {
    if let Some(accepted) = mode_accepts {
        return if accepted { Ok(()) } else { Err(PowLayer0Error::UnknownAlgoId(algo_id)) };
    }
    if algo_id == required_algo_id_for_mode(mode_required, palw_ollama_active, palw_llm_active, blake2b_sha3_active) {
        Ok(())
    } else {
        Err(PowLayer0Error::UnknownAlgoId(algo_id))
    }
}

/// Does Layer-0 PoW verification short-circuit for this header instead of reaching the Layer-1
/// finalizer?
///
/// **The one definition of "parentless root", shared by the PoW entry points and by every gate that
/// must run before them.** `kaspa_pow::calc_block_level_check_pow_layer0` returns
/// `(max_block_level, true)` without touching the finalizer exactly when this is true.
///
/// It is `parents_by_level.is_empty()`, NOT `direct_parents().is_empty()`, and the difference is a
/// live remote-panic vector rather than a nicety. [`crate::header::Header::direct_parents`] reads
/// `parents_by_level[0]` and yields `&[]` when that run exists but is EMPTY — so for a header whose
/// `parents_by_level` is `[[]]`, `direct_parents()` says "parentless" while the PoW short-circuit
/// does not fire. A gate exempting parentless headers on the `direct_parents` predicate therefore
/// skipped `check_algo_id` on precisely the header shape whose PoW still runs, letting
/// `algo_id = 4` reach the PALW arm on a worker-less node and panic it. Found by an adversarial
/// verifier with a proof-of-concept after the first version of the pruning-proof gate shipped with
/// the mismatched predicate (mainnet-readiness audit P0-1, trigger b).
///
/// Callers that mean "the PoW will actually run, so gate the input first" must use this.
#[inline]
pub fn pow_short_circuits_as_parentless_root(header: &crate::header::Header) -> bool {
    header.parents_by_level.is_empty()
}

/// Accept any algo_id this binary knows how to verify ({kHeavyHash, Argon2id, BLAKE2b-SHA3,
/// PALW LLM, PALW Ollama}).
///
/// **NOT USED BY ANY PATH, deliberately.** The doc here used to say "e.g. the pruning-proof path",
/// and that path does NOT use it: `pruning_proof::check_proof_header_shape` applies the strict
/// per-DAA [`check_algo_id`], because proof-only headers below the pruning point are never
/// re-processed by the main pipeline and the looser rule would admit an algo the network did not
/// mandate at that DAA (audit POW-01). Reading this function's doc as a description of live
/// behaviour was therefore wrong in the one direction that matters: it described a defence that
/// was not wired.
///
/// It is kept because the strict rule has a real cost it names correctly: `required_algo_id` never
/// returns Argon2id (2), so a chain that had actually run the Phase-2 algorithm could not have its
/// historical proof headers validated under [`check_algo_id`]. No shipped preset activates
/// Argon2id, so nothing is broken today — but a network that ever does must switch its proof path
/// to a rule that admits the algo its own history used, and this is that rule.
///
/// A caller MUST NOT substitute this for [`check_algo_id`] on a network whose history is
/// single-algo: accepting "any known id" there lets a proof header claim an algorithm the network
/// never mandated, which is a cheaper PoW than the one its difficulty was set for.
/// **This list is the set of ids `kaspa_pow::StateLayer0::calculate_l1_tag` implements.** It is
/// not the set of ids that have a CONSTANT — those are two different things, and conflating them
/// was audit C1: `POW_ALGO_ID_PALW_COMMITTED_V2` had a constant, four pipeline gates that could
/// DEMAND it, and no arm in the finalizer, so a network in `ConsensusV2` mode booted happily,
/// accepted its parentless genesis, and then rejected every block after it — its own miner's
/// included — as `InvalidPoW`, with no fallback id accepted and no pruning proof importable.
/// Listing 6 here said the binary could verify something it cannot; 6 was therefore delisted
/// until the arm existed, and re-listed in the same commit that landed the arm and its carrier
/// (`palw_v2_commitment_mutation_invalidates_pow` is the test that holds the three together).
///
/// Adding an arm to the finalizer means adding its id here, and the mode gate
/// (`PalwConsensusParamsV2::validate`) reads this function to refuse a ruleset whose algorithm
/// this binary cannot compute — so the two can only be wrong together, loudly, at startup.
#[inline]
pub fn check_algo_id_known(algo_id: u8) -> Result<(), PowLayer0Error> {
    if algo_id == POW_ALGO_ID_KHEAVYHASH
        || algo_id == POW_ALGO_ID_ARGON2ID
        || algo_id == POW_ALGO_ID_BLAKE2B_SHA3
        || algo_id == POW_ALGO_ID_PALW_LLM
        || algo_id == POW_ALGO_ID_PALW_OLLAMA
        || algo_id == POW_ALGO_ID_PALW_COMMITTED_V2
        // ADR-0072 SA-4: 9 shares 6's finalizer arm, so this binary can derive its tag — which is
        // the only question this function asks. Whether a network ACCEPTS it is
        // `Params::palw_attempt_activation`'s, asked in `check_pow_algo_id`; conflating the two is
        // what the heartbeat's triple gate did.
        || algo_id == POW_ALGO_ID_PALW_EXEC_V3
        // ADR-0044 Unit B: 7 joins the set the moment its finalizer arm exists. "Known" here
        // means "this binary can derive its tag", and the pruning-proof path is the caller that
        // needs the distinction — a proof header whose tag we cannot derive must be refused, and
        // one whose tag we CAN derive must not be.
        || algo_id == POW_ALGO_ID_PALW_RECEIPT_V3
        // ADR-0066 Decision 1: the heartbeat lane. Known unconditionally — "this binary can derive
        // the tag" is a statement about the binary, not about whether any network accepts the id.
        // Whether a header carrying it is VALID is `Params::palw_heartbeat`'s question, asked in
        // `check_pow_algo_id`; conflating the two is what the triple gate did.
        || algo_id == POW_ALGO_ID_HEARTBEAT_V1
        // ADR-0125: the round lane shares the heartbeat's finalizer arm, so this binary derives its
        // tag. Whether a network ACCEPTS it is `Params::palw_execution_lane`'s question.
        || algo_id == POW_ALGO_ID_PALW_ROUND_V1
    {
        Ok(())
    } else {
        Err(PowLayer0Error::UnknownAlgoId(algo_id))
    }
}

/// kaspa-pq Layer 0 PoW finalizer.
///
/// Layout (ADR-0007 §"Decision", ADR-0008-updated to take a
/// 64-byte `pre_pow_hash`):
///
/// ```text
/// pow_512 = BLAKE2b-512(
///     key   = POW_FINALIZER_DOMAIN,
///     input = network_id_len_le_u16 || network_id ||
///             algo_id ||
///             pre_pow_hash64 ||                     // 64 bytes
///             timestamp.to_le_bytes() ||
///             bits.to_le_bytes() ||
///             nonce.to_le_bytes() ||
///             (l1_tag.len() as u16).to_le_bytes() || l1_tag,
/// )
/// ```
///
/// All variable-length inputs (`network_id`, `l1_tag`) carry a
/// 2-byte little-endian length prefix in front so the input is
/// self-delimiting: adding a new `algo_id` whose tag is a
/// different length cannot collide with a previous variant's
/// concatenation.
///
/// Returns the 64-byte digest. The caller compares against the
/// 512-bit target via `Uint512::from_le_bytes` /
/// `Uint512::from_compact_target_bits_512`.
pub fn pow_finalizer_blake2b_512(
    network_id: &[u8],
    algo_id: u8,
    pre_pow_hash: Hash64,
    timestamp: u64,
    bits: u32,
    nonce: u64,
    l1_tag: &[u8],
) -> Result<[u8; POW_FINALIZER_BYTES], PowLayer0Error> {
    if l1_tag.len() > POW_L1_TAG_MAX_BYTES {
        return Err(PowLayer0Error::L1TagTooLong(l1_tag.len()));
    }

    let mut state = Params::new().hash_length(POW_FINALIZER_BYTES).key(POW_FINALIZER_DOMAIN).to_state();

    // 2-byte length-prefix for the variable-width network_id so the
    // domain separation is unambiguous across simnet / devnet /
    // testnet / mainnet, which all carry distinct network_id bytes
    // (see ADR-0001).
    state.update(&(network_id.len() as u16).to_le_bytes());
    state.update(network_id);

    state.update(&[algo_id]);
    // ADR-0008: pre_pow_hash is now 64 bytes (BlockPrePowHash64).
    state.update(&pre_pow_hash.as_bytes());
    state.update(&timestamp.to_le_bytes());
    state.update(&bits.to_le_bytes());
    state.update(&nonce.to_le_bytes());

    state.update(&(l1_tag.len() as u16).to_le_bytes());
    state.update(l1_tag);

    let digest = state.finalize();
    let mut out = [0u8; POW_FINALIZER_BYTES];
    out.copy_from_slice(digest.as_bytes());
    Ok(out)
}

/// Derive the 32-byte kHeavyHash v1 seed from the 64-byte
/// pre-PoW hash. kaspa-pq Phase 9 (PR-9.3); see ADR-0008
/// §"algo_id = 1 (kHeavyHash) seed derivation".
///
/// ```text
/// l1_seed32 = BLAKE2b-256(
///     key   = POW_L1_KHEAVYHASH_V1_SEED_DOMAIN,
///     input = pre_pow_hash64,
/// )
/// ```
///
/// This bridges the 64-byte Layer 0 pre-PoW hash to the upstream
/// 32-byte kHeavyHash interface for the Phase 1 `algo_id = 1`
/// path. The seed is domain-separated on its own keyed BLAKE2b
/// instance so the 32-byte seed and the 64-byte pre-PoW hash
/// cannot be substituted for each other anywhere else.
#[inline]
pub fn l1_seed32_for_kheavyhash_v1(pre_pow_hash: Hash64) -> Hash {
    let digest =
        Params::new().hash_length(32).key(POW_L1_KHEAVYHASH_V1_SEED_DOMAIN).to_state().update(pre_pow_hash.as_byte_slice()).finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(digest.as_bytes());
    Hash::from_bytes(out)
}

/// kaspa-pq Phase 2 (`algo_id = 2`): the memory-hard Argon2id Layer-1 tag.
///
/// ```text
/// password = BLAKE2b-256(key = POW_L1_ARGON2ID_V1_DOMAIN, pre_pow_hash64 || nonce_le)
/// salt     = BLAKE2b-128(key = POW_L1_ARGON2ID_V1_DOMAIN, "salt" || netid_len_le || network_id)
/// l1_tag   = Argon2id(password, salt; m=16MiB, t=1, p=1, out=32)
/// ```
///
/// Deterministic (fixed params + fixed per-network salt), binds to the block via `pre_pow_hash`
/// and to the search via `nonce`, and is domain/network-separated. The 32-byte tag is then fed to
/// the unchanged Layer-0 `pow_finalizer_blake2b_512` with `algo_id = 2`.
pub fn argon2id_l1_tag_v1(pre_pow_hash: Hash64, nonce: u64, network_id: &[u8]) -> [u8; POW_L1_ARGON2ID_OUT_BYTES] {
    // password: per-(block, nonce) — this is what miners vary across nonce trials.
    let password = {
        let digest = Params::new()
            .hash_length(32)
            .key(POW_L1_ARGON2ID_V1_DOMAIN)
            .to_state()
            .update(pre_pow_hash.as_byte_slice())
            .update(&nonce.to_le_bytes())
            .finalize();
        let mut o = [0u8; 32];
        o.copy_from_slice(digest.as_bytes());
        o
    };
    // salt: fixed per network (deterministic). Length-prefixed network id for unambiguous separation.
    let salt = {
        let digest = Params::new()
            .hash_length(16)
            .key(POW_L1_ARGON2ID_V1_DOMAIN)
            .to_state()
            .update(b"salt")
            .update(&(network_id.len() as u16).to_le_bytes())
            .update(network_id)
            .finalize();
        let mut o = [0u8; 16];
        o.copy_from_slice(digest.as_bytes());
        o
    };
    let params = argon2::Params::new(
        POW_L1_ARGON2ID_M_COST_KIB,
        POW_L1_ARGON2ID_T_COST,
        POW_L1_ARGON2ID_P_COST,
        Some(POW_L1_ARGON2ID_OUT_BYTES),
    )
    .expect("static Argon2id params are valid");
    let a2 = argon2::Argon2::new(argon2::Algorithm::Argon2id, argon2::Version::V0x13, params);
    let mut out = [0u8; POW_L1_ARGON2ID_OUT_BYTES];
    a2.hash_password_into(&password, &salt, &mut out).expect("Argon2id hash into fixed-size buffer");
    out
}

/// kaspa-pq Phase 3 (`algo_id = 3`): the compute-only BLAKE2b-512 ∥ SHA3-512 Layer-1 tag.
///
/// ```text
/// half_b = BLAKE2b-512(key = DOMAIN, netid_len_le16 || network_id || pre_pow_hash64 || nonce_le)
/// half_s = SHA3-512(DOMAIN || netid_len_le16 || network_id || pre_pow_hash64 || nonce_le)
/// l1_tag = half_b || half_s                                          // 64 + 64 = 128 bytes
/// ```
///
/// Both halves bind the block (`pre_pow_hash`), the search (`nonce`), and the network (length-prefixed
/// `network_id`), and are domain-separated on `DOMAIN` — the BLAKE2b half uses it as the key, the
/// (un-keyed) SHA3 half prepends it. The 128-byte tag is fed to the unchanged Layer-0
/// `pow_finalizer_blake2b_512` with `algo_id = 3`, which mixes a *second* BLAKE2b-512 over the whole
/// preimage (including `half_s`) — so a miner cannot skip the SHA3 half: the accepted digest depends
/// on every tag byte. Per-nonce work is therefore 2×BLAKE2b-512 + 1×SHA3-512, all compute-only.
pub fn blake2b_sha3_l1_tag_v1(pre_pow_hash: Hash64, nonce: u64, network_id: &[u8]) -> [u8; POW_L1_BLAKE2B_SHA3_OUT_BYTES] {
    // BLAKE2b-512 half (keyed on DOMAIN). Length-prefixed network id => self-delimiting preimage.
    let half_b = Params::new()
        .hash_length(64)
        .key(POW_L1_BLAKE2B_SHA3_V1_DOMAIN)
        .to_state()
        .update(&(network_id.len() as u16).to_le_bytes())
        .update(network_id)
        .update(pre_pow_hash.as_byte_slice())
        .update(&nonce.to_le_bytes())
        .finalize();

    // SHA3-512 half. `sha3` has no keying, so DOMAIN is prepended explicitly; the same
    // length-prefixed (network_id, pre_pow_hash, nonce) follow.
    let mut s = Sha3_512::new();
    s.update(POW_L1_BLAKE2B_SHA3_V1_DOMAIN);
    s.update((network_id.len() as u16).to_le_bytes());
    s.update(network_id);
    s.update(pre_pow_hash.as_byte_slice());
    s.update(nonce.to_le_bytes());
    let half_s = s.finalize();

    let mut out = [0u8; POW_L1_BLAKE2B_SHA3_OUT_BYTES];
    out[..64].copy_from_slice(half_b.as_bytes());
    out[64..].copy_from_slice(&half_s);
    out
}

/// Difficulty-lift helper. Maps a 256-bit upstream-style target to
/// a 512-bit kaspa-pq target while preserving block-finding
/// probability under the ideal uniform-hash model:
///
/// ```text
/// Pr[X_512 ≤ target_256 << 256]
///   = (target_256 << 256) / 2^512
///   = target_256 / 2^256
///   = Pr[X_256 ≤ target_256]
/// ```
///
/// Use cases:
///
///  - Translating historical 256-bit compact-bits values into the
///    kaspa-pq comparison domain at fork activation.
///  - Sanity-checking the `from_compact_target_bits_512` decoder:
///    by construction
///    `from_compact_target_bits_512(bits) == lift_target_256_to_512(
///        Uint256::from_compact_target_bits(bits))`.
#[inline]
pub fn lift_target_256_to_512(target_256: Uint256) -> Uint512 {
    Uint512::from(target_256) << 256
}

/// `floor(2^512 / (target + 1))` returned as a [`Uint576`]. Thin
/// re-export of `Uint512::calc_work_512` so consumers can pull the
/// kaspa-pq work-computation surface from `pow_layer0` without
/// also pulling `kaspa_math` directly.
///
/// NOTE (audit L): GHOSTDAG blue-work is **intentionally** still computed by the
/// legacy `difficulty::calc_work(bits)` (32-bit-compact target), NOT this 512-bit
/// form — the kaspa-pq difficulty lift keeps the historical work unit so blue-work
/// accounting is unchanged. This helper exists for the Layer-0 512-bit PoW surface
/// and block-level derivation. Switching only *part* of the work accounting to
/// `calc_work_512` would change blue-work and split the DAG, so the two MUST NOT be
/// mixed within a single accounting domain.
#[inline]
pub fn calc_work_512(target: Uint512) -> Uint576 {
    target.calc_work_512()
}

#[cfg(test)]
mod tests {

    /// **The attempt lane's frozen bits ARE the ambient V2 target, not a number beside it.**
    ///
    /// `PALW_V2_ATTEMPT_BITS` is what `pow/src/lib.rs` substitutes and what `validate_palw_v2`
    /// makes the fence declare, so a typo here would be a target no V2 genesis carries and every
    /// V2 header would fail its own PoW. Compared against the constant every preset's
    /// `max_difficulty_target` is set from, so the two cannot drift.
    #[test]
    fn the_attempt_lanes_frozen_bits_are_the_ambient_v2_target() {
        use crate::config::constants::consensus::MAX_DIFFICULTY_TARGET;
        assert_eq!(PALW_V2_ATTEMPT_BITS, MAX_DIFFICULTY_TARGET.compact_target_bits());
        // …and it is the value the shipped V2 genesis blocks already carry, so arming the lock
        // does not invalidate a genesis header.
        assert_eq!(crate::config::genesis::PALW_RC_GENESIS.bits, PALW_V2_ATTEMPT_BITS);
        assert_eq!(crate::config::genesis::DEVNET_GENESIS.bits, PALW_V2_ATTEMPT_BITS);
    }

    /// **One rule, two spellings — and only one of them is on the live path.**
    ///
    /// `Params::palw_receipt_rows_unpriced`'s doc names [`algo_id_is_priced_by_bits_v2`] as the rule
    /// in force past that fence. Nothing calls it: `difficulty::get_difficulty_blocks_with_lane`
    /// sets `priced: algo_id_is_priced_by_bits(..)` and a separate `receipt:` flag, and
    /// `retarget_bits` recomposes the two. The composition equals `_v2` today; nothing says so, and
    /// a change to either side is invisible until a chain retargets differently from what its own
    /// fence doc claims. This holds the two equal over the whole id space.
    ///
    /// A DRIFT PIN, not a rule test: it passes on today's code and exists so that it stops passing
    /// the moment the two spellings part company (mainnet audit, 2026-09-06 — the merge-drift item
    /// beside C-1).
    #[test]
    fn the_two_spellings_of_the_priced_row_predicate_agree() {
        for algo_id in 0u8..=u8::MAX {
            assert_eq!(
                algo_id_is_priced_by_bits_v2(algo_id),
                algo_id_is_priced_by_bits(algo_id) && algo_id != POW_ALGO_ID_PALW_RECEIPT_V3,
                "algo {algo_id}: the named predicate and the composition the retarget runs must be one rule"
            );
        }
        // …and the composition is not trivially true: at least one id differs between them.
        assert!(algo_id_is_priced_by_bits(POW_ALGO_ID_PALW_RECEIPT_V3));
        assert!(!algo_id_is_priced_by_bits_v2(POW_ALGO_ID_PALW_RECEIPT_V3));
        // …and the lane C-1 is about is priced under both, which is the design (ADR-0072 D3).
        assert!(algo_id_is_priced_by_bits(POW_ALGO_ID_PALW_COMMITTED_V2));
        assert!(algo_id_is_priced_by_bits_v2(POW_ALGO_ID_PALW_COMMITTED_V2));
    }

    use super::*;
    use kaspa_hashes::ZERO_HASH64;

    /// A well-formed attempt envelope at a chosen version. Shape only — the fenced gates under
    /// test read the version and the algo id and nothing else about it.
    fn attempt_envelope_at_version(version: u16) -> Vec<u8> {
        use crate::mldsa87_primitives::{MLDSA87_PUBKEY_LEN, MLDSA87_SIGNATURE_LEN};
        let h = |w: u64| kaspa_hashes::Hash64::from_u64_word(w);
        let attempt = crate::palw_attempt_v2::PalwAttemptUnsignedV2 {
            version,
            network_domain: h(0x7E57_00D0),
            challenge: h(0xC0FFEE),
            class_id: h(0xC1A55),
            executor_bond: crate::tx::TransactionOutpoint::new(kaspa_hashes::Hash64::from_bytes([3u8; 64]), 1),
            executor_pubkey: vec![7u8; MLDSA87_PUBKEY_LEN],
            operator_id: h(0x0E0),
            artifact_root: h(0xA7),
            trace_root: h(0x7A),
            output_root: h(0x07),
            pwu: 4_242,
            trace_manifest_root: h(0xD0),
            trace_chunk_count: 1,
            trace_retention_daa: 1_000_000,
            execution_root: h(0x41),
        };
        crate::palw_attempt_v2::PalwAttemptEnvelopeV2 { attempt, signature: vec![0x5A; MLDSA87_SIGNATURE_LEN] }.encode_wire()
    }

    /// **ADR-0072 SA-3 — the version check is fenced, and one binary holds both arms.**
    ///
    /// §3's Decision 7 analysis names the defect this closes: "a node on this build refuses every
    /// version-5 envelope, which is every attempt block the chain already holds — a fresh node
    /// cannot validate the history it is asked to sync. Every earlier attempt-format change shipped
    /// with a re-genesis for exactly this reason." Mainnet may not re-genesis (2026-08-27), so the
    /// version has to travel with the position instead of being compiled in.
    ///
    /// The `Unfenced` row is the one that says nothing shipped moved: it is every preset today, and
    /// it accepts exactly what the un-parameterised entry point always accepted.
    #[test]
    fn the_admissible_attempt_version_is_a_function_of_the_position_not_of_the_binary() {
        let current = crate::palw_attempt_v2::PALW_ATTEMPT_V2_VERSION;
        let legacy = crate::palw_attempt_v2::PALW_ATTEMPT_V2_VERSION_PRE_ADR_0072;
        assert_ne!(current, legacy, "a fence between two identical versions would fence nothing");

        // (lane, the id that IS the lane there, the version that lane admits)
        let rows = [
            (PalwAttemptLaneV1::Unfenced, POW_ALGO_ID_PALW_COMMITTED_V2, current),
            (PalwAttemptLaneV1::LegacyArm, POW_ALGO_ID_PALW_COMMITTED_V2, legacy),
            (PalwAttemptLaneV1::ExecutionArm, POW_ALGO_ID_PALW_EXEC_V3, current),
        ];
        for (lane, algo, admitted) in rows {
            assert_eq!(lane.attempt_algo_id(), algo, "{lane:?}");
            assert_eq!(lane.attempt_version(), admitted, "{lane:?}");
            assert!(
                check_palw_commitment_shape_at(algo, &attempt_envelope_at_version(admitted), false, lane).is_ok(),
                "{lane:?}: the version this position admits must validate"
            );
            let other = if admitted == current { legacy } else { current };
            assert!(
                check_palw_commitment_shape_at(algo, &attempt_envelope_at_version(other), false, lane).is_err(),
                "{lane:?}: the version this position does NOT admit must not"
            );
        }

        // The un-parameterised entry point is the `Unfenced` row, so no shipped call site moved.
        for version in [current, legacy] {
            let bytes = attempt_envelope_at_version(version);
            assert_eq!(
                check_palw_commitment_shape(POW_ALGO_ID_PALW_COMMITTED_V2, &bytes, false).is_ok(),
                check_palw_commitment_shape_at(POW_ALGO_ID_PALW_COMMITTED_V2, &bytes, false, PalwAttemptLaneV1::Unfenced).is_ok(),
                "version {version}: the old entry point must be the un-fenced lane exactly"
            );
        }
    }

    /// **ADR-0072 SA-4, at the shape gate — the wrong side of the fence is refused BY ALGO ID,
    /// before the version is read.**
    ///
    /// The finalizer refuses a cross-lane replay too (`pow_algo_id` is in the Layer-0 digest and in
    /// `pre_pow_hash_64` — see `a_valid_old_lane_attempt_is_not_a_candidate_in_the_new_lane` in
    /// `kaspa-pow`). This is the earlier, NAMED refusal, and the assertion that matters is the
    /// second one: the envelope carries the version the closed lane WOULD have admitted, so the
    /// error can only be about the id.
    #[test]
    fn an_attempt_on_the_closed_lane_is_refused_by_id_not_by_version() {
        let current = crate::palw_attempt_v2::PALW_ATTEMPT_V2_VERSION;
        let legacy = crate::palw_attempt_v2::PALW_ATTEMPT_V2_VERSION_PRE_ADR_0072;

        // Past the fence: the old id is closed. The envelope is legacy-versioned — exactly what the
        // pre-fence chain holds and what the old lane admits — so nothing about it is malformed;
        // its POSITION is what is wrong.
        assert_eq!(
            check_palw_commitment_shape_at(
                POW_ALGO_ID_PALW_COMMITTED_V2,
                &attempt_envelope_at_version(legacy),
                false,
                PalwAttemptLaneV1::ExecutionArm
            ),
            Err(PowLayer0Error::PalwAttemptLaneClosed { algo_id: POW_ALGO_ID_PALW_COMMITTED_V2, open: POW_ALGO_ID_PALW_EXEC_V3 }),
            "an old-lane block replayed past the fence must be refused for its id, not for its contents"
        );
        // And with the CURRENT version, which the open lane would accept: still the id.
        assert_eq!(
            check_palw_commitment_shape_at(
                POW_ALGO_ID_PALW_COMMITTED_V2,
                &attempt_envelope_at_version(current),
                false,
                PalwAttemptLaneV1::ExecutionArm
            ),
            Err(PowLayer0Error::PalwAttemptLaneClosed { algo_id: POW_ALGO_ID_PALW_COMMITTED_V2, open: POW_ALGO_ID_PALW_EXEC_V3 }),
            "the version is not what refuses it — edit the version and the refusal is unchanged"
        );

        // Symmetrically: the new id is not a lane before the fence, nor on an un-fenced network.
        for lane in [PalwAttemptLaneV1::Unfenced, PalwAttemptLaneV1::LegacyArm] {
            assert_eq!(
                check_palw_commitment_shape_at(POW_ALGO_ID_PALW_EXEC_V3, &attempt_envelope_at_version(current), false, lane),
                Err(PowLayer0Error::PalwAttemptLaneClosed { algo_id: POW_ALGO_ID_PALW_EXEC_V3, open: POW_ALGO_ID_PALW_COMMITTED_V2 }),
                "{lane:?}: the post-fence id must not be admissible before the fence"
            );
        }

        // The other lanes are nobody else's business: this predicate speaks only for the two
        // attempt ids, so a receipt or heartbeat header is untouched by the fence.
        for other in [POW_ALGO_ID_PALW_RECEIPT_V3, POW_ALGO_ID_HEARTBEAT_V1, POW_ALGO_ID_KHEAVYHASH] {
            for lane in [PalwAttemptLaneV1::Unfenced, PalwAttemptLaneV1::LegacyArm, PalwAttemptLaneV1::ExecutionArm] {
                assert!(lane.admits_attempt_algo_id(other), "{lane:?}: the fence must not speak for algo {other}");
            }
        }
    }

    /// The fence resolves to exactly one lane, and `None` — every shipped preset — is the one that
    /// leaves today's behaviour alone.
    #[test]
    fn the_lane_resolver_is_total_and_none_is_todays_behaviour() {
        assert_eq!(PalwAttemptLaneV1::from_fence(None), PalwAttemptLaneV1::Unfenced);
        assert_eq!(PalwAttemptLaneV1::from_fence(Some(false)), PalwAttemptLaneV1::LegacyArm);
        assert_eq!(PalwAttemptLaneV1::from_fence(Some(true)), PalwAttemptLaneV1::ExecutionArm);

        // And through `Params`, where the fence actually lives.
        let mut params = crate::config::params::MAINNET_PARAMS;
        assert_eq!(params.palw_attempt_lane_at(0), PalwAttemptLaneV1::Unfenced);
        assert_eq!(params.palw_attempt_lane_at(u64::MAX), PalwAttemptLaneV1::Unfenced);
        params.palw_attempt_activation = Some(crate::config::params::ForkActivation::new(1_000));
        assert_eq!(params.palw_attempt_lane_at(999), PalwAttemptLaneV1::LegacyArm);
        assert_eq!(params.palw_attempt_lane_at(1_000), PalwAttemptLaneV1::ExecutionArm, "`is_active` is inclusive at the fence");
    }

    /// The new id joins the families it must, and none it must not.
    #[test]
    fn the_new_attempt_id_is_in_the_v2_lineage_and_is_position_bearing() {
        assert!(is_palw_attempt_algo_id(POW_ALGO_ID_PALW_EXEC_V3));
        assert!(is_palw_attempt_algo_id(POW_ALGO_ID_PALW_COMMITTED_V2));
        assert!(!is_palw_attempt_algo_id(POW_ALGO_ID_PALW_RECEIPT_V3));
        // In the V2 lineage, so `palw_state_root` and `palw_commitment` are hash-VISIBLE on it —
        // without this, a stuffed state root on an algo-9 header would be block-hash malleability.
        assert!(is_palw_v2_algo_id(POW_ALGO_ID_PALW_EXEC_V3));
        assert!(is_palw_algo_id(POW_ALGO_ID_PALW_EXEC_V3));
        // It buys chain position exactly as algo-6 does: it is the same lane, priced the same way.
        assert!(!algo_id_carries_no_chain_position(POW_ALGO_ID_PALW_EXEC_V3));
        assert!(!algo_id_derives_no_block_level(POW_ALGO_ID_PALW_EXEC_V3));
        // Known to this binary (it shares algo-6's finalizer arm), which is what lets a pruning
        // proof carry it — the audit-C1 rule that an id may not be accepted before its arm exists.
        assert!(check_algo_id_known(POW_ALGO_ID_PALW_EXEC_V3).is_ok());
    }

    fn h(byte: u8) -> Hash64 {
        Hash64::from_bytes([byte; 64])
    }

    #[test]
    fn algo_id_phase1_only_admits_kheavyhash() {
        assert!(check_algo_id_phase1(POW_ALGO_ID_KHEAVYHASH).is_ok());
        for bad in [0u8, 2, 3, 7, 0xff] {
            assert_eq!(check_algo_id_phase1(bad), Err(PowLayer0Error::UnknownAlgoId(bad)));
        }
    }

    #[test]
    fn check_algo_id_enforces_exact_network_algo() {
        // BLAKE2b-SHA3-active network: must be 3; kHeavyHash (1) and the superseded Argon2id (2) are
        // both WRONG (not just unknown) on the active path.
        assert!(check_algo_id(POW_ALGO_ID_BLAKE2B_SHA3, false, false, true).is_ok());
        assert_eq!(check_algo_id(POW_ALGO_ID_KHEAVYHASH, false, false, true), Err(PowLayer0Error::UnknownAlgoId(1)));
        assert_eq!(check_algo_id(POW_ALGO_ID_ARGON2ID, false, false, true), Err(PowLayer0Error::UnknownAlgoId(2)));
        // kHeavyHash network: must be 1, 3 is rejected.
        assert!(check_algo_id(POW_ALGO_ID_KHEAVYHASH, false, false, false).is_ok());
        assert_eq!(check_algo_id(POW_ALGO_ID_BLAKE2B_SHA3, false, false, false), Err(PowLayer0Error::UnknownAlgoId(3)));
        // PALW-worker-active network: must be 4, and PALW takes precedence over BLAKE2b-SHA3.
        assert!(check_algo_id(POW_ALGO_ID_PALW_LLM, false, true, false).is_ok());
        assert!(check_algo_id(POW_ALGO_ID_PALW_LLM, false, true, true).is_ok());
        assert_eq!(check_algo_id(POW_ALGO_ID_BLAKE2B_SHA3, false, true, true), Err(PowLayer0Error::UnknownAlgoId(3)));
        assert_eq!(check_algo_id(POW_ALGO_ID_PALW_LLM, false, false, false), Err(PowLayer0Error::UnknownAlgoId(4)));
        // PALW-Ollama-active network: must be 5, superseding every other algo.
        assert!(check_algo_id(POW_ALGO_ID_PALW_OLLAMA, true, false, false).is_ok());
        assert!(check_algo_id(POW_ALGO_ID_PALW_OLLAMA, true, true, true).is_ok());
        assert_eq!(check_algo_id(POW_ALGO_ID_PALW_LLM, true, true, true), Err(PowLayer0Error::UnknownAlgoId(4)));
        assert_eq!(check_algo_id(POW_ALGO_ID_PALW_OLLAMA, false, true, false), Err(PowLayer0Error::UnknownAlgoId(5)));
        assert_eq!(required_algo_id(false, false, true), 3);
        assert_eq!(required_algo_id(false, false, false), 1);
        assert_eq!(required_algo_id(false, true, false), 4);
        assert_eq!(required_algo_id(false, true, true), 4);
        assert_eq!(required_algo_id(true, false, false), 5);
        assert_eq!(required_algo_id(true, true, true), 5);
    }

    /// `check_algo_id_known` (pruning-proof path) accepts every algo this binary can FINALIZE —
    /// kHeavyHash (1), the superseded Argon2id (2), BLAKE2b-SHA3 (3), PALW LLM (4), PALW-Ollama
    /// (5), the committed-V2 id (6), the receipt id (7) and the heartbeat id (8) — and rejects the
    /// rest.
    #[test]
    fn check_algo_id_known_accepts_all_verifiable_algos() {
        for ok in [
            POW_ALGO_ID_KHEAVYHASH,
            POW_ALGO_ID_ARGON2ID,
            POW_ALGO_ID_BLAKE2B_SHA3,
            POW_ALGO_ID_PALW_LLM,
            POW_ALGO_ID_PALW_OLLAMA,
            POW_ALGO_ID_PALW_COMMITTED_V2,
            // 7 joined when its finalizer arm landed (ADR-0044 Unit B): this set means "this
            // binary can derive the tag", and it now can.
            POW_ALGO_ID_PALW_RECEIPT_V3,
            // 8 joined with ADR-0066 Decision 1's heartbeat lane. Its tag arm is algo-3's, shared
            // rather than copied, so "this binary can derive the tag" was true the moment the id
            // existed — and it is listed in the same commit that added the arm, which is the rule
            // the algo-6 delisting below established. Note that KNOWN is not ACCEPTED: whether a
            // network admits an algo-8 header is `Params::palw_heartbeat`'s question, one level up.
            POW_ALGO_ID_HEARTBEAT_V1,
            // 9 joined with ADR-0072 SA-4's execution-priced attempt lane, under the same rule and
            // in the same commit as its arm: it SHARES algo-6's arm (the two lanes run one rule;
            // what separates them is that `pow_algo_id` is inside the Layer-0 digest), so "this
            // binary can derive the tag" was true the moment the id existed. KNOWN is not
            // ACCEPTED — whether a network admits an algo-9 header is
            // `Params::palw_attempt_activation`'s question, one level up, and every shipped preset
            // answers no.
            POW_ALGO_ID_PALW_EXEC_V3,
            // 10 joined with ADR-0125's round lane, in the commit that shares the heartbeat's arm.
            POW_ALGO_ID_PALW_ROUND_V1,
        ] {
            assert!(check_algo_id_known(ok).is_ok(), "algo_id {ok} must be known");
        }
        // 9 and 10 left this list when they were assigned; 11 and 12 stand in for the next unassigned ids.
        for bad in [0u8, 11, 12, 0xff] {
            assert_eq!(check_algo_id_known(bad), Err(PowLayer0Error::UnknownAlgoId(bad)));
        }

        // **Audit C1, closed.** This assertion was `Err(UnknownAlgoId(6))` while the finalizer
        // had no arm for the V2 id — the mode gate reads this function to decide whether a
        // `ConsensusV2` ruleset is runnable, and claiming 6 verifiable without an arm is what let
        // a V2 network boot and then stall at block 1. The arm landed together with its carrier
        // (`StateLayer0::calculate_l1_tag`'s algo-6 arm over the header-carried
        // `PalwAttemptEnvelopeV2`), so the id is listed again, and this flip happened in that
        // same commit — exactly as the delisting comment said it must.
        assert!(
            check_algo_id_known(POW_ALGO_ID_PALW_COMMITTED_V2).is_ok(),
            "the V2 arm exists; delisting 6 now would shut a bootable ruleset"
        );

        // Knowing the V2 id is not accepting a V2 block. `required_algo_id` has no V2 arm until the
        // atomic bundle lands (ADR-0042 Decision 1), so no combination of today's fork flags demands
        // it — which is what keeps the id inert on every shipped network while its semantics exist.
        for (ollama, llm, sha3) in
            [(false, false, false), (false, false, true), (false, true, false), (false, true, true), (true, true, true)]
        {
            assert_ne!(
                required_algo_id(ollama, llm, sha3),
                POW_ALGO_ID_PALW_COMMITTED_V2,
                "no fork-flag combination may demand V2 before the bundle exists"
            );
            assert_eq!(
                check_algo_id(POW_ALGO_ID_PALW_COMMITTED_V2, ollama, llm, sha3),
                Err(PowLayer0Error::UnknownAlgoId(POW_ALGO_ID_PALW_COMMITTED_V2)),
                "a V2 header must be refused everywhere today"
            );
            // The mode seam (PR-08): with no V2 mode (`None` — every real network), the
            // mode-aware gate is the V1 gate exactly, so a V2 header is still refused…
            assert_eq!(
                check_algo_id_for_mode(POW_ALGO_ID_PALW_COMMITTED_V2, None, ollama, llm, sha3),
                Err(PowLayer0Error::UnknownAlgoId(POW_ALGO_ID_PALW_COMMITTED_V2)),
                "with no V2 mode the V2 id is refused, exactly as the V1 gate refuses it"
            );
            assert_eq!(
                required_algo_id_for_mode(None, ollama, llm, sha3),
                required_algo_id(ollama, llm, sha3),
                "no mode = the V1 cascade, byte for byte"
            );
            // …and ONLY a ConsensusV2 mode (`Some(6)`) demands and accepts it — exclusively, the
            // V1 flags no longer consulted for that network.
            assert_eq!(
                required_algo_id_for_mode(Some(POW_ALGO_ID_PALW_COMMITTED_V2), ollama, llm, sha3),
                POW_ALGO_ID_PALW_COMMITTED_V2
            );
            assert!(
                check_algo_id_for_mode(POW_ALGO_ID_PALW_COMMITTED_V2, Some(POW_ALGO_ID_PALW_COMMITTED_V2), ollama, llm, sha3).is_ok()
            );
            // A V2 network refuses the V1 ids it would otherwise have required — nothing but V2.
            assert_eq!(
                check_algo_id_for_mode(required_algo_id(ollama, llm, sha3), Some(POW_ALGO_ID_PALW_COMMITTED_V2), ollama, llm, sha3),
                Err(PowLayer0Error::UnknownAlgoId(required_algo_id(ollama, llm, sha3))),
                "a V2 network accepts the committed-V2 id and nothing else"
            );
        }
    }

    /// ADR-0044 (FP-02): the receipt-spend id (7) exists, belongs to the PALW header family, and
    /// is demanded or accepted by NOTHING — no fork-flag combination, no mode that exists today
    /// (a `ConsensusV2` network still demands 6 exclusively), and not the pruning-proof gate,
    /// whose contract is "algos this binary can verify" and whose over-acceptance is the
    /// unknown-algo remote-crash shape.
    #[test]
    fn the_receipt_v3_id_is_known_to_the_family_and_demanded_by_nothing() {
        assert!(is_palw_algo_id(POW_ALGO_ID_PALW_RECEIPT_V3), "a receipt header carries (and hashes) its spend carriage");
        // **Position, both kinds, refused together.** The level half and the work half used to be
        // two independent decisions and only one of them said no; a receipt block took level 0 and
        // still handed its descendants `calc_work(bits)` of blue work, which is fork-choice weight
        // bought with a signature. They read this one predicate now, so neither can drift.
        assert!(
            algo_id_carries_no_chain_position(POW_ALGO_ID_PALW_RECEIPT_V3),
            "a receipt header buys neither pruning-proof level nor blue work"
        );
        assert!(
            !algo_id_carries_no_chain_position(POW_ALGO_ID_PALW_COMMITTED_V2),
            "the attempt lane is where chain position comes from — its digests are inference-priced"
        );
        assert!(!algo_id_carries_no_chain_position(POW_ALGO_ID_KHEAVYHASH), "and a hash network is untouched by any of this");
        assert!(
            check_algo_id_known(POW_ALGO_ID_PALW_RECEIPT_V3).is_ok(),
            "since Unit B the pruning-proof gate can derive this tag, so it must not refuse the id"
        );
        for (ollama, llm, sha3) in
            [(false, false, false), (false, false, true), (false, true, false), (false, true, true), (true, true, true)]
        {
            assert_ne!(required_algo_id(ollama, llm, sha3), POW_ALGO_ID_PALW_RECEIPT_V3);
            assert_eq!(
                check_algo_id(POW_ALGO_ID_PALW_RECEIPT_V3, ollama, llm, sha3),
                Err(PowLayer0Error::UnknownAlgoId(POW_ALGO_ID_PALW_RECEIPT_V3))
            );
            for mode_required in [None, Some(POW_ALGO_ID_PALW_COMMITTED_V2)] {
                assert_ne!(required_algo_id_for_mode(mode_required, ollama, llm, sha3), POW_ALGO_ID_PALW_RECEIPT_V3);
                assert_eq!(
                    check_algo_id_for_mode(POW_ALGO_ID_PALW_RECEIPT_V3, mode_required, ollama, llm, sha3),
                    Err(PowLayer0Error::UnknownAlgoId(POW_ALGO_ID_PALW_RECEIPT_V3)),
                    "no mode that exists today accepts a receipt block — the two-id set arrives only with the FP bundle's wiring"
                );
            }
        }

        // The header-shape gate, since Unit B: a receipt header MUST carry a well-formed spend
        // envelope — empty is refused, junk is refused, and the V1 fence flag is not consulted
        // at all (the lane's id already means the network demanded it).
        for bound in [false, true] {
            assert!(
                matches!(
                    check_palw_commitment_shape(POW_ALGO_ID_PALW_RECEIPT_V3, &[], bound),
                    Err(PowLayer0Error::PalwCommitmentMalformed { .. })
                ),
                "bound = {bound}: an empty carriage is not a spend"
            );
            assert!(matches!(
                check_palw_commitment_shape(POW_ALGO_ID_PALW_RECEIPT_V3, &[1, 2, 3], bound),
                Err(PowLayer0Error::PalwCommitmentMalformed { .. })
            ));
            // …and the attempt lane's rule is the mirror image: its own envelope or nothing.
            assert!(matches!(
                check_palw_commitment_shape(POW_ALGO_ID_PALW_COMMITTED_V2, &[], bound),
                Err(PowLayer0Error::PalwCommitmentMalformed { .. })
            ));
        }
        let oversized = vec![0u8; PALW_COMMITMENT_MAX_BYTES + 1];
        assert_eq!(
            check_palw_commitment_shape(POW_ALGO_ID_PALW_RECEIPT_V3, &oversized, false),
            Err(PowLayer0Error::PalwCommitmentTooLong { got: oversized.len(), cap: PALW_COMMITMENT_MAX_BYTES }),
            "the cap still reports the cap it broke, before any codec runs"
        );
    }

    /// BLAKE2b-SHA3 Layer-1 (algo_id = 3) must be DETERMINISTIC (miner and every verifier agree on
    /// the tag for a given header+nonce), 128 bytes wide, and sensitive to block, nonce and network.
    /// It must also differ from the kHeavyHash-seed and Argon2id derivations on the same inputs.
    #[test]
    fn blake2b_sha3_l1_tag_deterministic_and_sensitive() {
        let net = b"testnet-10";
        let a = blake2b_sha3_l1_tag_v1(h(0x11), 42, net);
        let b = blake2b_sha3_l1_tag_v1(h(0x11), 42, net);
        assert_eq!(a, b, "BLAKE2b-SHA3 L1 must be deterministic");
        assert_eq!(a.len(), POW_L1_BLAKE2B_SHA3_OUT_BYTES);
        assert_eq!(a.len(), 128);
        assert!(a.len() <= POW_L1_TAG_MAX_BYTES, "tag must fit the finalizer's max");
        assert_ne!(a, [0u8; POW_L1_BLAKE2B_SHA3_OUT_BYTES]);
        // The two halves are distinct hash families over the same preimage — they must not coincide.
        assert_ne!(&a[..64], &a[64..], "BLAKE2b half must differ from SHA3 half");
        assert_ne!(a, blake2b_sha3_l1_tag_v1(h(0x12), 42, net), "pre_pow_hash must change the tag");
        assert_ne!(a, blake2b_sha3_l1_tag_v1(h(0x11), 43, net), "nonce must change the tag");
        assert_ne!(a, blake2b_sha3_l1_tag_v1(h(0x11), 42, b"mainnet"), "network must change the tag");
        // Distinct from the other algos' derivations on the same input (different algo).
        assert_ne!(&a[..32], argon2id_l1_tag_v1(h(0x11), 42, net).as_slice());
        assert_ne!(&a[..32], l1_seed32_for_kheavyhash_v1(h(0x11)).as_bytes().as_slice());
    }

    /// Argon2id Layer-1 (algo_id = 2) must be DETERMINISTIC (miner and every verifier must agree on
    /// the tag for a given header+nonce) and sensitive to block, nonce and network.
    #[test]
    fn argon2id_l1_tag_deterministic_and_sensitive() {
        let net = b"testnet-10";
        let a = argon2id_l1_tag_v1(h(0x11), 42, net);
        let b = argon2id_l1_tag_v1(h(0x11), 42, net);
        assert_eq!(a, b, "Argon2id L1 must be deterministic");
        assert_eq!(a.len(), POW_L1_ARGON2ID_OUT_BYTES);
        assert_ne!(a, [0u8; 32]);
        assert_ne!(a, argon2id_l1_tag_v1(h(0x12), 42, net), "pre_pow_hash must change the tag");
        assert_ne!(a, argon2id_l1_tag_v1(h(0x11), 43, net), "nonce must change the tag");
        assert_ne!(a, argon2id_l1_tag_v1(h(0x11), 42, b"mainnet"), "network must change the tag");
        // It must differ from the kHeavyHash-seed derivation on the same inputs (different algo).
        assert_ne!(a.as_slice(), l1_seed32_for_kheavyhash_v1(h(0x11)).as_bytes().as_slice());
    }

    /// The finalizer is deterministic: same input -> same output.
    #[test]
    fn finalizer_deterministic() {
        let net = b"simnet";
        let a = pow_finalizer_blake2b_512(net, 1, h(0x11), 1_000_000, 0x1e7fffff, 42, &[7u8; 32]).unwrap();
        let b = pow_finalizer_blake2b_512(net, 1, h(0x11), 1_000_000, 0x1e7fffff, 42, &[7u8; 32]).unwrap();
        assert_eq!(a, b);
        assert_eq!(a.len(), POW_FINALIZER_BYTES);
    }

    /// Every input field meaningfully influences the digest. This is
    /// the self-delimiting property of the layout — varying any one
    /// field must shift the output.
    #[test]
    fn finalizer_inputs_change_digest() {
        let base = pow_finalizer_blake2b_512(b"simnet", 1, h(0x11), 100, 0x1e7fffff, 7, &[3u8; 32]).unwrap();

        let net_diff = pow_finalizer_blake2b_512(b"mainnet", 1, h(0x11), 100, 0x1e7fffff, 7, &[3u8; 32]).unwrap();
        assert_ne!(base, net_diff, "network_id must alter digest");

        // algo_id 2 is not a valid Phase 1 id, but the finalizer must
        // accept arbitrary algo_id bytes (Phase 2+ will hard-fork in
        // new ids). What matters here: changing algo_id changes the
        // digest.
        let algo_diff = pow_finalizer_blake2b_512(b"simnet", 2, h(0x11), 100, 0x1e7fffff, 7, &[3u8; 32]).unwrap();
        assert_ne!(base, algo_diff, "algo_id must alter digest");

        let pre_diff = pow_finalizer_blake2b_512(b"simnet", 1, h(0x22), 100, 0x1e7fffff, 7, &[3u8; 32]).unwrap();
        assert_ne!(base, pre_diff, "pre_pow_hash must alter digest");

        let ts_diff = pow_finalizer_blake2b_512(b"simnet", 1, h(0x11), 101, 0x1e7fffff, 7, &[3u8; 32]).unwrap();
        assert_ne!(base, ts_diff, "timestamp must alter digest");

        let bits_diff = pow_finalizer_blake2b_512(b"simnet", 1, h(0x11), 100, 0x207fffff, 7, &[3u8; 32]).unwrap();
        assert_ne!(base, bits_diff, "bits must alter digest");

        let nonce_diff = pow_finalizer_blake2b_512(b"simnet", 1, h(0x11), 100, 0x1e7fffff, 8, &[3u8; 32]).unwrap();
        assert_ne!(base, nonce_diff, "nonce must alter digest");

        let tag_diff = pow_finalizer_blake2b_512(b"simnet", 1, h(0x11), 100, 0x1e7fffff, 7, &[4u8; 32]).unwrap();
        assert_ne!(base, tag_diff, "l1_tag bytes must alter digest");

        let len_diff = pow_finalizer_blake2b_512(b"simnet", 1, h(0x11), 100, 0x1e7fffff, 7, &[3u8; 31]).unwrap();
        assert_ne!(base, len_diff, "l1_tag length must alter digest");
    }

    /// The 2-byte length prefix in front of `l1_tag` defeats the
    /// canonical-concat collision attack: two distinct (tag, netid)
    /// pairs whose concatenation is the same string must still
    /// produce different digests.
    #[test]
    fn finalizer_l1_tag_is_self_delimiting() {
        // Construction: two l1_tag values whose raw bytes differ only
        // by length-prefix boundary placement. Without the length
        // prefix this would collide; with it, the digests differ.
        let a = pow_finalizer_blake2b_512(b"net", 1, ZERO_HASH64, 0, 0, 0, b"AB").unwrap();
        let b = pow_finalizer_blake2b_512(b"net", 1, ZERO_HASH64, 0, 0, 0, b"ABCD").unwrap();
        let c = pow_finalizer_blake2b_512(b"net", 1, ZERO_HASH64, 0, 0, 0, b"").unwrap();
        assert_ne!(a, b);
        assert_ne!(a, c);
        assert_ne!(b, c);
    }

    #[test]
    fn finalizer_rejects_overlong_l1_tag() {
        let too_long = vec![0u8; POW_L1_TAG_MAX_BYTES + 1];
        let r = pow_finalizer_blake2b_512(b"net", 1, ZERO_HASH64, 0, 0, 0, &too_long);
        assert_eq!(r, Err(PowLayer0Error::L1TagTooLong(POW_L1_TAG_MAX_BYTES + 1)));
    }

    /// Difficulty-lift identity at the consensus-core boundary —
    /// matches the same identity tested in `kaspa-math` but routed
    /// through this module's `lift_target_256_to_512` re-export.
    #[test]
    fn pq_difficulty_lift_identity_at_consensus_boundary() {
        for bits in [0x207fffffu32, 0x1d00ffffu32, 0x1e21bc1cu32, 486722099u32] {
            let target_256 = Uint256::from_compact_target_bits(bits);
            let via_decoder = Uint512::from_compact_target_bits_512(bits);
            let via_lift = lift_target_256_to_512(target_256);
            assert_eq!(via_decoder, via_lift, "decoder and lift disagree on bits={bits:#x}");
        }
    }

    #[test]
    fn calc_work_512_reexport_matches_math() {
        let target = Uint512::from_compact_target_bits_512(0x1e7fffff);
        let work_via_module = calc_work_512(target);
        let work_via_math = target.calc_work_512();
        assert_eq!(work_via_module, work_via_math);
    }

    /// Sanity check: the empty-input digest is non-trivial. (Catches
    /// a future accidental hard-coding to zero.)
    #[test]
    fn finalizer_empty_input_nontrivial_digest() {
        let d = pow_finalizer_blake2b_512(b"", 0, ZERO_HASH64, 0, 0, 0, b"").unwrap();
        assert_ne!(d, [0u8; POW_FINALIZER_BYTES]);
    }

    /// kaspa-pq Phase 9 (PR-9.3): the algo_id = 1 (kHeavyHash) seed
    /// derivation is deterministic, sensitive to every byte of the
    /// 64-byte pre-PoW hash, and key-separated from the other
    /// kaspa-pq BLAKE2b-256 hashers (TransactionHash, BlockHash,
    /// MuHashElementHash, …). Determinism is the basis for miner
    /// reproducibility; key-separation is the basis for not being
    /// substitutable elsewhere.
    #[test]
    fn l1_seed32_for_kheavyhash_v1_basic_properties() {
        let a = l1_seed32_for_kheavyhash_v1(h(0x11));
        let b = l1_seed32_for_kheavyhash_v1(h(0x11));
        assert_eq!(a, b, "derivation must be deterministic");

        let c = l1_seed32_for_kheavyhash_v1(h(0x12));
        assert_ne!(a, c, "different pre-PoW hashes must yield different seeds");

        // Flip the last byte of the 64-byte input; the derived seed
        // must shift.
        let mut bytes = [0x11u8; 64];
        bytes[63] = 0x12;
        let last_bit_flipped = l1_seed32_for_kheavyhash_v1(Hash64::from_bytes(bytes));
        assert_ne!(a, last_bit_flipped, "every byte of pre_pow_hash must influence the seed");

        // Key separation against the existing 32-byte BLAKE2b
        // hashers. The kHeavyHash seed must not equal any of them on
        // the same input bytes.
        use kaspa_hashes::{BlockHash, Hasher, MuHashElementHash, TransactionHash};
        let pre_pow_bytes = h(0x33).as_bytes();
        let pre_pow_slice: &[u8] = &pre_pow_bytes;
        let seed = l1_seed32_for_kheavyhash_v1(h(0x33));
        assert_ne!(seed.as_bytes(), BlockHash::hash(pre_pow_slice).as_bytes());
        assert_ne!(seed.as_bytes(), TransactionHash::hash(pre_pow_slice).as_bytes());
        assert_ne!(seed.as_bytes(), MuHashElementHash::hash(pre_pow_slice).as_bytes());
    }
}

#[cfg(test)]
mod two_lane_gate_tests {
    use super::*;
    use crate::palw_mode_v2::PalwConsensusMode;

    /// **A V2 network accepts both of its lanes, and the gate has to ask the right question.**
    ///
    /// `required_algo_id` is what a producer DECLARES; `accepts_algo_id` is what a validator
    /// ALLOWS. They differ by exactly the free-prompt receipt lane — the one that needs no model —
    /// and a gate using the first refused every block on the second.
    #[test]
    fn the_gate_accepts_both_v2_lanes_and_nothing_else() {
        let bundle = crate::palw_mode_v2::tests::conforming_bundle();
        let mode = PalwConsensusMode::ConsensusV2(bundle.clone());
        let required = mode.required_algo_id();

        // The two bonded PALW lanes, always. The heartbeat is NOT one of them since ADR-0066: it
        // has its own id (8) and its own top-level fence, and the bundle deliberately cannot see
        // that fence — `Params::palw_heartbeat_lane_open_at` is the one place that decides.
        for id in [POW_ALGO_ID_PALW_COMMITTED_V2, POW_ALGO_ID_PALW_RECEIPT_V3] {
            check_algo_id_for_mode_accepting(id, required, mode.accepts_algo_id(id), false, false, false)
                .unwrap_or_else(|e| panic!("a V2 network must accept its own lane {id}: {e:?}"));
        }
        assert_eq!(
            mode.accepts_algo_id(POW_ALGO_ID_HEARTBEAT_V1),
            Some(false),
            "the bundle never admits the heartbeat id — the fence does, one level up"
        );
        assert_eq!(mode.accepts_algo_id(POW_ALGO_ID_BLAKE2B_SHA3), Some(false), "and the hash lane is not this network's");
        // The pre-V2 inference lanes and the Phase-1/2 algos are not this network's.
        for id in [POW_ALGO_ID_KHEAVYHASH, POW_ALGO_ID_ARGON2ID, POW_ALGO_ID_PALW_LLM, POW_ALGO_ID_PALW_OLLAMA] {
            assert!(
                check_algo_id_for_mode_accepting(id, required, mode.accepts_algo_id(id), true, true, true).is_err(),
                "a V2 network must not accept {id} — its lanes are exclusive"
            );
        }
    }

    /// **Every non-V2 preset is untouched, byte for byte.** `accepts_algo_id` is `None` there, and
    /// the function falls through to the comparison it always made.
    #[test]
    fn a_non_v2_network_falls_through_to_the_v1_cascade() {
        for mode in [PalwConsensusMode::Disabled, PalwConsensusMode::LegacyTn11] {
            assert_eq!(mode.accepts_algo_id(POW_ALGO_ID_PALW_RECEIPT_V3), None);
            let required = mode.required_algo_id();
            for (ollama, llm, b2s3) in [(false, false, false), (false, false, true), (false, true, false), (true, false, false)] {
                for id in 0u8..=8 {
                    assert_eq!(
                        check_algo_id_for_mode_accepting(id, required, mode.accepts_algo_id(id), ollama, llm, b2s3).is_ok(),
                        check_algo_id_for_mode(id, required, ollama, llm, b2s3).is_ok(),
                        "id {id} at ({ollama},{llm},{b2s3}) must decide exactly as it did before"
                    );
                }
            }
        }
    }
}
