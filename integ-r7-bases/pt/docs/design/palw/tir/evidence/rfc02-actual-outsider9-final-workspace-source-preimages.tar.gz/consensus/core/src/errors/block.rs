use std::{collections::HashMap, fmt::Display};

use crate::{
    BlockHash, BlueWorkType,
    block::AttestationTemplateDrop,
    errors::{coinbase::CoinbaseError, tx::TxRuleError},
    tx::{TransactionId, TransactionOutpoint},
};
use itertools::Itertools;
// kaspa-pq (ADR-0004 / design §12): the two utxo-commitment positions of
// `BadUTXOCommitment` are 64-byte `Hash64`; block-identifier positions use `BlockHash`.
use kaspa_hashes::Hash64;
use thiserror::Error;

#[derive(Clone, Debug)]
pub struct VecDisplay<T: Display>(pub Vec<T>);
impl<T: Display> Display for VecDisplay<T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "[{}]", self.0.iter().map(|item| item.to_string()).join(", "))
    }
}

#[derive(Clone, Debug)]
pub struct TwoDimVecDisplay<T: Display + Clone>(pub Vec<Vec<T>>);
impl<T: Display + Clone> Display for TwoDimVecDisplay<T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "[\n\t{}\n]", self.0.iter().cloned().map(|item| VecDisplay(item).to_string()).join(", \n\t"))
    }
}

#[derive(Error, Debug, Clone)]
pub enum RuleError {
    #[error("wrong block version: got {0} but expected {1}")]
    WrongBlockVersion(u16, u16),

    #[error("unknown pow_algo_id {0}: Phase 1 admits only kHeavyHash (POW_ALGO_ID_KHEAVYHASH = 1)")]
    UnknownPowAlgoId(u8),

    // MISAKA ADR-0038: `Header::palw_commitment` shape rule (pow_layer0::check_palw_commitment_shape).
    // On non-PALW algo ids the field is hash-invisible, so non-empty bytes there are block-hash
    // malleability; on PALW ids it is capped. Structural — not behind any activation fence.
    #[error("bad palw_commitment shape: {0}")]
    BadPalwCommitmentShape(String),

    /// MISAKA ADR-0042 Unit A / ADR-0044 Unit B: a V2-lineage header's carriage decoded, but its
    /// STATELESS admission failed — the carried challenge is not the one this header position
    /// derives, a budget field is zero, the signature is the wrong length, and so on. Separate
    /// from `BadPalwCommitmentShape` because "this is not a commitment" and "this commitment does
    /// not belong to this header" are different things to tell an operator.
    #[error("PALW header (algo_id = {algo_id}) failed stateless admission: {reason}")]
    BadPalwCarriageAdmission { algo_id: u8, reason: String },

    /// ADR-0042 Decision 10: a claim matured into a spendable reward, but the bond it names is
    /// no longer in the registry, so there is no payee to derive an output script from. The
    /// block is refused rather than paid short: dropping the claim would make the coinbase
    /// depend on which claims happened to resolve, and two nodes disagreeing about a coinbase is
    /// a fork. (The `palw_credit_batch` I7 rule, on the V2 lattice: missing is never empty.)
    #[error("PALW claim {0} matured with a spendable reward but its bond is not in the registry — no payee to derive")]
    PalwV2UnpayableClaim(kaspa_hashes::Hash64),

    // kaspa-pq Selected-Parent EVM Lane (ADR-0020). The EVM state-root / receipts
    // / commitment mismatch variants are added in the executor phase (P2) when
    // they are actually produced.
    #[error("block carries a non-empty EVM payload but its header version is below EVM_HEADER_VERSION (EVM lane not active)")]
    NonEmptyEvmPayloadBeforeActivation,

    // audit #6: a pre-v2 header's EVM commitment fields are hash-invisible (the
    // preimage only includes them from EVM_HEADER_VERSION up), so non-zero values
    // there would be block-id malleability + a migration hazard. Force them zero.
    #[error("pre-activation (v1) header carries non-zero EVM commitment fields (must be zero while hash-invisible)")]
    NonZeroEvmHeaderFieldsBeforeActivation,

    // audit R2-#4: the producer-side EVM acceptance run failed while building a
    // template (e.g. a local EVM store-integrity error). A template build failure,
    // NOT a panic — the node skips producing rather than crashing.
    #[error("EVM template acceptance execution failed: {0}")]
    EvmTemplateExecutionFailed(String),

    // v0.4 §4.1 / §6.2: the header's payload DATA commitment must match the body.
    #[error("header evm_payload_hash does not match the block body's EVM payload")]
    EvmPayloadHashMismatch,

    // v0.4 §7 (D4 inclusion-side cap, checked at body validation).
    #[error("EVM payload too large: {0} bytes exceeds MAX_EVM_PAYLOAD_BYTES_PER_DAG_BLOCK = {1}")]
    EvmPayloadTooLarge(usize, usize),

    // v0.4 §9.2: bounded producer-selected system ops.
    #[error("too many EVM system ops: {0} exceeds MAX_DEPOSIT_CLAIMS_PER_EVM_BLOCK = {1}")]
    TooManyEvmSystemOps(usize, usize),

    // v0.4 §6.1 class 1: payload admission — a producer including a
    // syntactically inadmissible tx invalidates ITS OWN block (cheap syntactic
    // check; acceptance-time conditions are class-2 skips, never block faults).
    #[error("EVM payload tx {0} fails class-1 admission: {1}")]
    EvmPayloadTxInadmissible(usize, String),

    #[error("the block timestamp is too far into the future: block timestamp is {0} but maximum timestamp allowed is {1}")]
    TimeTooFarIntoTheFuture(u64, u64),

    #[error("block has no parents")]
    NoParents,

    #[error("block has too many parents: got {0} when the limit is {1}")]
    TooManyParents(usize, usize),

    #[error("block has ORIGIN as one of its parents")]
    OriginParent,

    #[error("parent {0} is an ancestor of parent {1}")]
    InvalidParentsRelation(BlockHash, BlockHash),

    #[error("parent {0} is invalid")]
    InvalidParent(BlockHash),

    #[error("block has missing parents: {0:?}")]
    MissingParents(Vec<BlockHash>),

    #[error("pruning point {0} is not in the past of this block")]
    PruningViolation(BlockHash),

    #[error("expected header daa score {0} but got {1}")]
    UnexpectedHeaderDaaScore(u64, u64),

    #[error("expected header blue score {0} but got {1}")]
    UnexpectedHeaderBlueScore(u64, u64),

    #[error("expected header blue work {0} but got {1}")]
    UnexpectedHeaderBlueWork(BlueWorkType, BlueWorkType),

    #[error("block {0} difficulty of {1} is not the expected value of {2}")]
    UnexpectedDifficulty(BlockHash, u32, u32),

    /// ADR-0060 Decision 1: a heartbeat block inside the slot rule's interval — the youngest
    /// heartbeat this POV's window holds is too recent for another.
    #[error(
        "heartbeat block {0} at timestamp {1} is inside the slot interval: the window's youngest heartbeat is at {2} and the current interval is {3} ms (ADR-0060)"
    )]
    HeartbeatTooEarly(BlockHash, u64, u64, u64),

    /// **The clock floor, H3 (the 2026-09-24 heartbeat audit):** past `palw_clock_floor` a
    /// heartbeat stamped before the slot its own window's cursor opens is invalid. Such a beat can
    /// never be granted a DAA, so it was a valid block that ticked nothing — 89% of testnet-12's.
    #[error(
        "heartbeat block {0} at timestamp {1} is stamped before its slot, which opens at {2}: a beat before its slot can \
         never tick the clock (palw_clock_floor, H3)"
    )]
    HeartbeatBeforeItsSlot(BlockHash, u64, u64),

    /// **The clock floor, H5:** past `palw_clock_floor` a block whose mergeset grants a heartbeat's
    /// tick — the block that STEPS the clock — must itself be stamped at or past the cursor it was
    /// granted against, since it becomes the next slot's reference. Stamped earlier, it would open
    /// the next slot early and the clock could run faster than one tick per interval.
    #[error(
        "block {0} steps the clock at timestamp {1}, before the slot it was granted, which opened at {2}: the step is the \
         next slot's reference and may not predate the slot it consumed (palw_clock_floor, H5)"
    )]
    ClockStepBeforeItsSlot(BlockHash, u64, u64),

    /// **The clock floor, H3:** past `palw_clock_floor` a heartbeat chain over the per-mergeset
    /// bound (F5's exemption) must be paced by its own timestamps — at most two beats a slot, which
    /// is all an honest chain can hold — or the exemption admits a burst the slot rule once priced.
    #[error(
        "block merges a chain of {0} heartbeat blocks spanning {1} ms of timestamps: more than the {2} a chain paced by the \
         clock can hold (palw_clock_floor, H3)"
    )]
    MergeSetHeartbeatChainUnpaced(u64, u64, u64),

    /// **The lead cap (`palw_clock_lead_cap`):** a header that moves the heartbeat clock — a
    /// heartbeat, or the block that steps the clock on a beat's grant — stamped more than 132 s past
    /// this node's clock. A local-clock rule like [`RuleError::TimeTooFarIntoTheFuture`]: never
    /// cached as invalid, and the same header is admitted once the clock reaches the stamp less the cap.
    #[error(
        "block {0} moves the heartbeat clock and is stamped {1}, past {2} — this node's clock plus the 132 s a clock-moving \
         header may lead it (palw_clock_lead_cap); not invalid, admissible once the clock catches up"
    )]
    ClockLeadTooFarAhead(BlockHash, u64, u64),

    /// **The lead cap's construction half:** the template this node would build steps the clock at a
    /// stamp its own header stage refuses — `max(now, median + 1, slot)` past this node's clock plus
    /// 132 s. The builder waits rather than hand out a block every peer refuses. Virtual does not
    /// merge a beat whose step would be refused so (`palw_lead_cap_virtual_parents`), so what is left
    /// to reach this is a sink that is itself such a beat, or this host's clock stepping back.
    #[error(
        "the template would step the heartbeat clock at {0}, past {1} — this node's clock plus the 132 s a clock-moving header \
         may lead it (palw_clock_lead_cap): waiting {2} ms for wall time instead of building a block peers refuse"
    )]
    ClockStepTemplateTooFarAhead(u64, u64, u64),

    /// A header whose lane does not commit PALW state carries a non-zero `palw_state_root`. The
    /// field is hash-invisible on such a header (see `hashing::header::write_header_preimage`),
    /// so non-empty bytes there would be block-hash malleability — the
    /// `NonPalwHeaderCarriesPalwCommitment` class, reached through the sibling field.
    #[error("header (algo_id = {0}) carries a non-zero palw_state_root its lane does not commit; must be zero")]
    UncommittedPalwStateRoot(u8),

    #[error("block timestamp of {0} is not after expected {1}")]
    TimeTooOld(u64, u64),

    #[error("block is known to be invalid")]
    KnownInvalid,

    #[error("block merges {0} blocks > {1} merge set size limit")]
    MergeSetTooBig(u64, u64),

    #[error("block merges {0} heartbeat blocks > {1}, the heartbeat width bound (ADR-0068 Phase 1 / finding F3a)")]
    MergeSetTooManyHeartbeats(u64, u64),

    /// ADR-0125: a block's parents break the round lane's shape — every block needs a parent that is
    /// not a round block, a round block has exactly one, and a round parent's anchor must be on the
    /// block's selected chain.
    #[error("round lane parents: {0}")]
    BadRoundLaneParents(String),

    /// ADR-0125: a block's mergeset breaks the round lane's header rule (count, width, a permit twice,
    /// or a round block merging a round that is not older than its own).
    #[error("round lane mergeset: {0}")]
    BadRoundLaneMergeset(String),

    /// RFC-0008 v2: a coinbase's anchor trailer is malformed, rides a lane block, or does not match the EXEC blocks its heads cover.
    #[error("EXEC anchor: {0}")]
    BadExecAnchor(crate::palw_exec_v2_anchor::PalwExecV2AnchorErrorV1),

    /// RFC-0008 v2: an `EXEC_SLICE` carrier carries a transaction beside its coinbase — a slice has no user transaction batch.
    #[error("an EXEC_SLICE block carries {0} transactions: a slice carries only its coinbase")]
    ExecSliceCarriesTransactions(usize),

    /// Lane accept-order (post-launch, `palw_lane_accept_parents_first`): a round block carries no EVM
    /// payload — its merging block would execute it with no permit asked.
    #[error("a round block carries a non-empty EVM payload past palw_lane_accept_parents_first")]
    RoundBlockCarriesEvmPayload,

    #[error("block is violating bounded merge depth")]
    ViolatingBoundedMergeDepth,

    #[error("invalid merkle root: header indicates {0} but calculated value is {1}")]
    // PR-9.5c: `MerkleRoot` widened to `Hash64`; both arguments
    // carry the wider value.
    BadMerkleRoot(crate::MerkleRoot, crate::MerkleRoot),

    #[error("block has no transactions")]
    NoTransactions,

    #[error("block first transaction is not coinbase")]
    FirstTxNotCoinbase,

    #[error("block has second coinbase transaction as index {0}")]
    MultipleCoinbases(usize),

    #[error("bad coinbase payload: {0}")]
    BadCoinbasePayload(CoinbaseError),

    #[error("coinbase blue score of {0} is not the expected value of {1}")]
    BadCoinbasePayloadBlueScore(u64, u64),

    /// kaspa-pq PQ-only invariant: the coinbase payload's miner script must itself be ML-DSA
    /// P2PKH. Unlike the block's coinbase outputs (PQ-class-checked in isolation), the payload
    /// miner script flows into descendant blocks' reward fan-out, so a non-PQ script here would
    /// poison the reward path (every descendant's coinbase would carry a non-PQ output the PQ
    /// rule rejects) — a consensus-liveness hazard. Rejected at the source block.
    #[error("coinbase payload miner script is not a PQ-standard (ML-DSA P2PKH) script")]
    NonPqCoinbasePayloadScript,

    #[error("transaction in isolation validation failed for tx {0}: {1}")]
    TxInIsolationValidationFailed(TransactionId, TxRuleError),

    #[error("block compute mass {0} exceeds limit of {1}")]
    ExceedsComputeMassLimit(u64, u64),

    #[error("block transient storage mass {0} exceeds limit of {1}")]
    ExceedsTransientMassLimit(u64, u64),

    #[error("block persistent storage mass {0} exceeds limit of {1}")]
    ExceedsStorageMassLimit(u64, u64),

    #[error("outpoint {0} is spent more than once on the same block")]
    DoubleSpendInSameBlock(TransactionOutpoint),

    #[error("outpoint {0} is created and spent on the same block")]
    ChainedTransaction(TransactionOutpoint),

    #[error("transaction in context validation failed for tx {0}: {1}")]
    TxInContextFailed(TransactionId, TxRuleError),

    #[error("wrong coinbase subsidy: expected {0} but got {1}")]
    WrongSubsidy(u64, u64),

    #[error("transaction {0} is found more than once in the block")]
    DuplicateTransactions(TransactionId),

    #[error("block has invalid proof-of-work")]
    InvalidPoW,

    #[error("expected header pruning point is {0} but got {1}")]
    WrongHeaderPruningPoint(BlockHash, BlockHash),

    #[error("expected indirect parents {0} but got {1}")]
    UnexpectedIndirectParents(TwoDimVecDisplay<BlockHash>, TwoDimVecDisplay<BlockHash>),

    #[error("block {0} UTXO commitment is invalid - block header indicates {1}, but calculated value is {2}")]
    // kaspa-pq (ADR-0004 / design §12): the two commitment positions are 64-byte Hash64.
    BadUTXOCommitment(BlockHash, Hash64, Hash64),

    #[error("block {0} overlay commitment is invalid - block header indicates {1}, but calculated value is {2}")]
    // kaspa-pq ADR-0022: the DNS/PoS-v2 OverlaySnapshot commitment (as-of selected parent).
    // Positions 1/2 are 64-byte Hash64. Surfaces as StatusDisqualifiedFromChain like any c==v fault.
    BadOverlayCommitment(BlockHash, Hash64, Hash64),

    #[error("block {0} accepted ID merkle root is invalid - block header indicates {1}, but calculated value is {2}")]
    // PR-9.5c: positions 1 and 2 carry `AcceptedIdMerkleRoot`
    // (= `Hash64`). The block-identifier (position 0) is still
    // 32-byte `BlockHash` — that flips with the rest of `BlockHash`
    // in PR-9.5d.
    BadAcceptedIDMerkleRoot(BlockHash, crate::AcceptedIdMerkleRoot, crate::AcceptedIdMerkleRoot),

    #[error("coinbase transaction is not built as expected")]
    BadCoinbaseTransaction,

    // kaspa-pq Phase 10/11 (ADR-0009 Addendum B §B.4): the Model-B
    // reward-eligibility block-validity rule. A block carrying a
    // `StakeAttestationShard` whose attestation does not resolve to an
    // `Active` bond (in the block's selected-parent bond view, at the
    // attestation's target DAA score) with a valid ML-DSA-87 signature is
    // rejected, so that every included attestation is rewardable and the
    // coinbase fan-out needs no skip set. Args: the referenced bond's
    // transaction id and the attestation epoch. Inert below
    // `dns_activation_daa_score`.
    #[error("block includes an ineligible stake attestation: bond {0} epoch {1} is not an active bond with a valid signature")]
    IneligibleAttestationInBlock(TransactionId, u64),

    // kaspa-pq Phase 10/11 (ADR-0009 §"SlashingEvidencePayload" / ADR-0013):
    // a block carrying a SlashingEvidence whose evidence is not genuine —
    // its referenced bond is unknown in the block's selected-parent bond view,
    // or one of the two equivocating attestations does not ML-DSA-verify
    // against that bond's validator key — is rejected, so a well-formed but
    // forged evidence cannot slash a bond. Arg: the referenced bond's
    // transaction id. Inert below dns_activation_daa_score.
    #[error("block includes unverifiable slashing evidence against bond {0}")]
    UnverifiableSlashingEvidenceInBlock(TransactionId),

    // MISAKA Verified LLM Token-Weighted BFT (§7): a block carrying a compute
    // fraud proof that is not genuine — an unknown or unbonded challenger, a
    // challenger signature that does not verify, or (for the one slashing kind,
    // ContradictoryVerification) verdicts that do not ML-DSA-verify against the
    // bond they incriminate — is rejected. Without it a well-formed but baseless
    // challenge would deny any certificate its credit, and slash any bond, for
    // the price of one transaction. Arg: the challenge transaction's id. Inert
    // below dns_activation_daa_score.
    /// ADR-0134: past `Params::palw_compute_overlay_retired` no compute-overlay transaction (the
    /// VLT's certificate, challenge, capability, commitment or verdict subnetworks) enters a block.
    #[error("block includes a compute-overlay transaction {0} past the overlay's retirement")]
    ComputeOverlayRetired(TransactionId),

    #[error("block contains retired DNS participation transaction {0} (RFC-0012)")]
    DnsParticipationRetired(TransactionId),

    // MISAKA §5 round 2: a block carrying precommit evidence whose bond is unknown, whose
    // precommits are not bound to that bond's validator key, whose bond held no slashable stake
    // when it signed, or either of whose ML-DSA signatures does not verify, is rejected. The
    // stateless layer only checks that the two payloads *would* contradict each other; without
    // this rule anyone could author that contradiction and burn any validator's bond for the
    // price of one transaction. Arg: the referenced bond's transaction id. Inert below
    // dns_activation_daa_score.
    #[error("block includes unverifiable precommit evidence against bond {0}")]
    UnverifiablePrecommitEvidenceInBlock(TransactionId),

    // ADR-0032 Phase E2: a block transaction spends an audit-call bond UTXO (an
    // opening-call carriage transaction's output 0) whose disposition does not
    // permit it — the call is still inside its answer/settlement window, or an
    // accepted answer committed the bond to the slash flow. Inert while the
    // PALW credit fence is `None` (every shipped network).
    #[error("block transaction {0} spends audit-call bond outpoint {1} against its disposition")]
    AuditBondSpendAgainstDisposition(TransactionId, TransactionOutpoint),

    // kaspa-pq H-05 (audit / ADR-0010 "Unbonding"): a block carrying a
    // `StakeUnbondRequest` that is not owner-authorized — its bond is unknown in
    // the block's selected-parent view, is not `Pending`/`Active` at the block's
    // DAA score, or its `owner_pubkey` does not hash to the bond's
    // `owner_pubkey_hash` / does not ML-DSA-verify over the canonical unbond
    // digest — is rejected, so an attacker cannot force an honest validator's
    // bond into `Unbonding` (a liveness/grief attack). Args: the unbond tx id
    // and the referenced bond outpoint.
    #[error("block includes an unauthorized stake-unbond request: tx {0} for bond {1}")]
    UnauthorizedUnbondRequestInBlock(TransactionId, TransactionOutpoint),

    #[error("{0} non-coinbase transactions (out of {1}) are invalid in UTXO context")]
    InvalidTransactionsInUtxoContext(usize, usize),

    #[error("invalid transactions in new block template")]
    InvalidTransactionsInNewBlock(HashMap<TransactionId, TxRuleError>),

    // kaspa-pq DNS-finality optional hard-inclusion liveness: template construction may classify and
    // drop ineligible attestation shards before failing later (for example on the mandatory floor). Carry
    // those drops with the underlying error so the mining manager can still evict/quarantine them
    // and avoid rebuilding against the same poisoned mempool state forever.
    #[error("block template build failed after dropping attestation shard(s): {0}")]
    TemplateBuildFailedAfterAttestationDrops(Box<RuleError>, Vec<AttestationTemplateDrop>),

    #[error("DAA window data has only {0} entries")]
    InsufficientDaaWindowSize(usize),

    /// Currently this error is never created because it is impossible to submit such a block
    #[error("cannot add block body to a pruned block")]
    PrunedBlock,
}

pub type BlockProcessResult<T> = std::result::Result<T, RuleError>;

impl RuleError {
    /// Attach template-classifier attestation drops to an error that aborts block-template
    /// construction. Consensus validation errors remain unchanged when there are no drops.
    pub fn with_attestation_template_drops(self, dropped_attestation_shards: &[AttestationTemplateDrop]) -> Self {
        if dropped_attestation_shards.is_empty() {
            self
        } else {
            match self {
                RuleError::TemplateBuildFailedAfterAttestationDrops(source, mut existing) => {
                    existing.extend_from_slice(dropped_attestation_shards);
                    RuleError::TemplateBuildFailedAfterAttestationDrops(source, existing)
                }
                err => RuleError::TemplateBuildFailedAfterAttestationDrops(Box::new(err), dropped_attestation_shards.to_vec()),
            }
        }
    }
}
