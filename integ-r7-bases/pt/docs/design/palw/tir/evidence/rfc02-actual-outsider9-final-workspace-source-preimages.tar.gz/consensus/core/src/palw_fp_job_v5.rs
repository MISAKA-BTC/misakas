//! **FP Job V5: a free-prompt job with image inputs** — the job of a vision-language class
//! (RFC-0003 §II.2.1, PALW-GEN-13), in RFC-0001's free-prompt lane. Dormant behind
//! `Params::palw_fp_job_v5`: `None` on every preset, so FP Job V4 is exactly what it was.
//!
//! **V5 embeds V4 unchanged.** [`PalwFreePromptJobV5::v4`] IS an FP Job V4 — a
//! [`PalwFreePromptJobV3`] at [`PALW_FP_V4_VERSION`] with its `DecodeConfigV4` — and every field,
//! rule and method of it is the V4 lane's own: the V4 checks run on it verbatim
//! ([`PalwFpDecodeRulesV1::check_job`]), its decoder is its `decoder_v1()`. What V5 adds is the job's
//! images, each an [`PalwGenImageInputRefV1`] (`input_root`, `h`, `w`), exactly one per image slot of
//! the class (PALW-GEN-11), and — for a class that reads one (RFC-0003 §II.2.2, an encoder–decoder)
//! — its source, a [`PalwGenSourceRefV1`] (the source ids' hash in the network's prompt-id form, and
//! their count).
//!
//! **The wire.** `le16(8) ‖ the V4 job's bytes after its version word ‖ borsh(images) ‖
//! borsh(source)`: a V5 job is a V4 job whose version word says 8 and which is followed by its images
//! and its source ([`PalwFpV5TailV1`]). The source's ids never ride the chain: like the images'
//! bytes they travel to the worker and the panel, bound by the reference's hash, under either privacy
//! mode (a `PublicDa` job publishes its prompt, not its source). No V4 entry point decodes
//! it as a job it admits — every V3/V4 validator refuses version 8 by name (`UnsupportedVersion`) —
//! and no V4 byte string decodes as a V5 job (version 7 is not 8). The id is the whole borsh under
//! its own key, [`fp_job_id_v5`], a domain no V3/V4 id uses.
//!
//! **One encoding per behaviour** (RFC-0003 open question 14, decided 2026-09-29; extended by §II.2.2):
//! a class with image slots or a source takes V5 only; a class with neither V4 only
//! ([`palw_fp_job_version_offered_v1`]). A V5 job carries images or a source, never neither, so a
//! text-only job has exactly one encoding, V4's. The source's price is open question 15's (as prompt
//! tokens, PENDING USER CONFIRMATION with 13: [`palw_fp_v5_source_tokens_v1`]).
//!
//! **The image price** (RFC-0003 open question 13 — the recommendation, **PENDING USER
//! CONFIRMATION**): a V5 job's image stages are charged as prefill-equivalent prompt tokens — each
//! image slot's declared `token_equivalents`, floored by admission at `⌈admitted per-image work /
//! per-token work⌉` (`palw_gen_class_v1::palw_gen_image_token_floor_v1`) — at the job's per-token
//! price ([`palw_fp_v5_image_tokens_v1`], [`palw_fp_v5_image_charge_v1`]). Nothing in the lane reads
//! them yet: RFC-0001's D10 still credits decode leaves only, and wiring this price into the lane's
//! quanta waits for the user's confirmation.
//!
//! **The source price** (RFC-0003 open question 15 — the recommendation, **PENDING USER
//! CONFIRMATION** with 13): a V5 job's source ids are charged as prompt tokens, one per id, and never
//! below the class's `source_token_floor` — an encoder runs its whole padded width for any source, so
//! a short source pays the encoder's admitted work (the floor admission checks, as it floors an image
//! slot's price) ([`palw_fp_v5_source_tokens_v1`]); a job's whole input charge is its images' and its
//! source's ([`palw_fp_v5_input_tokens_v1`], [`palw_fp_v5_input_charge_v1`]). Wired into nothing, as
//! the image price.
//!
//! **The lane stays closed to V5**: a V5 claim's class resolves against the generative registry
//! ([`palw_fp_v5_resolve_class_v1`], over the `gen_classes` rows `ClassRegisteredGenV1` writes past
//! `palw_gen_v1`), but the free-prompt walk still skips every version-8 payload — the lane opens for
//! pipeline classes at its own later fence (this one, `palw_fp_job_v5`), with OQ13's price confirmed.
//! `tests/palw_fp_v5_leaves_v4_unchanged.rs` holds FP Job V4's wire, ids and validators byte for byte
//! with this module compiled in.

use std::io::{Read, Write};

use crate::Hash64;
use crate::config::params::{ForkActivation, PalwPostLaunchFenceV1, Params};
use crate::palw_freeprompt_v3::{PALW_FP_V4_VERSION, PalwFpDecodeRulesV1, PalwFpV3Error, PalwFreePromptJobV3, PalwFreePromptJobV4};
use crate::palw_gen_class_v1::{
    PalwGenImageInputRefV1, PalwGenJobImageErrorV1, PalwGenOffersV1, PalwGenSourceRefV1, palw_gen_job_images_admitted_v1,
};
use crate::palw_mode_v2::{PalwConsensusMode, PalwModeV2Error};

/// **The FP Job V5 version**: 8, the next unused job version (5 is V3, 6 ADR-0096 D8's constraint
/// job, named and unbuilt, 7 is V4). RFC-0001 may assign another number at freeze; this one is
/// provisional and binds nothing a network runs.
pub const PALW_FP_V5_VERSION: u16 = 8;
/// The V5 job id's key: a domain no V3 or V4 id uses.
pub const PALW_FP_V5_DOMAIN_JOB_ID: &[u8] = b"misaka-palw/fp-v5/job-id/v1";
/// The most images a V5 job carries: the pipeline format's image cap.
pub const PALW_FP_V5_MAX_IMAGES: usize = misaka_palw_tir::pipeline::MAX_JOB_IMAGES;

/// **FP Job V5's tail**: what version 8 adds after the V4 job's bytes — its images, then its source.
/// The lane's job type carries it as one field (`PalwFreePromptJobV3::tail`), so the carried bytes are
/// this wrapper's.
#[derive(Clone, Debug, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub struct PalwFpV5TailV1 {
    pub images: Vec<PalwGenImageInputRefV1>,
    pub source: Option<PalwGenSourceRefV1>,
}

/// **FP Job V5**: an FP Job V4, unchanged, and the job's images and source.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwFreePromptJobV5 {
    /// The FP Job V4 the job embeds: version 7, its `DecodeConfigV4` present.
    pub v4: PalwFreePromptJobV4,
    /// One image per image slot of the class, in slot order: 0..=16 (none for a class without slots).
    pub images: Vec<PalwGenImageInputRefV1>,
    /// The source ids' reference, exactly when the class reads a source (RFC-0003 §II.2.2).
    pub source: Option<PalwGenSourceRefV1>,
}

impl borsh::BorshSerialize for PalwFreePromptJobV5 {
    fn serialize<W: Write>(&self, writer: &mut W) -> std::io::Result<()> {
        let v4 = borsh::to_vec(&self.v4)?;
        borsh::BorshSerialize::serialize(&PALW_FP_V5_VERSION, writer)?;
        // The V4 job's bytes after its version word (a u16): every V3 field, then its decode rules.
        writer.write_all(&v4[2..])?;
        borsh::BorshSerialize::serialize(&self.images, writer)?;
        borsh::BorshSerialize::serialize(&self.source, writer)
    }
}

impl borsh::BorshDeserialize for PalwFreePromptJobV5 {
    fn deserialize_reader<R: Read>(reader: &mut R) -> std::io::Result<Self> {
        let version: u16 = borsh::BorshDeserialize::deserialize_reader(reader)?;
        if version != PALW_FP_V5_VERSION {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, format!("version {version} is not FP Job V5")));
        }
        // What follows is a V4 job's bytes after its version word: read them as the V4 job they are,
        // with the V4 lane's own decoder, by putting the V4 version word back in front.
        let v4_word = PALW_FP_V4_VERSION.to_le_bytes();
        let mut chained = (&v4_word[..]).chain(&mut *reader);
        let v4 = PalwFreePromptJobV3::deserialize_reader(&mut chained)?;
        let images = borsh::BorshDeserialize::deserialize_reader(reader)?;
        let source = borsh::BorshDeserialize::deserialize_reader(reader)?;
        Ok(Self { v4, images, source })
    }
}

/// **`fp_job_id_v5`**: `H64(key "misaka-palw/fp-v5/job-id/v1", le64(|bytes|) ‖ bytes)` over the
/// whole borsh — the V3/V4 ids' construction under V5's own key.
pub fn fp_job_id_v5(job: &PalwFreePromptJobV5) -> Hash64 {
    fp_job_id_v5_bytes(&borsh::to_vec(job).expect("an FP Job V5 is borsh-serializable"))
}

/// [`fp_job_id_v5`] of a V5 job as the lane carries it (a [`PalwFreePromptJobV3`] at version 8, its
/// images the tail) — the same bytes, so the same id; the lane's `fp_job_id_v3` dispatches here.
pub fn fp_job_id_v5_carried(job: &PalwFreePromptJobV3) -> Hash64 {
    fp_job_id_v5_bytes(&borsh::to_vec(job).expect("a free-prompt job is borsh-serializable"))
}

fn fp_job_id_v5_bytes(bytes: &[u8]) -> Hash64 {
    let mut state = blake2b_simd::Params::new().hash_length(64).key(PALW_FP_V5_DOMAIN_JOB_ID).to_state();
    state.update(&(bytes.len() as u64).to_le_bytes());
    state.update(bytes);
    let mut out = [0u8; 64];
    out.copy_from_slice(state.finalize().as_bytes());
    Hash64::from_bytes(out)
}

/// Why a V5 job, or a job's version for a class, is refused — each by name.
#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
pub enum PalwFpV5Error {
    #[error(
        "FP Job V5 is not admitted here — it arms at a height through Params::palw_fp_job_v5, and this network is below it (or has none)"
    )]
    NotArmed,
    #[error("the job is version {version}, not FP Job V5 (version 8) with its images")]
    NotAV5Job { version: u16 },
    #[error(
        "a V5 job embeds an FP Job V4 (version 7, its decode rules present); this one embeds version {version} (decode rules present: {decode_present})"
    )]
    NotAV4Job { version: u16, decode_present: bool },
    #[error("the embedded V4 job is refused as V4 refuses it: {0}")]
    V4(PalwFpV3Error),
    #[error("a V5 job carries at most 16 images, and images or a source; this one carries {0} images and no source")]
    ImageCount(usize),
    #[error(transparent)]
    Images(PalwGenJobImageErrorV1),
    #[error("{job} is not this class's job: a class with image slots takes FP Job V5 only, and a class without them FP Job V4 only")]
    JobVersionNotOffered { job: &'static str },
    #[error(
        "the prompt ({prompt}) and the decode budget ({decode}) need {need} positions; the class's text stage runs at most {max_trip}"
    )]
    ContextExceeded { prompt: u32, decode: u32, need: u64, max_trip: u32 },
    #[error("the job names class {0}, which is no generative class on this chain")]
    UnknownClass(Hash64),
    #[error("the job names a generative class of profile {profile}, which is not a text class: an FP job runs a text class only")]
    NotATextClass { profile: u8 },
    #[error("the job's tokenizer {job} is not the class's {class}")]
    TokenizerNotTheClasss { job: Hash64, class: Hash64 },
    #[error("the class reads a source: {0}")]
    Source(&'static str),
    #[error("the job carries {tokens} source ids; the class takes 1..={max}")]
    SourceLength { tokens: u32, max: u32 },
    #[error("the prompt does not start with the class's forced prefix (RFC-0003 §II.2.2)")]
    PromptPrefix,
    /// **RFC-0001 P3: a version-8 commitment whose output root, schedule root or data-availability trio is not the pipeline claim
    /// convention** ([`palw_fp_v5_check_commitment_conventions_v1`]), by field.
    #[error(
        "a V5 commitment's {0} is not the pipeline claim convention (RFC-0001 P3: output_root 0, schedule_root 0, trace_manifest_root 0, trace_chunk_count 1, trace_retention_daa 0)"
    )]
    CommitmentNotCanonical(&'static str),
}

/// **RFC-0001 P3 — the data-availability trio and the output root of a version-8 claim, decided before the V5 fold exists.**
///
/// `vlm::commitment_of` set `output_root = 0`, one trace chunk, no manifest and a caller-chosen retention, and recorded the lane's
/// retention for V5 as unspecified. It is now the convention every pipeline claim already follows (RFC-0003 §I.4.2 for the tensor
/// claim, line "`trace_manifest_root`, `trace_chunk_count`, `trace_retention_daa` | zero, `1`, zero (as Phase F's pipeline claims)"):
///
/// | field | value | why |
/// |---|---|---|
/// | `output_root` | zero | a text pipeline's canonical output IS its committed generated ids, which the execution root hashes (RFC-0003 §I.3.3: "a text claim commits no `output_root`") |
/// | `schedule_root` | zero | a V2 call schedule describes a text decoder's calls; a pipeline claim's work is the step space under `trace_root` |
/// | `trace_manifest_root` | zero | no retained-event manifest: the units open step leaves and nodes under `trace_root` (PALW-GEN) |
/// | `trace_chunk_count` | one | the lane's stateless rule requires non-zero; a pipeline's retention is one object |
/// | `trace_retention_daa` | zero | the chain derives it as `accepted_daa` + the minimum retention, as it does for a tensor claim; a stated deadline would be a promise nothing reads, and one encoding per behaviour refuses it |
///
/// Everything else in the commitment (`trace_root` the step root, `execution_root` the binding's, `work_leaves` the price, the
/// executed count and stop reason the V4 job's decoder derives) is unchanged.
pub const PALW_FP_V5_TRACE_CHUNK_COUNT_V1: u32 = 1;

/// **Check a version-8 commitment against the convention** ([`PALW_FP_V5_TRACE_CHUNK_COUNT_V1`]'s table). Total over the fields it
/// names; asks nothing about the rest.
pub fn palw_fp_v5_check_commitment_conventions_v1(
    c: &crate::palw_freeprompt_v3::PalwFreePromptCommitmentV3,
) -> Result<(), PalwFpV5Error> {
    let zero = Hash64::default();
    if c.output_root != zero {
        return Err(PalwFpV5Error::CommitmentNotCanonical("output_root"));
    }
    if c.schedule_root != zero {
        return Err(PalwFpV5Error::CommitmentNotCanonical("schedule_root"));
    }
    if c.trace_manifest_root != zero {
        return Err(PalwFpV5Error::CommitmentNotCanonical("trace_manifest_root"));
    }
    if c.trace_chunk_count != PALW_FP_V5_TRACE_CHUNK_COUNT_V1 {
        return Err(PalwFpV5Error::CommitmentNotCanonical("trace_chunk_count"));
    }
    if c.trace_retention_daa != 0 {
        return Err(PalwFpV5Error::CommitmentNotCanonical("trace_retention_daa"));
    }
    Ok(())
}

/// **The version-8 commitment a producer builds**, canonical by construction: the V5 job as the lane carries it, the binding's step
/// root and execution root and leaf count, the executed count and stop reason the job's decoder derives, and the convention's output
/// root and DA trio. A producer that builds it this way cannot fail [`palw_fp_v5_check_commitment_conventions_v1`].
pub fn palw_fp_v5_canonical_commitment_v1(
    job: &PalwFreePromptJobV5,
    trace_root: Hash64,
    execution_root: Hash64,
    work_leaves: u64,
    generated_tokens: u32,
) -> crate::palw_freeprompt_v3::PalwFreePromptCommitmentV3 {
    let carried = job.into_carried();
    let facts = crate::palw_fp_execution_v3::palw_fp_run_facts_for_executed_v1(&carried, generated_tokens);
    crate::palw_freeprompt_v3::PalwFreePromptCommitmentV3 {
        job: carried,
        trace_root,
        output_root: Hash64::default(),
        schedule_root: Hash64::default(),
        execution_root,
        decode_tokens_executed: facts.decode_tokens_executed,
        stop_reason: facts.stop_reason,
        work_leaves,
        trace_manifest_root: Hash64::default(),
        trace_chunk_count: PALW_FP_V5_TRACE_CHUNK_COUNT_V1,
        trace_retention_daa: 0,
    }
}

impl PalwFreePromptJobV5 {
    /// **A V5 job as the lane carries it**: its V4 job at version 8, the images its tail — the same
    /// bytes as this wrapper's.
    pub fn into_carried(&self) -> PalwFreePromptJobV3 {
        let tail = PalwFpV5TailV1 { images: self.images.clone(), source: self.source };
        PalwFreePromptJobV3 {
            version: PALW_FP_V5_VERSION,
            tail: Some(crate::palw_freeprompt_v3::PalwFpJobTailV1::V5(tail)),
            ..self.v4.clone()
        }
    }

    /// **The V5 job a carried job is**, if it is one: version 8, its decode rules and its tail present.
    pub fn from_carried(job: &PalwFreePromptJobV3) -> Result<Self, PalwFpV5Error> {
        let tail = match &job.tail {
            Some(crate::palw_freeprompt_v3::PalwFpJobTailV1::V5(tail)) => Some(tail.clone()),
            _ => None,
        };
        let Some(tail) = tail.filter(|_| job.version == PALW_FP_V5_VERSION && job.decode.is_some()) else {
            return Err(PalwFpV5Error::NotAV5Job { version: job.version });
        };
        Ok(Self {
            v4: PalwFreePromptJobV3 { version: PALW_FP_V4_VERSION, tail: None, ..job.clone() },
            images: tail.images,
            source: tail.source,
        })
    }

    /// **The V5 job's own shape**: its embedded job is an FP Job V4 that V4's own rules admit, and it
    /// carries at most 16 images, and images or a source (never neither: that job is V4's).
    pub fn validate_shape_v1(&self) -> Result<(), PalwFpV5Error> {
        if self.v4.version != PALW_FP_V4_VERSION || self.v4.decode.is_none() {
            return Err(PalwFpV5Error::NotAV4Job { version: self.v4.version, decode_present: self.v4.decode.is_some() });
        }
        PalwFpDecodeRulesV1::Active.check_job(&self.v4).map_err(PalwFpV5Error::V4)?;
        if self.images.len() > PALW_FP_V5_MAX_IMAGES || (self.images.is_empty() && self.source.is_none()) {
            return Err(PalwFpV5Error::ImageCount(self.images.len()));
        }
        Ok(())
    }
}

/// **Does a class read a source** (RFC-0003 §II.2.2)? Its offer names one.
pub fn palw_gen_class_reads_source_v1(offers: &PalwGenOffersV1) -> bool {
    offers.max_source_tokens > 0
}

/// **OQ14 (extended by §II.2.2): which job a class takes** — a class with image slots or a source
/// takes FP Job V5 only, and a class with neither FP Job V4 only. `v5` says which one is offered.
pub fn palw_fp_job_version_offered_v1(offers: &PalwGenOffersV1, v5: bool) -> Result<(), PalwFpV5Error> {
    let takes_v5 = !offers.images.is_empty() || palw_gen_class_reads_source_v1(offers);
    match (takes_v5, v5) {
        (false, false) | (true, true) => Ok(()),
        (true, false) => Err(PalwFpV5Error::JobVersionNotOffered { job: "FP Job V4" }),
        (false, true) => Err(PalwFpV5Error::JobVersionNotOffered { job: "FP Job V5" }),
    }
}

/// **A prompt's head against the class's forced prefix** (RFC-0003 §II.2.2): where the ids are held
/// (acceptance on `PublicDa`, the worker, a seat), the prompt must start with the class's
/// `forced_prompt_prefix`.
pub fn palw_fp_v5_prompt_head_admitted_v1(offers: &PalwGenOffersV1, prompt_ids: &[u32]) -> Result<(), PalwFpV5Error> {
    if prompt_ids.starts_with(&offers.forced_prompt_prefix) { Ok(()) } else { Err(PalwFpV5Error::PromptPrefix) }
}

/// **A V5 job for a vision-language class** — everything checkable without chain state: the fence
/// (`armed`: `Params::palw_fp_job_v5` in force at the judged height), the job's shape, the class
/// taking V5 (OQ14), the images one per slot at its size (PALW-GEN-11), and the prompt with the
/// decode budget within the class's text stage (`prompt + decode − 1 ≤ max_trip`).
pub fn palw_fp_job_v5_admitted_v1(
    job: &PalwFreePromptJobV5,
    offers: &PalwGenOffersV1,
    text_max_trip: u32,
    armed: bool,
) -> Result<(), PalwFpV5Error> {
    if !armed {
        return Err(PalwFpV5Error::NotArmed);
    }
    job.validate_shape_v1()?;
    palw_fp_job_version_offered_v1(offers, true)?;
    palw_gen_job_images_admitted_v1(offers, &job.images).map_err(PalwFpV5Error::Images)?;
    match (palw_gen_class_reads_source_v1(offers), &job.source) {
        (false, None) => {}
        (false, Some(_)) => return Err(PalwFpV5Error::Source("a source on a job of a class that reads none")),
        (true, None) => return Err(PalwFpV5Error::Source("no source on a job of a class that reads one")),
        (true, Some(source)) => {
            if source.tokens == 0 || source.tokens > offers.max_source_tokens {
                return Err(PalwFpV5Error::SourceLength { tokens: source.tokens, max: offers.max_source_tokens });
            }
        }
    }
    if (job.v4.prompt_tokens as usize) < offers.forced_prompt_prefix.len() {
        return Err(PalwFpV5Error::PromptPrefix);
    }
    let (prompt, decode) = (job.v4.prompt_tokens, job.v4.decode_token_limit);
    let need = (prompt as u64 + decode as u64).saturating_sub(1);
    if need > text_max_trip as u64 {
        return Err(PalwFpV5Error::ContextExceeded { prompt, decode, need, max_trip: text_max_trip });
    }
    Ok(())
}

/// **A V5 claim's class, resolved against the generative registry** (RFC-0003 §II.2.1): `row` is the
/// `gen_classes` row the job's `class_id` names (`PalwChainStateV2::gen_class_v1`). The row must
/// exist and be a text class, the job must use its tokenizer, and the class must admit the job
/// ([`palw_fp_job_v5_admitted_v1`] under the row's offers and text stage). What the lane then charges
/// is OQ13's, pending user confirmation — nothing here prices a job.
pub fn palw_fp_v5_resolve_class_v1<'a>(
    job: &PalwFreePromptJobV5,
    row: Option<&'a crate::palw_gen_class_v1::PalwGenClassRecordV1>,
    armed: bool,
) -> Result<&'a crate::palw_gen_class_v1::PalwGenClassRecordV1, PalwFpV5Error> {
    if !armed {
        return Err(PalwFpV5Error::NotArmed);
    }
    let row = row.ok_or(PalwFpV5Error::UnknownClass(job.v4.class_id))?;
    let text_max_trip = row.text_max_trip.ok_or(PalwFpV5Error::NotATextClass { profile: row.profile })?;
    if job.v4.tokenizer_id != row.tokenizer_id {
        return Err(PalwFpV5Error::TokenizerNotTheClasss { job: job.v4.tokenizer_id, class: row.tokenizer_id });
    }
    palw_fp_job_v5_admitted_v1(job, &row.class.offers, text_max_trip, armed)?;
    Ok(row)
}

/// **The image stages' price in prompt tokens** (OQ13's recommendation, PENDING USER CONFIRMATION):
/// the sum of the class's per-slot `token_equivalents` — one image per slot, so every job of the
/// class pays the same.
pub fn palw_fp_v5_image_tokens_v1(offers: &PalwGenOffersV1) -> u64 {
    offers.images.iter().map(|slot| slot.token_equivalents as u64).sum()
}

/// **The image stages' charge** (OQ13's recommendation, PENDING USER CONFIRMATION): the image tokens
/// at the job's per-token price.
pub fn palw_fp_v5_image_charge_v1(offers: &PalwGenOffersV1, per_token_price: u64) -> u128 {
    palw_fp_v5_image_tokens_v1(offers) as u128 * per_token_price as u128
}

/// **The source's price in prompt tokens** (RFC-0003 open question 15's recommendation, PENDING USER
/// CONFIRMATION with 13): a V5 job's source ids are charged as prompt tokens — their count, and never
/// below the class's `source_token_floor`; 0 for a job without a source.
pub fn palw_fp_v5_source_tokens_v1(offers: &PalwGenOffersV1, job: &PalwFreePromptJobV5) -> u64 {
    job.source.map_or(0, |s| (s.tokens as u64).max(offers.source_token_floor as u64))
}

/// **Every input a V5 job is charged for, in prompt tokens** (open questions 13 and 15, PENDING USER
/// CONFIRMATION): the images' token equivalents and the source's count.
pub fn palw_fp_v5_input_tokens_v1(offers: &PalwGenOffersV1, job: &PalwFreePromptJobV5) -> u64 {
    palw_fp_v5_image_tokens_v1(offers).saturating_add(palw_fp_v5_source_tokens_v1(offers, job))
}

/// **Every input's charge** (open questions 13 and 15, PENDING USER CONFIRMATION): the input tokens
/// at the job's per-token price.
pub fn palw_fp_v5_input_charge_v1(offers: &PalwGenOffersV1, job: &PalwFreePromptJobV5, per_token_price: u64) -> u128 {
    palw_fp_v5_input_tokens_v1(offers, job) as u128 * per_token_price as u128
}

/// **A V5 payload against its class** (the acceptance layer's composition past `palw_fp_job_v5`): the
/// stateless rules ([`palw_fp_v5_validate_payload_v1`]), the job the class's
/// ([`palw_fp_v5_resolve_class_v1`]), and — where the prompt's ids ride the payload (`PublicDa`, the
/// user's prompt mode: `palw_fp_carried_prompt_ids_v1`) — the prompt starting with the class's forced
/// prefix (RFC-0003 §II.2.2). A payload never carries the source's ids: they travel as the images'
/// bytes do, so V4's payload, its checks and the fold's prompt accounting read the prompt alone.
#[allow(clippy::too_many_arguments)]
pub fn palw_fp_v5_accept_payload_v1<'a>(
    payload: &crate::palw_freeprompt_v3::PalwFpCommitmentTxPayloadV3,
    row: Option<&'a crate::palw_gen_class_v1::PalwGenClassRecordV1>,
    network_domain: Hash64,
    panel_da_armed: bool,
    max_step_leaf_count: u64,
    ruleset_caps: Option<(u32, u32)>,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    armed: bool,
) -> Result<(PalwFreePromptJobV5, &'a crate::palw_gen_class_v1::PalwGenClassRecordV1), PalwFpV5Error> {
    let job = palw_fp_v5_validate_payload_v1(
        payload,
        network_domain,
        panel_da_armed,
        max_step_leaf_count,
        ruleset_caps,
        prompt_ids_form,
        armed,
    )?;
    let row = palw_fp_v5_resolve_class_v1(&job, row, armed)?;
    // **RFC-0001 §A.3's unit, RFC-0003 §I.3's convention.** The temperature, the frequency and
    // presence penalties and the logit bias are measured in the class's logit units (Q24), and a
    // generative text class's logits are in whatever unit its lowerer calibrated until the fence that
    // guarantees Q24 by construction opens the lane to classes registered past it: until then a V5 job
    // is offered the unit-free controls only (greedy, the repeat penalty, stop sequences, constraints).
    crate::palw_freeprompt_v3::palw_fp_decode_controls_offered_v1(&job.v4, false).map_err(PalwFpV5Error::V4)?;
    let carried = crate::palw_freeprompt_v3::palw_fp_carried_prompt_ids_v1(&job.v4, &payload.prompt_token_ids);
    if !carried.is_empty() {
        palw_fp_v5_prompt_head_admitted_v1(&row.class.offers, &carried)?;
    }
    Ok((job, row))
}

/// **The entry a drill arms FP Job V5 with** (`--palw-drill-fp-v5-at`,
/// [`crate::config::drill::palw_drill_fp_v5_at_v1`]). In NO testnet-12 flag-day list: dormant on
/// every network.
///
/// Its `set` also writes the bundle's mirror of the height (`Params::sync_palw_gen_v1` mirrors `palw_fp_job_v5` beside the
/// generative fence's in-flight caps, because the fold's tensor branch holds only the bundle) — a setter that left it unwritten
/// would arm a ruleset `validate_palw_v2` refuses ("disagrees with the V2 bundle's mirror").
pub const PALW_DRILL_FP_V5_ENTRY: PalwPostLaunchFenceV1 = PalwPostLaunchFenceV1 {
    name: "palw_fp_job_v5",
    set: |params, at| {
        params.palw_fp_job_v5 = at;
        params.sync_palw_gen_v1();
    },
};

/// The drill's one-entry list.
pub const PALW_DRILL_FP_V5_FENCES_V1: &[PalwPostLaunchFenceV1] = &[PALW_DRILL_FP_V5_ENTRY];

impl Params {
    /// `palw_fp_job_v5`, resolved: `Some` only on a `ConsensusV2` network that armed it.
    pub fn palw_fp_job_v5_fence(&self) -> Option<ForkActivation> {
        match (&self.palw_consensus_mode, self.palw_fp_job_v5) {
            (PalwConsensusMode::ConsensusV2(_), Some(fence)) => Some(fence),
            _ => None,
        }
    }

    pub fn palw_fp_job_v5_active_at(&self, daa_score: u64) -> bool {
        self.palw_fp_job_v5_fence().is_some_and(|f| f.is_active(daa_score))
    }

    /// **FP Job V5's own refusals**, asked by [`Params::validate_palw_v2`]: a `ConsensusV2` rule, over
    /// `palw_gen_v1` (a vision-language class is a generative class) and `palw_fp_decode_rules` (V5
    /// embeds V4), both in force at or below it. A `Some(never())` value is dormant and passes.
    pub fn validate_palw_fp_job_v5_v1(&self) -> Result<(), PalwModeV2Error> {
        let Some(fence) = self.palw_fp_job_v5.filter(|f| *f != ForkActivation::never()) else { return Ok(()) };
        if !matches!(self.palw_consensus_mode, PalwConsensusMode::ConsensusV2(_)) {
            return Err(PalwModeV2Error::Invalid("palw_fp_job_v5 is armed on a network that is not ConsensusV2"));
        }
        let at_or_below =
            |other: Option<ForkActivation>| other.is_some_and(|o| o != ForkActivation::never() && o.daa_score() <= fence.daa_score());
        if !at_or_below(self.palw_gen_v1.map(|g| g.activation)) {
            return Err(PalwModeV2Error::Invalid(
                "palw_fp_job_v5 needs palw_gen_v1 in force at or below it: a vision-language class is a generative class",
            ));
        }
        if !at_or_below(self.palw_fp_decode_rules) {
            return Err(PalwModeV2Error::Invalid(
                "palw_fp_job_v5 needs palw_fp_decode_rules in force at or below it: V5 embeds FP Job V4",
            ));
        }
        Ok(())
    }
}

/// **A V5 commitment's stateless rules** (the V5 twin of the extraction walk's
/// `validate_stateless_under_ruleset_v4`): the fence, the carried job a V5 job of the right shape,
/// and every commitment rule of FP Job V4 applied to its V4 view — the same commitment with the V4 job
/// the V5 job embeds — past V4's fence. The signature is the payload's own
/// (`validate_signature_v3` over the V5 claim id), checked by the caller as for V4.
#[allow(clippy::too_many_arguments)]
pub fn palw_fp_v5_validate_payload_v1(
    payload: &crate::palw_freeprompt_v3::PalwFpCommitmentTxPayloadV3,
    network_domain: Hash64,
    panel_da_armed: bool,
    max_step_leaf_count: u64,
    ruleset_caps: Option<(u32, u32)>,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    armed: bool,
) -> Result<PalwFreePromptJobV5, PalwFpV5Error> {
    if !armed {
        return Err(PalwFpV5Error::NotArmed);
    }
    let v5 = PalwFreePromptJobV5::from_carried(&payload.commitment.job)?;
    v5.validate_shape_v1()?;
    let mut view = payload.clone();
    view.commitment.job = v5.v4.clone();
    view.validate_stateless_under_ruleset_v4(
        network_domain,
        panel_da_armed,
        max_step_leaf_count,
        ruleset_caps,
        prompt_ids_form,
        PalwFpDecodeRulesV1::Active,
    )
    .map_err(PalwFpV5Error::V4)?;
    Ok(v5)
}

/// **[`palw_fp_v5_validate_payload_v1`] and the pipeline claim convention** (RFC-0001 P3): the door the V5 fold calls. A separate
/// door, not an edit of the first, so FP Job V4's validators and the existing door stay byte for byte what they were; wiring it into
/// the fold is the fold's own step and waits for the lane that builds it (and its fence).
#[allow(clippy::too_many_arguments)]
pub fn palw_fp_v5_validate_payload_canonical_v1(
    payload: &crate::palw_freeprompt_v3::PalwFpCommitmentTxPayloadV3,
    network_domain: Hash64,
    panel_da_armed: bool,
    max_step_leaf_count: u64,
    ruleset_caps: Option<(u32, u32)>,
    prompt_ids_form: crate::palw_prompt_ids_v1::PalwPromptIdsFormV1,
    armed: bool,
) -> Result<PalwFreePromptJobV5, PalwFpV5Error> {
    let job = palw_fp_v5_validate_payload_v1(
        payload,
        network_domain,
        panel_da_armed,
        max_step_leaf_count,
        ruleset_caps,
        prompt_ids_form,
        armed,
    )?;
    palw_fp_v5_check_commitment_conventions_v1(&payload.commitment)?;
    Ok(job)
}
