//! **Where a class registration stopped, named so an operator does not have to guess.**
//!
//! `model add` used to construct a `ClassRegistered` and print "ok" after the carrier left the
//! mempool. The 2M Qwen row showed why that is not enough: constructed and submitted can both be
//! true while the processor refuses `GLOBAL_WINDOW_EXCEEDED`, or the mempool can accept a carrier
//! that never folds into a registry row. The pipeline is five distinct facts:
//!
//! constructed → submitted → accepted (mempool/validate) → included (a block) → folded (class table)
//!
//! A hold always carries a machine token ([`PalwModelRegistrationCodeV1`]) and a sentence. Preflight
//! uses the same tokens the processor's admission gate returns, plus the positive checks a person
//! wants to see before they spend a fee (`FitsGlobalWindow`, `CourtCovered`).

use crate::Hash64;
use crate::config::params::Params;
use crate::palw_class_admission_v2::{PalwClassAdmissionError, palw_admission_shape_at_v1, verify_class_admission_v9};
use crate::palw_e2e_adjudicability::PalwE2eFamilyV1;
use crate::palw_mode_v2::PalwConsensusParamsV2;
use crate::palw_model_fit_v1::{PalwFitVerdictV1, PalwFitWallV1, palw_model_fit_v2};
use crate::palw_state_v2::PalwConsensusObjectV2;

/// Identity of a constructed registration object: keyed BLAKE2b-512 of its borsh bytes.
pub fn palw_registration_object_id_v1(bytes: &[u8]) -> Hash64 {
    kaspa_hashes::blake2b_512_keyed(b"PALW_MODEL_REG_V1", bytes)
}

/// **The class a lifecycle carrier registers**: `(class_id, artifact_root)` exactly when `tx` rides
/// the lifecycle subnetwork (0x4b) at the wire version the fold reads and its one object is a
/// `ClassRegistered` or a `ClassRegisteredTirV1`; `None` for any other transaction.
///
/// Read off the carrier's own bytes, the way the fold reads them
/// (`palw_lifecycle_objects_from_accepted_txs_v2`), so a registration status and the transition
/// cannot disagree about what a transaction carried.
pub fn palw_registration_carrier_class_v1(tx: &crate::tx::Transaction) -> Option<(Hash64, Hash64)> {
    match palw_registration_carrier_object_v1(tx)? {
        PalwConsensusObjectV2::ClassRegistered { class_id, artifact_root, .. }
        | PalwConsensusObjectV2::ClassRegisteredTirV1 { class_id, artifact_root, .. } => Some((class_id, artifact_root)),
        _ => None,
    }
}

/// **The `ClassRegistered` (or `ClassRegisteredTirV1`) a lifecycle carrier carries, whole** — [`palw_registration_carrier_class_v1`]'s
/// read, keeping the object: what a node re-asks its preflight about when a MINED carrier wrote no
/// row (`REGISTRATION_DROPPED`, testnet-12 lifecycle audit T12-030). `None` for any other
/// transaction.
pub fn palw_registration_carrier_object_v1(tx: &crate::tx::Transaction) -> Option<PalwConsensusObjectV2> {
    use crate::palw_lifecycle_objects_v2::{PALW_LIFECYCLE_TX_VERSION_V2, PalwLifecycleTxPayloadV2};
    if tx.subnetwork_id != crate::subnets::SUBNETWORK_ID_PALW_LIFECYCLE {
        return None;
    }
    let payload: PalwLifecycleTxPayloadV2 = borsh::from_slice(&tx.payload).ok()?;
    if payload.version != PALW_LIFECYCLE_TX_VERSION_V2 {
        return None;
    }
    // An IR registration (`ClassRegisteredTirV1`, RFC-0002 Phase F) rides the same carrier and writes the same class row: the
    // registration status and the dropped-carrier diagnosis read it exactly as they read a legacy one (before this they
    // answered `REGISTRATION_NOT_INCLUDED` / an unknown verdict for every IR carrier, mined or dropped).
    matches!(payload.object, PalwConsensusObjectV2::ClassRegistered { .. } | PalwConsensusObjectV2::ClassRegisteredTirV1 { .. })
        .then_some(payload.object)
}

/// **How many DAA past a carrier's acceptance the fold of its accepting block has certainly run** —
/// the margin before a mined carrier with no class row is read as dropped. A carrier's output enters
/// the virtual UTXO set when a block carrying it is added, and its row is written when a CHAIN block
/// accepts that block and folds it (about one block later); inside that interval the row is merely
/// not written YET.
pub const PALW_REGISTRATION_DROP_SETTLE_DAA_V1: u64 = 2;

/// **A lifecycle carrier's change: its output 0** (`build_palw_lifecycle_tx`: one input, one change
/// output back to the funding script). What a node looks up in its virtual UTXO set to learn that a
/// carrier was mined.
pub fn palw_lifecycle_carrier_change_v1(carrier: crate::tx::TransactionId) -> crate::tx::TransactionOutpoint {
    crate::tx::TransactionOutpoint::new(carrier, 0)
}

/// **Is this registration carrier one the chain mined and the processor DROPPED?** `Some(the DAA it
/// was accepted at)` exactly when it is out of the mempool, wrote no class row, its change
/// ([`palw_lifecycle_carrier_change_v1`]) stands in the virtual UTXO set at `change_accepted_daa`, and
/// the virtual is [`PALW_REGISTRATION_DROP_SETTLE_DAA_V1`] past it — so the fold of its accepting
/// block has run. Inside that margin a mined carrier is merely not folded yet (review of T12-030);
/// with its change spent (or never mined) there is no evidence either way and the answer is `None`.
/// Node policy (`getPalwModelRegistrationStatus`); nothing that folds calls it.
pub fn palw_registration_carrier_dropped_v1(
    in_mempool: bool,
    row_written: bool,
    change_accepted_daa: Option<u64>,
    virtual_daa: u64,
) -> Option<u64> {
    if in_mempool || row_written {
        return None;
    }
    let mined = change_accepted_daa?;
    (virtual_daa >= mined.saturating_add(PALW_REGISTRATION_DROP_SETTLE_DAA_V1)).then_some(mined)
}

/// **Which class-table row a carrier wrote — inclusion read off the chain's own record.**
///
/// The class table stamps every row with the DAA of the chain block whose fold wrote it
/// (`registered_daa`), and that chain block's acceptance data records which transactions it
/// accepted. A carrier wrote a row exactly when the chain block at the row's DAA accepted it and
/// the object it carries is that row's `ClassRegistered` (same class, same root). `carrier` is the
/// transaction as the chain block at `accepting_daa` accepted it — the caller reads the acceptance
/// record for it, never the mempool.
///
/// `getPalwModelRegistrationStatus` had no such door (testnet-12, 2026-09-23). It found a row only
/// by class id, and about a carrier it asked the mempool alone — and a carrier leaves the mempool
/// when it is MINED as well as when it is dropped. So `misaka model registration <txid>`, which
/// sends the carrier id in the class-id slot, read `accepted` while the carrier waited and then
/// `submitted` / `REGISTRATION_NOT_INCLUDED` once two blocks had carried it and its Candidate row
/// stood in the registry.
pub fn palw_registration_row_written_by_v1<'a>(
    carrier: &crate::tx::Transaction,
    accepting_daa: u64,
    rows: &'a [crate::palw_state_v2::PalwClassRowV2],
) -> Option<&'a crate::palw_state_v2::PalwClassRowV2> {
    let (class_id, artifact_root) = palw_registration_carrier_class_v1(carrier)?;
    rows.iter().find(|row| row.class_id == class_id && row.artifact_root == artifact_root && row.registered_daa == accepting_daa)
}

/// Where the registration currently sits. Later stages imply earlier ones, except that
/// `Accepted` can fail without ever becoming `Included`.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum PalwModelRegistrationStageV1 {
    Constructed,
    Submitted,
    Accepted,
    Included,
    Folded,
}

impl PalwModelRegistrationStageV1 {
    pub const fn name(self) -> &'static str {
        match self {
            Self::Constructed => "constructed",
            Self::Submitted => "submitted",
            Self::Accepted => "accepted",
            Self::Included => "included",
            Self::Folded => "folded",
        }
    }
}

/// Stable CLI/RPC token. Display of [`PalwClassAdmissionError`] stays the human sentence.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum PalwModelRegistrationCodeV1 {
    ModelAlreadyRegistered,
    ArtifactRootMismatch,
    CourtKernelUncovered,
    GlobalWindowExceeded,
    FamilyFenceClosed,
    NotEndToEndCertified,
    RegistrationNotIncluded,
    ReadySeatsInsufficient,
    FitsGlobalWindow,
    CourtCovered,
    KimiFamilyNeedsItsFence,
    AdmissionOk,
    /// Past `palw_offence_attribution` the class is not attributable
    /// (`palw_registration_attribution_v1`'s `Class` arm): the processor drops the registration.
    ClassNotAttributable,
    /// The carrier was MINED (its output stands in the virtual UTXO set) and no class row was
    /// written: the processor dropped the object. The fee is spent; re-sending the same object
    /// pays again for the same drop (testnet-12 lifecycle audit T12-030).
    RegistrationDropped,
}

impl PalwModelRegistrationCodeV1 {
    pub const fn code(self) -> &'static str {
        match self {
            Self::ModelAlreadyRegistered => "MODEL_ALREADY_REGISTERED",
            Self::ArtifactRootMismatch => "ARTIFACT_ROOT_MISMATCH",
            Self::CourtKernelUncovered => "COURT_KERNEL_UNCOVERED",
            Self::GlobalWindowExceeded => "GLOBAL_WINDOW_EXCEEDED",
            Self::FamilyFenceClosed => "FAMILY_FENCE_CLOSED",
            Self::NotEndToEndCertified => "NOT_END_TO_END_CERTIFIED",
            Self::RegistrationNotIncluded => "REGISTRATION_NOT_INCLUDED",
            Self::ReadySeatsInsufficient => "READY_SEATS_INSUFFICIENT",
            Self::FitsGlobalWindow => "FitsGlobalWindow",
            Self::CourtCovered => "CourtCovered",
            Self::KimiFamilyNeedsItsFence => "KimiFamilyNeedsItsFence",
            Self::AdmissionOk => "ADMISSION_OK",
            Self::ClassNotAttributable => "CLASS_NOT_ATTRIBUTABLE",
            Self::RegistrationDropped => "REGISTRATION_DROPPED",
        }
    }

    pub const fn message(self) -> &'static str {
        match self {
            Self::ModelAlreadyRegistered => "this class id is already on the chain",
            Self::ArtifactRootMismatch => "the artifact roots to a different value than the class would register",
            Self::CourtKernelUncovered => "the class reaches a kernel this court's catalog does not cover",
            Self::GlobalWindowExceeded => "n_ctx × layers exceeds the global enumeration window",
            Self::FamilyFenceClosed => "the class needs a family fence this network has not armed",
            Self::NotEndToEndCertified => "the class asks for weight but no end-to-end certified family covers it",
            Self::RegistrationNotIncluded => "the carrier left this node but no block has folded the object",
            Self::ReadySeatsInsufficient => "ready seats are below the class's requiredReadySeats",
            Self::FitsGlobalWindow => "the declared shape fits the global enumeration window",
            Self::CourtCovered => "every kernel the graph reaches is in this court's catalog",
            Self::KimiFamilyNeedsItsFence => "the class reaches a Kimi K3 kernel and the Kimi family fence is closed",
            Self::AdmissionOk => "the processor's admission gate would admit this registration",
            Self::ClassNotAttributable => {
                "past palw_offence_attribution the class is not attributable (canonical job, logits head, Kimi kernel or prompt form)"
            }
            Self::RegistrationDropped => "the carrier was mined, and the processor dropped the object: no class row was written",
        }
    }

    pub fn from_admission(err: &PalwClassAdmissionError) -> Self {
        match err {
            PalwClassAdmissionError::CoverageGap => Self::CourtKernelUncovered,
            PalwClassAdmissionError::NotEndToEndCertified { .. } => Self::NotEndToEndCertified,
            PalwClassAdmissionError::KimiFamilyNeedsItsFence => Self::KimiFamilyNeedsItsFence,
            PalwClassAdmissionError::TokenLiftNeedsItsFence | PalwClassAdmissionError::HeldMapNeedsItsFence => {
                Self::FamilyFenceClosed
            }
            PalwClassAdmissionError::Profile(s) if s.contains("enumeration past the work ceiling") => Self::GlobalWindowExceeded,
            _ => Self::FamilyFenceClosed,
        }
    }

    pub fn from_admission_code(code: &str) -> Option<Self> {
        match code {
            "COURT_KERNEL_UNCOVERED" => Some(Self::CourtKernelUncovered),
            "NOT_END_TO_END_CERTIFIED" => Some(Self::NotEndToEndCertified),
            "FAMILY_FENCE_CLOSED" | "KimiFamilyNeedsItsFence" => Some(Self::FamilyFenceClosed),
            "GLOBAL_WINDOW_EXCEEDED" => Some(Self::GlobalWindowExceeded),
            "MODEL_ALREADY_REGISTERED" => Some(Self::ModelAlreadyRegistered),
            "ARTIFACT_ROOT_MISMATCH" => Some(Self::ArtifactRootMismatch),
            "REGISTRATION_NOT_INCLUDED" => Some(Self::RegistrationNotIncluded),
            "READY_SEATS_INSUFFICIENT" => Some(Self::ReadySeatsInsufficient),
            "CLASS_NOT_ATTRIBUTABLE" => Some(Self::ClassNotAttributable),
            "REGISTRATION_DROPPED" => Some(Self::RegistrationDropped),
            _ => None,
        }
    }

    pub fn from_fit_wall(wall: PalwFitWallV1, ok: bool) -> Option<Self> {
        match (wall, ok) {
            (PalwFitWallV1::GeometryCeiling, true) => Some(Self::FitsGlobalWindow),
            (PalwFitWallV1::GeometryCeiling, false) => Some(Self::GlobalWindowExceeded),
            _ => None,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwModelPreflightCheckV1 {
    pub code: String,
    pub ok: bool,
    pub message: String,
}

impl PalwModelPreflightCheckV1 {
    pub fn from_code(code: PalwModelRegistrationCodeV1, ok: bool) -> Self {
        Self { code: code.code().to_string(), ok, message: code.message().to_string() }
    }

    pub fn from_admission_err(err: &PalwClassAdmissionError) -> Self {
        Self { code: err.code().to_string(), ok: false, message: err.to_string() }
    }
}

/// Map a mempool/submit error string onto a stable code when the node already named the gate.
pub fn palw_model_reject_from_submit_text_v1(text: &str) -> Option<PalwModelRegistrationCodeV1> {
    let t = text.to_ascii_uppercase();
    if t.contains("DUPLICATECLASS") || t.contains("ALREADY REGISTERED") || t.contains("MODEL_ALREADY_REGISTERED") {
        return Some(PalwModelRegistrationCodeV1::ModelAlreadyRegistered);
    }
    if t.contains("ENUMERATION PAST THE WORK CEILING")
        || t.contains("GLOBAL_WINDOW")
        || t.contains("GEOMETRY CEILING")
        || t.contains("PALW_STEP_MAX_ENUMERATION")
    {
        return Some(PalwModelRegistrationCodeV1::GlobalWindowExceeded);
    }
    if t.contains("NOT END-TO-END CERTIFIED") || t.contains("NOT_END_TO_END_CERTIFIED") {
        return Some(PalwModelRegistrationCodeV1::NotEndToEndCertified);
    }
    if t.contains("KIMI") && t.contains("FENCE") {
        return Some(PalwModelRegistrationCodeV1::KimiFamilyNeedsItsFence);
    }
    if t.contains("COVERAGE") || t.contains("KERNEL") && t.contains("UNCOVER") {
        return Some(PalwModelRegistrationCodeV1::CourtKernelUncovered);
    }
    if t.contains("ARTIFACT") && t.contains("ROOT") {
        return Some(PalwModelRegistrationCodeV1::ArtifactRootMismatch);
    }
    if t.contains("NOT ATTRIBUTABLE") || t.contains("CLASS_NOT_ATTRIBUTABLE") {
        return Some(PalwModelRegistrationCodeV1::ClassNotAttributable);
    }
    None
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwModelPreflightReportV1 {
    pub class_id: Hash64,
    pub artifact_root: Hash64,
    pub n_ctx: u32,
    pub layer_count: u16,
    pub graph_profile: String,
    pub canonical_prefill: u32,
    pub canonical_decode: u32,
    pub admissible: bool,
    pub processor_verdict: String,
    pub reject_code: String,
    pub checks: Vec<PalwModelPreflightCheckV1>,
    /// The gate's refusal in its structured form (code, rule, needed against limit, what decided the reading), when the gate refused
    /// — the same JSON every tool prints beside its sentence (`crate::palw_refusal_v1`).
    pub refusal: Option<crate::palw_refusal_v1::PalwRefusalV1>,
}

impl PalwModelPreflightReportV1 {
    pub fn empty() -> Self {
        Self {
            class_id: Hash64::default(),
            artifact_root: Hash64::default(),
            n_ctx: 0,
            layer_count: 0,
            graph_profile: String::new(),
            canonical_prefill: 0,
            canonical_decode: 0,
            admissible: false,
            processor_verdict: String::new(),
            reject_code: String::new(),
            refusal: None,
            checks: Vec::new(),
        }
    }
}

/// Processor-same preflight: fit walls plus [`verify_class_admission_v9`] and the attribution
/// checks the processor asks beside it
/// ([`crate::palw_attempt_rules_v1::palw_registration_attribution_v1`]).
pub fn palw_model_preflight_v1(
    params: &Params,
    bundle: &PalwConsensusParamsV2,
    object: &PalwConsensusObjectV2,
    certified: &[PalwE2eFamilyV1],
    chain_certified: &[PalwE2eFamilyV1],
    daa_score: u64,
    already_registered: bool,
    registered_root: Option<Hash64>,
) -> Result<PalwModelPreflightReportV1, String> {
    let PalwConsensusObjectV2::ClassRegistered { class_id, artifact_root, admission, share_permille, .. } = object else {
        return Err("the object is not a ClassRegistered".into());
    };
    let carriage = admission.as_ref().ok_or_else(|| "the registration has no admission carriage".to_string())?;
    let profile = &carriage.profile;
    let canonical = &carriage.canonical;
    let shape = palw_admission_shape_at_v1(params, bundle, profile, daa_score)?;
    let regime = crate::palw_model_fit_v1::palw_fit_regime_for_v1(shape.held, profile);
    let fit = palw_model_fit_v2(profile, bundle, shape.court, params.palw_prompt_ids_form_at(daa_score), regime);

    let mut checks = Vec::new();
    if already_registered {
        checks.push(PalwModelPreflightCheckV1::from_code(PalwModelRegistrationCodeV1::ModelAlreadyRegistered, false));
    }
    if let Some(root) = registered_root
        && root != *artifact_root
    {
        checks.push(PalwModelPreflightCheckV1::from_code(PalwModelRegistrationCodeV1::ArtifactRootMismatch, false));
    }
    if let Some(row) = fit.rows.iter().find(|r| r.wall == PalwFitWallV1::GeometryCeiling) {
        let ok = row.verdict == PalwFitVerdictV1::Admitted;
        checks.push(PalwModelPreflightCheckV1::from_code(
            if ok { PalwModelRegistrationCodeV1::FitsGlobalWindow } else { PalwModelRegistrationCodeV1::GlobalWindowExceeded },
            ok,
        ));
    }

    let admission = verify_class_admission_v9(
        bundle,
        profile,
        canonical,
        object,
        certified,
        chain_certified,
        shape.ladder,
        shape.court,
        false,
        shape.token_lift,
        shape.fused_dissectable,
        // F4 and C-4 from the shape, the one reading every preflight shares (route-matrix #6).
        shape.legal_job_bound,
        shape.held,
        shape.kimi_family,
        // 2026-09-23 audit C-4: the geometry a non-fused class is priced from must fit its query row.
        shape.attention_geometry_bound,
        shape.gdn_key_heads,
    );
    // **The processor's attribution checks, asked where it asks them** (beside the gate, after it):
    // ADR-0152 §4-ter C5's held check and addendum §4-bis.8's — one shared function, the processor's
    // two calls with its arguments (testnet-12 lifecycle audit T12-030: this preflight asked only
    // the first, so a canonical job the processor drops read ADMISSION_OK).
    let attribution = crate::palw_attempt_rules_v1::palw_registration_attribution_v1(
        profile,
        canonical,
        shape.offence_attribution,
        shape.prompt_ids_form,
    );

    let mut refusal: Option<crate::palw_refusal_v1::PalwRefusalV1> = None;
    let mut reject_code = String::new();
    let mut processor_verdict = PalwModelRegistrationCodeV1::AdmissionOk.code().to_string();
    let admissible = match (&admission, &attribution) {
        (Ok(_), Ok(())) => {
            checks.push(PalwModelPreflightCheckV1::from_code(PalwModelRegistrationCodeV1::CourtCovered, true));
            if *share_permille > 0 {
                checks.push(PalwModelPreflightCheckV1::from_code(PalwModelRegistrationCodeV1::AdmissionOk, true));
            }
            true
        }
        (Ok(_), Err(err)) => {
            checks.push(PalwModelPreflightCheckV1::from_code(PalwModelRegistrationCodeV1::CourtCovered, true));
            checks.push(PalwModelPreflightCheckV1 { code: err.code().to_string(), ok: false, message: err.to_string() });
            reject_code = err.code().to_string();
            processor_verdict = err.code().to_string();
            false
        }
        (Err(err), _) => {
            let decided_by = crate::palw_refusal_v1::palw_refusal_decided_by_v1(
                shape.held.armed,
                Some(daa_score),
                params.palw_held_context.map(|f| f.daa_score()),
            );
            let structured = err.refusal_v1(&decided_by);
            checks.push(PalwModelPreflightCheckV1 {
                code: err.code().to_string(),
                ok: false,
                message: format!("{err} [refusal {}]", structured.to_json()),
            });
            refusal = Some(structured);
            reject_code = err.code().to_string();
            processor_verdict = err.code().to_string();
            if !matches!(err, PalwClassAdmissionError::CoverageGap) {
                checks.push(PalwModelPreflightCheckV1::from_code(PalwModelRegistrationCodeV1::CourtCovered, true));
            }
            if matches!(err, PalwClassAdmissionError::KimiFamilyNeedsItsFence) {
                checks.push(PalwModelPreflightCheckV1::from_code(PalwModelRegistrationCodeV1::KimiFamilyNeedsItsFence, false));
            }
            false
        }
    };

    Ok(PalwModelPreflightReportV1 {
        class_id: *class_id,
        artifact_root: *artifact_root,
        n_ctx: profile.n_ctx,
        layer_count: profile.layer_count,
        graph_profile: profile.shape_profile_id().to_string(),
        canonical_prefill: canonical.declared_prefill_tokens,
        canonical_decode: canonical.exact_decode_tokens,
        admissible: admissible && !already_registered,
        processor_verdict,
        reject_code,
        checks,
        refusal,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn admission_errors_carry_the_stable_tokens_operators_grep() {
        assert_eq!(PalwClassAdmissionError::CoverageGap.code(), "COURT_KERNEL_UNCOVERED");
        assert_eq!(PalwClassAdmissionError::NotEndToEndCertified { share: 489 }.code(), "NOT_END_TO_END_CERTIFIED");
        assert_eq!(PalwClassAdmissionError::KimiFamilyNeedsItsFence.code(), "FAMILY_FENCE_CLOSED");
        assert_eq!(
            PalwModelRegistrationCodeV1::from_admission(&PalwClassAdmissionError::CoverageGap).code(),
            "COURT_KERNEL_UNCOVERED"
        );
        assert_eq!(PalwModelRegistrationCodeV1::GlobalWindowExceeded.code(), "GLOBAL_WINDOW_EXCEEDED");
        assert_eq!(PalwModelRegistrationCodeV1::FitsGlobalWindow.code(), "FitsGlobalWindow");
        assert_eq!(PalwModelRegistrationCodeV1::CourtCovered.code(), "CourtCovered");
    }

    #[test]
    fn submit_text_maps_onto_the_2m_window_refusal() {
        let text = "class abc is not admissible: the profile is not well-formed: the declared shape drives an enumeration past the work ceiling";
        assert_eq!(
            palw_model_reject_from_submit_text_v1(text),
            Some(PalwModelRegistrationCodeV1::GlobalWindowExceeded)
        );
    }

    #[test]
    fn stages_are_ordered_so_a_cli_can_print_ticks() {
        assert!(PalwModelRegistrationStageV1::Constructed < PalwModelRegistrationStageV1::Submitted);
        assert!(PalwModelRegistrationStageV1::Submitted < PalwModelRegistrationStageV1::Accepted);
        assert!(PalwModelRegistrationStageV1::Accepted < PalwModelRegistrationStageV1::Included);
        assert!(PalwModelRegistrationStageV1::Included < PalwModelRegistrationStageV1::Folded);
    }

    fn class_registered(class_id: Hash64, artifact_root: Hash64) -> PalwConsensusObjectV2 {
        PalwConsensusObjectV2::ClassRegistered {
            class_id,
            artifact_root,
            slash_value_per_pwu: 1,
            pwu_rule: crate::palw_state_v2::PalwPwuRuleV2::MaxPerAttempt(500),
            initial_target: u128::MAX,
            share_permille: 0,
            activation_daa: 0,
            admission: None,
        }
    }

    fn carrier_on(subnetwork: crate::subnets::SubnetworkId, payload: Vec<u8>) -> crate::tx::Transaction {
        crate::tx::Transaction::new(
            0,
            Vec::new(),
            vec![crate::tx::TransactionOutput::new(9_996_000_000, crate::tx::ScriptPublicKey::from_vec(0, vec![0x51]))],
            0,
            subnetwork,
            0,
            payload,
        )
    }

    fn carrier(object: PalwConsensusObjectV2) -> crate::tx::Transaction {
        let payload = borsh::to_vec(&crate::palw_lifecycle_objects_v2::PalwLifecycleTxPayloadV2 {
            version: crate::palw_lifecycle_objects_v2::PALW_LIFECYCLE_TX_VERSION_V2,
            object,
        })
        .expect("the lifecycle payload serializes");
        carrier_on(crate::subnets::SUBNETWORK_ID_PALW_LIFECYCLE, payload)
    }

    fn row(class_id: Hash64, artifact_root: Hash64, registered_daa: u64) -> crate::palw_state_v2::PalwClassRowV2 {
        crate::palw_state_v2::PalwClassRowV2 {
            class_id,
            status: "Registered".to_string(),
            share_permille: Some(0),
            budget_blocks: 0,
            canonical_leaves: 0,
            is_base_class: false,
            artifact_root,
            fp_certified: false,
            held: false,
            registered_daa,
        }
    }

    /// **An included registration reads as included, by the chain's own record** (testnet-12,
    /// 2026-09-23). The carrier id is not a class id, so the class column alone can never answer a
    /// question asked by carrier — which is how `model registration <txid>` read
    /// `REGISTRATION_NOT_INCLUDED` for a registration two blocks had carried. The row the carrier
    /// wrote is found through the DAA the row itself records.
    #[test]
    fn a_carrier_resolves_to_the_row_it_wrote() {
        let (class, root) = (Hash64::from_u64_word(0xC1A5), Hash64::from_u64_word(0x2007));
        let rows = vec![row(Hash64::from_u64_word(1), Hash64::from_u64_word(2), 0), row(class, root, 1_234)];
        let tx = carrier(class_registered(class, root));

        assert!(rows.iter().all(|r| r.class_id != tx.id()), "the defect: a carrier id finds no row in the class column");
        assert_eq!(palw_registration_carrier_class_v1(&tx), Some((class, root)));
        let written = palw_registration_row_written_by_v1(&tx, 1_234, &rows).expect("accepted at the row's DAA, it wrote the row");
        assert_eq!(written.class_id, class);

        assert!(palw_registration_row_written_by_v1(&tx, 1_235, &rows).is_none(), "accepted elsewhere, it did not write this row");
        let other_root = carrier(class_registered(class, Hash64::from_u64_word(9)));
        assert!(
            palw_registration_row_written_by_v1(&other_root, 1_234, &rows).is_none(),
            "a rival registration does not claim the row"
        );
    }

    /// **The DROPPED judgement** (review of T12-030): only a carrier out of the mempool, with no row,
    /// whose change stands mined, and only from two DAA past its acceptance — inside that margin a
    /// successful carrier is mined and not yet folded, and must not read as dropped.
    #[test]
    fn a_mined_carrier_reads_dropped_only_past_the_fold_of_its_block() {
        use PALW_REGISTRATION_DROP_SETTLE_DAA_V1 as SETTLE;
        assert_eq!(SETTLE, 2);
        assert_eq!(palw_registration_carrier_dropped_v1(false, false, Some(100), 100), None, "accepted this DAA: not folded yet");
        assert_eq!(palw_registration_carrier_dropped_v1(false, false, Some(100), 101), None, "one DAA on: still inside the margin");
        assert_eq!(palw_registration_carrier_dropped_v1(false, false, Some(100), 102), Some(100), "past the fold of its block");
        assert_eq!(palw_registration_carrier_dropped_v1(true, false, Some(100), 500), None, "still pooled");
        assert_eq!(palw_registration_carrier_dropped_v1(false, true, Some(100), 500), None, "its row is written");
        assert_eq!(palw_registration_carrier_dropped_v1(false, false, None, 500), None, "no mined change: no evidence");
        assert_eq!(palw_registration_carrier_dropped_v1(false, false, Some(u64::MAX), u64::MAX), Some(u64::MAX), "no overflow");
        let carrier = crate::tx::TransactionId::from_u64_word(7);
        assert_eq!(palw_lifecycle_carrier_change_v1(carrier), crate::tx::TransactionOutpoint::new(carrier, 0));
    }

    /// Only a lifecycle carrier at the fold's wire version carrying a `ClassRegistered` names a class.
    #[test]
    fn only_a_class_registration_carrier_names_a_class() {
        let object = class_registered(Hash64::from_u64_word(3), Hash64::from_u64_word(4));
        let payload = borsh::to_vec(&crate::palw_lifecycle_objects_v2::PalwLifecycleTxPayloadV2 {
            version: crate::palw_lifecycle_objects_v2::PALW_LIFECYCLE_TX_VERSION_V2,
            object: object.clone(),
        })
        .unwrap();
        assert!(palw_registration_carrier_class_v1(&carrier_on(crate::subnets::SUBNETWORK_ID_NATIVE, payload)).is_none());
        let wrong_version = borsh::to_vec(&crate::palw_lifecycle_objects_v2::PalwLifecycleTxPayloadV2 {
            version: crate::palw_lifecycle_objects_v2::PALW_LIFECYCLE_TX_VERSION_V2 + 1,
            object,
        })
        .unwrap();
        assert!(
            palw_registration_carrier_class_v1(&carrier_on(crate::subnets::SUBNETWORK_ID_PALW_LIFECYCLE, wrong_version)).is_none()
        );
        assert!(
            palw_registration_carrier_class_v1(&carrier_on(crate::subnets::SUBNETWORK_ID_PALW_LIFECYCLE, vec![1, 2, 3])).is_none()
        );
    }
}
