//! Native funded fixed-count text execution. This draft is not exported until
//! its complete money/court/DA/quota consumers and node regressions are ready.
//! All state writes use the parent transition journal; wire data supplies no
//! resource caps, eligibility, original reserve, settlement or trusted clock.
use super::*;
use crate::palw_flat_execution_v11::*;
use crate::palw_kernel_route_v1::palw_kernel_bond_id_v1;
use misaka_palw_kernel::{
    flat_execution11::*,
    flat_quota11::*,
    hash::{Digest, object_id},
};

fn refused(why: impl Into<String>) -> PalwStateV2Error {
    PalwStateV2Error::KernelRouteRefused(why.into())
}
fn key<T: borsh::BorshSerialize>(value: &T) -> Vec<u8> {
    borsh::to_vec(value).expect("bounded native11 journal key")
}
fn bytes<T: borsh::BorshSerialize>(value: &T) -> Vec<u8> {
    borsh::to_vec(value).expect("bounded native11 journal record")
}

/// Caps are compiled here, rather than negotiated by a Fund or class carrier.
/// They are conservative cumulative allowances on all21 axes, not PWU/credit.
fn policies(builder: &TransitionBuilder<'_>) -> Result<(ExecutionPolicyV11, QuotaPolicyV11), PalwStateV2Error> {
    let r = builder.state.kernel_route.as_ref().ok_or_else(|| refused("no native kernel header"))?;
    let exponents = [42u32, 45, 44, 45, 46, 44, 44, 24, 36, 36, 32, 34, 18, 16, 36, 30, 34, 40, 36, 31, 36];
    let plan = QuotaQuantitiesV11(exponents.map(|n| 1u128 << n));
    let scale = |times| QuotaQuantitiesV11(plan.0.map(|n| n * times));
    let quota = QuotaPolicyV11 {
        version: 11,
        enabled: true,
        network_domain: r.header.policy.network_domain,
        ruleset_digest: quota_ruleset_id_v11(),
        interval_daa: 10_000,
        plan: plan.clone(),
        block: scale(4),
        actor: scale(16),
        network: scale(64),
        max_subjects: EXECUTION_LIVE_JOBS_MAX_V11,
        max_actors: 256,
        // Ordinary requests32 + at most4 retained paid seals*2 protected
        // requests need at least40 ORIGINAL producer answer entitlements.
        future_attempts: [4, 32, 48, 2, 1, 2],
    };
    let sompi = crate::constants::SOMPI_PER_KASPA;
    let execution = ExecutionPolicyV11 {
        version: 11,
        enabled: true,
        network_domain: quota.network_domain,
        quota_policy_root: quota.root(),
        horizons: ExecutionHorizonsV11 {
            commit_window: 20,
            challenge_window: 200,
            seal_maturity: 3,
            seal_ttl: 100,
            da_answer: 20,
            proof_grace: 10,
            retention: 30,
        },
        reward_cap: 20 * sompi,
        external_gain_cap: 40 * sompi,
        default_obligation: 40 * sompi,
        required_producer_reserve: 100 * sompi,
        finder_permille: 490,
    };
    execution.check(&quota).map_err(refused)?;
    if quota.future_attempts[2] < 32 + 2 * 4 {
        return Err(refused("compiled native11 producer answer guarantee incomplete"));
    }
    if let Some(stored) = r.aux_row::<(ExecutionPolicyV11, QuotaPolicyV11)>(EXECUTION_POLICY_TABLE_V11, &[]) {
        if stored != (execution.clone(), quota.clone()) {
            return Err(refused("native11 compiled policy differs from original journal"));
        }
    }
    Ok((execution, quota))
}
fn epoch(ctx: &PalwBlockContextV2, quota: &QuotaPolicyV11) -> Result<TrustedEpochV11, PalwStateV2Error> {
    let block = object_id(b"misaka-palw/native/trusted-execution-block/v11", &ctx.block.as_byte_slice().to_vec());
    TrustedEpochV11::from_chain(quota, block, ctx.daa_score).map_err(refused)
}
fn source(
    r: &crate::palw_kernel_route_v1::PalwKernelRouteStateV1,
    binding: &Digest,
) -> Result<(NativeSourceBindingV11, crate::palw_model_artifact_v2::ModelArtifactBindingHeaderV2), PalwStateV2Error> {
    let h = r
        .model_artifact_binding_header_v2(&Hash64::from_bytes(*binding))
        .ok_or_else(|| refused("original native11 model binding missing"))?;
    Ok((
        NativeSourceBindingV11 {
            descriptor: h.descriptor,
            program_root: h.program_root,
            parameter_root: h.kernel_param_root.as_bytes(),
            inventory_root: h.model_inventory_root.as_bytes(),
            bound_daa: h.bound_daa,
            matures_daa: h.matures_daa,
            refuted: h.refuted,
        },
        h,
    ))
}
fn eligible_witness(
    r: &crate::palw_kernel_route_v1::PalwKernelRouteStateV1,
    class: &ExecutionClassRecordV11,
    e: &TrustedEpochV11,
) -> Result<NativeClassEligibilityV11, PalwStateV2Error> {
    if r.template().schedule.standing_at(&class.descriptor, e.block_daa) != misaka_palw_kernel::descriptor::KernelStandingV1::Active
        || r.model_artifact_candidate_binding_v2(&Hash64::from_bytes(class.candidate9_id))
            != Some(Hash64::from_bytes(class.binding_id))
        || r.aux.contains_key(&(EXECUTION_SOURCE_FACT_TABLE_V11, key(&class.binding_id)))
    {
        return Err(refused("native11 exact original source/fence no longer admits jobs"));
    }
    Ok(NativeClassEligibilityV11 {
        class_id: class.id(),
        active_descriptor: class.descriptor,
        active_binding: class.binding_id,
        execution_policy_root: class.execution_policy_root,
        quota_policy_root: class.quota_policy_root,
        current_daa: e.block_daa,
        block_hash: e.block_hash,
    })
}
fn checked_live_class(
    builder: &TransitionBuilder<'_>,
    e: &TrustedEpochV11,
    class_id: &Digest,
) -> Result<CheckedNativeExecutionClassV11, PalwStateV2Error> {
    let r = builder.state.kernel_route.as_ref().unwrap();
    let original = r.execution_class_header_v11(class_id).ok_or_else(|| refused("unknown original funded execution class"))?;
    let (policy, quota) = policies(builder)?;
    let (s, h) = source(r, &original.record.binding_id)?;
    let c = r
        .flat_candidate_record_v9(&Hash64::from_bytes(original.record.candidate9_id))
        .ok_or_else(|| refused("native11 class candidate missing"))?;
    let checked =
        restore_native_execution_class_header_v11(&c, &s, Some(&original.record), &policy, &quota, e.block_daa).map_err(refused)?;
    if checked.header().root() != original.original_header_root
        || checked.header().encoder_input_limit != original.encoder_input_limit
        || checked.view().scope.relations.len() != original.primitive_count as usize
        || checked.record().source_court_bound.max_proof_bytes != h.max_proof_bytes as u64
    {
        return Err(refused("native11 original class/header/source court changed"));
    }
    let witness = eligible_witness(r, checked.record(), e)?;
    authorize_native_execution_class_header_v11(checked, &s, &witness).map_err(refused)
}

/// The selected quota rows have their own authenticated journal root, never a
/// root/absence asserted by a carrier. A callback reads at most four fixed rows.
fn quota_key(kind: u8, id: &Digest) -> Vec<u8> {
    let mut k = vec![kind];
    k.extend_from_slice(id);
    k
}
fn rooted_row<T: borsh::BorshSerialize>(root: Digest, row: &T) -> Vec<u8> {
    let mut raw = root.to_vec();
    raw.extend(bytes(row));
    raw
}
fn split_rooted(raw: &[u8], width: u64) -> Result<(Digest, &[u8]), PalwStateV2Error> {
    if raw.len() as u128 != width as u128 + 64 {
        return Err(refused("native11 selected quota row extent differs"));
    }
    Ok((raw[..64].try_into().expect("checked fixed row root"), &raw[64..]))
}
fn load_shard(
    builder: &TransitionBuilder<'_>,
    quota: &QuotaPolicyV11,
    e: &TrustedEpochV11,
    actor: Digest,
    job: Digest,
    seal: Option<Digest>,
) -> Result<CheckedQuotaShardV11, PalwStateV2Error> {
    let r = builder.state.kernel_route.as_ref().unwrap();
    let global = match r.aux.get(&(EXECUTION_QUOTA_TABLE_V11, Vec::new())) {
        Some(raw) => {
            let (root, raw) = split_rooted(raw, QUOTA_GLOBAL_ROW_BYTES_V11)?;
            QuotaGlobalRowV11::from_rooted_bytes(raw, &root).map_err(refused)?
        }
        None => QuotaStateV11::new(quota, e.clone()).map_err(refused)?.global_row(),
    };
    let ar = r
        .aux
        .get(&(EXECUTION_QUOTA_TABLE_V11, quota_key(0, &actor)))
        .map(|raw| {
            let (root, raw) = split_rooted(raw, QUOTA_SELECTED_ACTOR_ROW_BYTES_V11)?;
            Ok::<_, PalwStateV2Error>((QuotaActorRowV11::from_rooted_bytes(raw, &root).map_err(refused)?, root))
        })
        .transpose()?;
    let sr = r
        .aux
        .get(&(EXECUTION_QUOTA_TABLE_V11, quota_key(1, &job)))
        .map(|raw| {
            let (root, raw) = split_rooted(raw, QUOTA_SELECTED_SUBJECT_ROW_BYTES_V11)?;
            Ok::<_, PalwStateV2Error>((QuotaSubjectSummaryV11::from_rooted_row_bytes(raw, &root).map_err(refused)?, root))
        })
        .transpose()?;
    let pr = seal
        .and_then(|id| r.aux.get(&(EXECUTION_QUOTA_TABLE_V11, quota_key(2, &id))))
        .map(|raw| {
            let (root, raw) = split_rooted(raw, QUOTA_SELECTED_SEAL_ROW_BYTES_V11)?;
            Ok::<_, PalwStateV2Error>((ProtectedSealSummaryV11::from_rooted_row_bytes(raw, &root).map_err(refused)?, root))
        })
        .transpose()?;
    CheckedQuotaShardV11::from_native_rows(
        quota,
        &global,
        &global.root(),
        actor,
        job,
        seal,
        ar.as_ref().map(|(row, root)| (row, root)),
        sr.as_ref().map(|(row, root)| (row, root)),
        pr.as_ref().map(|(row, root)| (row, root)),
    )
    .map_err(refused)
}
fn write_shard(builder: &mut TransitionBuilder<'_>, shard: &CheckedQuotaShardV11) {
    let global = shard.global_row();
    let actor = shard.actor_row();
    builder.write_kernel_row(EXECUTION_QUOTA_TABLE_V11, Vec::new(), Some(rooted_row(global.root(), &global)));
    builder.write_kernel_row(EXECUTION_QUOTA_TABLE_V11, quota_key(0, &actor.actor), Some(rooted_row(actor.root(), &actor)));
    if let Some(subject) = shard.subject_row() {
        builder.write_kernel_row(
            EXECUTION_QUOTA_TABLE_V11,
            quota_key(1, &subject.binding.job_id),
            Some(rooted_row(subject.row_root(), subject)),
        );
    }
    if let Some(seal) = shard.seal_row() {
        builder.write_kernel_row(EXECUTION_QUOTA_TABLE_V11, quota_key(2, &seal.key.root()), Some(rooted_row(seal.row_root(), seal)));
    }
}
fn fixed_rows_work() -> u64 {
    (QUOTA_GLOBAL_ROW_BYTES_V11
        + QUOTA_SELECTED_ACTOR_ROW_BYTES_V11
        + QUOTA_SELECTED_SUBJECT_ROW_BYTES_V11
        + QUOTA_SELECTED_SEAL_ROW_BYTES_V11
        + 4 * 64
        + 16 * 1024)
        * 64
        + 65536
}
fn paid(
    builder: &mut TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    signer: &PalwBondKeyV2,
    work: u64,
    protected: bool,
) -> Result<bool, PalwStateV2Error> {
    let Some(fee) = super::palw_flat_model_vector_fold_v3::charge(builder, ctx, signer, work, protected)? else { return Ok(false) };
    let bond = builder.state.bonds.get(signer).ok_or(PalwStateV2Error::MissingBond(*signer))?;
    // Avoid an overflow in the actual bond journal after a paid body is checked.
    if bond.slashed.checked_add(u64::try_from(fee).map_err(|_| refused("native11 fee amount overflow"))?).is_none() {
        return Err(refused("native11 cumulative actual debit overflow"));
    }
    builder.slash_bond(*signer, fee)?;
    Ok(true)
}
fn ordinary_stage(
    builder: &mut TransitionBuilder<'_>,
    quota: &QuotaPolicyV11,
    e: &TrustedEpochV11,
    actor: Digest,
    stage: &DerivedOrdinaryMetadataV11,
) -> Result<(), PalwStateV2Error> {
    let mut shard = load_shard(builder, quota, e, actor, [0; 64], None)?;
    shard.debit_ordinary(quota, e, stage).map_err(refused)?;
    write_shard(builder, &shard);
    Ok(())
}

/// Stage class/header once. Candidate9 admission already independently derived
/// its full resourceRoot. This header does not label a model faithful or tested.
pub(super) fn class_stage(
    builder: &mut TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    signer: &PalwBondKeyV2,
    candidate: &Digest,
) -> Result<(), PalwStateV2Error> {
    super::palw_flat_model_vector_fold_v3::enabled(builder, ctx)?;
    let (policy, quota) = policies(builder)?;
    let e = epoch(ctx, &quota)?;
    let r = builder.state.kernel_route.as_ref().unwrap();
    let candidate_id = Hash64::from_bytes(*candidate);
    let plan =
        r.flat_candidate_plan_v9(&candidate_id).ok_or_else(|| refused("class stage has no independently admitted candidate9"))?;
    let binding = r.model_artifact_candidate_binding_v2(&candidate_id).ok_or_else(|| refused("class stage source index missing"))?;
    let (s, h) = source(r, &binding.as_bytes())?;
    let ids = r.aux_row::<Vec<Digest>>(EXECUTION_CLASS_OWNER_TABLE_V11, &key(signer)).unwrap_or_default();
    if ids.len() >= EXECUTION_CLASSES_PER_ACTOR_V11 {
        return Err(refused("bounded active native11 class owner catalog full"));
    }
    let work =
        plan.native_restore_work.checked_add(fixed_rows_work()).ok_or_else(|| refused("native11 class stage tariff overflow"))?;
    if !paid(builder, ctx, signer, work, false)? {
        return Ok(());
    }
    // A new native metadata factory will consume exactly this authenticated
    // fixed-prefix work before copying the candidate; it supplies no raw price.
    let stage = derive_native_class_metadata_v11(&plan).map_err(refused)?;
    ordinary_stage(builder, &quota, &e, palw_kernel_bond_id_v1(signer), &stage)?;
    let r = builder.state.kernel_route.as_ref().unwrap();
    let candidate = r.flat_candidate_record_v9(&candidate_id).ok_or_else(|| refused("admitted native11 candidate record changed"))?;
    let checked = restore_native_execution_class_header_v11(&candidate, &s, None, &policy, &quota, ctx.daa_score).map_err(refused)?;
    if checked.record().source_court_bound.max_proof_bytes != h.max_proof_bytes as u64 {
        return Err(refused("native11 original source proof bound differs"));
    }
    let witness = eligible_witness(r, checked.record(), &e)?;
    let checked = authorize_native_execution_class_header_v11(checked, &s, &witness).map_err(refused)?;
    let id = checked.record().id();
    if r.execution_class_header_v11(&id).is_some() {
        return Ok(());
    }
    // Check node AND original-model source cases against the SAME fixed normal
    // route cap, including class restore, scoped filing, storedpost and finish.
    let court =
        misaka_palw_kernel::flat_court9::complete_scope_api_bounds_v9(&checked.view().scope).map_err(|x| refused(format!("{x:?}")))?;
    let assembly = court
        .filing_bytes
        .max(checked.record().source_court_bound.max_proof_bytes)
        .checked_add(7 + 16 * 1024)
        .ok_or_else(|| refused("native11 proof bound overflow"))?;
    let post_cap =
        16 * 1024 + 4 * (checked.record().max_positions as u64 + 1) + 64 * (checked.record().max_positions as u64).div_ceil(1024);
    let metadata = 64 * (post_cap + assembly) + 64 * (assembly + 1024) + 64 * (32 * 1024 + 3 * assembly + 1024);
    let terminal_work = plan
        .native_restore_work
        .checked_add(court.work.max(checked.record().source_court_bound.work))
        .and_then(|w| w.checked_add(metadata))
        .and_then(|w| w.checked_add(fixed_rows_work()))
        .ok_or_else(|| refused("native11 whole court work overflow"))?;
    let legacy = super::palw_kernel_route_fold_v1::route_ledger_policy_v1(builder)?;
    if terminal_work > legacy.guaranteed_proof_work_v1()
        || assembly > EXECUTION_FILING_MAX_BYTES_V11 as u64
        || legacy.prosecution_reserved_runs() < 2 && legacy.max_adjudications_per_block < 2
    {
        return Err(refused("native11 mandatory source/node court cannot fit unchanged reserve"));
    }
    let row = NativeExecutionClassRowV11 {
        header: NativeExecutionClassJournalV11 {
            record: checked.record().clone(),
            original_header_root: checked.header().root(),
            encoder_input_limit: checked.header().encoder_input_limit,
            owner: *signer,
            admitted_daa: ctx.daa_score,
            primitive_count: checked
                .view()
                .scope
                .relations
                .len()
                .try_into()
                .map_err(|_| refused("native11 primitive count overflow"))?,
        },
    };
    let mut ids = ids;
    ids.push(id);
    builder.write_kernel_row(EXECUTION_CLASS_TABLE_V11, key(&id), Some(bytes(&row)));
    builder.write_kernel_row(EXECUTION_CLASS_OWNER_TABLE_V11, key(signer), Some(bytes(&ids)));
    builder.write_kernel_row(EXECUTION_POLICY_TABLE_V11, Vec::new(), Some(bytes(&(policy, quota))));
    Ok(())
}

fn preparation_key(id: &Digest) -> Vec<u8> {
    quota_key(0, id)
}
fn preparation_owner_key(actor: &Digest) -> Vec<u8> {
    quota_key(1, actor)
}
fn max_prompt(header: &NativeExecutionClassJournalV11) -> u32 {
    header.encoder_input_limit.unwrap_or(header.record.max_positions)
}
fn note_actor(builder: &mut TransitionBuilder<'_>, signer: &PalwBondKeyV2) {
    builder.write_kernel_row(
        crate::palw_kernel_route_v1::PALW_KERNEL_ROUTE_TABLE_BOND_KEYS_V1,
        key(&palw_kernel_bond_id_v1(signer)),
        Some(bytes(signer)),
    );
}

/// Independently prepare actual input P and its exact resource/quota roots in
/// a separately paid transaction. Fund restores this fixed authenticated row.
pub(super) fn prepare(
    builder: &mut TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    signer: &PalwBondKeyV2,
    class_id: &Digest,
    wire: &[u8],
) -> Result<(), PalwStateV2Error> {
    super::palw_flat_model_vector_fold_v3::enabled(builder, ctx)?;
    let (_, quota) = policies(builder)?;
    let e = epoch(ctx, &quota)?;
    let actor = palw_kernel_bond_id_v1(signer);
    let r = builder.state.kernel_route.as_ref().unwrap();
    let header = r.execution_class_header_v11(class_id).ok_or_else(|| refused("Prepare unknown native11 class"))?;
    let candidate = r
        .flat_candidate_plan_v9(&Hash64::from_bytes(header.record.candidate9_id))
        .ok_or_else(|| refused("Prepare native candidate missing"))?;
    let mut ids = r.aux_row::<Vec<Digest>>(EXECUTION_PREPARATION_TABLE_V11, &preparation_owner_key(&actor)).unwrap_or_default();
    if ids.len() >= EXECUTION_PREPARATIONS_PER_ACTOR_V11
        || wire.len() > crate::palw_flat_model_vector_v3::FLAT_MODEL_VECTOR_MAX_POST_BYTES_V3
    {
        return Err(refused("bounded native11 preparation catalog/carrier full"));
    }
    // First predebit covers raw wire/header work and the full original scope.
    let restore_work = candidate
        .native_restore_work
        .checked_add(fixed_rows_work())
        .and_then(|w| w.checked_add(wire.len() as u64 * 64))
        .ok_or_else(|| refused("native11 Prepare restore tariff overflow"))?;
    if !paid(builder, ctx, signer, restore_work, false)? {
        return Ok(());
    }
    let restore = derive_native_class_metadata_v11(&candidate).map_err(refused)?;
    ordinary_stage(builder, &quota, &e, actor, &restore)?;
    let request = decode_flat_execution_fund_v11(wire, max_prompt(&header)).map_err(|x| refused(x.to_string()))?;
    if request.execution_class != *class_id || request.preparation != [0; 64] {
        return Err(refused("Prepare request has wrong class or nested prior preparation"));
    }
    let counter = builder
        .state
        .kernel_route
        .as_ref()
        .unwrap()
        .execution_nonce_counter_v11(&builder.state.bonds[signer].operator_id.as_bytes())
        .map_err(refused)?;
    counter.advance(&request.nonce).map_err(refused)?;
    let class = checked_live_class(builder, &e, class_id)?;
    let input = request.input(class.record().encoder).map_err(refused)?;
    if request.prompt.iter().any(|t| *t >= class.view().program.token_bound) {
        return Err(refused("native11 prompt exceeds admitted vocabulary"));
    }
    // Quote independently from the private class at the exact actual P. This
    // scheduled pass and fixed post/stored row bytes are prepaid before derive.
    let stage = derive_native_actual_preparation_metadata_v11(&class, input.positions).map_err(refused)?;
    let factory_work = u64::try_from(stage.quantities().get(misaka_palw_kernel::flat_resources10::ResourceAxisV10::MetadataWork))
        .map_err(|_| refused("native11 actual metadata tariff overflow"))?;
    if restore_work.checked_add(factory_work).is_none_or(|w| {
        w > super::palw_kernel_route_fold_v1::route_ledger_policy_v1(builder).map(|p| p.admission_work_limit_v1()).unwrap_or(0)
    }) {
        return Err(refused("native11 combined class/actual Prepare exceeds unchanged per-object cap"));
    }
    if !paid(builder, ctx, signer, factory_work, false)? {
        return Ok(());
    }
    ordinary_stage(builder, &quota, &e, actor, &stage)?;
    let plan = derive_job_quota_plan_from_checked_native_class_v11(&class, input.positions).map_err(refused)?;
    let checked =
        bind_native_execution_preparation_v11(&class, &quota, input, plan, actor, request.producer, request.nonce, request.reward)
            .map_err(refused)?;
    let row = NativeExecutionPreparationV11 {
        record: checked.record().clone(),
        plan: checked.quota_plan().record(),
        owner: *signer,
        prepared_daa: ctx.daa_score,
    };
    let id = row.id();
    if builder.state.kernel_route.as_ref().unwrap().aux.contains_key(&(EXECUTION_PREPARATION_TABLE_V11, preparation_key(&id))) {
        return Ok(());
    }
    ids.push(id);
    note_actor(builder, signer);
    builder.write_kernel_row(EXECUTION_PREPARATION_TABLE_V11, preparation_key(&id), Some(bytes(&row)));
    builder.write_kernel_row(EXECUTION_PREPARATION_TABLE_V11, preparation_owner_key(&actor), Some(bytes(&ids)));
    Ok(())
}

/// Original requester collateral is destroyed into one escrow here, atomically
/// with advancing its OPERATOR monotone nonce and writing the genuine book.
/// Nominated producers consume no quota until their own signed first Commit.
pub(super) fn fund(
    builder: &mut TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    signer: &PalwBondKeyV2,
    class_id: &Digest,
    wire: &[u8],
) -> Result<(), PalwStateV2Error> {
    super::palw_flat_model_vector_fold_v3::enabled(builder, ctx)?;
    let (_, quota) = policies(builder)?;
    let e = epoch(ctx, &quota)?;
    let actor = palw_kernel_bond_id_v1(signer);
    let r = builder.state.kernel_route.as_ref().unwrap();
    let header = r.execution_class_header_v11(class_id).ok_or_else(|| refused("Fund unknown native11 class"))?;
    let candidate = r
        .flat_candidate_plan_v9(&Hash64::from_bytes(header.record.candidate9_id))
        .ok_or_else(|| refused("Fund native candidate missing"))?;
    let mut jobs = r.aux_row::<Vec<Digest>>(EXECUTION_JOB_OWNER_TABLE_V11, &key(signer)).unwrap_or_default();
    let count = r.aux_row::<u32>(EXECUTION_JOB_COUNT_TABLE_V11, &[]).unwrap_or(0);
    if jobs.len() >= EXECUTION_JOBS_PER_REQUESTER_V11
        || count >= EXECUTION_LIVE_JOBS_MAX_V11
        || wire.len() > crate::palw_flat_model_vector_v3::FLAT_MODEL_VECTOR_MAX_POST_BYTES_V3
    {
        return Err(refused("bounded active native11 job catalog/carrier full"));
    }
    let work = candidate
        .native_restore_work
        .checked_add(fixed_rows_work())
        .and_then(|w| w.checked_add(wire.len() as u64 * 64))
        .ok_or_else(|| refused("native11 Fund tariff overflow"))?;
    if !paid(builder, ctx, signer, work, false)? {
        return Ok(());
    }
    let metadata = derive_native_class_metadata_v11(&candidate).map_err(refused)?;
    ordinary_stage(builder, &quota, &e, actor, &metadata)?;
    let request = decode_flat_execution_fund_v11(wire, max_prompt(&header)).map_err(|x| refused(x.to_string()))?;
    if request.execution_class != *class_id {
        return Err(refused("Fund class differs from signed outer class"));
    }
    let r = builder.state.kernel_route.as_ref().unwrap();
    let preparation: NativeExecutionPreparationV11 = r
        .aux_row(EXECUTION_PREPARATION_TABLE_V11, &preparation_key(&request.preparation))
        .ok_or_else(|| refused("Fund exact independent preparation missing"))?;
    if preparation.id() != request.preparation
        || preparation.owner != *signer
        || preparation.record.requester != actor
        || preparation.record.class_id != *class_id
        || preparation.record.input != request.input(header.record.encoder).map_err(refused)?
        || preparation.record.producer != request.producer
        || preparation.record.nonce != request.nonce
        || preparation.record.reward != request.reward
    {
        return Err(refused("Fund changed exact independently prepared request/actors/nonce/reward"));
    }
    let requester = builder.state.bonds[signer].clone();
    let counter = r.execution_nonce_counter_v11(&requester.operator_id.as_bytes()).map_err(refused)?;
    let next = counter.advance(&request.nonce).map_err(refused)?;
    let producer_key = if request.producer == actor {
        *signer
    } else {
        r.bond_key_of(&request.producer).ok_or_else(|| refused("Fund producer has no authenticated signed native actor mapping"))?
    };
    let producer = builder
        .state
        .bonds
        .get(&producer_key)
        .filter(|b| matches!(b.status, PalwBondStatusV2::Active))
        .ok_or_else(|| refused("Fund original producer bond is not active"))?
        .clone();
    if palw_kernel_bond_id_v1(&producer_key) != request.producer {
        return Err(refused("Fund producer digest/outpoint mapping differs"));
    }
    let class = checked_live_class(builder, &e, class_id)?;
    let prepared =
        CheckedExecutionPreparationV11::restore(&preparation.record, &preparation.plan, request.preparation).map_err(refused)?;
    let receipt = object_id(
        b"misaka-palw/native/original-requester-escrow-debit/v11",
        &(e.block_hash, e.block_daa, actor, request.preparation, counter.root(), next.root(), request.reward),
    );
    let prepared =
        prepare_execution_job_from_checked_plan_v11(&class, &quota, &e, prepared, request.reward, receipt).map_err(refused)?;
    let id = prepared.job.id();
    if builder.state.kernel_route.as_ref().unwrap().execution_job_header_v11(&id).is_some() {
        return Err(refused("Fund original job already exists"));
    }
    let book = ExecutionJobStateV11::from_native_funded_job(prepared.job).map_err(refused)?;
    let free = (builder.state.bonds[signer].collateral as u128).saturating_sub(builder.committed_at(signer, ctx.daa_score));
    if free < request.reward as u128 || builder.state.bonds[signer].slashed.checked_add(request.reward).is_none() {
        return Err(refused("Fund original requester cannot pay exact escrow"));
    }
    let book_bytes = bytes(&book);
    let job = NativeExecutionJobRowV11 {
        header: NativeExecutionJobHeaderV11 {
            version: 11,
            job_id: id,
            class_id: *class_id,
            original_class_header_root: header.original_header_root,
            funded_job_root: book.job().root(),
            book_root: book.root(),
            quota_plan_root: book.job().quota_plan_root,
            requester: *signer,
            requester_operator: requester.operator_id.as_bytes(),
            requester_payout: requester.payout_payload,
            producer: producer_key,
            producer_operator: producer.operator_id.as_bytes(),
            producer_payout: producer.payout_payload,
            book_bytes_len: book_bytes.len().try_into().map_err(|_| refused("Fund bounded book size overflow"))?,
            prompt_len: book.job().input.prompt_len,
            stored_post_cap: prepared.quota_plan.native_post_carrier_cap(),
            deadline_daa: book.job().deadline_daa,
            terminal: ExecutionTerminalV11::Funded,
            producer_reserved: 0,
        },
        book_bytes,
        quota_plan: prepared.quota_plan.record(),
        prompt: request.prompt,
    };
    // Every fallible check/serialization/payout preflight precedes the actual
    // original debit; journal rows and nonce are written in the same transition.
    let row_bytes = bytes(&job);
    let next_bytes = bytes(&next);
    let debit = builder.slash_bond(*signer, request.reward as u128)?;
    if debit != request.reward {
        return Err(PalwStateV2Error::Overflow("native11 original escrow debit"));
    }
    jobs.push(id);
    note_actor(builder, signer);
    builder.write_kernel_row(EXECUTION_JOB_TABLE_V11, key(&id), Some(row_bytes));
    builder.write_kernel_row(EXECUTION_REQUEST_INDEX_TABLE_V11, key(&next.operator), Some(next_bytes));
    builder.write_kernel_row(EXECUTION_JOB_OWNER_TABLE_V11, key(signer), Some(bytes(&jobs)));
    builder.write_kernel_row(EXECUTION_JOB_COUNT_TABLE_V11, Vec::new(), Some(bytes(&(count + 1))));
    // Preparation is consumed, while original book and monotone nonce remain.
    let mut ids = builder
        .state
        .kernel_route
        .as_ref()
        .unwrap()
        .aux_row::<Vec<Digest>>(EXECUTION_PREPARATION_TABLE_V11, &preparation_owner_key(&actor))
        .unwrap_or_default();
    ids.retain(|p| *p != request.preparation);
    builder.write_kernel_row(EXECUTION_PREPARATION_TABLE_V11, preparation_key(&request.preparation), None);
    builder.write_kernel_row(
        EXECUTION_PREPARATION_TABLE_V11,
        preparation_owner_key(&actor),
        if ids.is_empty() { None } else { Some(bytes(&ids)) },
    );
    Ok(())
}

/// Publicly paid unclaimed cancellation uses only the original fixed readonly
/// class/book/payout and works without producer signature or baseline subject.
/// A revoked source remains refundable; its boolean is not a court judgment.
pub(super) fn cancel_unclaimed(
    builder: &mut TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    signer: &PalwBondKeyV2,
    job_id: &Digest,
) -> Result<(), PalwStateV2Error> {
    super::palw_flat_model_vector_fold_v3::enabled(builder, ctx)?;
    let (_, quota) = policies(builder)?;
    let e = epoch(ctx, &quota)?;
    let actor = palw_kernel_bond_id_v1(signer);
    let r = builder.state.kernel_route.as_ref().unwrap();
    let h = r.execution_job_header_v11(job_id).ok_or_else(|| refused("Cancel missing original funded job"))?;
    if h.terminal != ExecutionTerminalV11::Funded || r.aux.contains_key(&(EXECUTION_CREDIT_TABLE_V11, key(job_id))) {
        return Err(refused("Cancel funded escrow already claimed/credited"));
    }
    let c = r.execution_class_header_v11(&h.class_id).ok_or_else(|| refused("Cancel original fixed class missing"))?;
    if c.original_header_root != h.original_class_header_root {
        return Err(refused("Cancel original class header substituted"));
    }
    if !paid(builder, ctx, signer, fixed_rows_work(), false)? {
        return Ok(());
    }
    let fixed = c.checked_fixed_header().map_err(refused)?;
    let stage = derive_native_readonly_terminal_metadata_v11(&fixed).map_err(refused)?;
    ordinary_stage(builder, &quota, &e, actor, &stage)?;
    let mut row = builder.state.kernel_route.as_ref().unwrap().execution_job_row_v11(job_id).map_err(refused)?;
    let mut book = row.restore_book(&fixed).map_err(refused)?;
    let settlement = book.cancel_unclaimed(fixed.record(), ctx.daa_score).map_err(refused)?;
    if settlement.requester_refund != book.job().escrow_original_debit
        || settlement.escrow_debit != book.job().escrow_original_debit
        || settlement.producer_credit != 0
        || settlement.finder_credit != 0
        || settlement.collected_original_slash != 0
    {
        return Err(refused("Cancel original escrow conservation differs"));
    }
    let held = builder
        .state
        .pending_payouts
        .get(&crate::palw_kernel_route_v1::palw_kernel_payout_key_v1(&row.header.requester_payout))
        .map(|r| r.amount)
        .unwrap_or(0);
    held.checked_add(settlement.requester_refund).ok_or(PalwStateV2Error::Overflow("native11 original refund queue"))?;
    row.replace_book(&book).map_err(refused)?;
    let credit = NativeExecutionCreditV11 {
        job_id: *job_id,
        original_funded_job_root: row.header.funded_job_root,
        terminal_book_root: book.root(),
        settlement_root: object_id(b"misaka-palw/native/original-execution-settlement/v11", &settlement),
        requester_refund: settlement.requester_refund,
        producer_credit: 0,
        collected_original_slash: 0,
        finder: None,
        finder_credit: 0,
        burned: 0,
        established_daa: ctx.daa_score,
    };
    let row_bytes = bytes(&row);
    let credit_bytes = bytes(&credit);
    builder.add_kernel_payout(row.header.requester_payout, settlement.requester_refund)?;
    builder.write_kernel_row(EXECUTION_JOB_TABLE_V11, key(job_id), Some(row_bytes));
    builder.write_kernel_row(EXECUTION_CREDIT_TABLE_V11, key(job_id), Some(credit_bytes));
    Ok(())
}
