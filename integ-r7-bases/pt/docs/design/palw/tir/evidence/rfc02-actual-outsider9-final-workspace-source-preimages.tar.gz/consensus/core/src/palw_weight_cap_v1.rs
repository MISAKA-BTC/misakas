//! **ADR-0160 F-W (lane cap-weight): claims × N is not fork power × N** — staged claim weight, the
//! per-bond provisional weight cap (J-1), and the capped consensus reservation.
//!
//! # What changes, and only past `Params::palw_capacity_weight_cap`
//!
//! Below the fence every non-terminal claim adds its whole stored `immature_contribution` (β·pwu,
//! "raw") to `bounded_immature`, so a bond's provisional fork power is additive in its claim count
//! and one 2M claim weighs ≈ 555,611 floor claims before any panel has looked at it. Past the fence,
//! for an ATTEMPT claim whose `accepted_daa` is at or past the height (a "new-rule" claim — the
//! ADR-0145 keying, so a claim keeps one accounting for its whole life):
//!
//! ```text
//! x_c      = staged weight of c            (Created 0, Anchored 10‰, Licensed 1000‰ / S2 250‰, Final → safe)
//! W_full   = min(raw_c, C7 ceiling) for a class on the C7 list, raw_c otherwise   (ADR-0160 D-3)
//! X_b      = Σ x_c over b's live new-rule claims
//! W_cap(b) = ⌊C_b / 6,500 MSK⌋ × FCW       (FCW = one genesis-target floor claim's raw weight)
//! bounded_immature = Σ_{old-rule live claims} raw_c  +  Σ_b min(X_b, W_cap(b))
//! reserved(c) = ⌈w_c / ρ(accepted_daa)⌉    (ρ = F-L's ramp step there; 1 where F-L is not in force)
//! ```
//!
//! # Stage 1 (rcore/cap-s1): ρ is the only capacity knob
//!
//! The user's staged-safety plan (2026-09-26) integrates the lanes at ρ = 1 with **no claim-count
//! increase**: every rule that admits more claims must do so through ρ, which moves only by a flag day.
//! The lane's reservation `min(w_c, R_budget(b) − held)` (ADR-0160 v3 §5.1, `R_budget = ⌊C/6,500 MSK⌋ ×
//! w_FCW`) raised a model class's issuance at ρ = 1 — the stage-1 state diff measured 8k at 13,000 MSK
//! 1 → 2 claims and 2M at 13,000 / 100,000 MSK 0 → 1 — because it priced a claim's weight at 0.215 MSK
//! whatever the weight. The reservation is therefore the weight's shipped price divided by ρ: at ρ = 1
//! exactly today's, at ρ it buys ρ× the claims (the escrow's `⌈E/ρ⌉` floor, ADR-0160 §5.3, divides the
//! other half the same way). Fork power is not what this prices: J-1's `W_cap` bounds it at any
//! reservation. The withdrawn formula's helpers ([`palw_bond_weight_budget_sompi_v1`],
//! [`palw_capped_weight_reservation_v1`]) stay for the shadow's comparison and the tests of what they
//! computed.
//!
//! `bounded_immature` stays the ONE rooted scalar fork choice reads (`PalwCandidateOrderV1::new`), so
//! the comparator is unchanged; only the value past the fence changes. The per-bond sums live in
//! [`PalwBondWeightIndexV1`], a DERIVED index of the claims: never hashed, never carried, rebuilt by
//! every load and delta path from the claims and the bonds, maintained incrementally by the fold's
//! `write_claim` (every phase door passes it) and `write_bond` (every collateral move passes it, so a
//! slash lowers the cap and a refund restores it), and checked against its re-derivation at load and
//! after every block in debug builds ([`palw_bounded_immature_v2`]).
//!
//! # What bounds a private fork (ADR-0160 §8 A1), and what does not
//!
//! J-1 bounds a private branch's gain to `live_A − live_public ≤ Σ W_cap(C_A)` at any claim count — but
//! bounded is not refused. Past the fence the public branch's gain that a private branch cannot import
//! is nil inside a lead shorter than `anchor_delay`: its post-fork claims weigh 0 until bound, a
//! saturated bond gains nothing from further licences, and its licences of pre-fork claims are
//! lifecycle objects the private branch carries verbatim. So ANY positive staging only the private
//! branch holds wins `palw_reorg_strict_economic_win`:
//!
//! * a bind on the private branch — which lane A (`Params::palw_operator_anchor`) denies past its
//!   fence, since no operator attempt is on that branch; `validate_palw_v2` therefore refuses F-W without
//!   lane A at or below it (until the structural P0-10 fix replaces the stopgap);
//! * a licence only the private branch carries, of a claim bound before the fork at an operator's
//!   anchor — lane A does not stop it. It needs the attacker's seats to hold the quorum of that claim's
//!   FAIRLY drawn panel (the panel-security bound itself: such an attacker licenses junk on the public
//!   chain too), and it is still `≤ Σ W_cap(C_A)`. Below the fence the same attacker wins with Created
//!   junk alone, which costs only collateral.
//!
//! Tests: `w_t6_…` and `w_t6b_…` (fold), `capacity_probe_w_t6_…` and `capacity_probe_w_t6b_…` (processor).
//!
//! # Fork choice past the fence: strict-win's rule, the one copy (rcore/cap-s1)
//!
//! The deep-reorg gate (`dns_reorg_outcome`) judges every non-extension sink move, a one-block
//! sibling switch included. Staged weight makes all-economic ties the rule — a `Created` attempt weighs
//! 0, a bond at its cap gains nothing — and a tie that keeps the incumbent is a rule about arrival
//! order: two honest nodes racing a slot would keep the siblings they saw first (the lane's verify
//! finding 2). The lane answered with its own shallow-tie rule behind F-W; the DAA-750 release shipped
//! the same rule as `palw_reorg_strict_economic_win`'s (`palw_fork_authority_v2::
//! palw_reorg_strict_economic_win_v1`: a tie at most [`PALW_CAPACITY_SHALLOW_REORG_DAA_V1`] DAA ticks deep
//! on the incumbent's side, which does not LOWER the sink's DAA, is decided by GHOSTDAG's own order;
//! deeper, the incumbent stays). rcore/cap-s1 keeps that one rule: F-W adds no arm to the gate, and it
//! is never armable without the no-DAA-lowering check
//! (`palw_fork_authority_v2::PALW_REORG_SHALLOW_TIE_NEVER_LOWERS_SINK_DAA_V1`, checked by
//! `Params::validate_palw_capacity_weight_cap_v1`) — without it chained tie releases walk the sink
//! back past two ticks, and worse under F-W, where an attempt-only branch ties at zero ticks.
//!
//! # Invariants (ADR-0160 §7.1), each pinned by a test in `palw_state_v2/tests/capacity_weight_cap_v1.rs`
//!
//! * **W-I1** — `bounded_immature − Σ old-rule raw ≤ Σ_b W_cap(b)`, at any claim count.
//! * **W-I2** — monotone: a new claim, a bind and a licence only raise x_c; at `Final` the bond's
//!   term falls by at most x_c ≤ W_full while `safe_weight` rises by the full contribution; live
//!   weight falls only on a void, a slash (the cap), a redraw or a conviction.
//! * **W-I3** — the running value equals [`palw_bounded_immature_v2`] after every block, on reorg
//!   and at load.
//! * **W-I4** (stage 1) — every new-rule claim reserves `⌈w_c / ρ⌉` at its acceptance's ρ: today's
//!   reservation at ρ = 1, never less than `w_c / ρ` at any ρ.
//! * **W-I5** — old-rule claims are byte-identical in accounting (a dormant fence moves nothing).
//! * **W-I6** — no underflow on slash, void or redraw.

use std::collections::BTreeMap;

use crate::palw_state_v2::{
    PalwBondKeyV2, PalwChainStateV2, PalwClaimPhaseV2, PalwClaimSourceV2, PalwClaimStateV2, PalwStateParamsV2,
    palw_rcore_counts_licensed_v1,
};

/// **FCW — one floor-claim weight**, in `immature_contribution` units: `⌊β·pwu⌋` of a genesis-target
/// floor claim, `⌊0.1 × 279 × 21,657,728⌋` (ADR-0160 Appendix A). The unit of the per-bond cap.
pub const PALW_CAPACITY_FCW_V1: u128 = 604_250_611;

/// **The collateral one FCW of provisional weight needs: 6,500 MSK** (half the 13,000 MSK producer
/// floor — so a floor bond holds exactly today's two instant floor claims of weight; ADR-0160 D-1).
pub const PALW_CAPACITY_COLLATERAL_PER_FCW_SOMPI_V1: u64 = 650_000_000_000;

/// **w_FCW — a floor claim's weight reservation, in sompi** (derived PWU × 5 sompi on testnet-12:
/// 0.1075266 MSK). The unit of the per-bond reservation budget `R_budget`.
pub const PALW_CAPACITY_W_FCW_SOMPI_V1: u128 = 10_752_660;

/// The staged weight of an ANCHORED claim (`PanelBound`), in permille of its full weight.
pub const PALW_CAPACITY_ANCHORED_PERMILLE_V1: u16 = 10;

/// The staged weight of an S2 licence (a recount below `PALW_RCORE_FINAL_BASIS_K_V1`: the full-replay
/// seat's `Valid` alone), in permille of its full weight.
pub const PALW_CAPACITY_S2_PERMILLE_V1: u16 = 250;

/// **The C7 ceiling (ADR-0160 D-3): a C7 claim's full weight never exceeds the raw weight of the
/// heaviest ATTRIBUTABLE class, 8k** (229.86 FCW) — until ADR-0153 gives the 2M class a conviction route.
///
/// **Applied to the classes on the C7 list only** (`Params::palw_rcore_conservative_classes`, the
/// mirror — at testnet-12 genesis exactly the 2M row), rcore/cap-s1's stage-1 finding F2: the lane
/// applied it class-blind, and a class-blind constant clips 8k itself whenever 8k's class target sits
/// above the point the constant was measured at — the stage-1 state diff, at the genesis class target,
/// measured 8k's raw weight at 2,777,853,944,832 (20× this) and its `Final` clipped to 1/20, which D-3
/// ("capped at 8k raw weight") does not intend. The list is a params mirror, so
/// [`palw_weight_full_v1`] stays a pure function of the params and the claim record (the reason the lane
/// avoided `palw_rcore_class_is_c7_v1`, which also reads `model_lifecycles`); a long-D class outside the
/// list is not capped (none is open: ADR-0152 §4-quater K-1).
///
/// **It moves nothing for an attributable claim whose raw weight is at or below it — which is a fact
/// about the work floor, not a guarantee.** A model class's pwu is `expected_attempts × derived`, with
/// the attempts `≈ W₀ / CCU` (`palw_effective_class_target_v1` → `palw_work_ticket_target_v1(ccu, W₀)`),
/// so 8k's raw weight scales with `W₀ = escrow · 10⁹ / rate`; this constant IS 8k's raw weight at
/// testnet-12's launch `W₀`, and `W₀` only falls from there with the subsidy schedule. A later change
/// that RAISES `W₀` — a larger worker carve, a lower rate, a slower block rate that raises the per-block
/// subsidy — puts 8k above the constant and clips its `Final` as well: the conservative direction for
/// fork choice, and consistent at all four sites that price a `Final` (`finalize_claim`, `retire_claim`,
/// `reverse_convicted_final`, the load-time re-derivation), but a change such a fence must re-derive this
/// constant for (ADR-0160 §10 D-3).
pub const PALW_CAPACITY_C7_WEIGHT_CEILING_V1: u128 = 138_892_697_241;

/// **The depth, in DAA ticks, within which an all-economic tie is GHOSTDAG's** — an ALIAS of
/// strict-win's [`crate::palw_fork_authority_v2::PALW_REORG_SHALLOW_TIE_DAA_V1`] (rcore/cap-s1: one
/// shallow-tie rule). The lane carried its own copy of the rule behind F-W; the DAA-750 release shipped
/// the same rule as `palw_reorg_strict_economic_win`'s, with the no-DAA-lowering check the copy lacked,
/// and past F-W (which requires strict-win at or below it) that rule answers.
pub const PALW_CAPACITY_SHALLOW_REORG_DAA_V1: u64 = crate::palw_fork_authority_v2::PALW_REORG_SHALLOW_TIE_DAA_V1;

/// The most selected-chain blocks the shallow-tie walk visits — an ALIAS of strict-win's
/// [`crate::palw_fork_authority_v2::PALW_REORG_SHALLOW_TIE_WALK_V1`] (rcore/cap-s1).
pub const PALW_CAPACITY_SHALLOW_REORG_WALK_V1: usize = crate::palw_fork_authority_v2::PALW_REORG_SHALLOW_TIE_WALK_V1;

/// **A claim's weight stage** (ADR-0160 §4.2).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PalwWeightStageV1 {
    /// `Provisional` (never bound, or redrawn): weighs 0.
    Created,
    /// `PanelBound`: [`PALW_CAPACITY_ANCHORED_PERMILLE_V1`] of its full weight.
    Anchored,
    /// `ReceiptLicensed`: `permille` of its full weight — 1000 where the licence counts
    /// (`palw_rcore_counts_licensed_v1`), [`PALW_CAPACITY_S2_PERMILLE_V1`] on an S2 recount, and (lane
    /// verify, future) the covered permille on a sampled door.
    Licensed { permille: u16 },
    /// `Final`: nothing in the immature set; its full weight is in `safe_weight`.
    Final,
    /// `Voided`, or retired: nothing.
    Terminal,
}

impl PalwWeightStageV1 {
    /// The permille of the claim's full weight this stage contributes to its bond's provisional sum.
    pub fn permille(self) -> u16 {
        match self {
            PalwWeightStageV1::Created | PalwWeightStageV1::Final | PalwWeightStageV1::Terminal => 0,
            PalwWeightStageV1::Anchored => PALW_CAPACITY_ANCHORED_PERMILLE_V1,
            PalwWeightStageV1::Licensed { permille } => permille.min(1000),
        }
    }
}

fn stage_of_phase(claim: &PalwClaimStateV2, phase: &PalwClaimPhaseV2) -> PalwWeightStageV1 {
    match phase {
        PalwClaimPhaseV2::Provisional => PalwWeightStageV1::Created,
        PalwClaimPhaseV2::PanelBound { .. } => PalwWeightStageV1::Anchored,
        PalwClaimPhaseV2::ReceiptLicensed { .. } => {
            // `palw_rcore_counts_licensed_v1` reads `claim.phase`; the licence record (`rcore`) is the
            // claim's whatever phase a dispute parked it in, so the recount is asked of the record.
            let counted =
                claim.rcore.licence_door.is_none() || claim.rcore.basis_k >= crate::palw_state_v2::PALW_RCORE_FINAL_BASIS_K_V1;
            PalwWeightStageV1::Licensed { permille: if counted { 1000 } else { PALW_CAPACITY_S2_PERMILLE_V1 } }
        }
        // **An open DA accusation keeps the stage the claim held** (`resumed`, the phase it restores
        // on a refutation). ADR-0160's table lists `DefaultDisputed` beside `PanelBound`, which is the
        // phase most accusations find; reading the resumed phase says the same there and keeps W-I2
        // everywhere: an accusation is not a conviction, so it must not lower live weight (a bonded
        // accuser could otherwise shave an honest chain's weight at will), and a refutation must not
        // raise it.
        PalwClaimPhaseV2::DefaultDisputed { resumed, .. } => stage_of_phase(claim, resumed),
        PalwClaimPhaseV2::Final { .. } => PalwWeightStageV1::Final,
        PalwClaimPhaseV2::Voided { .. } => PalwWeightStageV1::Terminal,
    }
}

/// **The stage of a claim** (a pure function of the record). Agrees with
/// [`palw_rcore_counts_licensed_v1`] on every undisputed licensed claim.
pub fn palw_weight_stage_of_claim_v1(claim: &PalwClaimStateV2) -> PalwWeightStageV1 {
    let stage = stage_of_phase(claim, &claim.phase);
    debug_assert!(
        !matches!(claim.phase, PalwClaimPhaseV2::ReceiptLicensed { .. })
            || (stage == PalwWeightStageV1::Licensed { permille: 1000 }) == palw_rcore_counts_licensed_v1(claim),
        "the Licensed stage is the room's counted-licensed predicate"
    );
    stage
}

/// **Is `claim` accounted under the weight cap?** An ATTEMPT claim accepted at or past the fence's
/// height (the mirror). A free-prompt claim never is: it adds no immature weight (its weight arrives
/// per spent quantum) and its reservation is its own lane's (ADR-0160 E-6).
pub fn palw_weight_cap_applies_v1(params: &PalwStateParamsV2, claim: &PalwClaimStateV2) -> bool {
    matches!(claim.source, PalwClaimSourceV2::Attempt) && params.capacity_weight_cap_applies_at(claim.accepted_daa)
}

/// **W_full(c)** — the claim's full weight in `immature_contribution` units: its stored raw weight
/// (already ADR-0069 D7-gated at acceptance) under the C7 ceiling where the fence applies and the
/// claim's class is on the C7 list ([`PALW_CAPACITY_C7_WEIGHT_CEILING_V1`]), the raw weight itself
/// otherwise.
pub fn palw_weight_full_v1(params: &PalwStateParamsV2, claim: &PalwClaimStateV2) -> u128 {
    if palw_weight_cap_applies_v1(params, claim) && params.rcore_conservative_classes().contains(&claim.class_id) {
        claim.immature_contribution.min(PALW_CAPACITY_C7_WEIGHT_CEILING_V1)
    } else {
        claim.immature_contribution
    }
}

/// **x_c — what a new-rule claim adds to its bond's provisional sum X_b**: `⌊W_full × stage‰⌋`. Zero
/// for a claim the fence does not apply to (an old-rule claim adds its raw weight to the uncapped
/// half of `bounded_immature` instead) and for every terminal or `Final` claim.
pub fn palw_staged_weight_v1(params: &PalwStateParamsV2, claim: &PalwClaimStateV2) -> u128 {
    if !palw_weight_cap_applies_v1(params, claim) {
        return 0;
    }
    let full = palw_weight_full_v1(params, claim);
    match palw_weight_stage_of_claim_v1(claim) {
        PalwWeightStageV1::Licensed { permille: 1000 } => full,
        stage => full.saturating_mul(u128::from(stage.permille())) / 1000,
    }
}

/// **W_cap(b)** — the most provisional weight a bond of `collateral_sompi` can put into fork choice:
/// `⌊C / 6,500 MSK⌋` floor-claim weights. Class-neutral (ADR-0160 D-2).
pub fn palw_bond_weight_cap_v1(collateral_sompi: u64) -> u128 {
    u128::from(collateral_sompi / PALW_CAPACITY_COLLATERAL_PER_FCW_SOMPI_V1) * PALW_CAPACITY_FCW_V1
}

/// **R_budget(b)** — the most weight reservation a bond of `collateral_sompi` holds across its live
/// new-rule claims: `⌊C / 6,500 MSK⌋ × w_FCW` (0.215 MSK at 13k, 1.61 at 100k, 16.45 at 1M).
pub fn palw_bond_weight_budget_sompi_v1(collateral_sompi: u64) -> u128 {
    u128::from(collateral_sompi / PALW_CAPACITY_COLLATERAL_PER_FCW_SOMPI_V1) * PALW_CAPACITY_W_FCW_SOMPI_V1
}

/// **The capped consensus reservation**: `min(raw_w, budget − held)`, never negative. `raw_w` is the
/// reservation the claim would take below the fence (`exposure_pwu × slash_value × attempts`).
pub fn palw_capped_weight_reservation_v1(raw_w: u128, budget: u128, held: u128) -> u128 {
    raw_w.min(budget.saturating_sub(held))
}

/// **The weight reservation a claim accepted at `accepted_daa` on `bond` takes** — the ONE reading the
/// fold's `apply_attempt`, the admission ceiling (`palw_admission_v2`) and the producer's headroom
/// (`palw_producer_facts_v4`) share (ADR-0152 SR-7), so the gate can never admit a claim the ledger
/// would record at a different number. Below the fence (every shipped preset) it is `raw_w` itself;
/// past it `⌈raw_w / ρ⌉` at `accepted_daa`'s ρ ([`palw_claim_weight_reservation_of_v1`]).
pub fn palw_claim_weight_reservation_v1(
    state: &PalwChainStateV2,
    params: &PalwStateParamsV2,
    bond: &PalwBondKeyV2,
    raw_w: u128,
    accepted_daa: u64,
) -> u128 {
    let collateral = state.bond(bond).map(|record| record.collateral).unwrap_or(0);
    palw_claim_weight_reservation_of_v1(params, collateral, state.capacity_weight_index().bond(bond).reserved_w, raw_w, accepted_daa)
}

/// [`palw_claim_weight_reservation_v1`] over a bond record the caller already resolved — the admission
/// gate's bootstrap bond (a registration the parent state does not hold yet) has no row in the state.
/// **Stage 1 (rcore/cap-s1): `⌈raw_w / ρ⌉`** with ρ the F-L ramp's step at `accepted_daa`
/// ([`palw_capacity_rho_at_v1`]; 1 where F-L is not in force), so the reservation is today's at ρ = 1
/// and the bond's collateral and held reservation no longer enter it (the module's stage-1 note: the
/// withdrawn `min(w, R_budget − held)` raised a model class's issuance at ρ = 1). The two arguments are
/// kept so the three SR-7 sites keep one signature.
pub fn palw_claim_weight_reservation_of_v1(
    params: &PalwStateParamsV2,
    _collateral_sompi: u64,
    _held: u128,
    raw_w: u128,
    accepted_daa: u64,
) -> u128 {
    if !params.capacity_weight_cap_applies_at(accepted_daa) {
        return raw_w;
    }
    raw_w.div_ceil(u128::from(palw_capacity_rho_at_v1(params, accepted_daa)))
}

/// **ADR-0160 stage 3 (F1): what `G`'s weight term needs of the params, in a `Copy` form** — F-W's
/// height and F-L's schedule (at most [`crate::palw_aggregate_liability_v1::PALW_CAPACITY_MAX_STEPS_V1`]
/// steps), so every reader of a claim's fraud gain — the fold, the panel draw's seat filter, admission,
/// the producer's facts, the shadow — scales it alike without holding the params.
///
/// **Why** (stage 1's finding F1): F-W reserves `⌈w/ρ⌉` for an attempt claim accepted past it, and every
/// `G` read the reservation as the claim's weight term — at ρ > 1 an uncredited claim's seat lock and
/// every conviction's `L` would have fallen by ρ with it, and AS-2's credited discount would have applied
/// twice. A fraudulent `Final` inserts the claim's WEIGHT, not its collateral reservation, so `G` reads
/// `reserved × ρ` (≥ `w`, the ceiling's rounding up): today's at any ρ, and AS-2 alone discounts a
/// credited claim's lock. At ρ = 1 — every shipped preset, and stage 1 — the scale is 1, byte for byte.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct PalwCapacityGainScaleV1 {
    weight_cap_from: Option<u64>,
    liability_from: Option<u64>,
    steps: [(u64, u32); crate::palw_aggregate_liability_v1::PALW_CAPACITY_MAX_STEPS_V1],
    len: u8,
}

impl PalwCapacityGainScaleV1 {
    /// The scale `params` define (the identity where F-W or F-L is not armed).
    pub fn of(params: &PalwStateParamsV2) -> Self {
        let mut scale = Self { weight_cap_from: params.capacity_weight_cap_from_daa(), ..Self::default() };
        if let Some(value) = params.capacity_liability()
            && value.activation != crate::config::params::ForkActivation::never()
        {
            scale.liability_from = Some(value.activation.daa_score());
            for (slot, step) in scale.steps.iter_mut().zip(value.steps.iter()) {
                *slot = (step.from_daa, step.rho.max(1));
            }
            scale.len = value.steps.len().min(crate::palw_aggregate_liability_v1::PALW_CAPACITY_MAX_STEPS_V1) as u8;
        }
        scale
    }

    /// **The ρ F-W divided `claim`'s reservation by** — its acceptance DAA's step for an ATTEMPT claim
    /// accepted past F-W ([`palw_claim_weight_reservation_of_v1`]'s own condition and ρ), 1 otherwise.
    pub fn scale_of(&self, claim: &PalwClaimStateV2) -> u32 {
        let accepted = claim.accepted_daa;
        if !matches!(claim.source, crate::palw_state_v2::PalwClaimSourceV2::Attempt)
            || self.weight_cap_from.is_none_or(|from| accepted < from)
            || self.liability_from.is_none_or(|from| accepted < from)
        {
            return 1;
        }
        self.steps[..usize::from(self.len)].iter().rev().find(|(from, _)| *from <= accepted).map_or(1, |(_, rho)| *rho)
    }

    /// **`G`'s weight term for `claim`**: `reserved × ρ` (today's `reserved` at ρ = 1).
    pub fn gain_reserved(&self, claim: &PalwClaimStateV2) -> u128 {
        claim.reserved.saturating_mul(u128::from(self.scale_of(claim)))
    }
}

/// **ρ in force at `daa`** — the F-L ramp's step there (`Params::palw_capacity_aggregate_liability`),
/// at least 1; 1 where the fence is not armed or not yet active (every shipped preset). The one reading
/// every stage-1 ρ-scaled capacity term shares: the weight reservation, the class room and the
/// per-bond share (`palw_state_v2`'s F-R clamp).
pub fn palw_capacity_rho_at_v1(params: &PalwStateParamsV2, daa: u64) -> u32 {
    params.capacity_step_at(daa).map_or(1, |step| step.rho.max(1))
}

/// **The `safe_weight` a `Final` claim contributes, under the C7 ceiling (ADR-0160 D-3).** `contribution`
/// is today's (`palw_claim_safe_contribution_v3`: its pwu or derived work, D7-gated); a new-rule claim
/// whose raw weight passed the ceiling contributes the same fraction of it that its full weight is of
/// its raw weight, so the ceiling holds in whichever unit `safe_weight` is kept. A claim at or under the
/// ceiling (every attributable class at the launch work floor), and every old-rule claim, is returned
/// `contribution` unchanged. A pure function of the claim record and the mirror, so the FOUR sites that
/// move a `Final`'s weight agree: `finalize_claim` adds it, `retire_claim` moves it to the retired
/// total, `reverse_convicted_final` (a DA-7 default at `FinalRow`, a post-`Final` conviction) takes it
/// back, and the load-time re-derivation sums it. A site that priced it any other way would strand the
/// difference in `safe_weight` — or, subtracting the unscaled amount, saturate it to zero.
pub fn palw_weight_final_safe_v1(params: &PalwStateParamsV2, claim: &PalwClaimStateV2, contribution: u128) -> u128 {
    let raw = claim.immature_contribution;
    let full = palw_weight_full_v1(params, claim);
    if raw == 0 || full >= raw {
        return contribution;
    }
    match contribution.checked_mul(full) {
        Some(product) => product / raw,
        None => (contribution / raw).saturating_mul(full),
    }
}

/// **One bond's row of the derived index**: the staged provisional weight of its live new-rule claims
/// (X_b) and the weight reservation they hold (Σ reserved).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct PalwBondWeightV1 {
    pub staged: u128,
    pub reserved_w: u128,
}

impl PalwBondWeightV1 {
    fn is_empty(&self) -> bool {
        self.staged == 0 && self.reserved_w == 0
    }
}

/// **The per-bond weight index** — derived from the claims, excluded from `state_root`, never
/// carried: a row exists exactly while its bond has a live new-rule claim with a non-zero staged
/// weight or reservation, so the index a fold maintains and the one a load rebuilds are EQUAL, not
/// merely equivalent (`PalwChainStateV2: PartialEq` compares them).
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct PalwBondWeightIndexV1(BTreeMap<PalwBondKeyV2, PalwBondWeightV1>);

impl PalwBondWeightIndexV1 {
    /// The index of a claim set, from nothing else (the rebuild every load and delta path runs).
    pub fn of<'a>(params: &PalwStateParamsV2, claims: impl Iterator<Item = &'a PalwClaimStateV2>) -> Self {
        let mut index = Self::default();
        if params.capacity_weight_cap_from_daa().is_none() {
            return index;
        }
        for claim in claims {
            index.note(params, claim, true);
        }
        index
    }

    /// A bond's row (zero when it has none).
    pub fn bond(&self, bond: &PalwBondKeyV2) -> PalwBondWeightV1 {
        self.0.get(bond).copied().unwrap_or_default()
    }

    /// Every row, in bond order.
    pub fn iter(&self) -> impl Iterator<Item = (&PalwBondKeyV2, &PalwBondWeightV1)> {
        self.0.iter()
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    /// Add (`add`) or remove one claim record's contribution. Removal saturates at zero — which an
    /// index consistent with its claims never needs (W-I6), and which the load-time comparison would
    /// refuse if it ever did.
    pub(crate) fn note(&mut self, params: &PalwStateParamsV2, claim: &PalwClaimStateV2, add: bool) {
        if !palw_weight_cap_applies_v1(params, claim) {
            return;
        }
        let staged = palw_staged_weight_v1(params, claim);
        let reserved = if claim.phase.is_terminal() { 0 } else { claim.reserved };
        if staged == 0 && reserved == 0 {
            return;
        }
        let row = self.0.entry(claim.bond).or_default();
        if add {
            row.staged = row.staged.saturating_add(staged);
            row.reserved_w = row.reserved_w.saturating_add(reserved);
        } else {
            debug_assert!(row.staged >= staged && row.reserved_w >= reserved, "W-I6: the index holds what it releases");
            row.staged = row.staged.saturating_sub(staged);
            row.reserved_w = row.reserved_w.saturating_sub(reserved);
        }
        if row.is_empty() {
            self.0.remove(&claim.bond);
        }
    }

    /// **`min(X_b, W_cap(C_b))`** — what `bond` contributes to `bounded_immature`, for a bond holding
    /// `collateral` (`None`: the registry holds no such bond, so it carries no cap).
    pub fn term(&self, bond: &PalwBondKeyV2, collateral: Option<u64>) -> u128 {
        let staged = self.bond(bond).staged;
        if staged == 0 {
            return 0;
        }
        staged.min(collateral.map(palw_bond_weight_cap_v1).unwrap_or(0))
    }

    /// `Σ_b min(X_b, W_cap(C_b))` over every row, the bonds' collateral read from `state`.
    pub fn capped_total(&self, state: &PalwChainStateV2) -> u128 {
        self.0.keys().map(|bond| self.term(bond, state.bond(bond).map(|record| record.collateral))).fold(0u128, u128::saturating_add)
    }
}

/// **The re-derivation of `bounded_immature`** (W-I3): `Σ_{live old-rule claims} raw +
/// Σ_b min(X_b, W_cap(C_b))`, from the claims and the bonds alone. Below the fence (every shipped
/// preset) this is today's sum of every live claim's `immature_contribution`.
pub fn palw_bounded_immature_v2(state: &PalwChainStateV2, params: &PalwStateParamsV2) -> u128 {
    let old_rule: u128 = state
        .claims_iter()
        .filter(|(_, claim)| !claim.phase.is_terminal() && !palw_weight_cap_applies_v1(params, claim))
        .map(|(_, claim)| claim.immature_contribution)
        .fold(0u128, u128::saturating_add);
    let index = PalwBondWeightIndexV1::of(params, state.claims_iter().map(|(_, claim)| claim));
    old_rule.saturating_add(index.capped_total(state))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// ADR-0160 §4.2 and Appendix A, from the constants alone.
    #[test]
    fn the_cap_and_the_budget_are_the_adrs_numbers() {
        const MSK: u64 = 100_000_000;
        assert_eq!(PALW_CAPACITY_FCW_V1, 279 * 21_657_728 / 10, "FCW = ⌊0.1 × 279 × 21,657,728⌋");
        for (collateral_msk, fcw, budget) in [
            (6_499, 0, 0),
            (6_500, 1, 10_752_660),
            (13_000, 2, 21_505_320),
            (100_000, 15, 161_289_900),
            (1_000_000, 153, 1_645_156_980),
        ] {
            assert_eq!(palw_bond_weight_cap_v1(collateral_msk * MSK), fcw * PALW_CAPACITY_FCW_V1, "{collateral_msk} MSK");
            assert_eq!(palw_bond_weight_budget_sompi_v1(collateral_msk * MSK), budget, "{collateral_msk} MSK");
        }
        // A genesis card (939,063 MSK) holds 144 FCW.
        assert_eq!(palw_bond_weight_cap_v1(939_063 * MSK) / PALW_CAPACITY_FCW_V1, 144);
        // The budget at 13k is 0.215 MSK: a 2M claim's reservation falls from 59,742.94 MSK to at most that.
        assert!(palw_bond_weight_budget_sompi_v1(13_000 * MSK) <= 21_505_320);
        assert_eq!(palw_capped_weight_reservation_v1(5_974_294_206_820, 21_505_320, 0), 21_505_320);
        assert_eq!(palw_capped_weight_reservation_v1(10_752_660, 21_505_320, 10_752_660), 10_752_660, "the second floor claim");
        assert_eq!(palw_capped_weight_reservation_v1(10_752_660, 21_505_320, 21_505_320), 0, "the third takes nothing");
        assert_eq!(palw_capped_weight_reservation_v1(10_752_660, 21_505_320, u128::MAX), 0, "never negative");
        // The ceiling is 8k's raw weight, 229.86 FCW.
        assert_eq!(PALW_CAPACITY_C7_WEIGHT_CEILING_V1 * 100 / PALW_CAPACITY_FCW_V1, 22_985);
    }

    /// The shallow-tie depth is a slot race with the lead cap's burst (two ticks), and the walk that
    /// finds it covers any honest chain's blocks in that many ticks many times over.
    #[test]
    fn the_shallow_tie_depth_is_a_slot_race() {
        assert_eq!(PALW_CAPACITY_SHALLOW_REORG_DAA_V1, 2);
        assert!(PALW_CAPACITY_SHALLOW_REORG_WALK_V1 as u64 >= 8 * (PALW_CAPACITY_SHALLOW_REORG_DAA_V1 + 1));
    }
}
