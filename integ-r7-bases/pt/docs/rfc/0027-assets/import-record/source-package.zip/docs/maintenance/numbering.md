# 文書番号の台帳

既存主文書は再採番していません。2026-10-20のローカル提案として **ADR-0193 / RFC-0027** を追加し、次のローカル候補は **ADR-0194 / RFC-0028** とします。添付ZIP内の既存本体の最大番号は0186/0026、会話にあるADR-0192本体は未同梱です。0192を再利用・捏造せず、他ブランチの予約・重複は統合前に確認します。0181/0021は設計凍結、0182/0022は画像・動画・改善の延期という既存記録を保持します。[機械可読版](number-registry.json)。

## 既存の衝突

### ADR-0026

- [0026-current-palw-testnet11-architecture.md](../adr/0026-current-palw-testnet11-architecture.md)
- [0026-palw-v2-runtime-separated-verification.md](../adr/0026-palw-v2-runtime-separated-verification.md)

### ADR-0173

- [0173-a-seat-holds-a-root-not-a-class-and-possession-gates-activation.md](../adr/0173-a-seat-holds-a-root-not-a-class-and-possession-gates-activation.md)
- [0173-public-verifier-dispute-completeness-is-misaka-purpose.md](../adr/0173-public-verifier-dispute-completeness-is-misaka-purpose.md)

## 既存台帳が記録した欠番（2026-10-17の記録を保持）

**ADR:** 0048, 0104, 0113, 0156, 0157, 0158, 0159, 0164。内容を捏造して補いません。

**RFC:** なし。内容を捏造して補いません。

2026-10-20の追加時点で0183–0185、0187–0192の本文はこのZIPにありません。他branchの割当状況は未確認で、これらを未使用として再割当しません。会話の0192は外部参照としてのみ記録します。

## 補助文書・仕様章

RFC-0010/0012のdormant implementationは主RFCではなくdesignへ移しました。旧新パスは [対応表](path-map.md)。Specの18番は以下の別章が共有するため、完全パスで区別します。

- [18-inference-surface.md](../spec/palw/18-inference-surface.md)
- [18-layer-sharded-panels.md](../spec/palw/18-layer-sharded-panels.md)
- [18-verification-certificates.md](../spec/palw/18-verification-certificates.md)
