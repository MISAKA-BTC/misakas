# RFC-0006: PALW layer-sharded panels — bounded cell verification from authenticated boundaries, with independent public-verifier localization and exact court on dispute

> **Status update 2026-10-08 (supersedes every "dormant" / "None on every preset" wording below that predates it):** `palw_tir_shard_v1` is **ARMED on testnet-12 at the int-11/12 flag day, DAA 5,300** (`PALW_T12_INT11_FENCES_V1`); it stays dormant on every other preset. Fold, cells, receipts by parts, the exact court (`TirShardCourtAccused`, any Active bond) and the kaspad e2e are IMPLEMENTED_AND_TESTED; per-segment resource pricing, a non-seat public cell watcher, a processor-level reorg/duplicate-receipt test, the V3 per-shard draw and the D-S1…D-S6 drill evidence are open (`docs/design/palw/remaining-rfc-integration-matrix.md`). Any change to an armed rule needs a new versioned fence.
>

> **Implementation update 2026-10-11:** The non-seat watcher, dormant segment-resident pricing and per-shard V3 engine are implemented; their implementation is not activation approval. V3 restore now derives its seal/entropy commitments and retains the verified output after shared-epoch pruning under explicit engine carriage version 2. Live shard v1 at DAA 5,300 is preserved. See [SHARD §1.4](../design/palw/shard-rfc6-10.md#14-restore-time-seal-and-entropy-provenance-2026-10-11) and the [four-RFC audit](../design/palw/rfc-0006-0007-0008-0012-design-audit-2026-10-10.md). D-S drill, public source/soundness, economic and worst-resource approvals remain open.
>

> **Spec closures 2026-10-15:** normative rules and named parameters for R6-CELL/DRAW/OUTSIDE/PRICE/MIGRATION and ALL-MODEL are in [Spec closures — 2026-10-15](#spec-closure-2026-10-15). No PASS, activation or change to live v1 is implied.
>

> **PALW共通前提 — 2026-10-10:** [ADR-0176](../adr/0176-bond-bounds-palw-production-rewards-and-final-weight.md)を適用する。確率的検証・公開反証・客観裁定に加え、bondと共通DAA期間がclaim発行能力、ブロック数、報酬総額、Final後の確定weightの上限を決める。
> モデル計算はその枠を使用するための正当な仕事であり、同額bond・同期間・同倍率なら計算省略や高速偽造で枠は増えない。有罪なら報酬失効と適用規則上の担保損失を負う。claim容量の倍率を上げてもbond当たりの総経済・consensus creditは増やさない。
> 将来のPALW設計・受入条件に適用し、過去の実測・実装記録・旧claim規則は保持する。上限は検出能力の証明ではなく、公開検証・徴収可能担保・責任保持・独立試験と明示的upgrade/activationを要する。
> **モデル入手への不介入 — 2026-10-10後続改定:** [ADR-0177](../adr/0177-model-bond-allocation-without-availability-consensus.md)を優先する。MISAKA Torrent・専用Seeder・Seeder報酬の概念を廃止する。モデル配布・取得可否を合意で管理せず、PoR/全量取得監査/TRDC/FPRによる資格・weight停止も撤回する。モデル別coinbaseは重複のない拘束miner bond元本に連動し、総発行予算と個別bond上限を維持する。
> 固定モデル同一性とclaim固有証拠の裁定は維持する。外部検証は正しいモデルを入手できた条件で成立し、公開参加の経済優位は倍率式・敵対的評価で立証する未完の目標である。過去の実装/試験/旧規則は保持し、新配分は未実装・未有効化である。


> **2026-10-07 中核目標・設計の優先規則:** [ADR-0173](../adr/0173-public-verifier-dispute-completeness-is-misaka-purpose.md)を適用する。普通の非Panel public bondが、producer秘密状態なしにpublic authenticated materialから不正をlocalizeしobjective convictionまで完結できることを目指す。衝突する将来設計は末尾のmission alignment amendmentで改定する。既存Status・実装記録・fenceは履歴として保持し、この追記は実装完了やactivationを意味しない。


| Field | Value |
| --- | --- |
| Status | Revised Draft, 2026-10-10後続改定 — off-chain model acquisition; model-bond coinbase allocation and conditional prosecution; historical implementation/measurements retain scope; new economics/implementation/activation pending |
| Author(s) | MISAKA core (drafted with Claude, lane M3) |
| Created | 2026-10-01 |
| Normative dependencies | RFC-0002 (PALW-TIR v1: commit points, cones, the step space of an IR class, the IR one-move court) |
| Affects | spec/palw 04b (§10: a cell), 07 (licence by parts, Final), 08 (draw, receipts, quorum, recount, outsider), 10 (locks and pay per cell), 16 (fences) · IR classes only, all networks (dormant until armed) · `consensus/core` (`palw_shard_panel_v1`, `palw_panel_v2`, `palw_state_v2`, `palw_verification_v2`, `palw_receipt`, `palw_tir_class_v1`), kaspad's panel worker, `misaka-palw-tir-exec` (a cell verifier) |
| Branch | `rfc6/gpu-shard` (text; an off-chain prototype in `experiments/palw-tir-gpu/tests/layer_shard.rs`) |
| Related | ADR-0098 (coverage is a number), **ADR-0099 / ADR-0100** (a seat holds a shard: the plan, the stratified draw, `ShardCourtAccused`, `ShardReceiptLicensed` — built for legacy classes, dormant), ADR-0103 (held context; D2 interval, D7 a seat holds a shard of the model and its state), ADR-0111 (leaf demand), ADR-0062 (DA court), ADR-0117 (a draw is one forward), ADR-0133 (verification is its own clock; segment-scoped receipts), **ADR-0147** (independence is drawn: the outsider seat), ADR-0152 (Q-1…Q-7, `basis_k`), ADR-0160 (claim capacity), RFC-0002 Phase F (`TirShardCourtAccused`, `TirStepLeaf`/`TirStepNode`), **RFC-0007** (lane M4: batched verification certificates and algebraic checks — receipt aggregation and cheaper per-shard checks are its subject, not this RFC's), `docs/design/palw/tir/gpu-integer-backend.md` |

## Current verification boundary — 2026-10-06

The cell partition, authenticated boundaries and exact localization baseline below remain useful.
For new probabilistic profiles, [RFC07 Part V](0007-palw-verification-certificates-and-algebraic-checks.md)
and [RFC11 §15](0011-permissionless-model-and-long-context-onboarding.md) replace routine whole-cell
replay with approved small constraint checks. [ADR0172](../adr/0172-model-extensibility-uses-versioned-kernels-not-a-universal-vm.md)
requires versioned kernels/typed plans, not a model VM or arbitrary circuit interpreter.

Each receipt binds class/kernel/plan/suite, checked scope, openings and transcript. Tally coverage
includes all required relations, initial/output state, cross-cell boundaries, memory and routing,
with composed whole-claim soundness. Randomly selecting a few raw cells is insufficient: one faulty
cell is found only with its selection probability even if its checker is perfect. The first-
divergence replay lemma below is a localization/conformance baseline, not algebraic-check soundness.
A cell checker needs reviewed relation binding, integer/field rules, sparse-error bounds and an exact
bounded court path. Missing evidence/scope, DA failure or silent seats cannot produce Final. Legacy
replay claims keep their old rules; a new receipt/coverage profile needs a separately reviewed fence.

## 概要(日本語)

- **問題。** claim の throughput を縛っているのは検証の供給(panel の receipt)。t12 の backlog(10-01)では未 licence の
  claim が 340 → 820 に増え、licence 数は 50 DAA あたり 273 → 60 に落ちた。供給は 600 receipt/h、需要は 380〜640/h で、
  余裕が無かった。今の seat は claim の job を **丸ごと** replay する(SEAT-R)。だから seat は「モデル全体+その job の
  KV」を ledger に予約できなければ席に着けず、replay 枠(2)は数十分ふさがる。モデルが大きくなるほど、検証できる host は
  減り、1 件あたりの検証も長くなる。
- **IR class では、層の区間 × 位置の区間(cell)を、commit 済みの値だけで検証できる。** PALW-TIR は block の carry-out
  (層の境界の行)、History の行、Fixed state の checkpoint を **すべて step leaf として commit** している(NF-20/21、
  phase-f §2.5)。だから層 `[a, b)` × 位置 `[p, q)` の seat が必要とするのは次だけ:
  - 位置ごとの層 `a` の入力(前の occurrence の carry-out)
  - 位置 `p` より前の、自分の層の K/V 行
  - 位置 `p` の state checkpoint
  - **自分の層の重みだけ**

  これらを step root に対して開き、cell 内のすべての commit point を再計算して照合する。
- **検出の補題。** honest な実行と最初に食い違う commit 値 `v` を考える。`v` の cone の入力はすべて `v` より前にあるので
  honest な値であり、再計算すると honest な値が出て、commit された `v` と食い違う。つまり **嘘は、`v` を含む cell を
  全対象commit pointを検査する verifier に見える**。この補題は、必要な認証materialを実際に取得して全対象を照合した場合に限る。honest seatの存在だけで検出を保証しない。境界の不正も、その境界を生成したcellの検査で扱う。
  既存IR one-move court(`TirShardCourtAccused`、tag 62)とH縮約のdissectionは裁定の土台である。ただし、普通の非Panel public bondが公開openingから証拠を生成して提出できるかは別gateであり、取得・局所化・terminal filingに不足があれば追加実装が必要である。
- **panel。** 既存の S1(segment・full seat + partial seat・segment ごとに 2 attest・mask 付き receipt)を
  **層 shard ごとに** 回す。cell = (層 shard, S1 segment)。
- **legacy の shard 設計(ADR-0099/0100、休眠)を t12 で止めていた二つの blocker を解く。**
  - ① R-core+ の `basis_k` 再集計に「部分 licence」の規則が無い → `basis_k` を cell 上で数える(Q-3 の自然な一般化)。
  - ② 層別の draw に outsider がいない(ADR-0147)→ **shard ごとに outsider を 1 席**、network 全体から引く。outsider が
    shard の重みだけを取ってきて検証できるのは、本 RFC の検証がモデル全体を要しないから。これは ADR-0147 §3 が
    「漏れを塞ぐもの」として名指ししたもの(モデルを持たずに claim を検証できる outsider)そのもの。
- **何が増えるか(1.5B、4 shard)。**
  - seat が持つ重みは全体の 26 %(最も重い shard)。
  - 層の境界転送は 1 位置 6 KiB。
  - 検証は 1 位置ずつの逐次 replay から、**層ごとに全位置まとめての GEMM** に変わる。GPU 実測で ×11〜19(同じ device の
    逐次比、256〜512 位置)、CPU kernel の逐次比で ×40 以上。
  - claim あたりの replay 量は 5 full replay(SEAT-R)から 2 replay 相当(cell ごとに 2 attest)に減る。
- **費用。** 1 claim の receipt が shard 数倍になる(4 shard で約 77 KB)。receipt の集約は RFC-0007 の主題。
- **有効化。** 休眠 fence `palw_tir_shard_v1` を 1 本(Some-only hash、`never()` collapse、未使用の高さ)。fence を跨ぐ
  drill(cell の嘘・境界行の隠匿・shard だけ持てる seat)を出荷 binary で回してから。
- **prototype(D4、実装済み)。** 小さな TIR fixture を producer として 1 回実行し、trace を Merkle root に commit する。
  層 `[a, b)` × 位置区間の cell を、root に対して開いた境界行・過去の History 行・checkpoint と、その層の重みだけで
  検証する(参照評価器の `eval_cone`)。
  - honest trace は全 cell が受理する。cell 内の改ざんは、その cell がその leaf で検出する。
  - 境界行の「つじつま合わせ」の嘘は、下流 cell が素通しし、上流 cell が検出する(補題どおり)。
  - state の嘘は、それを書く segment が checkpoint で検出する。
  - 8 層 4 shard では、1 cell が持つ重みは 25〜27 %、読む trace は 0〜1.6 %、照合するのは 1/8(§9)。

## Summary

A panel seat of an IR class today replays the claim's whole job. It must hold the whole model and the
job's whole history, and its replay is a sequence of single-position steps. This RFC lets a seat verify
a **cell** of a claim instead: a contiguous range of layers crossed with a position segment. It reads
only committed material: the carry-in of its first layer at every position of the segment, its own
layers' history rows before the segment, their state checkpoint at the segment's start, and **its own
layers' weights**. It recomputes every commit point inside the cell, as one batched pass per layer over
the segment's positions.

The **first-divergence lemma** (§2) applies when a verifier obtains authenticated material and checks every relevant commit point in the cell. It does not guarantee detection merely because an honest seat exists. Existing `TirShardCourtAccused` and dissection kernels provide a terminal-court baseline; an ordinary non-Panel public bond must also be able to acquire evidence, localize and file a bounded exact proof. Missing acquisition or prover capability requires additional work under RFC14.

The panel is ADR-0100's stratified panel, with three additions:

- Verification V2's S1 segments run inside each layer shard.
- An **outsider per shard**, drawn from the network as ADR-0147 draws one per claim.
- A **recount over cells**: `basis_k` is counted over cells instead of whole segments.

The last two remove the two refusals that keep ADR-0100's sharded licensing off testnet-12. Everything
sits behind one dormant fence.

## Motivation

### 1. Verification supply is the binding limit of claim throughput

On testnet-12 the panel, not the producers, decides how many claims become Final. The 2026-10-01
backlog (`docs/design/palw/t12-panel-backlog-1001.md` on `rcore/int-10-p1`):

- Open claims rose from ~340 to ~820 between DAA ~2,600 and ~3,090, while issuance rose from 0.6 to
  5.3 claims a DAA.
- `panel_bound` stood at 261 against ~17 in normal running.
- Licences per 50 DAA fell 273 → 126 → 60 while binds held at ~290.

Two node faults caused it:

- Two hosts' ledgers counted mimalloc's lazily-freed pages as used and refused every duty.
- One overcommitted host ran replays of 7–50 minutes instead of ~5 seconds. An 8k replay reserved 3.37
  of its seat's 3.5 GiB and held one of the seat's two replay slots for most of an hour, on seats drawn
  into 65 % of panels.

The faults are fixed (int-10.1, int-11), but the margin is not. Supply was ~600 receipts an hour against
demand of 380–640.

The structure behind the margin is what this RFC changes:

- **A seat replays the whole job.** Under SEAT-R a seat signs `Valid` only for arithmetic it ran
  itself. So on testnet-12 the full seat, every partial seat outside C7 and the outsider all replay the
  claim's whole job (`kaspad/src/palw_panel.rs:220-243`). A claim on the coverage door costs about five
  replays.
- **A seat must hold the whole model.** Readiness is filed only if a FULL-seat replay fits the ledger
  (`palw_panel.rs:4144-4151`). A partial seat must hold the whole model too, and the K/V prefix up to its
  segment's end (`palw_resource_profile_v1.rs:262-263`).
- **A replay is sequential.** A replay is one position at a time. On a device that is a chain of
  matrix–vector products, and the shape that wastes most of a GPU: §8 measures a batch of 256–512
  positions through the same weights at 11–19× the per-position speed on the same device.

Every larger class makes all three worse. A Qwen2.5-32B-shaped IR class is ~30.5 GiB of `i8` weights,
and a Llama-3-70B shape ~65.7 GiB (§8). No testnet-12 seat holds either, so no seat can replay them,
and supply for them is zero.

### 2. What already exists

ADR-0099 and ADR-0100 designed seats that hold a shard, for legacy classes, and built most of it
consensus-inert:

- a shard is a contiguous layer range, and the plan is derived (min–max of the widest seat; embedding
  first, logits last);
- a stratified panel (`derive_stratified_panel_v2`), with bonds declaring their shards
  (`BondShardsDeclared`) and the registrant declaring the count (`ClassShardPlanDeclared`);
- the one-move court a shard seat files (`ShardCourtAccused`);
- licensing by parts (`ShardReceiptLicensed`, a progress bitmap, the licence on the last part).

All of it is behind `palw_shard_court` and `palw_shard_licensing`, dormant everywhere.

PALW-TIR (RFC-0002) supplies the rest:

- **IR claims commit exactly what a shard reads.** Every block carry-out — the residual between layers
  — is a commit point (NF-21). So is every `HistAppend` row (NF-20). `Fixed` state is committed every
  `C` positions and `Hist` rows every `h_tile` positions, as leaves of the one step tree (phase-f §2.5).
  "Every leaf is adjudicated from leaves that precede it."
- **The court an IR shard seat needs is armed on testnet-12.** `TirShardCourtAccused` (tag 62, under
  `palw_tir_v1`) carries an IR close proof and is adjudicated by `adjudicate_close_proof_v2`. A leaf
  that reduces over the history opens an F7 dissection session.
- **The DA units for an IR leaf are scheduled.** `TirStepLeaf` and `TirStepNode` come with
  `palw_tir_fence2` at DAA 3,600.

**What is missing** is the verification mode, a seat checking a cell from committed rows, and two rules
that `validate_palw_v2` names as the reasons sharded licensing may not be armed on testnet-12:

1. *"palw_rcore_plus is armed beside palw_shard_licensing: Q-3's basis recount has no rule for a licence
   by parts"* (`config/params.rs:7116-7121`);
2. *"palw_admission_independence is armed beside palw_shard_licensing: a stratified panel seats no
   outsider, so a bought class licensed by parts would be judged by its own population alone (ADR-0147)"*
   (`config/params.rs:4174-4188`).

ADR-0147 §3 also names what closes its own residual: *"an outsider that can check a claim WITHOUT holding
the model"*. A cell check is that.

## Goals and non-goals

**Goals.**

- G1. A seat verifies a cell of an IR claim with nothing but committed material and its own layers'
  weights; no seat needs the whole model.
- G2. A lie anywhere in a claim is detected by the seat holding the cell where it is computed, and
  convicted by the court that exists.
- G3. The panel keeps today's guarantees per cell: two attestations per cell, the recount, and an
  outsider who is not the class's population.
- G4. Verification becomes batched over positions (a layer at a time), the shape both a CPU and a GPU
  run fastest.
- G5. One dormant fence; no change to any legacy class, any receipt below the fence, or any fingerprint
  while dormant.

**Non-goals.**

- Legacy classes (ADR-0099/0100 stay as they are).
- Receipt aggregation, Narwhal-style certificates, or algebraic shortcuts (Freivalds, weight sketches) —
  RFC-0007's subject. Its cheaper per-shard checks would plug in as a verification mode of a cell
  without changing anything here.
- Splitting a single layer across seats (tensor parallelism).
- Changing what a producer computes or commits: **no new commitment**. The cell is a reading of the step
  tree that exists.

## 1. Cells

### 1.1 The layer plan (derived, as ADR-0099 Decision 2)

An IR class's program has occurrences `o_0 = pre`, `o_(1+l)` for layers `l ∈ [0, L)`, and
`o_(L+1) = post` (spec 04b §3.3). A **layer plan** of `S_L` shards is the contiguous partition of
`[0, L)` that minimises the widest shard's **weight**:

- the bytes of every per-layer param instance its layers read;
- plus the bytes of every global param its layer blocks read (RoPE tables, a shared expert), counted on
  every shard that reads it;
- plus the `Hist` and `Fixed` state its layers hold at the class's `max_context` (the history in lanes,
  4 bytes a value — what a seat holds).

`pre` and its global params ride with shard 0 and `post` with shard `S_L − 1`, as ADR-0099 pins the
embedding and the logits. The plan is a pure function of the registered program and `S_L`, so two
nodes derive the same plan. `S_L` is the class's, declared once by its registrant (`ClassShardPlanDeclared`,
ADR-0100 Decision 4; for an IR class it carries `S_L` and `S_P`, below) and immutable.

### 1.2 Position segments

A job of `T` positions (absolute positions `a = 0 … T−1`, phase-f §2.5) is cut into `S_P` segments at
multiples of `G = lcm(C, h_tile)`, where:

- `C` is the class's checkpoint interval;
- `h_tile` is its history tile.

The cut makes every segment start at a position where every `Fixed` state of every layer has a
checkpoint leaf and every history row before it lies in whole history tiles. A segment boundary then
costs no state replay and no partial tile. The segments are Verification V2's segments (PALW-VF-33),
moved from leaf ranges to position ranges for an IR class: segment `j` is positions
`[⌊j·T/S_P⌋_G, ⌊(j+1)·T/S_P⌋_G)`, where `⌊x⌋_G` rounds down to a multiple of `G` and the last segment ends
at `T`.

A **cell** is `(shard i, segment j)`: occurrences `1 + l` for `l ∈ shard i` (with `pre` on shard 0 and
`post` on the last), at positions `a ∈ segment j`.

### 1.3 What a cell reads, and what it checks

**Inputs, every one a committed leaf** (opened against the claim's step root; the court's own openings):

| input | leaf | when |
| --- | --- | --- |
| the carry-in of the shard's first occurrence at every position `a` of the segment | the previous occurrence's carry-out commit tiles at `(a, slot)` (NF-21) | shard `i > 0`; shard 0 reads the job's tokens instead |
| every `Hist` row of the shard's layers at positions before the segment, inside the window | the rows' commit tiles (NF-20) or whole Hist tile leaves (every `h_tile`) | the segment does not start at 0 |
| every `Fixed` state of the shard's layers at the segment's first position | the checkpoint leaves at `a = p − 1` (`(a + 1) % C == 0`) | the segment does not start at 0 |
| the job's tokens — the prompt's, and at decode positions the generated ids as committed (the decode-token door, phase-f §2.5) | the job and its committed ids | shard 0 (and `Input(1)` everywhere); the LAST shard also checks each generated id against its own logits |
| the shard's params | inventory leaves under `artifact_root` (row pieces ≤ 32 KiB, closed-form indices) | always |

**Outputs, checked** — every leaf of the step tree the cell produces:

- the commit tiles of every commit point of the shard's occurrences at every position of the segment,
  including the last occurrence's carry-out (the next shard's input) and, on the last shard, the logits
  and the logits trace;
- the Fixed checkpoint leaves at positions inside the segment;
- the Hist tile leaves completed inside it.

The seat recomputes each leaf's preimage and checks it against the step root. The check uses either the
producer's leaf and its opening, or the run's sibling hashes for a whole contiguous run (a layer shard's
leaves at one position are one run of slots, ADR-0099 §1.1). A leaf that does not recompute is the
cell's finding.

### 1.4 Two ways to check a cell, one receipt

- **Sequential recompute.** Run the shard's occurrences over the segment from the cell's inputs alone,
  in position order, with commit points recomputed rather than read. This needs the fewest bytes: the
  inputs above, plus the step tree's siblings to place the recomputed leaves.
- **Local cone checks.** Evaluate every commit point's cone (spec 04b §9.2) from committed operands,
  the cell's internal commit points included. Every cone is independent, so the whole cell is one
  parallel batch, but the cell's committed values must be fetched.

Both establish the same fact: **every leaf the cell produces equals the PALW-TIR function of the
cell's committed inputs.** A `Valid` receipt for the cell attests that fact and nothing more. Which
mode a seat runs is node policy, like the transfer form ADR-0099 priced and did not choose.
Sequential recompute is batched as **one layer at a time over every position of the segment**
(ADR-0117's "one forward", base0's `forward_prefill_planned`): its projections are GEMMs over the
segment's positions, its attention is a batched causal kernel, and its recurrences step in position
order.

## 2. Why a cell's check is enough

### 2.1 The detection lemma

Order the leaves of a claim's step tree by the enumeration (phase-f §2.5: position-major, then slot,
then checkpoint and history leaves). The tree's invariant is that **every leaf is a function of
leaves that precede it, plus the params and the job's tokens**:

- a commit point's cone reads commit points of lower slots in the same position, carry-outs of
  earlier occurrences, and rows of earlier positions;
- a checkpoint leaf reads the previous checkpoint's leaves and the rows between;
- a Hist tile reads the rows it concatenates.

Call `F(ℓ)` the value PALW-TIR assigns leaf `ℓ` given the committed values of its predecessors.

> **Lemma.** Let a claim's committed tree differ from the honest execution's, and let `v` be the
> **first** leaf in the enumeration whose committed value differs from the honest value. Then
> `committed(v) ≠ F(v)`, and `v` lies in exactly one cell. A seat that checks that cell — by either
> mode of §1.4 — finds `v`, and finds no leaf of the cell before it.

*Proof.* Every predecessor of `v` agrees with the honest execution, by minimality. So `F(v)` evaluated
on committed predecessors is the honest value, which differs from `committed(v)`.

`v` is produced inside the occurrence and position that compute it, so it belongs to the one cell
containing that occurrence and position: checkpoint and Hist tile leaves belong to the cell of their
layer and position.

In local mode the seat evaluates `F(v)` from `v`'s committed operands, which are predecessors of `v`,
so honest, and sees the difference. In sequential mode the seat walks its cell in enumeration order.
Every leaf `u` of the cell before `v` is honest (minimality). It is recomputed from inputs that precede
it: the cell's committed inputs, which are honest, and the seat's own earlier recomputations, which
equal the committed honest values by induction. So the recomputed `u` matches and no leaf before `v`
is flagged. At `v` the recomputation is the honest value, and `committed(v)` differs. ∎

Three consequences:

1. **A consistent lie is caught upstream.** A producer that lies at a boundary row (a carry-out) and
   computes every later leaf honestly from the lie passes the downstream cells' checks: their inputs
   are the committed lie, and their outputs match it. The lemma puts `v` at the boundary row itself,
   which is an OUTPUT of the cell that computes it, and that cell does not verify. This is the
   argument the prototype exercises (§9).
2. **Cells compose.** If every cell verifies, the committed tree is the honest execution, by induction
   along the enumeration. A `Final` therefore needs every cell attested, exactly as the coverage door
   needs every segment attested today.
3. **The court is the existing one.** The cell's finding is a leaf and its committed inputs. That is
   the input of `TirShardCourtAccused`: a `TirCone` close proof for a commit point, the logits doors
   for the logits, and a Fixed or Hist leaf through its update cone. A leaf whose cone reduces over
   `H` is the F7 challenge: a session at `Terminal`, the responder's root claim first, then the
   dissection to one `h_tile` (spec 04b §9.5). Nothing about the court depends on who checked which
   cell. Its verdict depends only on the leaf, so *any* bonded party holding the cell's evidence can
   file it.

### 2.2 What a cell check does not see

A seat attests its cell, not the claim. A lie in a cell that no honest seat checks is not seen by the
panel. It stays convictable by anyone who later checks that cell within the court window, but a
corrupt quorum of that cell could license it first (§5).

## 3. Availability of boundary rows

A cell reads more of the producer's commitments than a replay does. A replay needs only the tokens and
compares roots; a cell needs its inputs' leaves (§1.3). These are the routes, in order:

1. **From the panel.** The previous shard's seats recompute the boundary rows of the same segment
   anyway, and its cell's check succeeds only if they equal the committed ones. A seat may take its
   inputs from any peer: every input is checked against the step root before use, so the source does
   not matter. A stratified panel can therefore run as a pipeline over shards, shard `i` starting each
   segment when shard `i − 1` has published its carry-outs. This is node policy and needs no consensus
   object.
2. **From the producer, off chain.** It is ADR-0111's fast path: a signed request and a 6-DAA wait
   (`PALW_LEAF_EVIDENCE_FAST_PATH_DAA_V1`). The producer's served annex (evidence-transport-scope,
   option B) is the natural carrier: per cell, the carry-in rows and its opening siblings.
3. **On chain, enforced.** It uses the IR DA units past `palw_tir_fence2`: `TirStepLeaf { index }` for a
   leaf, and `TirStepNode` for a 10-level subtree frontier (64 KiB). Withholding past `W_disclose`
   (1,200 DAA on testnet-12) is a default under the DA court's rules: void and slash (ADR-0062, ADR-0152
   DA-1..9). *(2026-10-15: demands are limited to claim-specific step material; demands for model weight bytes are
   prohibited for new rulesets — spec closures, ALL-MODEL item 3.)*

A cell's inputs are *runs*: one carry-out run per position, and history rows in whole tiles. So this RFC
adds one unit, **`TirStepRun { first, count }`**: a contiguous run of step leaves with its two boundary
paths, bounded by the carrier (100,000 bytes). One demand then serves about `⌊100,000 / (lanes × 4)⌋` positions of a segment's carry-ins, less the
paths (≈ 15 positions of a 1,536-wide residual per unit, against one per `TirStepLeaf`).

The ADR-0152 session limits (a seat: 1 open, 4 lifetime) stand. A demand names a run, not a cell, so a
seat whose producer withholds can force a default within its limits.

A seat that cannot obtain its inputs says `Unavailable { chunk, daa }`, as today: it abstains and is not
liable (PALW-VF-17). `seat_count − quorum + 1` such receipts redraw (SR-9).

### 3.1 Off-chain model supply, identity and claim-specific evidence — 2026-10-10後続改定

[ADR-0177](../adr/0177-model-bond-allocation-without-availability-consensus.md)を優先する。chainはmodel取得可否・Seeder登録/独立性・配布量/速度を管理せず、
旧必須Torrent、独立Bonded Seeder、PoR/Full Fetch/lease/TRDC/FPRと取得不履行に基づく資格/weight停止を撤回する。
model配布は任意のTorrent/mirror/共有契約で行い、取得失敗・非公開だけでSlash/Final延長を起動しない。

固定Model ID/root、weights/tokenizer/config/specは不変とし、変更は新Model IDとして登録する。
取得bytesは認証と全量復元rootで照合し、claimも同じroot/specをbindする。
任意のinfohash対応を登録する場合はimmutable bindingとし、必須取得経路にしない。
claim固有state/trace/output/witnessの有限な証拠責任は維持するが、modelの全量/反復range公開へ転用しない。
必要operandの認証と許可unit/累積scopeをADR177 D2で確定し、modelを得たfresh non-seat verifierの
計算反証/localization/exact courtを試験する。全model保有者拒否時の取得保証は撤回する。

重複しないminer拘束元本`S_m=sum_b C_{b,m}`からmodelのcoinbase予算を`f(S_m)`で配分する。
同じ元本をclaim数/rho/複数modelで増幅せず、総発行予算と個別bondのQ/B/R/F cap・共通DAA拘束を維持する。
資本預託だけでは支払わない。model別配分はblock頻度・DAA・fork choiceを自動変更しない。
公開参加資本が閉鎖自己資本より圧倒的に有利になることは倍率式・経済評価の未立証目標であり、
同額資本の所有者独立性をchainが識別できるとはしない。既存minerの実収入増も無条件保証しない。
non-interference、distinct-capital、三層予算、公開/閉鎖比較、回復/移行のgateはADR177 §3を用いる。
既存実装/測定・旧claim/activation記録は保持し、新配分・Panel=0は未実装/未有効化である。

## 4. The panel

### 4.1 The stratified draw, per shard (ADR-0100 Decision 4)

For a claim whose class has an IR shard plan, read at the claim's anchor:

- **Per shard, a panel.** The chain draws `derive_stratified_panel_v2` over `S_L` shards: per shard
  `s_shard` seats from the bonds that declared that shard (`BondShardsDeclared`), one seat per operator
  per shard, stake-weighted as the flat draw is.
- **Short shards.** A shard short of eligible operators refuses the draw by name, and the claim voids at
  `BindTimeout`. A sharded class never falls back to a flat panel.
- **The same operator may sit in several shards.** Its seats are distinct duties with distinct masks.

`s_shard = 3` is proposed (§5): one full-shard seat and two partial seats. The S1 assignment is
PALW-VF-33's run inside each shard: `K = s_shard − 1 = 2` segments, one drawn full-shard seat attesting
both, each partial seat attesting one by the drawn rotation. So `S_P = s_shard − 1` is the target, and
every cell is attested by two seats: the full-shard seat and its partial seat.

The recommended first step (open question 5) is `S_P = 1` *(historical; the Decision section governs v1)*. Each seat then attests its whole shard, and
a shard's two attesters are its first two seats. Segments switch on per class later.

### 4.2 An outsider per shard (ADR-0147, generalised)

For a claim of a bought class (`registrant_bond` is `Some`) at or past the fence, each shard's panel
gains an **outsider seat**. It is drawn from the network's base-class population exactly as ADR-0147
§2.1 draws the claim's outsider:

- the ticket is `H(outsider-ticket domain ‖ anchor ‖ claim ‖ shard ‖ operator_id)`;
- the registrant's bond and operator are excluded, as is the registration cut of §2.2;
- one operator holds at most one outsider seat of a claim.

The shard's outsider attests the **whole shard** (every segment). **No part licence stands without
its shard's outsider's `Valid`**, on every licensing arm.

An outsider does not declare the shard, so it has to obtain the shard's weights. It **fetches them**:
the shard's inventory rows under `artifact_root` (`palw_shard_inventory_rows_v1`, ADR-0100 Decision 2),
each a row piece with its opening, from any holder (the registrant's served artifact, a peer, a mirror).
It verifies every row against the class root, as a seat does at readiness.

Its cost is the shard's bytes, not the model's. That is §8's 26 % for a 4-shard 1.5B class, and 7.7 GiB
of a 32B shape at 4 shards. An outsider that cannot fetch or hold its shard says `Incapable`; the part
cannot license and the claim voids at its receipt deadline. *(2026-10-15: this is a non-fraud termination; it never
slashes, penalizes the registrant or suspends the class — spec closures, R6-OUTSIDE item 3, under ADR-0177 D1.)* This is ADR-0147's rule: *the cost of a
model the network does not run lands on the claims of that model*. What changes is that "the network
does not run" now means "no outsider can hold one shard", not "no outsider can hold the model".

This removes refusal 2: a stratified panel now seats an outsider in every part.

### 4.3 Receipts with cell masks

A receipt for an IR-sharded claim is the V3 receipt with its mask widened from segments to cells:
**`ReceiptV4 { …V3, shard: u16, segment_mask: u64 }`**. The signature covers both
(`palw_receipt_message_v4`, a new context in the next signature-context set). Verdicts are Q-1's:

- `Valid` attests every leaf of every cell in the mask (§1.4);
- `Unavailable { chunk, daa }` names a missing input leaf;
- `Incapable` is unchanged;
- `Sampled` never counts.

### 4.4 The recount over cells (Q-3, generalised)

The licence records

```
basis_k = min(3, min over cells (i, j) of #distinct counted Valid signers whose receipt covers (i, j))
```

over the union of every part's receipts. Final requires `basis_k ≥ 2` (`PALW_RCORE_FINAL_BASIS_K_V1`),
unchanged.

For a flat (unsharded) claim, `S_L = 1` and this is today's `palw_receipt_set_basis_k_v1` exactly: one
shard, segments as cells.

A supplementary receipt may raise `basis_k`, never lower it (Q-3). Each counted signer locks
`lock_{max(basis_k, 2)}` with its mask (Q-4, §6). A `Segmented` receipt is liable by its mask and the
fault's site (Q-6): a `Leaf` fault is charged to the receipts whose mask covers the leaf's cell, and a
`Whole` fault to every counted receipt of the claim.

This removes refusal 1: the recount has a rule for a licence by parts, and it is the one it already
had, read over cells.

### 4.5 Licence by parts, and Final

ADR-0100 Decision 4 unchanged:

- each shard's quorum is a `ShardReceiptLicensed` part: its `s_shard` seats plus its outsider, the
  outsider's `Valid` required;
- the claim licenses in the block that lands its last part;
- `basis_k` is recounted then (§4.4);
- a shard whose quorum says `Unavailable` voids the claim (where ADR-0065 D4 still has that door);
- `ReceiptLicensed` and `ProducerDefaulted` are refused for a claim that licenses by parts.

Final is PALW-LC's rule: `ReceiptLicensed` with `basis_k ≥ 2`, no open court and no open seat DA
session, at `max(licensed + 120, last_daa)`.

A part is `(s_shard + 1) × 4,772` bytes of receipts plus the claim and shard fields: about 19,100
bytes, one carrier, at any shard count. A 4-shard claim is about 77 KB against ~15–24 KB today. That
growth is what RFC-0007's batched certificates are for.

## 5. Coverage and collusion

Let:

- `h` be the honest share of the stake eligible for a shard;
- `f` be the registrant's share of the network's floor population (ADR-0147 §3);
- `s` be the counted seats of a cell (two attestations per cell under §4.1, three counting the shard's
  outsider).

A lie is committed with the claim, **before** the anchor that seeds its panel exists (the seed is the
anchor attempt's execution commitment, PALW-VF panel seed). So the lie's cell is fixed before its
seats are drawn, and a lie's chance of escaping is independent of the number of cells. This is ADR-0098's
"a one-leaf lie's coverage is independent of the shard count", at cell grain.

A lie escapes the panel only if every seat attesting its cell is corrupt or silent:

| per lie, the panel misses it with | `h = 2/3`, `f = 0.26` (ADR-0147's fixture) | `h = 0.9`, `f = 0.05` |
| --- | --- | --- |
| today on testnet-12: a 5-seat flat panel in which every seat replays the whole job (SEAT-R): `(1−h)^5` | 0.41 % | 0.001 % |
| today on paper (Verification V2: each segment attested twice) with the claim's outsider: `(1−h)^2 · f` | 2.9 % | 0.05 % |
| this RFC: the cell's two attesters (the shard's full seat and the segment's partial seat): `(1−h)^2` | 11.1 % | 1 % |
| …and the shard's outsider, who attests the whole shard: `(1−h)^2 · f` | **2.9 %** | **0.05 %** |
| four attesters a cell (`S_P = 1`, `s_shard = 4`: every seat attests its whole shard) and the outsider: `(1−h)^4 · f` | 0.32 % | 0.0005 % |

Reading:

- **The panel's detection is a parameter, not a property of sharding.**
  - The number of attesters a cell has is set by the S1 assignment: two per segment
    (`PALW_VERIFICATION_V2_ATTESTATIONS_PER_SEGMENT`), plus the shard's outsider.
  - A network that wants testnet-12's de-facto five whole replays sets four attesters a cell. It then
    pays the same work as today (§8), in shard-sized, batched duties.
  - The default (`s_shard = 3`) is exactly Verification V2's paper guarantee, at cell grain.
  - The user decides the point (open question 2).
- **The licence still needs quorum.** A corrupt quorum of one cell plus a corrupt outsider of its shard
  licenses a lie. The one-move court convicts it later if anyone checks the cell before the court
  window closes (3,000 DAA on testnet-12). The economic deterrent is ADR-0098 D4's coverage ×
  `claim.reserved`, now per cell.
- **Correlation across shards** helps the verifier. A lie in several cells is caught if any of their
  seats is honest. A producer that lies once is caught with the cell's probability; one that lies
  everywhere is caught with near certainty.
- **Stake per shard.** A shard's eligible population is the bonds that declared it. A class few
  operators shard has thin shards, and `h` per shard can be lower than the network's. The outsider per
  shard is the floor: a bought class cannot fill a shard's panel without also drawing the network's
  outsider.

## 6. Economics

### 6.1 Seat duty and locks, per cell

A counted `Valid` signer locks `lock_{max(basis_k, 2)}` for its mask (ADR-0152 lock_v2), and is liable
by its mask's cells.

The proposal scales a seat's duty and lock by its cells' share of the claim's work:

```
w_cell(i, j)        = the IR class's structural work (PALW-TIR-16) of shard i's occurrences over segment j's positions
duty_bind(seat)     = min( max(λ-term, lock_2) · Σ_{cells ∈ mask} w_cell / w,  ⌊commitment / seats⌋ )
lock(seat)          = lock_v2(…) · Σ_{cells ∈ mask} w_cell / w      (floored at the network's seat-lock floor)
```

With the floor, the panel's total lock over a claim is unchanged by sharding. Every cell is attested
twice, so the sum over a cell's two attesters is what one cell's work owes, and the sum over cells is
the claim's.

What changes is the **per-seat** lock: a 4-shard seat locks about a quarter of a full seat's. A bond
can therefore seat about four times as many duties within ADR-0160's aggregate liability. That is the
supply this RFC exists for.

The slash for a false `Valid` (S4: the lock plus `min(25 % C, 3G)`) is unchanged, so a seat that
attested a lie loses its bond's penalty term whatever its cell's size. **The deterrent does not shrink
with the cell.**

### 6.2 The claim's liability and the class room

The claim's `reserved` and its commitment `w + E + rr` are unchanged. Sharding changes who verifies,
not what a claim stakes.

Past F-R, a class's verification room (`palw_verify_capacity_v1`) counts two replays per claim
(`2 × eccu`) at the measured-speed constant. For an IR-sharded class it becomes the binding shard's:

```
room(c) = min over shards i of ⌊ ready_eff(c, i) × per_seat × window / (2 × eccu × w_i / w) ⌋
```

`ready_eff(c, i)` counts the seats ready for shard `i`. Readiness for a shard is the readiness proof
(tag 50) over the shard's inventory rows only, and the node's gate becomes "a full-SHARD replay fits
the ledger". A class whose shards are a quarter of its weight, held by four times the seats, has up
to **sixteen times** the room.

The measured-speed constant `PALW_CAPACITY_REPLAY_SPEED_PERMILLE_V1` (2,000 ‰) is consensus. A batched
cell verifier (§8) is faster than the replay that constant was measured on, but raising it is a
separate decision under its own fence, not part of this RFC.

### 6.3 Seat pay

The panel pool (the model-class share, `clamp(α·C_V/(C_P+α·C_V), 100 ‰, 300 ‰)`) is split by counted
receipts weighted by `Σ w_cell / w` of their masks, not `⌊pool / K⌋` per seat. A shard's outsider is
paid for its whole shard. That pays for the fetch the outsider had to make.

## 7. Held context (ADR-0103) and position segments

An IR class on testnet-12 runs under the held regime from genesis:

- the context is held off chain;
- the chain carries roots, openings and a logarithm;
- `CourtOpened` is refused, and every accusation is one move;
- `Fixed` state is checkpointed every `C`, and `Hist` rows every `h_tile` (`h_tile ≤ 4,096`).

Cells change nothing there. They read the same leaves and accuse at the same named leaf.

What they change is ADR-0103 D7, *"a seat holds a shard of the model and of its state"*. That becomes
literal for an IR class: a shard seat holds its layers' weights and its layers' history, never another
layer's.

The position axis is ADR-0103 D2's interval, made cheap. A late segment of a long job still needs every
earlier history row of its layers (attention reads all of them), so position segments bound a cell's
**compute** but not its history **read**. Layer shards are what bound the history a seat holds: its
`|shard| / L` of the model's. A 2M-position class (C7) thus needs layer shards; position segments alone
would leave every seat holding every layer's 2M rows.

Checkpoint alignment (`G = lcm(C, h_tile)`, §1.2) is what keeps a segment boundary free. `C` comes from
admission (`C_j` per state, spec 04b §10.3) and `h_tile` from the class layout. A layout whose `G`
exceeds `T / S_P` simply gets fewer segments.

## 8. Cost model and what it buys

**Weights a seat holds** (`i8` codes, the plan of §1.1; the embedding and the head untied, as in
`tir-exec-bench`'s programs):

| model shape (layers, d, ff, vocab) | whole | widest shard at `S_L` = 2 / 4 / 8 |
| --- | --- | --- |
| Qwen2.5-1.5B (28, 1,536, 8,960, 151,936): 44.6 MiB a layer, embedding and head 222.6 MiB each | 1.67 GiB | 0.83 / 0.44 / 0.26 GiB (50 % / 26 % / 16 %) |
| Qwen2.5-32B shape (64, 5,120, 27,648, 152,064): 465 MiB a layer | 30.5 GiB | 15.3 / 7.7 / 3.9 GiB |
| Llama-3-70B shape (80, 8,192, 28,672, 128,256): 816 MiB a layer | 65.7 GiB | 32.9 / 16.4 / 8.2 GiB |

A 24 GiB-class seat holds a 4-shard part of the 70B shape and a 2-shard part of the 32B. Today it holds
neither.

**Trace a cell reads.** Per position, a shard boundary is one carry-out row: `d × 4` bytes (6 KiB at
1.5B, 32 KiB at 70B). The whole committed trace of a 1.5B position is about 4.6 MiB (≈ 143 KiB of
commit tiles per layer plus 593 KiB of logits). A cell's carry-in is therefore 0.13 % of the trace its
segment commits. Its history read is its layers' K/V rows before the segment: `2 × kvd × 4` bytes per
row per layer (2 KiB at 1.5B), which is what bounds a late segment (§7).

**Work.**

| per claim | today (SEAT-R, t12) | this RFC (`s_shard = 3`, two attestations a cell) |
| --- | --- | --- |
| replay-equivalents | ≈ 5 (every seat outside C7 replays the job) | 2 (every cell twice) plus each shard's outsider's whole shard: 3 in all |
| per duty | the whole job | `≈ 1/S_L` of it (`1/(S_L·S_P)` for a partial seat) |
| memory per duty | the model and the job's history | the shard's weights and its layers' history |
| shape | `T` sequential single-position steps | `|shard|` layer passes, each a batch of the segment's positions |

**The batched shape, measured** (`tir-gpu-bench --layer-batch P`, `misaka-palw-tir-gpu`; design
`docs/design/palw/tir/gpu-integer-backend.md` §6). Setup: Apple M1 Max, a shared host at load 48–78.
The seven projections of one 1.5B layer, each batched result byte-checked against the CPU executor's
kernel before timing:

| positions | batched | per position | one position at a time | batching gain |
| --- | --- | --- | --- | --- |
| 256 | 36.7 ms | 0.144 ms | 1.59 ms | **×11.1** |
| 512 | 67.2 ms | 0.131 ms | 2.44 ms | **×18.6** |

The CPU kernel's per-position replay of the same projections took 5.7–33 ms a position on this host (3
threads, loaded), so a batched device check of a cell runs **×40–250** faster than the per-position
CPU replay a seat runs today. Every one of these results is byte-identical to the CPU executor's.

**Supply, put together.** At `S_L = 4` the projected effect is the product of three factors, each a
measured or a structural number:

- **1.7–2.5× fewer replay-equivalents.** A claim costs 2 replay-equivalents instead of 5, about 3
  with the outsiders.
- **About 4× more duties per ledger.** A shard's weights are a quarter, and so is its history.
- **×11–19 on the same device, ×40–250 against the CPU replay** (§8's measurement) for any seat that
  verifies in batches rather than replays.

Not projected:

- the receipt bytes (§4.5), which grow by `S_L` until RFC-0007;
- the boundary transfer, which is small (MiB per cell).

## 9. The prototype (D4)

`experiments/palw-tir-gpu/tests/layer_shard.rs` is an off-chain test; it changes no consensus code. It runs
on the reference evaluator only and needs no GPU.

1. **Produce.** A small PALW-TIR program runs once as a producer would. Every commit point of every
   occurrence at every position becomes a leaf, in slot order, with every `Fixed` instance
   checkpointed after each position `a` where `(a + 1) % C == 0`. The leaves become a Merkle tree
   (BLAKE2b-256), whose root is the claim's commitment. The producer is cross-checked against the
   reference evaluator's own run (`Interpreter::run`), commit point for commit point.
2. **Verify a cell.** A seat verifies occurrences `[a, b)` over positions `[p, q)`. It holds the root
   and a params source that serves exactly the cell's param instances and refuses every other one, so
   a check that needed another shard's weight fails. It opens every input against the root:
   - each position's carry-in;
   - the history rows before `p`;
   - the checkpoints at `p`.

   It recomputes every commit point with `Interpreter::eval_cone` — the court's own function — in
   position order, and checks each recomputed leaf by hashing it up the committed path. No producer
   value is used as an output.
3. **Fixtures:**
   - a four-layer decoder in `tir-exec-bench`'s conventions (`d` 64, GQA over full-attention histories,
     the wide RMS norm, a GLU MLP; 2 shards × 3 segments);
   - the same at eight layers and `d` 256 (4 shards × 2 segments);
   - the golden vector's gated-delta program `gdn-k2-v4-grouped` (two layers of per-layer `Fixed` state,
     `C = 2`; 2 shards × 4 segments).

### 9.1 Results (2026-10-01)

- **The honest trace verifies cell by cell**: 6 cells, 14 cells (with the 8-layer fixture) and 8 cells.
  No cell asked for a param outside its shard. The cells' checks **tile** the committed leaves: every
  leaf is checked by exactly one cell.
- **A tampered leaf inside a cell** (a commit point of layer 2 at position 5, one value moved by one)
  is found by that cell, **at that leaf**. The other five cells verify.
- **A consistent lie at a boundary row.** Layer 1's carry-out at position 6 is moved, and every later
  leaf is computed honestly from it. The **downstream** cell (layers 2–3, positions 4–8) verifies:
  its inputs and outputs agree. The **upstream** cell (layers 0–1, positions 4–8) finds the lie at
  the boundary row. This is the detection lemma's first consequence (§2.1), exactly.
- **A consistent lie in a state.** The GDN layer 1's state write at position 3 is moved, and the lie
  rides into the checkpoint the next segment starts from. The cell that writes it finds it at the
  checkpoint leaf. The next segment's cell starts from the lying checkpoint and verifies. Shard 0
  never reads it.
- **What a cell touches** (8 layers, 4 shards × 2 segments, `d` 256):

  | | per cell |
  | --- | --- |
  | weights | 25.3–26.8 % of all param bytes (`pre`'s embedding and `post`'s head ride with the end shards) |
  | committed trace read, as opened inputs | 0 % (the first segment of shard 0: tokens only) to 1.6 % (a late segment of a middle shard: its carry-ins and its layers' earlier history rows) |
  | committed trace checked | 12.2–13.1 % (one eighth) |

  At four layers and two shards the cells held 54 % of the weights, read up to 9.4 % of a 12-position
  trace, and checked 15.6–17.8 %. The history a late segment reads grows with its position (§7). At
  real widths it is a small fraction next to the weights, which dominate these toy models less than
  the per-layer 65,536-entry activation tables do.

## 10. Activation

*(Historical plan: `palw_tir_shard_v1` is armed on testnet-12 at DAA 5,300; later V3/segment-v2 profiles have their own fences.)*

**One dormant fence, `palw_tir_shard_v1`.** Past it, for IR classes only:

- `ClassShardPlanDeclared` may name an IR class (`S_L`, `S_P`);
- the stratified draw (ADR-0100 D4) draws per shard with an outsider per shard (§4.2);
- `ReceiptV4` is accepted (§4.3);
- the recount runs over cells (§4.4);
- `ShardReceiptLicensed` licenses an IR claim by parts (§4.5);
- `TirStepRun` is a DA unit (§3);
- the class room is the binding shard's (§6.2).

Legacy classes keep `palw_shard_court` / `palw_shard_licensing` and both refusals unchanged. The new
fence does not lift them for a legacy class.

`validate_palw_v2` requires these armed at or below the fence's height:

| prerequisite | why |
| --- | --- |
| `palw_tir_v1` | the IR one-move court that convicts what a cell finds |
| `palw_tir_fence2` | the IR DA units a cell's inputs are demanded by |
| `palw_verification_v2` | the S1 segments and masks |
| `palw_rcore_plus` | Q-1…Q-7, the recount the cells generalise |
| `palw_admission_independence` | the outsider rule the per-shard outsider generalises |

It requires a signature-context set carrying `palw_receipt_message_v4` and the outsider ticket's
domain.

**Fingerprinting**, the four places every fence has (memory note *a-some-only-fence-needs-its-never-collapse*):

1. an `Option<ForkActivation>` field;
2. its entry in `for_each_fence`;
3. **Some-only** writes in `consensus_params_id` and `consensus_schedule_id`, so a dormant network
   fingerprints as if the fence did not exist;
4. the **`never()` collapse** in `normalize_values_a_scheduled_fence_drags_with_it`, so a build that
   schedules it at `never()` and a build that lacks it agree.

Its height must be one **no other fence uses**, or the fork id (which hashes sorted, de-duplicated
heights) cannot tell a build that has it from one that does not.

**Drills, on the shipping binary, crossing the fence** (memory note *a-flag-day-needs-a-drill-that-crosses-it*):

| drill | what it shows |
| --- | --- |
| D-S1 cross | a TIR class with a 2-shard × 2-segment plan on a local devnet; a claim bound before the fence licenses whole; one bound after licenses by parts with an outsider in each; both go Final |
| D-S2 cell lie | the producer commits a wrong leaf inside shard 1 at one position; shard 1's seats find it; `TirShardCourtAccused` convicts; the claim voids and the bond is slashed |
| D-S3 consistent lie | the producer lies at the shard-0/shard-1 boundary row and computes shard 1 honestly from it; **shard 0** finds it (shard 1 verifies); conviction as D-S2 |
| D-S4 withholding | the producer refuses boundary rows; a seat files `TirStepRun`; silence is a default; void and slash |
| D-S5 a seat that holds a shard | a host whose ledger share cannot hold the whole class but holds a shard declares it, is drawn, verifies, and its receipt counts; duties per host before and after, measured |
| D-S6 outsider fetch | an outsider with no copy of the class fetches its shard's inventory rows and attests within the receipt window |

## Proposed Spec text (sketch)

New section 08 §8.7, "IR-sharded panels" (PALW-SH-*), applying past `palw_tir_shard_v1` to IR classes
with a declared plan:

- **PALW-SH-1 (the plan).** An IR class's shard plan is the derived layer partition of §1.1 for its
  declared `S_L`, `pre` on shard 0 and `post` on the last, and the position segments of §1.2 for its
  declared `S_P`. Two nodes derive the same plan.
- **PALW-SH-2 (a cell).** A cell is a shard's occurrences at a segment's positions. Its inputs are the
  leaves of §1.3 and the shard's inventory rows. Its outputs are every step leaf those occurrences
  produce at those positions.
- **PALW-SH-3 (Valid).** A `Valid` cell receipt attests that every output leaf of every cell in its mask
  equals the PALW-TIR function of the cell's committed inputs. A seat MUST NOT sign `Valid` for a cell
  it did not check.
- **PALW-SH-4 (the draw).** Per shard, `s_shard` seats from the bonds that declared it, one per operator,
  with the S1 assignment of PALW-VF-33 inside the shard. A shard short of operators refuses the draw.
- **PALW-SH-5 (the outsider).** For a bought class, each shard's panel has an outsider drawn from the
  network's base-class population (ADR-0147's draw with the shard in the ticket), attesting the whole
  shard. No part licence stands without its outsider's `Valid`.
- **PALW-SH-6 (the recount).** `basis_k = min(3, min over cells of distinct counted Valid signers
  covering it)`, over every part's receipts. Final requires `basis_k ≥ 2`.
- **PALW-SH-7 (liability).** A `Leaf` fault is charged to the receipts whose mask covers the leaf's
  cell; a `Whole` fault to every counted receipt.
- **PALW-SH-8 (inputs are opened).** Every input a seat uses is checked against the claim's step root
  (or the class root, for params) before use, whoever served it.
- **PALW-SH-9 (no new commitment).** A cell reads the step tree of RFC-0002 Phase F unchanged. Nothing
  a producer commits depends on the plan.

## Alternatives

| alternative | why not |
| --- | --- |
| Keep whole-job replay and add seats | supply scales with hosts that hold the whole model; for a model no seat holds it is zero |
| Position segments only (today's S1, with resume) | bounds a seat's compute, not what it holds: every layer's weights and history (§7) |
| Tensor parallelism (a layer split across seats) | a layer's matmuls would need cross-seat partial sums, and those are not committed; a new commitment per split, and no court input |
| Random leaf sampling (a seat checks `k` random leaves) | ADR-0098's numbers: 6.51 % per 300-token claim at `s = 5`; a cell check sees every leaf of its cell |
| ADR-0099's recompute form (the previous shard's rows) for IR classes as-is | it is this RFC's sequential mode; what ADR-0099 lacked for legacy classes was committed boundary rows for every node, which IR classes have |
| A per-shard flat licence without parts | ADR-0098 §1.2: one transaction holds the whole object only up to 8 shards |
| Outsider = a full-replay seat | an outsider for a model nobody else holds pleads `Incapable` and the claim voids (ADR-0147 §3's residual); a shard-sized outsider is what an honest stranger can hold |
| Aggregated or algebraic per-shard checks | RFC-0007 |

## Security and economic analysis

| failure | what happens |
| --- | --- |
| a lie inside a cell | that cell's seats find it (§2.1); the one-move court convicts; the claim voids, the bond is slashed, the reporter is paid |
| a consistent lie at a boundary row | the upstream cell finds it (§2.1 consequence 1); D-S3 |
| a corrupt quorum of one cell and a corrupt outsider of its shard | the part licenses a lie (probability §5); anyone who later checks the cell convicts within the court window; the attesting seats are slashed (S4) |
| the producer withholds boundary rows | the seats demand them (`TirStepRun`, `TirStepLeaf`); a default voids and slashes; the seats abstain `Unavailable` meanwhile |
| a seat serves a wrong boundary row to a peer | refused against the step root (PALW-SH-8); the receiving seat fetches from elsewhere |
| a shard nobody holds | the draw refuses; the claim voids at `BindTimeout` (ADR-0100); a class whose shards are thin has little room (§6.2) and stays small |
| an outsider who cannot fetch its shard | `Incapable`; the part does not license; the claim voids at its deadline (ADR-0147's cost on the claims of that model) |
| grinding the cell of a lie | the lie is committed before the anchor seeds the draw; the plan is derived and immutable; the cell is fixed before the seats |
| a plan the registrant chooses to its advantage | the plan is derived from the program and `S_L`; `S_L` and `S_P` are declared once and immutable, like the graph |
| a large operator in many shards | one seat per operator per shard; its correlated failure is in many cells, which raises detection of a single lie elsewhere and is bounded by the outsiders |
| `Fixed` replay at an unaligned segment | not possible: segments start at multiples of `lcm(C, h_tile)` |
| a long history read at a late segment | priced: it is the cell's history bytes, bounded by its layers; the H-dissection court adjudicates an attention leaf in `h_tile`-sized pieces |
| receipt bytes | grow `S_L`-fold (≈ 77 KB a 4-shard claim); RFC-0007 |

## Compatibility and migration

- Dormant: no fingerprint, object, receipt or rule changes until the fence is armed (§10). *(Historical: v1 is armed on
  testnet-12 at DAA 5,300; see the 2026-10-08 status note and spec closures, R6-MIGRATION.)*
- Legacy classes are untouched, and so are ADR-0099/0100's fences and refusals.
- A flat IR class (no plan) is exactly today's: `S_L = 1`, the recount over cells is the recount over
  segments.
- A claim bound before a class's plan keeps the whole licence it was drawn for (ADR-0100,
  `palw_claim_licenses_by_parts_v1`).
- Node side: the panel worker gains a cell verifier (the prototype's `layer_shard` check over
  `misaka-palw-tir-exec`; batched on a device by `misaka-palw-tir-gpu`), the readiness proof over a
  shard's rows, and the ledger's need for a shard (`PalwRoleMemoryNeedV1` over the shard's bytes).

## Historical open questions — initial baseline

The following list records the initial alternatives. The v1 implementation's constants record
adoption of their recommended defaults on 2026-10-03 (`palw_tir_shard_v1.rs`), and the implemented
baseline is described under **Decision** below. These are not unresolved choices for the live v1
rules. New probabilistic coverage, V3 strata and segment-resident pricing have their own later
review / activation requirements; this historical list does not authorize their activation.

1. **One fence or two?** A plan-and-draw fence and a licensing fence would let a network draw stratified
   panels and attest cells before licensing by parts (shadow mode).
   *Recommended default:* **one fence**, `palw_tir_shard_v1`, armed only after a shadow period in which
   the node's cell verifier runs beside the whole-licence replay on IR claims and their verdicts are
   compared (node-only, no fence).
2. **The attesters per cell and the detection point (§5).** Two (`s_shard = 3`, Verification V2's own
   rule, plus the outsider: 2.9 % per-lie miss at `h = 2/3`, `f = 0.26`) or four (`S_P = 1`,
   `s_shard = 4`: 0.32 %, testnet-12's de-facto five replays' detection at its work). The choice trades
   supply against detection per lie; the court window stays the backstop.
   *Recommended default:* **two attesters a cell (`s_shard = 3`) plus the shard's outsider** on
   testnet-12, where supply binds. Mainnet's point is set by its own measured `h`.
3. **The outsider's span.** The whole shard, or one cell (cheaper: `1/S_P` of the compute, weaker
   independence).
   *Recommended default:* **the whole shard**. The outsider fetches the shard's weights anyway, and a
   batched pass over all positions costs little more than one segment.
4. **`TirStepRun`.** A new DA unit, or peer serving plus `TirStepNode` only.
   *Recommended default:* **the new unit**. A segment's carry-ins are runs, and one `TirStepLeaf` per
   position cannot be demanded within the session limits.
5. **2-D at first, or layers only?**
   *Recommended default:* **layers only at first (`S_P = 1`; each seat attests its whole shard)**,
   with position segments switched on per class once batch verification is the node's common path.
   `S_P = s_shard − 1` (S1 inside the shard) is the target.
6. **Locks and pay by `w_cell / w` (§6)**, or per seat as today with the floor doing the work.
   *Recommended default:* **by `w_cell / w`, with the floor**. It is what lets a bond seat more shard
   duties; the slash term keeps the deterrent whole.
7. **The class room (§6.2)** as the binding shard's `ready_eff`, and the readiness proof over a shard's
   rows. Both change ADR-0160's lane-verify arithmetic.
   *Recommended default:* **adopt both**, together with the licensing fence; until then the class room
   stays ADR-0160's.
8. **Who declares `S_L`?** The registrant, once (ADR-0100), or derived from a network-wide seat budget
   (ADR-0099 Decision 2's `palw_shard_plan_for_seat_v1`), so that a class cannot be over-sharded to thin
   its panels.
   *Recommended default:* **derived from the network's seat budget** (the fewest shards whose widest
   shard fits it). The registrant may declare MORE shards only up to twice that number, so that a class
   cannot thin its own panels.
9. **The measured-speed constant (§6.2).** Batch verification is faster than the replay the constant was
   measured on.
   *Recommended default:* **leave it**. Raise it under its own fence, after a drill measures the cell
   verifier on the network's hosts.

## Decision

The implemented v1 baseline adopts the nine recommended defaults above: one original shard fence;
three class seats with two required attesters per cell and an outsider over the whole shard;
`TirStepRun` DA; layers-only as the default with `S_P = 2` offered for the S1 plan; work-share lock / pay
with the existing floor; the binding shard's effective readiness for class room; the network-seat-budget
minimum shard count with at most twice the minimum; and the original measured-speed constant.
`palw_tir_shard_plan_shape_v1` enforces the offered position counts, 2..64 shards, the layer-count bound
and the derived under/over-sharding limits. These choices describe the existing implementation.

The v1 fence is live on testnet-12 at DAA 5,300. The later [RFC6/10 implementation record](../design/palw/shard-rfc6-10.md)
adds V3 per-shard draws and non-seat watchers behind the permissionless-panel fence, and resident-aware
pricing behind the separate dormant `palw_tir_shard_segment_v2` fence. Live v1 work pricing is preserved.
The [four-RFC design audit](../design/palw/rfc-0006-0007-0008-0012-design-audit-2026-10-10.md) tracks the remaining
coverage / public-court / worst-cell capacity / fee evidence. Model acquisition follows ADR-0177 and
the later §3.1 amendment; historical readiness is not approval of a new acquisition-based earning gate.

## V3 shard assignment: retained derivation and restore contract — 2026-10-11

The later permissionless V3 shard draw has a pre-entropy frozen population and subject; this
contract does not amend live lane-A assignment at DAA 5,300. V3 assignment randomness remains
separate from RFC07 Part VI's computation challenge.

- The seal id must derive from network/ruleset, accepted immutable work subject and exposure,
  acceptance order, parent checkpoint, first future beacon epoch, frozen population root and
  strata. Lookup claim id and signature are not entropy. A matching copied id in a binding
  cannot substitute for this derivation.
- At readiness the engine copies the already verified epoch output into the claim's retained
  derivation material. Initial and retry bindings use that same output and subject. Terminal
  release/void may prune the shared epoch row, but must preserve the claim's output and binding
  history while that claim remains tracked. Live output must agree with the shared epoch row;
  missing material is refused, never filled with local randomness or a guessed output.
- Every restored `EntropyReady` and binding must rederive the seed/beacon id and exact policy
  readiness/assignment clocks. Frozen role/membership and per-stratum operator/retry exclusions
  remain mandatory. Whole carriage and keyed journal restoration enforce these checks. Import
  also requires its trusted consensus root; retained output alone is not a beacon certificate or
  authentication of an arbitrary self-consistent checkpoint. Historical collateral headroom and
  exact ranking require the authenticated transition history, not this material alone.
- The implementation uses explicit engine carriage/cursor version **2**, committed by the
  Some-only permissionless fence. Obsolete version-1 experimental states are refused; their
  reconstruction requires authoritative replay. This adds no new lifecycle object tag or delta
  number and arms no fence. Absent/never fences preserve public identities.
- The serialized import envelope must include population/stratum bits, every history binding and
  used operator, the current phase's binding copy, derived reservations and retained entropy.
  It must permit every state under the validated structural caps. The derived current bound is
  recorded in SHARD §1.4; a legal 4,096-seat flat checkpoint previously exceeded the old envelope.
  Serialized-size coverage is not a RAM/CPU/latency/service-rate or participation approval.

These rules close restore-time derivation omissions. They do not approve source independence,
grinding resistance, probabilistic coverage, public-court costs, fee/capital floors or network
migration. V3 is dormant on all public presets and real activation remains refused.

## Shared verification-challenge boundary — 2026-10-08

New algebraic checks of cells/layers and their boundary relations bind [RFC07 Part VI](0007-palw-verification-certificates-and-algebraic-checks.md#post-commit-challenge-protocol)'s
immutable challenge policy and complete statement before its future source window. Panel/role assignment stays a
separate versioned randomness contract; assigning a cell is not evidence of an unpredictable computation challenge.
No local seed formula or initially exposed seed for later adaptive proof messages is permitted. Partial cells still
need scope/boundary coverage and whole-claim error composition; repeated same-seed watchers do not add independent
trials. A fresh outsider reconstructs public queries/transcripts and follows mismatch through RFC14's bounded exact
court/DA rules. Source scarcity leaves checks pending under their deadlines without changing chain liveness.
This amendment adds no live policy, quorum change or implementation result.

## Mission alignment amendment — 2026-10-07

§2のfirst-divergence lemmaは、必要な認証境界と全対象commit pointを取得・検査した場合の局所化の補題である。honest seatが存在するだけの検出保証でも、公開証拠の取得やcourt proof生成の完成証明でもない。cell/shardのopening・重み・stateと有界dissection/closeを、選出されていない普通のpublic bondにも提供する。outsiderの選出やcell quorumを、そのbondの訴追権の条件にしない。

本節は、衝突する将来の実装指示・受入条件を改定する。本文中の既存実装、過去の測定、旧claimの規則はその時点の記録である。新しい合意規則はversioned specification・実装・独立試験・明示的activationを経て初めて適用する。[ADR173](../adr/0173-public-verifier-dispute-completeness-is-misaka-purpose.md)、[RFC14](0014-panel-independent-fraud-prosecution.md)、[RFC15](0015-panel-free-permissionless-verification.md)を参照する。

## Bond予算・総影響保存の改定 — 2026-10-10

[ADR-0176](../adr/0176-bond-bounds-palw-production-rewards-and-final-weight.md)と[RFC15 §8](0015-panel-free-permissionless-verification.md)を適用する。

shard・seat・coverageの増加はproducerのclaim容量と異なる検証供給である。将来の容量倍率を上げてもbond当たりのblock/reward/Final weight総量を増やさず、slice/shardに同じworkの権利を重複配分しない。
Panel有りのmodeでも共通予算・最早回復時計と残存責任を維持する。Panel=0はRFC15の別gate/activationを必要とし、本RFCの供給測定で代替しない。

本節は将来の規範・受入条件を改定する。過去の実装/測定、旧claim会計とactivation履歴は保持し、文書改定だけで新規則を有効化しない。

## MISAKA Torrent・Seeder報酬の廃止 — 2026-10-10後続改定

[ADR-0177](../adr/0177-model-bond-allocation-without-availability-consensus.md)に従い、MISAKA Torrentの採用/統合、専用Bonded Seeder、
Seeder報酬・固定15%配分の概念を廃止する。一般的な任意配布はoff-chain運用とし、
モデル入手の合意gateやSeeder向けcoinbase legへ復活させない。過去の設計/試験は撤回前の記録として保持する。

## 改定 — 2026-10-12（shardとPanel=1：提案）

**状態:** 設計の改定・提案。実装、敵対的試験、経済評価、ネットワーク有効化は未実施。数値は本番定数ではない。 全文は[Panel=1・Bond/time予算・モデル拘束資本倍率の改定案（2026-10-12）](../design/palw/panel1-bond-budget-model-capital-amendments-2026-10-12.md) §4。

Panel=1暫定modeでは、単一seatで全shard・全検証scopeを覆える経路だけを対象にする。shard outsider、segment mask、`seats-1` 等の複数seat前提を一括定数置換しない（RFC-0010 2026-10-12改定の1-seat移行監査）。

<a id="spec-closure-2026-10-15"></a>

## Spec closures — 2026-10-15

**Scope and reading rule.** This section closes specification gaps for R6-CELL, R6-DRAW, R6-OUTSIDE, R6-PRICE,
R6-MIGRATION and the cross-cutting ALL-MODEL group of the
[design audit's requirement index](../design/palw/rfc-0006-0007-0008-0012-design-audit-2026-10-10.md#完全解消を判定する要件の索引).
It states rules that the [RFC6/10 implementation record](../design/palw/shard-rfc6-10.md) and the 2026-10-13/14 RFC06
records implement but this RFC never stated, and marks stale text. [PRINCIPLES](../PRINCIPLES.md) and
ADR-0173/0176/0177/0178 rank above it; later user rulings prevail over older RFC text. Nothing here changes live
shard v1 at DAA 5,300, arms a fence, assigns a height or records a PASS. Mechanics or private-process results are not
independent review or economic evidence. "USER DECISION REQUIRED" marks a named parameter whose value needs the
user's decision; a recommendation appears only where an existing record justifies it.

### R6-CELL — coverage of new cell profiles

The first-divergence lemma (§2.1) remains a localization/conformance lemma for a **complete** check of a cell's
commit points. For any new probabilistic or algebraic cell profile (RFC07 Part V/VI) the following are normative:

- **PALW-SH-10 (relation coverage).** A cell receipt's declared scope MUST name every relation of the cell it
  covers — products, quantization/rounding, nonlinear, routing/TopK, `Hist`/`Fixed` memory updates, carry-in and
  carry-out boundary rows, decode-token door — and the claim's licence MUST cover every relation of every cell.
  A relation without a checker leaves the claim unlicensable.
- **PALW-SH-11 (boundary equality).** Equality of a carry-out with the next shard's carry-in, and of a checkpoint with
  the next segment's input, MUST have a designated checker or an aggregate relation that covers it. A committed but
  unchecked boundary is not coverage.
- **PALW-SH-12 (whole-claim error).** The whole-claim false-accept bound is the union over all cells, relations,
  boundaries and selection loss, charged per RFC07's cumulative accounting. Checking a random subset of cells is
  not whole-claim coverage; one faulty cell is found only with its selection probability.
- **PALW-SH-13 (localization).** A failed check localizes through authenticated partitions to an existing exact
  terminal (`TirShardCourtAccused`, logits doors, H-dissection), with bounded total work, bytes and moves, and is
  fileable by any eligible public bond holding the authenticated material.
- Remaining (observations): proof of whole-claim soundness for small constraint checks, and boundary/memory/routing
  coverage per accepted model profile, are not established.

#### R6-CELL round 3 — claim-wide boundary, routing and memory coverage (2026-10-15)

**Status:** this is an argument plus a checker in source form. It is not compiled, not tested and not reviewed, and
it is no PASS. It refines the remaining observation above and does not close it.

**Committed trace.** Every value a TIR claim commits is one of five things:

- a commit-point node tile (`PalwTirLeafKindV1::Commit`) of an occurrence (pre, layer `l`, post) at a position;
- a `Fixed` state leaf (`State`);
- a `Hist` window tile (`HistTile`);
- a logits row;
- the delivered token.

Every node input is exactly one of the following:

- **(i)** a node of the same occurrence;
- **(ii)** a carry-in slot (`Ref::CarryIn`), whose bytes are the previous occurrence's committed carry-out tile, with
  no second commitment;
- **(iii)** a state (the previous position's `State` leaf or `HistTile` window);
- **(iv)** a param, authenticated against the registered artifact;
- **(v)** the job input or the previous position's delivered token.

**Lemma (claim-wide first divergence).** Assume the binding term (BLAKE2b-512 collisions) does not fail. Suppose a
committed trace differs from the reference evaluation of the registered program on the authenticated params and the
job input. Then the first differing value, taken in evaluation order (position, then occurrence, then node), is
exactly one of three things:

- **(a)** the output of one relation instance of one cell, whose own inputs are all correct committed values or
  correct recomputations;
- **(b)** one state update (a `StateWrite`/`HistAppend` row, or a window that is not the previous window plus the new
  row);
- **(c)** the decode door (a delivered token that is not the decode of its committed logits row).

*Proof sketch.* Take the first differing value. Every input it reads comes earlier in evaluation order, through
(i)–(v), so each input is either correct or itself the first divergence:

- inputs (i) and (iv) are correct;
- input (ii) is the same bytes as an earlier commit point;
- input (iii) is an earlier `State`/`HistTile` leaf;
- input (v) is the job's input or an earlier door.

The carry slot is not a separate relation: equality of a carry-out with the next carry-in holds by construction,
because the next cell reads the committed carry-out tile. This holds only if every carry-out node is a commit point,
which `validate` enforces and the checker re-checks. The same argument covers a shard cut, which is a carry edge
between occurrences held by different shards (`palw_tir_shard_partition_v1` is contiguous), and a position-segment
cut (`S_P = 2`), which is a state/`HistTile` edge between positions.

**Coverage requirement.** By the lemma, a claim is localizable when each of the following has a verifier that maps
it to a bounded exact terminal (`TirShardCourtAccused`, the logits/decode arms, H-dissection):

- every relation of every node, by its family's descriptor checker (PALW-SH-10). Routing (TopK, Gather, Compare,
  Select, ReduceMax) is the Selection family and is checked by exact recompute;
- every carry-out slot, through the cell verifier's read of committed tiles (PALW-SH-11);
- every `Fixed`/`Hist` state, through `StateContinuity` plus `State`/`HistTile` leaf recomputation;
- the declared shard shape;
- the door.

The whole-claim false-accept bound is then the PALW-SH-12 union:

- exact verifiers contribute `0`;
- probabilistic relations contribute their RFC-0007 per-instance terms (R7-RELATION items 4 and 7), over every
  position;
- the binding term is added;
- if fewer than all cells are checked, the selection loss is added (`⌊log₂(N/(N−s))⌋`), which a uniform sample of
  `s` of `N` cells pays.

A beacon mismatch only localizes. Conviction is always the exact terminal's.

**The checker** is `consensus/core/src/palw_cell_coverage_v1.rs`. It is pure, and no consensus path calls it. It
enumerates every boundary the code accepts and routes each one to its verifier.

`palw_tir_cell_coverage_v1(descriptor, program, (S_L, S_P))` enumerates:

- every node as a relation, using `family_of_prim` and the descriptor's `support`;
- every Selection node again as routing;
- every `carry_out` slot (it must name an existing commit-point node);
- every `StateKind::{Fixed, Hist}` (exhaustive match, so a new kind cannot compile unclassified);
- the shard shape. Only `2 ≤ S_L ≤ min(64, layers)` and `S_P ∈ {1, PALW_TIR_SHARD_POSITION_SEGMENTS_S1_V1}` are
  accepted; any other shape is `UnknownProfileKind`;
- the decode door.

`palw_legacy_cell_coverage_v1(profile)` enumerates, for a `PalwShapeProfileV3`:

- the profile version (V1–V3 only; any other version fails closed);
- every layer by `layer_kind` (exhaustive over `GatedDeltaNet` / `Attention`) and every layer carry;
- the MoE router of every layer table. Exactly one q36 router TopK is covered. More than one is uncovered, because
  the router slot is then not unique. A fenced Kimi router is uncovered;
- each memory section the layers need (attention cache, recurrence state) under the registered state chunk map:
  - **no map:** the long form covers the section;
  - **a known map:** the section is covered only if the map spells that section **and**
    `palw_state_chunk_count_at_v1` enumerates it at a checkpoint;
  - **an unknown map id:** `UnknownProfileKind`.

`palw_shipped_legacy_profiles_v1` enumerates the shipped ladder families (graph v1, v5 and v7, and the v8 hybrid)
at every row in `PALW_CONTEXT_LADDER_ROWS`. The tests drive the TIR checker over the sketch fixtures (dense + MoE,
windowed, wide128) under K2-TIR-v2 and v4.

**Gaps the checker names (from reading the code; not yet run).** These are recorded gaps, not passes:

- The v1/v2 hybrid maps enumerate only their attention half. The recurrence section of a hybrid profile under them
  is uncovered.
- The standalone recurrence maps (`gdn_state_chunk_map_id_v1`–`v3`) are not enumerable by the court.
- Outside the checker, the step leg still treats an unknown, non-held map as "no fault"
  (`palw_step_leg.rs`, `_ => {}`), and V1/V2 profiles accept any map id. Both are fail-open acceptance paths that
  need a versioned fence to close.
- MoE in the legacy graph exists only as kernel and weight-name conventions.
- Whether the legacy step court covers every operator of a layer is asserted by name here, not re-proved.

**Remaining:**

- compile and test the checker;
- decide how to close the fail-open map paths (USER DECISION REQUIRED for any fence);
- an external review of the lemma;
- extend the enumeration to every registered class row of a live network, once a catalog of registered TIR
  classes exists.

#### R6-CELL round 4 — the coverage closure fence (2026-10-15)

**Status:** dormant source. Not compiled, not tested, not reviewed, and no PASS. The fence is `None` on every preset,
and `validate_palw_cell_coverage_closure_v1` refuses every real activation. Nothing is armed.

**Fence.** `Params::palw_cell_coverage_closure_v1: Option<ForkActivation>`. It is hashed Some-only into both
fingerprints, listed in `palw_fences_v1`, and collapsed from `Some(never())`. It has a `fork_id_v1` probe arm and is
mirrored to `PalwStateParamsV2::cell_coverage_closure_from_daa` by `Params::sync_palw_cell_coverage_closure_v1`. It
has an A-2 central-table row (`Int12FoldPastFence`, tags 3 / 8 / 12) and an arm in the A-2 harness. It pays and
weights nothing, so it is **not** in `PALW_N3_GATED_REWARD_FENCES_V1`. The rule is in
`consensus/core/src/palw_cell_coverage_closure_v1.rs`.

**One predicate.** `palw_cell_closure_legacy_refusal_v1(profile)` returns `None` exactly when
`palw_legacy_cell_coverage_v1` covers every boundary. Otherwise it returns the refusal:

- an unknown kind first, failing closed by name;
- else the first uncovered kind.

The checker now tags every gap with a `PalwCellUncoveredKindV1`.

**Rule past the fence.** Below the fence, every hook answers "old rule".

| REQ | Where | Keyed on | Past the fence |
|---|---|---|---|
| REQ-CELL-1 | `object_preconditions_v1` (fold second lock), `ClassRegistered` with a carried profile | the registration block's DAA | an uncoverable profile is refused: `CellCoverageRefused`, code `CELL_UNCOVERABLE` |
| REQ-CELL-1b | `check_class_admits_claim` (attempt, free-prompt, evaluation lanes) | the claim's acceptance DAA | a class whose graph the fold holds (`fp_work_profile_of`) and that is uncoverable takes no claim: `ClassNotRewardable`, code `CELL_UNCOVERABLE` |
| REQ-CELL-2 | `adjudicate_court_close_v4` (all three processor sites), plus the pure `check_step_refutation_closure_capped_v1` | the claim's acceptance DAA | see the paragraph below |
| REQ-CELL-3 | everywhere | — | below the fence (every shipped network: the mirror is `None`), verdicts, writes and roots are byte-identical. A claim accepted before the fence keeps its old ruleset. `adjudicate_court_close_v3` is v4 with `None` |

**REQ-CELL-2 in detail.** This applies where admission cannot see the graph: a class registered before the fence, or
a genesis class whose graph the fold does not hold. A close of a claim accepted past the fence is handled in this
order:

1. **The class is uncoverable.** The legacy binding is first pinned to the registered class and to the claim's
   execution root, and `verify_binding_v1` is run on it. The close then adjudicates `ExecutorGuilty`, objectively,
   from the binding alone. This is never `ChallengerDefeated`.
2. **The pure checker's closure form.** The shape pass answers `ShapeProfileNotCanonical` (kind 0, leaf 0). A mapped
   checkpoint count the court cannot derive is `CheckpointIndexNotCanonical`, not "no fault".
3. **No map.** The long form keeps its `None`.

**The fail-open is closed.** `palw_step_leg::checkpoint_fault` read an unenumerable map as "no fault", and V1/V2
profiles accepted any map id. Past the fence, neither path can reach a producer win:

- a new class with such a map is refused at registration;
- a new claim on such a class is refused at the claim gate, or convicted in court.

Old claims keep the old rule, because the fence is not retroactive.

**Coverage matrix, round 4.** `palw_cell_uncovered_disposition_v1` is exhaustive. In round 4 every uncovered kind is
**refused at admission**, and no kind is newly covered. Each covered case is named by its existing verifier.

| Case (legacy `PalwShapeProfileV3`) | Round 4 | Why |
|---|---|---|
| no map (long form), one q36 router per table | covered | `LegacyLongForm`, `LegacyRouterTopk` |
| attention-only maps (integer KV v1/v2, tiled v3/v4) on attention-only layers, enumerable | covered | `LegacyStateMapEnumerated` |
| hybrid v3 / held v4 / P0a v5 (v5 under a version-3 profile), enumerable | covered | `LegacyStateMapEnumerated` (both sections) |
| unknown map id | refused at admission (`UnknownProfileKind`) | the court cannot enumerate it, so the old step court failed open |
| hybrid v1/v2 map with GDN layers | refused (`HybridRecurrenceUnenumerated`) | covering it needs the recurrence geometry in the consensus crate plus an anchored GDN arm. v3/v4/v5 *are* that coverage, so register one of them |
| solo recurrence map (`gdn_state_chunk_map_id_v1`–`v3`) | refused (`SoloRecurrenceMap`) | its geometry belongs to the executor crate (`base0_gdn_state_geometry_v*`) |
| a known map missing a needed section (e.g. attention-only map under GDN layers) | refused (`MapSectionNotSpelled`) | the section has no anchor |
| a known map not enumerable at a checkpoint of this profile (e.g. v5 under a non-v3 profile) | refused (`MapNotEnumerable`) | the count is not decidable |
| more than one q36 router in a table | refused (`MultiRouterTable`) | `qwen36_router_topk_slot` answers `None`, so a routed product is unadjudicable |
| a fenced Kimi router | refused (`KimiRouter`) | its own row recomputes (`kimi_row`), but routed gather/combine resolve routing only through the q36 slot |
| TIR classes | outside this fence | coverage is per descriptor (`palw_tir_cell_coverage_v1`). No shipped fixture has a gap. The TIR kinds' disposition is "refused" if ever wired |

**Tests (source only, not run):**

- `palw_cell_coverage_closure_v1/tests.rs`:
  - `req_cell_the_fence_is_dormant_everywhere_and_refused_when_armed`;
  - `req_cell_1_an_unknown_map_is_refused_at_registration_past_the_fence`;
  - `req_cell_1_every_uncovered_kind_is_refused_at_admission`;
  - `req_cell_1b_the_claim_gate_refuses_an_uncoverable_held_class`;
  - `req_cell_2_the_court_never_acquits_an_unknown_map_past_the_fence`;
  - `req_cell_3_below_the_fence_every_predicate_is_the_old_rule`.
- `palw_step_leg.rs`: `req_cell_2_an_unknown_map_is_never_no_fault_under_the_closure`. This uses the honest fixture,
  whose map is unknown, and checks two things:
  - below the fence it is `NoFaultFound`, identical to the live checker;
  - under the closure it is `ShapeProfileNotCanonical`.
- `palw_cell_coverage_v1.rs`: `round4_every_uncovered_kind_is_enumerated_with_its_disposition`.

**Remaining:**

- compile, run and review the round-4 sources;
- a court-level fixture test of `adjudicate_court_close_v4` on a live-shaped session;
- whether the Panel false-valid structural routes (`palw_offence_v1` / `palw_offence_attribution_v1`, which call
  `check_step_refutation_capped_v1`) should pass the closure flag. They convict Panel signers, not the producer;
  past the fence an uncoverable class takes no new claim, or is convicted by the court;
- the arming decision (USER DECISION REQUIRED).

### R6-DRAW — the V3 per-shard draw

In addition to the 2026-10-11 restore contract above:

1. Per-stratum populations, seed and strata are frozen in the pre-entropy snapshot. Each stratum draws its class seats
   one per operator, plus an optional outsider whose operator holds no other outsider seat of the claim in this or an
   earlier round.
2. A retry excludes every operator that sat in that stratum in an earlier round; alternates are never reused per stratum.
3. **One reservation:** a bond seated in several strata of one round reserves its per-seat exposure once per claim and
   binding; retries do not accumulate reservations.
4. A stratum that cannot be filled ends the claim `NoCapablePanel` (non-fraud). A sharded class never falls back to a
   flat panel.
5. The per-block draw budget counts draws (one per stratum); the first due claim that does not fit stops that block's
   draws; no subset of strata is chosen.
6. **Named parameters** (V3 only; live v1 constants unchanged): per-claim retry bound, strata count bounds (code:
   2..64), class seats and outsider per stratum, and the retained candidate-population cap (the dormant mechanics refuse a
   fifth retained 100k population): **value: USER DECISION REQUIRED**.
7. **Snapshot transport.** Four retained 100k populations with 100,001 bonds encode to 437,719,699 bytes, above the
   unchanged legacy 384 MiB cap; that shape requires the negotiated protocol-107 compressed transport. Its experimental
   bounds (512 MiB canonical decoded, 384 MiB wire) are not approved: **value: USER DECISION REQUIRED**. Old peers keep
   protocol 106 and the legacy cap; a timeout never switches codec.
8. Remaining: V3 arming, historical collateral headroom, multi-process P2P/pruned IBD (validation-only).

### R6-OUTSIDE — non-seat verification and pre-emption

1. A non-seat watcher holds no seat, signs no receipt and needs no outsider selection. It may file
   `TirShardCourtAccused` or a `TirStepRun` DA demand within the non-seat budget, using only public authenticated
   material; it never asks the producer with a seat's signature.
2. **Pre-emption.** While a DA session, court session or `DefaultDisputed` state is open on a claim, no non-fraud end
   (neutral void, receipt/bind timeout) and no Final may take effect; the engine's own decision is deferred, not
   re-rolled. An accusation carried in the same block as an already decided end is late, not pre-emptive.
3. **Outsider `Incapable` (reconciles §4.2 with ADR-0177 D1 supplement).** When an outsider cannot obtain or hold its
   shard, the part cannot license and the claim ends as a **non-fraud termination** for missing required verification.
   This MUST NOT slash anyone, penalize the registrant, suspend the class's registration or stop rewards of other valid
   claims, and it is not a judgement of fraud.
4. **No positive detection floor is assumed.** A watcher's existence is not evidence that a check happened; where no
   independent holder of the model checks, the effective detection probability may be zero (ADR-0177 D7 and its note).
5. Remaining: actual detection-floor evidence; watcher compensation (see R6-PRICE).

### R6-PRICE — cell work, residency and capacity

1. Past the dormant `palw_tir_shard_segment_v2` fence, a seat's price share is `max(Σ work, Σ resident)` over its
   mask's cells (floored at 125 ‰, capped at 1,000 ‰), keyed on the claim's immutable `accepted_daa`; the lock a counted
   signer posts and the pay weight fixed at bind MUST use that same share. The slash term is unchanged.
2. Seat readiness past that fence is node policy: a node proves possession of a shard only when its ledger can hold the
   shard's heaviest cell. Node readiness, local resource admission flags and local quota evidence are **never** an
   on-chain capacity proof or a consensus input. Unknown resource bounds refuse (fail closed); they are never zero.
3. The class room (§6.2) and the measured-speed constant (2,000 ‰) are unchanged.
4. **Named parameters**, each requiring measurement on release hardware: worst-cell public material bytes, worst-cell
   fresh-verifier time, per-shard court capacity, and the non-seat watcher's compensation/fee. **value: USER DECISION
   REQUIRED** (no measured basis exists).

### R6-MIGRATION — live v1, history and new profiles

1. The rules armed on testnet-12 at DAA 5,300 are preserved; any change requires a new versioned fence.
2. The **Decision** section is authoritative for v1. Where the historical questions differ (question 5's `S_P = 1`
   against the Decision's layers-only default with `S_P = 2` offered), `palw_tir_shard_plan_shape_v1` and the Decision
   govern.
3. **Superseded text (kept as history):** the 2026-10-08 status note's list of open items (watcher, segment pricing, V3)
   is superseded by the 2026-10-11 implementation update; the 概要 "有効化" bullet, §10's "One dormant fence", and the
   compatibility bullet "Dormant: no fingerprint …" describe the pre-activation plan, not t12 after DAA 5,300.
4. New profiles (V3 draw, segment pricing v2, probabilistic cells) need their own versioned fence and approval and stay
   dormant until an independent Work Beacon bootstrap is verified (N3, 2026-10-12 user ruling).

### ALL-MODEL — shared rules for RFC6/7/8/12

1. **Identity.** A registered model's ID/root, weights, tokenizer/config and execution spec are immutable
   (ADR-0175); different content is a new Model ID. Claims bind that root/spec; fetched bytes are authenticated against it.
2. **No acquisition gate.** The chain does not manage model distribution, seeders or acquisition results. Miner and
   Panel MUST possess the correct model to participate under the applicable ruleset; a registrant owes no distribution.
   Acquisition failure alone never slashes, suspends registration or rewards, or extends a challenge window.
3. **Claim-specific evidence only.** New demand units target claim-specific witness/state/trace; requests that would
   enumerate or reconstruct model weights are prohibited. The four armed t12 court routes that can compel model bytes
   (`HeldStepLeaf`, `AttnRootClaimOperands`, `TirGenRootClaimParams`, `SeatReadinessLeaves`) are closed by a **dormant
   restriction fence** (2026-10-12 user ruling D2). A profile whose terminal needs model operands the court cannot
   authenticate under that restriction MUST NOT be presented as adjudicable.
4. **Non-public evidence paths** (e.g. V5 image/source IDs, `PanelDa`) are excluded from new reward and weight for
   claims accepted after a new fence (2026-10-12 user ruling N4).
5. **Allocation.** Model coinbase allocation uses distinct bound capital `S_m` without double counting, inside the fixed
   total budget and every per-bond Q/B/R/F cap; it changes no block frequency, DAA, fork choice or Final weight, and pays
   only valid claims. Allocation curve: **value: USER DECISION REQUIRED** (current provisional: `A_m = S_m^α`, α = 1.5,
   per the 2026-10-10 ruling; the 2026-10-12 `S_m·μ(S_m)`, μ ∈ [1.3, 2.0] proposal is undecided).
6. The effective detection probability of a closed model may be zero; this is an open safety gate, not closed by
   allocation economics.
