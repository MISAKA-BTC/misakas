# ユーザー判断 2026-10-15 — ADR C1〜C5・RFC-0016 V2〜V11・RFC-0017 U-1〜U-9

**Status:** ユーザー判断(設計方針の採用・修正指示)。**数値は校正・受入試験の出発点であり本番値ではない。新規 fence の有効化は承認していない。**
対象: 統合ブランチ `integ/rfc02-rfc06-12-g14`(`6b1a01acd`)の判断事項
([ADR 判断事項](adr-0162-0178-user-decisions-2026-10-15.md)、[RFC-0016 §14.1](../../rfc/0016-bond-weighted-block-opportunity-and-elastic-final-capacity.md)、[RFC-0017 §11–12](../../rfc/0017-model-eligibility-examination-and-renewal.md))。

## 基本方針

- DAG の並列生成を維持する。異なるモデルの miner が同時にブロックを生成でき、適格な RED の仕事も取り込む。
- α=1.5、30 日平均 bond、V+、既決定の拘束期間は変更しない(再審しない)。
- モデルの登録は自由とし、通常の採掘資格とは分離する。
- 検証されていない計算に、無条件の合意上の優位を与えない。Final weight を 0 にするだけでは safe frontier や決済深度まで 0 になるとは限らない。
- 測定前の暫定値は calibration/devnet 専用とし、本番 activation を禁止する。
- 最も重要な原則: **モデルの採掘資格と、計算がチェーンの安全性に寄与できる資格を分離する。**

## 1. ADR C1〜C5

| 判断 | 回答 | 指示 |
|---|---|---|
| C1: R_total の範囲 | 条件付き採用 | 新規発行される miner 向け coinbase 報酬は、経路を問わず実際の支払が R 上限を迂回しないようにする。利用者払いの取引・サービス手数料は既決定どおり別会計。拒否された claim への補助金支払が残るなら、coinbase 側を修正してから有効化 |
| C2: Panel=1 のみの bond の出金拘束 | 採用 | 出金拘束は 7 日相当を維持。Panel=1 の発行能力の回復は 1 日相当でよいが、出金・再登録・mode 切替で長期責任や枠を初期化してはならない |
| C3: Round 権利・income の rate | 修正して採用 | 7 日総量だけでなく短期間の集中発行を制限する rate/burst 上限を要求。同じ元本を複数の収入経路で二重に使わせない。具体的な rate は実測待ち |
| C4: P_m の二重適用 | 既決定を追認 | 物理ブロック機会は RFC-0016 V+ が 1 回、coinbase 配分は ADR-0177 が 1 回だけ適用。V+ 有効時は V3 の別の `block_opportunity` を無効にする |
| C4b: 利用者払い escrow | 修正して採用 | coinbase 由来のモデル予算に基づく claim 別上限 `r_c` を利用者払い escrow に転用しない。producer 共通 R 上限と必要担保は維持。不足するなら受理前に拒否し、受理後に減額しない |
| C5: Verifier 資本の定義 | 条件付き採用 | 実際の検証責任・拘束期間・処罰対象が定義された適格な資本だけを数える。Panel=0 で単に bond を登録しただけの資本は加算しない。OPV の検証責任会計が完成するまで当該新規資本の配分寄与は 0 |

C1 と C4b は既存の報酬会計や coinbase 処理の変更を要し得る。方針の採用と現行コードの合格は区別する。

## 2. RFC-0016 V2〜V11

| 判断 | 回答 |
|---|---|
| V2: σ・φ・pace・再配分 | 途中再発行は `A_m` 加重方式を採用。校正初期値 σ=0.25、φ=0.5、pace margin=1.2、仕様の全候補を測定。`k=1` で追加 ticket 傾斜は無効のまま。本番承認は保留。`A_m` 欠損時に先着 fallback で不当に権利を与えない |
| V3: entrant reserve | 校正案としてネットワーク総機会の 20‰ を上限。RFC-0017 の Probation 予算と 2 重確保しない。Probation のモデル別上限 2‰ を校正値として維持。`S_entry` は対象ネットワークの適格な最低 producer bond を基準にし、適格性のない資本を含めない |
| V4: Q/B/R/F・担保 | 測定で確定。最小 bond の正直な miner が継続採掘でき、高速偽造者がそれ以上の枠を得られず、責任担保も不足しない組合せだけを採用。必要なら claim 一件の権利を小さくする。元本や上限を無条件に引き上げない |
| V5: epoch 期間 | 初期校正は 720 DAA = 1 epoch。30 日平均の名目窓は 21,600 DAA。実時間と DAA 進行のずれは報告し、1 epoch が常に実時間 24 時間だとは表示しない。本番値は実測後 |
| V6: 合格閾値 | 安全性・会計の不変条件違反 0 件を必須。honest miner の cap 利用率 80% 以上を校正目標、V+ なし同条件に対する継続 REAL 生産の劣化は暫定 5% 以内を目標。新規モデルの最低機会保証と T4 の最終数値は E1〜E6 の実測で確定 |
| V7: queue・quote | 有界 queue と bond 資本比例の公平配分を採用。`L_queue`・`T_queue`・`h` は実測で決定。quote は確定権利ではなく、競合時は決定論的に再検査。TTL 超過は不正認定せず終了 |
| V8: 容量 attestation | モデル・verifier・能力・測定窓・期限・証拠 root へ署名して固定。各 verifier の容量はモデル間で二重計上しない。`sigma_cap` はまず 1 以下の校正候補、測定根拠のない容量増幅を禁止。計算量・メモリ・DA・court 負荷を一体評価 |
| V9: verifier 報酬 | 既存の 10〜30% を維持、校正基準 20%。負荷による傾斜と検査数 `N/m` は実測で決定。実際に検査した割合 `checked_share` と期限内の検証完了率を別々に計測。新規発行を増やして解決しない |
| V10: 未配分報酬 | attestation 未達で留保された補助金は他モデルや未検証 claim へ自動再配分しない。その epoch は未発行扱い、後日の追加発行で取り戻さない。発行上限を維持 |
| V11: coinbase の Panel 変更 | 今回は移行しない。V2 Attempt の既存 Panel 経路を維持し、Kernel/OPV の Panel=0 と区別。検証・rotation・責任・Final の実ノード試験後に別途判断 |

V2・V3・V5・V6・V8・V9 の数値は校正・受入試験の出発点で本番値ではない。V+ で権利を多く配っただけで、実際の計算・採用ブロック・Final・報酬が増えたとは判定しない。

## 3. RFC-0017 U-1〜U-9

- **U-1:** Registered → Probation → Eligible → Lapsed は採用。7 枠・4 承認は本番用として承認しない。ECON の 47 枠・24 承認を優先的な校正候補とし既存制度と整合させる。その他の設計値(Probation 7 日・16 claim、30 日更新、試行回数、2 日承認窓など)は試験用として維持、本番値は保留。
- **U-2:** Probation の Final weight=0 を採用。追加条件(activation 必須): Probation claim の Final を合意上の安全性 credit と混同しない;`safe_weight` と `bounded_immature` への寄与 0;`safe_frontier`、PALW の settled anchor 深度、Rule E の参加数を認証なしに進めない;Probation が発行できる物理 REAL block 自体の GHOSTDAG・DAA への影響は別途有界性を検証。現行の `F=0` だけではこれらを保証できない。
- **U-3:** stake 比だけで独立検証の成立を保証したことにしない。単一試行の自己承認通過確率(RFC-0017 §5.1 解析値): f=3% で 7/4 0.0026%・47/24 ほぼ 0%;f=33.3% で 17.3%・約 0.9%;f=60% で 71.0%・約 91.8%。全体 verifier stake の悪意ある支配割合 `f` を独立した脅威モデルとし、少なくとも f=1/3、f=0.6、最悪ケースを評価。実際の正直な verifier 比率をチェーン上で証明できない以上、抽選結果だけを無条件の計算正当性証明にしない。モデルの通常資格と、個別 claim をチェーンの安全性に使える証明は別に扱い、後者には検証可能な計算証拠と公開裁定条件が必要。
- **U-4:** 100,000 BILI は本番値として不承認(t12 の最低 producer bond 13,000 BILI より大きく、小規模な正直参加者の障壁になる一方、300M の攻撃者は止められない)。試行手数料の非返還・burn は採用するが金額は実測の検査費用から導出。lineage 単位の試行上限、ネットワーク上限、cooldown、公平な待ち行列を併用。正直な新規モデルが資本不足だけで参加不能にならないようにする。試行費用は (a) 取消し・失敗でも返還しない spam 防止の burn 手数料 と (b) 検証者へ支払うため事前に資金確保する検査費用(申請者負担の escrow 等、新規発行にしない)に分離する。全額 burn 実装を維持する場合も検証者の報酬原資を別途確定する。
- **U-5:** 1 更新期間(名目 30 日)の移行猶予を採用。既存 claim の権利・責任は維持。猶予を新規の未認証 security credit を無制限に発行する免除として扱わない。更新審査に通らなければ Lapsed。
- **U-6:** 永久の全面免除は不採用。非報酬の緊急 liveness を維持する BASE-0 には専用例外を認める。その他の報酬付き genesis モデルは既存モデルと同じ移行・更新審査を受ける。
- **U-7:** 当面は併存。RFC-0017 をモデルの資格・更新 gate、ECON を対象 epoch の検証と支払 gate として区別。同じ検査を二重計上・二重請求せず、必要な条件が未成立なら対象の支払を解放しない。置換は同等以上の検証が実証されてから。
- **U-8:** 採用。`roll_epoch` で決定論的な資格 snapshot を読み、Registered/Lapsed のモデルを配分の分子・分母・ブロック機会から除く。reorg・IBD・再起動で同じ値になることを必須試験とする。
- **U-9:** 採用。Registered/Lapsed のモデルは報酬や improvement score の昇格を生む評価経路で拒否。ただし登録・試験のための利用者払い Kernel/Funded job は維持。

## 4. 全 agent 共通の追加条件(新規 fence 有効化前に必須)

| 優先度 | 必須条件 | 理由 |
|---|---|---|
| P0 | Probation の Final weight=0 と、frontier・settled depth・参加数の不算入を一貫させる | weight だけ 0 でも合意上の優位が残り得る |
| P0 | Rule E の Voided attempt・bond 分割による参加数の問題を解決 | 資本額と独立した参加数の増幅を避ける |
| P0 | RFC-0017 の 47/24 を独立した計算証明と誤表示しない | stake 支配率が高ければ自己承認が可能 |
| P0 | R_total、coinbase、利用者 escrow の全経路を整合させる | 予算上限を経路の違いで迂回させない |
| P1 | 300M BILI の閉鎖モデル攻撃を 30 日・90 日の条件で評価 | モデル集中、分割、検証者支配、反復試行を比較 |
| P1 | 複数モデルによる DAG 並列生成、RED 取り込み、reorg、IBD の E2E 試験 | DAG を維持したまま合意が収束することを確認 |
| P1 | heartbeat・BASE-0 の継続稼働試験 | 資格・容量・検証待ちが時計を止めないことを確認 |

PRINCIPLES §0 が許容する `p=0` の残余リスクは、経済的な損失上限とチェーンの確定性を区別して扱う。モデル資格制度だけで frontier 優先 fork choice の問題が解決したとは宣言しない。

## 5. 統合・有効化

- **設計方針の採用:** 推奨(C4、V+、段階的モデル資格、Probation の Final weight 制限、GAP-E1/E4 の接続方針など)。
- **測定用コードの統合:** 生成物再現性・cargo check・対象テスト・影響スイート・clippy・未有効化時の旧ルール同一性が PASS したコードは休眠状態で統合してよい。
- **本番パラメータ確定・fence 有効化:** 承認保留。σ/k、Q/B/R/F、検証者資本の前提、手数料、queue 容量、モデル資格の安全性、実ノード試験が揃うまで有効化しない。

## 6. 補足判断(同日): 抽選検証者の承認を認証の柱とする

ユーザー判断:「抽選した検証者の承認を認証の柱にしている。これは承認にするということは前提にするのでそのままでいい。」

- RFC-0018 の `SecurityCertified`(Gate C)は、claim 固定後の乱数で global pool から抽選した検証者の **m-of-k 肯定承認** と **G14 公開告発 window の異議なし経過** で成立する。この設計を維持し、追加の暗号学的計算証明を認証の必須条件にはしない。
- 「抽選された検証者 stake のうち正直な割合が閾値以上である」ことを **明示的な前提(安全性の仮定)** として置く。U-3 の趣旨はこの前提を隠さないことであり、認証は前提に基づくもので無条件の数学的証明ではないと RPC・文書で表示する。
- f=1/3・f=0.6・最悪ケースの評価は、この前提が崩れた場合の影響範囲の報告として行う(認証方式の変更条件ではない)。
- G14 の公開告発で反証された claim は、認証済みでも従来どおり conviction・void の対象であり、合意 credit も取り消される。

## 7. 実装状況(branch `integ/decisions-1015`、休眠・未build・未試験)

各項目は「2026-10-15決定 → 実装(file:line)」または「測定待ち」として、次に記録した。数値は校正の出発点で本番値ではなく、新規fenceの有効化はしていない(全presetで`None`、t12の挙動は不変)。

* ADR C1〜C5: [ADR判断事項](adr-0162-0178-user-decisions-2026-10-15.md) §D
* RFC-0016 V2〜V11: [RFC-0016実装状況](rfc-0016-implementation-status-2026-10-15.md) §8、[RFC-0016](../../rfc/0016-bond-weighted-block-opportunity-and-elastic-final-capacity.md) §14.2
* RFC-0017 U-1〜U-9: [RFC-0017](../../rfc/0017-model-eligibility-examination-and-renewal.md) §14

RFC-0018への狭いinterface: 本branchのRFC-0017は`palw_model_eligibility_v1`にGate C(`palw_independently_work_certified_v1`)を同じ高さ以下で要求し、`palw_probation_security_credit_v1`・`palw_eligibility_security_credit_v1`を公開する(fork choice・safe frontier・settlement depth・rule E・認証述語そのものはRFC-0018 laneのcodeで、本branchでは編集していない)。

## 7b. ユーザー判断(同日、第 4 回): モデルの二階層 — 年次指定 1.0 / 通常登録 永久 0.3

ユーザー判断:「この方式にする。つまりモデル有効化の審査は追加モデルに対してのみ行い、genesis モデルと 1 年に一回ほどのソフトフォークもしくはハードフォークによって登録されるモデルにはその検証は一切しないという方針にする。」

- **二階層。** `ModelTier(m, h) = 1.0`(m ∈ ApprovedModels(h))、`0.3`(その他の有効な登録モデル)。ApprovedModels(h) は genesis と有効化済みの年次フォーク(ソフト/ハード)で指定された「モデル ID + 固定 artifact root」の集合。
- **モデル単位の審査(RFC-0017 の昇格・更新審査)は、オンチェーンで追加登録されたモデルにのみ適用する。** genesis モデルと年次フォーク指定モデルには一切適用しない(本判断で U-6 を変更: 免除は BASE-0 だけでなく genesis・年次指定モデル全体)。
- **通常登録モデルは審査を通っても永久に 0.3。** 何年経っても自動で 1.0 にならない。1.0 になる経路は年次フォークでの指定だけ。既存の `Active` 等の状態は運用状態として残し、1.0 の資格とは別物とする。
- **0.3 は一度だけ適用する。** α=1.5 配分の重みに掛ける(`A_m = c_m · S̄_m^1.5`)。その P_m を V+ の物理ブロック権利と coinbase 配分の両方が使う。受理ブロックの報酬にさらに 0.3 を掛けない(0.09 倍にしない)。
- **複数登録で上限を迂回できない。** bond 総量・共通 Q/B/R/F 予算に加え、通常登録モデル全体の発行上限を設ける。モデルを多数登録しても 0.3 枠は増えない。
- **年次フォーク。** 承認リストに追加するだけで既存モデルを上書きしない(ADR-0175 と整合)。リストへの指定は政策的決定であり、「公開されている」「独立検証可能」の技術的証明ではない。
- **claim 単位の安全性は全階層で維持する(ユーザー確認済み 2026-10-15:「これは残す。そうじゃないと claim の検証ができない」)。** genesis・年次指定・通常登録のすべてで、未認証 claim(SecurityCertified でない claim)は safe frontier・決済深度・Rule E 参加・settled anchor・weight を進めない。モデル単位の審査を外しても、claim 単位の検証・court・Gate C は廃止しない。抽選検証者の共謀可能性は残る(前提に基づく認証)。
- 本判断は経済上の資格の設計であり、計算していない claim への対策(Gate C)とは別の合意規則として維持する。数値 0.3/1.0 は設計値。fence の有効化は承認していない。

## 7c. ユーザー判断(同日、第 5 回): モデル単位の検証・審査は全廃

ユーザー判断:「genesis/fork モデルは 1 倍で有効、後から追加されるモデルは 0.3 倍で、そこから検証などはなく 0.3 倍のまま固定。つまりモデルに対しての検証がなくなった。」

§7b を次のとおり改める(§7b の「モデル単位の審査は登録モデルにのみ適用」は撤回):

- **モデル単位の検証・審査は、すべてのモデルについて廃止する。** RFC-0017 の資格審査(Registered → Probation → Eligible → Lapsed、抽選審査、更新、失効、試行手数料・試行上限)は適用しない。
- genesis・年次フォーク指定モデル(ApprovedModels(h)) = **1.0**。
- オンチェーンで追加登録されたモデル = **登録時点から審査なしで 0.3 に固定**。昇格・更新・失効はない。1.0 になる経路は年次フォークでの指定だけ。
- 0.3 は配分重みに一度だけ(`A_m = c_m · S̄_m^1.5`)。登録 tier 全体の発行上限は維持し、多数登録で枠を増やせない。
- **claim 単位の検証は全モデルで維持する**(§7b のユーザー確認どおり): Gate C / SecurityCertified、court、claim ごとの抽選検証者認証。未認証 claim はどの階層でも fork choice・決済・Rule E・settled anchor・weight を進めない。
- これに伴い、RFC-0017 の Probation に基づく SecurityCertified 不許可(U-2 の probation pin bar)は対象が存在しなくなる。claim の安全性は Gate C の claim 単位認証だけで扱う。

## 7d. 第 4 回・第 5 回の実装状況(branch `integ/decisions-1015`、休眠・未 build・未試験)

* **規則:** [ADR-0179](../../adr/0179-model-tiers-genesis-annual-1-0-registered-0-3.md)。統治する前提は PRINCIPLES §9。
* **RFC-0017** は階層の RFC に改定した。審査は廃止し、旧本文は履歴として残す。
* **改定節を追加した文書:** ADR-0175、ADR-0177、RFC-0016、RFC-0015。
* **fence `palw_model_tier_v1`:** `ApprovedModels` は genesis list と追加のみの年次 list で、`c = 0.3`(設計値)、登録 tier の上限 `κ`(設計値)を持つ。
* **狭い interface:** `palw_model_tier_v1(state, params, class)`。RFC02 の登録 lane と RFC-0019 の年次カタログが使う。
* **配分:** `c_m` は `roll_epoch_v3_tiered` で一度だけ掛け、`κ` を適用する。
* **RFC-0016 と RFC-0017 の予算:** tier fence の下では entrant reserve を `ε = 0` とし、Probation 予算は無意味になる。
* **審査の code:** tier fence の下では到達しない。`palw_model_eligibility_v1` は tier fence が同じ高さ以下にあるときだけ arm できる。
* **U-2 の Probation bar:** RFC-0018 の Gate C 述語と認証 sweep から削除した。Gate C 自体は不変である。
* **RPC:** registry 行(wire v4)に `modelTier` と `modelTierPermille` を載せる。
* **試験の対応:** ADR-0179 §試験 source。

## 8. ユーザー判断(同日): RFC06〜12 の設計判断メモは推奨案で進める

ユーザー判断:「推奨で進めて良い」(対象: `docs/design/palw/rfc-0006-0007-0008-0012-remaining-work-2026-10-15.md` §4.1〜§4.6)。

| 項目 | 採用する推奨案 | DAA 14,000 での扱い |
|---|---|---|
| §4.1 T6 lazy verifier | 既存の監査トラップで故意の不正を混ぜ(planted faults)、receipt 署名者にも責任を負わせる | 実装する(休眠 fence、測定値 gate) |
| §4.2 長い source cycle | source を target の commit より厳密に前に封印させ、任意の長さの cycle を構造的に作れなくする | 実装する(休眠 fence) |
| §4.3 Kimi | DAA 14,000 では対象外(credit なし)、後で専用 binding 版 | 対象外のまま |
| §4.4 DNS 退役の照合 | 後の DAA で DNS を退役させる private profile と、harness の coinbase 出力分類 | 実装する。最終証拠は出荷バイナリの DAA 14,000 跨ぎ drill |
| §4.5 fence 前に登録された class | DAA 14,000 では拒否を続け、後でレビュー済みの表を固定 | 拒否のまま |
| §4.6 出どころの無い責任の項 | DAA 14,000 では拒否を続け、後で既存の署名済みフィールドから取る | 拒否のまま |
