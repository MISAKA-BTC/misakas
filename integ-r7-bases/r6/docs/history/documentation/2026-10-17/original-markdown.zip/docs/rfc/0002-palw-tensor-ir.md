# RFC-0002: PALW Canonical Tensor IR v1 (PALW-TIR) — a bounded, deterministic integer tensor program as the consensus meaning of a class, with a reference evaluator and optional fused kernels

> **PALW共通前提 — 2026-10-10:** [ADR-0176](../adr/0176-bond-bounds-palw-production-rewards-and-final-weight.md)を適用する。確率的検証・公開反証・客観裁定に加え、bondと共通DAA期間がclaim発行能力、ブロック数、報酬総額、Final後の確定weightの上限を決める。
> モデル計算はその枠を使用するための正当な仕事であり、同額bond・同期間・同倍率なら計算省略や高速偽造で枠は増えない。有罪なら報酬失効と適用規則上の担保損失を負う。claim容量の倍率を上げてもbond当たりの総経済・consensus creditは増やさない。
> 将来のPALW設計・受入条件に適用し、過去の実測・実装記録・旧claim規則は保持する。上限は検出能力の証明ではなく、公開検証・徴収可能担保・責任保持・独立試験と明示的upgrade/activationを要する。
> **モデル入手への不介入 — 2026-10-10後続改定:** [ADR-0177](../adr/0177-model-bond-allocation-without-availability-consensus.md)を優先する。MISAKA Torrent・専用Seeder・Seeder報酬の概念を廃止する。モデル配布・取得可否を合意で管理せず、PoR/全量取得監査/TRDC/FPRによる資格・weight停止も撤回する。モデル別coinbaseは重複のない拘束miner bond元本に連動し、総発行予算と個別bond上限を維持する。
> 固定モデル同一性とclaim固有証拠の裁定は維持する。外部検証は正しいモデルを入手できた条件で成立し、公開参加の経済優位は倍率式・敵対的評価で立証する未完の目標である。過去の実装/試験/旧規則は保持し、新配分は未実装・未有効化である。


> **Token identity (2026-10-07):** The token name is **Misaka** and its ticker is **BILI** ([ADR-0174](../adr/0174-token-name-misaka-ticker-bili-address-prefix-unchanged.md)). MSK in retained measurements, quotations, command/output examples, identifiers or chain-ID mnemonics is a legacy label for the same coin; it does not change amounts, units, protocol IDs or address prefixes.

> **2026-10-07 中核目標・設計の優先規則:** [ADR-0173](../adr/0173-public-verifier-dispute-completeness-is-misaka-purpose.md)を適用する。普通の非Panel public bondが、producer秘密状態なしにpublic authenticated materialから不正をlocalizeしobjective convictionまで完結できることを目指す。衝突する将来設計は末尾のmission alignment amendmentで改定する。既存Status・実装記録・fenceは履歴として保持し、この追記は実装完了やactivationを意味しない。


| Field | Value |
| --- | --- |
| Status | Draft — implementation in progress: Phases A–C passed Gate 1 on 2026-09-28 (see *Implementation status*) |
| Author(s) | MISAKA core (drafted with Claude) |
| Created | 2026-09-28 |
| Affects | spec/palw 03 (registry), 04/04a (execution, arithmetic), 05 (canonical work), 08 (verification), 09 (court), 14 (node), 16 (fences) · all networks (dormant until armed) · `consensus/core` (admission, court), `misaka-palw-base0` (engines), `misaka-palw-sdk`, `misaka-palw-extension` |
| Working branch | `codex/rfc02-implementation` (2026-10-10 revision); the original text-only branch was `rfc/0002-tensor-ir` |
| Related | ADR-0135 (a model is data; Decision 7 the kernel boundary, historically called VM), ADR-0038 A4 (100 % catalog coverage), ADR-0040 (BASE-0; Decision E order-free accumulation), ADR-0047 (A16), ADR-0049 (adjudication contract), ADR-0052 (QWEN36 ops), ADR-0057 (backends below the semantic boundary), ADR-0069 (e2e adjudicability), ADR-0082/0093 (fused attention and dissection), ADR-0102 (fenced kernels), ADR-0103/0116 (held context, history bound), ADR-0145 (canonical work), ADR-0171/0172 (new verification and kernel-only extension) |
| Part II | Model onboarding (header-only preflight, streaming loader, runtime packs, quant registry, feature scope, staged enablement) — appended 2026-10-01; §II.7.5 records decided rules, not yet built. §§II.10–II.12 add Hub evidence, future-family extension and local-LLM ≥90% coverage; revised 2026-10-06 to remove the VM residual, all open acceptance work |

## Current requirements and historical records — 2026-10-10

The accepted revision in [§II.14](#ii14-completion-contract--2026-10-10) applies the 2026-10-10
design review: complete the public compiler interface, preserve efficient sparse/stateful computation,
derive bounded resources, and bind the whole computation through public verification and terminal court.
It keeps the deterministic tensor IR and versioned kernel boundary. It does not declare any unfinished
implementation, model, resource envelope, coverage target or activation gate complete.

| Current requirement | Authoritative sections | Historical material retained below |
| --- | --- | --- |
| Typed bounded tensor/state graph; **25 frozen v1 primitives**; reusable versioned extensions when necessary | spec 04b and §II.14.2 | The original 30–50 primitive estimate and Gate 1 development sequence |
| Reference/independent/backend bit equality; separate source-checkpoint fidelity | §1.2, §II.4–II.5, §II.14.3 | Architecture fixtures and old conversion measurements prove only their recorded scope |
| Approved probabilistic whole-claim verification, bounded dispute replay and public conviction | Current design boundary, §II.13, mission amendment, §II.14.6; RFC07/14 | Routine full replay in the original admission/verification profile |
| Model acquisition is outside consensus; fixed model identity and claim-specific evidence remain required | ADR-0177 and §II.14.6 | Old model-availability/serving gates are not reinstated |
| Resource ceilings, canonical work and bond-bounded economic credit are separate quantities | ADR-0176, §II.14.4–II.14.5 | Historical PWU measurements are not authorization to enlarge B/R/F rights |
| Completion needs the public extension path and real-checkpoint staged evidence | §II.10–II.12, §II.14; [implementation ledger](../design/palw/tir/rfc0002-implementation.md) | Old “not yet built” annotations record their date, not a current code audit |

## Current design boundary — 2026-10-06

[ADR-0172](../adr/0172-model-extensibility-uses-versioned-kernels-not-a-universal-vm.md)
selects versioned kernels and bounded declarative plans, not BVM/GVM or a universal VM.
TIR is a typed tensor/state graph with bounded scan, not an uploaded ISA or arbitrary verifier.
Existing layer-template code sometimes called a “canonical VM” is a kernel evaluator. New combinations
of active primitives need a frontend and plan; missing semantic, memory, checker or court relations
require a reusable kernel extension and coordinated activation. “SegWit-class” means versioned
extension, not automatic soft-fork compatibility; unknown rewarded operations fail closed.

For new large-model profiles, [RFC07 Part V](0007-palw-verification-certificates-and-algebraic-checks.md)
and [RFC11](0011-permissionless-model-and-long-context-onboarding.md) govern ordinary verification:
bind encoded constraints, perform approved small probabilistic checks covering the whole claim,
then require positive receipts, DA and the challenge window before Final. Exact bounded cone replay
is the dispute backstop, not compulsory routine replay of every selected segment. Admission checks
plan structure, coverage and bounded verifier/court resources using kernel rules; it does not prove
a future inference by recomputing it. Reference evaluators, integer semantics and legacy static-
admission/replay profiles below remain conformance and historical baselines. This amendment changes
no live class or active checker. §§II.11–II.12 replace the former residual-GVM route; ≥90% coverage
remains an unmeasured acceptance target.

## 概要(日本語)

- **目的。** active Kernelで表現できる新アーキテクチャの登録を、モデル名ごとのcoreリリース待ちから解放する。
  新モデルの全演算・taskがactive Kernelで表現できれば、HF config → lowerer → Canonical IR / plan → 登録へ進められる。
  本当に新しい演算は汎用Kernel更新を待つ。モデル名ごとのallowlistやVM fallbackを使わない。
- **今の境界。** canonical kernel evaluator は「層テンプレート + 45 個の kernel id」(`PalwShapeProfileV3`)で、GDN・fused attention・router の
  ような **層単位の kernel がそのまま consensus の命令** になっている。新しい種類の演算は kernel 追加 = リリース = protocol upgrade。
- **v1 の完成条件は「モデル」でなく「アーキテクチャ群」(§1)。** Dense・GQA/MQA/sliding・MoE・線形 attention(GDN)・SSM(Mamba/Mamba2)・
  recurrent(RWKV)・hybrid・routing 変種の代表モデルを **全部いったん分解し**、モデル固有 op を 1 個も足さずに表現できる最小の
  primitive 集合を逆算してから v1 を凍結する。Gate 1と正式仕様04bのv1は25個で、30〜50個は当初の見積り。
  必要な共通意味論は新versionで拡張できる。Qwen3.8(K 16 / V 48)は適合テストの1本にすぎない。
- **なぜ MISAKA で現実的か。** 汎用 VM の最難関は数値の決定性だが、MISAKA は既に **整数のみ**(ADR-0040)。丸めは名前付きの
  lossy site だけにあり、**丸め・saturation・shift・除算を含まず、全中間値が証明済みの範囲に収まる区間**(order-free region, §3.2)では
  加算順序が結果を変えない。規則は一つ: **fused kernel は order-free region の中だけを並べ替えてよく、lossy site を跨いだ融合で
  値を変えてはならず、commit 点の値は 1 bit も変えてはならない。** この下では GPU(int8 dp4a / IMMA / Metal)も許容誤差なしの厳密 backend になる。
- **有界。** ループ・ジャンプ・データ依存 shape は無い。時間方向の再帰は「位置軸上の bounded scan」(§4.2)として一箇所だけ。
  登録時に型・shape、範囲(overflow・不正 shift・0 除算・範囲外 index・過大確保が無いこと)、コスト(計算・メモリ・状態・court 最悪値)、
  court が 1 tile を上限内で裁けることを **すべて静的に証明** し、できなければ登録拒否。
- **court はモデルを知らない。** 知っているのは IR node・入力 commitment・param・出力 commitment・canonical 意味論だけ。争いは
  参照インタプリタで cone を 1 つ再計算して終わる。A4(カタログ 100 % カバー)は **primitive 集合に対して一度だけ** 満たせばよい。
- **ビット一致の範囲。** 参照インタプリタ == 独立の第 2 実装 == 出荷する全 backend はビット一致を要求する。HF の浮動小数モデルとの
  比較は **忠実度指標**(固定評価集合での top-1 一致率・KL・perplexity 差、ファミリーごとの閾値)で、ビット一致ではない(整数量子化は
  意図的に出力を変えるため)。
- **順序。** 意味論を固定し、参照実装・範囲／コスト検証・lowerer・checker・courtを揃える。
  高速実装と証拠生成の性能測定は並行し、実サイズで実現不可能なloweringを後から発見しない。
  既存kernelはIR patternのfused実装としてビット一致する範囲で利用する。
- **工数感。** 2〜4 人で 6〜9 か月。既存の Qwen3.6-35B(16/32)も踏んでいる GDN の k≠v 不具合の修正は、本 RFC とは別の小さな
  修正として独立に進められる(§7 Phase 0)。
- **名称と「VM ではない」こと(09-28)。** PALW-TIR は有限の静的グラフ + 静的な層スケジュール + 位置方向の scan だけで、実行中の
  分岐・ループ・ジャンプ・呼び出しは無い。reference evaluator はそれを評価するだけで、program counter を持つ VM ではない。
  題名を Canonical ML IR から **PALW Canonical Tensor IR** に改めたのはこの誤解を避けるため(crate 名 `misaka-palw-tir` は元から一致)。
- **frontend とコンパイラ基盤(09-28 評価)。** 主経路は HF の `config.json` + `transformers` の modeling コード → lowerer。
  ONNX・GGUF は v1 凍結後の任意の第 2 frontend(consensus 外)。MLIR は consensus にも参照ツールにも入れない — 誰が MLIR 等で
  TIR を生成してもよく、正準エンコーディングと検証器がそのまま接点になる。採らない理由は Alternatives の表。
  Rust 製の pliron(MLIR 風)も評価し、参照 lowerer の内部 IR には今は採らない(検証器・正準形・評価器は consensus 側が自前で持つ
  必要があり、pliron はその二重定義になる)。第三者の利用は自由、凍結後に任意の dialect adapter、lowerer の Gate 2 で再評価。

- **Part II(10-01 追記)。** モデル受け入れの標準経路 — header だけで読む preflight、streaming 変換と runtime pack、量子化 descriptor、feature scope、convert / register / mine の段階的な有効化(consensus に触れる §II.7.5 は決定済み・未実装)。本文は末尾の Part II。

## Summary

Replace the consensus meaning of a PALW class — today a layer-template graph whose nodes name one of
45 hand-written kernels — with **PALW Canonical Tensor IR v1 (PALW-TIR v1)**: the frozen set of 25
architecture-neutral integer primitives, and a class program that is a static, bounded DAG over them,
carried as chain data. **v1 is frozen on an architecture corpus, not on a model**: it is accepted only
when representatives of every major decoder family lower to it without a single model-specific
primitive. Native kernels, including every kernel we have today, become optional fused kernels: node
software that is byte-identical to the reference evaluator at every commit point and never part of
the identity. The court knows the primitives and nothing about models.

**Terminology: an IR, not a VM.** A PALW-TIR program is a finite static DAG, a static layer schedule
and a scan over positions whose trip count is the job's length. It has no program counter, branch,
jump, loop or call, and every cost is known at registration. The *reference evaluator* evaluates such
a program; it is an interpreter only in the sense that it walks the graph (in `misaka-palw-tir`).

## Motivation

### 1. Where the boundary is today

ADR-0135 Decision 7: a graph the active kernel evaluator expresses is permissionless; a new op is
a protocol upgrade. The original ADR called this the “canonical VM”; it is not a future model VM.
The problem is how coarse the existing kernel relations are.

- **The graph is one fixed schema.** `PalwShapeProfileV3` (`consensus/core/src/palw_step.rs:409-500`)
  holds four node tables (`pre / gdn / attn / post`, ≤ 64 nodes each), per-layer weight templates,
  geometry scalars, and a layer schedule that is either attention or GDN by `full_attention_interval`
  (two hard-coded variants, V1 `(i+1)%n` and V2 `i%n`, the second added for Kimi: `:752-765`).
- **An op is a kernel.** Each node names a `kernel_semantics_id`. The 18-variant `op_kind` tag
  (`:191-235`) is only a label (`MulElem` carries a requantize kernel, `SoftMax` a router top-k). The
  catalog holds 45 kernels: 7 float, 10 BASE-0, 12 A16, 16 Q36, plus 1 + 4 fenced
  (`palw_step_refute.rs:286-331`). BASE-0's ten are primitives; the Q36 and Kimi kernels are whole
  subgraphs (`GatedDeltaNet`, `AttnFused`, the router, the MoE combine).
- **Conventions live in code, not in the identity.** GDN value head `vh` reads key head
  `vh % k_heads`, hard-coded three times (engine `misaka/palw/base0/src/qwen36.rs:1239-1262`, float
  reference `qwen36_reference.rs:273-277`, court `palw_step_refute.rs:3218-3222`). The schema has one
  `gdn_heads` (`palw_step.rs:459`); the key-head count is not in the class id. The state chunk maps
  size the conv row as `(2k+v)·gdn_heads` (`palw_state_chunk_map.rs:1038-1039,1109-1111`) where the
  true width is `2·k_heads·hd + v_heads·hd` — correct only when `k_heads == v_heads`. Qwen3.6-35B
  (16/32) and Qwen3.8-27B (16/48) are both on the wrong side of it (`fp_recompute.rs:1296-1306`).
- **Semantics also live in names.** Economic compute detects MoE by the substrings `"router"` and
  `".routed"` in weight names (`palw_economic_compute_v1.rs:297-325`). `UnsupportedOp` is derived from
  `verification_ccu > 0` (`palw_model_registry_v1.rs:792`), a proxy. The manifest's `graph_ir_root`
  is a placeholder used only in tests (`palw_model_registry_v1.rs:29-37`).

### 2. What a new architecture costs today

| Lineage | Consensus code | New kernels | Runtime / tools |
| --- | --- | --- | --- |
| BASE-0 | ≈3,100 lines | 10 | `engine.rs`, `plan.rs` |
| Qwen2.5 A16 | ≈2,100 (+ A16 tier 1,237) | 0 | ≈13,000 lines of engine/backend/convert |
| Qwen3.6 | ≈4,450 incl. court arm | 16 + 1 fenced | ≈10,600 |
| Kimi K3 | ≈1,700 | 4 fenced | none; no e2e certificate |

Every family has needed a profile module, a court arm per kernel, an engine, a converter and an SDK
lineage (`docs/palw-model-onboarding-sdk.md:80-82`). That is a release per family, and each release
is a fence, a drill and a flag day. Adding `QWEN_GDN`, `MAMBA2` or `DEEPSEEK_MOE` as ops of a new IR
would reproduce the same problem a few years later.

### 3. Why this is tractable here and would not be elsewhere

The hard part of a general ML VM on a chain is numerical determinism: reduction order, FMA
contraction, rounding modes, vendor kernels. **MISAKA already removed it.** Every live class is
integer-only (ADR-0040 A: no libm, no float on the consensus path). Inside a proved no-overflow bound,
integer addition is exactly associative (ADR-0040 E). Information is lost only at *named* sites, each
with its own rule (ADR-0040 C1, ADR-0047, ADR-0052). ADR-0057 already lets a backend fuse and reorder
below a committed row provided the row is byte-identical.

The step from "a catalog of kernels" to "a catalog of primitives" therefore needs no new numerical
theory. It needs the kernels decomposed along the lossy sites they already have, and the checks the
kernels perform by hand (bounds, shapes, court cost) turned into static analyses over a program.

## Goals and non-goals

**Goals.**

- G1. A class program is data: a static DAG over a closed primitive set, hashed into the class id.
- G2. **v1 is complete for an architecture corpus (§1), with zero model-specific primitives.**
- G3. Every admissible program is adjudicable by construction; A4 is proved once, for the primitives.
- G4. Every admissible program's ranges, costs and court ceilings are derived at registration, exactly.
- G5. The court knows no model. It interprets primitives over committed values.
- G6. Native speed stays available through fused kernels outside the identity — built last.
- G7. The canonical work vector (ADR-0145) is derived structurally, with no name heuristics, and stays
  representation-neutral (PALW-WK-3).
- G8. Today's classes keep running unchanged; today's kernels become fused kernels of IR patterns.
- G9. A tool answers "is this model permissionless?" from a Hugging Face `config.json`, with the same
  function consensus admission calls.

**Non-goals.** Turing completeness; loops with data-dependent trip counts; jumps; recursion; dynamic
shapes. Floating point on the consensus path (ADR-0053 stands). Arbitrary user code (WASM, eBPF, CUDA)
as consensus semantics. zk proofs of inference. Changes to collateral, panels, the lottery or the
claim lifecycle. Sampling (it stays in the logits scheme and the FP job, RFC-0001).

## 1. The conformance corpus and the v1 freeze criterion

This section is the RFC's acceptance test and is fixed **before** any implementation.

### 1.1 The corpus

| # | Family | Representatives (at least one real checkpoint each, plus reduced configs) | What it exercises |
| --- | --- | --- | --- |
| C1 | Dense Transformer | Llama 3.x, Qwen2.5/Qwen3 dense, Mistral 7B, Gemma 2/3 | RMSNorm variants (Gemma's `1+w`), SwiGLU/GeGLU, RoPE variants (YaRN, partial), logit soft-capping, tied embeddings |
| C2 | Attention variants | Llama (GQA), Falcon/PaLM-style (MQA), Mistral / Gemma (sliding + global) | head grouping, windowed history, alternating layer schedules |
| C3 | MoE | Mixtral 8×7B, Qwen-MoE / Qwen3-MoE, DeepSeek-V2/V3 | top-k routing, shared experts, grouped (group-limited) routing, normalised and unnormalised gates |
| C4 | Linear attention | Qwen3.6 / Qwen3.8 GDN (16:16, 16:32, 16:48, 24:72, 32:128 head ratios) | gated delta rule, short causal conv, L2-normalised keys, unequal key/value heads |
| C5 | SSM | Mamba, Mamba2 | selective scan, `softplus(dt)`, `exp(A·dt)` decay, conv window, grouped B/C |
| C6 | Recurrent | RWKV-6/7 | token shift, data-dependent decay, WKV state |
| C7 | Hybrid | Qwen3.6 (attention + GDN), Jamba (attention + Mamba + MoE), Kimi-style schedules | per-layer block schedules, mixed state kinds |
| C8 | Routing variations | top-1/top-2/top-8, shared + routed, grouped top-k, expert bias terms | selection semantics and tie rules |

Each family is exercised at two scales: **reduced configurations** (same architecture, small widths
and depths, random and extreme-range weights — for bit identity and fuzzing) and **one real small
checkpoint** (≤ 3B where one exists — for fidelity).

### 1.2 The freeze criterion

PALW-TIR v1 is acceptable only if **all** of the following hold, and it is frozen (its `prim_set_id`
fixed) at the moment they first hold together:

1. **No model-specific primitive.** Every corpus family lowers to the primitive set. A primitive is
   named and defined by mathematics (`MatMul`, `Gather`, `IntExp`), never by an architecture or a
   model (`QwenGdn`, `Mamba2Scan`, `DeepSeekRoute` are refused by name).
2. **Minimality.** No primitive is expressible byte-identically by the others at equal court cost.
   The target is 30–50 primitives.
3. **Stability under the last family.** If lowering the last family added to the corpus forces a new
   primitive, v1 is not frozen: the new primitive must be general (useful to at least two families,
   or a standard mathematical operation), and the whole corpus is re-lowered.
4. **Three-way bit identity.** For every corpus program, on every generated input:
   `reference evaluator == independent second implementation == every backend that ships`, byte for
   byte, at every commit point.
5. **Fidelity against the float original.** The integer program is compared with the family's
   Hugging Face float reference on a fixed evaluation set — top-1 agreement, KL divergence and
   perplexity difference — against per-family thresholds set in Phase A. The reference is pinned:
   the `transformers` version the fixtures name (5.17 at Gate 1), eager attention, and per-position
   decode — `transformers` disagrees with itself across attention backends and between prefill and
   decode (soft-capping under sdpa, dynamic NTK and LongRoPE frequency switching). **This is not a bit-identity
   requirement**: static integer quantization changes outputs by design, and ADR-0053 withdrew
   tolerance from consensus. Fidelity decides whether a lowering is *useful*, never whether a claim is
   *valid*.
6. **Legacy conformance.** Each of today's integer catalog kernels (the 45 less the 7 float kernels,
   plus the fenced `RequantizeByToken`) is expressed as an IR segment and is byte-identical to it (so today's semantics are a subset of v1, and today's kernels can become fused
   kernels).
7. **Static verifiability.** Every corpus program passes the range, cost and court analyses of §3
   within the proposed ceilings, or the ceiling is revised with a stated reason.

Qwen3.8 (K 16 / V 48) is one test in C4, not the goal. Under the criterion, `16:32`, `16:48`, `24:72`
and `32:128` are shape data, not kernels.

## 2. Architecture

```
HF config.json + transformers modeling code (primary) · ONNX / GGUF importers (optional) · custom
             │   (outside consensus: anyone may write these)
             ▼
   Architecture lowerer (per family, data-driven templates)
             ▼
   High-level ML graph (RMSNorm, attention, GDN, MoE … as library subgraphs)
             ▼
   PALW Canonical Tensor IR v1 (PALW-TIR) ── tensor shape/index · integer arithmetic · reductions
                                     routing/indexing · quantization boundaries · bounded state
═════════════════════ CONSENSUS BOUNDARY ═════════════════════
   Static verifier (types · ranges · costs · court cones)   → admission
   Reference evaluator (slow, obviously correct)            → the court, the meaning of "correct"
             │
   Backends (CPU · Metal · CUDA), generic primitive kernels + fused kernels   → node software
```

Consensus knows the IR and nothing above it. Who wrote a lowerer, an importer or a Metal kernel
confers no protocol authority.

**Frontends and compiler infrastructure.** The primary frontend is a Hugging Face checkpoint: its
`config.json` read conservatively (every key that can change the math is understood or the model is
refused, never silently ignored) and its semantics taken from the `transformers` modeling code, which a
new architecture ships with on release day. ONNX and GGUF importers are optional secondary frontends
after the v1 freeze; they target the same high-level graph and add nothing to consensus. No compiler
infrastructure is a dependency of consensus or of the reference tools: anyone may produce TIR with
MLIR, TVM or a script, because the canonical encoding (§4.1) and the verifier
(`palw-class check-architecture --tir`) are the whole interface.

## 3. The primitive set (starting hypothesis)

Phase A derives the final list from the corpus. The table below is the hypothesis Phase A starts from
and must confirm, extend or shrink.

**The granularity rule.** A primitive boundary sits at an exact integer operation or a named lossy
site; everything above that is library (§3.3). Finer primitives do not raise the commitment cost,
because commit points are chosen per cone (§6), not per node — the lower bound on granularity is
exactness at the lossy sites, the upper bound is that no primitive knows an architecture.

### 3.1 Types and shapes

Tensors are raw integers. Quantization parameters are op attributes (`Requantize(mult, shift)`) or
parameter tensors from the artifact (per-channel scales, ADR-0050 D); there are no float values and no
scale types.

| Type | Use | May be committed |
| --- | --- | --- |
| `i8`, `i16` | activations (BASE-0 int8, A16 codes), weights | yes |
| `i32` | narrowed accumulators, fixed point Q[k], logits, state | yes |
| `i64` | exact wide accumulators inside a segment | **no** (the A16 rule "i64 never crosses a step boundary", generalised) |
| `idx` (u32) | token ids, positions, selection indices | yes |

Rank ≤ 4. Every dimension is a constant except the symbolic `H` (history length,
`1 ≤ H ≤ min(pos + 1, window) ≤ history_bound`, PALW-EX-16).

### 3.2 The order-free region

**Definition.** An *order-free region* is a connected set of nodes in which (a) every node is an exact
primitive (§3.3 kinds S and E), (b) no node saturates, shifts right, divides or rounds, and (c) the
range analysis (§5.2) proves every intermediate value, **for every association and every order of
every sum in the region**, within its declared type. Only inside an order-free region may an
implementation reassociate, reorder, regroup, tile or parallelise arithmetic. A region ends at every
lossy primitive, every selection primitive, every commit point and every state write.

Condition (c) is the reason the range analysis bounds a sum by `len · max|term|` rather than by the
final value: a partial sum in any order is then also inside the bound.

### 3.3 Primitives

| Kind | Primitives | Notes |
| --- | --- | --- |
| **S — structure** (exact, no arithmetic) | `Reshape`, `Permute`, `Slice`, `Split`, `Concat`, `Broadcast`, `Pad(const)` | static bounds, checked at admission; head tiling and grouping are `Reshape`+`Broadcast` |
| **S — indexing / routing** | `Gather(axis)`, `Scatter(axis)` (candidate), `Iota` | `Gather` over a pinned table is also how narrow-input activations and RoPE tables are evaluated (data, not arithmetic) |
| **E — exact arithmetic** | `Widen`, `Add`, `Sub`, `Mul`, `Neg`, `Min`, `Max`, `Abs`, `ShiftLeft` | results in a declared type proved to fit |
| **E — linear algebra** | `MatMul(acc)`, `BatchedMatMul(acc)` | contraction length bounded by range analysis |
| **E — reductions** | `ReduceSum(axis, acc)`, `ReduceMax(axis)`, `ReduceMin(axis)` | |
| **L — quantization boundaries** (lossy, each names its rule in `R = {HalfAwayFromZero, HalfUpSRDHM, Floor, Saturate}`) | `Requantize`, `Rescale`, `Narrow(shift, rule, to)`, `Clamp(lo, hi)`, `ShiftRight(n, rule)`, `DivConst(d, rule)` | the only primitives that lose information |
| **L — integer transcendentals** | `IntExp`, `IntLn`, `IntRsqrt`, `IntRecip`, `IntSigmoid` (candidate: library) | the fixed-iteration algorithms of 04a Decision F and ADR-0052 D, constants pinned by hash; never libm |
| **X — selection** | `Compare(cmp)`, `Select`, `ArgMax`, `TopK(k)`, `Sort` (candidate) | ties break to the **lowest index**; `TopK` returns its set in index order (ADR-0052 B) |
| **T — bounded state** | `StateRead`, `StateWrite` (saturates to the declared range), `HistAppend`, `HistRead(window)` | the position-axis scan of §4.2 |
| **T — within-step scan** (candidate) | `BoundedScan(body, axis, len)` | only if the corpus shows a recurrence *inside* one position (see §4.2) |

About 40 primitives, in the target range. Four properties follow:

- **Activation functions on narrow inputs are data.** An `i8`/`i16` activation (GELU, SiLU, a new one
  next year) is `Gather(table, x)` over a 256- or 65,536-entry table pinned in the artifact — PALW-EX-5
  ("a transcendental evaluated at registration is data") applied to activations.
- **Head layouts are data.** `vh % k_heads` (tiling) and `vh / (v_heads / k_heads)` (grouping) are
  both `Reshape` + `Broadcast` + `Reshape`. Which one a model uses is in its program and its class id.
- **MoE is explicit.** Routing is `TopK` → `Gather` over expert weights; grouped routing is
  `TopK` over group scores → `Select` mask → `TopK`. Canonical work counts active experts from the
  graph, not from weight names.
- **Composite ops are library subgraphs**, not primitives: `RmsNorm`, `LayerNorm`, `SoftMax`, `Silu`,
  `GeGLU`, `L2Norm`, RoPE, attention, the gated delta rule, the selective scan step, the WKV step, the
  causal conv, the MoE combine. The library (`tir_library_v1`) is data used by lowerers and by fused
  kernel patterns. Consensus sees only expanded primitives.

`Scatter`, `Sort`, `IntSigmoid` and `BoundedScan` are marked *candidate*: Phase A keeps them only if a
corpus family needs them and the others cannot express them at equal court cost.

## 4. The program, `TirProgramV1`

### 4.1 Structure

```
TirProgramV1 {
  version: 1,
  prim_set_id: Hash64,                                            // PALW-TIR v1
  inputs:  { token: idx, pos: idx },                              // one position per step
  params:  [ParamDecl { name, dtype, shape, per_layer: bool }],   // bound to artifact inventory tensors
  consts:  [ConstDecl { name, dtype, shape, bytes }],             // small inline constants, ≤ 64 KiB total
  states:  [StateDecl { name, kind: Fixed | Hist, dtype, shape, range, window?, per_layer: bool }],
  blocks:  [Block { name, carry_in, nodes: [Node], carry_out }], // e.g. pre, attn_layer, gdn_layer, moe_layer, post
  schedule: { layers: u16, kinds: [u8; layers] },                 // which block each layer runs
  outputs: { logits: NodeRef, logits_scheme_id },
  history_bound: 2^18 | 2^21,
}
Node { prim: u8, attrs: canonical bytes, inputs: [Ref; ≤ 8], out: { dtype, shape }, commit: bool }
Ref  = Node(i < self) | CarryIn | Param(j) | Const(j) | State(j) | Input(j)
```

- **The layer loop is a schedule, not a loop.** `schedule.kinds` names, per layer, the block that
  layer runs (`layers ≤ 1024`). This generalises `full_attention_interval` V1/V2 to any pattern —
  Gemma's sliding/global alternation, Jamba's attention/Mamba/MoE mix, a model whose first layers are
  dense and the rest MoE — without a schema version. Per-layer params and states are indexed by layer.
- **Refs point strictly backward.** Node order is the canonical topological order; the node index is
  the node's identity in commitments (`input_refs` already enforces this, `palw_step.rs:640-652`).
- **Canonical encoding.** Borsh, in a normal form admission enforces (no dead nodes, no duplicate
  consts, canonical attribute order, shapes fully inferred and equal to the declared `out`), so the
  program hash is the program.
- **Identity.** `graph_ir_root = H(TirProgramV1)` becomes a real field (the ADR-0135 placeholder). The
  class id commits to `graph_ir_root`, `artifact_root`, the tokenizer and the logits scheme, and **not**
  to node-local knobs (`n_threads`, `repack_on`, which today are inside the class id,
  `palw_step.rs:466,478`).

### 4.2 Time: the bounded scan over positions

A program computes **one position**: the logits for `token` at `pos`, reading and writing its states.
A run of `T` positions is the scan of that step over `0..T-1`, bounded by `history_bound`. This is the
bounded scan, and it lives in exactly one place:

- `Fixed` states carry recurrences: the GDN state `S`, the Mamba state `h`, the RWKV WKV state, conv
  windows, token shift. `StateWrite` saturates to the declared range (a named lossy site), so the
  recurrence stays inside its interval whatever the data. (Its *real* bound is ADR-0052 E's
  contraction argument; the saturation makes the analysis total, not tighter.)
- `Hist` states are append-only histories: the KV cache. `HistRead(window)` yields the last
  `min(pos + 1, window)` rows, which covers sliding-window attention with no dynamic slice.

Prefill is the same step at positions `0..T-1`. A backend batches prefill however it likes
(PALW-EX-12's "one pass over the weights" is a scheduling rule and is unchanged), but its committed
values must equal the per-position semantics. For recurrences this means a chunked-parallel prefill
(Mamba2's SSD form, chunked GDN) is a fused kernel only if it reproduces every per-position lossy site
— possible but hard, and exactly the kind of work that comes last.

**Within-step scans.** If a corpus family has a recurrence *inside* one position (none of C1–C8 is
known to), Phase A adds `BoundedScan(body, axis, len)` with a static `len`, a body that is itself a
TIR block, and the body's cost multiplied by `len` in every analysis. Until then it is not in v1.

## 5. Static verification (admission)

Admission of an IR class runs four analyses, each one pass, linear in the unrolled node count. A
program that any analysis cannot prove is refused; there is no "probably fine".

### 5.1 Types and shapes

Every node's output type and shape is inferred and must equal its declared `out`. `H` propagates
symbolically. A shape error is a refusal, never a panic (PALW-EX-5's totality rule).

### 5.2 Ranges

Each tensor gets an integer interval. Inputs and params take their type's full interval (a weight
declared `i8` is `[-128, 127]` — weights are not trusted to be small); states take their declared
range; `H` takes its bound. Each primitive has a sound transfer function (for `MatMul`,
`len · max|a| · max|b|`, which also bounds every partial sum in every order, §3.2(c)). Admission must
prove, for every node:

- **no overflow** of any exact primitive's declared type, including every partial sum;
- **no illegal shift** (every shift amount static and within `[0, width)`);
- **no invalid divisor** (`DivConst` divisors are nonzero constants; division inside the transcendental
  algorithms is proved nonzero by their domains);
- **no out-of-bounds index** (`Slice` bounds static; `Gather`/`Scatter` index intervals within the
  gathered axis; `TopK` `k` ≤ axis length);
- **no oversized allocation** (every tensor and every state within the size caps of §5.4).

The result is a guarantee handed to every runtime: *inside an order-free region, overflow cannot
happen.* That guarantee is what makes reassociation and fusion safe.

### 5.3 Costs

Each primitive has closed cost formulas. The analysis reports, per position and at the worst case
(`H = history_bound`):

- **compute**: MACs, elementwise ops, transcendental evaluations;
- **memory**: bytes read and written, peak live bytes in canonical order;
- **state**: bytes of `Fixed` and `Hist` state per layer and in total;
- **court worst case**: the largest terminal recomputation any single disputed tile can require (§6).

The formulas upper-bound the reference evaluator's work; their coefficients are benchmarked with a
margin in Phase D. Admission refuses a program over any network ceiling.

### 5.4 Court feasibility and size caps

For every commit point, the *cone* of its output — the nodes back to the nearest commit points, params,
consts, states and inputs — must fit the court's existing ceilings (`derive_court_cost_v1`: ≤ 16 Mi
terminal MACs per tile, ≤ 8 operands, ≤ 27 close chunks; `palw_mode_v2.rs:551,616,620`). Large nodes
are adjudicable at three levels, **IR node → canonical chunk → tile**:

- a `MatMul` output is committed in tiles; one tile is `tile_len` dot products, each within the
  contraction bound;
- a reduction over `H` must be **dissectable**: between the `HistRead` and the reduction there are
  only exact primitives and lossy primitives that act on one history position (a per-position
  `IntExp` of a score is fine; rounding a running sum is not). The reduction is exact, so the court
  dissects it by partial sums over canonical chunks of `H`, and the partials add without error. This
  is ADR-0082's attention dissection stated as a property of the program, and it fixes the canonical
  softmax as two-pass (maximum first, then exact sums);
- a cone that crosses a `StateRead` stops there: the state is an operand opened from the checkpoint
  leg, or replayed from the nearest checkpoint. Admission derives each `Fixed` state's maximum
  checkpoint interval `C` (the canonical chunk of the position scan) so that replaying `C` positions of
  its update cone fits the ceiling.

Size caps (proposed; sized in Phase D): program ≤ 256 KiB; blocks ≤ 16; nodes per block ≤ 512;
layers ≤ 1024; inputs per node ≤ 8; rank ≤ 4; any dimension ≤ 2^24; elements per tensor ≤ 2^28;
consts ≤ 64 KiB; states ≤ 16 per layer; step leaves ≤ 2^22 (existing). The registration price (1 BILI
burned, ≤ 4 bought registrations per block, `palw_state_v2.rs:7411,7426`) bounds how often admission
runs.

## 6. Commitment and the court

- **Commit points.** A node with `commit = true` materialises its output as committed tiles in the
  step leg, as a node output does today (`(call, node_slot, position, tile)`,
  `palw_step_leg.rs:1207-1228`), with `node_slot` = the node's unrolled index. Lanes stay 4 bytes.
- **Required commit points:** every block's `carry_out`; the logits; every `idx` tensor produced by a
  selection primitive that feeds a `Gather` over params (a wrong selection makes everything
  downstream unrelated, and no arithmetic bisection converges — ADR-0052 B — so the selection itself is
  an opened value); the input of every `StateWrite` and `HistAppend`. Lowerers add further commit
  points until §5.4 passes.
- **A cone is the unit of adjudication.** The terminal refutation opens one committed output tile and
  its cone's committed inputs, proves params against the artifact root (as today), and **interprets
  the cone** with the reference evaluator. One court arm replaces the per-kernel arms (`qwen36_row`,
  `base0_row`, `kimi_row`, …).
- **The court knows no model.** It sees a node, its input commitments, its params, its output
  commitment and the primitive semantics. A4 becomes "the court covers PALW-TIR v1", proved once;
  `palw_court_catalog_root_v1` gains `prim_set_id`; the coverage certificate for an IR class is "every
  node's primitive is in v1". For an admitted program `Unadjudicable`
  (`palw_step_refute.rs:2514-2520`) can only mean an interpreter defect, which the second
  implementation and the golden vectors exist to catch.
- **Bisection is unchanged** (`palw_bisect.rs`: step leaves or trace events, ≤ 48 rounds, rung
  deadlines, silence loses) over the same step space.

## 7. Fused kernels (built last)

A fused kernel is `(pattern, implementation)`: an IR subgraph template with exact structural
constraints (primitives, attributes, shapes, ranges) and native code for it.

- **F-1 (byte identity).** For every input in the pattern's declared domain, a fused kernel must
  produce, at every commit point inside or at the edge of the pattern, the bytes the reference
  interpreter produces. There is no tolerance (ADR-0057 D1).
- **F-2 (what may move).** A fused kernel may reorder, regroup, tile, vectorise or parallelise only
  inside order-free regions (§3.2). It must reproduce every lossy site's result; fusing *across* a
  lossy site is allowed only if the lossy site is still computed on exactly the same value.
- **F-3 (outside the identity).** A fused kernel is node software. It appears in no object, class id
  or fingerprint, and needs no fence (ADR-0057 D1/D2). Shipping one is a node release.
- **F-4 (the gate).** A fused kernel ships only with a differential gate that fires: random and
  range-extreme inputs against the reference evaluator *and* the independent second implementation,
  per backend (ADR-0057 D3).
- **F-5 (matching).** A pattern matches by structural equality after canonicalisation. An unmatched
  subgraph runs on generic primitive kernels.
- **F-6 (GPU).** Every primitive is integer and every order-free sum is order-independent, so an integer
  GPU backend (int8 `dp4a`, tensor-core IMMA, Metal integer SIMD) is an *exact* backend under F-1, not a
  tolerant family. ADR-0053's objection was to tolerance, which this does not need.

**Today's kernels are kept, as fused kernels.** Freeze criterion 6 expresses each of the 45 kernels as
an IR segment. Where the segment is byte-identical on the differential gate, the kernel becomes that
pattern's fused implementation; today's GDN, router and attention engines keep their speed.

**Runtime residency (node software, like the fused kernels).** Where a class's weights are held is the
node's decision, under ADR-0112's budget, with the tiers read off the program's dataflow — pinned
params read whole every forward, routed rows a route selects (a mixture's experts), gathered rows an
input selects (embeddings, n-gram tables) — and nothing read through a page fault:
[`docs/design/palw/tir/runtime-residency.md`](../design/palw/tir/runtime-residency.md). It changes
no byte any commitment sees (the identity is tested at the floor, at a fifth and against the page
cache), appears in no object, id or fingerprint, and ships as a node release.

## 8. The tool: `palw-class check-architecture`

```
palw-class check-architecture --config config.json [--weights-index model.safetensors.index.json]
palw-class check-architecture --tir program.tir
```

A lowerer (non-consensus, `misaka-palw-sdk`) turns a Hugging Face config into a program using the
library templates; the verdict comes from `tir_admit_v1`, the same function consensus admission calls,
without network state.

| Verdict | Meaning |
| --- | --- |
| `ADMISSIBLE` | registrable as data; fused kernels cover every hot pattern |
| `ADMISSIBLE_GENERIC` | registrable as data; some patterns run on generic kernels (estimated slowdown printed) |
| `LOWERABLE_UNVERIFIED` | lowered from an architecture whose float reference is remote code the tool cannot run offline; the verdict above it holds, the fidelity column is empty |
| `EXCEEDS(limit, value, cap)` | a size, range, cost or court ceiling fails |
| `NEEDS_PRIMITIVE(name)` | outside active kernel semantics: report `KERNEL_EXTENSION_REQUIRED` with relation and limits, then propose a reusable semantic/checker/court extension (§II.12); no VM fallback |
| `NOT_LOWERABLE(reason)` | no lowerer template for this family; the model may still be expressible by hand |

A legacy mode reports the same verdicts against today's `PalwShapeProfileV3` catalog, so the tool is
useful before the IR is armed.

## 9. Proposed Spec text (new chapter `spec/palw/04b-tensor-ir.md`)

Applies past `palw_tir_v1`. Legacy `PalwShapeProfileV3` classes keep chapter 04 unchanged.

- **PALW-TIR-1 (the primitive set).** An IR class's execution MUST be the evaluation of its
  `TirProgramV1` over PALW-TIR v1. No other operation has consensus meaning.
- **PALW-TIR-2 (integers only).** Every value on the consensus path MUST be an integer of a declared
  type. ADR-0040 A applies to the interpreter and to every backend.
- **PALW-TIR-3 (named loss).** Only lossy primitives MAY lose information, each by its declared rule.
  Every other primitive MUST be exact.
- **PALW-TIR-4 (order-free regions).** An implementation MAY reassociate or reorder arithmetic only
  inside an order-free region (§3.2). Everywhere else it MUST follow the program's order.
- **PALW-TIR-5 (no wide commitment).** An `i64` tensor MUST NOT be a commit point.
- **PALW-TIR-6 (bounded structure).** A program MUST be a DAG with strictly backward refs and a static
  layer schedule of at most 1024 layers; no dimension other than `H` MAY be non-constant.
- **PALW-TIR-7 (canonical form and identity).** Admission MUST refuse a program not in normal form.
  The class id MUST commit to `graph_ir_root` and MUST NOT commit to node-local knobs.
- **PALW-TIR-8 (shapes).** Admission MUST infer every shape and refuse any mismatch.
- **PALW-TIR-9 (ranges).** Admission MUST prove from type-worst-case inputs that no exact primitive or
  partial sum overflows, no shift is illegal, no divisor can be zero, no index is out of bounds and no
  allocation exceeds its cap. A program it cannot prove is refused.
- **PALW-TIR-10 (state).** A `Fixed` state MUST declare its range and `StateWrite` MUST saturate to it.
  A `Hist` state MUST be append-only and bounded by `history_bound` and its window.
- **PALW-TIR-11 (selection).** Selection primitives MUST break ties to the lowest index; `TopK` MUST
  return its set in index order. A selection that feeds a param `Gather` MUST be a commit point.
- **PALW-TIR-12 (cost).** No worst-case cost of §5.3 MAY exceed the network's ceiling.
- **PALW-TIR-13 (court cones).** Every commit point's cone MUST fit the court ceilings; every reduction
  over `H` MUST be dissectable; admission MUST derive each `Fixed` state's checkpoint interval.
- **PALW-TIR-14 (commit points).** Block outputs, logits, selections that feed a param `Gather`, and
  every state write MUST be commit points.
- **PALW-TIR-15 (the court).** A terminal refutation of an IR class MUST recompute the disputed tile
  by interpreting its cone over PALW-TIR v1. `court_catalog_root` MUST commit to `prim_set_id`.
- **PALW-TIR-16 (canonical work).** The work vector (PALW-WK-1) of an IR class MUST be derived from the
  program's structure; commit points and `tile_len` MUST NOT change it (PALW-WK-3).
- **PALW-TIR-17 (backends).** A backend MAY implement any subgraph natively, provided every commit
  point is byte-identical to the reference evaluator. A fused kernel MUST NOT appear in any
  consensus object.

## Activation plan

The order is the point: **corpus → semantics → reference evaluator → verifiers → lowerers → court →
fused kernels → migration.** Fused kernels come last so that no performance need can pull a
model-specific semantic back into the IR.

| Phase | Work | Consensus change | Exit gate | Effort (2–4 people) |
| --- | --- | --- | --- | --- |
| **0** (independent, may run now) | (a) fix GDN `k_heads ≠ v_heads` in the *live* kernels — it already affects Qwen3.6-35B (16/32); (b) `check-architecture` legacy mode | (a) its own small fence on testnet-12; (b) none | (a) a 16/32 and a 16/48 fixture replay and adjudicate end to end | 2–4 weeks |
| **A. Corpus** | Lower every corpus family (§1.1) to a high-level graph and then, on paper and in a throwaway prototype, to candidate primitives; set fidelity thresholds per family | none | a primitive list that meets freeze criteria 1–3 on paper | 4–6 weeks |
| **B. Semantics** | The normative definition of every primitive (types, shapes, exact integer semantics, rounding rule, range transfer function, cost formula); golden vectors `consensus-vectors/tir-v1/` | none | reviewed spec text; vectors for every primitive incl. range extremes | 3–4 weeks |
| **C. Reference evaluator** | `misaka-palw-tir`: slow, obviously correct, no SIMD, no fusion; and an independent second implementation from the spec alone | none | both pass every golden vector; they agree on fuzzed programs | 4–6 weeks |
| **D. Verifiers** | `tir_admit_v1`: types, ranges, costs, court cones, normal form, size caps; cost coefficients benchmarked; admission CPU time measured | none | every corpus program verifies; mutation tests (overflowing, OOB, oversized, non-dissectable programs) are all refused | 4–6 weeks |
| **E. Lowerers** | Library templates and lowerers for C1–C8; quantisation/calibration tooling; fidelity runs; legacy conformance of the 45 kernels | none | freeze criteria 4–7; **v1 frozen, `prim_set_id` fixed** | 6–8 weeks (overlaps C/D) |
| **F. Court and admission** | Interpreter court arm, generic `H` dissection, generic checkpoint replay, structural work derivation, admission v10 — all behind dormant `palw_tir_v1`; drills | dormant fence | devnet drill registering **Qwen2.5-A16 as an IR program** (same weights): same logits as the legacy class, same verdicts on the forged-output battery (8/8); a drill that crosses the fence on the shipping binary | 6–8 weeks |
| **G. Fused kernels** | Legacy kernels as fused patterns first; then CPU/Metal/CUDA kernels for hot patterns | none (node releases) | F-4 gates fire and pass per backend | continuous |
| **H. Migration** | Arm `palw_tir_v1` on testnet-12 at a post-launch flag day; first new family as pure data; mainnet: IR is the admission path for new classes (`palw_tir_only_v1`) | fences | registration → panel → Final for a model no core developer wrote code for | — |

Total to Phase F: about 6–9 months with two to four experienced people. `palw_tir_v1` is a `Params`
fence like ADR-0102's: a dormant network fingerprints as if it did not exist; when armed, the params
fingerprint gains `prim_set_id` and the IR ceilings. On testnet-12 it would join the first fence list
after the capacity steps (ADR-0160), at a height chosen when Phase F's drill passes.

## Implementation status

- **Gate 1 (2026-09-28): Phases A–C.**
  - **Corpus:** `docs/design/palw/tir/corpus-v1.md`, with every semantic claim cited to the `transformers` modeling code.
  - **Normative text:** `docs/spec/palw/04b-tensor-ir.md`.
  - **Crate `misaka-palw-tir`:** the reference evaluator with golden vectors `consensus-vectors/tir-v1/`. The BASE-0 frozen KAT and the A16/Q36 kernels are byte-identical as IR segments.
  - **Crate `misaka-palw-tir-lower`:** HF `config.json` + safetensors → frontend-neutral high-level graph → f32 reference. It matches `transformers` 5.17 on 57 tiny architectures and is estimated to cover about 91 % of decoder-only HF checkpoints by count.
  - **The primitive set came out at 25**, below the 30–50 target: minimality removed every composition. `Requantize`, `Rescale`, the shifts, `IntRecip` and `IntSigmoid` are library segments, byte-identical to the legacy kernels. `Scatter`, `Sort`, `BoundedScan` and `BoundedMap` are out, and a user-body `BoundedReduce` is refused. The additions are an internal-only `i128`, `Log2Floor`, and a `Div` with a tensor divisor, which carries every rounding shift.
  - **Deviations recorded in 04b §14:**
    - `HistAppend` returns the window.
    - Fixed state is committed at checkpoints rather than at every position (a per-position GDN state is far above the step-leaf cap).
    - `token_bound`.
    - Committed operands are checked against their proven intervals (PALW-TIR-33: out of interval is a malformed commitment and the producer loses).
    - Params get a 2^40 sanity bound instead of the 2^28 cap.
- **Gate 2 (running):** the composite library, conformance against the live kernels, `tir_admit_v1`, quantisation and fidelity, the independent second implementation, and the Phase F integration design.
- **Found on the way (legacy code, outside this RFC):**
  - A court arm that could panic on hostile committed lanes. It is being fixed as a node update.
  - The fenced Kimi court arms disagree with the model: zeroed KDA state, equal-head-dim MLA, and a softmax router where HF uses a grouped sigmoid.
  - For GDN, HF maps value head `vh` to key head `vh / (v_heads / k_heads)` (grouping). The live kernel's `vh % k_heads` equals it only after a value-head reordering at conversion, which Phase 0 checks.

## Alternatives

| Alternative | Why not |
| --- | --- |
| Keep adding kernels (status quo) | A release, a fence and a drill per family; conventions hide in code and bite later (the GDN k≠v defect) |
| An IR that grows per model (`QwenGdn`, `Mamba2Scan`, `DeepSeekRoute` as ops) | The same problem, one level down, in a few years. Refused by freeze criterion 1 |
| Generalise kernels one by one | Worth doing for live bugs (Phase 0), never changes the nature of the boundary |
| A Turing-complete deterministic VM (WASM-like) | Halting and metering become runtime problems; the court must bound an arbitrary program; nothing an LLM needs requires it |
| Cryptographic proofs of model computation | Permanently prohibited by the user's 2026-10-15 decision and PRINCIPLES §8; use sampled replay, public localization, deterministic court and the explicit validator-approval assumptions |
| ONNX / StableHLO as the consensus IR | Open op sets, float semantics, implementation-defined corners. Good lowerer *inputs*, not consensus |
| ONNX importer as the primary frontend (evaluated 2026-09-28) | A new architecture reaches ONNX export later than `transformers`, sometimes never, which defeats day-one registration; exporter-specific decompositions (attention, RoPE, caches) must be pattern-matched back into composites; QDQ carries float scales and ties-to-even rounding and is re-quantized anyway. Kept as an optional secondary frontend after the freeze |
| Upstream MLIR as the compiler infrastructure, a MISAKA dialect (evaluated 2026-09-28) | A C++/LLVM toolchain in a Rust node for an IR of ~40 primitives whose lowering is template expansion; consensus could not depend on it in any case. Allowed for third-party compilers (the encoding is the interface); revisit for Phase G code generation, outside the identity |
| pliron (Rust-native, MLIR-inspired: dialects, ops, regions, verification, printing, passes) as the reference lowerer's internal IR (evaluated 2026-09-28) | What it provides is what consensus must own itself: the typed DAG, the verifier, the canonical encoding and the evaluator live in `misaka-palw-tir`, and admission and the tool call the same verifier (G9). A pliron `palw.tir` dialect would be a second definition of every primitive's type and shape rules plus a second representation with translation layers, not less work; what the lowerer adds on top is domain logic (configs, weight layouts, float reference, calibration) it does not help with. Also 0.x with a breaking minor release about every six weeks and no declared MSRV, against this repository's pinned toolchain. Third-party compilers may use it; an optional dialect adapter (pliron ⇄ canonical bytes) after the freeze; re-evaluated at the lowerer's Gate 2 if the lowerer grows non-trivial rewrite passes |
| RLX (a Rust ML compiler/runtime: HIR → MIR → LIR, memory planning, ONNX/GGUF import, multi-backend) as the compiler or runtime | Float, JAX-shaped semantics and a fast-moving API; the byte-identity rule (F-1) needs integer kernels written against this IR. Reference material for Phase G backends and the secondary frontends |
| Cranelift as the IR | An SSA code-generation IR without tensor semantics; a candidate for CPU code generation of generic kernels in Phase G, outside the identity |
| TOSA's integer profile as the semantic base | The closest existing integer specification and useful prior art, but its rescale rounding is not the frozen rules the live kernels use (ADR-0040 C1/C2), and it has no state, position scan, commit points or court cost |
| Structured control inside a step (`BoundedMap`, `BoundedReduce` with a user body) | Heads, experts and channels are tensor axes, so batching needs no control flow; a user-body reduction is order-dependent unless proved associative and exact, which breaks §3.2. `BoundedScan`/`BoundedMap` enter only if the corpus needs them (Phase A) |
| Bounded extension programs for what the IR cannot express | Withdrawn under ADR-0172: use a generic versioned semantic/checker/court kernel extension, not a second ISA execution model or guest fallback (§II.12) |
| A float IR with tolerances | ADR-0053: tolerance turns fraud proofs into votes on noise |
| Every primitive committed | Multiplies step leaves several-fold against the 2^22 cap; cones give the same adjudicability at today's commitment cost |

## Security and economic analysis

- **Unadjudicable programs (A4).** An attacker registers a program the court cannot try and lies in it
  for free. Closed: every node must be a v1 primitive and every cone within ceilings. Residual: an
  interpreter defect — two independent implementations, golden vectors, fuzzing, and the legacy
  conformance against kernels that already survived the red-team battery.
- **Overflow to break order-freedom.** A program whose partial sums overflow would make hosts with
  different reduction orders disagree, so an honest seat looks like a liar. Closed by §5.2 from
  type-worst-case inputs and partial-sum bounds; weights cannot escape a bound that does not trust them.
- **Cost under-metering.** A program cheap on paper and slow in reality would stall panels. Cost
  formulas upper-bound the reference evaluator, coefficients carry a benchmarked margin, and the
  worst-case step is capped. A registrant with a private fused kernel is faster than the network until
  the kernel is public — P5's "efficiency is rewarded" — while seats run generic kernels at the metered
  cost. Whether weight (ADR-0069) should also require a measured generic-backend throughput floor is
  open.
- **Mis-fusion.** A fused kernel applied to a subgraph it does not implement convicts whoever ran it,
  never the network: the court runs the interpreter. F-5 and F-4 make it unlikely.
- **Selection games.** Near-ties decided by rounding would make "which expert" a vote on noise.
  PALW-TIR-11 fixes the tie rule and commits the selection.
- **Identity grinding.** Encodings of one program would give free class ids. Normal form makes the
  encoding unique; node-local knobs leave the id.
- **Registration DoS.** Linear-time admission with capped sizes; the 1 BILI burn and the 4-per-block
  cap stay; admission CPU time is measured in Phase D and becomes a ceiling if needed.
- **Canonical work.** Derived structurally: `dense_matmul` = `MatMul` with a non-gathered `Param`;
  `routed_expert_matmul` = `MatMul` whose `Param` passes through a `Gather` indexed by a `TopK`
  (active experts only); `attention_*` = primitives over `H`; `recurrence` = the update cones of
  `Fixed` states; `normalization` = cones feeding `IntRsqrt`; the rest `other_verified_ops`; bytes from
  `HistRead`/`HistAppend` and the artifact layout. Commit points and `tile_len` feed none of it.
- **Overall surface.** One interpreter of ~40 small primitives replaces 45 bespoke court arms and
  their per-kernel shape rules.

## Compatibility and migration

- Live classes and kernels are untouched; legacy admission (v9) stays for existing lineages.
- After freeze criterion 6, each legacy kernel is also a fused kernel of an IR pattern. A legacy class
  may be re-registered as an IR program (new class id, same weights, same outputs); nothing forces it.
- The ADR-0135 manifest's `graph_ir_root` and `runtime_version` become real (`runtime_version` =
  `prim_set_id`); `UnsupportedOp` becomes `NEEDS_PRIMITIVE(name)` from the verifier.
- Economic compute's name heuristics are retired for IR classes.
- ADR-0135 Decision 7 is unchanged in wording; its scope widens because the VM expresses more.

## Open questions

1. **The final primitive list**, decided by Phase A and frozen in Phase E — in particular `Scatter`,
   `Sort`, `IntSigmoid`, `BoundedScan`, and whether Kimi's KDA or DeepSeek's MLA need anything new.
2. **Existing `AttnFused` vs "dissectable".** Does today's fused attention compute exact two-pass sums
   over the history? If it rescales a running sum, legacy conformance fails for it and the difference
   must be resolved before the freeze.
3. **Integer fidelity of the corpus.** Static int8/A16 quantisation with frozen activation scales may
   lose too much on some families (outlier activations in large dense models, long-context SSMs). The
   thresholds and the calibration tooling are Phase A/E work; a family that cannot meet them is a
   quantisation problem, not an IR problem, and must be reported as such.
4. **Program carriage**: inline in the admission carriage up to 256 KiB, or an artifact leaf with only
   `graph_ir_root` on chain.
5. **Weight for IR classes (ADR-0069)**: is the drilled primitive set enough, or does each program still
   need its own end-to-end drill (responder availability was ADR-0093's gap, not arithmetic)?
6. **A generic-backend throughput floor** as a condition of weight.
7. **Normalization** in the work vector: `IntRsqrt` cones, or folded into `other_verified_ops`.
8. **A8/A16**: separate families inside the IR, or dtypes of one family.
9. **The GDN head convention** in the live kernel (`vh % k_heads` tiling vs grouping): Phase 0 must
   check it against the model's reference semantics; the IR makes the choice explicit.

## Decision

<Open.>

---

# Part II — Model onboarding: a standard path from a Hugging Face directory to a registered, reproducible and honestly staged class

*Added 2026-10-01 (lane F, branch `tir/onboard`). Part I defines the IR, the court and the fused-kernel rule; Part II
defines everything between a model someone downloaded and a class that earns. **Part II adds no primitive and changes
no consensus rule.** §II.7.5 records the consensus rules *decided* on 2026-10-01 under a dormant fence; they are specified there and
not yet built. Everything else in Part II is tooling, data formats and node-side reporting, outside consensus (P7).*

## Part II in one page

Part I makes a model *expressible as data*. It does not make *getting a model there* a standard path, and today each
model is refused for a different reason, late: after hundreds of GB were downloaded and converted. Part II specifies eight
things, one per requirement of §II.0.1.

1. **A header-only preflight (§II.2).** Reading only the Hugging Face config files plus the safetensors headers, or the
   GGUF header, it reports the architecture and its features, every tensor's storage type, the vision/audio/MTP parts the
   class would not compute, the artifact size, the testnet-12 conditions the chain would judge (admission sizing, close
   sizes, court cost, DA ladder, the court window, the canonical job), and the memory a seat needs, and then names, per
   stage (**convert**, **register**, **mine**), what is missing. It answers before a single weight is fetched.
2. **The converter as a function with a streaming loader (§II.3) and versioned runtime packs (§II.4).** The converter holds
   one block of a tensor at a time. A *runtime pack* is one manifest pinning the source, the frontend, the quantisation
   descriptors, the profile, the converter and its math, the executors, the logit convention, the result and the
   conformance vectors, so that anyone can rebuild the same artifact root and check it on three independent executors.
   Adding a model never inherits another model's conditions: every condition is in the pack and in its digest.
3. **Quantisation as data (§II.5).** A checkpoint's quantisation is a descriptor file (`misaka.palw.quant-format.v1`)
   read by one interpreter. An unknown type is refused by name, with the safe paths that exist; a new one is a file with
   test vectors, not a release.
4. **Feature scope (§II.6).** A class is one function. What the model has beyond it (a vision tower, an audio tower, a
   projector, MTP heads) is named with its evidence in the pack, the listing and the preflight; the class either computes
   a part entirely or says it does not.
5. **Staged enablement (§II.7).** Registration is existence; mining is a separate, gated stage. The chain's lifecycle
   already separates them; §II.7 states what it does and does not guarantee against the requirement, gives the registry a
   structured `blocking` field (stage, code, what is missing, how much), and records the consensus rules, decided but not yet built,
   that close what it lacks.
6. **Hub-wide end-to-end coverage (§II.10).** The 50–100 architecture corpus measures the lowerer, not how many Hugging Face
   repositories can register, obtain independent seats, produce a valid claim and reach `Final`. A pinned Hub census and a
   stratified, real-checkpoint cohort measure every gate separately. The largest measured failure categories determine the
   next generic frontend, format, modality, admission or verification work; a declaration of broad coverage needs the
   end-to-end evidence, including panel capacity.
7. **Future-model permissionlessness (§II.11).** A new family whose computation fits the armed TIR primitive set and
   canonical job profiles can supply its own compiler or declarative frontend pack and register canonical program and
   artifact bytes without a `main` release or model-name allowlist. Missing semantics require a reusable versioned
   kernel extension, checker/court/resource evidence and coordinated activation before registration.
8. **The local-LLM kernel-coverage objective (§II.12).** Aim for at least 90 % of a pinned, publicly runnable local-LLM cohort
   to reach registration, independent seats and `Final` through active tensor/verification kernels. Publish the
   residual extension/resource/source gaps; do not presume that a VM covers the remainder.

## 概要(Part II、日本語)

- **目的。** 「このモデルは登録できるか、何が足りないか」を、数百 GB を落とす **前** に答える。今は一つ一つのモデルが別の理由で、遅く拒否される。
- **preflight(§II.2)。** HF の config と safetensors の header(GGUF は header だけ)しか読まない。architecture と feature(Level A/B/C)、
  tensor ごとの量子化型、vision/audio/mmproj/MTP、artifact の推定サイズ、t12 の条件(admission の大きさ、close の大きさ ≤ 搬送上限、
  court cost ≤ 2^26、DA の ladder、court window、canonical job)、seat の必要メモリを出し、**convert / register / mine** のどの段階で何が欠けるかを名指しする。
- **runtime pack(§II.3–II.4)。** 変換は streaming(常駐メモリは最大 chunk のみ)。pack は source・frontend・量子化 descriptor・profile・converter(数学は
  `libm-v1`)・executor・conformance を 1 つの manifest に固定し、誰でも同じ artifact root を再構築して、独立 3 実装で確認できる。他モデルの条件は黙って継承されない。
- **量子化はデータ(§II.5)。** GGUF/GPTQ/AWQ/FP8/compressed-tensors/MXFP4/bitsandbytes は descriptor ファイル。未知の型は **名指しで拒否** し、安全な経路を示す。新型は release でなくファイル+テストベクタ。
- **feature scope(§II.6)。** text-only はすべての面に出る。vision / audio / projector は「未対応の feature」であり、部分対応にはしない。
- **段階的な有効化(§II.7)。** 登録は存在、mining は別の段階。現行 lifecycle の穴(ready seat は bond 数・probation の claim は報酬が出る・実行系の認証 gate が無い・seat のメモリ不足は無言)を洗い出し、
  node 側だけで直せる部分(registry の構造化 `blocking`)は実装し、consensus に触れる部分は dormant fence(`palw_class_seating`、全 class 種別に 1 つの着席規則)として 2026-10-01 に決定済み(未実装)。
- **完成基準(§II.8)。** 50〜100 の代表 architecture、既存 feature で ≥ 90 % 表現可能、到達可能な TIR op への court coverage 100 %。
- **HF 全体への到達(§II.10)。** 上の 90 % は代表 architecture の下ろしやすさであり、HF のモデル登録率ではない。公開モデルの
  repo と revision を固定して、取得可能性、変換、実サイズの admission、独立 seat、claim の `Final` を別々に測る。失敗を
  format・feature・modality・court・座席/処理能力に分類し、件数の大きい汎用的な欠落から閉じる。実走なしに「大半が登録・Final」と言わない。
- **将来のモデル(§II.11)。** 既存 TIR primitive と canonical job で意味を記述できる新型モデルは、第三者の frontend pack または
  直接生成した TIR / plan を使って、`main` のモデル別更新なしに登録できる経路を必須とする。未対応演算・checker・courtは
  汎用Kernelの合意更新が必要で、VMでは迂回しない。有効化と実サイズの実走までは対応済みに数えない。
- **ローカル LLM のKernel coverage目標(§II.12)。** 公開・取得可能な固定cohortで、active tensor/verification Kernel経路による
  ≥ 90 % の登録・独立 seat・`Final` を目標にする。残りはKernel拡張・format・resource等の欠落を公開し、未実装を成功と数えない。

## II.0 Requirements, acceptance and the three examples

### II.0.1 The requirements

The user's, in the user's order. R1–R5 are the onboarding path; R6 adds the 2026-10-03 Hub-majority outcome;
R7 makes future-family onboarding independent of a `main` release where the armed semantics suffice;
R8 sets the local-LLM active-kernel coverage target, replacing the historical 90/10 VM split.
The acceptance criteria are §II.0.2.

- **R1. A header-only preflight.** Read only the Hugging Face config files plus the safetensors headers, or the GGUF
  header (metadata KV and tensor infos, never the data section). Report: supported architecture and features; per-tensor
  quant types; vision/audio components; estimated artifact size; the testnet-12 court and canonical-job conditions
  (admission v10 sizing; close sizes ≤ the carried cap; court cost ≤ 2^26; DA step leaves against the ladder, 2^22 below
  `palw_tir_fence2` and the class's own ladder up to 2^30 past it; the court window); and the seat resources needed.
- **R2. Versioned runtime packs.** One manifest identifies the model config, weight format, profile, converter version,
  executor and conformance vectors. Adding a model never silently inherits another model's conditions, and registration
  is reproducible.
- **R3. An extensible quant registry.** Unknown types are refused explicitly, never misread. New types can be added as
  decoder modules with tests. Refusals present the safe paths that exist.
- **R4. Feature scope shown.** A text-only artifact says so in the manifest, the listing and the preflight. A model that
  needs extra files (a vision projector, an `mmproj`) is shown as an unsupported feature, never as partial support.
- **R5. Registration separated from mining enablement.** Mining claims and rewards stay off until the class is
  adjudicable, the executor is certified (conformance), and enough ready seats from distinct operators have possession
  proofs. A failure says which stage (convert / register / mine) lacked what, in both the CLI and the chain registry.
- **R6. Most Hub models can complete that path, measured as repositories rather than architecture examples.** The
  system must name each blocking gate, close the largest generic gaps without a model-specific consensus path, and prove
  that a representative set of real checkpoints can register, be independently seated and reach `Final` (§II.10).
- **R7. Permissionless extension within an armed semantic envelope.** An unknown model family that can be expressed
  with the armed TIR primitives and job profiles must be registerable through a third-party frontend or direct canonical
  TIR submission, with no model-name allowlist, built-in feature-registry entry or `main` code change (§II.11).
- **R8. Local-LLM kernel coverage.** Target at least 90 % of a dated, reproducible cohort of publicly runnable local
  LLM checkpoints through active tensor/verification kernels. The residual requires explicit extension/resource
  work, not RFC05's withdrawn VM fallback; publish real-size registration-to-Final evidence (§II.12).

### II.0.2 Acceptance

- **A1.** A model with a custom quantisation gets its verdict, and the features it lacks, before its full weights are
  fetched.
- **A2.** The artifact root, the converter version and the profile are reproducible and pass an independent conformance
  check.
- **A3.** The testnet-12 preflight (shape depth and above) shows the court window and the canonical-job conditions.
- **A4.** Mining starts only after the ready seats of distinct operators and their possession proofs.
- **A5.** Failures are visible per stage, in the CLI and in the registry.
- **A6.** A pinned, auditable Hub census and real-checkpoint cohort meet the quantitative end-to-end claim rule of
  §II.10.5. The architecture-corpus percentage alone cannot satisfy A6.
- **A7.** An independently authored, previously unknown family and weight layout pass the no-`main`-change
  registration-to-`Final` exercise in §II.11.4; unsupported semantics refuse by name and never execute as an unknown op.
- **A8.** Meet §II.12's ≥90 % active-kernel threshold and confidence requirement, with a complete residual table.
  Residual failures stay in the denominator; A8 does not establish 100 % coverage or support for an inactive
  extension. A proposed kernel route is not a measured result.

### II.0.3 The three examples

| Example | What it needs | Where Part II answers it |
| --- | --- | --- |
| **`qwen4_exp`** — QSA (sparse block attention), a hashed n-gram per-layer embedding, a gated residual; 125 B parameters with 6 B active plus 51 B of n-gram tables; about 360 GB | feature lowerers that exist as data/generic code, not a Qwen4 parser; a streamed conversion; a verdict from headers | §II.1 (Levels), §II.3, §II.2: the architecture is a *combination of features* (lane G); the preflight reads a 360 GB checkpoint's headers (kilobytes) and says Level A/B/C, the artifact size, and the admission sizing |
| **`Mitsuba-ComfyUI-27B-GGUF`** — a Qwen3.8-27B-family GGUF with custom types `PQ2_0` / `PTQ1_0` and an `mmproj` | a quant registry that refuses a custom type by name and takes a descriptor file; feature scope for the `mmproj` | §II.5 (the refusal names the type id and the tensors, lists what is described, and gives the safe paths); §II.6 (`mmproj` is a modality the class does not take; the class is the text decoder). The two custom types stay refused until their layout is specified; a descriptor file can add them with no code change |
| **A Qwen3.5-9B refused for its court window** — "the court needs 5,102 DAA, the t12 limit is 3,000" | the court window as a *named, early* condition | §II.2.3(7) (the preflight computes the window and the limit at the asked height) and §II.2.6 (the plug point for the class-specific window that release int-10 carries) |

### II.0.4 Where each requirement lives

| Requirement | Part II | State on `tir/onboard` |
| --- | --- | --- |
| R1 preflight | §II.2 | specified here; the command is task 7. Its inputs exist: `TensorSource` headers (§II.3), `model::analyze`/`ArchitectureReport` (lane G), `model::scope_of`, `check_ir_config_v1`, the descriptor registry |
| R2 packs | §II.3, §II.4 | implemented: `palw-class pack build \| verify \| show` (`468ae4404`); `libm-v1` (`537ca553f`); streaming converter (`b0d799769`, `0876a1744`, `ef1f8ef40`); content-addressed chunks (`e6fbb3ba2`); streamed inventory root (`e502567ba`) |
| R3 quant registry | §II.5 | implemented: 29 ggml types (`957d8e26d`), GPTQ, AWQ, FP8 block, three compressed-tensors formats (`1db3c430f`), MXFP4 from safetensors (`096e88de5`), bitsandbytes nf4/fp4/int8 (`f74d1a333`); known-undescribed list (`17febcd9d`) |
| R4 feature scope | §II.6 | implemented (`d7c0d776a`); shown by the report, the pack and `misaka model inspect` |
| R5 staged enablement | §II.7 | analysed here; the registry's `blocking` field and its CLI display are node-only and specified in §II.7.4; the consensus rules of §II.7.5 are decided (2026-10-01) and not yet built |
| R6 Hub-majority outcome | §II.10 | new acceptance program, **not an implementation claim**; requires a live Hub census, real checkpoints and an adequately seated end-to-end drill |
| R7 future-family extension | §II.11 | proposed direct-TIR and third-party frontend contract; existing data adapters and quant descriptors cover only their current languages, so this is **not yet a proven end-to-end capability** |
| R8 local-LLM kernel coverage | §II.12 and [Kernel design §§K.0–K.8](../design/palw/versioned-kernels.md) | unmeasured target; real-size checker/court/panel resources need evidence; no VM route |
| A1–A5 | §II.8 | A2 is met by the pack; A1, A3, A4, A5 complete with the preflight (task 7), `blocking` and the decision on §II.7.5 |
| A6 | §II.10.5 | open until the measured `register` and `Final` gates pass; neither the 92 % A/B corpus reading nor the earlier Hub estimates close it |
| A7 | §II.11.4 | open until third-party direct-TIR and frontend-pack paths pass with unchanged node/consensus binaries and independent seats |
| A8 | §II.12 | open until the dated cohort, active-kernel end-to-end funnel, confidence requirement and residual table meet the target |

## II.1 Principles

These come from lane G's frontend (`misaka-palw-tir-lower`, branch `tir/generic`;
`docs/design/palw/tir/model-adapter-v1.md` §§1–6, `docs/design/palw/tir/hf-coverage.md`; commits `c52b8b3a7` ModelSpec V1
and the feature registry, `f2a364b74` Gemma-4 as data with no per-family Rust in the default build, `1a4964205` the Qwen4-Exp
fixtures through the data adapter). Part II depends on them and restates them because every part of the onboarding path
must obey them.

- **P1. `model_type` is informational.** Nothing is selected by it. Two models whose `ModelSpec`s are equal compute the same
  function whatever they are called, and the court never sees the name.
- **P2. A finite, versioned feature vocabulary.** A model is a *combination* of features (`FeatureId`s of `model::REGISTRY`:
  attention variants, MoE routing, linear recurrences, state-space blocks, per-layer inputs, KV sharing, hyper-connection
  streams, hashed n-gram embeddings, …). A feature is lowered once, by a generic lowerer, to the existing primitives.
  Adding a feature adds a lowerer and tests, never a primitive and never a per-model code path.
- **P3. Levels A, B and C, and adapters are data.**
  - **A**: the standard keys and tensor names suffice; the reader's own template reads the configuration.
  - **B**: an adapter file (`misaka.palw.model-adapter.v1`, a JSON document with a bounded, pure expression language)
    maps the class's keys onto features; no protocol change. The adapter is pinned by the BLAKE2b-512 hash of its
    effective canonical JSON, and the built-in pack by a pack hash, so a runtime pack names exactly which reader ran.
  - **C**: a capability is missing: a feature that cannot be lowered yet, or a protocol gap, **named, together with the
    smallest *general* primitive that would close it** — never a model-specific one. A Level C verdict is a statement about
    the vocabulary, not about the model.
- **P4. Static shapes, nothing ignored.** Every dimension is constant except the history length `H` (§3.1). A configuration
  key that no rule reads is refused (`NOT_LOWERABLE`), never ignored: a key that can change the math is understood or the
  model is refused.
- **P5. Selection is in the IR, not in the model's code.** `TopK` breaks ties to the lowest index and returns its set in
  index order (PALW-TIR-11, ADR-0052 B); routing variants (grouped, shared + routed, bias terms) are data over `TopK`,
  `Gather` and `Select`.
- **P6. State is declared.** Every recurrence and every cache is a state declaration of §4.1 (`Fixed` with its range, or
  `Hist` with its window), derived by the lowerer from the spec's mixers. Nothing about state is implicit in a kernel.
- **P7. The court sees only TIR nodes.** The court knows primitives, committed values, params and the primitive semantics. It
  never sees a model name, a feature, an adapter, a quantisation descriptor or a pack. Therefore **everything in Part II
  lies outside consensus** (§2): a class's identity is `H(graph_ir_root, layout, artifact_root, tokenizer)` (§4.1), and
  how the artifact was produced, or by whom, confers no protocol authority. The one exception is the lifecycle of §II.7,
  which is registry behaviour and is analysed, not changed, here.
- **P8. The legacy converter is frozen.** `qwen36-convert` serves the three architectures it already serves and points every
  other model at `palw-class check-architecture` and the TIR path (commit `0e5f56ac7`). New architectures are never
  added to it.
- **P9. A limit of the tool is not a verdict on the model.** A refusal states what the *tool* lacks (a feature, a
  descriptor, a primitive, a fence) and what exists instead. The preflight reports an unknown as unknown and a block as a
  block; it never turns "this build cannot" into "this model cannot" (ADR-0108's rule for verification depths).
- **P10. Reproducible by construction.** A conversion depends on nothing but the pack's inputs: no clock, no thread count,
  no platform libm (§II.3.3). Two builds from one pack give one artifact root.

## II.2 The header-only preflight (R1)

`palw-class preflight <input>` and `misaka model preflight <input>` answer, for a model nobody has downloaded yet, whether it can be
registered and what is missing. Both print the same report, human or `--json`.

### II.2.1 Inputs, and what is read

The command dispatches on the kind of its input and **says which mode ran in the first line of its output**.

| Input | Mode | Read | Never read |
| --- | --- | --- | --- |
| a directory with `config.json` (a Hugging Face snapshot, possibly with the weight files absent or sparse) | model | `config.json`; the presence and size of the tokenizer files (the tokenizer files are read whole: they are megabytes) and of `generation_config.json`, `preprocessor_config.json` and any `*mmproj*` file beside the checkpoint; `model.safetensors.index.json`; **the header of each safetensors shard** (8-byte length and the JSON header) | the data region of any shard |
| a `config.json` file | model | the same, beside it; shard headers if `--headers <dir>` supplies them (`*.safetensors` files or their header prefixes) | |
| a `.gguf` file | model | the magic, version, tensor count, the metadata key/values and the tensor infos (name, dimensions, type, offset) | the data section: the file may be truncated after the header, and the tool only uses the file size |
| a model repository id (cargo feature `remote`, off by default) | model | the same ranges by HTTP range requests, one request per header | everything else; no test uses the network |
| a `.palwtir` artifact | artifact admission | as today (`palw-class preflight` / `misaka model preflight <artifact>`) | |

A download that follows a preflight is therefore a *decision*, and the report says how many bytes it would fetch and how many
of them the class needs: a tensor the feature scope leaves out (§II.6) is listed with its size and need not be downloaded.

### II.2.2 Depths and the first line

The verification depths of ADR-0108 (Structural, Vectors, Full) apply, renamed for a model:

| Depth | Computes | Needs |
| --- | --- | --- |
| `headers` | architecture and features, scope, per-tensor storage types and their descriptors, the tensor and shape checks against the program's parameters, the artifact-size estimate; the convert stage's verdict | the files of §II.2.1 |
| `shape` (the default when a network is named) | adds the **shape-only lowering** (no weights: the program depends on the configuration, and the parameters' shapes come from the headers), the admission sizing, the chain's conditions at a height, the seat's resource needs and the lifecycle forecast; the register and mine verdicts | a network (`--network`, default `testnet-12`) and a height (`--height <DAA>`; default the node's tip when `--node` is given, else the first height at which every fence the network schedules is in force, and the choice is printed) |
| `full` | the artifact is built (or supplied) and verified: the existing artifact admission and `pack verify` | the weights and a pack |

The first line is of the form

```
preflight: model · Hugging Face directory · depth shape (requested shape) · testnet-12 at DAA 7,150 · 61 KiB of 17.6 GB read
```

or `preflight: artifact admission · .palwtir` for an artifact. When a depth stops early the report says `depth_reached`,
`depth_requested` and `stopped_at` (for example `depth_reached: headers, stopped_at: "network not given"`), and every verdict that
needs a deeper depth is `unknown`, never `ok`.

### II.2.3 What the shape depth computes

Each item names the function that answers it, so the preflight is a composition of existing, tested parts and invents no rule.

1. **The model.** `hf_schema::read_model_with` reads the configuration (and, when headers are given, the tensor names) into a
   `ModelSpec`; `model::analyze` gives the `ArchitectureReport`: the Level (A, B or C), the adapter (built-in, user file, none)
   and its hash, the features used with their lowering status, the assumed defaults and the refusals by named feature.
2. **The scope.** `model::scope_of` over the configuration, the tensor index and the files beside it (§II.6): what the class
   computes and what it leaves out, with evidence and the bytes the left-out tensors hold.
3. **The storage.** A histogram of the checkpoint's tensors by storage type (safetensors dtype; GGUF type id and name), each
   mapped to a descriptor of the registry (§II.5): described and supported; **no descriptor** (the id, the name the metadata
   gives it, the tensors that need it); known and not yet described (§II.5.6); or refused by the descriptor's own rule (for
   example LLM.int8 with an outlier threshold). Parameters a descriptor reads from `quantization_config` are resolved and
   its shape checks run on the header-only role tensors (plus the few small role tensors a descriptor reads for its own
   parameters, at most 4 KiB each).
4. **The tensors.** Every parameter of the lowered program is bound to a checkpoint tensor (or a served virtual tensor, §II.5.3)
   and its shape equals the header's; a missing tensor, a shape mismatch and a checkpoint tensor nothing reads (outside the
   scope's left-out parts) are reported before any download.
5. **The artifact.** The estimated size of the `PALWTIR1` container: the parameters by the quantisation policy (the integer
   width each weight lowers to, per-row scales, tables), the program, the tokenizer; and the *download* size, the bytes of the
   tensors the class needs.
6. **Admission.** `tir_admit_v1` (the function consensus admission calls) over the shape-only program: node counts against the
   caps, ranges, costs, court cones; the verdict is one of Part I §8's (`ADMISSIBLE`, `ADMISSIBLE_GENERIC`, `EXCEEDS(limit, value,
   cap)`, `NEEDS_PRIMITIVE(name)`, `NOT_LOWERABLE(reason)`).
7. **The chain's conditions at the height**, each as *needed against limit*:
   - **close sizes**: the worst carried close of every terminal tile (PALW-TIR-38, `palw_tir_close_size_v1`) against the carried cap;
   - **court cost** (`derive_court_cost_v1`): terminal MACs, operands and close chunks against 2^26 elements / terms and the
     per-tile ceilings of §5.4;
   - **the DA ladder**: the class's step leaves against the ladder in force — 2^22 below `palw_tir_fence2`, the class's own
     ladder, up to 2^30, past it;
   - **the court window**: the DAA the court needs to adjudicate the class (the dissection ladder's rungs, their deadlines and
     the close) against the window the network gives it (§II.2.6);
   - **the canonical job**: the declared prefill and decode token counts, `max_context` and the history bound against the
     network's canonical-job bounds and the class's profile;
   - **the fences**: every fence the class needs (`palw_tir_v1`, `palw_tir_fence2`, …) against what the network has armed at the
     height (`FENCE_NOT_ARMED(name)`), and the registration's price (the 1 BILI burn and the carrier fee).
8. **The seat.** The memory one seat needs to replay the class — the artifact (mapped) plus the replay working set, which
   grows with the context (the K/V history and the scratch of the widest cone) — against the memory share a seat declares
   (`--palw-host-memory-share`), and the time to page the artifact in. A seat whose share is below the replay never becomes
   ready and, today, says so nowhere (§II.7.3 F4); the preflight is where it is said first.
9. **The forecast.** The path the lifecycle (§II.7.1) would take on the network: an admission jury at the next audit
   (`palw_admission_audit_period_daa`), `required_ready_seats` ready seats, `probation_claims` probe claims, `stable_epochs`
   stable spans, how many independent operators the network has against the seating floor (§II.7.5), and the earliest time to the
   first paid claim. It is informational: the chain decides.

### II.2.4 Verdicts, stages and codes

The verdict is one table, one row per stage, in the order the user meets them:

| Stage | The question | Blocked by |
| --- | --- | --- |
| **convert** | Can an artifact be built from this source, reproducibly, by anyone? | architecture and features (Level C), config keys, quantisation, tensors, tokenizer, completeness of the source |
| **register** | Would the chain admit this class at this height? | admission sizing, the court's conditions, the court window, the canonical job, the fences |
| **mine** | If it is registered, will it be admitted to claims and paid? | seat resources, ready seats, the lifecycle path, conformance (full depth) |

Each stage is `ok`, `blocked` or `unknown` (depth too shallow). A blocker is
`{ stage, code, what, evidence, have, need, safe_paths }`; `have` and `need` are present when the condition is a count or a
size. Codes are stable once published; the initial set (`SCREAMING_SNAKE`, the registry's own `PalwModelRegistrationCodeV1`
style, and the registration codes it already has are reused where they mean the same):

| Stage | Codes |
| --- | --- |
| convert | `ARCH_NEEDS_FEATURE(feature)`, `ARCH_NEEDS_PRIMITIVE(name)`, `ARCH_REFUSED(feature, why)`, `CONFIG_KEY_UNREAD(key)`, `CONFIG_INVALID`, `REMOTE_CODE(module)`, `QUANT_NO_DESCRIPTOR(scheme, id, name, tensors)`, `QUANT_KNOWN_UNDESCRIBED(method)`, `QUANT_REFUSED(descriptor, why)`, `TENSOR_MISSING(name)`, `TENSOR_SHAPE(name, want, got)`, `TOKENIZER_MISSING`, `SOURCE_INCOMPLETE(file)` |
| register | `ADMISSION_EXCEEDS(limit, value, cap)`, `CLOSE_SIZE_OVER_CAP`, `COURT_COST_OVER_CEILING`, `DA_LADDER_EXCEEDED`, `COURT_WINDOW_EXCEEDED`, `CANONICAL_JOB_OUT_OF_BOUNDS`, `FENCE_NOT_ARMED(name)`, `ARTIFACT_ROOT_KNOWN` (full depth) |
| mine | `SEAT_MEMORY_SHORT`, `READY_SEATS_INSUFFICIENT` (a class already on the chain), `PACK_NOT_VERIFIED` (full depth) |

Not every note is a blocker. The feature scope (§II.6) is reported as a note, not a block: a vision-language model is registrable
as its text decoder, and the report says so (`text stage only on testnet-12; vision needs RFC-0003's generative class`).

### II.2.5 Safe paths

A refusal says what exists instead, taken from data rather than prose: for `QUANT_NO_DESCRIPTOR`, the model's original
safetensors, or re-quantising to a described type (listed), or supplying a descriptor file with `--quant-format` (§II.5.5); for
`ARCH_NEEDS_FEATURE`, the feature's name and the general primitive that would close it (lane G's `FeatureInfo`) and whether a
data adapter can supply a missing key mapping; for `COURT_WINDOW_EXCEEDED`, a smaller `max_context`, the class-specific window
where the build has it, and the numbers each would give; for `SEAT_MEMORY_SHORT`, the context at which the class fits the seat.

### II.2.6 Plug points

- **The court window.** The derivation of a class's court window arrives with release int-10 (lane R, `rcore/int-10`). Until a
  build has it, the preflight prints the *global* rule (`window_court` against the dissection depth the class needs) and says
  `court window: global rule; this build has no class-specific window`. The window is a provider (`needed`, `limit`,
  `source`) so that merging int-10 replaces one function.
- **The network.** Parameters (`Params`), fences and registration terms come from the named network preset or, with `--node`, from
  the node (`getPalwRegistrationTerms`), so a live chain's terms — which differ from genesis after a retarget — are the ones
  judged.
- **The seat share.** The default tiers are the testnet-12 fleet's: a memory share of 3.5 GiB (the 5.104 seats, MemoryMax 9 GiB) and 8 GiB (the ibm/.113 seats, MemoryMax 16–20 GiB); `--seat-share [name=]GiB` (repeatable) replaces them.

### II.2.7 The JSON form

`--json` prints `misaka.palw.preflight.v1`: the mode, depths, the network and height; `source` (files, sizes, SHA-256 of the
config and each header); `model` (architectures, Level, adapter id and hash, features); `scope`; `storage` (histogram, descriptors
by name and digest); `artifact` (estimates); `chain` (each condition with `needed`, `limit`, `source`); `seat`; `forecast`;
`verdict` (the stage table); and `registries` (the adapter-pack hash, the feature-registry digest, the quant-registry digest and
the tool's version), so a verdict is attributable to the build that gave it. It contains no timestamp and no path: the same
inputs give the same bytes.

### II.2.8 What a preflight does not claim

It does not claim fidelity (that needs the weights: §II.4's reference fit), it does not claim the artifact root (that needs the
data), and it does not claim that the chain *will* admit the class: it computes the chain's own functions at a height, and the
chain decides when the object is carried. It claims only what the headers and the rules say, and says which.

### II.2.9 As built (2026-10-01), and what this slice leaves out

`misaka_palw_sdk::preflight` is the library; `palw-class preflight <model>` and `misaka model preflight <model>` are two faces
of it (the same report, `--json` the same bytes). Where the build differs from, or decides within, the text above:

- **Dispatch.** A directory with `config.json`, a `config.json` file, a `.gguf` file (or a directory holding only a
  `model.gguf`) is a model; a `.palwtir` file is an artifact and keeps its old meaning in both commands (`palw-class preflight`
  runs the artifact admission; `misaka model preflight` asks the live chain). The first line says which ran.
- **Exit code.** 0 when no stage is blocked and the convert stage is `ok`, 2 when a blocker exists, 1 for an input the command
  cannot read.
- **Network and height.** `--network` defaults to `testnet-12` for a model; `--depth headers` needs none. With no `--height` the
  height is the last DAA `Params::fence_schedule_v1` lists (every fence the network schedules is in force there) and the report
  prints how it was chosen. `palw_tir_v1` is read from the network's real schedule: below its activation, or on a network that
  has not armed it, the register stage carries `FENCE_NOT_ARMED(palw_tir_v1)` and **every other condition is judged as if it
  were armed** (at the fence's own height, or DAA 1), so a model learns what else stands in its way before the flag day.
- **The declared context is searched.** A class is declared at a context; `declare-layout` defaults to the widest the program
  and the network admit, which no one can register (past 32,783 positions the canonical prompt exceeds J5b's 4,096 inline ids).
  The preflight, given no `--max-context`, declares the **widest context at which admission v10 admits the class** (the court
  window and the inline bound cap the search, then halving and bisection on the gate itself) and says so, with the refusal the
  program's own widest context meets. `--max-context N` judges exactly N.
- **Every wall at once.** The gate refuses at the first wall it meets; the preflight also computes the court window, the canonical
  job and the sizing on their own, and any that is over its limit is a blocker too, so fixing one wall is not mistaken for
  fixing the model (ADR-0097's rule). Each condition is `needed / limit / unit / ok`.
- **Shape-only lowering.** The program is the lowering of the configuration (`prepare_spec`, which reads no weights); the
  parameters' shapes are checked against the headers by the frontend's own binding (`check_weights`; `check_names` when only the
  index is present). A described format that derives a shape from a small role tensor (at most 4 KiB) whose data is not on disk
  is reported as `not checkable` with the tensor to fetch, never as a wrong shape.
- **The artifact estimate** is `palw_tir_work_shape_v1(program).param_bytes()` — the registry's own figure for the class's
  parameters — plus the program and the tokenizer files; the download figure is the tensors the class reads, minus what the
  scope leaves out. The inventory's leaf count is an estimate (it only sets the depth of a close's paths).
- **The seat.** `needed = artifact (mapped) + state at the declared context + one position's peak live bytes + the widest tile a
  close opens`; the report gives the need against each seat tier (the fleet's two, or `--seat-share`) and says which tiers hold the class and which never become ready for it; `SEAT_MEMORY_SHORT` is raised only when no tier holds it, with the context at which each fits; a class only some tiers hold is a note.
- **The forecast** is `palw_derive_profile_v1` over `palw_tir_model_work_v2`: the registry's own derivation of the window,
  prefetch, ready seats, in-flight claims and registration bond. It does not know how many independent operators the network has.
- **Tokenizer.** `TOKENIZER_MISSING` is raised for a directory (no `tokenizer.json`, `tokenizer.model` or `vocab.json`) and for a
  GGUF without `tokenizer.ggml.tokens`; a lone `config.json` says nothing about it.

**Not in this slice**, each with where it plugs in: `--node` (the live chain's registration terms and tip, and with them
`READY_SEATS_INSUFFICIENT` for a class already on the chain); a repository id by HTTP ranges (the `remote` feature of the
lowerer's `RemoteCheckpoint` is the reader; no network is used by any test); the `full` depth, which reports what it needs
(`palw-tir-fidelity`, `pack build`, `pack verify`) and `PACK_NOT_VERIFIED` / `ARTIFACT_ROOT_KNOWN`; and the class-specific court
window, which replaces one function (`window_at` in `preflight::chain`) when release int-10 merges.

## II.3 The streaming loader and the converter (R2)

A conversion that must hold a checkpoint in memory cannot be run on a 360 GB model, so the converter is built around one rule:
**the resident memory of a conversion is a block of a tensor, never a tensor and never the checkpoint.**

### II.3.1 `TensorSource`

The loader's face is a trait (`weights::TensorSource`). Beyond reading a whole tensor it serves the three things streaming needs:
`metadata(name)` (a header lookup, no data), `read_slice(name, range)` (a byte range of the tensor's stored data) and
`load_rows(name, rows)` (a row range decoded to `f32`); `serves_row_ranges()` says whether the last reads only what it is asked
for. The sources are:

| Source | Serves ranges by |
| --- | --- |
| sharded safetensors (`Checkpoint`: `model.safetensors.index.json` and the shards) | `pread` of the shard file at the header's offsets |
| GGUF | the header's data offsets; block-quantised tensors decode through their descriptor (§II.5) |
| a *described* source (`DescribedSource`) | a wrapper that hides tensors a descriptor stores packed and serves the float tensors it declares in their place (§II.5.3), decoding any element range without materialising the rest |
| remote (`CurlFetcher`, cargo feature `remote`, off by default) | HTTP range requests; the library never opens a connection by itself and no test does; the feature is tested against a loopback server |

### II.3.2 Streaming materialisation and the converter

- **By blocks of rows.** `materialise_stream` produces each parameter of the program a block of rows at a time, evaluating a
  source row-wise where its form allows (a slice, a transpose, a stack of experts); projections whose input has outlier channels
  split their rows by the calibration statistics in the same pass. What a fill cannot evaluate row-wise (a few small tensors) is
  read whole, and the loader counts them.
- **Content-addressed chunks.** The container (`PALWTIR1`) is assembled from canonical 4 MiB chunks in a chunk store, streamed:
  the same bytes are the same chunk. A composite class (a parent and an unmerged LoRA adapter, RFC-0004) therefore *shares its
  parent's chunks*, and an updated adapter rewrites only its own.
- **The inventory root by leaf.** The inventory root is computed leaf by leaf over a container or a chunk store (`derive_streamed`),
  equal to the consensus root; a 74 MiB container is rooted with 4 MiB resident.
- **Calibration** produces the activation statistics (`misaka.palw.calib-stats.v1`) the quantisation policy needs. They are a
  bit-exact file (a decimal does not round-trip through every JSON reader), a pinned input of the pack (§II.4), and re-measurable
  from the calibration sequences the pack carries.
- **`convert_model(ConvertRequest) -> ConvertOutcome`** is the converter as a function; `palw-tir-convert` and `palw-class pack
  build` are thin wrappers. The container's meta records what read the model — the frontend, the scope, the descriptors, the math
  — and enters the file digest, never the roots.

### II.3.3 Reproducibility

A conversion is a function of the pack's inputs and of nothing else:

- **Math.** Every transcendental the lowerer evaluates (activation and RoPE tables, scales, query temperatures, SSM decay) and
  the log2 of its scale arithmetic come from `detmath`: the pinned pure-Rust `libm` 0.2.8 (`math: "libm-v1"`, the default of a
  new pack), so a seat on any platform rebuilds the same root. A class registered before it records `math: "std"` and the
  platform it was built on (os/arch), and stays reproducible there. Measured on the 68 fixtures on macOS arm64 (`std` against
  `libm-v1`, one set of statistics): **0 of 14,688,768** activation-table entries and **0 of 4,141,056** RoPE-table entries
  differ; 2,146 of 6,577,152 entries of every other tensor differ, all in the query-temperature table of Llama-4, Llama-4-VLM
  and Ministral-3, by at most 8 codes (one binary32 ulp of `ln_1p` at Q24). The platforms' `f64` libms agree on every table
  here; their binary32 ones do not, and another platform's `f64` is untested, which is why the math is pinned.
- **Threads.** The conversion uses rayon; `tests/determinism.rs` rebuilds nine families (RoPE variants, hybrid, SSM, MoE,
  LongRoPE, YaRN) under pools of 1 and 7 threads, and the statistics and container bytes are equal.
- **Equality with the whole-tensor path.** The streamed artifact is byte-identical to `materialise` on all 68 Hugging Face
  fixtures, and `tests/golden_lowering.rs` pins the program and artifact digests of 92 checkpoints and 63 real configurations: a
  change in the lowering that moves a root is noticed by that test, and `LOWERING_VERSION_V1` is bumped when it is meant.
- **Memory.** `tests/streaming_budget.rs` converts a synthetic sharded Llama-shaped checkpoint (default 24 layers, about 270 MB of
  BF16 in many shards; `TIR_BUDGET_LAYERS=100` is a 2 GB-disk run) under a counting allocator: the peak above the process's own
  memory stays inside a budget (default 32 MiB) that is below the embedding table alone as `f32`, and no tensor deferred to the
  streaming path was loaded whole.

The known limits of this section (the float reference of calibration is not row-streamed; conformance on a very large model
loads the artifact whole on each executor) are in §II.9.

## II.4 Runtime packs (R2)

A **runtime pack** (`misaka.palw.runtime-pack.v1`) is the one document that says what is needed to rebuild a class's artifact
from public source and to judge the result. It is a directory: `pack.json` and the sidecars it pins by hash (the calibration
statistics, the calibration tokens, the Hugging Face reference logits, a user-supplied adapter, user-supplied descriptors).

### II.4.1 Identity and form

- **Identity.** `pack_digest` is BLAKE2b-256, keyed (`misaka.palw.runtime-pack.v1`), over the canonical JSON of `pack.json` (keys
  sorted, compact, integral floats as integers). The file may be pretty-printed; the digest does not depend on it. Nothing in the
  manifest depends on the machine, the time or the thread count.
- **Numbers.** Every number that is not an integer — the quantisation headroom, the logit scale, the tolerances, the measured
  fit — is stored as the 16 hexadecimal digits of its IEEE-754 binary64 bits, because a decimal does not round-trip through
  every JSON reader (serde_json's default parser is one ulp off on some values) and a digest must not depend on the reader.
- **Strictness.** Unknown fields are an error (`deny_unknown_fields`); a sidecar named by a path with `..` or an absolute path is
  refused; hash lengths and character sets are checked before anything is trusted.

### II.4.2 The sections

| Section | Pins | Why it is there |
| --- | --- | --- |
| `model` | the source: format (`safetensors` / `gguf`), label and revision (informational), architectures, `model_type` (informational), the digest of the configuration the frontend read, and every file's size and SHA-256 | the source is public, so anyone can fetch it and the hashes say it is the same bytes |
| `frontend` | the adapter (`none` for Level A, `built-in` or `user-file`, by id and BLAKE2b-512 hash; the template for Level A), the built-in pack's hash, the digest of the `ModelSpec` the lowering started from, the Level, and the configuration keys the class defaults supplied | a different reader is a different pack |
| `features` | the digest of the feature vocabulary of the build, the features used (`{id, layers, detail}`), and the scope (§II.6) | what the class computes and what it leaves out |
| `quant` | the descriptors, by name and digest (built-in, or a file inside the pack) | the weights are read the way the descriptor says (§II.5) |
| `profile` | the quantisation policy (headrooms), the maximum window, the context, the calibration (statistics digest and file, where measured, optionally the sequences) | the numbers that decide the integer program |
| `converter` | name, crate version, the lowering version (`misaka.palw.lowering.v1`), the math (`libm-v1`, or `std` with its platform) | the tool and the arithmetic |
| `executor` | the program format, `prim_set_id`, and the implementations that must agree byte for byte | what "correct" means (§II.4.4) |
| `logits` | the convention (`legacy-greedy-only`, or `q24-natural-v1`: code / 2^24 are natural-log logits, the scale exactly 2^-24), the scale and the tolerance (slope, correlation, top-1, KL) | what the integer logits are in |
| `result` | the container's file digest and size, `graph_ir_root`, the inventory root, the leaf count, the tokenizer id, the program size | what the build produced |
| `conformance` | the vectors: a prompt, the greedily decoded tokens, the number of positions, and two digests — over every position's logits and over every commit point | what any executor must reproduce |
| `hf_reference` | the Hugging Face reference (its file and digest, what produced it, sizes) and the fit the integer program measured against it (slope, intercept, correlation, max-abs, RMSE, top-1, KL) | the fidelity claim (never a bit-identity claim: Part I §1.2(5)) |
| `declared` | per network: the layout digest, the class id the layout gives, `max_context`, checkpoint interval, `h_tile`, and the file digest of the container written with it | the class the artifact becomes on that network |
| `files` | the sidecars, by BLAKE2b-256 | |

Adding a model never inherits another model's conditions because **there is nowhere to inherit them from**: every condition that
shapes the artifact — adapter, descriptors, policy, statistics, math, executors — is a field of this model's pack and so of its
digest, and verifying a pack reads nothing from any other.

### II.4.3 The commands

```
palw-class pack build  --model <hf dir | .gguf> --out <artifact.palwtir> --pack <dir> (--calib <tokens.json> | --stats-in <stats.json>) …
palw-class pack verify <pack dir> [--model <dir | .gguf>] [--artifact <file>] [--rebuild] [--no-ref2] [--no-exec] [--strict] [--json]
palw-class pack show   <pack dir> [--json]
```

`build` converts (streaming, `libm-v1` by default), writes the artifact and the pack, runs the conformance vectors on every
executor, holds the program to the reference within the tolerance, and, per `--declare <network>`, declares the class.
`verify` checks every claim it can from what is at hand and reports **PASS**, **FAIL** or **SKIPPED** (not checkable here, and
why) for each: the manifest and sidecars by hash; the source files by hash; the adapter and the descriptors by hash; the
frontend by reading the model again (the spec digest, the features, the scope); the artifact, rebuilt from the source with the
pack's profile and statistics (`--rebuild`) or the one supplied (`--artifact`), by file digest, inventory root, graph root and
tokenizer; the declared classes by class id; the conformance vectors on every executor; and the program against the Hugging Face
reference within the tolerance. A pack is **VERIFIED** only when nothing failed and nothing was skipped.

### II.4.4 Independent conformance

The conformance vectors are the independent check of A2. Each is run on three implementations, which must give the same bytes at
every position's logits and at every commit point `(slot, block, layer, node, values)`:

1. the reference evaluator (`misaka-palw-tir`, Part I §6: the meaning of "correct");
2. the typed backend that nodes run (`misaka-palw-tir-exec`);
3. the independent second implementation (`misaka-palw-tir-ref2`), written from the specification alone, decoding the canonical
   bytes with its own codec.

The Hugging Face reference fit is a *unit check* as much as a fidelity measure: the least-squares slope of the reference logits on
the program's `code × scale` must lie in `[slope_min, slope_max]`, which fails a program whose logits are in other units than
natural-log logits (a slope far from 1).

### II.4.5 What a pack is not

A pack is not a chain object and no consensus code reads it (P7). It is the evidence a person gives so that others can reproduce
a class without trusting them; the chain's evidence is the court. A registration's artifact root is the same value whether or not
a pack exists; the pack is what lets a seat, an auditor or a competing registrant rebuild that root and check that the executors
agree before spending a fee or a gigabyte on it.

## II.5 Quantisation as data (R3)

A model's weights reach the lowerer in whatever storage format its publisher chose. Each format used to be a Rust decoder, one
more release per format. They are now **descriptors**: JSON files (`misaka.palw.quant-format.v1`, `quant-formats/*.json`) that say
where a tensor's fields are, which tables it indexes and, as expressions, what each element is, read by **one** interpreter
(`quantfmt`). The registry refuses what it does not describe, by name; a new format is a file with test vectors and no change
to the crate.

### II.5.1 The descriptor

**Status: draft.** Additive changes are allowed until the first runtime pack is published; then the schema freezes and a later
change is `quant-format.v2`. The identity of a descriptor is the BLAKE2b-256 digest of its canonical JSON (the text's layout does
not matter).

```jsonc
{
  "schema": "misaka.palw.quant-format.v1", "name": "BNB_NF4", "doc": "…",
  "ids":    [ { "scheme": "ggml", "id": 2 },                                            // a GGUF tensor type
              { "scheme": "config", "method": "bitsandbytes",                           // a quantization_config
                "when": [ { "path": "load_in_4bit", "one_of": [true] },                 // …told apart by other keys
                          { "path": "bnb_4bit_quant_type", "one_of": ["nf4"] } ] } ],
  "params": { "bits": { "config": "bits", "default": 4, "allowed": [2, 4, 8] },         // from the configuration
              "bs":   { "from_role": { "role": "qstate", "path": "blocksize" } } },     // or from a tensor's JSON document
  "config": { "inert": [ … ], "skip": "llm_int8_skip_modules", "skip_match": "path",
              "lm_head": "unless_skipped", "checks": [ { "path": …, "one_of": [ … ], "message": "…" } ] },
  "tables": { "name": { "bits": 8, "signed": true, "hex": "…" } },                      // constants the format indexes
  "layout": { "kind": "blocks" | "tensors" | "virtual", … },
  "decode": { "target": "integers" | "floats" | "tensor", … },
  "tests":  [ { …a vector… } ]                                                           // mandatory
}
```

**Vectors are mandatory and are checked when a descriptor is loaded.** A vector is a valid random input and the expected output as
computed by an *independent* implementation; `QuantFormat::from_json` decodes every vector and refuses the descriptor if one
element differs by a bit. A descriptor that fails its own vectors does not enter the registry.

### II.5.2 The three layouts

| Layout | A unit is | Decodes to | Used for |
| --- | --- | --- | --- |
| `blocks` | a block of `elems` elements in `bytes` bytes, fields at byte offsets (`u8`, `f16`, …) | the stored integers under group scales (`q`, `scale`, `zero`, `min`, code range, offset term) or floats | GGUF's ggml types |
| `tensors` | a *module's* tensors, each a **role** (a name, a suffix, accepted dtypes, a rank, required or not) | the stored integers under group scales (`group.size`, `group.index`, `q`, `scale`, `zero`, `min`, `code`, `order`, `offset_term`) or floats (`value`) | GPTQ, AWQ, FP8, compressed-tensors, bitsandbytes |
| `virtual` | tensors a checkpoint stores packed, **served as float tensors under another name**, of any rank up to four (the first lane may be an expert axis) | a tensor: `axes`, a `shape` expression per axis, and one `value` expression | MXFP4 as Hugging Face stores it (`<name>_blocks` + `<name>_scales` served as `<name>`) |

A target that is `integers` is *lowered from the stored integers* (nothing is re-quantised: the codes are the weights, and each
row's group scales become exact integers at the row's unit, `lower/qlinear.rs`); a target that is `floats` or `tensor` decodes to
floats and the weight takes the ordinary W8 path of Part I's lowerer. Which a format is follows from what its elements are, not
from how it is stored: a codebook (NF4, FP4, FP8) is floats; an integer code under a scale is integers.

### II.5.3 Virtual tensors

A `virtual` layout is the answer to a format whose stored tensors are not the tensors the model uses. `DescribedSource` wraps a
checkpoint, lists the *served* names instead of the packed ones, answers a shape from the role tensors' headers, and evaluates any
element range of the served tensor without materialising the rest. OCP MXFP4 as Hugging Face stores it (gpt-oss) is one line:

```
roles  blocks  <name>_blocks  U8 [E, out, in/32, 16]      scales  <name>_scales  U8 [E, out, in/32]
axes   e, i, o          shape  [dim_blocks[0], dim_blocks[2] * 32, dim_blocks[1]]
value  fp4x2[(blocks[e, o, i / 32, (i % 32) / 2] >> (4 * (i % 2))) & 15] * 0.5 * e8m0(scales[e, o, i / 32])
```

A leading expert axis and per-block scales over a 3-D tensor are a lane `e` and a read `scales[e, o, i / 32]`: nothing in it is
specific to a model, and every binding that reads the float export reads the served tensor unchanged.

### II.5.4 The expression language

Closed, total and deterministic; the whole of what a descriptor can say (`quantfmt/expr.rs`).

- **Values.** Integers are `i64` and every operation is checked (an overflow, a division by zero, a shift out of range is an
  error, never a wrap; `/` and `%` truncate toward zero, as C). Floats are IEEE `f64` with `+ − × ÷` only and every result must
  be finite. There is no loop and no recursion, so every expression ends, and no transcendental function, so a decoded value does
  not depend on a platform's libm.
- **Grammar.** `c ? a : b`, `|| && | ^ &`, comparisons, shifts, `+ - * / %`, unary `- ~ !`, `name[i, j]`, `f(a, b)`, literals. A ternary
  evaluates each arm only for the lanes that take it, so an out-of-range read in the arm not taken is never an error.
- **Names.** the *lanes* (`e`, `i`, `o`, `g`, `blk`, …: columns evaluated a batch at a time), the format's *parameters*, a block's
  *fields* or a tensor's *roles* read by index (`qweight[i / 8, o]`), `dim_<role>[axis]` (a role's dimension, known from its header
  alone), `has_<role>` (an optional role is present), `float_<role>` (a role is stored in a floating dtype, which tells apart a
  role that accepts bytes or floats), and *tables*.
- **Functions.** `float int abs min max floor sext bits pow2`; the small float formats' decoders `f16 bf16 f32 e8m0 fp8e4m3
  fp8e5m2`; and the **rounding functions** `rnd32 rndbf16 rndf16 rnd(x, kind)` (to nearest even to binary32 / bfloat16 / binary16;
  `kind` 0, 1, 2, a constant a descriptor can take from the checkpoint), by which a descriptor reproduces a library's float32
  arithmetic *exactly*: a float32 `+ − × ÷` is the correctly rounded float32 result of the float64 operation on float32 operands
  (a format with `p' ≥ 2p + 2` significand bits, here 53 ≥ 50, does not double-round), so `rnd(a * b, 0)` is bit-for-bit a float32
  multiplication.
- **Parameters read from a tensor.** A parameter may be read from a role that holds a UTF-8 JSON document (`from_role`: a dotted
  path, an `int`, `float` or `string` through the parameter's `map`, a default for an absent key). The JSON is read by an exact
  reader that keeps numbers as text, so a decimal is parsed once and correctly rounded. bitsandbytes stores each module's logical
  shape, block size, dtype and double-quantisation offset this way.

### II.5.5 Reading `quantization_config`

Every top-level key of the configuration is *read* (a parameter's `config` path), declared *inert* (it does not change what the
stored tensors mean), named by a *check*, or refused by name: a key the descriptor does not know may change the meaning, so a model
that carries one is refused with the key's name. `skip` names the key that lists the modules kept in float, and `skip_match` how
an entry names a module — `exact`, `contains`, `path` (transformers' bitsandbytes rule: the module's last component, its whole
name, or a path prefix) or `regex` (the subset `^ $ . .*` and escapes, which is what Hugging Face's `re.match` entries use; anything
else is refused); `lm_head` says whether the head is stored in the format. A `quant_method` can announce several descriptors,
told apart by `when` conditions on other keys (bitsandbytes: `load_in_4bit`, `bnb_4bit_quant_type`, `load_in_8bit`); another
descriptor under the same conditions is refused, one under others is added.

### II.5.6 Refusals, and what is known and not yet described

An unknown type is never misread. A GGUF type no descriptor describes, a `quant_method` nothing reads, or a configuration a
descriptor refuses is a refusal that names it (the scheme, the type id, the name the metadata gives it, how many tensors and which
need it), lists what *is* described, and gives the safe paths: use the model's original safetensors, re-quantise it to a described
type, or supply a descriptor file (`--quant-format <file>`, or a pack's `quant.descriptors`) — no code change is needed.

`quant-formats/known-undescribed.json` lists the methods that are known, so that nobody mistakes a refusal for a verdict on the
model: HQQ, AQLM, VPTQ, SpQR, EETQ, FBGEMM-FP8 and BitNet (descriptors are expressible in principle; none written), QuIP/QuIP# and
HIGGS (the weights are decoded and then rotated by Hadamard transforms at run time, which is not a static decode; refused until a
transform feature exists), torchao (tensors serialised as Python objects, not safetensors tensors: refused, not described). The
preflight prints the entry beside the refusal.

### II.5.7 The descriptors this build carries, and their evidence

39 built-in descriptors, each with vectors:

| Descriptors | Layout, target | The vectors' reference |
| --- | --- | --- |
| 29 ggml types: `F32 F16 BF16 F64`, `Q4_0 Q4_1 Q5_0 Q5_1 Q8_0`, `Q2_K Q3_K Q4_K Q5_K Q6_K`, `IQ4_NL IQ4_XS`, `TQ1_0 TQ2_0`, `MXFP4 NVFP4`, `Q1_0 Q2_0`, `IQ2_XXS IQ2_XS IQ2_S IQ3_XXS IQ3_S IQ1_S IQ1_M` | `blocks`; floats for the four plain types, integers (grid codebooks are constant tables) for the rest | gguf-py's own numpy dequantisers on 8,700 random blocks (`Q1_0`, `Q2_0`: a numpy transcription of the C); the tables are parsed out of `ggml-common.h`, not typed |
| `GPTQ` (v1 and v2, 2/4/8 bits, act-order, per-row) | `tensors`, integers | a torch re-implementation of AutoGPTQ's dequantisation |
| `AWQ` (GEMM, 4-bit) | `tensors`, integers | a torch re-implementation of AutoAWQ's `dequantize_gemm` |
| `FP8_BLOCK` (DeepSeek-V3, Qwen3-FP8) | `tensors`, floats | the reference `weight_dequant` over torch's float8 |
| `CT_PACK_QUANTIZED`, `CT_FP8_CHANNEL`, `CT_INT8_CHANNEL` (compressed-tensors) | `tensors`, integers / floats / integers | a torch re-implementation of compressed-tensors' `unpack_from_int32` and `dequantize` |
| `MXFP4_HF` (gpt-oss) | `virtual`, tensor | `transformers.integrations.mxfp4.convert_moe_packed_tensors`, the library's own function |
| `BNB_NF4`, `BNB_FP4` (also double-quantised), `BNB_INT8` | `tensors`: floats, floats, integers | `tools/bnb_ref.py`, a numpy/torch re-implementation of bitsandbytes' stored format and of its CUDA kernel's arithmetic |

**Evidence, stated plainly.** Only the ggml types (gguf-py) and `MXFP4_HF` (transformers) are checked against the maintainers' own
code. For GPTQ, AWQ, compressed-tensors and bitsandbytes the quantisation libraries are not installed in the offline environment
and the vectors come from re-implementations of their documented behaviour and source. The end-to-end fixtures (a tiny random
decoder quantised in numpy per each format's specification, `tools/gen_quant_fixtures.py`, 33 fixtures) are checked against
`transformers` with the dequantised weights substituted; that checks the *lowering* of a format, not the library's output. A
first checkpoint from the real quantiser belongs in the corpus (§II.8) and would settle it.

### II.5.8 What is exact, and what the formats cost

- **Integer targets are exact in their integers.** The lowering carries the stored codes as they are (nothing is re-quantised); a
  row's group scales become integers at one unit per row (`|a| ≤ 2^20`). An fp16 scale has 11 significant bits, so every scale
  within 2^9 of its row's largest is exact there (every checkpoint seen so far). A float32 scale (bitsandbytes' `SCB`) has 24, so it
  is rounded at 2^-20 of its row's largest; any scale that is not exact is counted (`quant_inexact`), a relative error of at most
  one part in a million in that scale.
- **A 4-bit code costs a byte in v1** (the program's weight dtypes are `i8`/`i16`); a packed `i4` dtype is a v2 candidate in
  `freeze-v1.md`. A 4-bit checkpoint's artifact is therefore about twice its packed size.
- **Float targets take the W8 path**: the dequantised weights are quantised per row by the lowerer's policy. For a format whose rows
  were quantised row-wise by absmax this recovers the same integers; for a codebook format (NF4, FP4, FP8) it is a re-quantisation,
  measured by the pack's reference fit.
- **bitsandbytes, in detail.** The 4-bit weight is a `uint8 [⌈N/2⌉, 1]` of the flattened row-major weight, the even element in the
  high nibble, with one `absmax` per `blocksize` flat elements and a 16-entry code table *stored in the checkpoint*, so the format
  is table-agnostic. **Double quantisation is exact**: the nested absmax is `nested_quant_map[absmax] · nested_absmax[block / 256] +
  nested_offset`, two float32 operations, each a `rnd(·, 0)` of a float64 operation on float32 operands. An element is the float32
  product of its code and its absmax, rounded once to the module's dtype (bitsandbytes' CUDA kernel's arithmetic; its pure-PyTorch
  fallback rounds the code table to that dtype first and differs by up to one bfloat16 ulp). For FP4 the kernel's literal for code 1
  (0.00520833) differs from the stored table's (0.0625 / 12 in float32) in the seventh digit; the descriptor follows the stored
  table. **Refused by name**: `bnb_4bit_quant_storage` other than `uint8`, and a hardware-reordered int8 `weight_format`.
  **`llm_int8_threshold` is inert (decided 2026-10-01).** Above 0, LLM.int8 splits every matmul at run time (activation columns past
  the threshold go through float16 against the dequantised weight columns, the rest through int8); that is how bitsandbytes *runs* a
  layer, not what is stored, and `BitsAndBytesConfig`'s default is 6.0, so most int8 checkpoints published carry it. The stored
  weights define the model, whatever the threshold. The pack's fidelity measure against the Hugging Face reference (§II.4.4) says how
  far the integer program is from the library's own run, and it must still pass; the `SCB` rounding stays counted
  (`quant_inexact`).

### II.5.9 Adding a format

1. Write the descriptor: `ids`, `params` and `config` (what the configuration says), `layout` and `decode`.
2. Write an *independent* reference for the vectors (the library's own function where it can be imported; else a transcription from
   its source, said so in the descriptor's `doc`), generate random valid inputs and the expected values, and add them as `tests`.
3. `QuantFormat::from_json` checks the vectors; the registry refuses a redefinition of a type, a method or conditions it holds.
4. Supply it with `--quant-format <file>` (or a pack's `quant.descriptors`) for a conversion that needs it; promote it to
   `quant-formats/` and the built-in list when it is general.

No code change is needed unless the language itself cannot say the format; a gap in the language is a general addition (`from_role`
and `float_<role>` and `rnd` were added for bitsandbytes, `virtual` for MXFP4), tested once, and available to every later format.

## II.6 Feature scope (R4)

A registered class is **one function**: token ids in, next-token logits out (for an encoder, a pooled embedding). A model that also
takes images or audio, or proposes several tokens at once, has parts the class leaves out. The *scope* says which, with the
evidence and the reason, wherever the class is shown, so that a text-only class is never presented as the whole model — and never
as a partly multimodal one: **a class computes a part entirely or says that it does not.**

- **The object** (`misaka.palw.feature-scope.v1`): `task` (`text-generation` or `text-embedding`), `input`, `output`, `text_only`
  (the model has a modality the class does not take), and `excluded`: for each left-out part its `kind`, `what`, `why`, whether it
  is `modal` (an input the class cannot take, as against a head it can do without), the `evidence` that showed it
  (`config.<key>`, `tensors <prefix>*`, `file <name>`) and the tensors and bytes it holds.
- **The rules are data** (`scope/rules.v1.json`, `misaka.palw.scope-rules.v1`): configuration keys, tensor-name prefixes or
  substrings and file names beside the checkpoint that are evidence of a part. Nothing selects code by model name. The kinds are
  `vision` (the tower; `vision_config`, `image_token_id`, …; `*mmproj*.gguf`, `preprocessor_config.json`), `projector` (the module
  that maps vision or audio features into the decoder's space), `audio`, `mtp` (multi-token-prediction heads) and `draft`
  (a speculative-decoding draft network, Medusa/Eagle heads).
- **Where it is shown.** The architecture report; the container's provenance meta; the runtime pack's `features.scope`
  (§II.4.2); `misaka model inspect`; the listing; and the preflight (§II.2.3 item 2), with the bytes of the tensors the class does
  not need, which a download may skip.
- **What it says for a vision-language model.** *Text stage only on testnet-12; vision needs RFC-0003's generative class
  (`palw_gen_v1`).* The class is the text decoder (RFC-0003 §II.2.1 specifies the placement of image rows an LM reads); the tower
  and the projector are named, and an `mmproj` file is an unsupported feature, not a partial one. A user who needs the modality
  sees at once that this class cannot give it.
- **It is a note, not a block.** A vision-language model is registrable as its text decoder; the report says what it is and what
  it is not. It becomes a block only where a user requires a modality (`preflight --require vision`).

## II.7 Staged enablement: convert, register, mine (R5)

The requirement is that **registering a model and enabling mining for it are different acts**, and that when either does not
happen the user is told which stage lacked what. §II.7.1 states the lifecycle the chain has today; §II.7.2 what it already
guarantees; §II.7.3 where it falls short of R5 (found by reading the code, with the functions named); §II.7.4 the node-only change
that makes every stage visible; §II.7.5 the consensus rules that were decided to close what is missing.

### II.7.1 The lifecycle today

`PalwModelLifecycleV1` (`palw_model_registry_v1.rs`) is stepped once per span by the registry fold from chain-visible facts
(`step_model_registry`, `palw_lifecycle_step_v1`). On testnet-12 a panel has 5 seats, `required_ready_seats` is the panel plus
2 spare, 7 (`palw_seat_gate_possession`), and the audit period is 100 DAA.

| State | Admits claims | Leaves when | The stage that lacks something |
| --- | --- | --- | --- |
| `Registered` | no | the manifest verdict is `Valid` (the graph names only operations the VM defines and derives work) | **convert** — the artifact's graph is the problem |
| `Candidate` (a bought class, past `palw_admission_independence`) | no | an admission jury seats: `seat_count` operators drawn from the *network's* population, not the class's, excluding the registrant's bond and operator, and a majority of them hold the class ready (ADR-0147); one audit per period | **register** — the network has not admitted it |
| `Prefetching` (a genesis class starts here) | no | `ready_seats ≥ required_ready_seats` and the collateral is there | **mine** — possession |
| `Probation { probes_passed }` | 50 ‰ of the derived admission | `probation_claims` (10) probe claims reach `Final` with none failing (a failure resets it; past `palw_registry_resilience` only two distinct bonds' failures do) | **mine** — verified service |
| `ActiveLimited { stable_epochs }` | 100 ‰ | `stable_epochs` (3) stable spans and the class's cap utilization under the ceiling | **mine** — stability |
| `Active` | 1,000 ‰ | falls to `ActiveLimited` if the cap is exceeded, to `Held` if the panel cannot be drawn or the class overloads | — |
| `Held` | no | the seats are back and the class is not overloaded; it re-enters `Probation` | **mine** — seats or the receipt window |

A *ready seat* is a bond with a fresh readiness row: a possession proof of a challenge leaf of the artifact's inventory that rotates
every span (readiness V2; 24 spans on testnet-12), an active bond above the floor, and free collateral for the readiness multiple
(3 seat exposures). One predicate, `palw_seat_not_ready_reason_net_v1`, counts ready seats for the lifecycle, the jury's votes, the
panel room and the registry RPC.

### II.7.2 What it already guarantees

- **Registration is existence.** `Registered`, `Candidate` and `Prefetching` admit no claim. The claim gate
  (`class_lifecycle_refusal`) refuses a claim to a class whose state does not admit claims, the model market follows the same
  gate, and the producer asks it before it spends an inference. A class nobody serves earns nothing and carries no weight.
- **Static court feasibility is checked at registration.** Admission v10 checks types, ranges, costs and court cones (Part I §5); existing weight rules also require a certified family covering the program's primitives (`NotEndToEndCertified`; `palw_uncertified_weightless`). These are the existing gate's scope, not proof that a fresh public bond can acquire evidence and prosecute every admitted profile. Future reward/weight admission additionally requires RFC14's public-verifier dispute-completeness gates under ADR173.
- **Independence, once.** A bought class passes a jury of operators the network drew (ADR-0147), at one audit per period, so a
  registrant is admitted alone only with the probability that its share of the operator lottery wins a majority of the jury.
- **Possession.** Ready seats hold fresh possession proofs with collateral behind them.
- **Volume.** A new class is admitted at 50 ‰ and then 100 ‰ of its derived admission before it is `Active`.

### II.7.3 Where it falls short of R5

**F1. "Ready seats from distinct operators" is a count of bonds after `Candidate`.** The registry fold observes `ready_seats` as the
number of *bonds* with a ready row (`model_registry_ready_seats`), and `Prefetching → Probation` needs it to reach
`required_ready_seats`. Distinctness of operators is enforced in one place only: the admission jury. On testnet-12,
`palw_operator_id_unique` ("one operator identity, one bond", with a proof of possession of the operator key in the registration)
makes a bond and an operator identity one thing, so the bond count there *is* a count of distinct operator identities. Three
things remain. (i) On a network without that fence the lifecycle over-counts, while the panel room's own count
(`palw_panel_ready_eff_of_bonds_v1`) already groups by operator and caps weights: the two disagree about what a ready seat is. (ii)
The jury's independence is a snapshot at one audit: after `Candidate` nothing asks again whether the ready seats are anyone but the
registrant's own keys, so a registrant that holds seven bonds, each a distinct key, keeps its class in `Probation` alone once its
jury has once been seated and the outsiders' readiness has lapsed (24 spans). (iii) The chain cannot tell two keys of one party from
two parties: independence is economic (the collateral behind each key), never an identity. And the rule is now **two rules**: lane D's
RFC-0003 lane admits a tensor claim only once `seat_count` distinct operators, never the executor's, hold the class with a fresh readiness
V2 proof (`GenClassNotReady`, RFC-0003 §I.4.5, `rfc3/gen-claim`), while an attempt class counts bonds and a composite class follows the
attempt lane. How many *independent* operators should gate the first claims, and one rule for every class kind, is §II.7.5 Proposal A.

**F2. Probe claims are paid.** `Probation` admits claims at 50 ‰ of the derived admission and a probe *is* an ordinary attempt claim:
one that reaches `Final` is counted as a pass (`note_model_probe`) and is paid and weighed as any other claim of the class: the
lifecycle only scales how many claims are admitted (`admission_permille`). `admits_claims()` is the only gate and the registry has
no unpaid state (ADR-0145 §7: "probation bounds volume, not price"). So rewards begin the span the class enters `Probation`, as soon as `ready_seats ≥ required_ready_seats`, before one claim
of the class has been verified and before any evidence about a seat's *executor* beyond a possession proof.

**F3. There is no executor-certification gate.** What the chain checks about whether a class can be executed correctly: statically at
registration (above), and by the primitive-set certificate (`certify_tir_e2e_family_v1`: the court acquits an honest run and convicts
planted faults at every primitive the program uses). Readiness is *possession* plus collateral and says nothing about whether a
seat's executor reproduces the class. The first evidence is the probe claims, in band and paid (F2). A divergent executor is *safe*
(the court convicts the party that computed wrongly, Part I §6) but not *free*: an artifact that does not match its own program, or an
executor that mis-implements a primitive, voids claims, resets probation, holds the class and wastes the honest producers' work. The
pack's conformance vectors (§II.4.4) catch these before registration; nothing makes registration, or readiness, depend on them.

**F4. A seat's resource failure is silent.** A seat whose memory share is below the class's replay writes a line to its own log and
never becomes ready (the 8k class needs 3.37 GiB per full-seat replay: 1.68 of artifact and 1.67 of trace scratch). The class never
leaves `Prefetching`, and the registry says only `ready 0 < 7 required (seats prove possession to be counted)`.

**F5. The registry's reasons are prose.** `RpcPalwModelLifecycle.reason` is a sentence from `palw_lifecycle_reason_v2`: no stage, no
code, no structured count, and the `Candidate` sentence describes the jury rule loosely. `getPalwModelRegistrationStatus` has stable
codes for the carrier's pipeline (constructed, submitted, accepted, included, folded) and nothing after `folded`.

### II.7.4 The node-only change: a structured `blocking` in the registry

`getPalwModelRegistry` gains, for each class, **what is blocking it and at which stage**. It reads only what the node already
serves, so it needs no consensus change, and its derivation is one pure function over a class's row and the registry's globals
(`palw_registry_blocking`, in `rpc/core`), used by the node to fill the response and by the CLI to show an older node's registry the
same way.

```
RpcPalwClassBlocking {
  class_id, stage: "convert" | "register" | "mine" | "",     // "" : nothing blocks
  code,                                                         // stable, SCREAMING_SNAKE
  what,                                                         // one sentence: what is missing
  have, need,                                                   // present where the condition is a count
  next,                                                         // what lifts it
}
```

| State (and condition) | Stage | Code | have / need |
| --- | --- | --- | --- |
| no row, or the base class | — | (none: legacy, never gated) | |
| `Registered`, `ops_supported` false | convert | `KERNEL_EXTENSION_REQUIRED` | |
| `Registered`, no artifact bytes or no derived work | convert | `NO_WORK` | |
| `Candidate` | register | `ADMISSION_JURY` | ready seats now / the jury quorum (`seat_count / 2 + 1`); the jury counts only its drawn operators |
| `Prefetching` | mine | `READY_SEATS` | `ready_seats_now` / `required_ready_seats` |
| `Probation { probes_passed }` | mine | `PROBATION` | `probes_passed` / `probation_claims` |
| `ActiveLimited`, spans below target | mine | `STABLE_SPANS` | stable spans / `stable_epochs` |
| `ActiveLimited`, spans reached | mine | `CAP_SATURATED` | |
| `Held`, ready seats below a panel | mine | `PANEL_NOT_DRAWABLE` | `ready_seats_now` / `seat_count` |
| `Held`, below the required seats | mine | `READY_SEATS` | `ready_seats_now` / `required_ready_seats` |
| `Held`, seats back, window does not fit | mine | `WINDOW_DOES_NOT_FIT` | |
| `Active` | — | (none) | |

`KERNEL_EXTENSION_REQUIRED` waits for the unsupported operation's reviewed kernel extension to be
implemented and activated; then the model must be lowered and registered as a new class (ADR-0172).

`what` carries the numbers a reader needs (`3 of 7 seats hold a fresh possession proof; 14 bonds on the network have the
collateral headroom to be a seat`; `4 of 10 probe claims have reached Final; 0 failed since entry`), and `next` says the act that
lifts the block (`run a seat for this class: a seat needs 3.37 GiB`, `the next admission audit is within 100 DAA`). The wire:
`GetPalwModelRegistryResponse` moves from version 1 to 2 and **appends** `blocking: Vec<RpcPalwClassBlocking>` after its last field;
an element of `classes` is not extended, because it is read as a vector element and a longer one would misalign an older reader,
while a trailing field of the response is not read by one. The CLI shows it in `misaka palw registry` (a line under each class
that has one) and in `misaka model status <class>` (`stage`, `blocked by`, `have/need`, `next`), and it is in `--json`.

Reserved for Proposal A (§II.7.5): `INDEPENDENT_OPERATORS` (`have / need` independent operators) and the class's licensable share,
served once the consensus read that carries the seating facts exists.

This closes F5 and the *reporting* half of F4 (the registry names `READY_SEATS` and the preflight, §II.2.3 item 8, names the
memory). It changes nothing the chain decides.

### II.7.5 The consensus rules — historical decision and implementation status at 2026-10-01

**Current reading (2026-10-10):** the seating predicate and dormant fence now exist in
`palw_class_seating_v1.rs` and `palw_class_seating_fence_v1.rs`. The following “not built” statements
are the original decision record. Presence of those modules does not prove activation or A7's
independent registration-to-Final exercise; see the implementation ledger for verified evidence.

The coordinator decided on 2026-10-01: **Proposal A approved** (one seating rule for every class kind, under the new dormant fence
`palw_class_seating`; the independence floor a fence parameter, default 3; armed with the RFC-0003/0004 flag day, not with int-10);
**Proposal B: go**; **Proposal C: C1**; and **`misaka model add` requires a `pack verify` PASS by default**, with an explicit expert
override flag that prints a warning (the chain does not enforce it). The consensus rules below are built by the consensus lanes
(lane D owns the shared predicate; this lane specifies it here, writes the scenarios the drills must include, and builds the
node-side reporting and the seat duty). None of the consensus rules is built yet. *(Corrected 2026-10-12: Proposal A is built —
`palw_class_seating`, armed on testnet-12 at DAA 5,300 with `independent_floor = 3`; see the [register](../design/palw/mainnet-spec-register-2026-10-12.md) N1/N2.)*

All of them are **fences**: dormant on every preset (`None`, hashed Some-only, a dormant network fingerprints as if the rule did not
exist), armed on testnet-12 through a flag-day entry like `PALW_T12_TIR_FENCE2_ENTRY`, with a drill that crosses the fence on the
shipping binary.

#### Proposal A — one seating rule for every class kind (approved)

A fence `palw_class_seating`. Past it there is **one predicate**, asked at every door through which a class's work is admitted.

> `class_seated(class, executor, span)`. Let `Ready(class, span)` be the set of **operators** — an operator counted once, however many
> bonds it holds — with a fresh readiness V2 possession proof for the class, by the registry's own five-clause predicate (an active
> bond above the floor, a fresh row, free collateral for the readiness multiple), and `Base(span)` the network's base-class
> population as the admission jury and the outsider seat draw it (active bonds above the floor that serve the liveness floor,
> matured, registered before the span's cut). The class is **seated** for a claim whose executor is `e` iff
>
> 1. **possession floor** — `|Ready \ {operator(e)}| ≥ seat_count`: a panel can be drawn without the executor;
> 2. **independence floor** — `|(Ready ∩ Base) \ {operator(registrant), operator(e)}| ≥ independent_floor`, where `independent_floor`
>    is a **parameter of the fence** (default `quorum(seat_count)` = `⌊seat_count / 2⌋ + 1` = **3** on testnet-12): operators that are
>    neither the claim's executor nor the class's registrant and that the network's own lottery could have drawn. A genesis class has no
>    registrant to exclude.

**The parameter.** `independent_floor` lives in the fence's ceilings (`PalwClassSeatingCeilingsV1`), hashed into the params
fingerprint with the fence (Some-only), so it can be raised by a later flag-day entry and never moves under a running chain.
`validate_palw_v2` refuses a floor of 0 or above `seat_count` (a floor no panel could meet). Three is the default because it is the
number of operators the network already accepts as evidence of independence when it admits a bought class (the jury's strict
majority), made a *continuing* condition; the reasoning is below.

**Where it is asked** (one function, so the doors cannot disagree):

| Door | Today | Under Proposal A |
| --- | --- | --- |
| claims of an IR or legacy attempt class, bought or genesis | the lifecycle state admits claims (`Prefetching → Probation` at `required_ready_seats` ready *bonds*); a claim no panel can be drawn for is voided *after* the bind window as `NoCapablePanel`, the executor's reservation held meanwhile | `class_seated` at claim admission: a refusal (`ClassNotSeated`, naming the floor that failed) before the reservation is taken |
| a tensor claim of an RFC-0003 generative class | lane D's `GenClassNotReady`: `seat_count` distinct operators, never the executor's, hold the class with a fresh readiness V2 proof (`rfc3/gen-claim`, `9a25e6d20` / `28f60cf24`); its lifecycle row stays `Registered`, so this is its only gate | the same function: D's rule *is* condition 1; condition 2 is added |
| claims of a composite class (a parent and an unmerged adapter) | as an attempt class, on the composite's own class id and artifact root | the same function, on the composite's readiness rows |
| the lifecycle | `Prefetching → Probation` and `Held → Probation` read the bond count against `required_ready_seats` | they read `|Ready| ≥ required_ready_seats` (`seat_count` + spare, **7** on testnet-12) **and** condition 2: the class enters `Probation`, and its probe claims begin to be paid, only when seven distinct operators, three of them independent, are ready |
| the registry, the CLI and the preflight | `blocking` (§II.7.4) names `READY_SEATS` with a bond count | `blocking` reports `have / need` for each condition (`INDEPENDENT_OPERATORS`), and the registry reports the class's licensable share; the preflight's forecast says how many independent operators the network has |

**The shared function — the API proposed to lane D.** One implementation in `consensus/core` (`palw_class_seating_v1.rs`), pure over the
state, with no side effect. Lane D's inline loop in `apply_gen_tensor_commitment_v1` becomes a call to it.

```rust
/// The fence's terms in force at a DAA (`Params::palw_class_seating_terms_at`): `None` below the fence.
pub struct PalwClassSeatingTermsV1 { pub independent_floor: u16 }          // default 3

/// What the predicate counted: every number a refusal, the lifecycle, the registry RPC and the preflight need.
pub struct PalwClassSeatingV1 {
    pub ready_operators: u32,        // |Ready \ {operator(executor)}|                       condition 1, have
    pub needed_operators: u32,       // seat_count                                           condition 1, need
    pub independent_operators: u32,  // |(Ready ∩ Base) \ {operator(registrant), operator(executor)}|   condition 2, have
    pub needed_independent: u32,     // terms.independent_floor                              condition 2, need
    pub base_operators: u32,         // |Base \ {operator(registrant)}|                      the licensable share's denominator
}
pub enum PalwClassNotSeatedV1 {
    Possession { ready: u32, needed: u32 },
    Independence { independent: u32, needed: u32 },
}
impl PalwClassSeatingV1 {
    pub fn verdict(&self) -> Result<(), PalwClassNotSeatedV1>;     // condition 1 first: possession, then independence
    pub fn licensable_share_permille(&self) -> u16;                // independent_operators × 1000 / base_operators; 0 for an empty base
}
pub fn palw_class_seating_v1(
    read: &PalwFoldReadV1<'_>,                 // the fold's reader at the block, of which `model_registry_seat_is_ready` is a method
    fold: &PalwModelRegistryFoldV1,            // the registry fold: `globals.seat_count`, the readiness horizon
    class_id: &Hash64,
    executor: Option<&PalwBondKeyV2>,          // the claim's executor bond; `None` for the lifecycle's observation and the registry read
    daa: u64,                                  // the block's DAA score
    terms: PalwClassSeatingTermsV1,
) -> PalwClassSeatingV1;
```

- The **population** `Base` is one function, extracted from `admission_jury_v1`'s filter (`Active`, `palw_bond_may_take_work_v2`,
  `palw_bond_may_judge_class_v2`, registered before the span's cut and matured, the registrant's bond and operator removed), so the
  jury, the per-claim outsider draw and the seating floor read **one** population and cannot drift apart.
- **The refusal** is one error, `PalwStateV2Error::ClassNotSeated { class, floor, have, need }`, with `GenClassNotReady` kept as the
  generative lane's name for the possession floor if lane D prefers (`Possession` maps to it one to one).
- **The lifecycle** reads it with `executor: None`: `PalwLifecycleObservationV1.ready_seats` becomes `ready_operators` and a new field
  `independence_floor_met` (true below the fence, so no existing transition changes); `Prefetching → Probation` and `Held →
  Probation` require `ready_enough && independence_floor_met`.
- **The registry read** (`PalwModelRegistryClassReadV1`) gains `seating: Option<PalwClassSeatingV1>` (`None` below the fence); the RPC
  and the node's `blocking` (§II.7.4) serve it, and `GetPalwModelRegistryResponse` gains the class's licensable share.
- It is `O(bonds)` per call over a `BTreeMap`, deterministic, and called once per claim at admission and once per class per span.

**Why these numbers.**

- *Possession floor = `seat_count`.* It is the least for which a panel exists without the executor: lane D's structural floor, kept.
- *Independence floor = `quorum(seat_count)`, 3 on testnet-12.* It is the number of operators the network already accepts as evidence
  of independence when it admits a bought class (the jury's strict majority), made a *continuing* condition instead of one audit's
  snapshot, and it is the least that stops the registrant and the executor, between them, from completing a first panel's quorum.
  Fewer (1) leaves one operator's outage between a class and `Incapable` voids; more (`seat_count`) makes every new class depend on
  the whole fleet of a network that has a few dozen operators. Independence beyond the quorum is carried by the lottery and by the
  collateral behind each key, not by a larger count — and the count is a parameter, so a larger network can raise it.
- *Operators, not bonds.* As the panel room's `ready_eff` already counts. On testnet-12, where `palw_operator_id_unique` makes an
  operator one bond, it changes no number; elsewhere it removes an over-count.
- *What it cannot do.* The chain cannot tell two keys of one party from two parties (§II.7.3 F1(iii)): a registrant that funds three
  more keys, each with the collateral of a panel-eligible bond (130,000 BILI on testnet-12), passes condition 2. The independence is
  bought and priced in collateral locked, which is the most that a rule reading only the chain can ask.

**The ADR-0147 outsider seat (lane D's caveat).** A bought class's claim has an outsider seat, drawn **per claim** from `Base`, which
**must hold the class to file `Valid`**: else it pleads `Incapable` and the claim voids at its receipt deadline (ADR-0147 §2.1). Condition
2 counts only operators of `Base` that hold the class, so the outsider pool is never empty; it does **not** make the outsider capable,
because the draw is over all of `Base`, not over its holders. The probability that a claim's outsider holds the class is
`|Ready ∩ Base \ {registrant}| / |Base \ {registrant}|`; three holders in a base of twenty license 15 % of the claims. That is
ADR-0147's price and it is kept on purpose: drawing the outsider from the *holders* would make its composition the registrant's choice,
which is exactly what ADR-0147 refuses. What Proposal A adds is **visibility**: the registry and the preflight report that share (the
class's *licensable share*), so a producer sees before its first claim what fraction of its claims can be licensed. No gate reads it.

**Arming.** With the RFC-0003/0004 flag day (the same consensus release as `palw_gen_v1` and the improvement protocol), **not** with
int-10. `palw_class_seating` is `None` on every preset until that flag day's entry sets its height and ceilings.

Cost: a class nobody else serves is admitted no claim, which is the independence the jury demanded once, kept; adoption is how a model
gets claims, and the registry says how far it is (`blocking`: `have 2 / need 3` independent operators). Risk: one function now guards
every door, so a defect in it is a defect everywhere; the predicate is pure over the state, is tested against lane D's gate and the
lifecycle's, and the fence is crossed by a drill on the shipping binary.

##### Scenarios the drills must include

The seating rule is exercised in the RFC-0003/0004 drills (lane C's D-M and lane D's step 8). Each scenario applies to every class
kind (an attempt class, a generative class, a composite class) unless it says otherwise, and states what must be observed. **Where
each runs** (int-11, S = 240 on the salted drill chain, seven seat nodes and one node-less bond): in the chain, SEAT-2 together with
the SEAT-5 lapse (one class, the executor among exactly five ready operators after one node stops serving it, one node down at a time),
SEAT-4 (six ready, a seventh starts serving), SEAT-7 (a genesis class admitting claims), SEAT-9 (the fence's edge, with a relay started
without the flag) and, where the class exists, SEAT-11; as fold-level tests, SEAT-3, SEAT-6, SEAT-8's statistics (the chain checks only
that the registry reports the licensable share) and SEAT-10; the generative variants of SEAT-1 to SEAT-5 in lane D's chain.

| # | Setup | Observed |
| --- | --- | --- |
| SEAT-1 | **Too few operators.** Fewer than `seat_count` distinct operators, the executor's excluded, hold the class ready (4 of 5) | the claim is refused, `ClassNotSeated { Possession, have 4, need 5 }` (a generative claim: `GenClassNotReady`); no reservation is taken and no `NoCapablePanel` void follows; the registry's `blocking` says `READY_SEATS` with `have / need`; the CLI shows stage `mine`. *For an attempt class the lifecycle holds a class below `seat_count` ready operators at the next span boundary, so the refusal is by seating within the span of the lapse and by the state (`Held`, `PANEL_NOT_DRAWABLE`) after it; the pure possession refusal is the generative lane's, whose lifecycle stays `Registered`* |
| SEAT-2 | **The executor does not count.** Exactly `seat_count` ready operators, the executor's among them | refused with `have = seat_count − 1`; the same class and claim with a different executor (not among the ready operators) is admitted |
| SEAT-3 | **Enough operators, too few independent.** `seat_count` ready operators of which only two are independent (the others: the registrant's, the executor's, or registered after the span's cut). *A fold-level test: where every operator is in `Base`, only the registrant and the executor are excluded, so five ready operators excluding the executor contain at least four independent ones and condition 2 cannot bind alone* | refused, `ClassNotSeated { Independence, have 2, need 3 }`; `blocking: INDEPENDENT_OPERATORS 2/3`; when a third independent operator proves readiness the next claim is admitted |
| SEAT-4 | **Enough.** At least `seat_count` ready operators, three independent. For an attempt class in `Prefetching`: with six ready operators it stays `Prefetching` (`READY_SEATS 6/7`); with a seventh (three independent) it enters `Probation` at the next span boundary; likewise `Held → Probation` | claims admitted; the lifecycle transitions as stated; the first probe claim is paid |
| SEAT-5 | **A lapse.** One independent operator's readiness expires (the readiness age) while the class is in `Probation` | the next claim is refused (`Independence`, 2/3), the state stays `Probation` until the existing rule holds it (`ready < seat_count`), and claims flow again when the operator re-proves; no probe is counted for a refused claim |
| SEAT-6 | **Operators, not bonds** (a devnet without `palw_operator_id_unique`). One operator with three ready bonds | counts once: five bonds from three operators are three ready operators, and the claim is refused |
| SEAT-7 | **A genesis class** (no registrant). The floor excludes only the executor | with the eight genesis operators ready: admitted; with four: refused |
| SEAT-8 | **The outsider.** A bought class held by 3 of a base of 20 | the registry reports a licensable share of 150 ‰ before the first claim; over at least 400 claims the licensed fraction is within tolerance of it, and the rest void as `Incapable`, as ADR-0147 says |
| SEAT-9 | **The fence's edge.** A claim accepted just below the fence height | judged by the old rules for its whole life (the claim's own `accepted_daa`, as ADR-0147 §2.4: the draw, the bind and every licensing arm read one answer); a claim accepted above it by the seating rule; below the height every rule is byte for byte the release's |
| SEAT-10 | **The parameter.** `independent_floor` raised from 3 to 4 at a later flag-day entry | a class with three independent operators is admitted below the new height and refused (`Independence`, 3/4) above it |
| SEAT-11 | **A composite class.** The parent held by seven operators, the composite (parent + adapter) by two | the composite is refused (readiness is per class id and artifact root); the parent's claims are unaffected |

#### Proposal B — executor conformance by the seat (go)

**Decided: go.** To be built by this lane after the preflight (§II.2), node-only, no fence. A seat, before it first proves readiness
for a class, runs the class's canonical self-test on its own executor against the reference evaluator — a few positions, or one tile
of each primitive kind for a large class (§II.9 L2: sampled conformance) — and posts a possession proof only if they agree. When it
does not, it writes why, and `getPalwNodeStatus` (what this node is doing) shows it. A dishonest seat can skip the self-test and sign a false assertion; readiness alone does not prevent harm or establish detection. Responsibility follows only when authenticated evidence objectively refutes the assertion within its signed scope. Future admission must therefore also pass independent public-bond evidence acquisition, localization and conviction under RFC14/ADR173. The registry cannot tell from a readiness declaration alone which seats actually tested.

#### Proposal C — what probation pays (C1 decided)

**Decided: C1.** Probation stays paid, and the gates move in front of it (A, and B at the seats). Probation then begins only with
seven ready *distinct* operators, three of them independent of the registrant and the executor, each of which ran the class's
conformance on its own executor, and it admits 50 ‰ of the derived volume until ten probe claims have been verified. The first paid
claim follows every condition of R5 that a chain can enforce. (C2, unpaid probation, was not chosen: it needs a probe-claim marker or
a state-dependent payout in the claim accounting, touches conservation properties of the escrow and the vesting, and asks producers to
run inferences unpaid for a class they may not trust.)

#### The registration policy of the CLI (decided)

`misaka model add` **requires a `palw-class pack verify` PASS by default**: it takes the pack with `--pack <dir>`, verifies it against
the artifact, and registers only on PASS. An explicit expert override, `--skip-pack-verify`, registers without one and prints a
warning that nothing the pack would have checked was checked. This is a CLI policy, not consensus: the chain does not enforce it, and a
registration made any other way is valid.

#### Open items

1. **The API with lane D** (above): to confirm or amend the signature, the error and the lifecycle observation's new field; one
   implementation for IR, generative and composite classes.
2. **The flag-day height** for `palw_class_seating` (the RFC-0003/0004 flag day).
3. **The drills** (lane C's D-M, lane D's step 8) to include SEAT-1 to SEAT-11.

## II.8 Acceptance criteria and corpus completion

### II.8.1 The acceptance criteria as checks

| Criterion | The check that closes it | State |
| --- | --- | --- |
| **A1** a custom quantisation gets a verdict before the weights are fetched | `palw-class preflight` over a synthetic GGUF header with custom type ids and an `mmproj`, in a file truncated after the header: the verdict names the type ids, the tensors and the unsupported feature, and the source never reads past the data offset (instrumented) | with the preflight (task 7). The refusal's content exists (§II.5.6) |
| **A2** root, converter version and profile reproducible; independent conformance | `pack build` then `pack verify --rebuild` rebuilds the artifact under pools of 1 and 7 threads to one root and runs the vectors on the reference evaluator, the typed backend and the independent implementation; the Hugging Face fit is within the tolerance | met on the fixtures (`tests/runtime_pack.rs`, `tests/determinism.rs`); cross-platform reproduction is §II.9 L7 |
| **A3** the testnet-12 preflight shows the court window and the canonical-job conditions | a Qwen3.5-9B-shaped configuration: the window needed and the limit, and the canonical job against the network's bounds, at a height | with the preflight (task 7) and the court-window plug point (§II.2.6) |
| **A4** mining starts only after ready seats of distinct operators with possession proofs | today: ready bonds with possession proofs (the lifecycle, §II.7.2); after Proposal A and C1: for every class kind, `seat_count` distinct ready operators besides the executor (five on testnet-12; "seven" was an earlier draft — corrected 2026-10-12), three of them independent of the registrant and the executor | partly met today; Proposal A (approved) closes the rest |
| **A5** failures are visible per stage in the CLI and the registry | the preflight's stage table (convert, register, mine); the registry's `blocking` and its CLI display (§II.7.4), one test per lifecycle state | with `blocking` (this lane) and the preflight (task 7) |
| **A6** a majority of Hub model repos can register and reach `Final` | the pinned Hub census, real-checkpoint cohort and end-to-end gate evidence meet every threshold in §II.10.5 | open; architecture-corpus percentages and earlier Hub estimates do not close it |
| **A7** a new family within armed semantics needs no `main` update | third-party direct TIR and a declarative frontend pack each complete §II.11.4 with the same node/consensus binaries; a novel primitive is refused | open; current adapter and quant-descriptor support do not prove this full route |
| **A8** local LLMs meet kernel coverage | pinned cohort shows ≥90 % real-size registration-to-Final success with the confidence requirement; all residual blockers remain counted | open; no measured denominator or active-kernel cohort drill |

### II.8.2 Corpus completion

The preflight and the frontend are only as good as the architectures they have met, so Part II adds a *completion* criterion to
Part I's freeze criterion (§1.2), for the corpus-and-coverage lane. The corpus is complete when:

1. **Breadth.** It holds **50 to 100** representative architectures, counted by *feature set*, not by name (two models with equal
   `ModelSpec`s are one entry), each with a real published configuration and a tiny random-initialised fixture that matches
   `transformers` for its reference.
2. **Expressibility.** **At least 90 %** of the corpus lowers with the features and primitives that exist, as Level A or Level B —
   no new feature, no new primitive. The remainder are Level C, each naming its missing feature or its smallest *general*
   primitive.
3. **Court coverage.** For every TIR primitive *reachable* from the lowered corpus programs (appearing in some commit cone), the court
   has a conviction and an acquittal vector: the family certificate covers **100 %** of them.
4. **No model names in the path.** No branch on `model_type` or an architecture name outside adapters, fixtures and tests; the gate
   is a search over the crates.
5. **Reproducible verdicts.** Every corpus entry has a golden preflight (`--json`, no timestamp) and a golden program and artifact
   digest (`tests/golden_lowering.rs`); a change that moves one is deliberate and bumps the version it belongs to.

## II.9 Known limits and open questions

**Limits of what exists.**

- **L1. Calibration's float reference is not row-streamed.** It runs one layer's weights resident at a time before the budgeted
  window of the conversion and is reported, not budgeted (`tests/streaming_budget.rs`). A model whose single layer does not fit a
  host's memory needs the float reference itself streamed.
- **L2. Conformance loads the artifact whole on each of three executors.** For a very large model, `pack build` and `pack verify`
  need a streamed or **sampled** conformance mode (the commit points of a few positions, or one tile of each primitive kind), which
  Proposal B also needs. Not built.
- **L3. The lowerer emits the `legacy-greedy-only` logit convention** until lane G's `LOGITS_Q24_V1` (lowering version 2, `af8d35a86`
  on `tir/generic`) reaches this line; a pack records either, and `pack verify` checks the unit by the slope of the fit.
- **L4. Quant vectors from re-implementations** (§II.5.7): only the ggml types and `MXFP4_HF` are checked against the maintainers'
  own code. A real GPTQ, AWQ, compressed-tensors and bitsandbytes checkpoint, with the library's own dequantised output, belongs in the
  corpus.
- **L5. An LLM.int8 checkpoint is read at any threshold** (§II.5.8), so the integer program omits the run-time outlier decomposition the
  library applies at a threshold above 0; the pack's reference fit is what measures the difference, and a pack that fails its tolerance is
  not VERIFIED. No real int8 checkpoint has been measured (the library is not installed offline).
- **L6. A 4-bit code costs a byte** (§II.5.8); a packed `i4` is a v2 candidate in `freeze-v1.md`.
- **L7. `libm-v1` is argued platform-independent (pure Rust, no `std` math) and measured on one platform** (§II.3.3); a Linux
  x86-64 rebuild of a pack built on macOS arm64 has not been run.
- **L8. Remote header fetching** (cargo feature `remote`) is tested against a loopback server only.
- **L9. Vision and audio towers are not computed** by any class (RFC-0003), and are named in the scope.

**Open questions.**

1. **Should a pack's digest be committed in the class record?** It would let a seat check that the artifact it holds was built by a
   verifiable pack. The container's meta already carries the provenance and the sidecar binds file digest and inventory root, so this
   is not proposed: a class record is consensus data, and a pack is evidence.
2. **Where do conformance vectors for a permissionless class come from?** The registrant's pack is one source; every seat can also
   regenerate the vectors from the program on the reference evaluator, which is Proposal B.
3. **The court window** (§II.2.6): whether the class-specific window of int-10 replaces the global rule everywhere the preflight
   reads it, and what the preflight reports for a class registered under the old rule.

## II.10 Hugging Face majority: from a lowerable architecture to a class that can reach `Final`

*Added 2026-10-03 for R6/A6. This is an acceptance and implementation plan for Part II. It does not arm a fence, relax
`tir_admit_v1` or the court, or assert that the present build already meets the target. RFC-0003 supplies non-text job and
output profiles; RFC-0006 and RFC-0007 supply the smaller per-seat verification and cheaper receipt carriage needed to
serve large classes. RFC-0008 changes block work, not the model-onboarding denominator.*

### II.10.1 The gap and the unit of measurement

The 92 % A/B reading of the 100-architecture corpus (§Implementation status, `hf-coverage.md` §23) means that those
fixtures' feature combinations read. It is **not** the share of Hub repositories whose real weights convert, whose
full advertised task is supported, whose real-size program passes admission, or whose claims can be licensed and
finalised. `hf-coverage.md` §19.2's approximate registrable counts are estimates over incomplete modality and format
coverage, not a live census or a `Final` measurement. An unsupported image, audio, encoder, adapter or quantised repo
cannot disappear from the denominator just because the decoder corpus passes.

The census unit is one public **model repository at one pinned commit SHA** (`repo_id@revision`) in a dated Hub snapshot.
One repo counts once in the headline, even if it publishes many formats. Its selected artifact path, every base-model
reference and their SHAs, task, intended inputs/outputs and weight digest are recorded. A derived LoRA or other adapter
counts only if its base resolves at a pinned revision and the complete composite can be checked. Also report unique
artifact roots and unique feature sets separately, so a popular architecture copied into thousands of repos cannot
hide missing families. Later revisions enter the next snapshot, never rewrite the old result.

Use three visible denominators, and publish the exclusions rather than silently shrinking them:

| Denominator | Meaning |
| --- | --- |
| `D_all` | Every public Hub model repo enumerated at the snapshot, including gated listings and repos with no usable weights. Private repos are not enumerable and are stated outside the claim. |
| `D_files` | The subset with publicly readable, complete weight files or a fully resolvable base-plus-adapter chain. An unknown architecture, format or modality stays **in** this denominator. |
| `D_rights` | Repos from `D_files` for which the registrant has established permission for the proposed download, redistribution/serving and on-chain use. A card's license field is evidence to review, not an automatic permission decision; unknown terms remain `RIGHTS_UNCONFIRMED`. |

Publish both repo-weighted and download-weighted rates, but the repo-weighted `D_all` rate is the headline. Downloads
are a secondary demand signal, never a substitute for breadth. Report each task (`pipeline_tag`), library, model-size
band, format, age and feature family, including an `unknown` stratum. A repo that advertises a multimodal or generative
task does not count as covered because its text decoder alone lowers: the **whole declared task** must have a canonical
job, inputs, output, court path and artifact. A smaller text-only class may be listed as a separately scoped class,
without crediting the original repo's full task.

### II.10.2 A repeatable Hub census and real-checkpoint cohort

At a recorded UTC instant, enumerate model repos through the version-pinned Hub API. Save the response, repo id,
commit SHA, `pipeline_tag`, `library_name`, card license/gating fields, downloads, `siblings` and the recursive file
inventory with sizes and content identifiers. Resolve the repository and every referenced component at those SHAs.
Fetch only configs, model/pipeline indices, tokenizer metadata and safetensors or GGUF **headers** for the census's
first pass. File access failure, missing weights, an ambiguous base reference and unsupported files are results, not
repos dropped from the table. Respect Hub pagination and rate limits; the census is reproducible from its saved
manifest without asking the Hub to retain the same mutable `main` branch.

The Hub exposes `list_models`, revision-pinned `model_info` and `list_repo_tree`; model cards carry task and license
metadata. `snapshot_download` can fetch only named files at a revision. Standard Diffusers pipelines have a
`model_index.json`, and modular pipelines may have `modular_model_index.json`; treating every repository as a
`transformers` text `config.json` is therefore a measurable coverage loss. See the primary API descriptions:
[Hub API](https://huggingface.co/docs/huggingface_hub/package_reference/hf_api),
[model cards](https://huggingface.co/docs/hub/model-cards),
[revision-pinned downloads](https://huggingface.co/docs/huggingface_hub/en/guides/download), and
[Diffusers loading](https://huggingface.co/docs/diffusers/main/using-diffusers/loading).

Run the header-only preflight for **every** `D_all` entry that exposes readable metadata. For deeper gates, draw a
published, reproducible stratified sample of real checkpoints from each material task × format × size × feature
stratum, with a random tail sample as well as the most downloaded repos. Pin the sample seed, inclusion probability,
all repo SHAs and reasons for nonresponse. A finite corpus of 100 architecture fixtures remains a regression suite;
it is not this probability sample. Publish estimates with confidence intervals and raw counts, and show the failure
list so the numerator cannot improve by reclassifying a hard repo as `unknown` or `inaccessible`.

### II.10.3 The gates whose failures must be counted

The preflight, pack and chain observations use one machine-readable row per repo and one stable `blocking` code per
failed gate. A downstream gate is `NOT_RUN_AFTER_<gate>` when an earlier one failed, never `PASS` by inference.

| Gate | PASS evidence | Examples of named blockers |
| --- | --- | --- |
| `source` | Pinned files, components, task and access/rights decision; complete artifact or resolvable adapter base | `GATED_ACCESS`, `MISSING_WEIGHTS`, `BASE_UNPINNED`, `RIGHTS_UNCONFIRMED` |
| `lower` | Full task lowers to a versioned `ModelSpec`/TIR program and every semantic key and weight is consumed | `FEATURE_C`, `CUSTOM_CODE_UNMODELLED`, `MODALITY_PROFILE_MISSING`, `PARTIAL_TASK_ONLY` |
| `pack` | Real checkpoint converts by a bounded-memory stream; format decode matches an independent implementation; reference and integer outputs meet the pinned fidelity rule; rebuilt roots agree | `QUANT_DESCRIPTOR_MISSING`, `QUANT_LIBRARY_UNVERIFIED`, `FIDELITY_FAIL`, `ARTIFACT_MISMATCH` |
| `admit` | The real-size graph, cost, court cone/window, DA close, capacity and artifact pass the actual `tir_admit_v1` and registry path at a named ruleset/height | `COURT_BUDGET`, `CLOSE_TOO_LARGE`, `CONTEXT_BOUND`, `CLASS_SEATING` |
| `seat` | Required distinct, independent operators prove possession and each seat's executor conformance for **this** class root; required shard/witness data are available | `READY_SEATS_SHORT`, `INDEPENDENCE_SHORT`, `SEAT_MEMORY`, `WITNESS_UNAVAILABLE` |
| `claim` / `Final` | A real job makes a valid PALW claim, obtains counted independent receipts, survives the court window and reaches `Final` with its expected reward/weight; the claim and all lifecycle objects remain in the accepted fold | `PANEL_BACKLOG`, `RECEIPT_TIMEOUT`, `OBJECT_DROPPED`, `COURT_FAULT` |

`registration-ready` means `source` through `admit` passed offline against the named ruleset; `registered` requires
the class's transaction to be accepted on the chain. `seat-ready` and `Final-proven` are later, different facts.
A produced block, a `PanelBound` object, a `Capped` class, or a successful tiny fixture is not a `Final` verdict.
Report stage counts as a funnel for `D_all`, `D_files`, `D_rights` and every stratum, with the exact stage at which a
repo stopped. Never use an unverified pack, an unavailable independent seat or an optimistic receipt as a pass.

### II.10.4 Close the largest measured blockers without weakening verification

1. **Generic frontend and full-task profiles.** Rank `FEATURE_C` and `MODALITY_PROFILE_MISSING` by lost repos and
   downloads. Add a feature to the data adapter/generic lowerer once for all matching architectures (II.1 P1–P4),
   and require a full real-checkpoint fixture plus the one-move court battery. Route image, embedding, vision input,
   audio and video through RFC-0003's canonical jobs, stage edges and outputs. Keep a missing profile blocked; no
   text-decoder-only success can silently stand for a vision or audio model.
2. **Formats and custom code.** Add common safetensors, GGUF and other measured weight layouts through the descriptor
   registry (§II.5), checking real upstream quantiser output, not only synthetic bytes (§II.9 L4–L5). A repo's Python
   `trust_remote_code` or custom Diffusers pipeline never runs in a consensus node or seat. An offline, revision-pinned,
   isolated reference run may help author a declarative adapter and fixtures; independent implementations must then
   reproduce the canonical program, weights and output. Unknown behaviour remains a named refusal. Hub custom code
   is executable code, as [Diffusers documents](https://huggingface.co/docs/diffusers/using-diffusers/custom_pipeline_overview).
3. **Real-size admission.** Triage actual `COURT_BUDGET`, close, context and fidelity failures before changing a
   ceiling. For example, `hf-coverage.md` §19.1c records Qwen3.5's real-size `C_j` refusal and proposes bounding
   elementwise work in the same generic cost proof. Measure the new bound and court vectors; never waive a court
   ceiling, a range proof or an unknown quantisation to improve a coverage percentage.
4. **Seats and verification supply.** Proposal A's class seating and Proposal B's seat conformance (§II.7.5) remain
   binding. RFC-0006 can make a large class feasible per seat by verifying committed layer/position cells with only
   that shard's weights; RFC-0007 can lower verifier work where its algebraic checker is sound and batch verdict
   carriage. Their dormant fences need independent crossing drills before their gains count. A capped class under
   RFC-0007 is measured separately: it does not pass `Final` until full holder coverage and re-verification. At the
   target claim rate, measure receipt supply, `PanelBound` age, queue growth, licences, `Final` rate and dropped
   lifecycle objects. Increase qualified seat supply or bound intake when the queue grows; do not turn missing
   receipts into `Valid` or reduce independence/quorum to meet a target.
5. **Iterate from the census.** For each release, publish the top blocker buckets with counts, one generic change per
   bucket, its before/after cohort, and regressions in other strata. Re-run the census on new pinned snapshots.
   An improvement in A/B architecture coverage that does not move `registration-ready`, `seat-ready` and `Final`
   remains a frontend improvement, not completion of R6.

### II.10.5 Exit criteria and the permitted coverage claim

The phrase **"most Hugging Face models can be brought to PALW"** is permitted only when a dated report shows all of
the following. The first target is literal majority; the engineering target is at least 80 % of `D_files` at
`registration-ready`, without treating `D_files` as the headline denominator.

1. The estimated repo-weighted `registration-ready / D_all` share has a **one-sided 95 % lower confidence bound above
   50 %**, with exclusions and nonresponses included as failures in `D_all`. Give the exact point estimate, bound,
   denominator and snapshot. Report all material task/format/size strata even if some remain below 50 %; never
   advertise an unrestricted modality claim from a text-only result.
2. From the same stratified real-checkpoint cohort, the estimated `Final`-capable share of `D_all` also has a lower
   bound above 50 %. Each sampled success needs a confirmed registration, independent seat evidence, a PALW claim
   and its on-chain `Final` under the shipping binary and the target ruleset. A sample without enough seats is a
   measured `seat` failure, not a waived trial. The report includes enough independent operators to exercise the
   seating rule; a four-node fence-crossing drill cannot close this item.
3. The panel runs at the intended sustained issuance rate for at least two receipt windows without an increasing
   `PanelBound` queue, an unaccounted dropped lifecycle object or a stalled `Final` rate. Every failure is retained
   in the cohort's gate table. Corpus coverage (§II.8.2), `Capped` entry, block production and isolated unit tests
   are supporting evidence, never replacements for this run.

If any condition fails, publish the measured narrower claim (for example, *decoder-only float checkpoints lower*)
and the blocker distribution. This keeps the goal visible without declaring Hub-majority registration or `Final`
from the 90–92 % architecture corpus or the earlier unmeasured Hub estimates.

## II.11 Future families without a `main` release (R7/A7)

*Added 2026-10-03. This is the target contract for permissionless onboarding, not a claim that the current frontend,
registry or seats already pass it. “No `main` update” means no consensus/node binary upgrade and no privileged
model-family approval. Registrants and seats may install third-party **off-chain** tooling and fetch class artifacts;
the class must still satisfy the armed admission, seating, execution and court rules.*

### II.11.1 Decide by the missing semantic, not by the model's name

| What a future model needs | Route | `main`/protocol change? |
| --- | --- | --- |
| New config keys, tensor names, layer schedule or a **static** combination of already armed TIR primitives | A third-party frontend pack (§II.11.2), or direct canonical TIR (§II.11.3) | No, if its graph and real-size class pass admission |
| New storage or quantisation layout expressible by `quant-format.v1`, or a custom offline importer that emits the canonical artifact | A descriptor with independent decode vectors (§II.5), or an independently reproducible converter | No; unknown layouts remain refused until described and checked |
| A new task made solely from already armed canonical job/input/output kinds and pipeline stages | A class-declared RFC-0003 pipeline and complete task scope | No; a new **consensus** job or output meaning needs a versioned RFC-0003 extension |
| A tensor operation not expressible by active primitives within checker/court limits | `KERNEL_EXTENSION_REQUIRED`: generic semantic/constraint/checker/court family, independent vectors, resource/soundness review and fence (§1.2, §9; ADR-0172) | Yes, coordinated kernel upgrade; no guest fallback |
| Bounded data-dependent control | Finite AOT/`Select` within active grammar/limits, or an explicitly defined bounded routing/state kernel extension | No for admitted composition; yes for missing relations; no BVM/GVM |
| Runtime-dependent agent/tool workflow or arbitrary program logic | Off-chain orchestration may submit supported jobs; arbitrary uploaded programs are outside the model-plan grammar | No consensus VM is planned; a new bounded task relation needs a separate kernel/task proposal |

Thus a frozen finite TIR can support **new combinations indefinitely**, but cannot promise every future computation.
There is deliberately no universal instruction substrate. Missing semantic/memory/checker/court relations remain
extension gaps until a reusable kernel upgrade becomes active. Arbitrary circuits, `CustomOp`, EVM precompiles
and frontend scripts cannot bypass that boundary. Bind semantics, whole-statement constraint coverage, bounded
resources and dispute localization; confidence is not registrant-selected. Importers and job/input/output profiles
remain separate problems. The old RFC05 decoder survey is not measured residual-model coverage (§II.12).

### II.11.2 An open, content-addressed frontend-pack interface

The built-in `FeatureId` registry and `model-adapter.v1` are conveniences for the reference lowerer, **not** an
allowlist for consensus. The present adapter maps keys onto features that the installed lowerer already knows;
therefore that adapter alone cannot express every future feature without a tool update. Add a versioned,
user-supplied `tir-frontend-pack` format for the common no-release path. Its declarative language can construct a
bounded static TIR subgraph from existing primitives, dimensions, layer schedules and declared `Fixed`/`Hist` state;
map config keys and tensor roles; include quant descriptors; and declare the full task scope and source revisions.
It may compose named template fragments but has no runtime branch, IO, clock, remote fetch, native code or operation
definition. The compiler expands it under explicit size/fuel limits, type-checks every tensor and refuses an
unconsumed math-affecting config key, tensor, component or custom-code behavior. Its output is ordinary canonical
TIR plus the artifact and runtime pack, not a new class kind. A pack may be published anywhere and identified by
its content hash; no default repository, signer or maintainer approval is needed for admission. The reference CLI
may offer a curated index for discovery, but index membership cannot decide validity.

The runtime pack pins the frontend-pack hash, compiler/tool version, config and source SHAs, quant descriptors,
generated `ModelSpec`/TIR digest, artifact root, complete/partial task scope, conformance vectors and HF-reference
fidelity evidence (§II.4). A seat verifies **the submitted TIR and artifact** with the armed generic evaluator and
class conformance rules; it never has to execute a registrant's Python, `trust_remote_code` or frontend pack to
decide a claim. A third-party pack's own test vectors do not grant authority: malformed output fails the common
verifier, and a false HF-equivalence claim is distinguished from the on-chain integer-program verdict.

**Implementation increment (2026-10-10):** [tir-frontend-pack.v1](../design/palw/tir/tir-frontend-pack-v1.md)
now composes the frozen primitive/state grammar without ModelSpec dispatch, consumes config/tensor
bindings, and streams exact integer or explicitly rounded IEEE imports into the ordinary container.
`palw-tir-frontend` emits replayable receipts; SDK `pack build-frontend`/`verify-frontend` pins source
SHAs/compiler/executor revisions and uses common inventory and three-way conformance. Fixtures
include direct-byte equality and offline class admission. Bounded inline **virtual**, **tensors**
and **blocks** quant descriptors now feed the same compiler/SDK route, with explicit raw roles,
mandatory decode vectors, nested-config checks, bounded pages and before/after source hashes.
Tensor shape/JSON metadata is acquired after all binding-header checks, with per-plan and aggregate
limits, exact-number parsing and source-change pins. MXFP4 expert axes, all built-in saved layouts
and unknown third-party formats are exercised. Storage decode is explicitly binary32 before the
declared integer rounding. Native whole/split GGUF acquisition now exposes raw names/layouts to
the same generic CLI/SDK, including supplied unknown GGML IDs, strict native metadata and embedded
tokenizer identity. Standard split names and a public index allow independent part selection;
part numbers, shared declarations, primary metadata and global tensor uniqueness are checked.
Aggregate header/allocation/count budgets, checked extents and snapshot revalidation protect
this producer-side reader across every part and index. SDK artifact publication follows all receipt/inventory/conformance/source
checks. Independent companions now attach public reference logits under predeclared revision/task/
context/units/error criteria, and verify independently repeats a portable fit. The existing exact-class
binding and beacon commit/run/fresh-verify tools accept both formats through one artifact/layout/
static-admission/challenge/evidence path; independent imports use typed absent calibration.
Conformance binds the node's kernel program-root domain, separately from the container graph root,
and derives the same plan. Single-program selection uses the node prosecution/carrier/block
limits for v1/v2/segmented v4 without shortening requested context; v4 still requires separate
OPV admission/economics. No tool report supplies availability, activation or approved policy.
Reference-logit gates stay separate from source identity, routing/state fidelity and task quality.
These synthetic fixtures do not close §II.11.4: real-checkpoint source fidelity, real-node beacon and
independent-seat
claim/Final/redemption evidence remain open in the [implementation ledger](../design/palw/tir/rfc0002-implementation.md).

### II.11.3 Direct-TIR escape hatch and exact boundary of permissionlessness

Any independent compiler may submit canonical `TirProgramV1` bytes (or an armed RFC-0003 pipeline), a compatible
artifact and the ordinary class registration. The registry must judge them by `prim_set_id`, program version,
canonical encoding, type/range/cost/court admission, artifact commitment and class lifecycle only. It must not
require a recognised `model_type`, built-in `FeatureId`, official pack, HF repository, preferred compiler or
model-family signature. This path is essential when the declarative frontend language is too narrow but the
**resulting TIR is already expressible**. It also keeps an extension-language revision outside consensus.

Direct TIR proves the submitted integer program can be adjudicated; it does **not** prove that it faithfully
imports the named HF checkpoint. Without independently reproducible source conversion and fidelity evidence,
show `SOURCE_EQUIVALENCE_UNVERIFIED` in onboarding reports and do not count the repo as an A6 full-task success.
Likewise, an active kernel execution path alone does not solve a missing canonical input, output or job profile;
the full advertised task stays blocked under §II.10.1 until that profile is armed. A class that exceeds static
ceilings remains `EXCEEDS`, however popular its model family is. New semantics must use a new `prim_set_id` or
program/job version and fence; previously registered classes retain their exact old meaning and court.

### II.11.4 Acceptance before calling this permissionless

With **unchanged** consensus/node binaries, unchanged armed `prim_set_id` and no model-name allowlist:

1. An independent party names a previously unknown, static feature combination, publishes a frontend pack and
   a real checkpoint, then completes header preflight, streamed conversion, reproducible pack verification,
   registration, independent seat possession/conformance, a claim and on-chain `Final`. Another party rebuilds
   the same roots without the first party's executable code.
2. Another independent party emits the same canonical TIR bytes directly with a different compiler. Admission and
   court give the same verdict. A third party adds a quant descriptor and its independent vectors without a
   node release; bad vectors and ambiguous tensor bindings are refused.
3. Mutation cases cover an unknown op, hidden config key, missing tensor/component, false shape, unbounded
   expansion, unsupported job kind, bad artifact root and a deliberately wrong fused backend. Each fails at the
   named gate; an untrusted pack cannot bypass admission, seating or court. The old registered class still runs
   byte-identically after a newer frontend-pack version is published.

Record node/consensus binary digests, frontend/compiler and pack digests, class and artifact roots, seat operators,
claim id, `Final` reference and every refusal. Passing a small direct-TIR fixture establishes the protocol
interface; a **real checkpoint, full task and independent seats** establish the onboarding claim. Feed these
results into A6's Hub cohort, so the no-release extension mechanism demonstrably improves the real `Final` funnel.

Implement in this order: arm and exercise generic TIR admission/execution/court and the needed RFC-0003 job profiles;
prove direct third-party TIR registration; add the bounded declarative frontend-pack interpreter and open discovery;
run A7 and the Hub-wide A6 cohort. Measure the local-LLM residual (§II.12) before prioritizing or claiming a new
kernel extension. The public extension interface, Hub-wide majority and local-LLM coverage target are distinct milestones;
none may be inferred from another.

## II.12 Local-LLM coverage: active kernels and an explicit extension queue (R8/A8)

*Added 2026-10-03; revised 2026-10-06 under ADR-0172. The historical 90/10 VM split is withdrawn.
This is not a present 90 % measurement. It is narrower than A6's all-Hub denominator and broader than the old
decoder-only safetensors corpus. [Kernel design §§K.0–K.8](../design/palw/versioned-kernels.md) define kernel-only extension.*

### II.12.1 Define “90 % of local LLMs” before counting

Publish a dated, reproducible frame `L_listed` of publicly discoverable models offered for **local text generation**,
including local chat/reasoning/coding checkpoints, MoE and hybrid models, safetensors and GGUF-only releases,
pre-quantised weights and adapter-plus-base chains. The initial discovery frame is the Hugging Face Hub's pinned
text-generation and GGUF listings plus the local-model registry entries in Ollama's library; add other public
registries with a named snapshot and method, and disclose missing catalogues. HF's [Hub API](https://huggingface.co/docs/huggingface_hub/package_reference/hf_api)
supports model listing and revision metadata; its [GGUF catalogue](https://huggingface.co/docs/hub/gguf) is a
separate format signal. [Ollama's library](https://ollama.com/library) is an additional local-distribution source.
No finite catalogue is literally every model “in the world”; the claim must name the surveyed sources and date.

The counted unit is one pinned model checkpoint or complete base-plus-adapter chain, with its intended local task;
exact mirrors of the same weights collapse by digest, while changed weights remain distinct. Multiple quant files
of one checkpoint are a **format-coverage** stratum, not extra votes in the headline. `L_files` is the subset whose
complete weights and task metadata are publicly readable; inaccessible gated entries, missing files and unresolved
bases stay in `L_listed` with named blockers. Unknown use rights remain in `L_files` and fail the `source` gate as
`RIGHTS_UNCONFIRMED`; they are never silently removed from the denominator. Report both denominators, feature-family
and size strata, and repo-weighted and demand-weighted views. A vision-chat model counts for its advertised full
input task only when the needed RFC-0003 profile exists; a decoder-only extraction is separately labelled.

### II.12.2 Actual kernel routes and counted gaps

For every `L_files` member, run §II.10.3's source → lower → pack → admit → seat → claim/`Final` funnel at its real
size. Name the route `ACTIVE_KERNEL`, `KERNEL_EXTENSION_REQUIRED` or another exact blocker; publish kernel/suite/
plan ids and retain earlier blockers if an upgrade later succeeds. A pass requires a registered whole-task class,
independent capable seats and actual `Final` under the active binary. New probabilistic profiles require approved
encoded/algebraic checks, whole-claim error accounting, positive receipts, DA and the elapsed challenge window,
with bounded exact court on dispute—not routine full segment replay. An inactive proposal, a tiny fixture or a
`Final` for a partial task is not a pass.

The target is **at least 90 % active-kernel passes over `L_files`**, with a one-sided 95 % lower confidence bound at or above
90 % when a probability sample is used. Report the exact numerator, denominator, weights, sample design and date.
Publish the residual extension/resource queue: `KERNEL_EXTENSION_REQUIRED`, `CHECKER_LIMIT`, `COURT_LIMIT`,
`DA_LIMIT`, `SEAT_CAPACITY`, `NEEDS_JOB_PROFILE`, `SOURCE` or the actual first failing gate. Count a later extension
only after activation and the same full-task drill. Unsupported, untested and resource-limited models remain
failures in the denominator; there is no automatic route for “the other 10 %”. Report each kernel family, the
aggregate end-to-end rate and the still-uncovered fraction.

### II.12.3 Engineering order and the upgrade rule

Close frequent format, importer, quantisation, static-feature, real-size admission and seat-throughput failures in
RFC-0002 first. Group missing relations into reusable versioned kernels rather than one extension per model.
Add semantic/checker/court vectors and whole-statement soundness/resource evidence, shadow-test, coordinate
fingerprinted activation, then rerun the cohort. Missing importers stay off chain; missing canonical jobs remain
RFC03 tasks. A heavy operation outside active limits is **not** covered: measure tiling/composition improvements,
then propose a bounded kernel/limit change with checker, DA, court and panel evidence. Do not implement a VM
fallback. A frontend pack cannot change consensus semantics or bypass a cap.

A8 closes with published `L_listed`/`L_files`, ≥90 % active-kernel success meeting the confidence requirement,
real-checkpoint `Final` references, sustained panel evidence and a complete residual table. This is not 100 %
coverage: remaining kernel/resource/source/rights failures prevent an unrestricted coverage claim. RFC11's
broader all-HF target retains `D_all`; neither target implies the other.

## II.13 Immutable challenge-policy binding and later conformance evidence (2026-10-08)

[RFC07 Part VI](0007-palw-verification-certificates-and-algebraic-checks.md#post-commit-challenge-protocol) is the sole
post-commit challenge protocol. For a new versioned class/profile, bind the active KernelDescriptor digest,
VerificationPlan root, `challenge_policy_id`, program/artifact/tokenizer/input-schema/layout/context commitments
and RFC14 dispute-plan digest before any challenge randomness. Resolve checker/challenge/soundness as the approved
immutable tuple in the [Kernel design](../design/palw/versioned-kernels.md); a declarative plan cannot select weaker randomness, omit relations or upload a checker.

| Immutable identity/statement bindings | Later conformance or activation evidence |
| --- | --- |
| Kernel descriptor, semantic/checker/court/soundness suites, challenge policy, plan and material/layout identities | Actual source references, beacon/lock descriptor, challenge seed, selected queries/vectors, transcript, outcomes |
| Canonical class/profile/candidate id fixed before future work | RFC13 ConformanceCommitment submission provenance and BeaconConformanceEvidence tied to that fixed id |

Do not put an actual beacon or sampled row into class identity: a new beacon does not rehash the same class. Changing
artifact/layout/plan/policy creates the appropriate new class/profile commitment under a separately versioned encoding;
legacy hashes and already-bound claims keep their old meaning. No new codec/hash domain or network activation is
assigned by this document. Claims/receipts/cache keys/material manifests bind the applicable identity and policy.

RFC11 §17 defines Static Admission → Beacon Conformance → Active Eligibility. RegisteredDormant can precede the
beacon, but neither conformance agreement nor an unknown-op sample promotes it to Active. Full semantic/constraint/
court/public-material/resource admission remains mandatory; the beacon selects tests, not semantics. Independent
runtime-pack conformance follows RFC13, while per-claim verification and public prosecution use the same RFC07 policy.
All newly proposed bindings/lifecycle gates need an explicit implementation/migration before use.

## Mission alignment amendment — 2026-10-07

§5、§II.7、§II.10–II.12のadmissionにpublic-verifier dispute completenessを追加する。静的cone/cost検査、kernel catalog、conformance、readyな独立seat、admission jury、FamilyCertifiedだけでは報酬・weightを有効にしない。boundary/history/checkpoint、fused reductionのdissectionとcloseも、fresh non-seat verifierが公開取得した証拠から作れる必要がある。「登録時にadjudicabilityが確定する」はこの追加gateを含む場合に限る。

本節は、衝突する将来の実装指示・受入条件を改定する。本文中の既存実装、過去の測定、旧claimの規則はその時点の記録である。新しい合意規則はversioned specification・実装・独立試験・明示的activationを経て初めて適用する。[ADR173](../adr/0173-public-verifier-dispute-completeness-is-misaka-purpose.md)、[RFC14](0014-panel-independent-fraud-prosecution.md)、[RFC15](0015-panel-free-permissionless-verification.md)を参照する。

## Bond予算・総影響保存の改定 — 2026-10-10

[ADR-0176](../adr/0176-bond-bounds-palw-production-rewards-and-final-weight.md)と[RFC15 §8](0015-panel-free-permissionless-verification.md)を適用する。

canonical TIRの実行statement、実仕事量、承認済みkernel/planは正確に保持する。容量倍率による経済的権利の細分化を、計算量を小さく偽装する意味へ読み替えない。
全reward profileのclaim/block/reward/Final weightは同じproducer資本・期間の予算へ束縛し、正当な計算と公開検証の条件を維持する。

本節は将来の規範・受入条件を改定する。過去の実装/測定、旧claim会計とactivation履歴は保持し、文書改定だけで新規則を有効化しない。

## II.14 Completion contract — 2026-10-10

This revision incorporates the model-extensibility design review. All six requirements below are
part of RFC02 completion, together with the existing A1–A8 criteria. The implementation ledger
records evidence and unresolved work; passing a newly added unit test cannot close the whole RFC.

### II.14.1 Scoped support and the public extension interface

The support record key is **checkpoint revision × complete task × context range × storage format
and arithmetic version × kernel/verification/dispute plan**. Record structure/lowering, actual
weight import, source fidelity, real-size execution, ordinary verification, public localization/
terminal court and independent real-node Final/redemption as distinct stages. Each has measured
evidence, `FAIL`, or `NOT_RUN`; a downstream pass is never inferred. Record partial tasks, fixtures,
and reduced contexts explicitly. They cannot count as real-size/full-task coverage in A6/A8.

Complete both §II.11 paths through the same node binary: independent canonical TIR and a
content-addressed declarative frontend pack. They consume all math-affecting config keys, tensors
and components, use bounded expansion before allocation, and cannot depend on an official signer,
model name, registry entry or compiler. Unknown semantics fail the shared admission gate. Source
equivalence remains unverified until independently reproducible conversion and fidelity pass.

### II.14.2 Bounded dimensions, sparse computation and state

Preserve v1 bytes, meanings and courts. New dimension/index/state semantics require a versioned
program/kernel contract covering the entire execution, checker and court path. Token length,
patch count and audio-frame count have declared maxima and job-committed actual lengths. No claim
or later slice can enlarge them. Sparse access specifies index length/range, duplicate policy,
selection and tie rules, and the binding of selected values to the original state/weights.

Long-context acceptance must derive cost and evidence bounds at the requested length; raising
the v1 history constant alone is insufficient. MoE lowering must preserve selected-expert work;
sparse attention must preserve sparse access; recurrent updates must preserve state reuse. For
any unavoidable asymptotic or constant-factor expansion, report the reason, real-size ratio and
resource failure separately from structural representability. Measure execution, proof creation,
hashing, retention and delivery early, alongside bit-exact backend conformance.

### II.14.3 Storage, arithmetic and fidelity

Storage decoding (including GGUF, MXFP4 and FP8), consensus arithmetic (width, rounding, saturation,
normalization), and backend scheduling are independent identities. Decoding a format does not
establish fidelity; a backend changing committed results requires new semantics, not a tolerance.
Fix the evaluation corpus, contexts, metrics and acceptance thresholds before the run. Measure
logits and task quality, routing agreement for MoE/sparse selection, long-context degradation,
and state saturation/continuity where applicable. Keep failed and missing dimensions visible.

### II.14.4 One derived resource contract

Derive from the admitted program/plan and the committed job dimensions a resource vector for:
maximum execution operations; executor working memory; state/history bytes; evidence-generation
work; ordinary verifier work; on-chain checker work; court bytes/operations/rounds; evidence
retention/delivery; and aggregate concurrent claim/session load. Registration, claim admission,
proof ingestion and court processing must read the applicable same derived contract, rather than
trusting independently declared cheap values. Arithmetic is checked; reject overflow, false
shapes, enormous broadcasts and compiler expansion before their large allocation/work begins.
Per-block, per-bond and network-wide aggregate limits are required in addition to per-claim caps.

An executor's chosen memory budget does not set consensus capacity. Validator/court memory bounds
remain independently enforced even when a producer owns a large GPU. New resource-contract or
limit semantics require an explicit version/fence; legacy admission keeps its exact meaning.

The pre-activation `palw_probabilistic_constraints_v1` route now prices structural claim
admission from the registered commitment envelope and public schema, using the same byte-work
tariff and persisted block budget as public courts. Program, pipeline, segmented and typed
claims check their class envelope before copying traces; registrations must fit admission's
share and a worst court must fit the work reserved for proofs. Onboarding judgements and kernel
objects use the same budget transition. This changes hypothetical admission behind that dormant
fence; it does not change the live legacy route or the frozen TIR/plan grammar. SDK program
preflight applies the same admission/proof-work limits. This is **partial resource accounting**:
the byte tariff does not certify hardware instruction counts, and the complete executor,
evidence-generation, aggregate state/network and semantic checker resource vector remains open.

### II.14.5 Work and economic conservation

Resource bounds, canonical work and economic credit are separate. Apply defined canonicalization
to dead/duplicate/redundant expressions; do not claim to decide semantic usefulness in general.
Preserve work identity across roots, slices, riders and model copies, and charge derived rights
to the same principal and window. Excess PWU, redundant computation, model duplication, splitting
and resubmission cannot enlarge B/R/F ceilings. A faster correct evaluation is valid: claims bind
results, state and constraints, not a count of physical GPU instructions. Test role swapping and
the complete accounting path, not only a work-count helper.

### II.14.6 Whole-statement public verification and completion evidence

A new reusable feature ships as **semantics + type/range rules + costs + ordinary checker +
authenticated evidence binding + localization + terminal court**. Execution-only support cannot
enable rewards. Bind source weights, routing, previous state, KV positions, checkpoint/slice
continuity and outputs across the full graph. Sampling guarantees require whole-claim probability
accounting; primitive court coverage alone does not establish detection probability.

Required adversarial drills include shape/product overflow and huge broadcasts; tiny frontend
expansion bombs; substituted/duplicate experts and weights; reset state, shifted KV and skipped
slices; silently ignored config/tensors; wrong backends and artifact roots; floods of invalid
proofs/courts against an honest producer; duplicate work under different labels; and aggregate
concurrent overload. Attribute invalid requests' costs to the attacker and preserve the honest
producer's opportunity to answer. A fresh non-seat verifier must reach objective conviction using
public authenticated material, and an honest independent participant must reach Final/redemption.

The public onboarding verifier now derives the attempt, bound kernel program, Finals and v3
source seals from one complete op-211 row snapshot. Every page must retain the same DAA, roots,
header and total count; ordered rows, advancing cursors, completeness and both reconstructed
roots are checked before verification. The candidate, descriptor, program, plan and parameter
link must agree. This checks consistency with the served roots, not their canonical-chain
authentication: the caller still needs its node/state-proof trust. The 128 MiB retained wire-byte
ceiling is local reader policy, not a bound on total verifier RAM or a consensus capacity.
Complete-check attempts now dispatch from the same snapshot to exhaustive file replay, with the
chain's domain bounds checked before tensor collection. Pinned pagination on a continuously
advancing node, real-checkpoint public conviction and independent Final/redemption remain required
completion evidence. `palw-class kernel-preflight` also accepts canonical TIR without a frontend
or model configuration, reports the shipping schedule and applies the node's hypothetical bounds
at exactly the requested positions; it grants no registration or reward eligibility.

Use pinned real checkpoints for dense baselines, GDN/KDA and unequal QK/V heads, MoE/routing,
Mamba/hybrid state, sparse/compressed attention and complete multimodal tasks. The review's model
names are discovery candidates, not a supported list; pin revisions and verify their exact required
features before choosing tests. RFC03 supplies encoder/image/audio stage bindings; RFC07/11/14
supply whole-claim verification and G14. Conditional verification (A) remains: obtain the correct
model externally; do not reintroduce model-distribution consensus. Missing source access or a
zero detection floor remains a failed security condition, never repaired by type/cost checks.

#### 14.7 Bounded flat Gather courts and a real-program static regression

The dormant segmented decoder/encoder kernels identify whole-value pricing revision 2 in new
v4/v5 descriptor digests. A rank-one axis-0, unbatched Gather with output shape equal to its index
shape uses allocation-free direct lookup, with the same index refusal, operand reads and exact
result as the reference. Only this evaluator's per-output price changes (32 to 16 abstract units,
then the existing factor 64); authenticated bytes and both commitment hashes retain their prices.
The previous conservative DA16b withholding selection remains fixed. No resource limit, primitive
semantics, v1–v3 descriptor or activation fence changes.

The exact real Qwen2.5 pilot's 32-position TIR is committed as static regression material; its
worst court work is 473,589,248, below the unchanged guaranteed proof reservation 536,870,912.
Its direct TIR route is hypothetically eligible and remains inactive in the shipping schedule.
This closes the pilot's previous static court-price refusal only. A vocabulary-sized synthetic
court and differential/reference/root tests verify the optimization; they do not prove the
real-weight node path, source fidelity, long context, model security or Final/redemption. Evidence,
commands and remaining full-scope gates are in the implementation ledger's
[whole-value Gather pricing revision](../design/palw/tir/rfc0002-implementation.md).

#### 14.8 Generic bounded preparation of real parameter commitments

The SDK and `palw-class kernel-params` prepare the existing segmented-kernel v3 parameter map
from canonical artifact byte ranges without model/config/frontend selection. The raw-width
builder reads every element once and reproduces both commitment trees using checked bounded
buffers; it allocates no complete tensor or i128 expansion. Every model-instance workspace and
the aggregate payload cap are checked before any payload read. Decoder/encoder parameter roles
follow the explicit descriptor memory model; unknown memory models refuse, and v5 job-input slots are
excluded only under encoder semantics. Partial preparation publishes no map.

On the full real Qwen2.5 pilot artifact, all 1,636 instance roots and the complete param map agree
with decoded reference hashing. Streaming measured 57.985 s and 38,223,872-byte maximum process
RSS, versus 223.809 s and 4,131,471,360 bytes for the decoded diagnostic. These local debug
measurements concern producer/verifier **root preparation**, with explicit off-chain caps. They
change no wire preimage, kernel identity, resource price, network activation or economic right.
They do not prove source-model fidelity, execution, public node prosecution or Final. Commands,
bounds, raw evidence and the remaining full-scope work are in the
[RFC02 implementation ledger](../design/palw/tir/rfc0002-implementation.md).


### 14.9 Exact context and actual-weight node execution evidence

Local executor conformance must compare exactly the requested positive number of positions,
within the canonical program's history bound. It must refuse zero or oversized requests before
reference parameter acquisition, rather than silently substitute a shorter context.

The generic `check-kernel-node-execution` SDK example first checks every actual decoder
parameter instance against a supplied prepared v3 map under explicit off-chain limits, then
compares the node's typed CPU executor with the integer reference. It requires no ModelSpec,
model name or official compiler. This is a local diagnostic, separate from registered-model
public verification and chain admission.

On the full real Qwen2.5 pilot artifact, the predeclared two-position protocol authenticated
all 1,636 instances and compared 790 commit points and both complete vocabulary logits;
every comparison matched. Four node conformance tests passed. Comparison elapsed was
381.881 s; whole-process maximum RSS was 6,442,958,848 bytes. That process includes reference
and native execution plus preparation; it does not establish native producer speed, ordinary
verifier memory bounds, source-model fidelity, full context/task support, public conviction or
Final. The same-node-binary registration and actual-weight public claim/court path remain
required. Protocol, commands, scope, raw results and hashes are in the
[RFC02 implementation ledger](../design/palw/tir/rfc0002-implementation.md).


### 14.10 Native segmented roots and real delivery-court evidence

A canonical decoder artifact can now produce existing v3 node and segmented roots through the
node's typed executor, without a ModelSpec or compiler registry. The local SDK path rederives
its exact plan and reuses unchanged node static prosecution/carrier/block ceilings. It streams
one successful complete position at a time, checks native values against declared wire types,
and keeps only position roots unless private capture is explicitly requested. Local hash/trace
caps exclude native buffers, mapped weights and caller retention; activation and economic
rights remain independent chain facts.

The fixed real Qwen2.5 lowered pilot completed 32 positions, committing 245,056 node values.
Native computation plus node hashing/capture took 169.916 s; whole-process maximum RSS was
2,143,010,816 bytes. Its public reproduction bundle is 161,675 bytes, with no private position
values or raw weights. A 17,924-byte existing Decode court proof convicts a substituted output
token, while honest delivery is dismissed. A separate offline test consumes only that public
witness to reproduce the outcomes and refuse copied/tampered openings. Eight relevant tests
and five refusal checks passed.

This establishes actual-weight trace construction and offline terminal delivery-court evidence.
It does not establish registration, public RPC acquisition, full computational integrity,
independent source/task fidelity, original full context, outsider node G14 or Final. Same-node
registration/public claim/prosecution/settlement and the remaining full-scope requirements are
still required. Protocol, commands, measurements, raw evidence and hashes are in the
[RFC02 implementation ledger](../design/palw/tir/rfc0002-implementation.md).


### 14.11 Requested-claim identity and actual-weight node delivery path

An outsider consuming a segmented public record must bind it to the **requested claim id**,
not only the class header and trace roots. The final delivered id is not fed into the trace.
`SegmentedClaimRecordV1::view_for_claim` recomputes the canonical claim id from its job,
producer, all delivered ids and evidence root; it also checks canonical parameter ordering,
prompt authentication, exact output length/vocabulary, context and evidence input binding.
Its header must be anchored in authenticated class/chain state. This local identity check is
not a substitute for chain inclusion or an authenticated RPC state proof.

The actual-weight 32-position Qwen2.5 delivery witness now has a node integration test:
registration data in 32,000-byte ordinary chunks, prompt tiles, salted claim carriers,
production RPC op 210 JSON, outsider proof, block court, reservation slash, honest Final,
coinbase redemption and a second node's replay. Activation validation, parameter attestation
and OPV eligibility are still the parent's explicit test seams. Excluding the eligibility
hook, the class is `NotOnboarded`; the stateful program cannot use the small-stateless complete
check. The separate V2 inventory root is not registered or confused with the kernel root.
These mechanics do not establish model onboarding, public DA acquisition or whole-claim G14.
The full requirement and these gates remain in force.

The segmented bootstrap had a metadata cycle: only OPV can register v4/v5, OPV eligibility
requires kernel binding/conformance, and kernel binding required a registered class. The
conformance-only candidate path in §14.12 breaks this dependency **without granting executable claims,
rewards, Final weight or beacon-source rights** before the existing independent gates pass.
The legacy Panel bootstrap is not an allowed fallback for segmented classes. Sampled
conformance remains a non-reward signal pending its digest/refutation courts; its signal or
a test hook cannot substitute for release eligibility.

Allocation-free v3 leaf counts are now used for court byte pricing. Rows and strided columns
retain exactly their existing leaf coverage, wire sizes and tree-choice tie rule, and the
actual 32-position plan root is unchanged. This eliminates transient index vectors created
merely to count elements during repeated ledger reconstruction. No descriptor, price,
commitment preimage, resource ceiling or activation flag changes. Final test evidence and
remaining full-scope work are recorded in the
[RFC02 implementation ledger](../design/palw/tir/rfc0002-implementation.md).


### 14.12 Conformance-only class preparation

`RegisterConformanceClass` is route version 1, new inner tag **21** of outer tag 110.
It requires both the existing route fence and `palw_panel_free_v1`; shipping fence validation
is unchanged. The preparing signer must be a non-exiting bonded actor. It carries exactly a
known descriptor, canonical program, exact verification plan and parameter commitments. No
model name, `ModelSpec`, frontend vendor or compiler approval participates in this contract.

Preparation calls the same registration validation for active kernel semantics, ranges,
parameter instances, independently attested parameter root, prosecution bounds, court work,
OPV economics and carrier envelopes. It omits only the eligibility prerequisite that would
otherwise depend on the conformance it is being prepared to obtain. A successful candidate
consumes one ordinary adjudication run and its derived admission byte work from the shared
block budget; it cannot spend the public-proof reserve. At most **eight candidates per bond**
can stand. The ordinary wire ceiling still applies. This per-bond catalog bound is not a
proof of the remaining system-wide resource and honest-liveness requirements.

A candidate lives in ledger **table 28**, keyed by its eventual OPV class id, with value
`borsh(preparing bond, ClassRecordV1)`. The root is extended only when that table is nonempty:
`H("misaka-palw/kernel/ledger-conformance-extension/v1"; previous root || collection root)`.
The collection domain is `misaka-palw/kernel/ledger-collection/conformance-classes/v1`.
Older object discriminants, metadata encodings and roots of ledgers with no candidates remain
unchanged. Row reconstruction checks the candidate's key against its canonical OPV identity.
The preparing bond receives no exclusive ownership of the computation or promotion priority.

`KernelBoundV1`, conformance checking and derived eligibility can read the checked candidate
metadata. They still require the same V2 canonical program, live binding over that exact
parameter root, conformance statement, policy, resources and clocks. Execution paths read
only ordinary registered classes: preparation alone opens no job/escrow/claim, pays no reward,
creates no Final, supplies no Final weight and contributes no work-beacon source. Ordinary
`RegisterClassV2` promotes the same identity only after its independent derived eligibility
passes, and consumes the candidate. The candidate cannot make a stateful or large class
eligible for the small-stateless complete check; sampled evidence still does not gate release
rewards pending GAP-70. No production activation is implied.


### 14.13 Bounded v3 artifact-identity refutation

Tag 105 appends `ArtifactMismatchProofV1::TileV3` as proof discriminant **2**.
The old instance-set and row variants retain discriminants 0/1, encoding, judgement and
fold behavior. The new court binds a carried parameter map to the exact bonded kernel root,
authenticates one v3 tile against the named instance, and authenticates the canonical V2
inventory piece against the registered class root. Authenticated dtype/shape differences or
different bytes at common coordinates refute the binding. Rank, dtype, instance, leaf index,
leaf count, canonical piece length and both roots are checked. A copied or disjoint opening
proves no fault. Both row and strided column tiles are supported: a forged column tree must
remain refutable even when its paired row root is truthful.

`ArtifactTileOpeningV3` uses the existing leaf wire bytes, with lengths checked before
allocation: rank ≤ 4, elements ≤ 4,096, path ≤ 64. It does not change the kernel leaf codec.
The inventory material is checked before hashing against its 32 KiB piece and 32-level path
ceilings. This court opens neither a full model tensor nor a whole execution trace.

Only this appended proof spends the shared block court/run budget, before decoding the
stored program or judging either opening. Its work tariff is serialized proof bytes plus
stored canonical program bytes plus 16 times opened element count. A refutation may use the
existing proof reserve. A charged judgement that proves nothing slashes the challenger's
free collateral by `dismissal_fee_v1(work)` and persists that fee and budget as an accepted
dismissal. An over-budget object runs no court and pays no judgement fee. Neither outcome
slashes/defaults the honest binder. A valid proof uses the existing one-time reservation
slash and reporter share. The dormant route fence and shipping validation remain unchanged.

The SDK can stream one V2 inventory opening with a 32 KiB piece buffer, its existing bounded
read-ahead window and logarithmic sibling-subtree frontiers, rather than retaining all
weights or all inventory leaf hashes. The core `tile_refutation_v3` builder checks public
openings through the same pure court. Model acquisition remains conditional; this adds no
consensus model-weight retention or provider obligation. Refutation here requires an authenticated
opening of the **bound** tensor as well as the verifier's true inventory bytes. An arbitrary
opaque false commitment with no public opening is not made refutable by this comparison
alone; that residual binding/prosecution requirement remains open. The generic
`prepare-artifact-tile-court` diagnostic reauthenticates all v3 instances before producing
an honest and a one-element false-binding witness; it consults no model/compiler allowlist.

The predeclared tests and full-scope exclusions are recorded in
[`rfc02-artifact-tile-protocol.json`](../design/palw/tir/evidence/rfc02-artifact-tile-protocol.json).
This identity court cannot substitute for stateful release conformance, full computation
verification, source fidelity, full task/context support or shipping activation. The v5
bridge must still explicitly distinguish artifact parameters from its two job-input roles;
v3 root preparation alone does not resolve that inventory contract.

### 14.14 Descriptor-scoped model inventory and job-input roles

A model artifact binding must authenticate **descriptor identity, complete canonical program,
model inventory root and kernel parameter root together**. The challenger cannot choose the
role contract. K2-TIR-v4 treats all declared params as artifact bytes. K2-TIR-v5 treats its
validated trailing `input.ids` and `input.count` as job inputs, leaving the preceding params
as model bytes. Identical tensor names under v4 do not grant the v5 exclusion. Unknown kernel
semantics cannot copy a memory-model number to gain it; a new implemented descriptor needs
its own explicit contract.

The role scope retains the complete validated program, including its input references. It
must not remove the last two declarations and validate a rewritten graph, read synthetic
job placeholders from the model source, or count job inputs as missing model tensors.
Inventory leaves retain the existing tensor-name/layer/byte-offset hash grammar and
32 KiB piece limit. Their count and index are derived from the descriptor's model instances.
The entire scope belongs to the authenticated statement, even when two scopes share a root.

`PalwTirModelInventoryV2`, bounded streamed model roots/openings and the pure
`verify_artifact_mismatch_v2` judge implement this role foundation for exact current v4/v5
identities. The new judge accepts instance-set proofs and bounded v3 tiles; legacy whole-row
proofs remain in the old judge. The BERT and XLM-R weight-bearing fixture trial tests honest
no-fault, changed/missing/surplus model weights, copied source/kernel roots and rejection of
unknown semantics. It proves mechanics at the fixture's scope, not a full checkpoint task.

**Foundation snapshot (`d5ed40277`): node integration was still required.** §14.15 records
the subsequent consumer implementation. Historical `ArtifactBoundV1` (104) and its challenge
(105) retain their all-parameter inventory and existing wire meaning. They cannot be converted
into v5 statements using a later binding or names inferred from an untrusted proof. A new
versioned, signed and rooted statement must persist the full scope, apply collateral and
shared resource budgets, and expose only a matching matured attestation before a v5 candidate
can pass through the ordinary node. The new pure APIs do not supply that statement, activate
an encoder, establish release conformance, resolve opaque-root withholding, or prove RFC02
completion. Large/stateful conformance, full-task public G14 and the other §II.14 requirements
remain mandatory.

### 14.15 Signed model artifact statements in the node consumer

The new route inner kinds **22 `BindModelArtifactV2`, 23 `RefuteModelArtifactV2` and
24 `RegisterModelConformanceClassV2`** ride signed outer 110 and require both its
probabilistic-constraints fence and the dormant PanelFree fence. The central allocation
and exhaustive inner fence table name all three. The bare kernel ledger refuses them:
only the node consumer can authenticate chain collateral and the stored scope.

A signed statement commits the exact current v4/v5 descriptor, complete canonical program,
model inventory root and parameter map. Its content id binds descriptor, program digest
and both roots. Aux **46** stores the immutable statement/liability record, **47** its bounded
bond index, and **48** the admitted candidate's chosen statement. Tables 43–45 belong to
the provider court; the earlier model allocation overlapped them and is corrected before
shipping activation. Table 42 remains reserved
for the existing chunk lane. Each bond can retain eight statements, including decided
records. Identical content is reusable by any candidate registrant; the binder's identity
owns liability and grants no execution or reward priority. The reservation is the existing
100-BILI binding amount and uses the existing challenge/liability horizons.

The fixed-size stored header suffices for reservation, deadline and work reads. Per-bond
committed collateral and both live-duty withdrawal gates count the reservation until the
stored liability horizon or refutation. Release is a clocked read, requiring no new global
per-block scan of model programs. Binding and refutation spend the same blue-score block
budget as other admissions/courts; admissions cannot spend the prosecution reserve. The
metadata work tariff is `p² + 64p + 64b`, with `p` canonical program bytes and `b` map/filing
bytes. It is a conservative structural envelope, not execution work or economic credit.
A charged invalid proof pays the policy's dismissal fee; an over-budget proof is not judged.
The public decoder checks PC cardinality, ordering, tile bounds, inventory name/piece/path
counts and trailing bytes before any corresponding allocation. Legacy whole-row proofs
are not admitted here. Valid fraud slashes the statement reservation once under the existing
49% challenger share; self-operator bounty collection is refused.

A matured statement attests only the exact descriptor/program/PC tuple carried by inner 24.
The consumer delegates the ordinary conformance-only validation, including ranges, plan,
prosecution and carrier bounds, and records its chosen statement. Its temporary PC
attestation is restored before ledger rows are persisted: it never enters the global
attested-root list and cannot be borrowed by an unrelated class. This creates metadata,
not an execution registration. Historical 104/105 and their inventories are unchanged.

The node mechanics trial uses a lowered weight-bearing BERT fixture and ordinary signed
carriers, with independent replay. The companion SDK capture also covers the XLM-R fixture.
This is not a published full-checkpoint task/context support PASS. Generic scoped release
conformance, full computation G14, the arbitrary opaque/withheld bound-root case, the complete
resource/economic/liveness contract and shipping activation remain open under §II.14.

### 14.16 Descriptor-scoped finite-domain conformance reference

`ModelConformanceDomainV2` derives a finite input domain from the complete validated
program and verification plan, using the exact current v4/v5 descriptor. For v4 it
includes every nonempty token word of lengths `1..=plan.max_positions`; for v5 it
includes every word of lengths `1..=L`, with the encoder's canonical ids padding and
count injected as job inputs. Stateful decoder cases start from the reference's initial
state independently and replay the complete prefix. Repeating one token does not cover
this domain. Stateless programs use the same domain without a dependency-based shortcut.

Before model tensor decoding or execution, the constructor caps input cases, model leaves,
raw model bytes, a conservative reference RAM envelope, and reference work. The envelope
includes all retained node values at worst-case H, declared states and constants, decoded
model parameters, job inputs, operand clones and primitive scratch. These are local
reference limits, not a change to network admission limits or proof that the full shared
resource vector is complete. The constructor also checks the plan's program binding and
ranges. Callers cannot supply a smaller input count or work estimate.

The reference validates every inventory coordinate, re-roots the exact source bytes,
recomputes the v3 parameter commitments from those same bytes, and hashes every node's
shape, dtype and integer values for every input case, including stage inputs and state
writes. The result binds descriptor, complete program, plan, source and PC roots, case
count and input order. Comparing claimed implementation roots proves equality with this
reference result; it does not establish the identity or independence of the implementations
that supplied those roots, or fidelity to a source floating-point checkpoint.

At the `f7f93d0d3` reference snapshot this was a pure dependency without a node consumer.
The authenticated consumer is specified in §14.17 below. Large
vocabularies/context domains exceed exhaustive enumeration; they still require the scalable
GAP-70 digest/refutation path. No input subset, sampled signal or raised limit substitutes
for that requirement, and no shipping fence is armed here.


### 14.17 Authenticated finite-domain conformance and direct execution registration

Inner **25 `CompleteModelConformanceV2`**, carried by authenticated outer 110, requires
both probabilistic-constraints and PanelFree fences. It names a scoped candidate and a
matured model statement. Any active bond may submit the complete source inventory and
three claimed implementation roots; neither the binder nor the first registrant receives
priority. The consumer checks the exact descriptor/program/plan/source/PC relation and
every input in §14.16's bounded domain before writing a fixed-size conformance row in aux
**49**. Aux **50** counts judged checks per blue-score block, with a maximum of two.

Before decoding the stored program or proof, a judged attempt reserves shared admission
work equal to `p² + 64p + 64b + 2^26`, checks the actor's free collateral, and charges the
actor's dismissal fee on success or failure. Proof bytes, operand counts, names and piece
lengths are bounded before allocation. Invalid attempts create no conformance record and
do not slash the model binder. An already checked class is not rerun. A successful check
selects its proved statement in aux 48, so an earlier candidate with a false declared source
root cannot permanently poison the class.

Ordinary inner 13 `RegisterClassV2` may then derive OPV eligibility from that exact checked
scope. Admission rechecks descriptor standing, denial, binding standing, plan prosecution
bounds, carrier fit, court work and economics, and the complete-check policy. Temporary PC
attestation is removed before persistence. This path introduces no model-name or compiler
allowlist, V2 decoder identity, persistent global attestation, or new payout. A candidate
alone is not an execution registration or beacon source.

This consumer certifies the bounded integer function and the source-to-PC relation. Claimed
role roots do not certify independent runtime implementations or source checkpoint fidelity.
Large vocabularies/context remain outside exhaustive enumeration and need GAP-70. The full
shared resource/liveness contract, real-checkpoint task/context coverage and the remaining
§II.14 requirements stay open. Shipping fences remain dormant.


### 14.18 Public trace courts for unregistered scoped candidates

A new versioned, non-reward statement uses inner **26 `PostModelVectorV2`** and
**27 `RefuteModelVectorV2`** under authenticated outer 110 and dormant PanelFree.
An active bond may publish a vector of an admitted scoped candidate without creating
an execution class, job or kernel claim. It need not obtain a preceding Final. The
statement binds the exact candidate and model binding, the public prompt, exact delivery
length and delivered ids, network/ruleset, program/plan/PC identity, segmented evidence
and segment roots. For a decoder, the last delivered token is not fed back as input.

The three claimed implementation roots must agree with this explicit typed trace grammar.
It commits intermediate values and logits through the existing v3/segmented trees, so a
shared wrong computation is subject to the existing bounded element/type/decode courts.
A public verifier with the matching model reconstructs this context and supplies a fault
against its roots. A proof cannot be borrowed by another vector, source binding, program
or plan. This is a new statement, not a reinterpretation of legacy tag-109 `a`/`b` flat
logit/commit digests. Equality of role roots still does not establish actual independent
software execution or source-checkpoint fidelity.

Aux **51** stores a fixed reservation/court header followed by bounded post bytes; **52**
is the poster's lifetime catalog, capped at eight statements. A new distinct assertion
reserves 100 BILI of the poster's own free capital for the existing 200-DAA liability
horizon. Both withdrawal duty gates and ordinary committed/free-capital calculations read
this reservation together with all other commitments. Expiry is a clocked read and does
not erase the catalog or scan all vectors per block. The model binder owns no liability
for another bond's vector. Identical content shares a statement and grants no priority.

Posting and refuting reserve the existing shared block work before program/post/proof
decoding. Every judged post, including a truthful duplicate, pays the actor's policy fee.
An invalid judged refutation also pays the actor's scaled fee; an over-budget filing is
not judged or charged. The fixed header prices the worst admitted court plus program/wire
work; admission requires this whole envelope to fit the work reserved for prosecution.
Nested counts, v3 leaf sizes and paths are bounded before allocation. §14.19 adds bounded
WholeValue optional tensors within the candidate's already admitted filing/work envelope.
A valid fault slashes the poster's reservation once and pays only the existing 49% share
of the collected slash; self-operator bounties are refused.

This path offers falsifiable integer trace assertions for domains too large to enumerate.
It is **not** complete-domain conformance, an OPV eligibility source, or a sampled reward
gate. §14.19 supplies public point-unit trace demand/default. Vector discovery/transport
tooling, immutable policy selection and its whole-statement soundness, legacy flat-digest courts and independent
runtime certification remain required before integrating it into reward eligibility.
Opaque/withheld source-PC relation cases and every other §II.14 requirement remain open.
Shipping activation is unchanged.


### 14.19 Candidate trace unit availability and verifier-owned whole-value courts

Inner **28 `DemandModelVectorV2`**, **29 `AnswerModelVectorV2`**, and **30
`SettleModelVectorDemandV2`** use the same signed, dormant PanelFree consumer. A demand
names the exact statement and `(position, occurrence, node, axis, line, tile)`: row/column
tiles (axis 0/1), or node commitment and Merkle paths only (axis 2, zero line/tile). No
parameter, model file or inventory range can be requested. The candidate commitment-only
mask (§14.20) is authoritative for this new statement; a value marked withheld owes only its node opening. The v4/v5 claim
disclosure mask remains unchanged.
The Level-1 model-byte mask also forbids requesting a copied or model-only tensor even
when its WholeValue envelope is too large for the existing disclosure mask.
Where a bounded court exists (§14.20), its tensor is supplied by the verifier's
own model under that candidate court.
Conditional model acquisition remains outside consensus.

A requester owns four reusable slots, backed by its free collateral together with all
other commitments and both withdrawal duty gates. Other bonds cannot occupy its slots.
A replaced settled slot deletes its old demand row; answers/closing calls bind the new
request id, including vector, unit, requester, slot and filed DAA. Demands decode and
validate the stored program/trace only after reserving shared admission work and charging
the actor's fee. The fixed request retains its admitted node index/count, positions and
containing segment root; response classification does not decode the program or trace.

The policy's court deadline plus proof grace must fit the vector's liability horizon. An
answer is timely through its deadline; a default is closable strictly after it. Pending
requests keep the poster's reservation held even after that horizon, until explicitly
closed. Aux **53** holds requests, **54** their bond/slot indices, **55** authenticated
public-unit receipts, and **56** the outstanding count per vector. No periodic scan over
all vectors/requests is added. Reservation reads visit at most eight vectors or four
request slots per bond. Any active bond may close a request; a default bounty goes to the
requester's recorded payout, not the closer. A poster's own operator cannot demand it.

Answers have an 80 KiB ceiling, two bounded paths and at most one existing 4096-element
v3 tile. Counts, type/rank and paths are checked before allocation. Like the existing
segmented response lane, this bounded Merkle/byte classification uses no shared court
adjudication run; exhausting proof runs cannot by itself prevent a valid answer. Invalid
answers pay their actor's scaled fee. A timely authenticated answer is public thereafter;
its collected requester deposit compensates the poster once per admitted request. The
deposit is at least the policy demand bond and the fee floor of the maximum bounded
answer. Other pending requests for that same unit close from its public receipt, subject
to their own original deadline. No new demand is admitted for an already public unit.
This local fee floor is not a measurement of complete network/producer economics.

An unserved request's explicit close slashes the poster's remaining vector reservation
once, sets **unavailable**, refunds pending requester reservations, and pays only the
existing 49% collected-slash bounty. Availability failure is distinct from a proven
integer fault (**refuted**); either outcome prevents a second slash. A timely service
and later integer conviction remain separate operations. Closed/late requests are
refused before classification and no mutable deadline extension is allowed.

The existing WholeValue proof variant is admitted with bounded node/leaf paths, input
counts and optional whole tensors. Rank, dtype, checked dimension product and exact byte
length are verified before allocating tensor bytes. Both wire and stored trace bytes
join the program/court work envelope; the candidate's derived prosecution bounds and
reserved proof-work/carrier limits still apply. This allows a verifier to reconstruct
a falsifiable withheld-node relation from public openings and its own model, without
requiring that model's weights from the poster. It does not certify independent runtime
implementations or complete-domain conformance.

These routes remain non-reward conformance signals and grant no execution eligibility.
Legacy flat-vector courts, immutable whole-statement policy/soundness, actual checkpoint
fidelity and task/context/feature coverage, discovery/transport tooling and the complete
network resource/liveness/economic contract remain required. Opaque source-PC fidelity
relations and large model-only trace relations outside the bounded candidate courts
remain open; §14.20 extends the parameter-Gather case without forced weight disclosure.
All other §II.14 requirements remain open. Shipping fences stay dormant.


### 14.20 Candidate Gather dependency courts without a full weight opening

Candidate statements (inner 26–30) use `model_vector_withheld_mask_v2`,
`check_model_vector_positions_v2` and `verify_model_vector_fault_v2` together.
The existing v4/v5 program arithmetic, plan, trace commitments, claim checker/court,
`seg_withheld_mask_v1` and reward eligibility retain their meaning. These non-reward
statements do not change the disclosure contract of an execution claim.

For `Gather(axis=0,batch_dims=0)` whose data operand is a registered model parameter,
the candidate whole-value court price includes the row leaves covering at most the
number of selected items. It includes each selected item's full trailing dimensions,
all row tiles and each leaf's full Merkle depth. For rank-one data, each scattered
index may touch a distinct 4096-element tile. Repeated indices never increase this
worst bound beyond the parameter's complete row tree. The independent index operand,
node paths, reference element evaluation and both output commitment hashes retain
full prices. Other axes, batch dimensions, primitives and committed data operands
retain the established conservative whole-value price.

A model-dependent node is commitment-only for this statement when its whole-value
opening and work fit the existing one-MiB and 2^36 ceilings, or when the frozen
v4/v5 mask already withholds it. Admission takes the maximum of the established
class bounds and these additional candidate court bounds before checking the shared
reserved proof work and actual carrier. Refutation must fit the stored admission
header and its own node's dependency opening bound. An unnecessarily large filing
cannot borrow another node's larger byte envelope. These bounds are derived, never
supplied by the poster.

The verifier acquires the matching model outside consensus and re-executes. At the
first divergent bounded Gather, it files only the output's public authenticated node
opening, the authenticated selected parameter leaves from its own model, and the
index operand. The court recomputes every output element and the v3 commitment;
it need not receive the poster's Gather tensor or the full weight file. Bad parameter
bytes or a borrowed commitment dismiss at the challenger's cost. The same request
lane refuses copied-model tensor tiles and serves the node commitment only.

This closes the bounded parameter-Gather dependency case, not all large model-only
relations. A whole output beyond these limits, another axis, a large committed data source,
opaque source-PC fidelity or a relation outside these ceilings still needs a separate
bounded court. No sampled security/complete-domain conformance, actual checkpoint
support, independent runtime identity or reward eligibility follows. Every remaining
§II.14 completion requirement and the dormant shipping fences remain in force.


### 14.21 Staged flat-v4 commitment material for large withheld values

`misaka-palw-kernel::merkle4` implements the flat hiding-width layout proposed in
`k2-real-scale.md` §4.2 as a **new hash and wire grammar**, not a v3 leaf-rule
replacement. This stage provides commitment construction, public hash-only
openings, filer-owned value openings, bounded root descent and material resource
bounds. No descriptor, class, candidate statement, route object, reward source
or shipping fence selects it. A commitment helper is not a terminal court or a
completed large-model prosecution path.

The canonical layout flattens the row-major tensor across rank/line boundaries.
Let `N` be its checked element count. For `N >= 64`, it has `floor(N/64)` leaves:
all but the last contain 64 elements; the last contains 64 through 127, including
the entire ragged tail. A 65-element tensor has one 65-element leaf; a 129-element
tensor has one 64-element leaf and one 65-element leaf. No padding, short tail
hash or interior hash of that short tail is published. Tensors below 64 elements
have no flat-v4 leaf contract and still need a bounded whole-value alternative.
Rank is at most four; zero dimensions, overflow and non-committable dtypes are
refused. The primitive arithmetic and the existing `I64`/`I128` commit prohibition
are unchanged.

The flat leaf commits its dtype, flat leaf index, exact count and raw-width
little-endian elements under the new flat-v4 leaf domain. A binary tree carries
an odd final node upward; separate flat-v4 node and typed-tensor domains bind
both tree structure and dtype/rank/dimensions. A hash opening carries bounded
metadata, one leaf digest and its exact path; it contains no elements. A value
opening additionally carries exactly the declared span's bytes, at most 508
bytes for the existing committable dtypes. Both codecs check rank/count/path and
carrier limits before allocating variable fields, and refuse surplus bytes.

A model holder authenticates each public reply against the committed typed
value before comparing it with its own tree. A differing leaf is terminal
material for a future relation court. Otherwise, the first differing bottom-up
sibling identifies a strictly smaller divergent branch, including odd carried
nodes. At most `ceil(log2(leaves)) + 1` replies identify a divergent leaf. A
cached tree reads paths in logarithmic time; it does not copy/hash the whole
tree on every probe. The root-only raw-width builder retains a fixed stack
with a conservative 8 KiB scratch bound and does not expand bytes into an i128
tensor. Optional retained trees expose their derived live digest/vector bounds
and can refuse a caller's retention limit before hashing or tree allocation.

The 64-element rule supplies a minimum encoded width; it does **not** prove
entropy, cryptographic privacy of predictable values, or cumulative disclosure
safety. No ordinary participant is required to acquire the model through
consensus. Before selecting this format, the full profile must also bind its
masked nodes and source commitments, implement the union of each leaf's
primitive dependency lines and terminal court, derive court/RAM/work/retention
and aggregate budgets, connect authenticated DA/default and verifier descent,
and pass fresh actual-node prosecution/Final trials. It cannot inherit reward
eligibility from the existing v4/v5 plans. Existing commitments, plans, claims,
candidate v2 statements and every §II.14 completion requirement remain in force.

### 14.22 Staged flat-profile dependency-leaf terminal court

`misaka-palw-kernel::flat_court4` adds a **separate, explicit profile context**
for a terminal relation court over the §14.21 material. Its profile ID must be
bound by a future consumer's typed statement, alongside the program, parameter
commitments, job input, extents and segmented evidence roots. No existing
execution descriptor, candidate-v2 statement, route discriminant, class,
reward or shipping fence selects this context. Passing this component's tests
cannot establish node prosecution, Final/redemption, complete-domain security
or real-checkpoint support.

Under this staged profile, a committable node value with at least 64 elements
uses flat-v4. Other node values retain v3, including small and wide intermediate
values; registered parameters retain their existing v3 commitments. This is an
explicit mixed grammar, not reinterpretation of a shape in an existing claim.
Non-committable values are not thereby legal commit points. The existing TIR
primitive set, integer arithmetic, program validation and state wiring are
unchanged. The profile ID and fault version are checked independently of the
untrusted filing.

A filing contains the output's authenticated node opening and **one hash-only
flat leaf opening**, plus a sorted, duplicate-free union of operand value
leaves. It contains no producer output values. The court authenticates the
output coordinate against its segment, resolves each source from validated
program wiring, and authenticates every filed operand against that exact
source. Carry-in names the preceding occurrence's carry-out; fixed state names
the preceding position's writer, or zeros at initialization; history names the
preceding position's window and the current row. Crossing a 1024-position
segment boundary does not permit a replacement state or window. A parameter
leaf names its declared parameter and layer instance. Public tokens, positions,
constants and encoder job inputs come from their bound job/program context.
Borrowed coordinates, substituted weights/routing, missing dependencies and
malformed material dismiss rather than convict the output.

The court calls the frozen `element_value_v1` for every element of the declared
64..127-element span, hashes the resulting raw-width bytes using the flat leaf
preimage and compares that digest. A different digest, or authenticated operands
for which the reference semantics refuse, proves this leaf relation false. A
matching digest is `NoFault`. The model holder's dependency recorder calls the
same evaluator over its own operand tensors and deduplicates the actual leaf
union. The court reads sorted proof leaves through cached layouts and binary
search; it does not build a full tensor, a per-element map or an operand tree.

The staged per-leaf admission derives maximum dependency reads, leaf counts,
full paths, raw-width carriers, reference line/sort scratch, hash/lookup work,
and bounded program/wiring work. Identity-coordinate relations use a contiguous
flat-span bound. Strided/Gather/MatMul/reduction bounds conservatively cap the
union by both dependency reads and the source's leaf count, not by opening an
entire source unconditionally. Every ragged output tail is priced at its actual
count, up to 127. A relation exceeding one MiB, 2^30 abstract work units, 32 MiB
scratch or 1024 operand leaves is refused before reference evaluation. These
are component bounds, not measured peak RSS/time or network-wide admission;
a consumer still needs worst bounds across all positions/leaves and shared
per-block/per-bond/network accounting before accepting this profile.

The strict fault decoder caps all vector counts before allocation: rank four,
64 node/hash siblings, ten position/prompt siblings, nine operands, 1024 total
operand leaves, 4096 values per legacy row leaf and 4096 prompt IDs. It checks
exact value spans, known dtype/version/option tags and end of input. The
in-memory verifier enforces the same carrier/shape/count ceilings and each
relation's derived opening limit. Legacy row leaves are filer-owned proof
material; no public DA service of them is introduced. Root-only hashing of an
already resident tensor uses fixed scratch and avoids retaining another tree.

Still required: typed node admission/statement binding, public hash-unit
DA/default/session accounting and deadlines, complete-profile malformed/decode
and small/wide-node courts, acquisition/localization from actual chain carriers,
fresh model-holder prosecution with independent node replay and Final/redemption,
measured verifier resources and honest liveness under aggregate invalid filings.
Real checkpoint/task/context/fidelity, arithmetic/backend conformance, whole
statement security and all other §II.14 requirements also remain open. This
stage implements the dependency-leaf relation component; it does not activate
or declare completion of the large-model path.

### 14.23 Staged all-dtype internal flat-v5 material and fault kinds

`misaka-palw-kernel::merkle5` and `flat_court5` add a separate, explicitly
selected internal evidence profile. Every node value with at least 64 elements,
including I64/I128 intermediates, uses the new flat-v5 hash namespace with
64..127-element leaves. Smaller node values and registered parameters retain
v3. This closes the component gap where a first wrong wide intermediate could
not use the flat leaf relation court. It does not make wide values legal TIR
commit points: the existing program validation and all 25 integer primitive
semantics remain unchanged. Flat-v4 domains, bytes and public APIs retain their
previous meaning through version-specific aliases of shared implementation.

The explicit v5 fault envelope dispatches four terminal court kinds:

- **Leaf:** recompute a hash-only output leaf from authenticated operand leaves,
  including wide internal operands, using the frozen reference evaluator.
- **Whole:** recompute every element of a sub-64 node and compare its typed v3
  commitment. Producer output values are not required.
- **Malformed:** authenticate the typed header preimage and convict a mismatch
  in dtype, shape or profile grammar. Rank/count caps apply before allocation;
  overflow and zero-dimension metadata can be authenticated without constructing
  the claimed tensor. Unbound headers dismiss.
- **Decode:** authenticate logits at the position selecting the delivered token,
  then compare a rival with at most two filer-owned leaves. Equal logits select
  the lower index. An out-of-range delivered index is convicted from the bound
  node coordinate and declared length, with no value leaves required.

The profile identifier binds this grammar; the envelope has version 5 and a
strict fault-kind discriminant. Unknown versions/tags, truncation, surplus
bytes and oversized nested counts are refused. Source authentication,
validated state/history wiring and bounded dependency recording are shared
with §14.22. The per-filing limits remain one MiB, 2^30 abstract work units,
32 MiB scratch and 1024 operand leaves. Derived limits are checked before
reference evaluation. These are component bounds, not measured network or
worst-job resource guarantees.

Synthetic kernel tests cover all 25 primitive samples and merged tail leaves,
first wrong wide intermediates, small values of all six dtypes and scalar rank,
header type/shape/overflow/grammar mismatches, decode position and tie rules,
and bounded codecs. Independent material oracles cover all six dtypes,
extreme I64/I128 values, root-only hashing and logarithmic divergent-leaf
localization. No descriptor, candidate, class or shipping node route selects
this profile. These tests do not establish real checkpoint support, privacy
entropy, actual-node prosecution, Final/redemption or full RFC02 completion.

Still required: worst-position/leaf admission for the entire profile, typed
node statement binding, public hash-unit DA/default/session budgets and
deadlines, shared aggregate resource accounting, public-chain acquisition,
fresh model-holder prosecution and independent Final/redemption. The original
§II.14 checkpoint/task/context/fidelity, conformance, economic and honest
liveness requirements remain open. Shipping fences stay dormant.

### 14.24 Staged flat-v5 all-position terminal-court resource admission

`misaka-palw-kernel::flat_scope5::flat_resource_scope_v5` derives a canonical
resource declaration from the validated program, maximum position count and
optional exact encoder binding. `check_flat_resource_scope_v5` independently
re-derives it and rejects any difference, including omitted relations, smaller
costs, altered occurrence counts, profile/program/extent substitution or a
changed job mode. The declaration has its own v5 root domain. There is no model
name, frontend identity or operator allowlist input.

The derivation validates wiring once, prices one representative per reachable
block node and counts every layer occurrence. The same shared price function
prices individual §14.23 filings and the registration envelope. No position
array, parameter tensor, output tensor or Merkle tree is constructed; program
serialization size is measured once and reused across relations. v1 permits
at most one H per tensor, and H is `min(position + 1, window)`. The maximum
resolved shape bounds every contraction/reduction/sort line, tree depth and
source size, but is **not sufficient alone** for the commitment grammar:

- Every large output span is conservatively priced at 127 elements, including
  an earlier merged tail when the final shape has only 64-element leaves.
- A source node that can cross 64 elements is priced for both flat-v5 and its
  largest sub-64 v3 shape. The envelope retains the larger leaf count, carrier
  and scratch bound; flat contiguous-span optimizations cannot discard the
  earlier v3 row openings.
- Initialization requires fewer sources than later positions. The maximum
  position includes the previous fixed-state writer and HistAppend window
  whenever either can occur in the admitted extent. The same symbolic block
  types and fixed proof depths apply to every layer instance.
- Constants and public inputs need no Merkle leaves, but still pay reference
  contraction/reduction/sort work and scratch. The previous staged flat price
  omitted those costs when skipping leaf authentication; both filing and scope
  prices now include them. This correction activates no shipping profile.

Every reachable relation must fit the existing one-MiB, 2^30 abstract-work,
32-MiB scratch and 1024-operand-leaf caps, including the v5 envelope bytes.
Malformed-header and decode costs join the maximum court vector. Logits have
no H under v1, so decode pricing is invariant across positions. The declaration
also records relation instances, maximum raw trace bytes, node commitment
bytes, flat-tree bytes per position and flat hashing input bytes per claim.
These are conservative independent maxima. They are neither a promise to
serve clear model values nor a requirement to retain every position's full
tree simultaneously. They are not yet the complete execution/checker/DA/network
resource vector.

An exhaustive small-program price oracle enumerates every position and leaf
for all 25 primitive samples and growing/sliding histories with differing row
sizes; every individual price fits the derived scope. Tests include earlier
63-row v3 paths and 127-element tails, wide intermediate histories, exact
encoder binding, 1,024 per-layer state instances, changed declarations and a
2^21-position extent with a 2^24-entry external parameter table, without passing
parameter images or position arrays to admission. Constant TopK beyond the
court work cap is refused by both admission and the exact filing guard before
reference sorting. Actual synthetic courts also cross 63→64→65 elements and
a sliding window, convict false relations and dismiss missing/borrowed sources.

This closes the staged **terminal-court resource preflight component**. A
shipping consumer still must bind and check this exact scope in typed class/job
statements, combine it with execution/checker/DA and aggregate budgets, and
implement bounded public material/default/session acquisition. Actual-node
fresh prosecution and independent Final/redemption, measured costs, real
checkpoint/task/context/fidelity, privacy, economic and liveness requirements
remain open. No shipping descriptor/class/route or fence selects flat-v5, and
this declaration does not confer reward eligibility or full RFC02 completion.

### 14.25 Dormant actual-node flat-v5 candidate statements and courts

The consumer now has explicit `PostFlatModelVectorV3` and
`RefuteFlatModelVectorV3` route kinds, inner 31/32, owned by the existing
`palw_panel_free_v1` fence beneath the kernel-route fence. Shipping activation
parameters remain unchanged. These are non-reward candidate trace statements,
not execution claims or full conformance certificates.

The outer v3 statement binds the flat-v5 profile and the independently derived
§14.24 scope root to the descriptor-scoped class, model binding, program, PC,
job inputs, generation and segmented commitments. Its nested typed job/evidence
carrier retains the frozen v2 grammar; the new wrapper, trace/statement domains
and route kinds select the new interpretation explicitly. Existing v2 vector
commitments and wire encodings keep their meaning. Aux tables 57/58 store the
new statements and bounded bond catalog separately from v2 tables.

Admission derives the scope over the candidate's full admitted maximum extent,
not merely the shorter posted trace, and persists exact filing/work/scratch
ceilings. Every court rebuilds the typed context and scope and requires equality
with the stored ceilings. Cached fixed-size program/PC/body lengths price and
reserve the shared block budget before variable stored program, PC, post or
fault decoding. The PC-map tariff includes every admitted parameter instance.
Worst-case court admission must fit the existing guaranteed court budget and
one-MiB proof carrier. Invalid declarations, duplicate admissible posts and
invalid filings pay the actor's fee; exhausted block budgets stop further work.

The v2 and v3 catalogs share the same eight-statement limit per bond. Both
reserve the same original collateral through the existing global commitment
and exit-duty accounting. Adding a profile does not add capital or court
capacity. A successful bounded court slashes the statement poster once and
pays the existing challenger share through ordinary payout/redemption; the
poster's operator cannot collect that bounty. Invalid filings cannot refute
an honest statement or slash its model binder.

Actual-node synthetic trials cover the typed decoder and encoder routes,
large leaf and small whole relation convictions, borrowed proofs, forged
profile/scope/program/PC/role bindings, duplicate accounting, invalid-proof
block budgets, mixed v2/v3 catalogs and independent replay/redemption. The
filer reconstructs operands from its own model copy and authenticated public
job input and receives only commitment/hash openings for the producer output.
In these trials a test helper supplies those public hash openings; it is not a
node public-acquisition protocol. No execution Final is claimed by these tests.

Public flat hash-unit acquisition, localization, retention, default/session
rules and proof pre-emption seals remain open. Candidate admission still uses
the existing candidate plan, so this does not admit every large shape allowed
by the staged terminal-scope component. Full execution/checker/DA/network
resource accounting, fresh outsider acquisition through actual node APIs,
execution Final/redemption, real checkpoint/task/context/fidelity, privacy,
economics and honest liveness requirements remain open. The full RFC02 goal
remains active, and no shipping fence is armed by this increment.

### 14.26 Dormant flat-v5 public hash-unit demand, service and default

Inner kinds 33/34/35 add `DemandFlatModelVectorV3`,
`AnswerFlatModelVectorV3` and `SettleFlatModelVectorDemandV3`, under the existing
route/PanelFree fences. Aux tables 59–63 store fixed requests, requester slots,
public responses, open-request counts and unavailability. Shipping presets and
the existing v2/v3 statement encodings are unchanged.

A request identifies a committed position/occurrence/node and optionally a
flat leaf index. Its grammar has no model-file, parameter, row/column or clear
value request. Admission reserves structural work before reconstructing the
stored statement, independently checks its scope and binds the fixed request
to the exact node index/count, segment root, extent, declared dtype and resolved
shape. Small nodes allow only node commitments; large nodes additionally allow
hash leaves of 64–127 elements. A response binds the two node/position paths
and, where requested, the flat-v5 hash path. The explicit answer version and
strict ten-KiB carrier reject old answer grammars, unbounded nested counts,
wrong units/shapes, copied roots, surplus bytes and truncation.

Each requester owns four slots **shared with v2**, and each flat vector permits
at most 32 simultaneously open requests. Open requests reserve the requester's
own collateral. Their service deposit covers the maximum bounded-answer fee
floor and is paid to the statement poster on authenticated service. Published
answer bytes and their digest can be read through the node's native route read
API even after the requester recycles its slot; a fresh verifier independently
authenticates them and uses its own model copy for values and operands. The
response fold reads only fixed request metadata and bounded hash paths; it
decodes no stored program, parameters, trace or clear values. As in v2, these
bounded responses use payload carriage rather than public adjudication slots,
so spending the court count does not prevent service.

A request must leave the existing response deadline and proof grace inside the
statement's liability horizon. An unresolved request keeps the poster's
reservation committed after that horizon. An explicit bounded close accepts
timely public service, or marks the statement **unavailable**, slashes its
remaining reservation once and pays the authenticated requester. A copying
closer cannot take that bounty. Later service cannot erase an earlier request's
missed deadline. Availability default is separate from integer conviction.
The original statement row remains immutable on default; the auxiliary status
is authoritative for refutation, demand and reservation accounting.

The actual-node synthetic trial reads hash openings from persisted public node
state, localizes a late false leaf through bounded adaptive probes, reconstructs
its operands from an independent model copy and files a successful court. An
independent replay node reproduces public replies and ordinary challenger payout
redemption. Additional trials exercise shared v2/v3 slots, invalid replies,
responses after a full court count, slot recycling, held liability and default.
These are native read-API trials, not a deployed RPC/transport drill or real
checkpoint/fidelity acceptance. General first-fault verification and streamed
localization across all relations, proof pre-emption seals, public retention/
pruning, the complete shared resource vector and aggregate DA/network load,
execution Final, privacy/economics and honest liveness remain open. No shipping
fence is activated; full RFC02 completion is still unproven.


### §14.27 — Generic streamed flat-v5 detection (dormant component, 2026-10-11)

`flat_detect5::check_flat_claim_v5` consumes the authenticated public job, an
independently acquired model checked against registered v3 parameter commitments,
and a public provider exposing only node commitments and flat hash paths. It
uses the frozen streaming integer evaluator, visits positions/occurrences/nodes
in order and authenticates each node path against the statement's segment roots.
`Clean` requires exact agreement at every node and every delivered greedy id; it
is not a sampled security receipt or an execution Final.

The first divergent large value is localized with at most the layout's derived
`localization_replies` hash probes. A small value uses the existing sub-64 whole
relation. The verifier records the dependency union, opens only its own values,
authenticates earlier-node sources and registered weights, and constructs the
existing bounded flat-v5 filing. This covers common primitive wiring, carry,
initial zero states, previous state writes, previous history windows, constants,
public position/token ids, and encoder job ids/padding/count. Decode uses its own
logits and at most two value leaves, including the lowest-index tie rule and
out-of-logits ids. Every emitted filing survives the strict wire roundtrip and
the same terminal court the node uses. No new primitive or statement grammar is
introduced.

Missing or borrowed paths and invalid hash metadata yield an exact point DA
request, never a clean verdict. A malformed committed tensor for which the
producer cannot serve the expected typed hash path still needs the existing
DA service/default process; this detector does not invent a malformed-header
conviction. Wrong/missing acquired weights, an inconsistent job or failed
reference evaluation are reported as inconsistent, not as producer guilt.

The detector retains current/previous position values, with an extra previous
position copy alongside the existing replay engine, and the replay engine's
bounded history rows. It does not retain all positions. It still hashes all
reference values, reads all node paths in a clean scan and builds full own
Merkle trees for filing operands. A retry after a DA request replays the prefix;
caching public responses does not remove that execution cost. Consequently this
component does **not** prove real-size practicality, bounded whole-job delivery,
shared verifier/resource accounting, or completion before the liability horizon.
Those requirements remain mandatory before practical or reward acceptance.

Synthetic tests cover all 25 primitives, state/history across positions and
generated-token feedback, small and I128 intermediate values, encoder inputs,
decode ties/out-of-logits ids, bad acquisition and public-path withholding or
substitution. The actual-node late-leaf trial now drives this generic detector
from persisted public answer bytes through point requests, a court, challenger
payout redemption and independent replay. Native evidence remains a synthetic
Gather case; it is not all-feature real-node or real-checkpoint acceptance. RPC
transport/retention, proof pre-emption seals, aggregate load/honest liveness,
execution Final, checkpoint fidelity/complete tasks, A6/A8 and economics remain
open. The shipping fences stay dormant; RFC02 completion is not established.


### §14.28 — Versioned local replay budgets over the frozen flat scope (2026-10-11)

`flat_replay6::FlatReplayEnvelopeV6` is a new, read-only resource projection over
the independently checked flat-v5 scope. Its new v6 domain binds the unchanged
v5 scope root. No existing v3 statement, v5 resource serialization/root, court
profile, route discriminant or shipping fence is reinterpreted. The native
`flat_model_vector_replay_envelope_v6` read API derives it from the authenticated
stored candidate view; the local verifier independently rederives all fields.

The registered-model replay adapter checks acquired dtype, shape and element
count against the program declaration before canonical-value scanning or full
commitment hashing, even if a substituted tensor has the supplied parameter
root. The acquisition provider must separately cap its own allocation/transport
before constructing and returning a Tensor.

The projection reports reference tensor **payload**, separately from artifact
storage: every `Tensor.data` value is an i128 even for i8 storage. It derives
maximum position payload, largest operand payload and retained history-row
payload from bounded shapes and actual layer occurrences, without allocating
weights, tensors, trees or position arrays. It prices full v3 acquired-parameter
commitment hashing, both v3/flat node hashing (including earlier sub-64 H and
filing trees), node reads and bounded hash localization replies. Each public
provider call reserves a full ten-KiB native response allowance, including
missing or cached responses; this is a reservation, not measured wire bytes.
Other transports must enforce that carrier bound before parsing.

`FlatReplaySessionV6` carries chosen local ceilings across DA responses. Before
model acquisition or replay it verifies the entire derived envelope and the
class extent, checks tensor payload ceilings and reserves one whole worst-case
replay's parameter/trace hash allowance. A withheld or inconsistent attempt
still spends that allowance. Provider calls spend session-wide node/hash/read
byte quotas before delegation. Attempt/hash/read exhaustion returns an explicit
limit result, never a clean verdict or a producer conviction. Cached reads and
repeated requests cannot reset the same session's counters. The native late-leaf
trial uses this path from independently derived node resources to a successful
court and payout replay.

These are **local verifier limits**, not a new source of economic rights or
network admission. A caller starting a new local session must pay/account for
that work separately. The existing unbounded v5 checker remains available as
a lower-level API. The payload quantities are not peak allocator memory: model
residency, position copies, transient evaluator/sort buffers and allocator
capacity still require complete accounting. They also do not prove wall-clock
or CPU maxima, metadata/prompt/path-verification hash costs, RPC/retention costs,
whole-job deadline feasibility or aggregate per-block/per-bond/network load.
These remaining quantities must join the shared complete resource vector and
its consensus admission before practical or reward acceptance. Proof pre-emption
(including equivalent proof encodings), real checkpoint/task/fidelity acceptance,
execution Final, A6/A8 and the other full RFC02 conditions stay open.


### §14.29 — Actor-bound sealed evidence and equivalent-carrier counterexamples (2026-10-11)

A proof-byte digest and earliest matching beneficiary lookup alone do not protect
against another valid encoding of the same fault. Two different authentic greedy
rivals can convict the same delivered id. An out-of-range delivery ignores the
rival. An already inline-bound prompt permits a redundant authentic prompt tile
in a relation filing. These carriers have different exact digests while producing
the same conviction. The unchanged flat-v3 native route remains unsealed: a
copyist submitting the alternate carrier first receives its bounty. That is a
security counterexample, not a protected-route acceptance result.

`flat_seal6` adds a separate staged v6 contract. Its salt-bearing commitment binds
vector, authenticated actor and exact bounded proof bytes under new domains.
Every reveal requires the **filer's own mature seal**. It has no unsealed-filer
fallback and does not search other actors' opaque seals for a beneficiary.
Copying a finder's seal fails actor binding; changing its proof fails exact-byte
binding. A new correctly rebound seal posted after observing a reveal cannot
enter a court before its own maturity, including for an equivalent carrier.
An independently prepared mature proof is still admissible; the contract does
not claim protection against censorship until a later copy matures.

The local book has fixed-size metadata rows keyed by `(vector, actor)`, a maximum
of 1,024 rows with a caller-selected smaller total and per-actor bound, and no
stored proofs or historical seal list. An occupied row cannot be overwritten.
A successful court consumes its row once; a failed court leaves it unspent.
Both states retain their bounded slot until explicit, constant-key expiry.
Maturity must precede expiry, which is clipped to the vector's immutable horizon;
all DAA additions are checked. Fixed slot/time checks and bounded raw-carrier
hashing run before a deferred court callback, so an absent, immature, expired or
mismatched seal cannot force a variable stored-program/court decode. Rejected
filings still need consumer fee accounting.

This is **not yet a consensus seal route or protected payout implementation**.
The consumer must authenticate actors and vector/context identity, persist rows
and shared quotas, reserve the same original capital, charge proof/admission work,
and atomically apply one conviction and one payout per vector. A future explicit
versioned protected statement must refuse the old unsealed refutation route;
merely adding a seal object beside that bypass does not close the gap. Economic
fees, aggregate capacity and honest inclusion/deadline feasibility must be
verified before this path is accepted for rewards. Frozen candidate/route grammar,
resource roots and dormant shipping fences remain unchanged. Full RFC02, real
checkpoint/task/fidelity, execution Final and A6/A8 acceptance remain open.

### §14.30 — Protected native flat candidate statements and evidence seals v6 (2026-10-11)

The v6 protected statement wraps the unchanged v3 candidate body. Its separate
trace-root domain binds the v3 root and the fixed v6 maturity, TTL and capacity
policy. It retains the admitted flat-v5 resource scope and candidate-only status.
Append inner kinds 36 `PostFlatModelVectorV6`, 37 `SealFlatModelProofV6`, 38
`RevealFlatModelProofV6` and 39 `ExpireFlatModelSealV6` behind the existing dormant
kernel-route/panel-free fences. Formal rules are in spec 04b §18. Existing v3
bytes, root preimages, inner 31–35 semantics and resource scopes retain their
meaning; the protected statement cannot enter inner 32's unsealed court.

The consumer derives the actor from its authenticated signing bond and persists
one immutable fixed row per `(vector, actor)`. The salt-bearing seal binds actor,
vector and exact proof bytes. A reveal requires that actor's own mature seal;
there is no unsealed fallback, borrowed beneficiary or earliest-byte-sealer
search. Wrong salt, copied seal, changed equivalent carrier, immature/expired
seal, changed context or an honest/malformed proof cannot settle the vector.

Posting burns the shared admission tariff and holds the route policy's original
seal deposit. Four rows per bond and 1,024 total rows bound simultaneous pending
seals. Retirement/withdrawal and all common capital accounting read this same
reservation. Expired pending deposits remain held until a bounded explicit close
forfeits them; a decided vector releases deposits on close. Occupied slots cannot
be replaced or extend their clocks. Maturity is three DAA; expiry is the lesser
of posting plus 100 DAA and the immutable vector liability horizon.

One proof-reserve debit covers fixed metadata, bounded raw hashing, stored
program/PC/body work and the admitted terminal court, before variable decoding.
Registration includes this debit in its worst-court admission. This avoids a
normal-admission flood consuming the honest reveal's reserved capacity. Refused
proofs charge the authenticated filer. A successful fold spends the seal,
releases its deposit, settles the original vector collateral once and credits
49 percent to the authenticated finder atomically. It grants no execution Final,
conformance certificate or model/task support PASS.

This is the consensus consumer implementation of the previously local §14.29
contract. Native synthetic trials, exact commands and results belong in the
implementation ledger. Whole-network invalid-proof/seal saturation, transport,
retention, worst-job inclusion/deadlines and honest liveness still need evidence.
The full resource contract, real-checkpoint fidelity/task/performance, independent
execution Final/redemption and A6/A8 are unchanged completion requirements. No
shipping fence is activated by this increment.

### §14.31 — Protected candidate SDK and offline CLI (2026-10-11)

`misaka-palw-sdk::flat_candidate_v6` and `palw-class flat-v6` expose the protected
post, seal, reveal and explicit-expiry operations. Preparing a v6 post first
requires all three source implementation records to agree on the original v3
root for the selected class and binding. It preserves the job, trace and scope,
then rebinds those agreed records to the protected root. It cannot convert
divergent implementation results into declared agreement. Native admission
still derives and checks the actual bound context and resource scope.

Sealing produces a public signed commitment and separate private material that
binds network domain, vector, signing bond, fresh OS-random salt and exact proof
bytes. The CLI creates the private file with mode 0600 on Unix, refuses existing
outputs, bounds input bytes and nested counts, and omits the proof/salt from its
report. Reveal preparation refuses a different network/bond, borrowed row,
changed proof or salt, immature/expired/spent row before writing a public proof.
The supplied row and height are an offline precheck; the native consumer remains
responsible for authenticated chain state and authoritative clocks.

The SDK signs the existing network/bond/bytes message under the existing ML-DSA
context. The CLI writes reviewable objects and, when needed, the existing bounded
generic `ObjectChunk` parts for `misaka palw submit-object`; it sends no carrier.
Generic shared-group capacity does not establish honest proof inclusion before
the seal/vector horizon. Public RPC acquisition, authenticated snapshot/row
discovery, whole-job retention, protected large-proof liveness and aggregate
invalid-proof/seal saturation therefore remain completion requirements.

SDK codec/signature/file trials and actual-node admission/court/payout replay
using these helpers belong in the implementation ledger. These convenience APIs
grant no conformance, checkpoint fidelity, model/task coverage, reward eligibility
or execution Final, and activate no shipping fence. Full RFC02 acceptance stays
open until all independent requirements have evidence.

### §14.32 — Mature actor-owned protected proof chunks (2026-10-11)

Append `FlatProofV6 { vector, actor } = 3` to the existing kernel chunk target
grammar. It carries only the protected reveal of that vector signed by the
sealing actor, and each part is signed by that same bond. Opening/continuing
requires an open protected vector and that actor's mature unspent seal; the
target deadline is strictly before seal expiry and vector liability. Completion
still requires the exact salt/proof seal and independently bound native court.

The existing two kernel chunk slots per bond, per-part original collateral,
64-DAA clipped TTL and completion/refund/expiry-forfeiture apply. These are the
bond's own slots, separate from the generic shared eight-group table. Bound
protected assembly to one MiB plus 16 KiB of signed envelope before variable
decode. Charge the part and a conservative three-assembly-byte allowance for
own stored-group handling before decoding that group. Opening/continuing also
needs capacity for the completing part and terminal court together, including
two runs. Candidate admission alone does not grant that transport capability.
An authenticated mature
target uses the proof reserve; missing/borrowed/expired targets use admission
capacity and do not open a group. Completion also pays the native reveal debit.

Common chunk-count/deposit queries now read only the bond-key prefix and fixed
headers; they do not decode all actors' variable payloads while calculating free
capital. Stored parts and signatures retain their existing serialization. The
SDK/CLI directs large protected reveals through signed kernel parts and refuses
a silent generic split; large posts retain generic carriage. Supplied offline
seal rows remain unverified until authenticated locally.

The actual-node saturation trial forces a synthetic valid court into multiple
parts and holds all generic slots open. It checks absent/borrowed seals, owned
deposits, one conviction/payment, cleanup and independent replay. This tests
the route, not a real large checkpoint or whole-network saturation bound. Shared
invalid-proof load, all-target aggregate metadata/state and expiry-sweep costs,
worst-job deadlines, transport/acquisition/retention and complete resources still
need evidence. No shipping fence or full RFC02 acceptance is granted.

### §14.33 — Protected candidate reads from one anchored public snapshot (2026-10-11)

The protected SDK reader consumes the existing `getPalwKernelRows` (op 211)
response grammar; no new RPC allocation or consensus object is introduced. One
complete snapshot must preserve the tip, both roots, header and declared row
count across all pages, with strictly advancing rows/cursors. The common snapshot
rebuild checks both served roots and refuses a header newer than the tip.

`FlatSnapshotAnchorV6` separately supplies the locally authenticated tip,
network/ruleset domains and ledger/aux roots. All five must match before protected
reads become available. A caller must authenticate that anchor to its own chain
or a state proof. Copying the anchor from the same remote pages proves only
consistency; the SDK/CLI must not report independent chain membership in that
case. An offline file cannot attest its own chain trust.

Candidate reads bind the requested vector/class/model statement to the explicit
protected profile and independently rebuild the same program, parameter/input
bindings and immutable resource scope used by the native court. Seal export
requires the authenticated signing bond's row, an open candidate, and an unspent
mature seal before its expiry at the anchored tip. Private salt/exact-proof guards,
current bond status, clocks and terminal fault validity remain rechecked by reveal
preparation and native acceptance. Snapshot membership grants no fidelity,
execution rights, reward eligibility or Final.

`palw-class flat-v6 snapshot` accepts one op-211 JSON response per NDJSON line and
a separate anchor JSON file, then exclusively writes the checked native seal row
and reports its anchored height for `flat-v6 reveal`. It uses the existing local
128-MiB decoded snapshot ceiling plus a bounded JSON page envelope. JSON byte,
row-count and hex bounds precede allocation of additional binary copies; this
is not a peak-memory, consensus capacity or network-wide load guarantee. Unknown
fields, malformed hex/tables, stray terminal cursors, incomplete/moved snapshots,
root/anchor/context substitutions, unavailable routes and closed/immature/spent
seals fail without publishing an output. Files are never overwritten.

The node component trial uses the actual op-211 response builder and JSON grammar,
a separately authenticated local consensus anchor, a reconstructed protected
candidate/seal, and the existing own-chunk terminal court/settlement/replay.
Synthetic/offline fixture roots establish reader behavior, not chain admission or
actual-checkpoint/full-task acceptance. Public network transport, automatic local
anchor/state-proof acquisition, retention/pruning, whole-job deadline/liveness,
shared aggregate resources and the rest of §II.14 remain completion requirements.


### §14.34 — Bounded TopK point counterexamples and native-storage selection (2026-10-11)

The frozen v1 rule remains score descending with lower index first on a tie,
followed by ascending selected indices. The reference evaluator now uses a
K-candidate heap for K <= 64 and at most 2K indices in bounded partition blocks for larger K. Selecting the whole axis
emits its known index set directly. The typed execution backend uses the same
bounded-memory strategy and reads the original storage through offset/strides,
including transpose, slice and broadcast views. It does not widen or gather the whole score
source for TopK. Both changes preserve primitive identities, canonical work,
existing program/job limits and exact results; they are backend improvements.
Repeated bounded partitions retain the best K indices of each prefix and cost
O(N) in total before the O(K log K) index ordering. The implementation uses the
in-place linear-time contract in the pinned
[Rust 1.93.0 slice implementation](https://raw.githubusercontent.com/rust-lang/rust/1.93.0/library/core/src/slice/mod.rs).
The ordinary callback-based verifier below retains its separately priced heap
scan; it does not assume cheap repeated reads of remote score material.

An explicitly selected `topk-point-court/v7` adds a separate bounded fault codec
over the unchanged flat-v5 internal/v3 parameter commitments. It is **not**
selected by an existing class, vector, protected reveal, descriptor or default
proof decoder. Its context must bind the exact new court id and the ordinary
program/job/segment/parameter context. Registered parameters or authenticated
node scores are supported; uncommitted/public full-tensor sources retain the
existing court and are refused by this point contract.

Range faults open one selected id outside N; order faults open an adjacent
non-increasing pair, including duplicates. A dominance fault opens a selected
member, a rival score at the same axis row, and the adjacent selected members
around the rival's claimed insertion gap. Those neighbors authenticate omission
from a correct ascending set. A larger rival score, or an equal score with a
smaller rival index, convicts. Every wrong set either has a range/order defect or
excludes a true TopK member that outranks one of its members. A correct set cannot
produce any of these authentic counterexamples. All requested points are bound
to their exact typed roots, coordinates and source wiring; missing, borrowed or
malformed material dismisses. The court opens at most three output and two score
leaves and never reconstructs the N-element axis.

The versioned relation scope derives selection work/auxiliary memory separately
from proof bytes, court work and scratch. The local checker precharges a complete
scan attempt before any score callback; missing acquisition consumes that attempt.
Its 32-MiB selection auxiliary ceiling is a local ordinary-verifier limit, not a
producer memory limit. The 128-KiB filing cap bounds legal parameter and
internal-node score widths; byte, nested-count, shape and path bounds precede allocations. Frozen v1
continues to forbid i128 parameters; i64 parameters and i128 internal-node scores
retain their existing types. Selection/source residency, hashing, evidence acquisition/retention and aggregate
load remain separate prices. A consumer must bind the complete all-relation
scope, normal verification, DA and reserved transport before selecting this court
in a node/reward route.

Missing score material does not convict or default the producer in this court.
Conditional external-verification mode A remains unchanged; this component adds
no consensus availability obligation.

The synthetic 10,485,760-score, K=2 trial executes the reference/backend and scans
an incorrect committed selection. Its terminal filing is 17,485 bytes, below the
independently derived 37,744-byte envelope. This proves a large **fixed axis**
component, not a ten-million-token checkpoint or maximum-length job. Frozen
flat-v5 whole-axis admission still refuses that relation, and existing native
proof routes still refuse v7 bytes. Bounded token/patch/audio lengths, H-axis
selection, all-plan/shared network budgets, full model/task/fidelity/performance,
independent execution Final/redemption and A6/A8 remain required. No shipping
fence or full RFC02 acceptance is activated by this increment.

### §14.35 — Explicit mixed-court graph scope and prepaid independent replay (2026-10-11)

`flat-resource-scope/v7` now selects the point court through an independently
derived **complete graph** contract. The commitment grammar remains flat-v5
internal/v3 parameter; the separately domain-bound court-set id and scope root
select the v7 terminal semantics. Every reachable block node, every unrolled
layer occurrence, the admitted maximum positions, decode and malformed-header
courts are included. A declaration must equal the complete derivation in every
field. A small TopK filing cannot admit another oversized relation or replace
the graph's exact program, mode, extent or resource ceilings.

Committed TopK sources select the v7 point court. Public/constant/initial-zero
sources retain bounded v5 courts. When initial state and a later state writer
require different courts, the scope prices both and selects the court from the
exact typed wiring at that position and occurrence; neither a registrant nor a
filer chooses the cheaper kind. Frozen state roles, per-layer state namespaces,
history windows, source coordinates and v1 type/shape rules remain unchanged.
Admission visits metadata, not model images or position arrays. It accounts for
earlier sub-64 legacy layouts when monotone H crosses into flat commitments,
including the case where an earlier legacy row tree has more paths than the last
flat tree. It serializes/hashes the program once for the unrolled TopK prices.

`flat-fault/v7` wraps either the exact bounded v5 court bytes or v7 TopK point
bytes under a new version and discriminant. The mixed court rederives complete
scope, checks the wiring-selected kind and exact filing bounds, then dispatches
the existing authenticating court. All historical v5/v6 decoders and routes
retain their previous acceptance behavior; none implicitly accepts this wrapper.

The ordinary v7 verifier reexecutes from independently acquired registered
parameters and authenticated public job ids. Its shared replay engine still
checks ordinary relations and delivered decode ids. When TopK differs, it reads
selected ids through a new **16-KiB, single-output-leaf, bounded byte codec**,
authenticates every reply to the same node/type/shape/root, scans its own scores
under the derived budget and builds a bounded point counterexample. A public
value reply is evidence for the selected member, never the reference score or
the correctness of the computation. Missing, oversized, wrong-version or
borrowed material yields a demand, never a Clean verdict or conviction.

The versioned local replay session independently binds the complete scope and
prices reference i128 tensor payloads, parameter/trace hashing, history rows,
node/hash/value reads, reply bytes, TopK scan work, temporary selection memory
and attempts. The full hashing/scan attempt is reserved before artifact or public
callbacks; missing material or an inconsistent artifact consumes that attempt.
Each response consumes its read and byte allowance before delegation. Retries
share the same counters. Storage bytes, the reference i128 representation and
temporary selection bytes are distinct quantities. These component prices do
not yet certify total allocator/RSS, all-primitive CPU/deadlines, public storage/
delivery, per-block/per-bond or network-wide economic and load admission.

An actual synthetic N=10,485,760, K=2, **one-position graph** now passes honest
independent replay and prosecutes a wrong selection through the mixed court.
The mixed filing is 17,488 bytes; its reference source occupies 167,772,160 bytes,
and its scan charge remains 251,658,288 with 128 temporary selection bytes.
Separately, metadata-only admission covers TopK→Gather→state update with 1,024
layers and the existing 2,097,152-position ceiling; this is a derived envelope,
not execution or a materialized maximum-length job. Synthetic graphs exercise
range/duplicate/dominance faults, state and history transitions, all sub-64/64/127
thresholds, decode, encoder inputs, substitution refusal and prepaid retries.

No consensus post/seal/reveal/chunk/DA or reward route selects the mixed v7
contract yet. The protected-v6 actual-node regressions remain compatibility
evidence, not v7 native acceptance. A subsequent consumer must bind the new
court set and complete scope to admission, public acquisition, actor-owned
prosecution, reserved transport, shared resources and original-capital payout.
Versioned token/patch/audio job lengths, H-axis sparsity/state semantics, the full
shared resource vector and economics, real checkpoint/task/context/fidelity/
performance, fresh outsiders, independent execution Final/redemption and A6/A8
remain required. Conditional external-verification mode A remains unchanged;
this increment adds no consensus model-availability obligation. Full RFC02 stays
active and shipping fences stay dormant.

### §14.36 — Explicit v7 native candidate registration (2026-10-11)

Native object 40, `RegisterFlatModelCandidateV7`, now registers a **non-reward
conformance candidate** for the complete mixed-court contract. The v4 decoder
or v5 encoder descriptor identifies the artifact/job role; the independently
derived v7 court-set, profile, maximum positions, encoder binding, resource
scope and replay envelope identify its verification semantics. The consumer
requires a Matured/Final model binding with exactly the submitted descriptor,
canonical program root and complete registered parameter-instance root. Neither
an official compiler nor a model-family name substitutes for that binding.

The kernel independently validates canonical normal form, exact range proof,
every real parameter instance and the complete scope/replay declaration. It
checks guaranteed court work and component reference-memory policy. Table 29,
`flat-conformance-v7`, stores the binding and complete derived plan separately
from execution classes. Its conditional state-root extension preserves the
historical root when empty; row restoration rederives the stored contract.
Old and new candidates share the same eight-entry bonded-owner catalog and
withdrawal cleanup. Registration creates no execution class, OPV eligibility,
job, reward weight or execution Final right.

The bounded canonical object decoder checks the program and parameter counts
before allocation. Native binding hashing is charged to ordinary block budget
and the actor's original collateral before checking authenticity, including
failed attempts. Canonical preparation has its own conservative metadata debit
before decode/range/unrolling. It cannot consume proof-reserved work. The SDK
prepares the exact plan and signs object 40 under its actual network/lifecycle
signature domain; historical v6 preparation and signing do not silently opt in.

Five kernel candidate tests, three new actual-node tests and two new SDK tests
cover identity/codec, complete declarations, rows/root/rollback/withdrawal,
shared old/new quotas, paid refusals and protected proof-budget headroom. The
actual-node suite includes all 18 prior conformance regressions and replays its
resulting state on an independent node. A synthetic 10,485,760-score candidate
at 2,097,152 maximum positions is accepted from bounded metadata. Its source
weights, tokens and maximum-length trace are not materialized; this is not an
executed long-context checkpoint.

The actual pinned Qwen2.5-1.5B checkpoint's 14,011-byte program and 1,636
parameter instances still fail this candidate contract: the present admission
tariff is 7,557,621,401 against the 536,870,912 ordinary allowance, and complete
scope derivation independently refuses an ordinary relation exceeding terminal
court caps. These are recorded refusal results, not model admission passes.
Pricing and bounded ordinary-relation court refinement must be completed
without raising the caps merely to admit this model.

This registration increment does not yet connect v7 posts, actor-owned
seal/reveal, chunk transport or selected-value DA. Those consumers, complete
shared resources/economics, real tasks and independent source fidelity, fresh
outsiders and honest execution Final/redemption remain required. Keep the
original A6 denominator and confidence/participation conditions and A8 complete
task cohort. The user's current goal additionally requires A6/A8 at least 90%;
no inaccessible checkpoint or failure is removed to manufacture that rate.
Conditional external mode A and dormant shipping fences remain unchanged.

### §14.37 — Frozen bounded job lengths and history-selection component (2026-10-11)

`FlatLengthTemplateV7` adds a bounded declarative specialization contract for
token, patch and audio counts. It binds a canonical maximum-shape v1 program
and a strictly ordered map of fixed parameter/state/carry/node axes. Both the
maximum graph and every requested actual specialization independently pass
normal form, exact ranges and complete scope/replay derivation. The immutable
admission binds the template, actual counts, specialized program, positions and
scope/replay roots; enlarged/rebound declarations fail. Zero means an absent
modality. Existing H, primitive attributes, constant bytes and state roles are
not rewritten. Text decoder counts include the prompt and all fed-back tokens;
the final delivered token is excluded. Encoder counts bind its prompt at one
position. Patch/audio inputs still require their separate typed stage/root
binding and are refused on the text-only route.

Adversarial length execution exposed a production trace bug: a provider's
larger or differently typed parameter could reach evaluation despite a smaller
declaration. Buffered, streaming and stage traces now check exact declared
shape, dtype, payload length, representable values and layer namespace before
evaluation. The frozen interpreter already required this contract. Correct
executions, roots and tie semantics remain unchanged. Five length tests and
three trace regressions exercise the actual shared runtime, not a substitute
executor.

`flat_history8` separately implements a **version 8 history-selection
relation**, without relaxing the frozen v1 prohibition on H-axis TopK. At
position p, its source has H=min(p+1,window) rows and its IDX output has
min(Kcap,H) selected rows. Selection is score-descending with lower local id
breaking ties. Explicit window-local-to-absolute coordinates prevent treating
rolled-window ids as global token positions. Work is O(N log K), selection
auxiliary memory is O(K), and exact source/output node coordinates and roots
bind bounded range/order/dominance counterexamples. Its independent court
authenticates at most two source leaves and three output leaves. The session
precharges reference scan/hash and every bounded selected-value callback;
failed acquisitions and retries consume their shared allowance.

Eight history-component tests cover all six dtypes, warmup H=1 with Kcap>H,
flat layout thresholds, window rollovers, i128 extrema, prepaid failures,
hostile codecs, coordinate substitutions and 966 exhaustively enumerated small
selection tuples. Metadata reaches 10,485,760 maximum positions without
allocating position arrays or history images. This does not execute a
ten-million-token checkpoint. It does not prove the source HistAppend/state
continuity, define a complete typed v8 model graph, register/execute that graph
in a node, bind media stages, or close the shared economic/resource vector.
Those obligations remain open alongside full RFC02 acceptance.

### §14.38 — Independent actual-checkpoint source diagnostic (2026-10-11)

Qwen/Qwen2.5-1.5B-Instruct revision
`989aa7980e4cf806f80c7fef2b1adb7bc71aa306` now has an independent Hugging Face
Transformers 4.48.3 / Torch 2.5.1 float32 eager-CPU reference from its actual
BF16 safetensors. Source file bytes are pinned and checked before and after
execution. The reference uses the installed built-in model class, offline
loading and no remote code. The diagnostic protocol fixes exact artifact,
source manifest, tokens, arithmetic units, jobs and thresholds before the
integer comparison. Revision labels are informational to this tool; chain
authentication and checkpoint provenance remain separate obligations.

For four fed-token sequences of lengths 30/31/32/30, all 123 next-token-logit
positions meet the predeclared thresholds. Top1 agreement is 96.747967%, mean
KL 0.001367878, slope 0.998682249, correlation 0.999847941, maximum absolute
logit difference 1.506592512 and RMSE 0.070122785. This is empirical original
source fidelity, separately from bit equality between integer implementations.
It supersedes the need to treat the previous local HL comparison as an
independent HF reference; it does not extend its diagnostic scope.

Measured whole-process wall time/RSS are 26.67 seconds/6,366,314,496 bytes for
the source reference and 242.18 seconds/2,151,088,128 bytes for the integer
comparison. These separate processes include import/load/hash overhead and
may be affected by concurrent builds. They are observations, not a service
throughput guarantee or complete execution/evidence/hash/store/delivery cost
certificate. The diagnostic's context is 32; original context 32,768,
complete chat/code/translation tasks, routing/state fidelity and public native
verification/Final remain untested by this run.

The dated census frame still has D_all=3,117,871 and D_files_listing=2,247,414
(72.081687%). These are listing/shape observations, not registration/Final
coverage. On that historical frame, the listed subset alone cannot supply
90% of D_all. Keep inaccessible/gated/missing entries and nonresponses in the
denominator; obtain new admissible evidence rather than reducing it. There is
no measured complete-task active-kernel A8 cohort or hook-free independent
Final/redemption result. A6/A8 and the full RFC02 goal remain unmet.

### §14.39 — Prepaid exact scheduled-metadata admission (2026-10-11)

The v7 candidate's overly conservative byte-times-maximum-schedule price is
replaced by two paid stages. Reserve B² + 64B + 8,832P + 16,384 before hashing
parameter commitments or decoding the canonical program. From that typed
decode count the actual scheduled node occurrences N without constructing
wiring or tensor values. Reserve 16N*1,024 before range/scope/replay work, and
reuse the decode. The conservative metadata pass count covers the actual
prepared writer/offset constructions, TopK source walks, occurrence framing
and reference replay. Declared instance counts are checked before building
the per-layer set.

The two debits remain one adjudication attempt. Combined per-attempt and shared
block work must fit the ordinary allowance; neither stage borrows the proof
reserve. Invalid canonical bytes retain the first debit. Invalid scopes,
insufficient remaining metadata budget and retries preserve work already spent.
This changes admission pricing only, not canonical PWU, reward weight,
registered identities, scope/replay roots or terminal court caps.

The actual Qwen metadata has 314 template nodes and 7,658 scheduled nodes.
Its preparation price becomes 211,670,361 + 125,468,672 = 337,139,033, within
the 536,870,912 ordinary allowance. Its frozen ordinary court scope still
refuses independently; this removes one metadata-price obstacle and does not
establish model registration, native execution or Final. The earlier 307-byte
synthetic candidate's complete price is now 139,113 + 49,152 = 188,265.
The historical tariff/refusal observations remain retained rather than edited
to look like successful current admission.

Five new staged-cost adversarial tests pass, alongside the five existing
candidate regressions. Exact inputs, paid-attempt accounting, compiled binary
identities and the retained Qwen scope refusal are recorded in
[the staged-pricing verdict](../design/palw/tir/evidence/rfc02-staged-price-v7-verdict.json).
These tests do not establish full-model execution, native Final or A6/A8.

### §14.40 — Native protected mixed-graph prosecution, v7 (2026-10-11)

The registered v7 scope/replay now has explicit native post, own seal/reveal,
expiry and public node/hash/selected-TopK-value demand/answer/default carriers
(inner tags 41..47, following candidate tag 40). The complete stored candidate,
scope and replay are rederived for posting and prosecution. Ordinary v5 faults
and bounded point TopK7 faults share that exact namespace; v3/v6 carriers cannot
bypass the protected route. An optional text length admission fixes one current
program specialization and its exact token count, scope and replay. It does not
make one registered class dynamically shaped or accept patch/audio inputs.

Protected v7 seals share the v6 four-per-bond and 1,024-global limits. The
original vector catalog still shares eight statements per bond with v2/v3/v6.
Requester slots are shared in both admission orders with old DA routes. Public
answers authenticate fixed saved coordinates and type/shape/root without
decoding the stored program. There are at most 32 open demands per vector and
16 KiB per answer. Invalid filings retain actor processing costs; only an own
mature seal enters guaranteed proof work. Own tag113 target4 chunks bind the
same actor and vector and survive saturation of the generic chunk catalog.
The last chunk plus its court requires two guaranteed runs, without increasing
the ordinary or proof ceilings.

A fresh, non-genesis bond registered on an independently synced node acquires
public op211 pages and requested evidence, independently checks a synthetic
sparse/state graph, seals its own proof, convicts and redeems the actual UTXO
credit. Full IBD independently recreates that credit; pruning import checks all
retained deltas and complete tip/rows. The original poster reserve funds one
49% finder/default share and the remaining burn. The paged RPC conversion is
exercised locally; this is not a live TCP service measurement.

The recorded build set passes 27 native, 16 SDK, 41 core and 155 kernel tests
(239 distinct; one hardware benchmark ignored). Thirteen tests are new. Kernel
trace-parameter and staged-pricing changes are included. The later resource10,
checked-settlement and graph9 changes are not included; the native-to-core
source difference is a static allocation inventory/test pin only. Compiled
source preimages, immutable binary hashes, repaired fixture trials and scope
limits are preserved in
[the native verdict](../design/palw/tir/evidence/rfc02-native-mixed-v7-verdict.json).

An honest protected candidate has clean verification but still creates no
execution class, reward eligibility or ExecutionFinal right. This evidence uses
a synthetic 65-axis TopK/Gather/state program, not the actual checkpoint. Honest
execution Final, complete typed H/media jobs, shared resources/economics and
actual-model A6/A8 acceptance remain open. Mode A and dormant shipping fences
remain unchanged.

### §14.41 — Independent free-running task diagnostic failure (2026-10-11)

An additional frozen context-32 protocol runs the actual pinned Qwen source
and integer artifact on three arithmetic/translation/code prompts, each with
eight requested output tokens. Each implementation feeds its own generated
tokens. All 75 fed positions and 24 generated outputs remain in the denominator;
EOS affects answer display/scoring only, not the fixed execution count.

The generated-token agreement is 22/24 (91.666667%), below the predeclared 95%
threshold. Exact generated jobs are 2/3, meeting only that separate threshold.
Both source and integer task-answer fractions are 1/3, below the predeclared
100% answer threshold. Arithmetic differs at two positions after EOS; translation
outputs `Hello.` instead of the exact frozen `Hello`; the eight-token code job
does not finish its fenced answer or emit EOS. These failures are retained;
output formatting, thresholds and job membership are not revised after scoring.

The source process completes in 15.62s at 6,367,248,384B maximum RSS; the integer
process completes its computation in 206.33s at 1,974,124,544B RSS and returns
failure for the unmet threshold. The independent tokenizer-based scorer also
returns failure. These are separate diagnostic observations, not service
throughput or task/cohort acceptance. Four bounded-protocol/scoring refusal
tests pass, but do not turn the measured result into a pass. Frozen protocol,
all source/integer/scorer outputs, process logs, tool/binary identities and
limitations are recorded in
[the failed generation verdict](../design/palw/tir/evidence/qwen25-independent-greedy-task-verdict.json).
The earlier 123-position teacher-forced logit diagnostic remains a distinct
passing result. Neither result establishes complete task benchmarks, maximum
context, native execution Final or A6/A8 coverage.

### §14.42 — Complete ordinary point graph and resource components, v9/v10

An explicit v9 graph contract now uses authenticated scalar output and exact
dependency openings for all 24 ordinary frozen primitives. Registered MatMul
second operands use the existing PC-v3 column layout; internal nodes retain
flat-v5 or small legacy commitments. Committed TopK uses point7 and public/
initial TopK, malformed headers and decode use their separately checked v5
relations. The complete scope covers all scheduled occurrences, history
initialization, both sides of the 63/64-element grammar boundary and maximum
H, with conservative 127-element flat tails. No frozen v5/v7 scope or resource
ceiling is changed.

The mixed court independently rederives that full scope and prices both its
metadata preparation and the terminal. Its locator replays from acquired
registered parameters and authenticated job input, then requests bounded
typed output/header/hash evidence for the first mismatch; it needs no supplied
fault coordinate. Typed value replies support all six dtypes. Missing evidence
creates a demand, not a fabricated conviction. Retry/hash/read/TopK work is
prepaid by the local replay session. These are versioned components; native9
and execution-class/job11 integration are separate acceptance steps.

Resource10 independently binds that complete scope and derives 21 dimensions
for primitive operations, validation/copy/index traffic, hashes, provider calls,
reference payload/container allowance, evidence storage, delivery/reply/retry,
complete court/metadata work, raw parameter storage/tree scratch and owned
peak payload. Its streaming reference consumer checks borrowed raw byte width,
dtype and shape before i128 expansion, authenticates parameters, and atomically
reserves plan/block/bond/network allowances before callbacks. Failed callbacks
and retries retain the debit. This local component neither installs persistent
native quotas nor measures process RSS, transport retention or coin fees.

Checked reference settlement preflights every accumulated u64 total, funds
payouts/burns from prior original collateral debits and FinalReward from spent
escrow, and rolls back a rejected or unbalanced receipt batch atomically.
Existing reservations remain releasable after another lane slashes collateral;
only new allocation rejects a collateral overhang. Seven new conservation
tests and 58 existing route/OPV/verifier/pipeline tests pass, alongside eight
resource tests and seven point/four mixed-graph tests. Exact build scopes and
retained failures are recorded separately; the earlier native7 full-library
run does not include these later changes. Actual measured point/parameter
checkpoint evidence follows in its own observation. Complete native resource/
escrow enforcement, typed H/media jobs, honest Final and A6/A8 remain open.

### §14.43 — Actual checkpoint point court and parameter continuity, v9

The pinned Qwen2.5-1.5B integer artifact is executed twice through independently
opened mapped executors for one fed token (4498), with all 7,658 nodes. A finder
without the producer's mutation coordinates locates the first divergent node
after 35 agreeing prior roots. A fixed first-leaf typed reply supplies the
divergent element; this trial does not establish arbitrary-leaf public hash
descent or live transport. It independently authenticates the selected real
matrix parameter against PC-v3, convicts the ordinary point and dismisses
missing source. The proof is17,944 bytes, with combined court work151,708,672
and scratch21,316,001 bytes. Whole-process time/RSS is16.30s/3,995,418,624B.
The earlier quadratic node-directory localization trial also passed at76.06s;
its source and result are retained rather than rewritten as the linear trial.

A separate streamed check authenticates every one of the1,636 registered
parameter instances against the exact mapped integer artifact:1,835,516,100
raw payload bytes read,27,275,264-byte maximum derived helper workspace below
32 MiB,81.07s whole-process time and1,853,112,320B maximum RSS. Artifact SHA is
checked before and after both trials. This is complete integer-artifact-to-PC
continuity, separately from empirical original BF16 fidelity; it is neither
original arithmetic bit equality nor a native source-binding substitution.

[The checkpoint observation](../design/palw/tir/evidence/qwen25-real-courts9-observation.json)
records immutable executable/source hashes, commands, actual/max positions,
the exact proof and limitations. Scope metadata covers32 positions, whereas
this prosecution executes one position. No model admission, real native
execution Final, maximum-context or cohort/A6/A8 credit follows from these
component results. Those acceptance steps remain open.

### §14.44 — Bounded authenticated external stage inputs, component v12

The opt-in `flat_inputs12` component binds a frozen program-v2 external stage,
its exact maximum v1 view, the immutable real source-PC namespace and bounded
token/patch/audio axis map. Every present modality must bind an actual external
input axis. Job admission fixes actual lengths and positions; maximum and actual
graphs independently pass validation, interval analysis and complete scope9.
Source-weight and persistent-state axes cannot be resized by the input map.
Both maximum and actual input payloads are bounded at16 MiB raw/32 MiB expanded
i128, with at most16 inputs and16,384 real parameter instances.

Acquisition checks job/admission/root counts and real source PC before provider
calls. It atomically prepays a local input attempt and its complete raw/expanded
payload. Dtype, shape and exact bytes are checked before expansion, followed by
the declared interval and each exact job-input root. Failed expensive reads
retain their complete allowance. Authenticated input values and combined PC
are private, with immutable accessors; virtual input roots occupy the canonical
v1-view parameter namespace after the real weights.

Five synthetic tests pass. A three-position patch3/audio5 stage produces
16/32/48 under independent arithmetic, the v2 interpreter and exact v1 trace.
Patch/audio reductions, an explicit previous-position state read and its write
use the same full scope9/court9: honest proofs dismiss, wrong committed outputs
convict, and borrowed input/state openings refuse. Wrong job/source/scope/count
and insufficient allowances refuse before callbacks. Immutable binary, exact
dependency preimages and selected commands are retained in
[the component verdict](../design/palw/tir/evidence/rfc02-typed-inputs12-verdict.json).

This component serves job-constant external tensors across admitted positions.
Per-position media inputs, random/earlier-stage sources, post-write stages,
native transport/retention/codec, resource10/quota11 integration, job funding
and media Final remain open. Its local allowance bounds input callbacks and
raw/i128 payload only; metadata, PC/tree hashing, scratch and provider-internal
work require the shared native resource contract. Real source-PC continuity is
distinct from original-model fidelity. No real-media task or A6/A8 credit is
added; RFC02 completion remains open.

### §14.45 — Generic public checkpoint localization and fresh context128

The complete ordinary locator now authenticates its full scope and requested
relation before any evidence callback. Public hash descent locates an unknown
divergent leaf, and authenticated headers cover all six dtypes, including
malformed metadata needed for prosecution. Two additional graph tests pass
(six graph tests total); this does not repeat the four earlier tests as new.

The actual pinned Qwen checkpoint trial independently matches all7,658 honest
node roots, then finds occurrence1/node27/element1500 after35 agreeing roots.
Nine public queries return5,853 bytes; the17,816-byte proof convicts through
the same complete scope9/court9. Missing headers/values require acquisition or
dismissal. The fixture retains an authentic and a false R/PC tile pair, separately
from full integer-artifact PC continuity. Its frozen fixture, executables,
source identities and diagnostic limitations are recorded in
[the generic checkpoint observation](../design/palw/tir/evidence/qwen25-real-generic9-observation.json).
The public service and actual native prosecution remain separate checks.

A newly lowered context128 program changes both history windows from32 to128
while retaining the exact parameter declarations, all1,636 registered parameter
instances, schedule and quantization recipes. All four positional table fills
are independently reconstructed. Borrowed mapped payloads authenticate against
the same PC; no second1.835-GB integer artifact is produced. The earlier32-position
calibration is reused explicitly.

The frozen128-position diagnostic evaluates two complete128-token sequences
against independently loaded original source weights. It passes the unchanged
predeclared logit gates: top1 agreement252/256 (98.4375%), mean KL0.00230502,
slope0.99773344 and correlation0.99953118. Integer auditing plus execution takes
574.41s at2,438,201,344B maximum RSS; source inference takes8.61s at6,544,982,016B.
These different diagnostic processes are not a controlled performance comparison.
[The context observation](../design/palw/tir/evidence/qwen25-borrowed-context128-observation.json)
retains failed scale-decoding and disk-space trials, exact protocol/tokens,
immutable executable hashes and source outputs. This establishes context128
logit fidelity, not original context32768, a completed free-running task,
native Final, media support or A6/A8. The prior frozen greedy-task failure
remains unchanged. RFC02 completion remains open.

### §14.46 — Funded execution and persisted quota components, v11

The independently checked class binds a matured native source header, exact
candidate9 program/PC, maximum scope/replay/resource10, trusted quota policy,
fixed liability horizons, reward ceiling and original producer reserve. The
text-job record separately fixes requester/producer/nonce, prompt and complete
fed positions, actual scope/resource/quota roots and an original escrow debit.
Its semantic request identity cannot change with admission time or a funding
carrier; native also needs a permanent requester/nonce once-only index.

Private job state permits one protected claim and one terminal settlement.
Final pays only original escrow after all retained evidence, pending own proofs,
DA and latest-answer grace close. Fault settlement refunds that escrow and funds
finder/burn only from actually collected original producer collateral. Amount
overflow, wrong roots, duplicate settlement and anchored state rewind refuse
before mutation. A trusted DAA jump may close/refund an expired job without
reopening computation/source proof windows. Late trace-DA default requires its
immutable establishment time within liability; unavailable external R is not
a source-mismatch judgment. Twelve synthetic execution tests pass against the
final20-test quota snapshot, with both the initial disk refusal and immutable
passing executable retained in
[the execution verdict](../design/palw/tir/evidence/rfc02-execution11-verdict.json).
Original-class restoration independently rechecks all original candidate/source/
policy roots, fixes private admission permission to false and preserves access
to funded-job settlement after source revocation. It creates no fault from a
revocation flag. Fresh funded policies require every future guarantee kind.

The quota component persists cumulative consumed/reserved amounts for21 axes
at subject, block, producer and network scopes under a rooted trusted policy.
Baseline is once-only; producer actions alone spend their reserved allowance.
Public challenger attempts spend their own ordinary allowance. Failed expensive
work stays spent, and admission floods cannot consume matured own court/DA/chunk/
close guarantees. Expired terminal collection prepays a fixed current ordinary
close envelope and uses a private token bound to current state and the genuine
terminal book; it restores no old credits. Twenty synthetic quota tests pass,
superseding earlier10/11/12/14/17/19 counts rather than adding them, in
[the quota verdict](../design/palw/tir/evidence/rfc02-persisted-quota11-isolated-verdict.json).

Quota restoration requires an independently rooted native state anchor. A paid
terminal attempt leaves the subject open until the genuine terminal book and
atomic payout authorize its private close token. Class-maximum court/chunk and
native metadata-restore costs are reserved independently of the smaller actual
job scope; native must guard the priced stored-post cap before copying/decoding.

These components do not authenticate carriers or spend native coins themselves.
Atomic native policy/nonce/quota/escrow/UTXO application, protected challenger
entitlements and retained-source lifecycle remain required. Bounded terminal
quota-row collection now requires authenticated permanent spent-request/job
anchors and a paid row operation; same-interval consumption is preserved. This first funded-job grammar refuses patch/audio. No native
honest execution Final, actual complete-task or A6/A8 credit follows; the full
goal remains active.

### §14.47 — Predeclared complete free-running task diagnostic, context128

A distinct protocol is fixed before source/integer outputs: arithmetic,
translation and a complete Python addition function, maximum32 generated tokens,
first predicted EOS included, and no EOS at the cap counted as incomplete.
Answer rules,95% same-position token agreement, at least2/3 exact jobs and100%
task success for both models are predeclared. Missing output tokens count as
unequal. This protocol does not change the prior fixed-eight-output failure.

Independently loaded original source and the fresh context128 integer program
both complete all three tasks correctly. Generated counts are3/2/12 including
EOS; all17 output token IDs and all three jobs match exactly. An independent
tokenizer/semantic scorer passes the frozen rules. Six bounded-policy/scoring
controls pass. Source inference takes12.28s at6,480,707,584B maximum RSS; integer
source-PC auditing and dev-profile execution take261.35s at2,009,333,760B.
The differing processes do not certify production throughput. Exact protocol,
immutable executable/source identities, outputs, scorer and earlier trials are
retained in
[the complete-task observation](../design/palw/tir/evidence/qwen25-borrowed-context128-complete-task-observation.json).

This is a three-task offline diagnostic with short24/20/36-token prompts. It is
neither original32768-context coverage nor a probability-sampled active cohort.
Its EOS-stop grammar is distinct from the first native fixed-count job contract;
native execution Final, public fresh-node acquisition, other models/modalities
and A6/A8>=90% remain required. Neither its success nor the earlier context32
failure is substituted for the retained population denominators.

### §14.48 — Native mixed-court conformance and bounded candidate restoration, v9

The explicit opt-in v9 route registers the candidate, posts its rooted typed
trace, serves selected values, and connects own seal/reveal/chunk and settlement
to the same candidate scope and court. Legacy roots remain unchanged when the
new tables are empty; v9 grants conformance rights without activating a funded
execution descriptor. SDK checking independently derives the full candidate
scope/replay/resource10 rather than trusting transmitted plan metadata.

Ordinary native ledger restoration prepays and reads at most128 fixed candidate
headers. It preserves large raw rows outside the journal diff; candidate-local
DA/court paths reconstruct only their authenticated candidate scope. Public
bulk import independently validates rows but first bounds row count, total raw
bytes and aggregate derivation work. Owner withdrawal is refused while either
v7 or v9 protected traces or pending own proofs/DA still need that candidate's
metadata. Expired candidates with no dependencies may retire without expanding
the catalog or deleting live evidence.

The actual Qwen fixture reaches authenticated selected DA, own seal/reveal,
original-collateral finder payout and independent IBD replay. Its node finder
uses a prepared actual-model proof; a fresh finder running the model and locating
an unknown bad coordinate through only public node data remains separate work.
This result grants no honest funded execution Final or A6/A8 coverage.

The coherent native milestone passes51 selected core regressions,35 real-node
conformance regressions,134 SDK tests and five candidate-import/adversarial
tests. The new distinct tests are five candidate, four SDK, three typed-DA and
eight node tests; these20 increase the protected component pool from341 to361.
Existing regression tests and previous quota snapshots are not counted again.
Exact source preimages, immutable binaries, trial failures and test-only
inventory corrections are retained in
[the native milestone verdict](../design/palw/tir/evidence/rfc02-native9-typed-da-node-verdict.json).

### §14.49 — Rooted native execution headers and staged request funding, v11

The native-only class checker rechecks the canonical program, complete class
scope and replay against the original independently admitted candidate9. It
retains the original class resource10 root without materializing its quantity
vector. Public imports and SDK candidate checking still independently derive
that vector. Actual-job preparation independently derives resources once; its
fixed record binds class, prompt/input, requester, producer, canonical nonce,
reward and quota-plan root. Fund restores that exact original native preparation
and rechecks live source/policy eligibility at the current block hash and DAA,
original debit and the whole admitted liability interval. A plan for the same
position count cannot substitute another prompt or actor.

The immutable class record additionally commits the exact original native2
R/PC proof bound. For canonical program size B and N committed instances,
PC bytes are 4 + the sum of 67 bytes per unlayered instance or 69 per layered
instance; max proof bytes are PC bytes +128KiB. Source-court work is
B² +64B +8832N +64(max proof bytes +7) +65536; owned scratch is
8B +512N +8(max proof bytes +7) +65536. Computation and source bounds must both
be represented in the independently derived Court/Chunk quota plan. Native
must compare the proof bound with the authenticated original binding header
and prepay all actual restores and fixed-row processing under unchanged action
limits; these formulas do not prove any actual model fits those limits.

A separately rooted fixed class header can restore and settle an existing
funded book without reconstructing its program/scope/resource vector. It is
readonly and cannot grant admission. Source revocation cannot strand original
escrow. Historical settlement requires an authenticated, originally verified
court identity with exact R/PC, subject, proof and original inclusion time
within claim liability. A refuted flag or new late proof is insufficient. An
existing global R/PC theorem may stop another exact-scope claim's Final; only
its original paid finder can receive a bounty. Native checks operator identity,
and a finder who is that claim's producer receives no bounty: the whole actual
collected slash is burned and the requester is refunded.

[The component verdict](../design/palw/tir/evidence/rfc02-execution11-native-headers-verdict.json)
records 26 pure tests and an immutable replay, with stable owned-source
preimages. The initial17/23/25 trials and the compiler refusal are retained.
Concurrent dependencies were not uniformly frozen for this component run.
Authenticated original state and actual coin debit/payout remain native boundary
fixtures in these tests; funded native Final/redemption, the accepted native
model cohort and the A6/A8 90% requirement remain unproven.

### §14.50 — Public-snapshot streaming outsider consumer, v9

[The local consumer verdict](../design/palw/tir/evidence/rfc02-mapped-R-ordinary9-local-consumer-verdict.json)
records 12 SDK controls for an ordinary-point outsider. It authenticates the
public candidate/binding/trace and complete original R windows before its own
model execution, uses bounded selected DA and unknown-node/leaf descent, and
predebits local reference, source, metadata, hash, delivery and retry budgets.
It does not receive a prepared fraud coordinate or proof. Source acquisition
remains external under mode A; this is not a consensus source-distribution duty.
Special TopK/history/Decode relations return an explicit separate-court demand.

The actual Qwen fresh-node run now authenticates all1,445,797 R leaves and
all1,636 PC instances before executing its own7,658 nodes. The finder receives
no prepared fault coordinates, proof or archived replies. It obtains43 public
DA demands through44 attempts, locates an unknown ordinary fault and constructs
its own17,816-byte proof. Native scope9 seal/maturity/reveal, the original100
collateral slash, its own49-unit actual UTXO and independent IBD replay pass.
The final immutable run takes155.22s, with2,669,395,968B maximum RSS. Selected
service reserves123 callbacks and962,560 wire bytes; it does not claim an
unmeasured discovery guarantee under malicious ordinary traffic exhaustion.

Its first run refused the explicit local IndexSteps budget before opening the
model; that refusal is retained. The next local budget was fixed in
[protocol v2](../design/palw/tir/evidence/rfc02-actual-outsider9-protocol-v2.json)
before the next finder output, without changing network or court limits.
Coordinated prebuild capture and actual Cargo/.d selection preserve1,442 local
compiled inputs for the immutable node and SDK binaries. The actual1, SDK12 and
existing35 native regressions all pass in
[the final outsider receipt](../design/palw/tir/evidence/rfc02-actual-outsider9-final-verdict.json).
This ordinary-point,
class-maximum32/actual-position1 result adds no honest funded execution Final,
requester escrow redemption, accepted model cohort or A6/A8 acceptance.

### §14.51 — Protected quota rows and bounded execution11 carriers

[The quota receipt](../design/palw/tir/evidence/rfc02-protected-quota11-isolated-verdict.json)
supersedes20 pure controls with40, including protected paid-seal/fragment
reservation, fixed authenticated selected rows, operator nonce witnesses and
source-court costs across21 resource axes. It does not substitute a whole-map
restore for the priced four selected rows. Expensive failed attempts stay paid;
unused expired reservations cannot recreate same-interval credits.

[Five carrier controls](../design/palw/tir/evidence/rfc02-native11-bounded-carriers-verdict.json)
check bounded framing, exact actors/nonces, job-specific outer trace identity,
salted own proof identity and source/computation wrappers. The carrier module
is compiled, but execution11 Fund/Commit/court/DA/Final routes are not activated.
Its unexported fold draft is excluded from the compiled source receipt.

Proof-root-bound protected DA2 begins only after a proof exists. It does not
guarantee unknown-coordinate discovery after ordinary demand exhaustion.
Native execution11 must reserve and authenticate a separate bounded paid
discovery entitlement before proof construction, then bind its conversion to
the same owner's exact proof and new maturity. Producer delivery and fixed
readonly terminal costs must be independently reserved before admission.
These remaining guarantees and actual Fund→Final→redemption remain required.

The protected distinct component pool is413: prior361 plus14 execution,
20 quota,12 SDK, five carrier and one actual fresh-node test functions.
Repeated35 regressions, local intermediate8/33/37 snapshots and immutable
replays add zero. This engineering test count is not a model denominator or
completion percentage; accepted native honest-Final model records remain0.

## 改定 — 2026-10-12（seatingとモデル保有、単一seat scope：提案）

**状態:** 設計の改定・提案。実装、敵対的試験、経済評価、ネットワーク有効化は未実施。数値は本番定数ではない。 詳細は[RFC/ADRレビューの整理（2026-10-12）](../design/palw/rfc-adr-review-resolution-2026-10-12.md) と[Panel=1・Bond/time予算・モデル拘束資本倍率の改定案（2026-10-12）](../design/palw/panel1-bond-budget-model-capital-amendments-2026-10-12.md) §4。

Proposal Aの `class_seated`（executor以外のモデル保有operatorを `seat_count` 以上、registrant・executorを除いた独立operatorの下限）は、モデル配布監査ではなく、実際にclaimを検証できるPanelを形成する条件として維持する（ADR-0177 D1補足：Miner・Panelは保有必須、登録者に配布義務はない）。Panel=1暫定modeでは、単一seatで全検証scopeを覆える経路だけを対象とし、旧複数seat前提を一括定数置換しない（RFC-0010 2026-10-12改定）。

### §14.52 — Paid pre-proof discovery and one-slot proof conversion, v13 (2026-10-13)

`flat_quota11::discovery13` defines an explicit v13 policy and bounded fixed-row
transition API. A discovery ticket needs an authenticated original funded claim,
independent owner/operator, original deposit receipt and permanent native nonce
absence. It needs neither a prebuilt proof nor a known fault coordinate. Its
policy commits the original quota policy and a bounded request allowance.
Producer admission must cover ordinary lifetime answers plus discovery answers
for all four retained job slots and the eight post-proof protected demands.
Underfunding or arithmetic overflow refuses; declaring a ticket does not reserve
producer deliveries retrospectively.

The ticket uses the original v11 global, actor and job retained-slot counters
and all 21 cumulative resource axes. Admission reserves request envelopes,
fixed journal operations and the existing independently derived seal/court/chunk
plan together. Requests debit before decoding or calling a provider; failed
expensive attempts stay paid. They consume reserved capacity even when ordinary
capacity is exhausted. Immutable selected-row roots, exact per-attempt costs,
ownership, maturity, original interval and deadline are independently checked.
All returned rows must be applied in a single native journal transaction.

The frozen v11 request tariff used here covers fixed request metadata, not a
full class/post restore. It also does not cover a complete original PC leaf of
4096 i128 values. An integrated consumer must price those larger operations in
separate, explicitly consented supplements before restoring or decoding them;
the v13 ticket alone grants neither operation.

Conversion authenticates a new exact own proof seal on the same claim, vector,
owner/operator and original deposit receipt. It takes a new proof maturity and
transfers one retained slot and only the prepaid proof guarantee to the existing
v11 protected row. Unused discovery capacity becomes consumption, never an
ordinary refund. Same-interval retirement likewise consumes unused guarantees;
after an authenticated native rollover, collection pays a new ordinary fixed
journal operation and restores no expired credits. Native must preserve a
permanent spent-ticket/nonce anchor through row collection.

This is a bounded discovery reservation component, not a completed native route.
The v13 policy must be bound and checked by the eventual versioned native
Fund/claim/demand/answer/close path. A configured request count is not a theorem
that every unknown relation can be localized within that count or before its
deadline. Original-model acquisition remains external (mode A). Native atomic
coin/nonce/row application, operator-wide capital and rotation accounting,
complete localization bounds, aggregate adversarial liveness, funded execution
Final/redemption and all §II.14/A6/A8 acceptance remain open. No shipping fence,
frozen TIR byte, v7/v9 court, v11 policy root or existing seal grammar changes.

The local-LLM census now reports its shape threshold separately from A8
acceptance. A header-only report with zero measured active-kernel full-task
Finals always has `meets_target=false` and `acceptance_status=NOT_RUN`, even
when its shape-ready lower confidence bound exceeds 90%. Historical shape
measurements are retained; they are not Final evidence.


### 14.53 Prospective native funded and typed-stage namespaces

Inner 63 (`FundedExecutionV11`) and inner 64 (`StageExecutionV14`) are separately
fenced native integrations of the complete-scope checker, original requester
escrow, principal nonce, derived shared quota and typed source/input contracts.
Their policy identities and prospective state extensions do not change frozen
v1/v7/v9 meanings. Funded proof chunk target 6 belongs to inner 63's owning
fence and original protected seal, including failed fragment/assembly charges;
it does not acquire ordinary chunk-pool priority. Typed stage14 source inventory
covers real original weights/state and never synthetic job-input slots.

Collection of an expired protected seal by a third party requires authenticated
rows for both current payer and original seal owner, plus the complete original
subject/global counters and terminal anchor. Price the full fixed restore and
journal to the payer's current ordinary allowance, decrement exactly the original
owner/subject/global retained counters, and delete once. Collection must never
refund old guarantees or recreate a proof attempt. Empty selected maps do not
prove absence of other retained seals or discovery tickets.

These are prospective implementation contracts. The native monetary, discovery,
court/DA and independent Final gates, real full-context/checkpoint conditions
and A6/A8 population criteria in II.14 remain required. Shipping presets keep the
new fields absent and arming validation remains closed. Current code and actual
measurement status are recorded in the [implementation ledger](../design/palw/tir/rfc0002-implementation.md).

### 14.54 Original producer consent and additional source obligations

Consent18 precedes Fund and commits the exact original preparation, requester
and producer principals, operator nonce, reward, quota interval, expiry and
derived availability/fee policy roots. Old metadata acceptance does not grant
these rights. A requester cannot allocate another producer's answer capacity,
catalogue slots or recipient R merely by naming that producer. A consumed
consent and funded principal nonce remain spent across row collection.

Source16 supplements frozen v11 with an independently derived original-PC
answer obligation, allowing a complete original leaf within a bounded 128-KiB
carrier. It covers original headers, subtrees and original 4096-value leaves,
never a smaller reinterpreted leaf. Its checked quote commits the original
class, real parameter/source inventory, job quota plan and policy. A rooted
fixed cached quote is authenticated against those original native roots; a raw
serialized price vector cannot grant capacity. The source guarantee shares
all 21 global and producer resource aggregates while preserving the v11
subject's original attempt/quantity meanings. Answers debit before payload
decode, including failed attempts. Native pending-request authentication,
exact per-request attempts, original deadlines and original producer ownership
are additional obligations of the consumer.

Trace17 separately covers complete original class/post restoration by the
requesting actor and producer. Source16 and Trace17 are granted only under the
producer's original Consent18, and paid caller entitlement precedes expensive
restore. Neither supplement is a Final authority. Public expired collection
authenticates the original terminal and source row and pays a new current
caller tariff. It cannot move expired reservations into the current interval,
refund them or resurrect an obligation.

DA fee income requires explicit capped consent and actual collected caller
collateral. Original reward plus all credited fees and configured external or
default gains must remain within the original producer liability. Unpaid or
partly paid recipient R remains held across sparse DAA jumps; the reuse clock
starts at actual queue payment. Illustrative policy numbers do not establish
economic deterrence or guaranteed carriage. Localization turns, simultaneous
response capacity and whole-path deadlines require their own authenticated
policy bounds and measurements before independent Final can open.

Physical carriage must use actual consensus compute, transient and contextual
storage mass. The inner 128-KiB codec limit is not a delivery guarantee: that
payload plus signature/transaction overhead can exceed the actual 500000 mass
block. A carrier contract must bound the complete payload, inputs, outputs,
signature scripts, output scripts, sigops and contextual UTXO storage, and
authenticate the governing mass constants from Params. New delivery leases
must share block room with existing H1/readiness lanes, include paid failed
attempts and proof transport, and prevent fast slot reuse from exceeding the
promised service rate. A mass quotation alone does not establish that scheduler.

### 14.55 Original physical leases and native carrier selection

Native text Consent23 and Fund24 explicitly bind the original Consent18,
Pursuit19 and physical service/lease22 roots. Frozen Fund2 and Consent18 are not
silently upgraded. A consent23 preparation cannot fall back to Fund2 to omit
its physical obligations. Global lease admission includes failed answer attempts,
original proof fragments and localization/transport deadlines. An ordinary stream
or owned proof stream retains its original slot until its original deadline;
answering early, copying a pending ID or converting a discovery owner to a proof
owner cannot manufacture an additional concurrent stream.

The native mempool/template path must authenticate the original pending unit,
producer/owner, remaining attempt and live lease against the template's exact
selected-parent state. A route tag, parser success, fee or caller-declared mass
does not grant priority. Recheck the complete populated transaction against its
original payload/input/output/script/sigop/contextual-storage envelope. Limit
UTXO variants of the same unit/part and take at most one such variant in the
reserved selection for a block. The original unit survives transaction fee,
signature encoding and UTXO changes; source/trace/proof and text/stage namespaces
remain distinct. Local index count and retained-byte ceilings also apply, and
every removal or original-unit retirement releases its exact local entry.

Selection uses the same virtual read snapshot as transaction validation. It may
not substitute the mutable store tip if the selected-parent state is unavailable.
Existing H1/readiness carriage and the ordinary fee market share the actual block
mass left by the native packet. A service boundary crossed by a DAA jump must not
be ignored merely because the new DAA is not an exact multiple of the period.
Boundary selection alone does not prove the promised duration: bounds on DAA
advancement, relay/admission, template refill, competing leases and actual
inclusion require separate measured evidence. A node-local reserved index is not
a censorship theorem or an independent Final authority.

The current consumer service remains a non-authorizing probe until the reserved
builder and its delivery assumptions are verified. Stage14 requires its own
original physical consent/lease before using this lane; a text23 lease cannot
authorize a stage response. All shipping activation fields remain absent.

### 14.56 Original burst residency and the new full-court contracts

The full-court25 checker, actual/max EOS stopping29 and Stage28 contracts have
their own records, roots and bounded decoders. They do not enlarge the frozen
v7/v9/v11/v14 court, count, pricing or length semantics. Text29 reserves the
original maximum before Fund, checks the actual first-EOS-or-cap length at
Commit, and retains the maximum reservation after early stopping. Stage28
reserves the full original component bundle, real source namespace and the
whole acquisition/discovery/prove/delivery horizon before Fund. New paid
transport29 uses u16 parts and at most512 parts; old target6/7 carriers retain
their u8 and64-part meanings.

Every new Final27 consent must additionally bind Queue30's original policy and
independently derived plan. Delivery density alone cannot admit a burst: account
for all answer/proof variants, complete carrier envelopes, populated input UTXO
scripts and retained index/transaction copies. Reserve both packet count and
owned bytes in the SAME shared native global before collateral or escrow moves.
Text and Stage share that global. Joint physical22/Queue30 admission is atomic;
a live legacy23 lease without an original Queue30 promise cannot be silently
relabeled. A caller-supplied serialized memory quote is not a checked plan.

An honest consumer provisions the declared native queue in addition to its
ordinary mempool. Ordinary transactions, including local high-priority entries,
cannot borrow that earmarked capacity. Local RAM scaling cannot reduce the
original native reservation. The new queue's complete singleton envelope uses
confirmed inputs; an unconfirmed ancestor is not an additional free carriage
slot. Same-unit fee replacement subtracts the superseded original variant once,
while a third independent variant gets no position. Generic fee/expiry removal
must retain live indexed native units. Genuine terminal collection releases
the exact Queue30 and physical22 leases together after their original horizon,
all pending answers/owners/fragments and physical cooldowns close; it never
restores frozen21 quota credits.

Final27's trusted public profile binds Queue30 policy in network identity.
An implemented node selector is distinct from measured whole-claim detection,
complete cold-reference cost, actual delivery and independent Final/redemption.
These conditions and A6/A8 evidence still gate activation. All shipping fences
remain absent until completion evidence passes the contract.

Initial registration31 is a separate, ordinary paid pre-Fund transport for a
large canonical source/class body. Its signed Start binds original owner,
permanent network sequence, exact target (Text29 class or Stage28 source/class),
whole-body root, byte extent, u16 count and expiry inside the original interval.
At most4 objects and1 per mature operator are retained, with512 parts of32KiB,
16MiB total and2 original attempts per part/assembly. Charge whole retained and
assembly buffers in the SAME21-axis global before allocating/storing them;
malformed inner lengths consume their paid attempt before decoding. Assembly
rechecks all extents and the original hash, then invokes the target's genuine
registration checks. The transport cannot dispatch Fund, Commit or Final and
offers no protected delivery guarantee before Fund. Expired paid collection
deletes exact bounded fragments while retaining the permanent sequence.
Frozen object/proof chunk counts and canonical TIR program limits are unchanged.

### II.14.57 Independent original credit delivery — audit32/redemption33

Native Final evidence must open original consensus rows under an independently
pinned header, selected parent and owning ruleset. A producer's serialized audit
record is a projection to compare against rederived rows, never an authority to
mint a checked Final. Explicit auxiliary/payout proof labels authenticate their
exact original commitment positions. New envelope semantics require their own
opening verifier and cannot use an old-version or raw-root fallback.

New Final27 credits have a unique payment identity binding original job,
funding, settlement and payee. A pooled queue for another job cannot stand in
for a previously consumed original credit. Redemption33 checks the actual
coinbase at transaction index0 against the pinned block's transaction Merkle
root, including the owning Crescendo mass-commitment fence and exact missing
subtree grammar. Complete authenticated before/after payout tables prove the
same canonical drain prefix that the transition clears. Its contiguous outputs
must preserve original order, amounts and payee scripts, and the exact original
credit queue must disappear. The resulting evidence names a real outpoint and
the original credit; it does not infer maturity, current unspentness or a later
successful spend. Independent node validation and those UTXO lifecycle checks
remain part of the completion and A6/A8 evidence.

### II.14.58 Text29 native lane, accepted-spend redemption and the A6/A8 receipt rule (2026-10-15)

> **Change marker — 2026-10-15 (RFC text amended; implementation is an unverified
> source checkpoint).** This section adds three normative rules and amends
> II.14.57's last paragraph: the "UTXO lifecycle checks" it left open are now
> specified by rule 2 below. No shipping fence, preset or release height changes.

1. **Text29 action grammar.** Inside the funded namespace (inner 63), actions
   27–40 belong to Text29 and are judged only past BOTH `palw_funded_execution_v11`
   and `palw_native_final_v27`; below either fence the bodies ride unjudged.
   Action 32 is the common paid paged part for namespaces 28 and 29: the part that
   completes a paid file's Part/Assembly/Court debits also reveals it. Action 34
   has no body and is refused by name. Action 40 carries an explicit collection
   kind: 0 retires one expired paid owner, 1 collects the next indexed public
   answer/default cache, 2 retires a genuinely terminal job. Kind 2 requires every
   paid owner, caller row, public cache and physical stream to be retired already;
   it then retires the source guarantee, the shared quota subject and the joint
   Queue30/physical22 leases once under a kernel-checked original terminal grant
   (`check_text_terminal_v29`), returns the finite owner-catalogue slots, and keeps
   the immutable original credit receipt, consumed-consent anchor and nonce counter.
   Text29 producer reserves and requester DA bonds count in the bond's unavailable
   collateral beside the v11 sums.
2. **Independent redemption is an accepted spend.** A producer Final credit of
   Text29 uses the SAME unique credit identity as Final27
   (`native_final_credit_queue_v27(job, funding, settlement, payee)`), so audit32 and
   delivery33 verify it without any Text29-private row DTO (`namespace = 29`).
   Redemption is complete only when spend35 shows the exact original credit
   outpoint consumed by a non-coinbase transaction whose id is in the complete
   accepted-id list of an independently pinned chain block: the verifier recomputes
   `AcceptedIdMerkleBranchHash64(selected-parent root || sorted mergeset ids)` and
   compares it with the pinned header. Consensus acceptance implies maturity, prior
   unspentness and a valid payee signature; the DAA clock is re-checked against the
   owning ruleset's coinbase maturity. No producer, Panel seat or serving-node flag is
   an input. Current unspentness of a not-yet-spent credit is not claimed.
3. **Measurement Final is not A6/A8 evidence.** An isolated calibration34 devnet
   (`NativeFinalPurposeV34::IsolatedCalibration`, distinct genesis, pinned snapshot)
   may produce real Final/delivery/spend receipts for measurement. Every audit report
   names its class (`final_receipt_class`: `measurement-final` or `qualified-final`).
   The A6/A8 aggregator counts the `final` stage only for a `qualified-final`
   audit32 report and the `redemption` stage only when that report also carries a
   verified delivery33 and spend35; a measurement Final stays in the denominator as
   the named failure `MEASUREMENT_FINAL_ONLY`. The node and every auditor load the
   calibration snapshot through one shared factory, and the auditor refuses a node
   whose announced params fingerprint, schedule id or genesis differs from its own
   reconstruction. A qualified Final requires a shipping network whose Final27 policy
   has the `Qualified` purpose; no preset has one, and creating one is a user decision.

### II.14.59 Versioned length fields and lead defaults (2026-10-15)

> **Change marker — 2026-10-15 (RFC text amended).** Items 1–4 are *lead defaults
> pending user review* (reversible). Implementation is an unverified source checkpoint.
> No public preset, fence or release height changes.

**Versioned length fields (normative).** A job length is never reinterpreted: a change of
maximum, history growth rule or modality unit is a new contract version. Contract 36
(`LengthContractV36`) binds the program root, a history rule, the maximum positions and one
declaration per modality axis:

| Field | Meaning |
| --- | --- |
| `rule = FrozenV1 { history_bound }` | v1 semantics unchanged: `maximum_positions ≤` the program's frozen `history_bound` |
| `rule = Window8 { plan, window, selection_cap }` | the v8 window/selection relation (`flat_history8`); the plan root binds graph coordinates, row shape, window and cap; cost and evidence bounds are derived from that plan **at the requested maximum** (`HistorySelectionPlanV8::scope`) |
| `token { maximum, unit_bytes = 4, profile = 0 }` | exact u32-id axis, `maximum ≤ maximum_positions` |
| `patch` / `audio { maximum, unit_bytes, profile }` | RFC03 axes: committed bytes per patch / audio frame and the RFC03 encoding/preprocessing profile root |

A job commits its maximum lengths before Fund: every present axis is
`1..=maximum`, every absent axis is 0, and no claim or later slice can enlarge them.
For an unknown stopping point, Commit fixes the actual lengths and applies `check_actual`
against that original maximum; Fund never requires the future generated ids. A window
Text job's token axis counts evaluated positions (prompt plus generated ids fed back into
the decoder, excluding the final returned id that is not evaluated again). Attachment
checks the original request maximum, and Commit, Final and independent extraction check
the actual extent against the same Length36 contract. The
RFC03 patch/audio axes decode (so their bytes ride unjudged below their fence) but are refused
by name until their typed stage contract and fence ship (`MEDIA_LENGTHS_ARMABLE_V36 = false`).
A Text/Stage class that adopts contract 36 is itself a new class version; existing
Text29/Stage28 classes keep their v1/v28 meanings. Still open: the complete typed v8 graph
(HistAppend continuity, KV/state binding) and the RFC03 media stage contracts.

**Lead defaults (pending user review).**
1. *Stage28 credit identity.* Stage28 keeps its own credit identifier (fixed before its
   settlement exists). The audit record carries it as `payout_queue` with `namespace = 28`;
   audit extraction authenticates it against the original header and the immutable kind-14
   receipt; redemption33 skips only the v27 re-derivation for namespace 28. No consensus change.
2. *Master32 composite Final.* Composed at audit time from the components' individually
   genuine, settled Stage28 Finals in one pinned state's verified rows, the owning Stage28 policy
   and public tokens/outputs (each output authenticated against its component's trace
   openings). The composite is **not a consensus object**: no carrier, row or credit.
3. *Qualified Finals for validation.* A LOCAL purpose `LocalQualifiedValidation` judges Finals
   under the Qualified conditions but is bound to an isolated devnet genesis and loadable only
   through the v34 snapshot path (`palw-class native-calibration34 --purpose local-qualified`).
   It is never a public preset, t12/mainnet or release height. Reports mark
   `local_qualified_validation_network`.
4. *Below-fence rule.* While Final27 is inactive, funded actions 25–40 are neither rejected nor
   applied: validation passes them unjudged and the fold returns before any read or write, using
   the identical predicate (Final27 active ∧ OPV active).

**Real-checkpoint chain stages.** Register (class bound to a mature unrefuted source with its
derived maxima) and seat (job funded with the producer's original consent — the Panel-free
lane's seat) are re-derived from the same verified full aux opening as Final and redemption.

### II.14.60 Typed window graph v37 and the window class (2026-10-15)

> **Change marker — 2026-10-15 (RFC text amended; unverified source checkpoint).**
> New dormant fence `palw_window_class_v37` (absent on every preset, Some-only hashed,
> `Some(never())` collapsed, refused when armed except `always()` on an isolated
> calibration34 devnet). No release height.

`flat_history8` proves only the selection over an authenticated history image and leaves
that image's continuity open. **`WindowGraphV37`** closes it for a whole program:

1. **KV/state binding (append).** For every declared history (a layer's K, V or recurrent
   state image) and every position `p`, the newest row of the image at `p`
   (`H_p = min(p+1, window)`) equals that position's committed writer-node output.
2. **State continuity.** Every older row of the image at `p` equals the image at `p-1`,
   shifted by exactly one row once `p ≥ window`. A reset, skipped, duplicated or reordered
   row is a two-point counterexample (`WindowFaultV37`: `Append` or `Continuity{slot}`) whose
   points authenticate against the claim's segment roots; its filing/court bounds derive from
   the graph (`scope`), never from a declaration.
3. **Selection binding.** The v8 selection plan's `graph_root` is the outer graph's root and
   its source must be one of these continuity-bound histories (same node, dtype, row shape).

**Window class v37** (funded action 45) registers a class from one registered Text29 class:
its `LengthContractV36` must use the `Window8` rule whose plan is the graph's selection plan,
with the same program root and maximum positions; native re-derives the record (program, real
PC, inventory, length/graph/scope roots) from the authenticated Text29 class and the program's
frozen header. Registration creates no job, reward, consensus weight or Final right; the window
job lane (fund/commit/court using `WindowFaultV37` and the v8 selection court) is the next
class-version step. **A-2:** below `palw_window_class_v37` (or below Final27) action 45 is
neither rejected nor applied — validation passes it unjudged and the fold returns before any read
or write, with the identical predicate. The route decoder's funded action ceiling becomes 45.

#### II.14.60a Window-class job path (2026-10-15, unverified source checkpoint)

A window job **is a Text29 job**: preparation, producer consent, Fund, Commit, close/Final,
collection, audit32 (namespace 29), delivery33 and spend35 are exactly Text29's. Funded action
46 (`u16 37 ‖ job ‖ window class`) lets the job's **producer** opt its Funded, uncommitted job
into a registered window class of the same Text29 class — producer consent is required because
the window courts add liability beyond the original Text29 consent. Attachment re-derives the
window class, binds the graph to the actual program (`check_window_graph_program_v37`: node
count, flat slots, history `[min(p+1,W), row]` and writer `row` shapes at the boundary
positions), requires the job's maximum positions within the class's and both window court
envelopes within the job's original paid filing bound. A window-bound job additionally accepts,
through the same paid paged29 owner/Part/Assembly/Court path and the same conviction and
settlement, a filing in its own envelope (`u16 37, kind, len, body`; the frozen v25 envelope
keeps kinds 0..=2): kind 3 = `WindowFaultV37` (append/KV binding or continuity), kind 4 = the
job's deterministic v8 `HistorySelectionFaultV8` (`window_selection_job_v37`). Actions 45/46
ride unjudged below `palw_window_class_v37` or Final27 (A-2); the route decoder ceiling is 46.

**Source-audit correction (2026-10-15; implementation unverified).** Coordinates and
history/writer shapes alone do not bind a selection court. Registration and attachment
must additionally bind the program root, actual HistAppend state and input writer, the
actual selection input, and its Idx dtype and position-specific output shape. All court
work/scratch/restoration must fit the original paid envelope as well as filing bytes.
The frozen v1/v2 grammar refuses TopK on symbolic `H` and cannot express the required
`min(H, selection_cap)` output. Accordingly the source guard is a defensive refusal,
**not a completed positive window execution path**. A separate versioned execution/source
contract is still needed; the v37 declarations above and standalone v8 relation do not
establish that implementation, native Final or RFC02 completion.

### II.14.61 Genesis model set: eight text-generation models in one `.palwart` format (user decisions, 2026-10-15)

**This replaces the initial seven-model target below** (kept as history). The user named ten genesis models, dropped #7
(Gemma 4 26B-A4B, overlapping #8) and #9 (Qwen3-32B, overlapping #6), and chose the uncensored variant of each (huihui
abliterated; Dolphin where no huihui variant exists) — #8 included since 2026-10-16, rebuilt from huihui's abliterated
Qwen3.6-35B-A3B GGUF. Ids keep the original numbering. These
models are the next network's genesis (RFC-0019 edition 0, the 1.0 tier); testnet-12, its preset and its DAA 14,000 release scope
are unchanged. **Every genesis model is served at a 32K context (32,768 tokens; user decision 2026-10-16).** A PALWQ361 artifact
bakes its context into its header and rotary table, so #8 is rebuilt with `qwen36-convert --context 32768` from
`huihui-ai/Huihui-Qwen3.6-35B-A3B-abliterated-MTP-GGUF` @ `acd5abe0` (Q8_0), streamed both ends (a measuring pass, then an output
pass into `palwart pack --from-pipe`, bit-identical to the one-pass file), into the new `Misakachain/Huihui-Qwen3.6-35B-A3B-abliterated-PALW`;
the earlier 512-position `Misakachain/Qwen3.6-35B-A3B-PALW-runtime` stays as history. #1 is re-converted with the A16 converter at
`--n-ctx 32768` (the published 8k file stays as history).

**Scope: text generation only** (user policy, 2026-10-15). A genesis class maps token ids to next-token logits. Vision towers and
projectors (mmproj), image/audio/video embedders and processors, and multi-token-prediction (MTP) heads are not computed, not
covered, not admitted as claims and not rewarded; image paths will not be enabled. The artifact refuses such components by name
(`check_text_scope_v3`: job inputs, out-of-scope params, tensors and files, program kinds) and so does the genesis claim route
(`palw_genesis8_admits_input_v1`: anything but token ids).

| # | Source (pinned revision) | Architecture | License | Route |
| --- | --- | --- | --- | --- |
| 1 | `dphn/Dolphin3.0-Qwen2.5-1.5B` @ `60c996e2` (re-converted at `--n-ctx 32768`) | Qwen2 dense | Apache-2.0 | BASE-0 A16 |
| 2 | `huihui-ai/Huihui-Qwen3.5-2B-abliterated` @ `b2e291a6` | Qwen3.5 Gated-DeltaNet hybrid | Apache-2.0 | TIR |
| 3 | `huihui-ai/Huihui-Qwen3.5-9B-abliterated` @ `05b9e7c9` (tentative: no official Qwen3.8 9B) | Qwen3.5 GDN hybrid | Apache-2.0 | TIR |
| 4 | `huihui-ai/Huihui-gemma-4-12B-it-abliterated` @ `060ea173` | Gemma-4 Unified (dense, multimodal wrapper) | Apache-2.0 | TIR |
| 5 | `huihui-ai/Huihui-gpt-oss-20b-BF16-abliterated` @ `b73ec897` | gpt-oss MoE (sinks, sliding window) | Apache-2.0 | TIR |
| 6 | `huihui-ai/Huihui-Qwen3.8-27B-Coder390-EfficientThink-abliterated-GGUF` @ `a0b17c71`, bf16 GGUF | Qwen3.8 GDN hybrid (community SFT) | Apache-2.0 | TIR |
| 8 | `huihui-ai/Huihui-Qwen3.6-35B-A3B-abliterated-MTP-GGUF` @ `acd5abe0`, Q8_0 (rebuilt at `--context 32768`) | Qwen3.6 GDN hybrid + MoE | Apache-2.0 | PALWQ361 integer runtime |
| 10 | `huihui-ai/Llama-3.3-70B-Instruct-abliterated` @ `fa133346` | Llama 3 dense | Llama 3.3 | TIR (not required to be end-to-end adjudicable) |

Every genesis model ships as **one versioned `PALWART3` artifact** (`misaka/palw/tir/artifact/src/palwart_v3.rs`): an index and
streamed segments holding a canonical manifest (source repository and revision pin, license, attribution), the program record, the
per-architecture weight section (A16, PALWQ361 integer, TIR inventory; MXFP4 exact integer reserved), the tokenizer, chat template,
source configuration, license texts and calibration inputs. The legacy `.palwart`/`.palwtir`/`.palwq36` formats stay readable under
their own magics and identities (kept as inner roots, never reinterpreted); the catalog's `artifact_root` is the `PALWART3` root.
Published artifacts go to `Misakachain/<SourceName>-PALW` (#10's name begins with "Llama", its card says "Built with Llama", and
the Llama 3.3 license, Acceptable Use Policy and notice ship with it).

Calibration measures each site's activation range on the float reference (absmax, per-position and per-channel maxima); the
integer program, and every adjudication over it, is exact and deterministic for any pinned calibration set, so the calibration
length is a fit choice, not a correctness one. A recurrent (Gated DeltaNet) class is calibrated on one sequence as long as the
context it serves (freeze-v1 §5.2, enforced by the converter): #2, #3 and #6 calibrate on one 32,768-token sequence. Dense classes
use four 512-token texts and declare 32,768. The texts are git blobs at one pinned commit; the token file and the measured
statistics travel in the artifact and the manifest records texts, tokenizer, lengths and policy. The float reference's threaded
kernels and its node-by-node runs of positions are bit-identical to the one-thread, position-by-position reference, so the
statistics depend neither on the core count nor on the run length. The memory design for the long context (one full-sequence
carry, no score matrix, opt-in carry spill, RAM accounting) is [RFC-0020](0020-long-context-calibration-memory.md). A fit guard
(`palw-tir-fidelity --exec`: held-out short text, and the held-out next 32K tokens with a 32-window drift curve; mean KL <= 0.1,
top-1 >= 0.8, every window's KL <= 0.1) withholds the index of a class outside the tolerance where it can be measured on the
conversion host. The genesis list is
`consensus/core/src/palw_genesis8_catalog_v1.rs` (dormant: edition 0 is built only from supplied roots); the conversion pipeline is
`scripts/genesis/genesis10_pipeline.py`; per-model status, coverage (architecture × layer kind) and open items are in
`docs/design/palw/genesis8-status.md`.

Adjudication is unchanged in kind (II.14.62): sampled deterministic re-execution, public localization and the deterministic court;
genesis listing is economic only, and every claim still needs its own Gate C approval. Open at this writing: registration binding
of the `PALWART3` root and K2-TIR kernel activation.

#### History: the initial seven-model activation target (user decision, 2026-10-15; superseded the same day)

The initial rewarded set must include all seven models below: the six dense size
tiers remain, and the 35B-A3B hybrid MoE is an additional model, not a replacement
for 32B dense. All seven target block production, coinbase and Final weight from
the start of the new network. This is a completion requirement, not evidence of
present eligibility or an instruction to bypass admission.

| Tier | Selected model repository |
| --- | --- |
| 1.5B | `Misakachain/Qwen2.5-1.5B-PALW-A16-runtime` (original `Qwen/Qwen2.5-1.5B-Instruct`) |
| 8B | `meta-llama/Llama-3.1-8B-Instruct` |
| 14B | `Qwen/Qwen3-14B` |
| 24B | `mistralai/Mistral-Small-3.2-24B-Instruct-2506` |
| 32B | `Qwen/Qwen3-32B` |
| 70B | `meta-llama/Llama-3.3-70B-Instruct` |
| 35B-A3B | `Misakachain/Qwen3.6-35B-A3B-PALW-runtime` |

The user fixed the 35B-A3B target to the original **PALWQ361 integer runtime**:
`palw-runtime/qwen36-35b-a3b.palwq36`, 36,492,831,232 bytes, SHA-256
`5fe1d15caf0e544b718a4a2398db4f902b9a6722b266dd53824fbc9723578b29`.
The other `.palwq36` variant and the Claude-related GGUF files do not substitute
for this artifact. Its tokenizer, complete original context and canonical
conversion still require their own pinned identities and execution evidence.

The dated publisher revisions and Git/LFS file inventory are recorded in
`docs/design/palw/tir/launch/initial-seven-models-v1.json`. They are preparation
metadata: every selected runtime variant, canonical artifact/inventory, real PC,
tokenizer, context, random/decode rule and source conversion must still be pinned
before execution. Existing A16 and Qwen36 runtime formats do not automatically
become Source28/TIR artifacts or inherit a new class's rights. Missing pins remain
`NOT_RUN`, not a silently substituted checkpoint or a successful release gate.

The launch gate requires **7/7**, with independently reproduced full advertised
tasks, honest and corrupted-trace courts, native registration/funding, genuine
Final, coinbase delivery and accepted redemption under the target ruleset. Mistral's
vision encoder/projector are part of complete-model coverage; the MoE routing,
expert weights and recurrent state remain included in the 35B model. A nominal
4-bit weight size is neither verifier RAM nor an admissible cost quote. For 70B,
measure complete preparation, verification and evidence carriage within the
owning Panel=1 one-day DAA opportunity; no unmeasured smaller context may stand
for the full requested class.

The existing qualified-bond allocation (`alpha = 1.5`, 30-day average) and shared
Q/B/R/F caps apply. Seven entries do not imply equal one-seventh coinbase shares,
synthetic founding bonds or a model-specific multiplier. Keep the statistical
A6/A8 populations and their failure denominators unchanged: this launch set is
a separate all-required engineering gate. Activation is held until every model
passes, including the added MoE; no shipping preset is changed merely by listing
the target models here.

### II.14.62 Verification assumptions (user decision, 2026-10-15)

[PRINCIPLES §8](../PRINCIPLES.md#8-llm計算の暗号学的証明を使用しない--2026-10-15ユーザー決定)
governs this RFC and every implementation and future plan. Use sampled replay,
algebraic spot checks, public localization, deterministic adjudication and
economic deterrence. Cryptographic proofs of model computation are permanently
excluded. Merkle openings, tensor commitments, hashes and signatures authenticate
data identity and origin; they do not establish correctness of the whole model
computation.

Consensus credit authentication requires the prescribed randomly selected
validator approvals under an explicit honest-fraction assumption. A matching
local replay, an expired challenge period, an optimistic component Final, a
complete Master aggregate or a private escrow payment does not replace those
approvals. The all-seven block/coinbase/Final-weight gate must inspect the actual
ordinary model/claim approval path and original bond caps. Report missing
approvals, unknown detection rates and absent execution evidence explicitly.

### II.14.63 Unsupported models and consensus upgrades (user decision, 2026-10-15)

When a model cannot be supported under the current RFC02 consensus rules,
implement the required **hard fork or soft fork** to support it. Record the exact
model/task/context and missing feature. Existing-rule frontend or lowering
changes need no consensus change; a new primitive, grammar or validity extension
uses an explicitly versioned hard fork when old nodes would disagree. Use a
soft fork only when the new validity conditions restrict the old valid set and
old nodes accept the resulting blocks. Determine compatibility from the actual
rules; never reinterpret frozen old bytes or primitive semantics.

Both paths need explicit activation, node/migration implementation, original
source and full-context evidence, independent replay and public deterministic
court, DA/resource/deadline/economic checks, sampled-validator approvals, Final,
redemption and reorg verification. Unsupported models earn no provisional rights
by bypassing those checks. PRINCIPLES §8 remains mandatory in either upgrade.
The current implementation and validation backlog is tracked in
[the remaining-work document](../design/palw/tir/rfc0002-remaining-work-2026-10-15.md).
