# t11 Relaunch 5f — genesis card

> Cleanup, 2026-10-10: The algo-4/5 driver and its tests have been removed. The V1 runtime discussion below records the earlier launch; current network behavior follows the V2 preset.

> **Token identity (2026-10-07):** The token name is **Misaka** and its ticker is **BILI** ([ADR-0174](../adr/0174-token-name-misaka-ticker-bili-address-prefix-unchanged.md)). MSK in retained measurements, quotations, command/output examples, identifiers or chain-ID mnemonics is a legacy label for the same coin; it does not change amounts, units, protocol IDs or address prefixes.

**Branch** `palw-testnet-5f` · **tip at writing** `fc496331` · public at github.com/MISAKA-BTC/misakas

This is the card the cut is made from. Every number here is derived or measured; where a value is
someone's decision rather than an arithmetic consequence, it says so and says whose.

> **Every `file.rs:NNNN` citation below resolves against `palw-adr0082-impl` at `aa049f96`, not
> against this branch.** The card describes the POST-MERGE cut, so it necessarily cites code 5f does
> not have yet — `palw_attn_court_v1.rs` does not exist here at all, and `prompt_ids_merkle` appears
> zero times in this branch's `params.rs`. That is legitimate and it is also exactly how six wrong
> citations got written in one sitting: read from one tree, committed to another, and wrong in a way
> no test suite can see. **`scripts/ci/check-doc-citations.sh <doc> <tree>` resolves every citation and
> prints the line it lands on**; run it against the merged tree at the freeze and read the output,
> because a citation that resolves is not the same as a citation that is right. Caught by the
> session verifying this card, not by the one writing it.
>
> **And relabelling is not a null operation.** Declaring the card impl-relative fixed those six and
> silently INVERTED one that had been right against 5f — `golden_vector_ids_are_frozen` in
> `palw_freeprompt_v3.rs`, 1521 on this branch and **1643** on impl — inside the very sentence
> warning that the function has two homes. So the freeze check is the TWO-tree form:
> `check-doc-citations.sh <doc> <tree-a> <tree-b>` lists only the citations that resolve
> DIFFERENTLY, and those are the only ones any tree label can hurt. Seven of this card's citations
> are tree-dependent; everything it does not list is immune to the label.

---

## 0. This is a RE-GENESIS, not an upgrade

The genesis UTXO set changes — the community premine entries are added — so the **genesis hash
moves**. There is no upgrade path from 5e: no earlier appdir and no earlier binary can join, and
the failure is at handshake rather than at a rule, which is strictly less legible than a ruleset
mismatch. Every host wipes.

Stating it as a rule and not as history matters, because the previous page said the genesis card
"has not moved since 5c, only the ruleset over it" — true as history, and read as a promise it was
never making.

### The name is already contested, and the relaunch adds one more claimant

Measured on the live fleet, six hours of `misaka-t11-node0`'s own log:

    over 24.3 h on the public entry node (.t11, port 26311)
    genesis mismatches           18,034   from 10 distinct peers
    consensus params mismatches   3,074
    distinct FOREIGN genesis hashes    THREE — the fourth value in the log is ours
      4b619a1a…  8,352    8d2002cc…  6,377  (Relaunch 4's, still dialling)
      c664a224…  3,311    08e9c8a4…  18,040 as `local`, once per rejection line
    successful inbound connections    67, from 9 distinct peers; 6 connected now

The three foreign counts sum to 18,040 exactly, so they account for every line and there is no
fourth. **Ten stuck peers retrying every ~48 seconds produce eighteen thousand rejections** — which
is the figure to give a joiner, because "18,034 mismatches" reads like a swarm and ten misconfigured
nodes on a retry loop is what it is.

So the node is **not** isolated — it has working peers — and at the same time it is rejecting
thousands of dials from nodes that answer to `misaka-testnet-11` and build on something else. **At
least four chains share this network name right now**, and 5f will be the fifth.

Two consequences for the announcement, neither optional:

1. **A joiner must wipe.** Not "should" — an old appdir cannot handshake, and the failure it prints
   is a genesis or params mismatch, which reads like a bug in the new build rather than the expected
   result of not wiping.
2. **The old chains keep answering.** Somebody who points an old node at a seed will keep syncing
   something, and it will not be this network. The genesis hash is the only thing that tells them
   apart, so it belongs in the announcement as a value to check, not as trivia.

---

## 1. Fences to arm at genesis

There are **fourteen** `Option<ForkActivation>` fences, not eleven, and "None on every shipped
preset" is true only of **testnet-11**. Measured:

    testnet-11   0 armed
    devnet       5 armed — palw_heartbeat, palw_attempt_work, palw_context_ladder,
                           palw_uncertified_weightless, palw_kary_court

**That is not merely a correction to a count — devnet already runs the exact configuration §1 tells
the operator to arm.** `palw_context_ladder`, `palw_uncertified_weightless` and `palw_kary_court`
are all `Some(ForkActivation::always())` there today. So the arming below is not an untried
combination being attempted for the first time on a public network: it is the devnet preset's
standing configuration, and `DEVNET_PARAMS` is the worked example to diff against when §7b's
checklist disagrees with what a build does.

Three are armed at genesis on testnet-11 and the rest stay `None`.

| fence | at genesis | why |
|---|---|---|
| `palw_context_ladder` | **`None` — DO NOT ARM** | **This row has now been wrong twice and is right for a third reason.** It first said ARM on a false premise. It then said DO NOT ARM because *"nothing reads the fence"* — true on `palw-testnet-5f`, where `palw_context_ladder_at` does not exist and the processor never reads it, and **false on `palw-adr0082-impl`**, where the ClassRegistered arm (`processor.rs:6162`) and 5b's admission-shape accessor both read it. *Worse, I argued it from the absence of `palw_context_ladder_active_at` — a name I invented; the real one is `palw_context_ladder_at`, so my sentence stays true while its conclusion went false.* **The reason that survives is the shape, measured on the preset that ships:** t11 is `court: Some(arity 2, Flat ids, window 3000), ladder: None`, and that is the shape FG proved the 512 row admits under. Arming would move t11 to devnet's shape — **the one nothing has validated for t11's registered set** — and move the fingerprint for a rule only post-genesis registrations would feel. *Do not arm it because the shape it would produce is the unmeasured one.* |
| `palw_uncertified_weightless` | **ARM, `ForkActivation::always()`** | genesis is the ONLY moment — `validate_palw_v2` refuses any other height (`params.rs:1490`). **And unlike the ladder, this one HAS a reader**: `palw_class_bears_weight_v2` (`palw_state_v2.rs:1183`) is `!uncertified_weightless \|\| share > 0`, called from `palw_claim_safe_contribution_v2` and the safe-weight accumulation at `:4589`, with the consistency check branching on it at `:4770`. It gates whether an uncertified class's `pwu` enters safe weight — ADR-0069 D7, on the fold that is the production path. |
| `palw_kary_court` | **ARM, `ForkActivation::always()`** | **ADR-0082's, does not exist yet.** Without it the registered row is admitted and UNPROSECUTABLE — see §3. A bare fence: no companion value, no bundle field. `dissection_arity` stays 2 on every preset and the fence overrides it with the derived arity. |
| `palw_prompt_ids_merkle` | `None` — **and it cannot be armed** | ADR-0082's. Not needed at the registered width: flat ids are 82,080 against a budget of 83,333. It becomes REQUIRED above about n_ctx 1,024 — but as of FD it is no longer a fence anyone may arm at that point: **`validate_palw_v2` REFUSES a ruleset that arms it** (`config/params.rs:1595`, on impl; 2310 is only the doc comment about it), because the commitment form it selects does not ship. Registering a wider row is therefore blocked on implementing the form, not on flipping the fence. |
| `palw_fp_decode_rules` | `None` | ADR-0082 stream H's (decode leaves earn, seeded argmax). Not a prosecutability condition and not on the acceptance path; deferred so the cut arms only what it must. |
| the other nine | `None` | nothing in this cut needs them; a fence armed without a shipping thing to obey it is the ADR-0065 D1 mistake |

**A fence that must be armed at genesis and does not exist yet is a scheduling fact, not a
contradiction** — it lands with ADR-0082 (§7), and the card names it now so the arming is not
discovered at cut time.

**The two fences look alike and are opposites — the difference is one grep, and it is the grep to
run before arming anything.** Both are `Option<ForkActivation>`, both were listed ARM here, both
reach `palw_ruleset_id_v2`. One is wired to the state fold that decides safe weight; the other is
wired to nothing. *The name of a fence tells you what it was meant to do; only its readers tell you
what it does.* The check is: does an accessor exist, and does anything outside `params.rs` call it?

**"Arming the ladder is TWO moves" was half right: only the SECOND move exists.** The bundle's
`PalwCourtParamsV2::max_step_leaf_count` is the whole mechanism; `Params::palw_context_ladder` has
no reader. Setting the fence and not the field produces a build that looks armed and prices the old
row — which was the real warning, and it survives. Setting the field is what moves the width.

*Arming a fence nothing reads is the ADR-0065 D1 mistake — a rule armed with no shipping thing to
obey it — which is the last row of this very table. I wrote the row and the warning against it in
the same section, and it took FG registering the row with the fence dormant to show which was
right.*

**And it is armed to `PALW_RC_COURT_MAX_STEP_LEAF_COUNT` = 2^26 — not to 2^32.** Naming the field
without naming its value is the same defect one level down. 2^32 is not available at this cut and
the refusal is arithmetic, not policy: at 2^32 the RC admits **no arity at all**, because the
cheapest honest exchange is 73 moves (at arity 32 or 64) and `73 × 42 = 3,066` is already past the
3,000-DAA window before the 216-DAA assembly reserve is added. `palw_court_arity_v1` returns `None`
there, which is ADR-0082 Z4's refusal working. Going deeper than 2^26 needs the window to grow, the
clock to shrink, or the leaf ladder to become k-ary for real — all three are genesis decisions, and
none of them is in this cut.

---

## 2. Class set at genesis

| class | registered | seated | note |
|---|---|---|---|
| BASE-0 floor | yes | yes | the floor must have a producer or DAA stops and the chain cannot leave the state by itself |
| dense A16 **512 row** | **yes** | yes | the only wide row registered — see the width argument below, which is not the one this card first gave |
| hybrid QWEN36 | **YES** | — | registered at 489‰ declared (957‰ after dense dilution). **This card excluded it for a reason that expired twice — see below.** |
| demonstration class | yes | **SEAT AT GENESIS** | a class registered post-genesis has NO epoch budget until the next boundary |

**Why the hybrid row IS registered, after this card spent two revisions saying it should not be.**
Two weak arguments were on the table first — a 0.43% admission margin, and graph-v4's composition
being `NotPriceable` — and were replaced by one that felt binding and was not:

    hybrid graph-v5, n_ctx   128:  200,604 bytes = 3 carriers
    hybrid graph-v5, n_ctx   256:  200,668 bytes = 3 carriers
    hybrid graph-v5, n_ctx   512:  200,732 bytes = 3 carriers

**Three carriers, at every width — against a ceiling of TWENTY-SEVEN.** That is 24 to spare, and
the argument dies there. It was written when a class needing more than one carrier could not file at
all; W6's two acceptance checks are in `palw_court_v2` and the split path is open. **I carried the
conclusion past the change that falsified it, twice, restating it each time as though restating were
checking.** Removing the row now would move the dilution and collateral arithmetic to satisfy a
paragraph, which is the worst reason there is to move a genesis input.

*The superseded argument is kept below, because the shape of the mistake is the useful part: a
disqualification that was true, became false, and went on reading as true because nothing in the
sentence expired.*

Superseded — this is not a wide-row problem — it is the
recurrence's interval replay evidence, which does not shrink at any context. So the hybrid cannot
close on a shipped build at ANY width until W6/W7 open the split path (§5), and a registered class
whose disputes cannot be defended is worse than an absent one: the honest party loses by deadline.
Flat correctness fact, not a margin. *(Swept by 1c on a detached `palw-adr0082-f-cost`.)*

**No operator pubkey may appear in two `BondRegistered` rows.** The genesis tool PANICS on this,
it does not warn.

### Why 512, and why the first two answers were the wrong quantity

Three different numbers are all "tokens for a kind", and this card quoted the wrong one twice:

| quantity | value | what it actually answers |
|---|---|---|
| grammar floor | cad 38, music 60, scene 104 | the shortest legal non-degenerate answer. **NOT "fits at n_ctx 128"** — see the prompt row |
| **the prompt itself** | **134 tokens**, ChatML, measured on the live gateway | added to every floor: cad **172**, music **194**, scene **238**. Nothing fits at 128 |
| what the model gates needed | 256, both tiers | the width at which a checkpoint's own answers parsed |
| **what the shipped corpus costs** | cad 66, **music 261, scene 286** | **the answers a demonstration actually publishes** |

Only the third is binding. At n_ctx 256 the decode budget is 247, and **both the MIDI and the GLB
that were derived, validated through mido / pygltflib / numpy-stl and shown to a human are over
it** — 261 and 286 against 247. A launch sized on the floors or on the gates registers a class that
can express every kind and **cannot emit the artifacts the announcement is about**, and the failure
arrives as a worker refusal, after the announcement, on the one request the announcement invites.

At 512 the budget is 503 and the demonstration set closes. Whole corpus, for whoever revisits this:

    budget   119 (n_ctx  128)  ->   9/34 answers fit
    budget   247 (n_ctx  256)  ->  21/34
    budget   503 (n_ctx  512)  ->  24/34
    budget 1,015 (n_ctx 1024)  ->  25/34
    budget 2,039 (n_ctx 2048)  ->  28/34

The tail is grammar coverage rather than demonstration: `map/05-large-dungeon` is 11,222 tokens and
the `9x-*` entries exist to be refused.

**Two ceilings, and the card quoted only one of them.** On the CLOSE side the flatness makes width
nearly free: 80,440 bytes at 256 against 80,504 at 512, one carrier either way, sixty-four bytes
apart. That is what this card said, and it said it as though 1,024 were simply the next rung.

**And a third confirmation arrived from the chain itself, not from a corpus.** Stage 4 of the
end-to-end drill PASSED — the panel registered the class, every validator carried `FamilyCertified`
and `ClassLaneCertified`, the chain graded both, and `/health` reported `fp_certified` true and the
lane open. Stage 5 then refused a **one-token** job:

    prompt 134 + decode ceiling 1 exceeds max_context_tokens 16

That is the whole certification path working and the width being the only thing left — and it is
what turns the 134 into a measurement rather than an estimate. It also says the first row of the
table above was quoted wrong wherever it appeared: a grammar floor is what the ANSWER costs, and no
job is only its answer. `scene`'s 104 needs 238 positions to be asked for at all.

**So "why 512" has a measured answer in three independent directions**: 238 is the floor once the
prompt is counted, 286 is what the shipped `scene` corpus actually costs, and 574 is the widest row
the 2^26 ladder admits. 512 is the first artifact-stated width above the first two and inside the
third. It is not a round number anybody liked. (2^24's 156 would not have covered even `scene`'s
238, which confirms the ladder choice from the same direction.)

**It is not, on the LADDER side.** At the chosen 2^26 the widest admissible row is **574** — so 512
fits with about twelve per cent of margin and **1,024 does not fit at all.** 1,024 needs 2^28. So
512 is not merely "the width a demonstration was measured against"; it is also close to the ceiling
of the ladder the genesis is arming, and the next rung is a different cap rather than a rounding.

Both sentences are true and only together are they the answer. A width has to clear the close budget
AND the ladder, and this card had been reasoning about the first while quoting the second's
numbers — the fifth time a figure measured under one configuration has been read as though it held
under another, and the first where the figure was this card's own.

**And the width is right for BOTH lanes, measured rather than assumed.** The QWEN36 lane uses a
different tokenizer — the GGUF's own `tokenizer.ggml.*`, 248,320 tokens against the dense lane's
151,936 — so its costs did not have to be the dense ones. They are, exactly:

    cad/01-extrude-l-bracket     qwen36  66   dense  66   (+0)
    music/03-overlapping-melody  qwen36 261   dense 261   (+0)
    scene/02-hierarchy           qwen36 286   dense 286   (+0)

The reason it is durable rather than lucky: **a canonical DSL is ASCII JSON, and the two
vocabularies coincide over that range** — the larger one's extra 96,384 entries are elsewhere. A
grammar that ever admits non-ASCII string content does not inherit this and must re-measure.

*The agreement was only worth recording because the instrument was first shown capable of
disagreeing:* a tokenizer built from unread merges degrades to something byte-ish, and two degraded
tokenizers agree on everything — which would read exactly like a +0. The measurement asserts the
vocabularies differ in size AND that probes actually diverge (`Ω≈ç√∫` is 6 tokens against 5; two
musical-keyboard emoji, 6 against 2), so a degenerate load fails instead of producing a comfortable
+0.

**Third confirmation, from the artifact itself:** `qwen25-1.5b-a16.palwart` declares
`max_position = 512` in its own header. The registered row, the artifact on disk, and the
demonstration corpus all agree at 512. *(Corpus token counts measured by 1c with the shipped Qwen2.5
tokenizer; header decoded here.)*

---

## 3. ADR-0082 is a precondition, not an optimisation

This is the finding that changed the shape of the cut, and it is worth stating in full because the
earlier framing — "0082 makes it cheaper and wider, not possible" — was wrong and was believed by
three sessions.

Carrier is `PALW_OBJECT_CHUNK_MAX_BYTES` = 100,000 bytes. The `PalwStepBindingV2` the mempool
charges for but the court does not is 13,996 at its widest.

> **Every close figure on this card carries its ARITY *and its PROMPT-IDS FORM*, because three of
> them looked like disagreements and were one measurement under three courts.**
>
> The third: `classes.rs`'s pin asserts **81,599 B** and FG reports **81,312 B** for the same row.
> Both are correct. The test's own output line says which court it used — *"arity 2 **Merkle ids**
> … binding close 81599 B"* — and `kary_court(&bundle)` takes `dissection_arity` and
> `window_court_daa` from the bundle and **hardcodes `prompt_ids_form: MerkleV1`**. The shipped
> bundle cannot be Merkle: `validate_palw_v2` refuses to assemble one, because *"no writer or
> checker on this build reads it: every producer still commits the flat prompt-ids digest"*.
> **So 81,599 is a court the network refuses to run and 81,312 is the shipped figure.**
>
> *A helper that takes two of three fields from the real bundle and one from a literal produces a
> number that LOOKS bundle-derived and is not* — the same defect as pricing the cache-write route
> by hand, one field over, in a pin that passes and honestly prints the configuration nobody
> checked it against. `82,719 − 81,599 = 1,120` is exactly the
> arity-16 move disclosure, and the difference was already named in a test's own comment. **The
> genesis derives arity 2** from the v5 row in `genesis_objects`, on both the RC and devnet bundles
> — not the 4 a brief assumed, not the 16 an early sweep measured at. A byte count without its arity
> is a number from a court nobody is running.

**Every graph-v5 figure below is UNDER THE DISSECTION COURT.** This is not a footnote: under the
shipped BINARY court a fused leaf's terminal check opens the whole history it reads — about 1 MB at
n_ctx 512, twelve to thirteen carriers — which §5 shuts. So a graph-v5 row registered with only the
ladder and weightless fences armed is admitted and **unprosecutable**, and the number that says
otherwise was measured under a court the build would not be running. `palw_kary_court` is what
makes the table true, which is why §1 arms it.

**§3's central claim is now MEASURED, not argued** — priced at the ruleset's own 2^26 ladder on
`5f + impl(4ffb2b26)`, which is the first time the "precondition, not optimisation" line has had a
number under it:

    RC ceiling                        2,250,000 B = 27 chunks
    graph-v2/v3 @ 512                 1,999,729 B = 24 chunks   FITS
    graph-v5    @ 512, no dissection  3,446,708 B = 42 chunks   OVER THE CEILING
    graph-v5    @ 512, dissection     (FD's derivation)  4 chunks

So "a graph-v5 row registered with only the ladder and weightless fences armed is admitted and
unprosecutable" is **42 against 27** — refused at acceptance, by fifteen carriers. The dissection
court is what takes it to 4. That is the whole of §1's reason for arming `palw_kary_court`, in one
line, and it can now be re-derived by anyone rather than believed.

**Nor does the ladder bind either row — and here too v5 has the larger margin.** Worst-case step
leaf counts against the ruleset's 2^26, through `worst_case_step_leaf_count_capped_v1` at the
ruleset's ladder (not the un-suffixed form, which assumes 2^22 and refuses both):

    ruleset ladder cap            67,108,864
    graph-v2/v3 @ 512             59,000,848   FITS, margin 8,108,016   (12.1%)
    graph-v5    @ 512             52,778,128   FITS, margin 14,330,736  (21.4%)

`59,000,848` is the same number `palw-certify bind` printed independently for the v2 row, which is
two routes agreeing. The fused site removes leaves as well as kernels and carriers, so **every one
of the three ceilings this cut cares about — ladder, vectors, close — has more room under v5 than
under v2.** That is the fourth independent reason for the row we register, and none of them is the
fusion being interesting.

**The certification vector cap does not bind either row, and v5 is the cheaper of the two.** Measured
as an upper bound from the profile alone (`2 × |distinct (table, kernel) pairs|`, the 2 being prefill
and decode; the drill's real count can only be lower, since a leaf whose capture the material does
not hold is skipped):

    graph-v2/v3 @ 512   12 kernels, 16 (table,kernel) pairs, vectors <= 32   cap 32  FITS
    graph-v5    @ 512   10 kernels, 14 (table,kernel) pairs, vectors <= 28   cap 32  FITS

Fusing the four-node attention site into one **removes two distinct kernels**, so the row this
genesis registers needs fewer vectors than the graph-v2 row that sits exactly at the cap. An upper
bound is the right instrument here: at or below the cap it cannot bind, and only a number above
would have needed the full drill. So `PALW_CERTIFICATION_MAX_VECTORS` stays 32 and the hybrid's 74
is deferred with its refusal asserted by name — see §5.

*(That deferral is load-bearing rather than lazy: `PALW_CERTIFICATION_MASS_PER_VECTOR` is
`(CHUNK_MAX_BYTES × CHUNK_MAX_COUNT) / MAX_VECTORS`, so the per-vector price is DERIVED FROM THE
CAP. Raising the cap does not raise the fee — it lowers the price of each re-execution and leaves
the total identical, buying validators 2.31× the grading work for the same payment. Any future raise
must decouple the mass rule in the same change, or it is a fee cut wearing a bound's clothes.)*

**And the same table answers a real strategic question, which is why it is worth having.** A
graph-v2/v3 row at 512 **fits without ADR-0082 at all** — 24 chunks against 27, no fused site, no
court arming, and its 12 kernels are already covered by the shipped A16 family. So 0082 is not a
precondition for *a 512 class*; it is a precondition for *the v5 512 class*. The card said the
former and meant the latter, and the distinction is only visible once both rows are priced.

**We stay with graph-v5, and the reason is the close, not the fusion.** 24 carriers is a 0.3375 MSK
assembly deposit and a 192-DAA reserve on every close, against 4 carriers and 32 DAA — and that
reserve is charged to the court window whether or not anyone ever files, which is what compressed
the turn deadline in the first place. A v2 row would ship a class every honest dispute of which
costs six times what it needs to.

*(This correction is the same defect class as everything else on this card: a figure measured under
one configuration, quoted as if it held under another. It was caught by the session that derived
it, reading its own label — "dissection court, arity 16, Merkle prompt ids".)*

### …and the same thing again, one axis over: the EVIDENCE ROUTE

The court must be able to play whichever route the disputed position needs, and the two routes do
not cost the same. Dense graph-v5 @ 512, dissection court, 2^32 ladder, kv_dim-wide tiles:

| route | bottom opening | whole close | chunks |
|---|---|---|---|
| checkpoint | 41,997 | 82,719 | **1** |
| cache-write (rows after the last checkpoint, one leaf per row with its own 2 KiB path) | 175,297 | 216,019 | **3** |

**And the dense tier has no checkpoints at prefill positions today** — the leg checkpoints per
decode call. So a dispute at any prefill position, or at a decode position whose tile straddles the
last checkpoint, is the three-chunk close, which §5 cannot file.

**Therefore, as things stand, the dense row is prosecutable only for the positions the checkpoint
route happens to cover, and that is not "prosecutable".** The honest sentence until this closes is:
*three carriers on the cache-write route, one on the checkpoint route.*

**Stream K has landed and the claim is now unconditional.** With a checkpoint at every position the
bottom opening is **40,461 bytes = 0.49 carriers at EVERY position class** — prefill, first decode,
tile-aligned, straddling a tile boundary, and last — measured per class rather than averaged. The
close falls from 216,019 (3 chunks) to **82,719 = ONE chunk**, binding `attn[7] AttnFused`, and
*(both figures under this section's `2^32` ladder. The SHIPPED close, on t11's dormant ladder, is
**81,312** — what carries out of this comparison is the RATIO, not either absolute.)*
82,911 at n_ctx 4,096. Per-position retention is **zero**: the fold keeps no chunk bytes, where a
chunk-retaining capture at 16 positions would have held 1,114,112.

**And the cache-write route was not merely expensive — it was unsound.** K found a K/V series swap
admissible on it, which convicts an honest executor. It is REFUSED now for any class that
checkpoints every position, so the route that could not be carried is also the route that could not
be trusted, and removing it closes the arming blocker for `palw_kary_court` rather than working
around it.

One design fact to carry: the anchor sits at **p+1** — the checkpoint written once position p's own
K/V rows exist — not at p−1 plus a residue. That single change took the dense close from 93,367
(2 chunks) to 82,719 (1).

Hybrid graph-v5 is 274,460 = 4 chunks on the same derivation, bound by the recurrence replay
evidence. It is unregistered at genesis (§2) and will need W6/W7's split acceptance regardless.

| row | close proof | + binding | carriers | fileable |
|---|---|---|---|---|
| graph-v2/v3 dense @ 512, binary court (today) | 1,154,673 | 1,168,669 | 14 | **no** |
| graph-v5 dense @ 512, **binary** court | ~1,000,000 | — | 12–13 | **no** |
| graph-v5 dense @ 512, **dissection** court, **arity 16** | 80,504 | **94,500** | **1** | **yes** |
| graph-v5 dense @ 512, **dissection** court, **arity 2 — what genesis derives** | **81,599** | 95,595 | **1** | **yes** |
| graph-v5 hybrid @ 512, dissection court | 200,732 | — | 3 | no |

**How flat "flat" is, swept rather than interpolated** — graph-v5 dense, every registrable width:

| n_ctx | close proof | carriers | decode budget |
|---|---|---|---|
| 128 | 80,376 | 1 | 119 |
| 256 | 80,440 | 1 | 247 |
| 512 | 80,504 | 1 | 503 |
| 1,024 | 80,568 | 1 | 1,015 |
| 2,048 | 80,632 | 1 | 2,039 |
| 4,096 | 80,696 | 1 | 4,087 |

**64 bytes per doubling — thirty-two times the context for 320 bytes.** That is the sentence to put
in front of someone who has to believe it, and it is better than "the close stops growing with
n_ctx". It also means **512 is not a compromise**: 1,024 costs 64 more bytes and is equally
prosecutable. The width is chosen by what the model gate measured, not by what the close can
afford. *(Swept by 1c.)*

**Admissible and prosecutable are different properties**, and the tree had only ever measured the
first. Swept against what can actually be FILED:

    n_ctx 30 -> 81,849 bytes = 1 carrier   prosecutable
    n_ctx 32 -> 85,953 bytes = 2 carriers  admissible, disputes cannot be defended

The widest prosecutable dense row today is **n_ctx 30**, decode budget **21 tokens**, and the
grammar floors are cad 38, music 60, scene 104. **Nothing fits.** So without ADR-0082 the
demonstration is not expensive — it is impossible.

**Derived, and independently confirmed twice** (a 512-row table and the genesis-set derivation
landed on the same integers): dense A16 @ 512 = 1,154,673 binding `attn[10]`; hybrid QWEN36 @ 512 =
2,240,241 binding `attn[15]`; the set gives **27 = `DEFAULT_MAX_CLOSE_CHUNKS`**. The shipped
constant IS the derivation — nothing on this card corrects it.

`dissection_arity` stays **2** on every preset until its fence arms. **The court's arity derivation
at the RC selects 2** — not the 4 an earlier draft of this card recorded, and not the ADR's worked
16. Verified by running on `palw-adr0082-impl` at `aa049f96`
(`the_rcs_derived_deadline_selects_an_arity_for_its_own_row_and_none_for_the_fences`):

| quantity | value |
|---|---|
| window / clock | 3,000 DAA / **42** |
| ladder | 2^26 |
| RC 512 row | arity **2** — 26 binary ladder rounds + 5 history rounds |
| moves | `2 × (26 + 5) + 2 + 1` = **65** |
| worst-case duration | 65 × 42 = **2,730** |
| assembly reserve | **216** (27 carriers) |
| total against the window | 2,730 + 216 = **2,946** < 3,000 |

The dense graph-v5 512 row — the row this genesis registers — derives arity **2** as well, at the
8-lane count it actually disputes. *The four numbers this table replaces (arity 4, 48 moves, 2,160
DAA, a 45 clock) were each correct when written and none of them survived FD; a figure is only as
current as the tree it was last read from.*

### Two derivations the cut deliberately does NOT take

Both were raised by fixer FD with the work already done and correct, and both are refused for the
cut. Recording them here because a derivation that exists and is not used looks like an oversight
to the next reader, and it is not one.

**M-5 — `court_max_close_bytes` keeps its literals.** FD built the derivation behind the assembler
(`palw_derived_court_max_close_bytes_v1`) and touched no shipped constant. Measured on `aa049f96`:

| set | derived | shipped |
|---|---|---|
| t11, graph-v2/v3 @ 512 | 2,250,000 B = 27 chunks | 2,250,000 B = 27 chunks |
| devnet, the shipped rows | widest close 78,688 B = 1 chunk → ceiling 83,333 B | 81,920 B = 1 chunk |
| graph-v5 @ 512, dissection court | 333,333 B = **4 chunks** | — |

The literals stay, for three reasons in order of weight:

1. `with_derived_court_close_v1` takes `families` and `rows` as arguments, and
   `PALW_LADDER_FAMILIES_V1` / `_V5` have **zero non-test callers** in the tree. An assembler that
   called it would have to hand it a families constant — the same free choice as a literal, one
   indirection deeper. That is priced-≠-pinned (ADR-0072 D8) wearing a derivation's clothes.
2. The ceiling is load-bearing in two OPPOSITE directions: `palw_mode_v2.rs:1211` refuses admission
   above it, and `palw_attn_court_v1.rs:1186` charges the assembly reserve from it. Tightening to
   the v5 pair's 4 chunks would buy ~184 DAA of window — the clock goes 42 → ~44, and both are
   ≥21× the hybrid's 2-DAA worst rung, so neither convicts an honest responder — and would
   **permanently refuse every class whose close exceeds 333,333 bytes on this network**. Admission
   is permissionless (ADR-0054). 5f is the first network to carry the dissection court; it is not
   also going to be the network that can only ever admit dissection-court shapes. That door is
   worth more than 2 DAA of move budget.
3. Devnet's 81,920 against a derived 83,333 is the same chunk count, so neither the reserve nor the
   clock moves. Only the literal would — a fingerprint move that buys nothing.

The builder and its reporting test stay in the tree, unwired: they are the falsifiable record that
the two numbers agree today and will say so when they stop. **After 5f**, the right shape is to
wire the derivation to `palw_shipped_court_rows_v1()` — the walk FD's own devnet arm already uses —
so its input is the registered set rather than a hand-supplied constant. Post-freeze, not at it.

**Decision 3's arity stays "smallest k that fits".** The alternative on the table was "maximise the
deadline", which would move the RC's clock from 42 to 48. Refused, and *not* because 42 is the
shipped number — reproducing 42 is the check, not the argument. Two reasons:

- The clock has ~21× headroom over the thing it must cover, while bytes-per-move has a hard carrier
  ceiling that arity 64 already breaches at the hybrid's 256-lane head
  (`palw_attn_dissect_arity_fits_carrier_v1`). Spend the abundant resource, conserve the scarce one.
- **"Maximise the deadline" is not a derivation.** It needs a second number — how much deadline is
  enough — and that number is chosen. Decision 3 is "the arity a ruleset DERIVES, never writes";
  the alternative reintroduces exactly the free field the rule exists to close.

*Revisit condition, so this is falsifiable rather than a preference:* if a measured replay floor for
any graph-v5 row ever comes within half the derived deadline, the trade flips and `k` should buy
rounds back.

---

## 4. The freeze and the single re-pin — ORDER MATTERS

**The agreed sequence, as of the last fixer. Every step's owner is named and every arrow is a
dependency, not a preference.**

    1  palw-merge-resolved 4205f535  -> impl     1c's three-way (5f + impl + the artifact branch)
    2  palw-launch-consolidated f7f56498 -> impl the four verifier fixes; ONE conflict,
                                                 host_security.rs, doc-only, pre-ruled in §3
    3  FH   the derived-artifact binding          on top of 2, because 2 already edits derive/src
    4  FG   the graph-v5 512 registration         profile/params only; merges impl at its end
    5  cargo +1.93.0 fmt --all                    ONCE, on the merged tree, LAST source change
    6  scripts/ci/check-derive-freeze.sh             after 2 and again after 5 — until it prints nothing
    7  "frozen"                                   5b says it only after 6 prints nothing
    8  the re-pins                                mine, last, and nothing touches derive/src after

**Steps 3 and 4 are in that order for a reason that is not obvious.** FH writes in
`misaka/palw/derive/src/`, which `palw-launch-consolidated` also edits (`5e369d10`, `928b4081`,
`ce9a6a24`, `e2341aec`), so FH must land *after* the merge or it collides with four fixes it agrees
with. FG touches only the profile, params and test files, so it can come last and merge impl at its
end without racing anything.

**Step 6 is the only thing that makes step 7 sayable.** "Frozen" is a sweep, never a recollection —
see 3b below. It is run twice because step 5 is itself a change to the crate being frozen.


`transformer_id` is a function of `source_tree_sha256`, which covers **every byte** under
`misaka/palw/derive/src/` — comments included. It moves silently and everything stays green when it
does. A published derivation whose id no longer reproduces is unverifiable, so this is the last
thing done before the cut and it is done ONCE.

**Order:**
1. Freeze `misaka/palw/derive/src/` completely. Three doc edits and one formatting pass are already
   inside the hashed bytes.
2. Run `cargo +<pinned> fmt --all` LAST among source-changing steps — formatting is inside the hash.
3. Then re-pin `transformer_id_pin` and `shipped_presets_have_pinned_fingerprints`, in one commit.
3b. **"Frozen" is a sweep, not a recollection** — `scripts/ci/check-derive-freeze.sh`. Re-run it after
   every merge until it prints nothing. As of this writing **four** branches still move the crate:

       MOVES IT   palw-artifact-names-genesis-row  -> 10b7eac25bab
       MOVES IT   palw-launch-consolidated         -> defa73b60943
       MOVES IT   palw-launch-derived-proof        -> 79305dbfe5f1
       MOVES IT   palw-launch-qwen36-demo          -> 3f5996e60331

   **Three sweeps were written for this and only the third asks the right question**, which is worth
   knowing because the first two look authoritative and disagree:

   | sweep | asks | answer |
   |---|---|---|
   | `git diff <rel> <b> -- <path>` | do the END STATES differ | **11** — mostly abandoned branches that merely predate the work |
   | `git log <rel>..<b> -- <path>` | are there COMMITS touching it | **23** — includes `palw-adr0082-impl`, whose `derive/src` is byte-identical to 5f's |
   | merge-tree, compare the subtree hash | would the MERGE move it | **4** — the only count that predicts a stale pin |

   All three are honest counts of different things. The pin depends on the third.

   *This step exists because the pin was taken early and reverted.* The claim was "the merge cannot
   move `transformer_id`, checked rather than assumed", and what had been checked was
   `palw-adr0082-impl` and two in-flight fixers. **That claim about impl was true** — impl really
   does not move the tree. What was false was generalising it to the merge, when three launch
   branches and 1c's do. Two sessions reached the same wrong shape independently and by the same
   route: measure the thing in front of you, assert the conclusion for the population.

4. Nothing under `misaka/palw/derive/src/` may be touched after step 3, for any reason, including a
   typo in a comment.

**The re-pins, by owner. Nothing touches both sides.**

| pin | where | owner |
|---|---|---|
| `transformer_id_pin` | `misaka/palw/derive/tests/` | here, at the cut |
| `shipped_presets_have_pinned_fingerprints` | `consensus/core/src/config/params.rs` | here, at the cut |
| `golden_vector_ids_are_frozen` | `consensus/core/src/palw_freeprompt_v3.rs` — ADR-0082 stream H gave the job two fields | here, at the cut |
| **genesis `utxo_commitment`** | `all_networks_genesis_constants_match_premine` | here, **FIRST OF ALL** — via the `config::premine` CEREMONY tool, not a hand edit |
| `PALW_RC_COURT_E2E_ROOT_BYTES` | `consensus/core/src/palw_e2e_adjudicability.rs` | here, second — see the ordering below |
| state version 18 → 19, ADR-0043 goldens | `palw-adr0082-impl` | 5b, on that branch |

### A RED PIN PROTECTS NOTHING WHILE IT IS RED — the re-pin must be a PREDICTION, not a reading

**This changes how the ceremony is run and it is the most important procedural finding of the cut.**

A re-genesis is precisely the window in which several pins are red at once. While they are red they
are not guarding anything, so **a second change made in that window is invisible — and then gets
blessed by the paste.**

Proved by mutation rather than argued. One byte of `PALW_RC_GENESIS_QWEN36_ARTIFACT_ROOT` flipped
(`0xf4` → `0xf5`), consensus-core run before and after:

    clean tree    3 failed:  premine, fingerprints, freeprompt golden
    mutated tree  3 failed:  premine, fingerprints, freeprompt golden      IDENTICAL

    but the fingerprint test's own message moved:
      clean    testnet-11 … got f38049f023cec8d4…
      mutated  testnet-11 … got 1d03bd9c143f39f1…

**The gate detects the change and cannot report it.** An operator watching pass/fail sees three reds
before and three reds after, with the same three names. Whoever then re-pins by pasting the `got`
value pastes the mutated one and **freezes the accidental byte into the genesis** — after which
every gate is green and the tree is wrong.

**So the re-pin is a prediction that must be confirmed, never a value that is read and pasted:**

    1  BEFORE any further change, on the frozen tree, record the expected fingerprints.
    2  Perform the re-pins.
    3  The value the ceremony reads MUST equal the value predicted in step 1.
    4  If it does not, NAME the change that moved it — or stop. "It moved" is not a finding;
       "it moved and here is why" is. An unexplained move in this window is the one thing
       this window cannot otherwise show you.

*The method is the deliverable, not any particular string.* Both prediction values must be taken
from the **frozen** tree by whoever holds it — FG moves testnet-11's legitimately, so a prediction
taken before FG lands is a prediction for a tree nobody ships.

*Found by 1c, who built a scanner for this class, noticed its baseline was generated from the tree
it checks and therefore could not fail, and asked the underlying question by hand instead.*

### THE RE-PIN LIST WAS WRONG AND THE MISSING ONE ABORTS EVERY HOST AT STARTUP

**`PALW_RC_GENESIS` holds TWO literals that both move at this re-genesis, and the procedure re-pins
one of them.** `hash` (`config/genesis.rs:348`) and `utxo_commitment` are separate constants; the
header hash covers the commitment, so the community premine moves both.

Every guard that could catch the second one is looking somewhere else:

| guard | what it actually covers |
|---|---|
| `every_genesis_commits_to_the_premine_this_build_mints` | **`utxo_commitment` only** — and it DOES name `PALW_RC_GENESIS` (`genesis.rs:469`). Goes green on a commitment-only paste. |
| `config::premine::tests::print_premine_commitment` — the printer the FAILURE MESSAGE names | printed `*_PREMINE_UTXO_COMMITMENT` and `*.utxo_commitment` lines. **Never a genesis hash.** Fixed at `68f0a1b6`. |
| `repin::print_repinned_rc_genesis` — the printer the RUNBOOK names | **always printed both**: it assigns the new commitment into `params.genesis` and *then* derives the header, so `REPIN hash` is the hash the new commitment implies. Never had the gap. |
| `test_genesis_hashes` — the test that recomputes each genesis' own hash | iterates `[GENESIS, TESTNET_GENESIS, TESTNET11_GENESIS, SIMNET_GENESIS, DEVNET_GENESIS]` (`genesis.rs:499`). **`PALW_RC_GENESIS` is not in that list.** |

**The precise shape is worse than "an unchecked constant", and the difference matters.**
`PALW_RC_GENESIS` is *not* unwatched: `every_genesis_commits_to_the_premine_this_build_mints` names
it directly. What is unwatched is **two of its fields** — `hash` and `hash_merkle_root` — which are
exactly the two that abort a host at startup. **The one test that names the constant covers the
field that is not the problem**, so the constant looks guarded, and a reader checking "is this
pinned value tested?" finds a test, sees the name, and stops.

And `TESTNET11_GENESIS` is not a near-miss for it — `genesis.rs:462` calls it a **"retired fossil"**,
`params.rs:7969` sets `params.genesis = PALW_RC_GENESIS`, and their hashes differ
(`08e9c8a4…` against `572f80c0…`). **So the hash test recomputes the genesis this network does not
ship and skips the one it does.**

**The failure sequence, which is why this is the worst thing found today:** the operator adds the
community entries, runs the first gate in §6's own table, gets the premine failure, runs the printer
it names, pastes what it prints — and `cargo test -p kaspa-consensus-core --lib` goes **fully
green** while `PALW_RC_GENESIS.hash` still names the pre-community block. The fleet is then stopped,
wiped and redeployed, and **every host aborts at startup**. There is no earlier symptom, because
every gate the card told the operator to run has passed.

**So the freeze re-pins FIVE, not four**, and the fifth has no test until one is written:

    1  PALW_RC_GENESIS.utxo_commitment    every_genesis_commits_to_the_premine_this_build_mints
    1b PALW_RC_GENESIS.hash               test_genesis_hashes  (CLOSED — see below)
    2  the two shipped fingerprints       shipped_presets_have_pinned_fingerprints
    3  the free-prompt golden             palw_freeprompt_v3::golden_vector_ids_are_frozen
    4  the eight transformer ids          transformer_id_pin

**CLOSED on impl at `68f0a1b6`, before the ceremony rather than after.** Both one-liners landed:
`PALW_RC_GENESIS` is now the sixth entry in `test_genesis_hashes`'s array, and
`print_premine_commitment` prints, beside the commitment, the `PALW_RC_GENESIS.hash` that commitment
implies (and the `hash_merkle_root` it does not move).

**The new guard is GREEN today, and that is the honest reading rather than a weakness.** The stored
hash covers the stored commitment, so the struct is self-consistent right now; it goes red *the
instant the commitment is re-pinned without the hash*, which is the only moment it needs to fire.
A guard that were red today would be telling you about the old genesis.

**Take the value from the cut's own commit, not from here.** The printer's output moves when any
genesis object moves — FG's v5 registration will move it — so a hash printed before FG lands is a
hash for a genesis nobody ships. Run `config::premine::tests::print_premine_commitment` on the
frozen tree and paste what it prints, both lines.

**There are TWO ceremony printers, and the defect was which one the failure message pointed at.**
`repin::print_repinned_rc_genesis` (kaspa-consensus, named by the runbook) has always printed both
values, correctly — it substitutes the new commitment into `params.genesis` before deriving the
header. `print_premine_commitment` (kaspa-consensus-core, named by the *test failure message*)
printed commitments only, until `68f0a1b6`.

So an operator following the **runbook** was safe; one following the **failure message the first
gate prints at them** was not. That is the live-site-versus-search-order defect exactly: the message
wrote an address, and the tool at that address was the incomplete one. Both print both now, and both
derive the hash the same way, so they cannot disagree.

*I first recorded this as "the ceremony tool does not print the value", which was true of one of two
tools. Corrected after reading the runbook's printer in full rather than a grep of selected lines
from it — the assignment that made it correct was on a line my pattern did not match.*

### The re-pin list is SEVEN items and only FOUR have a red test — here is where the other three went

Measured on the re-merged tree (`4205f535`): `misaka-palw-base0` 360/0, `kaspa-consensus-core`
1815/3, `misaka-palw-derive` 201/1. **Four reds, and each is one of the seven:**

    every_genesis_commits_to_the_premine_this_build_mints    re-pin 1  premine utxo_commitment
    shipped_presets_have_pinned_fingerprints                 re-pin 3  the two fingerprints
    palw_freeprompt_v3::golden_vector_ids_are_frozen         re-pin 5  free-prompt golden
    transformer_id_pin::…_pinned_with                        re-pin 4  the eight transformer ids

The other three are accounted for and none of them is a silent hole:

- **re-pin 6, the state-version goldens: already done, by FA2.** `PALW_STATE_V2_VERSION` is 20 and
  the empty/inhabited goldens were re-pinned in the same change that bumped it
  (`966bae07…` / `a0b711e1…`, in `palw_state_v2.rs`). A version bump that re-pins its own goldens is
  the right shape; nothing is left for the freeze.
- **re-pin 2, `PALW_RC_COURT_E2E_ROOT_BYTES`: gated, and currently NOT stale.** The gate is real and
  it is not in consensus-core — `the_pinned_rc_e2e_root_is_what_this_build_certifies`
  (`misaka/palw/base0/src/e2e_drill.rs:1745`), a plain `#[test]`, which compares
  `palw_court_e2e_root_v1()` (computed from the registered families) against the pin. base0 is
  360/0, so on this tree the root has not moved. The `581466da… → 8f08d303…` move measured elsewhere
  was against a per-kernel drill rule that is **not merged**; if it lands, this becomes a live re-pin
  and base0 goes red to say so.
- **re-pin 7 does not exist** — the seventh slot was the two fingerprints counted as two items.

**And one assertion in this area checks nothing, with a confident message.** `config/params.rs:11228`:

    assert_eq!(bundle.court_e2e_root, palw_rc_court_e2e_root_v1(),
               "the attempt-lane genesis set is the one this build certifies");

`bundle.court_e2e_root` is **set from that same function** (`palw_fp_devnet_v3.rs:803`). It compares
a value with itself. The thing its message claims — that this build's court can play the family set
the pin names — is `palw_court_e2e_root_v1()`, a different function that this test never calls.
It is the `signed: true` defect again: *a word answering a different question than the one it was
asked.* The real check exists in base0; this line should say what it actually checks (that the
assembler does not let a caller name the root) or point at the gate that does.

### The certified-set root is regenerated TWICE, and that is correct

It is not a freeze-time chore. With the covering type change in, **no node can register a class at
all**: the registration pricing path compares the supplied certified set against the network's
commitment before it prices anything, so a stale root stops an acceptance drill at stage 2 and
nothing downstream can be measured. Found by running a chain, not by a suite.

    now, on the owning branch    provisional, tree sha in the commit message, so the drill can measure
    at the freeze, here          once, from the final tree

**The pair is a measurement of the interval between them.** If the freeze's value matches the
provisional one, nothing that landed in between touched a family digest; if it differs, the
difference names exactly what did. Two regenerations handle staleness better than one at a moment
nobody can identify in advance — and there is no re-pin hazard here, because the hazard in a re-pin
is JUDGEMENT and a derived value carries none.

**The regeneration must come from the DRILL, not from the profile.** Writing
`drilled_kernel_ids = profile.reachable_kernel_ids_v1()` would compile, would be green, and would be
a set that was typed rather than drilled — the exact defect the field exists to close. If the two
turn out equal, that is a result to be observed, not a shortcut to be taken.

### A tautology is not a stale claim — the doc was never true, and the check was built not to notice

`the_shipped_rows_keep_interval_one_and_their_ids` asserted `qwen25_a16_class_id_v2() ==
qwen25_a16_class_id_v2()` — a pure function compared with itself, whose failure message was
unreachable. Writing the comparison its own doc describes turned it red and produced **three class
ids for one model at one width**:

    f942e268…   qwen25_a16_profile_v1(QWEN25_1_5B_A16)       the superseded v1 graph
    71bbb755…   qwen25_a16_profile_v2(QWEN25_1_5B_A16)       what the genesis REGISTERS
    7a76d29b…   palw_a16_context_row_profile_v1(16)          that module's own projection

"Three adjacent ids loose in this project's notes" has been a warning in these commit messages for
days. Here they are, measured, and **the reason nobody found them is that the only assertion in the
area could not fail.**

**This is a different defect from a stale claim and the difference is worth holding.** A stale doc is
a true statement that expired. This doc was **never true** — so the only assertion that could sit
underneath it was one incapable of failing, and the test was shaped to agree with the prose rather
than with the code. You cannot find it by re-reading either the doc or the test; you find it only by
**writing the comparison the doc describes and watching it go red**.

**And the shape is NOT mechanisable — this is a limitation, measured, not an unwritten gate.**
`assert_eq!(f(), f())` looks greppable, so it was swept: **25 hits, about 20 of them legitimate**
determinism checks where `f` has hidden state (fresh buffers, iteration order, memoisation) —
`the_same_dsl_twice_is_the_same_bytes` under a "determinism" heading, `assert_eq!(run(), run())`
where `run()` builds fresh state each call, and eighteen more. **A gate on this pattern fires on all
of them, and the first thing anyone does is add allow-comments to the real determinism tests** —
which leaves the tree worse than no gate, because the exemptions become where defects hide and now
they carry a blessing.

What made the defect a defect was never the shape: it was **the doc above it claiming a different
comparison**. Had that doc said "this id is stable across two derivations", the identical line would
have been correct and unremarkable. *The discriminator is agreement between prose and assertion, and
no static check reads that.* The instrument stays manual: **do what the doc says and see whether the
code minds.**

**The root cause is worth more than either.** All three instances were written in the same sitting
as the thing they test — *the nearest value is the one you already have in hand, and it type-checks*.
That IS greppable, unlike the shape: **a test introduced in the same commit as its subject** is where
to look, as a review heuristic rather than a gate.

*Pinned as three-way DISTINCTNESS rather than three literals — a literal would join the re-pin set
whenever any of the three graphs moved, for no benefit, while the property actually worth holding is
that they stay tellable apart. A collision means a row built by one route silently names the class
another route owns, which is the `bind` defect in a different costume.*

### The dense lane is broken from BOTH ends, and it is ONE fixer — do not land half of it

Two findings that read as separate items are the same defect seen from two sides, and FG closes both:

    the class the chain HOLDS cannot be executed   registered row declares rms_eps_q 1;
                                                   every artifact carries eps_q 256, so
                                                   A16Engine::plan_from_profile refuses it —
                                                   while that row holds 489‰ of cadence
    the class the WORKER embodies is not held      palw-a16-fp-worker's MODEL_ID is the v5 512
                                                   row, which the genesis does not register, so a
                                                   commitment under it names a class no chain holds

**Registering the v5 row and arming `palw_kary_court` were never separable, and neither are these.**
Landing the registration without the eps replacement leaves 489‰ on an unexecutable class; landing
the eps fix without the registration leaves the worker pointed at nothing. *Written as one item
because two items are how half of it ships.*

### THE 62 SKIPPED TESTS INCLUDE EVERY TEST THIS NIGHT EXERCISES HARDEST

The full suite is **4,072 run, 4,066 passed, 6 failed, 62 skipped** in 407s — and the six are the
five re-pin tests plus one fixture branch, exactly as owned. But the **skipped** set is the one worth
reading, because of what this particular night is:

    ibd_participation_tests::a_node_killed_partway_through_recovery_comes_back_safe
    ibd_participation_tests::e2e_a_a_stronger_chain_found_during_ibd_wins
    ibd_participation_tests::e2e_b_bootstrap_recovery_crosses_a_provisional_pruning_point
    ibd_participation_tests::mainnet_gate_handoff_holds_repeatedly_over_a_delayed_link
    ibd_participation_tests::mainnet_soak_randomized_fault_injection
    daemon_integration_tests::daemon_utxos_propagation_test
    simpa tests::test_pruning_via_simpa
    palw_agent_equivalence::the_resident_agent_and_a_fresh_process_compute_the_same_tag

**These are `#[ignore]`d for cost, which is a defensible standing decision and a DIFFERENT decision
from "ignored on the night every host is wiped and every node re-syncs from a new genesis."**

The isolated boot on ibm covers the **start**. Every test above covers *a second node joining a
chain that already moved* — which is literally the next thing that happens after the producer comes
up. And this project has been bitten there: a pruned-IBD panic that put a joining node into
permanent quarantine.

*A standing decision made for cost becomes a different decision on the one night its subject is the
main event. The set did not change; the night did.*

**And that is a THIRD member of the staleness family, more invisible than the other two:**

| what goes stale | what pushes back |
|---|---|
| a claim that **broke** | a red test, a failed build, a confused reader — *something* |
| a claim that **improved** | nothing. It reads as a correct caution (see below) |
| a **decision** whose premise stopped applying | nothing, and **it was never a statement at all** |

The third is the worst because *a standing decision does not come up for re-decision* — it persists,
correctly, into a night with different physics. `#[ignore]` for cost is right on an ordinary week and
nobody re-decides it, because nothing in the mechanism asks. **There is no sentence to re-read.**

*The filter that finds them is not "what claims might be stale" but "what does THIS operation
uniquely create". A resident agent disagreeing with a fresh process can only surface after every host
restarts at once — nothing in the normal running of a chain produces that condition, and a wipe
produces it on every machine simultaneously.* Six of the ignored tests are being run on that
reasoning: the three IBD-participation cases, and the three pow-driver ones — including
`a_dead_agent_costs_a_delay_and_not_a_tag`, because **a wipe is every agent dying at once.**

**ALL THREE PROPERTIES THIS NIGHT MANUFACTURES ARE NOW MEASURED, AND ALL THREE ARE GREEN.**

    a node killed partway through recovery comes back safe   impl 41e364b6   242s, 7 restarts
    a stronger chain found during IBD wins                   d7957910       609s
    bootstrap recovery crosses a provisional pruning point   d7957910       620s

**The third is the scar.** A joining node crossing a provisional pruning point is exactly where this
project put a node into permanent quarantine before. It passes.

*The two on `d7957910` are one merge behind impl; IBD participation is not a surface FH, FH2 or the
fmt touches. Caveat stated, not discovered.*

**AND THE IGNORE STRING ITSELF CARRIED A CLAIM NOBODY WAS CHECKING.** Those two tests are marked:

    #[ignore = "passes; opt-in because it takes ~6 minutes — run with --include-ignored"]

They took **10.2 minutes each** — the stated runtime is 70% low. That is trivial. **The word
`passes` is not.** It is an assertion about the *result*, living on the one test that never runs to
produce a result — and it is read at exactly the moment someone is deciding not to run the thing
that would check it. Had these started failing, the attribute would still have said `passes`, and
the next person weighing the cost would have read a reassurance.

**An `#[ignore]` reason may say WHY. It must not say what the result would be.** That is the
favourable-staleness shape one level further in than a document, and worse placed: a stale doc is
read by someone reading; a stale ignore string is read by someone deciding *not* to look.

**RUN, AND GREEN — on the cut tree, with the duration proving it ran.**

    impl 41e364b6
    ibd_participation_tests::a_node_killed_partway_through_recovery_comes_back_safe
      RESTART complete: 0 failures out of 7
      test result: ok. 1 passed; 0 failed  —  242.35s

**242 seconds and seven restart scenarios**, against the 0.016s that would have meant a skipped
fixture. So the risk this section states is now *measured on this tree* rather than enumerated: a
node killed partway through recovery comes back safe, which is the failure with the worst story if
it bit — an operator being told what to delete on a chain nobody has a mental model of yet.

*One of eight. The other seven remain a stated risk, and three IBD cases plus three agent-recovery
cases are running as this is written. `mainnet_soak_randomized_fault_injection`,
`mainnet_gate_handoff_holds_repeatedly_over_a_delayed_link`, `daemon_utxos_propagation_test` and
`test_pruning_via_simpa` are not being run and that is a stated gap, not an oversight.*

**Superseded note — the reasoning that got us here:** — it is the
failure mode with the worst recovery story, and the wall clock is free while the last fixer
finishes. Whatever it prints goes in §6 as a gate that was run rather than a set that was skipped.

### A SHORTCUT THAT HAPPENS TO BE RIGHT IS WORSE THAN ONE THAT IS WRONG

`cargo run -p misaka-palw-derive --bin palw-derive -- drill --report r.json` builds **that one
binary**. The drill then shells out to `palw-evm-runner`, does not find it, and six of forty-six
goldens refuse — ADR-0079 SA-1's confinement gate holding, exactly as the card already documents for
the `--lib` case. **The report's own `verdict` field said `FAILS`.** Its `transformers[]` array sat
right beside it, populated and inviting.

Built the crate properly (`cargo build -p misaka-palw-derive`), re-ran, got a valid report — *46
goldens, 0 mismatched, 8 bounds enforced* — and compared:

    8 of 8 transformer ids IDENTICAL between the FAILS run and the valid one
    source_tree_sha256 identical: 637858dba5ea5e34b9459a580b2b81d1361aecf450bc615a4ee9621d4953a988

**The ids do not depend on the EVM runner. So pasting them out of the failed report would have
produced exactly the right genesis — and nothing, ever, would have told anyone the process was
wrong.** The values would have been correct, the pins would have been green, the chain would have
launched, and the next person to follow the same shortcut would have had no reason to doubt it —
until a change *did* make the ids depend on what the failed leg covers.

*A wrong answer gets corrected. A right answer from an invalid process gets INHERITED.* That is why
the rule is procedural and not a matter of judgement: **check the report is valid before reading any
field of it.**

**And the first version of that rule said "assert the report's `verdict`" — which does not work,
because the report file has no `verdict` field.** The verdict is printed on **stdout only**. Both
files carry an identical key set:

    arch bounds golden os refused rows schema source_tree_sha256 transformers uncovered

**A `--report` file, read on its own, is structurally identical for a FAILS run and a valid one.**
The discriminator exists but it is one level in:

    report["golden"]["mismatched"] == []     valid: []   failed: six entries
    report["uncovered"] == []                [] in BOTH — this one does not discriminate

So the executable rule is: **`golden.mismatched` must be empty**, not "check the verdict". *I wrote
the rule from what stdout told me and it did not survive contact with the artefact it was about* —
which is the same defect one turn later, in the correction for it.

*The deeper reading: a report designed to be machine-read carries the ids and not the judgement of
whether the run that produced them was valid. That is a defect in the report's shape, worth an
issue after the cut — the file a tool writes for another tool should not be the one that omits
whether it worked.*

### SEND THE VALUE **AND** WHAT YOU THINK PRODUCED IT — the disagreement is the check

A hash arrived with a sentence: *"derive/src tree hash after the fmt: `4969f8dc…` (the fmt moved it
as expected)."* **The hash was right. The sentence was wrong** — that is the value from *before* the
fmt too, and `git diff` across the fmt shows nothing under that crate. The fmt ran (17 files, 211
insertions) and touched base0, the tests and the sdk; `misaka/palw/derive/src` was already formatted.

The cause was two hashes over one directory that are easy to conflate: **`source_tree_sha256`**, the
project's own hash and the transformer ids' input — which **FH did move**, `d2419027…` →
`637858db…` — and the **git tree hash** of the same path, which moved at neither FH nor the fmt in
the window being discussed. Same content, different algorithms, and an intuition that applies to one
reads as applying to the other.

**A bare hash would have passed unchallenged.** The only reason it did not is that the sender said
what they believed had produced it, and the belief and the value disagreed. *So the ceremony's
reporting rule is: never send a value alone — send the value and the operation you think produced
it.* It costs a clause and it converts every handoff into a two-ways check.

**And the correction was in our favour**, which is the part that would otherwise have gone unnoticed:
if the fmt moved nothing under that crate, the prediction captured *before* it is the exact tree the
pin comes from, and the "two readings minutes apart" hazard this ceremony was built to guard has
nothing to guard.

### THE PREDICTION, taken pre-fmt on impl `41e364b6` — check every paste against it

Recorded **before** the formatting pass, per the ceremony rule, so a value that moves without a named
cause stops the paste. `derive/src` tree at capture: `4969f8dc051cac31`.

    1  premine    PALW_RC_GENESIS.utxo_commitment
                    pinned  2d882275dae82945a99e825fcb5f973c66a9e945f4d0849d833e8b8f9c0835ff…
                    builds  ba2612417e7e0817cca0ac0cade91caa585834c051114bc4125542acb05898db…
                  and .hash, printed beside it by the ceremony tool

    2  fingerprints  testnet-11  a7baab7957d27bbd… -> 71efa66480211731e3dc6fa2312ed73f
                                                      7ed11b93372a19a55ac66ef39b65920e
                    devnet      84153175ce880504… -> c0da0c9024d68b94b95010d1566cb1d5
                                                      35a818cd0727d9978906b0a2a8b13692

    3  free-prompt golden   pinned 700b90364860460f7d89d85eed59019c
                            new    c940b5c36ee40846087e6c5927d6e6b5

    4  the eight transformer ids + source_tree_sha256 — THE ONLY ONES THAT MOVE AT THE FMT

**Three of the four must be UNCHANGED after the fmt**, because formatting touches no consensus
input. If any of 1–3 differs from the above when the ceremony runs, something landed between this
capture and the paste, and the ceremony stops until it is named.

**The two fingerprints were measured independently by two sessions and agree exactly** — `71efa664…`
and `c0da0c90…` from 5b's run and from mine, on the same tree by different invocations. That is the
two-ways rule applied to the prediction itself, which is the one number a wrong paste would freeze
into the genesis.

### RED-COUNT IS NOT RE-PIN-COUNT, and two tests print left/right in opposite senses

**Five re-pin tests. Four re-pin values.** Anyone checking their work by "did the number of reds go
down by one" after each paste will over-count and go looking for a fifth value that does not exist.

The premine value alone accounts for **three** observations, all of the same pair:

    kaspa-consensus       utxo_set_override::all_networks_genesis_constants_match_premine
                          left  ba2612417e7e0817…  (BUILT)     right 2d882275…  (PINNED)
    kaspa-consensus-core  every_genesis_commits_to_the_premine_this_build_mints
                          "pinned 2d882275…, premine BUILDS ba2612417e7e0817…"
    the isolated boot     utxo_set_override.rs:60 — the node refuses to start on the same pair

**And the two tests print the pair in OPPOSITE senses.** One puts the built value on the left, the
other names the pinned one first. A reader holding both messages side by side sees `ba26…` on the
left in one and on the right in the other, and the natural reading is *the two tests disagree*.
**They agree exactly.** That is a five-second panic at the worst possible moment and it is free to
know about now.

*Both are the same underlying thing: a count and a sense are properties of the REPORTING, not of the
work, and at 3am the reporting is all anyone has.*

### THREE REDS CLOSE WITH ONE PASTE — and one gate breaks the script's own rule

Full `ci-gates.sh` on the merged content: **15 passed, 4 FAILED**, and every failure is a re-pin this
ceremony performs or the fmt sweep. **No gate fails for a reason this cut does not already own.**

    artifact-stranger   FAILED rc=2     transformer re-pin  \
    derive-suite        FAILED rc=101   transformer re-pin   > ONE file: transformer_id_pin.rs
    (consensus-core)    the pin test                        /
    nextest             FAILED rc=100   premine re-pin
    fmt                 FAILED rc=1     43 inherited diffs, closed by the single pass

`transformer_id_pin.rs` closes **three** of them — a consensus-core test, a derive-suite gate and a
CI gate — because the stranger *reads its pins out of that file* rather than restating them. That is
the one-spelling rule paying a dividend at the freeze: one paste, three reds.

**And `nextest` breaks the script's own rule 2.** `ci-gates.sh` says *"a checker that prints its
verdict without printing its coverage is unfalsifiable"* — and `nextest` fail-fasts at **34 of
4,072**, so its verdict is *the first failure* and never *the set*. It prints the coverage number
and nobody reads it as one. **The gate script states the rule and one of its gates violates it**,
which is the postmortem-next-to-its-own-instance shape, in the file that exists to enforce the rule.

*After the cut, not now:* `--no-fail-fast` costs wall clock on a red run and buys the entire red set
on the run where it matters most, which is exactly a freeze. Changing a gate's invocation during one
is how a freeze acquires an unmeasured variable.

### FAVOURABLE staleness is the kind that survives — nobody re-checks an item that got better

Three claims in these documents went stale today and **all three had improved**:

    the hybrid's exclusion       "cannot close at ANY width"  ->  3 carriers against a ceiling of 27
    the width table              "capped at 39 positions"     ->  the ladder moved to 2^26
    the announcement's Known-open "the hybrid is not registered" -> FG registered it

**Not one of them was a claim that had broken. Every one was a constraint that had lifted.** A claim
that breaks produces a red test, a failed build, a confused reader — something pushes back. A
constraint that lifts produces nothing at all, and the sentence describing it keeps reading as
true, in a document nobody has a reason to revisit. *An item that got better is one nobody is
motivated to re-check.*

So the freeze pass has a specific instruction, not a general one: **go through every "known open",
every "cannot", every "not yet" and ask what would have to have changed for it to be false — then
check whether it did.** That is a different sweep from looking for broken claims, it takes minutes,
and it is the one that catches the sentences a re-read cannot.

*All three of these were caught by grepping for the claim, not by re-reading the document. Re-reading
is what let them survive: a favourable staleness reads exactly like a correct caution.*

### ASK THE SAME THING TWO WAYS — the only cheap detector for a broken instrument

**This is the method that made this cut work, and it was used all day before anyone named it.** Every
pair below caught something; **not one of the single measurements would have.**

| the pair | what the second one caught |
|---|---|
| ancestry **and** content-grep | a fixer "absent by ancestry" that was present by content, and vice versa |
| arity **and** prompt-ids form | 81,599 measured under a court `validate_palw_v2` refuses to assemble |
| the library route **and** the binary route | `bind` naming the genesis row in a test and the wrong graph through its own argument parsing |
| a re-armed ruleset **and** the genesis object itself | a third close figure, from the only route that asks what the chain answers |
| the pass count **and** the wall clock | a suite whose artifact cases skipped, printing the same ten dots and the same `ok` |
| two sessions measuring independently | every number in this card that survived |

**The mechanism is not redundancy — it is that a broken instrument answers ONE question
confidently.** A failed fetch, a filter with no digit class, a helper hardcoding one of three fields,
a skip that returns early: each produces a believable result, and nothing inside that result says it
is wrong. **A contradiction between two askings is the cheapest signal in this whole system**, and it
is available for the cost of asking twice.

*The counter-instinct is the dangerous one: when two measurements disagree, the pull is to pick the
convenient one and move. Every finding in this section came from someone refusing to.*

### The short function name is the genesis-anchored one, and it answers the wrong court

**Measured against myself: I reached for the wrong variant six times in one day**, and every time the
wrong answer looked like a finding rather than a mistake. The pattern is mechanical enough to state:

| the short name | what it silently assumes | the one that asks the ruleset |
|---|---|---|
| `derive_court_cost_v1(profile)` | `PALW_STEP_MAX_LEAVES` = 2^22, `kv_checkpoint_bytes: 0`, `dissection: None` — the cache-write route | `derive_court_cost_shaped_v1(profile, shape)` |
| `worst_case_step_leaf_count_v1(profile)` | 2^22 | `worst_case_step_leaf_count_capped_v1(profile, ladder)` |
| `step_merkle_root(leaves)` and its five siblings | `PALW_STEP_LEG_MAX_LEAVES` | the `_capped_v1` form |
| `PalwCourtCostShapeV1::genesis_anchored_v1` | the genesis ladder, not the ruleset's | build the shape from the ruleset's rules |

**Every one of these is correct for its own purpose and wrong as a measurement of the shipped
network.** The failures they produced today, in order: both dense rows "refused at 512" (they were
priced at 2^22); the 512 close "arity-invariant" (priced on a route the ruleset does not play, where
the binding node is not the fused one and `shape.dissection` is read only for `AttnFused`); and
every A16 row "REFUSED at 512" a second time from the leaf count.

*The tell is a result that is identical across inputs that should change it, or a refusal whose
`max` is a number the ruleset does not use.* `classes.rs` states the rule for its own case — "a test
that swapped the route by hand would be pricing a route the ruleset no longer plays" — and the
general form is: **the convenience wrapper is the easiest to call and it answers a different court.**

### The tell for "is this a chain change?"

**A change that moves a value the chain commits to is a chain change, and its cost is measured on a
chain.** But the useful half is the tell, because knowing the rule did not prevent this one:

> **It is not "did something move". It is "does anything OUTSIDE this crate compare it to
> something".**

The value that moved was nameable — `palw_court_e2e_root_v1` — and the cost was still reported in
tests, because the comparison that makes it expensive lives in the registration pricing path against
a genesis commitment, and one side of that comparison is a chain. No suite can hold it.

**The premine commitment is re-pinned before everything, because it is what makes this a
re-genesis.** `premine_is_the_expected_split` PASSES — the premine itself is right and only the
commitment pin is stale — but that pin is the genesis UTXO set's identity, so the genesis hash and
every value downstream of it move with it. It is also the only one of the seven that needs a
ceremony tool rather than an edit.

**The e2e root is re-pinned BEFORE the fingerprint, because it is INSIDE it.** `consensus_params_id`
reads the pinned `PALW_RC_COURT_E2E_ROOT_BYTES`, so re-pinning the fingerprint first produces a
value computed from a stale root — correct-looking, self-consistent, and wrong. Order: e2e root,
then fingerprint, then everything else.

**And the trap that ordering hides, which cost a measurement today.** "Does adding a fourth
certified family move `consensus_params_id`?" was measured as **no** — byte-identical on both
networks, with the change and with it stashed. The measurement was correct and the conclusion was
false: the fingerprint was unchanged *because the build was not yet self-consistent*. Updating the
root pin, which the build requires anyway, moves it:

    testnet-11  a090885af5856071…  ->  404c624568360b22…
    devnet      7acb81ebd3c8d942…  ->  67b0e2ebcb02c7e5…

**Measuring whether a change moves a derived value, while a pin that value is derived FROM is
stale, measures a build nobody will ever run.** The constant's own doc said the root is inside every
RC network's params id; it was read after the measurement rather than before.

**The fingerprint moves under you, so re-pin LAST and never early.** Measured twice a few hours
apart on this branch: `a7baab79…` was the pin, one reading gave `d201a54f…`, and the next gave
`4e0fe90b…` (devnet `84153175…` → `b84ea8cf…` → `6dbad795…`). Nothing was wrong either time — the
value is a function of the consensus parameters and every merge moves it. A re-pin taken before the
last merge lands is a value that was true when it was read and false when it shipped.

**Careful with the third**: `golden_vector_ids_are_frozen` exists TWICE — `palw_freeprompt_v3.rs:1643`
and `palw_derived_v1.rs:441`. One name, two homes, in the same crate. Only the free-prompt one moved.
Re-pinning by name rather than by module is how the wrong one gets rewritten, and this is the same
one-thing-two-homes shape that produced the two ladder caps and the class root spelled two ways.

**Two re-pins, two owners, no overlap.** The state version goes 18 → 19 on `palw-adr0082-impl` (the
court session gains its dissection phase) and the ADR-0043 goldens move with it — those are re-pinned
there, by the session that moves them. `transformer_id_pin` and
`shipped_presets_have_pinned_fingerprints` are re-pinned here, once, in step 3. Stated because a
fingerprint is not the sum of two diffs: two sessions re-pinning the same value against different
bases produce a third value, and this project has done exactly that before.

Anything quoting the old scene goldens is stale: `02-hierarchy` is **2736** (was 2716) and
`05-tetrahedral-rotations` is **17748** (was 17728).

### The merge surface, measured ahead of the freeze — FIVE conflicts, one already decided

Trial-merged in a throwaway worktree so the conflict set is known before the cut rather than
discovered during it.

**The first version of this section said "one conflict" and was wrong, from two correct
measurements.** Each branch conflicts with 5f in exactly one file — and that says nothing about the
merge actually being done, because the remaining four conflicts are between the two BRANCHES, and
neither pairwise merge contains both:

    5f + palw-adr0082-impl                 -> 1   misaka/palw/base0/src/fuzz_a16.rs
    5f + palw-artifact-names-genesis-row   -> 1   misaka/palw/base0/src/fuzz_a16.rs

    5f + impl, THEN + artifact-names       -> 5   fuzz_a16.rs (as above), plus
                                                 consensus/core/src/palw_class_admission_v2.rs
                                                 consensus/core/src/palw_state_v2.rs
                                                 misaka/palw/base0/src/classes.rs
                                                 misaka/palw/base0/src/fp_recompute.rs

Order does not help: five either way. *`5f + A` and `5f + B` do not predict `5f + A + B`* — and the
whole point of a trial merge is to trial the merge you are going to do, which this card asserted
while not doing.

**A merge surface is a measurement with a timestamp.** An earlier three-way run had
`palw-a16-fp-worker.rs` in the set and today's does not; 5f moved thirty-odd commits between them.
This set is against `2af2e5c5` and will move again with the next fixer. Re-run before the cut; the
count is not the deliverable, the *rehearsed resolution* is.

**The conflict, and its resolution, are already ruled.** 5f has `pub fn next(&mut self) -> u64` with
an `#[allow(clippy::should_implement_trait)]`; impl and 1c's branch both have `pub fn next_u64` with
no allow. **Take `next_u64`.** The justification written beside that `allow` was false — it claimed
`next` is what every RNG calls this step, in a file that already spelled it both ways twice over,
and `rand_core`'s own name for it is `next_u64`. The half of that doc comment worth keeping is the
Iterator argument, which is true: this is an infinite deterministic sequence, and implementing
`Iterator` would offer combinators that are meaningless on it and let a `for` loop run forever while
reading as ordinary code. Keep that sentence, drop the lint apologia, take the rename.

*Recording it here because a one-line conflict resolved under time pressure at a cut is exactly how
a retracted argument gets re-adopted: the `#[allow]` side reads as the more thoroughly justified one,
and it is the wrong one.*

**A THIRD merge is required and the card did not name it: `palw-launch-consolidated`.** It is not
optional polish — it carries two defects of exactly the class this cut keeps finding, in the tool an
operator uses to verify a published derivation:

    5e369d10  "I cannot check this" was being reported as "this is a forgery"
              UnknownGrammar / UnknownTransformer -> UNVERIFIABLE, still exit 2
    928b4081  `"signed": true` was a BORSH field being PRESENT, not a signature that verifies
              it was `signature.is_some()`; a signature that is a byte of noise verified `consistent`
    ce9a6a24  the drill silently skipped contract/evm/v1 and said nothing
    e2341aec  `width` — the row's arithmetic, so a narrow class refuses BY NAME

`signature.is_some()` printed as `signed: true` is the sharpest of the four: the tool that exists to
let a stranger check a derivation was answering a different question than the word it printed.

**One merge, not three** — `palw-launch-consolidated` already contains `palw-launch-derived-proof`
and `palw-launch-qwen36-demo` (verified by ancestry). It adds 35 commits over the re-merged tree and
conflicts in exactly one file.

**That conflict is pre-ruled: `misaka/palw/core/src/host_security.rs`, and it is DOC-ONLY.** Two hunks,
zero non-doc lines inside either. Both sides independently discovered the same defect — that
`MISAKA_PALW_NETWORK_ID` missing from `PALW_WORKER_ENV_ALLOWLIST` made every free-prompt worker
unstartable, with SA-7 withholding the real reason so the gateway reported only "the worker exited
before announcing its manifest" — and both wrote it up. The allowlist entry itself is byte-identical
on both sides at line 78.

    KEEP HEAD's test.  HEAD has `assert!(PALW_WORKER_ENV_ALLOWLIST.contains(&"MISAKA_PALW_NETWORK_ID"))`
                       at line 949; consolidated has no such test. Losing it is the real risk here.
    MERGE the prose.   HEAD explains the two well-founded rules that pointed opposite ways and that
                       a name is not a capability; consolidated has the reproduction (`env -i` with
                       the exact delivered set) and the exact `die` message. Both halves are worth
                       keeping and neither is a superset.

*Two sessions finding the same defect and writing two explanations is the cheapest kind of conflict
and the easiest to resolve badly: a side-pick keeps one write-up and silently drops a test.*

**The other four, and who owns them.** `classes.rs`, `palw_class_admission_v2.rs` and
`palw_state_v2.rs` are where the fourth certified family, the artifact-route change and the
`canonical_leaves` field meet ADR-0082's court — 1c's to resolve, and they are resolving them.
`fp_recompute.rs` is impl-against-J and is mine. **Verified state of the two-way merge**, so the
three-way starts from something known: `misaka-palw-base0` 327 passed / 0 failed (the crate the
`fuzz_a16` resolution is in), `kaspa-consensus-core` 1,808 passed / **3 failed, and all three are
re-pins this cut performs anyway**:

    config::genesis::tests::every_genesis_commits_to_the_premine_this_build_mints   re-pin 1
    config::params::…::shipped_presets_have_pinned_fingerprints                     re-pin 3
    palw_freeprompt_v3::tests::golden_vector_ids_are_frozen                         re-pin 6

No fourth red, and no red that is not on the re-pin list. That is the result worth having from a
trial merge — not the conflict count, which expires.

---

### The artifact binding, verified by running — and the WALL CLOCK is what proves it ran

FH closes the hole the audit found. Verified here, not read: `misaka/palw/derive/tests/answer_binding.rs`,
**10 passed / 0 failed / 0 ignored / 0 filtered out, finished in 18.40s**, with
`instruct-bound.palwart` (1,795,427,276 B) at the path the fixtures name and `qwen25-tokenizer.json`
where they expect it.

**AND `--run-ignored all` IS THE MIRROR: the same missing fixture, the opposite verdict.**

    a skip that returns early         counts as PASSED
    an ignored test FORCED to run     counts as FAILED
    same absent fixture — and NEITHER verdict is about the code

Measured: the three worker-dependent agent tests "failed" in **0.016s** each under `--run-ignored
all`, panicking on `env::var("MISAKA_PALW_GGUF").expect(…)`. Nothing ran. **The duration is the tell
again** — 16 ms cannot spawn a resident agent and a fresh process.

**The `#[ignore]` reason string was the only honest part of the mechanism** — *"needs the real
palw-worker and the 1.2 GB pinned model"* names exactly what is absent — and forcing the run
discards it. *Reaching for more coverage produced less information*, and produced it in the shape of
an alarm: three reds in the one subsystem a wipe stresses hardest, thirty seconds from being reported
as a divergence. **A false alarm is harder to catch than a false green, because alarm feels like
diligence.**

The repair is the one already noted below: absence should have ONE meaning. Fail when the fixture is
missing in CI, skip on an explicit opt-out — never a verdict that flips sign depending on the flag.

**A LOUD SKIP STILL COUNTS AS PASSED, and `cargo test` captures the announcement.** Measured on the
sibling suite the same evening:

    without the artifact   ...SKIPPED: set MISAKA_PALW_ARTIFACT…   9 passed   0.01s
    with the artifact      (no SKIPPED line)                       9 passed   9.70s

The skip prints — it was built to print — and **only `--nocapture --test-threads=1` surfaces it**,
which nobody runs by default. So "9 passed" included a test that checked nothing about the real
weights, and the captured log could not have said otherwise. *The duration is the evidence; the
count cannot be.*

**The design fix, for after the freeze: absence should be a DECISION, not a default.** An
artifact-dependent test should **fail** when its file is missing in CI and skip only on an explicit
opt-out. A skip that is the default state is indistinguishable from a check nobody wanted, and it
passes.

**The 18.40s is the evidence, and the dot count was not.** These fixtures decode a 1.79 GB artifact;
a skipped test is milliseconds. A green suite whose artifact-dependent cases quietly skipped would
print the same ten dots and the same `ok`. *So the instrument for "did the expensive check actually
run" is the wall clock, not the pass count* — and it is worth reaching for whenever a suite depends
on a file that may not be there. (5b measured 16.8s independently on their machine.)

What it now does, from the reproduction that produced `verdict: consistent` this morning:

    unbound   consistent-given-the-supplied-answer — binding_checked: false;
              NOT a statement that this artifact came from that inference
    bound     binding_checked: true, verdict: consistent — dsl_hash, artifact_hash and
              artifact_bytes recomputed over the bytes this claim's ids RENDER to under the
              tokenizer it pins, and output_root over those same ids
    refused   a DSL that is not the rendering of its ids; a tokenizer the claim does not pin
              (naming both hashes, never called a forgery); a missing artifact file

**Still open, and the announcement waits on it:** `binding_checked: true` is unreachable from the
shipped gateway, because nothing emits the `PalwJobContextV2` — only its hash. **The check exists
and the operator path cannot reach it**, which is the live-site-versus-search-order defect landing on
the fix for that defect. FH2 carries the context through the worker manifest and the gateway
response. *A disclosure saying "we check this" while no operator path reaches the check is worse than
silence — it is the same false assurance, in the security section.*

### The isolated boot has teeth — rehearsed on ibm, and it refused

Run against the `5f + impl` release binary on a throwaway appdir, unused ports, `--nodnsseed`, no
peers, live producers untouched throughout:

    [INFO ]  PALW court certified end-to-end for: PALW-BASE-0, PALW-QWEN36, PALW-QWEN25-A16
             (court_e2e_root 581466da…)
    [INFO ]  Consensus params fingerprint: 68e1e117…10516612 (network testnet-11)
    [ERROR]  panicked at consensus/src/consensus/utxo_set_override.rs:60:9
             genesis utxo_commitment mismatch (audit M-07)
               left:  ba2612417e7e0817…   what the premine BUILDS
               right: 2d882275dae82945…   what is PINNED
    Exiting...

**The node refuses to start rather than starting wrong**, which is the whole point of the step and
the first time this cut has seen it fire. That refusal is re-pin #1 not yet done — correct, because
the tree is not frozen — so this is the rehearsal succeeding, not the build failing.

**Three things it confirmed that had been reasoned about separately, each now from a running
binary rather than from a test:**

| | |
|---|---|
| the new commitment | `ba2612417e7e0817…` — the same value `print_premine_commitment` prints and `every_genesis_commits_to_the_premine_this_build_mints` reports as "builds". Two routes, one number. |
| the e2e root has NOT moved | boot prints `581466da…`, the pinned value. Confirms re-pin #2 is not live on this tree — the `8f08d303…` move belongs to an unmerged per-kernel drill rule. |
| the fingerprint | `68e1e117…10516612`, matching the pre-re-pin measurement taken independently. |

**So the ordering in §4b — build, then isolated boot, THEN stop and wipe — is load-bearing rather
than tidy.** A node that will not boot is survivable while the old chain is still up and is a dead
network fifteen minutes after the wipe. **The isolated boot must be green before any host is
stopped**, and this run is the evidence it can fail for a reason that is invisible to `cargo test`
until the re-pin is done.

## 5. Known-open, shipping anyway, stated so no page claims otherwise

### No drill anywhere exercises post-genesis registration end to end on a live chain

**Added when devnet's genesis was changed to register testnet-11's class set**, so this is a gap
the decision created and it is stated in the terms the decision was taken in.

Before: devnet registered the dense class **post-genesis**, so the drill walked panel → chain →
certification → budget → production. It never completed — a post-genesis class has no epoch budget
until the next boundary, and devnet's is 1,000 DAA at ~35 s a block, so stages 5b–8 were **~9.7
hours** past the end of any drill. **The path was covered by a run that could not finish.**

After: the class is registered at genesis and budgeted from DAA 0, so the drill reaches the
commitment, the claim, `Final`, the receipt block and the derived MIDI and 3D — **and nothing
exercises the post-genesis sequence on a live chain any more.**

```
what still covers it   the admission DECISION — verify_class_admission_v6 under t11's own
                       shape, from consensus-core and from the SDK preflight, by two authors
what nothing covers    the SEQUENCE — panel signs -> tx on chain -> family certified ->
                       lane bound -> epoch budget -> the class produces
```

**The launch-stopper was found by the unit-level tests, not by the drill** — the drill could not
have found it, because devnet arms the ladder and t11 does not. So this gap costs less than it
reads. *It is still a gap, and the reason it is here rather than in a footnote is that the
alternative was a devnet differing from t11 in two dimensions instead of one, with an unmeasured
rounding in the second.*

### The split close is OPEN, and this is what it costs

Superseding this card's earlier paragraph, which described the release branch before the ADR-0082
merge and was marked stale rather than deleted so the two states stayed distinguishable.

| | |
|---|---|
| `max_close_chunks` | **27** on the RC preset, **1** on devnet; a wider declaration is refused at acceptance |
| when a declaration is legal | **only at Terminal** — the row cannot be opened at round 0 and held under an unfinished ladder |
| assembly deposit | `count × relay fee for 100,000 B` = **33,750,000 sompi (0.3375 MSK)** at 27 chunks |
| when the deposit is collected | on **every ending that is not the close it pinned**, both sides, all five endings — and on no ending that is |
| what it is charged against | **posted collateral, not an escrow.** A poor bond may declare and is charged what it has |
| when a group is swept | its own `assembly_deadline_daa` = declared + 4 × count, at most **108 DAA**, through the same conviction the backstop uses, before the backstop |
| declaration fee | `palw_certification_rent` is `None` on every preset, so the 28,125,000-sompi fee is **not charged**; a declarer pays 28 carrier fees plus the deposit only if it lapses |
| chunk journalling | O(1) deltas — 26 arrivals are **2,611,201 B** against 67,709,897 B in the whole-group form |

**The critical that made "open" dangerous is closed.** The per-block adjudication slot
(`PALW_COURT_CLOSE_MAX_PER_BLOCK = 1`) is now spent only by a move acceptance that was **admitted** —
the counter increments inside the `Ok` arm, after the fence, the signature and the folded state. So
one minimum-fee transaction per block carrying a forged `CourtAttnRootClaimed` can no longer deny
every chunk completion network-wide. That mattered more than a denial usually does: **a close denied
through its assembly window is not a delay but a conviction of the declarer.**

**The hybrid row is still not registered, and the reason has changed.** It is no longer "the split
path cannot be filed" — it can. It is that the hybrid's close is three carriers at every context
width, because it binds a recurrence rather than attention, and there is no width at which that
stops.

*One risk the fixer flagged and I am accepting: a good-faith declarer on the OTHER side is charged
when a verdict ends the session before its own assembly window closes. That is the right call — the
row held the room and will never deliver — and the alternative is one `if` if it proves wrong in
practice.*

**Faucet stays 0.5 tMSK.** The docs carry the real numbers instead: floor 11.2 MSK, A16 2,290,
QWEN36 3,868, plus an 8,333,316-sompi change floor. The faucet does not fund a bond and the pages
say so rather than implying it might.

---

### The ADR names a replay source the shipping code does not have

ADR-0082 Decision 7 says an opening asked for later is *"re-derived by replay from the checkpoint
chunks (`fp_interval`)"*. The fold retains **zero chunk bytes per position** — correct, measured, and
the thing that makes the capture affordable — so an executor serving a folded interval **replays
from the PROMPT**: one forward pass per opening served, not from retained chunks.

The verdicts do not change. The executor's cost per opening does, and by the ADR's own argument that
ratio is the practical lane's first number, so this is not cosmetic.

Closing it needs a retention shape — a live cache held across a claim's life — at one seam, and that
is not in this cut. **So the ADR's sentence is corrected rather than the code.** A document that
describes a stronger system than the one shipping mis-budgets the reader's suspicion: they stop
looking where the doc says the work is done. Fourth instance today, after the court's stale gap
list, the seed reader's format comment, and the free-prompt `tokenizer_id` cross-check that does not
exist.

## 6. Verification gates — every one must be green, and each must have been SEEN to fail

The rule earned today: **the gate you never ran locally is the gate you have never seen fail.**
`cargo fmt --all -- --check` was red on this branch for an unknown length of time, and every "CI is
green except the known pin" said this week was a statement about jobs that never ran.

| gate | command | note |
|---|---|---|
| format | `cargo +<pinned> fmt --all -- --check` | runs FIRST in CI; run it first locally |
| clippy | `cargo clippy --tests --benches --examples -- -D warnings` | must be the pinned toolchain, or it measures a different lint set |
| consensus core | `cargo test -p kaspa-consensus-core --lib` | **1646/2, and both reds are load-bearing** — see below |
| base0 | `cargo test -p misaka-palw-base0 --lib` | 264/0 |
| derive | `cargo test -p misaka-palw-derive` | **NOT `--lib`** — `--lib` builds no binaries, `palw-evm-runner` is absent, and ADR-0079's confinement gate refuses rather than falling back in-process. Those seven reds are the gate HOLDING. |
| cli | `cargo test -p misaka-cli` | 73/0 |
| artifact selftest | `scripts/verify/misaka-palw-artifact-conformance.py selftest` | five damaged artifacts, each refused BY NAME — a test on the exit code alone would call four-of-five a pass |
| doc citations | `scripts/ci/check-doc-citations.sh docs/…-genesis-card.md <merged-tree> palw-testnet-5f`, then the same without the second tree | **the two-tree form first**: it lists only citations that resolve differently on the two trees — the only ones a tree label can change the meaning of. Then the one-tree form against the merged tree, and READ the lines. A REPORT, not a verdict: it exits non-zero only on a missing file or line, because a citation that resolves to the WRONG line still resolves. |
| stranger | `scripts/verify/misaka-palw-derive-stranger.py selftest` | recomputes the bytes in Python, independently of the Rust. **RED right now, and correctly so — read its two halves separately** (below). |
| third party | `scripts/verify/misaka-palw-artifact-thirdparty.py --require` | mido / pygltflib / numpy-stl; compares MEANING (enclosed volume, playback duration) against the DSL |
| model gate, dense | `palw-model-gate` | A16 lane only — declared in advance |
| model gate, QWEN36 | `palw-qwen36-model-gate` | needs the ChatML fix (§7) to pass through the production assembly |
| fused-attention guard | `verify_class_admission_v5` | Refuses an `AttnFused` profile unless `palw_kary_court_active_at` — `FusedAttentionNeedsTheKaryCourt`, *"the class carries a fused attention site and this ruleset's court has no dissection to try it with"*; and `PricedForADifferentCourt { priced, court }` when the registered cost shape's arity is not the court's. **A guard on the way in, beside the drill and not instead of it.** |
| the split close is open | `check_court_close_declaration_acceptance_v2` (W6's signature), `check_close_declared_chunk_count_v2` (the ruleset's own `max_close_chunks`, so devnet's 1 refuses the path rather than engaging it), `palw_court_close_min_fee_v1` (an under-rented declaration is dropped with the block standing) | **Named so a reader can falsify §5 in ten seconds** rather than trust it. Every number here carries where it came from; a behaviour should too. |
| **prosecutability** | ADR-0082 stream I's end-to-end court drill | **This is the gate, and admission is not.** A graph-v5 leaf disputed to the bottom under the ARMED fence set, through `apply_object`: honest acquitted, forged convicted. F's admission arm refusing an unfenced `AttnFused` profile by name is a guard on the way in — useful, and not the property. The property is that a dispute can be carried to a verdict, and only the drill asserts it. |

**The stranger's two SKIPPED cases are the refusal cases, and the gap is structural.** Its per-file
output includes:

    91-over-max-steps.json          SKIPPED: cad op 'extrude' is outside this verifier's subset
    92-over-max-artifact-bytes.json SKIPPED: cad op 'revolve' is outside this verifier's subset

So `MAX_STEPS` (4,000,000) and `MAX_ARTIFACT_BYTES` (1 MiB) are confirmed **only by the
implementation under test**. `MAX_DSL_BYTES` is fine — `90-over-max-dsl-bytes` refuses for the same
reason on both sides, because a byte count is checked before any op runs.

**And it cannot be closed with a cheaper fixture, which is worth knowing before someone tries.** The
two limits are reachable only through the two high-amplification ops, and the kind's own doc says
why: *"The boolean reaches none of them, because `BOOLEAN_LEAVES_MAX` is DERIVED from the artifact
ceiling rather than declared: it is the largest leaf count whose worst-case lattice still fits. So a
boolean the grammar admits is never refused by a bound."* A `box`/`boolean` fixture — the ops the
verifier does implement — therefore **cannot** trip either ceiling by construction, and 64 KiB of
DSL cannot describe enough boxes to reach 1 MiB of STL anyway; it would trip `MAX_DSL_BYTES` first
and test the wrong limit.

Closing it means implementing ear clipping and revolve in the Python verifier — which is precisely
the `n³` work its refusal message declines. **Shipping with this open**, stated here rather than
discovered: the two ceilings an attacker would push on are pinned by one implementation. The skip is
loud, so it is a coverage gap and not a false green. *(That `BOOLEAN_LEAVES_MAX` is derived from the
ceiling rather than declared is the same one-spelling rule this cut enforces everywhere else — the
gap exists because the design is right, not because it is wrong.)*

**The stranger gate's red is a STALE PIN, and its summary line does not say so.** It prints
`SELFTEST FAILED — 3 of 18 checks disagree with the shipped tree`, which reads like a verifier that
disagrees with the build. It is not. The 18 checks are two different kinds and they must be read
apart:

- **Oracles 1–4 — all GREEN.** Every corpus file's `dsl_hash`+`artifact_hash` MATCH, every refusal
  refused for the same reason as the shipped tree, every corpus file has a golden entry, and a
  tampered `artifact_hash` is caught with exit 2. *This* is the property the gate exists for: an
  independent Python implementation reproduces the Rust byte for byte.
- **The 3 reds are all `recomputed X, pinned Y`** — `source_tree_sha256` and the two
  `transformer_id`s. Nothing is disagreeing with anything except a frozen constant, and it is stale
  for a reason the tree can name: two commits have touched `misaka/palw/derive/src/` since the pin
  was last set at `d16fb54e` — `a87cc282` (a formatting pass; formatting is inside the hash) and
  `81c1ca1d` (the alphaMode fix). This is re-pin #5, on schedule.

**So the failure mode to guard against is reading the summary line instead of the split.** A red
ORACLE would be disqualifying — it would mean the second implementation and the shipped one produce
different bytes, and the gate says so itself: *"a second implementation that is wrong proves nothing
and accuses the innocent."* A red PIN is a chore. Both print under one `SELFTEST FAILED`. Before the
cut this gate must be green outright; before then, check that the reds are exactly three and all of
them of the `recomputed/pinned` shape.

*(The pins live in `misaka/palw/derive/tests/`, outside the `src/` tree the hash covers, so writing
the new pin does not move the hash it pins. That is why §4 step 3 can be a single commit.)*

**On the MERGED tree** (`5f + adr0082-impl + the family branch`), measured by a session that wrote
none of the pins: `kaspa-consensus-core --lib` is **1,790 passed / 3 failed**, and the same three
with that session's own changes stashed — so nothing in the merge caused any of them. The three are
the premine commitment, the shipped fingerprints, and `palw_freeprompt_v3::tests::golden_vector_ids_are_frozen`.
The gate run there is **15 passed / 4 red, and all four are pins on the ordering above.** Nothing on
that tree is red for a reason the freeze will not clear.

**On this branch alone: 3,809 tests run, 3,807 passed, 2 failed** —
`cargo nextest run --no-fail-fast`, 720 seconds. Both failures are the pins below.

**Run it with `--no-fail-fast` or do not quote it.** The default run reported *"353/3809 tests run:
352 passed, 1 failed"* and stopped at the first pin. "One red" was true and said nothing about the
other 3,456 tests, which had not executed. A count of failures among tests that ran is not a count
of failures, and the gap between the two was three and a half thousand.

**The two expected reds, and the condition that closes each.** A branch with unexplained reds has
no gate; a branch with reds nobody wrote down has a worse one, because the next person greens them.

| red | closes when |
|---|---|
| `shipped_presets_have_pinned_fingerprints` | §4's single re-pin, after the freeze. Owned here. |
| `the_shipped_ruleset_admits_the_row_the_genesis_registers` | the ruleset's `COURT_MAX_STEP_LEAVES` moves to a cap that admits n_ctx 512 — **2^26 is the smallest**. Owned by whoever makes that change; it goes green by measurement, not by assertion. |

**The second red WAS the whole width story, and the move has since happened — this paragraph is kept
because its correction is the point.** It read: *"the ruleset's field is set to that same constant,
`COURT_MAX_STEP_LEAVES = PALW_STEP_MAX_LEAVES`, so W1b moved no width at all … the registered class
is capped at 39 positions."* That was true when written and is now false:

    consensus/core/src/palw_fp_devnet_v3.rs:367
    pub const COURT_MAX_STEP_LEAVES: u64 = PALW_RC_COURT_MAX_STEP_LEAF_COUNT;   // 2^26

The ladder moved to 2^26, `the_shipped_ruleset_admits_the_row_the_genesis_registers` is green, and
the 512 row clears it with 21.4% margin. **W1b's second half landed and this card went on saying it
had not**, for the ordinary reason: nobody re-reads a paragraph whose conclusion still feels right.
*A "known open" that has quietly closed is the same defect as a claim that has quietly broken — both
are the document disagreeing with the tree, and only one of them looks like good news.*

Measured, and reproduced independently from two crates by two sessions:

| ruleset cap | widest admissible n_ctx (A16) | admits the registered 512 row |
|---|---|---|
| 2^22 (shipped today) | **39** | no — the registered row needs **52,778,128**, has 4,194,304 |
| 2^23 | 79 | no |
| 2^24 | 156 | no — opens every grammar floor, at a class narrower than the registered one |
| **2^26** | **574** | **yes**, with **21%** headroom (14,330,736 of 67,108,864) |
| 2^28 | 1,833 | yes |

2^24 is the trap: it opens cad 38, music 60 and scene 104 and still tops out at 156, so it would
open MIDI and 3D **at a narrower class than the one being registered** — which means deriving a
third class id, which is the loop §2 exists to end.

`the_registered_row_names_the_ladder_it_needs` pins that table and is GREEN; it is arithmetic about
profiles and holds whatever any network froze. The red one is the other question.

**Why this row exists at all.** Every wrong turn on this card came from measuring admissibility and
reading it as usability: the 512 row, the hybrid's margin, the court the close was priced under.
Admissibility is what the tree kept measuring because it is what the tree made easy to measure. The
gate above is the one that would have caught all three.

---

## 7. Must land before the cut

- **ADR-0082 full implementation** — §3 makes this a precondition, not a preference. Includes the
  `palw_kary_court` fence itself (§1), and stream E's court wiring: the dissection phase on the
  court session, the `AttnDissection` close-proof arm, the deadline read, and a **state version bump
  18 → 19** because the session record gains a field.
- **THE 512 ROW HAS NO GENESIS BUILDER, AND §2 SAYS IT IS REGISTERED.** Checked by looking rather
  than assumed: the class this entire card is about appears in **zero** `.rs` files on
  `palw-testnet-5f`, `palw-adr0082-impl` or `palw-artifact-names-genesis-row` — no constant, no
  `ClassRegistered`, no builder. §2's table lists it as registered at genesis and nothing registers
  it. The three that DO exist live in the profile modules, not `params.rs`, and that is where the
  fourth belongs:

      consensus/core/src/palw_qwen25_profile.rs:616   qwen25_a16_registration_v2   <- params.rs:4796
      consensus/core/src/palw_qwen36_profile.rs:1411  qwen36_registration_v3       <- params.rs:4789
      consensus/core/src/palw_base0_profile.rs:764    palw_rc_base0_registration_v1

  **It must carry a carriage**, because `verify_palw_genesis_v2` now refuses a fused row minted at
  genesis whose `ClassRegistered` has `admission: None` — `GenesisFusedRowCarriesNoProfile`,
  `GenesisCarriageIsNotTheClass`, `GenesisFusedDisagreesWithCatalog`. **Its signature is empty and
  that is correct, not a concession**: genesis verification never reads `.signature` (the only
  verifier is the acceptance layer at `consensus/src/pipeline/virtual_processor/processor.rs:6099`),
  a signature authenticates *who moved a permille from every incumbent* and at genesis nobody did,
  and it would anyway be checked against a `registrant_bond` key that the same genesis object list
  is creating.

  **FG MUST NOT ADD A SECOND A16 ROW AT WIDTH 512.** `bind --artifact` resolves without a
  `--model-id` because the width is unique in the table, and that uniqueness is a property of the
  TABLE, not of the code. The five A16 rows, printed by the tests rather than asserted:

      Qwen/Qwen2.5-1.5B                    16
      Qwen/Qwen2.5-Coder-1.5B-Instruct     18
      Qwen/Qwen2.5-1.5B/graph-v2           16
      Qwen/Qwen2.5-1.5B/graph-v3           16
      Qwen/Qwen2.5-1.5B/graph-v5@512      512   <- the only row at its width

  At 16 the route already refuses with `AMBIGUOUS at 16: [three rows]` rather than picking — which
  is the right behaviour and also the proof that a sixth row at 512 turns the working
  `bind --artifact` into an `AmbiguousAtWidth` refusal. It fails LOUDLY rather than binding wrong,
  so it is a liveness risk and not a safety one — but it would arrive on cut day as "certify
  suddenly refuses", against a tool that worked an hour earlier, at the moment nobody has spare
  attention. FG is the commit that would be adding rows near that width.

  **And the artifact→class pairing is now RUN rather than argued.** With the real 1,795,427,276-byte
  `qwen25-1.5b-a16.palwart` present, `the_shipped_artifact_names_the_row_genesis_registers` and
  `the_binary_binds_the_genesis_row_from_the_shipped_artifact` both pass (9.4 s and 9.6 s — they
  decoded the file). `decode_artifact_file_v1` recomputes the declared digest over every byte, so
  the id comes from **the file's own header**, not from a second computation of this build's. That
  is the pairing this section said nothing forced to agree.

  **The class id must be DERIVED and reported, never quoted into the builder.** `shape_profile_id`
  is `keyed64` over the borsh of the profile, so the id is whatever the profile derives to — and
  three adjacent ids are loose in this project's notes for three different things: `4277d84f…` from
  the registration/certification/artifact chain, `71bbb755…` which is what the panel actually
  registered at n_ctx 16, and `8d2e6f16…` which `palw-certify bind` produced from the artifact's own
  512 row. Reconcile the derived value against the artifact and the certification path before the
  freeze. *A class id quoted from a summary is what burned `n_ctx 17` on 2026-08-28.*
- **A one-line test for the 512 close, so the announcement can cite a command instead of a number.**
  `the_512_close_is_one_carrier`: assert `derive_court_cost_shaped_v1` over
  `palw_a16_context_row_profile_v5(512)` at `PALW_RC_COURT_MAX_STEP_LEAF_COUNT` is **one carrier**,
  and print the byte figure with `--nocapture`. Assert the CARRIER COUNT (stable, and the claim that
  matters); print the bytes (moved three times: 81,599 → 82,719 → 81,312). *This item exists because
  the announcement cited that test before it was written — the card-without-the-test defect, made by
  the person who had spent the day naming it, in the public-facing document.*
- **THE DERIVED-ARTIFACT BINDING — no shipped verifier ties an artifact to the inference it names.**
  Reproduced with the shipped binary: `palw-derive verify` recomputes `dsl_hash`/`artifact_hash`
  from the caller's ANSWER BYTES and `output_root` from the caller's TOKEN IDS, ANDs them, and
  prints `verdict: consistent` for an artifact whose DSL has nothing to do with those ids.
  `rendered_output_hash_v1` hashes the *ids* rather than the rendered text, so `output_root` carries
  no information about the answer bytes and the two arms cannot meet by accident. **An executor can
  attach any artifact of any kind to any of its own claims and every verifier in this release calls
  it consistent** — and the forger must be the claim's own executor, which is precisely the party
  ADR-0078 Decision 5 says a consumer should not have to trust.

  Every piece is already in the right crate, checked rather than assumed:

      misaka/palw/derive/Cargo.toml:30      misaka-palw-base0 is a real [dependencies] entry
      misaka/palw/base0/src/fp_worker.rs:851  render_answer_v1(&QwenTokenizer, &[u32]) -> Vec<u8>
      misaka/palw/derive/src/derive.rs:226    already calls misaka_palw_base0::* on this path

  so the missing step is one call — `canonicalize(render_answer_v1(tok, ids)).dsl_hash ==
  object.dsl_hash` — and the only input not in hand is the tokenizer, which `PalwJobContextV2`
  already pins by id.

  **Two parts; the first is mandatory even if the second slips.** (1) `verify` must never print an
  unqualified `consistent` for a binding it did not check — `binding_checked: false` and a word that
  does not read as "this artifact came from that inference". (2) `--artifact <path>` loads the
  tokenizer and performs the join, skipping by name when absent.

  **Ordering:** both files are under `misaka/palw/derive/src/`, so this moves all eight
  `transformer_id`s. It must land **before** the single `fmt --all` and before the tree is declared
  frozen, or the re-pin is stale on arrival. `scripts/ci/check-derive-freeze.sh` is the check.

  *This is the one place the release's own promise — that a stranger can check a claim without
  trusting the claimant — is not kept, and it is the place the launch is named after.*
- **The 2^22 sweep (fixer FD2).** The ladder went to 2^26, but `2^22` survives as a bare literal at
  a set of sites the ladder change did not reach — and the 512 row's canonical job is **6,630,544
  leaves**, so until they move, *every honest claim of the class this genesis registers is refused
  by the transition*. `palw_freeprompt_v3.rs:1030` (`WorkLeavesAboveCap`) is the one that refuses on
  the acceptance path; the others are the E2E certificate's declared count, the genesis catalog
  entry's counts, the schedule's leaves, and `PALW_STEP_LEG_MAX_LEAVES` — if the leg shape pass
  bounds at 2^22 the row's leg cannot be committed at all. **Plus one the first sweep did not
  name:** `derive_court_cost_v1` (`palw_class_admission_v2.rs:293-295`) anchors `genesis_anchored_v1`
  at `PALW_STEP_MAX_LEAVES` = 2^22 while the RC ruleset ships 2^26, and three of its six production
  callers build the `court_cost` field of a `PalwClassCatalogEntryV2` — the registration row itself
  (`palw_qwen36_profile.rs:1422`, `:1502`; `palw_base0_profile.rs:805`). Either the catalog row and
  the v6 gate derive at different ladders and every genesis row is refused by its own cost field, or
  nothing compares them and the catalog publishes a cost for a court that will not play. The gate
  for this bullet is one end-to-end test: a 6,630,544-leaf v5 commitment passes every layer under
  the RC bundle, is refused **by name** under a 2^22 one, and the v5 row's catalog `court_cost`
  equals what the v6 gate derives under the RC bundle.

  *Why it was found this late: J's drill never reached stage 5, so no v5 claim had been executed
  through the chain. A cap nothing has yet exceeded is a cap nobody has yet seen refuse.*
- **NOBODY MAY APPEND A VARIANT TO `PalwConsensusObjectV2` ON 5f** until E's wiring lands. The Borsh
  discriminants are positional; W5 already appended two, and E appends three more. A fourth appended
  in parallel collides by number, and the collision is silent until two builds disagree about what
  an object is.
- **The QWEN36 lane's own chat renderer** — the lane serves Qwen3.5 through Qwen2.5's template. The
  model's own template appends a `<think>` preamble in BOTH modes; there is no branch that stops at
  `assistant\n`. Under the shipped assembly **4 of 8 correct answers were refused at column 1** and
  2 more burned their budget on an open reasoning trace. The preamble must be `Special(id)` — as
  text it becomes BPE pieces through ADR-0079 D7's `encode_without_specials`.
- **A way to certify the 512 row.** The A16 catalog is a fixed three-row table — `Qwen/Qwen2.5-1.5B`
  at n_ctx 16, `Qwen/Qwen2.5-Coder-1.5B-Instruct` at 18, `Qwen/Qwen2.5-1.5B/graph-v2` at 16 — and
  `palw-certify bind` takes only `--model-id`, with no `--n-ctx`, no `--class-id` and no
  `--artifact`. **So the certification tool cannot bind the class this card registers.**

  This is not a missing feature. It is **an identifier that does not identify**: a model id does not
  determine a width, `n_ctx` is inside the identity, and so everything downstream is a
  `ClassLaneCertified` for the wrong class or none at all. Under ADR-0075 the lane then ships
  CLOSED and the demonstration refuses on the first request — a refusal that reads to whoever runs
  it exactly like the width wall, which is the failure this card exists to prevent.

  **Fixed by naming the class, not by adding a row.** A 512 catalog row would make the drill green
  and is unfalsifiable: a wrong width binds to the wrong class silently, where a named width fails
  to bind. The table has already failed in that exact direction — its own comment marks
  **n_ctx 17 BURNED** by a 2026-08-28 mispairing that registered a class on chain against the
  genesis constant, past a green suite. So `bind` gains `--artifact`, deriving the profile by
  calling what the panel calls rather than writing a second spelling of it. The underlying defect is
  one class root spelled two ways — from the artifact's inventory and from a constant — with nothing
  forcing them equal, which is the A16 genesis root defect again.

  **Both ends now measured, not inferred:**

      registered by the panel   71bbb755…   the catalog's graph-v2 row at n_ctx 16
      certified by bind         8d2e6f16…   the artifact's own row at 512

  **And `--artifact` alone does NOT fix it — that prescription was wrong.** All four ids derived and
  printed on the merged tree, which is what turned a suspicion into a defect:

      a16 graph-v2/v3  n_ctx  16   7a76d29b…  fused false
      a16 graph-v5     n_ctx  16   1ae17978…  fused true
      a16 graph-v2/v3  n_ctx 512   8d2e6f16…  fused false   <- what `bind` produces
      a16 graph-v5     n_ctx 512   4277d84f…  fused true    <- what genesis registers

  `8d2e6f16…` is **graph-v2 at 512**. So `bind` is not merely binding the wrong WIDTH, which is what
  this section assumed — it binds the wrong GRAPH, at the right width, differing only by the fused
  site. Deriving from the artifact does not help by itself: the artifact header declares geometry
  (family, width, eps) and **no graph**, so `bind --artifact` projects it through
  `a16_row_for_artifact_shape_v1` → `palw_a16_context_row_profile_v1` and lands on v2 again.

  **The correct derivation already exists and is already tested.** J shipped
  `classes::a16_artifact_row_v1`, which projects the same header through
  `palw_fuse_attention_site_v5` over the graph-v3 dense row with the artifact's own epsilon and the
  tiled v3 map — **with an equality test pinning that it derives the same `shape_profile_id` as the
  genesis row.** The fix is that `bind` calls the other one. *The forcing test existed and the
  production path took the other spelling anyway*, which is this project's fourth instance of one
  class root spelled twice with nothing making them equal.

  **The test to add is not "the two derivations agree" — J has that and it did not help.** It is
  that `bind --artifact` over `instruct-bound.palwart`, through the binary's own argument parsing,
  prints `4277d84f…`. A unit test that builds both ends from one source of truth checks nothing.

  The registered value is printed by the panel that computed it rather than scraped from a log —
  an earlier reading came from `grep -oE '[0-9a-f]{128}' | tail -1` and was returning block hashes.
  **A value an operator is asked to match against a certificate has to be printed by the thing that
  computed it.**

  *It is in no test because no test registers a class it did not also define.* A rehearsal found it.

- **A drill fixture for the fused attention kernel, and it must land BEFORE the family's union.**
  `graph-v5@512` reaches ten kernels; nine are covered by the certified dense family and
  `09b81d17ed5a73ef…` is in none. So no `FamilyCertified` can be produced for the row and both lanes
  ship closed.

  §2's union ruling puts that kernel in the family's declared set. **A family that declares a kernel
  it has no fixture to drill is a certificate asserting an adjudication nobody has performed** —
  strictly worse than the honest refusal, because today the class cannot be certified and says so,
  and with the union alone it would be certified and the assertion would be empty. The first person
  to discover it would be a challenger unable to open a dispute over a kernel nobody had proven the
  court can score.

  And the fixture has to be judged by what it PROVES, not by existing: **a fault vector the court
  scores identically to a correct execution certifies nothing, and that failure looks exactly like
  success.** If it cannot be authored in this cut, the choice — register the row uncertified, or do
  not register it — is a genesis decision and belongs here, not in a declaration.

  *Two things this is NOT, both checked in the source rather than reasoned about:* it is not the
  court — `shape_profile_id` hashes the profile's borsh and no court field is in that struct, and
  `canonical_classes_v1`'s second line is `let _ = court;`, so the court parameter is decorative
  with respect to class identity. W3's `max_close_chunks` is not implicated.
- **Re-bind the dense artifact's tokenizer — from the INSTRUCT checkpoint, not the base one.** The
  shipped `qwen25-1.5b-a16.palwart` carries 64 zero bytes where the tokenizer commitment goes, and a
  zero commitment pins nothing: a replay with a different `tokenizer.json` produces the same
  artifact. Re-binding needs a re-conversion.

  **It must be `Qwen2.5-1.5B-Instruct`, sha256 `dd924a11…`, not the base checkpoint.** The file on
  this Mac is the BASE model — `a961db72…`, `config.json` 684 bytes; Instruct is `dd924a11…` with a
  660-byte config. **Both safetensors are exactly 3,087,467,144 bytes, so size does not distinguish
  them**, and the `tokenizer.json` is identical in both repos, so a tokenizer commitment computed
  from either reproduces the same value and confirms nothing about which weights were read.

  Converting the base checkpoint produces a *valid, faithful, deterministic* artifact — same size,
  same 434,440 operands, same class id `8d2e6f16…` through `bind --artifact` — whose weight body
  differs from the shipped one in **484,183,979 bytes as ±1 in int8**, which is exactly what a
  fine-tune delta looks like after quantization. Its inventory root is `2246a380…` against the
  shipped `1a7457f1…`.

  **Nothing derived from the base checkpoint may be registered.** Expect digest `c00faa48…` from the
  Instruct conversion, with only the commitment field moving.

  **Do it on `ibm`, where the inputs already are** — `/root/palw-class/qwen25-src/` holds the Instruct
  config (660 B), safetensors (3,087,467,144 B, sha256 `dd924a11…` confirmed on the machine that ran
  the original conversion) and tokenizer (7,031,645 B), and `/root/qwen25-pipeline.sh` is the script
  that produced the shipped file. Nobody downloads 3 GB.

  **Provenance, closed except one line.** The conversion ran **2026-08-27 17:10–17:20** on ibm from
  `Qwen2.5-1.5B-Instruct`, and the artifact was then distributed as a binary — identical sha256 on
  ibm, C and the operator box. The 08-30 23:21 timestamp on this Mac is the *copy landing*, three
  days later, which is why a local mtime said nothing about provenance. **What is still unrecorded is
  the converter REVISION**: the pipeline log records the build succeeding, not what it built from.
  That is answerable by walking `/root/misakas-t11r`'s reflog — unknown rather than unknowable — and
  the quantization code has not moved since.

  *Recorded because the trap is well disguised: two checkpoints of identical size, a shared
  tokenizer, and a converter that is deterministic and correct on both. The class id survives the
  swap — it hashes the PROFILE, and no weight is in the profile — so `bind --artifact` reports the
  same class for the wrong model. Only a weight-derived value, or the checkpoint's own sha256,
  tells them apart.*
- ~~Re-bind the dense artifact's tokenizer~~ — **DONE, and characterised to the byte.**

  | | value |
  |---|---|
  | input | `Qwen2.5-1.5B-Instruct`, `sha256 dd924a11…` verified on this machine after transfer |
  | tokenizer commitment | was 64 zero bytes at offset 1,777,209,032; now `fa9a4352…` |
  | container digest | `c00faa48…` → **`158314b5…`** (a genesis input) |
  | everything else | **byte-identical** — 128 bytes differ in a 1,795,427,276-byte file, and they are those two 64-byte fields |
  | faithfulness | 45/57 top-1, unchanged — the same weights |

  **And the reproducibility claim is now proven rather than argued.** Running the ORIGINAL converter
  on ibm against the same checkpoint reproduced the shipped artifact with **zero differing bytes**.
  So `qwen25-convert`'s own doc — *"a verifier re-runs this and compares the class id, which is why
  the conversion has to be bit-reproducible"* — is a property this build has, demonstrated on two
  machines with two binaries.

  **The swap is verified, not assumed.** The bound file was put through `palw-certify bind
  --artifact` and it decodes — 1,795,427,276 bytes, declared digest recomputed over every byte —
  and **names the same class as the shipped one**, with the same twelve reachable kernels covered by
  the same family. So binding the tokenizer does not move the class the artifact names, which is
  exactly what the replacement needed in order to be safe.

  The bound artifact must replace the shipped one at the cut; `from_registered_profile` refuses the
  unbound file, so the dense SDK path does not work until it does.

  **Distributing it costs 128 bytes, not 1.8 GB.** Every host already holds the shipped artifact,
  and the bound one differs from it in exactly two 64-byte fields. Writing those two fields in place
  and checking the result's sha256 against the converted file's is a complete verification — the
  hash covers every byte, so a wrong patch cannot produce a right hash, and there is no partial
  state between "identical" and "not". Done and confirmed on the fleet's first host:

      sha256(bound artifact, converted here)   3f8fc5066bafae28d81b2360227a08e43fdb961ee6355938c56d32edf19d7623
      sha256(shipped artifact, patched there)  3f8fc5066bafae28d81b2360227a08e43fdb961ee6355938c56d32edf19d7623

      offset 1,777,209,032   fa9a4352…a649bb   (tokenizer commitment, was 64 zero bytes)
      offset 1,795,427,212   158314b5…bf6450   (container digest)

  The alternative — transferring 1.79 GB per host over a link measured at 2 MB/s — costs half an
  hour each and is not more trustworthy, because it would be verified by the same hash.
- **Toolchain pinned** and the CI gates runnable in one local command
- **The single re-pin**, in the order of §4

---

## 7b. Arming `palw_kary_court` — a checklist, not a sentence

§1 arms this fence at genesis. It must not be armed until every line here is closed, and each one
is a finding from the audit wave rather than a precaution.

- [ ] **Five criticals in the dissection court's bindings.** All one shape — *a derived value
      computed and not compared*: the root claim's `history_positions` taken from the wire; `S*`
      unvalidated, giving an i64 overflow panic **inside block validation**; bottom openings unbound
      to coordinates; the anchor unbound to the derived checkpoint; and no clock on the responder's
      root claim, so silence at Terminal wins challenger-side.
- [ ] **The engine executes the real fused node on the registered artifact, not only synthetic
      material.** The refusal — "per-layer declares 24 against 27 recorded" — is
      `profile.attn_nodes.len()` of a graph-v5 layer table (**27 − 3, the fusion's net removal**)
      against a hard-coded 27-row v4 program in the plan-LESS route. The PLANNED route already
      executes the fused site and is bit-equal to the reference on real geometry; only
      `Qwen25A16Backend::new` refuses, and chain-registered classes go through
      `from_registered_profile`, which plans. Until it lands, a `FamilyCertified` would cover a
      kernel nothing has executed on the row the genesis registers.
- [x] **`(v − max) << up` wraps i64 before the clamp** in `softmax_shifted` and `a16_attn_exp_one`
      for `up_bits ≥ 47` — a key 40,000 below the maximum receives full weight. **MEASURED on the
      shipped artifact: the maximum across all 28 layers is 25.**

          layers 28    values {14, 15, 16, 18, 21, 25}    max 25    threshold 47

      Read out of the artifact's own `attn_softmax_up` entries, one byte per layer, on the bound
      file. **So the fix moves no committed value for the class being registered** and is free
      whenever it lands, rather than free only before the cut. It still belongs in the arming set —
      a class at a higher `up_bits` would be silently wrong — but it stops being an ordering
      constraint on the freeze.
- [ ] **The window must fit a dispute a session actually PLAYS.** The derivation prices a k-ary LEAF
      ladder no session plays — the ladder is binary and only the history search is k-ary. At RC
      numbers the played dispute is **60 moves × 51 + 216 reserve = 3,276 against a 3,000 window**,
      so Z4 is violated and **an honest prosecution times out.** Being re-derived; **if no arity fits
      the 512 row inside the RC window, that is a genesis decision and comes back here.**
- [ ] **The arity has two spellings** — a bundle literal of 2 against a derived 4, with admission
      comparing the wrong one and nothing asserting they agree. Fourth instance of one-thing-two-homes.
- [ ] **The cost walk caps at 2^22** (`genesis_anchored_v1`), so the 512 row is refused with
      `TooManyLeaves` on a 2^26 network — the same 2^22-against-2^26 mismatch as the executor's
      ladder, in the cost arm.
- [ ] **Post-genesis registration calls `verify_class_admission_v3`** — no court, no ladder — so no
      graph-v5 class can ever register post-genesis; and **genesis minting runs no admission gate at
      all.**
- [ ] **A second pinned cross-machine determinism digest for the v5 base** (ADR-0067 D5 is pinned
      only for the v2 fuzz corpus). A new pin produced by a run, not a moved one.

*The 27 − 3 above also settles §2's family ruling by measurement: the fusion removes four kernels
and adds one, so a family derived from the v5 row alone would drop `ATTN_SCORES` and `ATTN_VALUES`
and stop covering the rows already on chain. The family's `kernel_ids` are the UNION over every row
the lineage ships.*

## 8. Announcement wording — the claims the evidence actually carries

- **"The QWEN36 lane produced a grammar-valid description" is what the evidence carries.
  "Qwen3.6 wrote this file" is a different sentence.** The 35B weights are not on the machine that
  measured this (19 MB of metadata and an empty directory); what ran is `qwen35-2b.palwq36`, the
  QWEN36 lane carrying a 2B model.
- **512.** Not "thousands of tokens" for the registered row's width — 512, with ~500 decode tokens
  and about 1,200 bytes of answer.
- **"Thousands of tokens" is exact for the flat close; "tens of thousands" is not.** A graph-v5
  dense close is flat except the prompt-id term only to about n_ctx 4,096 — 80,504 at 512 and
  80,696 at 4,096, **192 bytes for eight times the context**. At 32,768 the binding node becomes
  the embedding gather and the generated-token ids are a second context-linear term ADR-0082 D5
  does not anchor; it Merkle-izes the prompt ids only.
- **The dense tier's faithfulness is 45 of 57, not 57 of 57.** The shipped artifact's own conversion
  log records `a16 top-1 agree 45/57`, `top-5 contains 56/57`, `rank corr (100) 0.8932` against the
  float reference, and calls that FAITHFUL — which is the bar the class passed, measured at
  conversion time rather than asserted. Say the number if the subject comes up; do not let a page
  imply the quantized class reproduces the reference exactly. (An independent conversion here of the
  *base* checkpoint landed at 44/57 and 0.8627, so the figure is characteristic of the quantization
  rather than of one lucky run.)
- **The model's answer IS the artifact's source, canonicalized** — this is the central claim and it
  is now re-runnable: `palw-model-gate` and `palw-qwen36-model-gate` ship, and
  `docs/evidence-qwen36-model-gate/` carries the answer bytes and the artifacts derived from them.
- **5e had known unpatched defects while it ran.** The security-lane commit messages describe them
  and they are public. Say so; do not let someone else say it first.

---

## The instrumentation I wrote to measure the last open gap had two defects, both already written down

The three worker-dependent agent tests are the one measurement still open. I drove them
on ibm from a script — `/root/agent-recovery.sh` — and the script contained **two defects
this session already has notes about**. Neither produced an error.

### 1. `| tail -4` on the build, again

```
nice -n 19 cargo build --release … --bin palw-worker 2>&1 | tail -4
```

The four lines that survived were: half of a doc comment, `note: run with RUST_BACKTRACE=1`,
`warning: build failed, waiting for other jobs to finish...`, and `WORKER MISSING`.
**The `error:` line is above the window.** The log is 273 bytes and says the build failed
without saying why — so `grep -n '^error'` over the whole file returns nothing, and the
file reads as though there were no error at all.

This is the second time today. The rule is not "use a bigger tail":

> **Truncate the summary, never the diagnostic.** A tail is a display decision applied to
> a stream whose important line is at an unknown position. Write the whole thing to a file
> and grep it; `tail` the grep, not the build.

### 2. `pgrep -f agent-recovery.sh` matched the ssh command that was asking

My first check printed `script: 2` and I read it as "the run is in progress". The script
had **exited 1 twenty minutes earlier**. Both matches were shell processes whose *command
text* contained the string — one of them the `ssh … pgrep …` I had just typed.

I have a memory file about exactly this (`pgrep -f の待機ループは自分に一致する`) and it
did not fire, because last time the shape was a `until ! pgrep -f` **wait loop** and this
time it was a one-shot **census**. The stored lesson was attached to the loop, not to the
predicate.

The second invocation printed the proof in its own output:

```
2505482 bash -c … pgrep -af "bash /root/agent-recovery.sh" …   <- the asker
2505485 bash /root/agent-recovery.sh                            <- the actual script
```

> **A process census that includes the censor is off by one, and the one is always yours.**
> Match on the executable (`pgrep -x`), or on a pid you recorded when you started it, or
> require the count to drop rather than to be nonzero.

### What this cost, and what it did not

Nothing in the cut moved: the four re-pin values are unaffected, and the tests concerned
are already listed under §5 as a **stated gap**, not as a green. What it cost was twenty
minutes of believing a measurement was running when it had failed, which is the cheaper
half of the same defect — the expensive half is believing a measurement *passed*.

The rerun captures the full build output and is running now. **Whatever it says, the honest
line in §5 is unchanged until the tests are observed, and if the build error turns out to
be something other than the pinned-llama.cpp link I named, then my stated reason for the
gap was wrong even though the gap was real** — a true fact with a fabricated cause, which
is the form that survives review because the conclusion checks out.

### Correction, same hour: I named the group after one of its three files

I have been calling them *"the three `palw_agent_recovery` tests"*, and 1c wrote the phrase
back to me in their ledger. They are **three tests in three different files**, one each:

```
palw_agent_recovery::a_dead_agent_costs_a_delay_and_not_a_tag
palw_agent_concurrency::concurrent_seeds_are_faster_and_are_the_same_tags
palw_agent_equivalence::the_resident_agent_and_a_fresh_process_compute_the_same_tag
```

The number was right; the **address** was wrong. And the address is what a command consumes:
my script ran `cargo test --test palw_agent_recovery -- --ignored`, which builds and selects
**exactly one binary**. It would have printed `1 passed` and I would have reported that the
three had run. *A group named after the member you happen to know will be selected by that
member's name.*

1c got the complete set — but by tooling, not by knowing the layout, having never checked
the files either:

```
cargo nextest run --run-ignored all --no-fail-fast \
  -E 'test(the_resident_agent_and_a_fresh_process_compute_the_same_tag) or
      test(concurrent_seeds_are_faster_and_are_the_same_tags) or
      test(a_dead_agent_costs_a_delay_and_not_a_tag)'
```

> **Prefer the selector whose output proves its own reach.** nextest names the *binary* on
> every result line, so three distinct binaries in the output is the evidence the filter
> found all three. `--test <file>` prints `1 passed` and looks identical to a complete run
> of a one-member set. **The count in the result is not evidence about the size of the
> intended group unless the result also names what it selected.**

### And the gap's stated cause was right while its consequence was not

The build panic is verbatim what §5 claims:

```
misaka-palw-worker links the PINNED llama.cpp build, which this repository does not
contain, and MISAKA_LLAMA_SRC is not set.
```

But **`misaka-palw-pow-driver` does not depend on that crate.** The tests spawn the worker
as a **subprocess** from `$PALW_WORKER`. They need a *binary*, not a *build* — and ibm has
two prebuilt ones (Aug 14 and Aug 16), both of which execute. So the sentence *"they cannot
run"* did not follow from the true fact I attached it to.

> **A correct cause with an unchecked implication is harder to catch than a wrong fact**,
> because the quotable part survives every review. The thing to check is not the citation;
> it is the *therefore*.

Same shape, one line further: I have been carrying **"`palw-worker` runs on all three fleet
hosts."** `pgrep -x palw-worker` on ibm is **0**. The binaries are present and executable
and nothing is running one — the re-executor spawns it on demand. *"Runs on" carried an
implication nobody tested.*

All three are running on ibm now against the real 1.2 GB pinned model. **Two caveats stated
before the result rather than after it:** the ibm checkout is `8923b354` detached — **not
the tree being cut** — and the worker binary is three weeks old, so an equivalence pass is a
pass against a stale counterpart. Whatever colour it comes back, it is evidence about the
property and not about 5f's copy of these tests, and §5 keeps its stated gap.

### The run happened, it went red, and the red is about the fixture — measured, not inferred

`a_dead_agent_costs_a_delay_and_not_a_tag`, on ibm, with the real 1.2 GB pinned model:

```
test result: FAILED. 0 passed; 1 failed   finished in 41.36s      (WALL 131.26 s)
panicked at palw_agent_recovery.rs:79:5:
  no resident agent was running to kill — the first seed did not use one
```

**41.36 s is the first thing to read.** The `--run-ignored all` version of this failure took
**0.016 s** and was a missing env var. This one loaded a model and ran. *The wall clock is the
evidence a test ran* — and here it is what separates a real red from a fixture-shaped one.

The panic comes from `pkill -f "palw-worker --mode pow-agent"` exiting non-zero, which the
assertion renders as *"the first seed did not use one"* — a sentence about the **driver's
choice**. The actual cause is one level down and is not a choice:

```
/root/palw-drill/bin/palw-worker   built 2026-08-16   strings | grep -c pow-agent = 0
/root/palw-class/palw-worker       built 2026-08-14   strings | grep -c pow-agent = 0
```

**The binaries predate the mode.** `--mode pow-agent` is not an option they can refuse; it is a
string they do not contain. The driver spawned one, the worker printed its usage line and exited,
the driver fell back to one-shot — which the test's own comment calls correct — and it did so at
seed one, where the test needs the agent alive to kill it.

> **`pkill` exiting 1 means "matched nothing", which is not the same as "nothing was started".**
> A limit rendered as a verdict, once more, and this time the verdict names a *decision*
> ("did not use one") for what is really an *absence*. The message would have sent a reader to
> read the driver's fallback logic, which is correct code.

### The fleet fact underneath it, which is the part that outlives this test

Measured across all three hosts, every `palw-worker` on disk:

```
169.58.39.220    /root/palw-drill/bin/palw-worker   2026-08-16   pow-agent=0
                 /root/palw-class/palw-worker       2026-08-14   pow-agent=0
169.58.232.113   /root/palw-class/palw-worker       2026-08-26   pow-agent=0
5.104.81.23      /root/palw-class/palw-worker       2026-08-14   pow-agent=0
```

**Four binaries, three hosts, three build dates, zero of them have the resident-agent mode.**
Running processes: 3 on ibm — all children of the test run above — and **0** on the other two,
which are the hosts carrying kaspad.

So the claim I had been repeating, *"`palw-worker` runs on all three fleet hosts"*, is wrong twice
over: it is not running on two of the three, and none of the deployed binaries can do the thing
the phrase implies. **Nothing in the announcement or the runbook makes a claim about the resident
agent** — checked, no hits — so there is no public sentence to retract. This one lived only in
my own prose, which is where it would have leaked from.

### What §5's line should say instead

Not *"the three tests cannot run because the crate links a pinned llama.cpp."* That is a true
sentence attached to the wrong noun. The accurate version:

> These three tests need a **worker binary built from a tree that has `--mode pow-agent`**.
> Building one requires an external llama.cpp checkout at `LLAMA_COMMIT`, **built, not merely
> cloned**, which this repository does not contain and the fleet has never had. Every deployed
> worker predates the mode. `cargo build --release` skips the crate by default, so **the relaunch
> will not produce one either** — the fleet's behaviour here is the same before and after the cut.
>
> By the crate's own build script: *"No node needs it to produce or verify a block: since ADR-0053
> there is one execution family and it is BASE-0's, which is pure Rust in this tree."*
> **These tests exercise a path that is not on the block-production path.**

That last sentence is the one that decides how much the gap costs, and it is the one my original
phrasing never reached — because I stopped at a true fact about llama.cpp and never asked what
the subsystem was *for*.

### The second red carries a green inside it, and the verdict throws the green away

`concurrent_seeds_are_faster_and_are_the_same_tags`, same host, same stale worker:

```
permits: 3 (pool warmed in 156.099172681s)
3 seeds serially through the pool: 52.802461904s
3 seeds concurrently:              113.394920626s
speedup: 0.47x
FAILED   ... finished in 358.11s   (WALL 375.15 s)
  concurrent seeds were not faster than serial ones — the permits are not being used
```

**The assertion that failed is the last one in the test.** Everything above it ran and passed:

```
assert_eq!(inference_concurrency(), PERMITS)          the permit gate took the count
expected[i] = one_shot_tag(worker, seed_i)            three fresh-process baselines
assert_ne!(expected[0], expected[1])                  anti-vacuity: the seeds differ
assert_eq!(tags[i], expected[i])   x3                 <- THE CONSENSUS PROPERTY, GREEN
```

So this run established, on real hardware with the real pinned model:

> **Three concurrently-computed Layer-1 PoW tags each equal the tag an independent fresh
> process computes for the same seed**, with the test's own anti-vacuity guard confirming the
> three seeds are genuinely distinct.

That is the property consensus depends on. **It is green, it was measured here for the first
time, and `test result: FAILED` is what the log records.** What actually failed is a *speed
direction* — and the speed direction is the one property a stale counterpart is guaranteed to
invert: with no `pow-agent` mode in the binary, "concurrent" means three simultaneous 1.2 GB
model loads on a 23 GiB box, so 0.47x is the arithmetic of the missing feature, not a defect.
The message *"the permits are not being used"* is literally true and names a mechanism where
the cause is again an absent binary feature — **the same mis-attribution as the first test's
message, in a second test, written by the same hand.**

> **A verdict is a reduction, and a reduction over `assert` is `AND`.** One failed clause turns
> a run with four established facts into the word FAILED. **This is the exact inverse of the
> `--report` defect from an hour ago**: there, the file carried the data and omitted whether the
> run was valid; here, the run carries the validity and discards the data. Both are the same
> break — *the join between a measurement and its standing is lost* — and they fail in opposite
> directions, so no single habit catches both. **Read the assertions that passed before the one
> that failed.** They are not consolation; on this run they are the only new evidence.

The order matters and is not luck: the author put the cheap correctness assertions first and the
host-dependent timing assertion last, with a comment saying the magnitude is *"a property of the
host's cores, not of this code"*. **The test was built so that a failure of the weak claim comes
after the strong ones have been established** — that is a design worth copying, and the log
format is what hides it.

### The third one PASSED, and its pass is the finding — the anti-vacuity guard is weaker than its own comment

```
the_resident_agent_and_a_fresh_process_compute_the_same_tag ... ok
one-shot, 3 fresh processes:                        45.749246189s
resident agent, 1 process including the model load: 44.593963373s
test result: ok. 1 passed   finished in 90.34s
```

**Green. And the worker binary contains the string `pow-agent` zero times.** There was no
resident agent. The driver fell back to one-shot, so the test compared three one-shot tags
against three one-shot tags and found them equal — which they are, trivially.

The author **knew this failure mode and wrote it into the file**, immediately above the guard:

```rust
// And the agent was genuinely used. Every failure inside it falls back to the one-shot path,
// which is the right behaviour and would also make this test pass while proving nothing — so
// the cost is the evidence: a silent fallback runs the same three processes and lands within
// noise of the baseline, NOT SEVERAL TIMES UNDER IT.
assert!(agent_elapsed < one_shot_elapsed, "... it most likely fell back, making the equality above vacuous");
```

The prose names the right discriminator — *several times under*. The code encodes `<`.

```
one-shot   45.75 s      agent path 44.59 s
margin     1.16 s = 2.5%          ratio 1.026x
guard as WRITTEN    agent < one_shot          -> PASSED
guard as COMMENTED  several times under       -> would need ~15.2 s
```

**A silent fallback makes the two numbers two samples of the same distribution, so `agent <
one_shot` is a coin flip. The guard catches the vacuity it was written to catch about half the
time, and this run is the other half.** The prose is not decoration here — it is the correct
specification, sitting one line above an implementation that does not meet it.

> This is [[boundary-tests-pin-the-off-by-one]] in its purest form yet: **the comment states the
> property and the assertion pins something weaker, so the test's own author left the evidence
> that the test is wrong inside the test.** And it is *the same defect as a doc comment cited as
> if it were code* — prose that is right next to code that is not, where the prose is what gets
> read and the code is what runs.

**Fix, post-cut, one line:** `assert!(agent_elapsed * 2 < one_shot_elapsed, …)` — the comment
already justifies the constant, and a genuine resident agent pays one model load instead of
three, so 2x is conservative against the 3x the design implies.

### The three, together — and the shape they make

```
palw_agent_recovery       FAILED  41.4s   honest red: fixture; no information about the property
palw_agent_concurrency    FAILED 358.1s   red on SPEED; contains a real green (3 concurrent
                                          tags == 3 fresh-process tags, non-vacuity guarded)
palw_agent_equivalence    ok      90.3s   VACUOUS: compared one-shot to one-shot; its own
                                          guard would have said so with a ratio instead of `<`
```

**The one that passed is the one that proved nothing, and the two that failed are where the
evidence is.** Nothing about the colour column is a guide to what the run established.

*What this run actually establishes*, and all it establishes: **three concurrently-computed
Layer-1 PoW tags each equal an independent fresh process's tag for the same seed** — from the
concurrency test's pre-speed assertions, on real hardware, with the real 1.2 GB pinned model and
an anti-vacuity guard that did hold. That is worth having. It is not "the three agent tests
pass", and §5 keeps its stated gap.

*Caveats, as promised before the run:* the ibm checkout is `8923b354` detached, **not the tree
being cut**, and every worker involved is three weeks stale. Neither of those weakens the tag
equality — it is an equality between two paths measured in the same run — and both of them are
why nothing here is offered as a green for the cut.

### Third time in one hour: a true sentence whose implication I did not check

Twenty minutes ago I wrote that building a worker with `--mode pow-agent` *"requires an external
llama.cpp checkout at `LLAMA_COMMIT`, **built, not merely cloned**, which this repository does
not contain and the fleet has never had."* Every clause of that is true. Then I stopped.

**This machine has one, built:**

```
/Users/wata/Downloads/misaka-palw-runtime/llama.cpp-cpu/build/CMakeCache.txt      Aug 11
/Users/wata/Downloads/misaka-palw-runtime/llama.cpp-cpu/build/src/libllama.a
                                          .../build/ggml/src/libggml.a
                                          .../build/ggml/src/libggml-base.a
                                          .../build/ggml/src/libggml-cpu.a
```

CMakeCache plus all four static libraries — **exactly the shape `build.rs` demands**, and the
`-cpu` suffix matches the `MISAKA_PALW_CPU=1` profile the same file describes. The sentence I
wrote scoped its claim to *the repository* and *the fleet*, and the reader's conclusion — and
mine — was **"therefore nobody can build it"**. Nobody said that. Nobody checked the third place.

> **Three times this hour, in three unrelated subsystems: the fact was right and the *therefore*
> was never tested.** `llama.cpp is absent from the repo` → *therefore the tests cannot run*
> (they need a binary, not a build). `palw-worker exists on all three hosts` → *therefore it
> runs there* (`pgrep -x` says 0). `the repo and the fleet lack a built llama.cpp` → *therefore
> it cannot be built* (the build machine has one). **A citation checker catches none of these,
> because in all three the citation is correct. What needs checking is the arrow.**

Recorded, not acted on: closing that gap means building `misaka-palw-worker` against this
checkout and re-running the three tests here. It is off the block-production path by the crate's
own statement, so **it is not a precondition for the cut** — but §5 must now say *"unbuilt here,
buildable on the release machine"* rather than anything that sounds like *"unbuildable"*.

## The free-prompt gateway, driven end to end — and the finding I nearly filed against this card

The goal names *自由プロンプト* beside MIDI and 3D, and the operator-facing path had never been
run. It runs. On **5f**, with the real A16 artifact and tokenizer:

```
[1] health ok — template misaka-palw/fp-gateway-template/chat-segments/v1, n_ctx 16,
    chain anchor file …/anchor.json
    registered / fp_certified / bond_active / exposure_room  -> all four present, all "unknown"
    can_submit -> false
```

**ADR-0077 Decision 3 holds against a live gateway**: all four chain names present in `/health`,
every one `unknown` in the offline form, and a gateway with no `--rpc` says it cannot submit.
Then the worker refused the job on width:

```
the worker refused the job: prompt 36 + decode ceiling 24 exceeds max_context_tokens 16
```

Which is §2's own argument arriving from the operator's end: **the certification path, the manifest
handshake, the class check and the width check all work, and width is the only thing left.**

The QWEN36 lane runs too, and refuses on its own class boundary first — correctly:

```
qwen35-2b.palwq36 is not a Qwen3.6-35B-A3B/graph-v3 artifact: the layer stack is not this
class's (24 layers)                                    <- the class check doing its job
class_id mismatch — ours 2e91c9d3…, request c1c1c1c1…  <- the identity check doing its job
prompt 36 + decode ceiling 24 exceeds max_context_tokens 8
```

### What I nearly reported, and what stopped it

The running 5f worker announces `71bbb755…` at n_ctx 16, from a hardcoded const:

```
palw-testnet-5f:  const MODEL_ID: &str = "Qwen/Qwen2.5-1.5B/graph-v2";
```

This card says, at the dense-lane section: *"the class the WORKER embodies is not held —
`palw-a16-fp-worker`'s `MODEL_ID` is the v5 512 row."* Measured against 5f, that reads false, and
I was one command from filing it as a defect **in this card**. Checking the other tree first:

```
palw-adr0082-impl:  const MODEL_ID: &str = misaka_palw_base0::classes::A16_GRAPH_V5_MODEL_ID;
```

**The card is right, about impl. I ran 5f.** The statement is accurate for the integration branch
and unlabelled as to tree — the same defect `check-doc-citations.sh` exists for, in the one form
that tool cannot catch, because there is no `file.rs:NNNN` in it to resolve.

> **The habit that saved it was checking both trees before asserting, not checking harder.**
> Every wrong thing I have said today would have survived a more careful reading of the single
> source I was looking at. *Ask the same thing two ways* is not a thoroughness setting.

So the true state, with the tree named for every clause: **on 5f** the FP worker serves graph-v2
at 16; **on impl** it points at the v5 512 row; **the merge is what moves it**; and §7's
*"THE 512 ROW HAS NO GENESIS BUILDER"* remains the binding item, unchanged by any of this.

### Two real defects on a shipped path, found by running the documented command verbatim

`misaka-palw-gateway` **is** in `default-members`, so this is a path the cut ships.

**1. The documented invocation cannot work as written.** `docs/palw-freeprompt-gateway.md`:

```bash
python3 scripts/drills/misaka-palw-fp-gateway-smoke.py ./target/release/misaka-palw-gateway \
    ./target/release/palw-a16-fp-worker "$MISAKA_PALW_GGUF"
```

Run verbatim it fails three times in a row, each on something the doc never mentions:

```
cannot spawn ./target/release/palw-a16-fp-worker: No such file or directory
        (relative paths — the gateway does not resolve them from the caller's cwd)
fatal: MISAKA_PALW_NETWORK_ID is not set        <- checked FIRST, before the artifact
fatal: MISAKA_PALW_ARTIFACT is not set          <- and then MISAKA_PALW_TOKENIZER
```

The usage line advertises **three arguments** and the worker needs **three more environment
variables**, none of which appears anywhere in that document — `grep` for either name returns
nothing. *An interface that documents a third of what it requires.* And the ordering is worth
keeping: `NETWORK_ID` is refused first, with the best error message in the subsystem, which is
why I stopped predicting which variable would fail and read what it said.

**2. The smoke's synthetic identity cannot pass a class-checking worker.** It writes
`"class_id": "c1" * 64`, which every worker that checks its own id refuses. It works today only
against a worker that does not check. Running it against one that does needs the real id
patched in, which is what I did.

Neither blocks the cut. Both are the operator's first five minutes.

### A named pre-announcement gate: the free prompt must produce an ANSWER, not a correct refusal

The run above demonstrated the handshake, the class check and the width check. **It never
demonstrated an inference.** The width wall on 5f is structural, not configuration:

```
palw-testnet-5f       const MODEL_ID = "Qwen/Qwen2.5-1.5B/graph-v2"      -> n_ctx  16
palw-adr0082-impl     const MODEL_ID = classes::A16_GRAPH_V5_MODEL_ID    -> n_ctx 512
palw-adr0082-into-5f  const MODEL_ID = classes::A16_GRAPH_V5_MODEL_ID    -> n_ctx 512
```

There is no environment override on the A16 worker; the one lever is the *qwen36* worker's
`MISAKA_PALW_MODEL_ID`, and every qwen36 canonical row shares `QWEN36_RC_CANONICAL = (7, 2)`, so
all of them land at 8. **No configuration of 5f admits a 60-position job.** The merge is what
moves it, and after the merge the 5f worktree is already built, so the rerun costs a rebuild and
a script rather than a fourth cold worktree — `/private/tmp` is at 87% with 55 GiB free, and a
cold target is 7–62 GiB.

> **GATE — after the merge, before the announcement.** Rerun the FP gateway smoke on merged 5f
> with the 1.79 GB `.palwart` and the qwen2.5-1.5b tokenizer.
>
> **Green: the announcement may say a free prompt produced an answer.**
> **Red or unrun: it says the width check works.** Only one of those is earned by what is
> measured today, and it is the second.

Two predicted stoppers, written before the run so a red is reported rather than explained:

1. **The artifact must match the v5 row's declared shape.** 1c's
   `the_shipped_artifact_names_the_row_genesis_registers` passes in 9.90 s against the real
   1,795,427,276-byte file, so the header digest lands on `4277d84f…`. If the worker resolves its
   class the same way, that half is already evidence and need not be re-derived.
2. **`MISAKA_PALW_TOKENIZER`.** The v5 row pins an *inventory* root rather than a container
   digest, so a tokenizer binding must not move the class id. **If a tokenizer mismatch surfaces
   as a wrong class id rather than as its own named refusal, that is a finding about the
   inventory-root property — not a fixture problem** — and it gets reported as one.

### The rule this evening earned, applied to claims rather than to numbers

Every measurement in this card names its tree: `8923b354` detached, a three-week-old worker,
`d7957910` one behind. **The claims do not**, and that asymmetry is what nearly produced a false
finding against this card an hour ago — a number looks incomplete without provenance and a
sentence does not.

> **A statement about code names its tree in the same sentence, or it is defective for not
> naming it.** `check-doc-citations.sh` cannot enforce this: there is no `file.rs:NNNN` in
> *"the worker's MODEL_ID is the v5 512 row"*, so there is nothing for a citation checker to
> resolve. **A claim about which tree a fact holds in is not a citation, and we have no
> instrument for it** — only the habit.

### The structural wall, stated positively

The width limit is worth recording as a property rather than only as a blocker:

> **Nobody can configure their way past the served width.** The A16 row is a hardcoded const
> with no environment override, and the one lever that does exist — the qwen36 worker's
> `MISAKA_PALW_MODEL_ID` — lands every canonical row at 8, because they all share
> `QWEN36_RC_CANONICAL = (7, 2)`. **A limit that cannot be widened by environment is a
> different and better thing than a limit that merely happens not to be widened**, and an
> operator cannot produce a commitment wider than the court admits by setting a variable.

### Three times today the note existed and its author walked past it

Not three careless moments — one mechanism, and the most uncomfortable pattern of the evening
because every instance is self-observed within minutes of writing the rule:

```
"assert the report's verdict before reading any field"   -> KeyError 'verdict', one turn later
"pgrep -f matches the asker" (written 2026-08-30)        -> read `script: 2` as running; the
                                                            script had exited 20 min earlier
"check the arrow, not the fact" (1c, this hour)          -> "I have no GGUF, therefore I cannot
                                                            run the gateway smoke" — written
                                                            WHILE composing the rule; the A16
                                                            worker never reads MISAKA_PALW_GGUF
```

> **A rule is at its weakest immediately after you articulate it, not its strongest — because
> stating it feels like having applied it.** The satisfaction of having named the failure mode
> is the same feeling as having checked for it, and nothing distinguishes them from inside.

The practical form is not "try harder to remember". It is that **a rule earns its keep only
once it is attached to a mechanical trigger** — a script, a gate, a grep — because the moment
it is only in prose it competes with the feeling of already having used it. The three that did
fire today were all mechanical: `check-doc-citations.sh`, the anchor-count guard that refused
my `sed` when it found 1 occurrence instead of 2, and `strings | grep -c pow-agent`.

*The guard that stopped the bad `sed` is the smallest and the most instructive: it cost one
line, it fired within seconds, and what it caught was that my own pattern did not match my own
text.*

## The artifact the free-prompt lane needs, and two traps around it

On the merged tree the worker resolves the genesis class — `4277d84f7d91528c…`, n_ctx 512, from
the artifact header — so the width wall is gone and stopper (1) is closed. It then refuses at
boot for a new reason:

```
this artifact declares no tokenizer: `tokenizer_commitment` is all zeros, so every job this
class produces would publish `tokenizer_id` 0 and no replay could prove it read the ids this
class means. Re-convert it with a tokenizer bound … binding a tokenizer moves
`artifact_digest`, so this is a NEW ARTIFACT AND A GENESIS DECISION, not an upgrade
```

**The final clause is false for this row**, and the tree says so in two places:

```
misaka/palw/base0/src/classes.rs:1331
  assert_eq!(v5.artifact_root(&bound), v5_root,
    "a court-capable row registers the operand inventory, which the tokenizer is not in — so
     binding one is NOT a genesis input for this row and the registered root does not move")
ecc7cefb  "the inventory root is invariant under the graph and the binding (1a7457f1… for both)"
```

A court-capable row registers the **inventory root**, not the container digest. The remediation
text is right for a digest-rooted v1 row and **was never narrowed when court-capable rows
arrived**. Read literally it says the free-prompt answer path needs a genesis change, which
tonight means *not before launch*; read correctly it needs a conversion run and nothing else.

> **An error message that overstates the cost of its own fix**, on the one path that decides
> which sentence the launch document can carry. A limit rendered as a verdict — pointed at the
> operator rather than at us.

### Trap 1: the checkpoint on the build machine is the WRONG MODEL and looks right

```
Mac  models/qwen2.5-1.5b/model.safetensors   sha a961db72…  HF Qwen/Qwen2.5-1.5B  (BASE)   config 684 B
shipped qwen25-1.5b-a16.palwart              from Qwen2.5-1.5B-INSTRUCT dd924a11…          config 660 B
```

**Same file size (3,087,467,144 B) and the same `tokenizer.json` — commitment `fa9a4352…a649bb`
identical for both.** Size and tokenizer cannot tell them apart. A re-conversion from the Mac
checkpoint lands ~484,183,979 bytes different and produces a different class. **This was once
diagnosed as "the build cannot reproduce the shipped artifact"; the converter is deterministic
and innocent, and the input was the difference.** `qwen25-convert` on this machine is the one
command that must not be run.

### Trap 2: a file whose NAME asserts what its digest denies

Four files on ibm, measured:

```
qwen25-1.5b-a16.palwart          1795427276 B  sha a8c4e53e…  2026-08-27   <- shipped
qwen25-1.5b-a16.rebound.palwart  1795427276 B  sha a8c4e53e…  2026-09-03   <- BYTE-IDENTICAL
bound-candidate.palwart          1795427276 B  sha 3f8fc506…  2026-09-03 08:45
```

**`rebound` is a copy.** Its name says a rebind happened; its digest says one did not. It sits
beside the artifact it claims to derive from, and anyone reaching for the obviously-named file
gets the unbound artifact and the same all-zeros refusal — twice, because the second failure
looks like the first.

> **A name is a claim, and nothing verifies it.** Same shape as `#[ignore = "passes"]`, as a
> group of three tests named after the one file that holds one of them, and as a `--report`
> whose field set implies a verdict it does not carry. **This project's most durable defect is
> not a wrong value; it is a true-sounding name attached to something nobody re-derived.**

### What `bound-candidate` actually is — measured, and not what I assumed

```
cmp -l shipped bound-candidate
  differing bytes  128
  first offset     1,777,209,033      98.985% through the file
  last offset      1,795,427,276      = EOF
  span             18,218,244 bytes   = 17.4 MiB
```

**The 1.777 GB of weights are byte-identical**, so this is not a re-conversion from another
checkpoint — that would differ by ~484 million bytes. But the 128 differing bytes are **not
contiguous**: they are scattered across the final 17.4 MiB. A tokenizer commitment is 32 or 64
contiguous bytes. **A count and a location answer different questions and I had only asked for
the count.**

So the byte diff is *encouraging and insufficient*. The decisive measure is
`a16_root_probe::print_a16_v5_root_forms` over the two real files — `artifact_digest` must move
and `inventory_root(v5)` must not. **A small diff says how different; only the inventory root
says whether the class moves**, which is the property that decides whether this artifact can be
registered against the genesis being cut. Running on ibm (`8923b354`, not the cut tree).

*The probe is the third instrument the 62-ignored set has supplied tonight* — after the IBD
participation trio and the drill goldens. **The enumeration has now paid for itself more times
than it cost**, which is worth saying given it began as a risk about what a skip hides.

### `test result: ok`, `RC=0`, and zero tests ran — mine, tonight

```
running 0 tests
test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 2 filtered out; finished in 0.00s
RC=0
```

ibm's checkout is `8923b354` and its copy of the probe holds `print_a16_root_forms`.
`print_a16_v5_root_forms` exists only on `palw-adr0082-impl`. **My name filter matched nothing,
so cargo filtered out both tests and reported success.** Four minutes of compile, then nothing,
then the word *ok*.

The only tells were `2 filtered out` and **`0.00s`** — a probe that maps two 1.79 GB artifacts
and hashes their inventories cannot finish in zero. *The wall clock is the evidence a test ran*,
for the third time today, and this time against a run I designed.

> I verified the env var names against the test source. **I did not verify that the test name
> existed in the tree I was running it on** — I checked the arguments and not the target. That
> is the arrow rule pointed at a command line: *"the probe exists, therefore this invocation
> runs it"* is an inference, and the tree it runs on is the thing that has to be true for it.

### The checker I wrote to catch silent absence had two silent absences

`scripts/ci/check-doc-tree-claims.sh` reports which identifiers a document mentions whose
**definition differs between two trees** — the class `check-doc-citations.sh` cannot see, because
a claim with no `file.rs:NNNN` has nothing to resolve. It took three runs to work, and every
failure printed a clean plausible number:

```
run 1   mapfile: command not found          macOS /bin/bash is 3.2 — a script that runs on
                                            the fleet and dies on the release machine
run 2   "1 identifier, not found"           the array became a string and `"${idents[@]}"`
                                            expanded to ONE element, over a document with 299.
                                            A loop over the wrong collection reports a small
                                            clean number, NOT a failure
run 3   "0 found in either tree"  (x39)     `\b` in `git grep -E` is POSIX ERE: it matches
                                            NOTHING and reports zero. And removing it makes
                                            `MODEL_ID` match `MODEL_IDENTITY_KEY` — the naive
                                            repair trades a false zero for a false hit
```

**A tool written to catch absence-you-cannot-see, silently reporting an absence it could not
see, twice.** Only running it against a known-present identifier found either.

Working, it earns its place on its first real run — **six identifiers this card names whose
definition differs between the trees it is written across**:

```
PALW_STATE_V2_VERSION           5f  = 18                     impl = 20
genesis_anchored_v1             5f  (profile)                impl (profile, ladder)   <- gained an argument
PALW_LADDER_FAMILIES_V1         5f  <absent>                 impl  [PalwLadderFamilyV1; 2]
print_a16_v5_root_forms         5f  <absent>                 impl  present            <- tonight's probe
MODEL_ID                        same LINE, different FILES   (a16 worker vs qwen36 worker)
```

`genesis_anchored_v1` is the sharpest: **it takes a `ladder` argument on impl and does not on
5f.** Every sentence in this card about that wrapper's cost model is a sentence about one of two
different functions, and until now none of them said which.

*The `MODEL_ID` row is the tool being honest about its own resolution*: the definition line is
byte-identical on both trees because two different files each define a `MODEL_ID`, and a
leaf-name match cannot tell them apart. It is reported as differing-or-not by line, which is the
right conservative answer and not the whole one.

## §1's `palw_context_ladder` row: the conclusion may stand, the REASON no longer does

§1 says `palw_context_ladder` → **`None`, DO NOT ARM**, and gives as its reason:

> *"There is no `palw_context_ladder_active_at`: nothing reads the fence. Every use of that name
> is the module, the field, the `never()→None` normalisation, or `params.rs:3243` writing it into
> the FINGERPRINT. So arming it moves the fingerprint and gates nothing."*

**On `palw-testnet-5f` that is exactly true** — measured, not recalled: outside `config/params.rs`
the only reads are the guard assertions in `palw_context_ladder.rs`. **On `palw-adr0082-impl` it
stopped being true tonight**, in 5b's preflight fix `e5651de0`:

```rust
// consensus/core/src/palw_class_admission_v2.rs   (ADDED in e5651de0)
let ladder = params
    .palw_context_ladder … .then(|| palw_class_ladder_rules_for_court_v1(profile, court, bundle.court.max_step_leaf_count()))
```

**That accessor is the fence's first real read.** The row's conclusion is probably still right —
§1 records FG proving the 512 row admits and prices at 2^26 *with the fence dormant* — but
**a decision whose premise stopped applying is not automatically wrong; it is merely no longer
supported by what it says.** The row keeps its verdict and loses its argument until re-derived.

### And the presets now diverge, deliberately, with a test that says so

```
DEVNET_PARAMS             palw_context_ladder: Some(ForkActivation::always())
palw_rc_shipped_params    None                                                <- t11, the cut
mainnet / testnet / simnet   None
```

`only_devnet_arms_the_context_ladder` asserts exactly this, and the arming site's comment cites
**this card's §1** for the two-moves rule. It is considered, not accidental. On 5f the same test
asserted `devnet_shipped_params().palw_context_ladder.is_none()`; that assertion is gone on impl
and replaced by an equality against the armed value. *The guard did not silently break — it was
rewritten to state the new truth, which is the right way for a guard to change.*

> **The open question, and it is the one the announcement leans on:** 5b's devnet drill validates
> the graph-v5@512 registration under `ladder: Some(…)`. **t11 registers it under `ladder: None`.**
> Same call, different admission shape. This is the defect 5b just fixed, one level up — *the
> pre-check asked a court the chain does not run; the drill asks a network the chain is not.*
>
> Asked, not assumed: **is that registration exercised anywhere under `palw_rc_shipped_params()`?**
> Either answer is fine tonight — a covered case to cite, or a gap to state — but it must not be
> *inferred* from a green on the other preset.

*Recorded because it is the third time today that the thing being validated and the thing being
shipped were configured differently, and the first two were only found by looking.*

## ANSWERED: binding a tokenizer does not move the registered root

Run on ibm against the two real 1.79 GB artifacts, `88.55 s`, `1 passed`, **`0 filtered out`**:

```
[shipped] artifact_digest       c00faa480f2344d4a737e5b2e87ab606…
[bound]   artifact_digest       158314b58843430efebe343d61d1078c…    <- DIFFERS
[shipped] inventory_root(v5)    1a7457f100d9fb0f3406d882b4b5bcd7…
[bound]   inventory_root(v5)    1a7457f100d9fb0f3406d882b4b5bcd7…    <- IDENTICAL
shipped inventory(v5) == bound inventory(v5)   true
v5 == the v2 genesis pin                       true  (both files)
v5 profile class id  4277d84f7d91528c…    v2 profile class id  71bbb75513cf3d47…
```

**`bound-candidate.palwart` is registrable against the genesis being cut.** The worker's refusal
text — *"binding a tokenizer moves `artifact_digest`, so this is a new artifact and a genesis
decision, not an upgrade"* — is **false for this row**, confirmed on the two real artifacts
rather than on a synthetic `with_tokenizer_commitment`.

**Stated precisely, because two equalities print adjacent and only one is being claimed:**
`v5==v2 inventory` is `true` for both files, so the inventory root does not distinguish the
graphs. The claim is *"binding a tokenizer does not move the **v5** inventory root"* — the same
profile across two files. **It says nothing about v5 versus v2.**

`c00faa48…` now agrees three ways: the trailing 64 bytes read directly out of the file, the
digest the worker printed in its refusal, and this probe recomputing it. Three routes, three
machines, one value.

### The run before this one said `ok` in 0.00 s

Both invocations are in this card and the pair is the lesson:

```
0.00s   ok. 0 passed; 0 failed; 2 filtered out    RC=0   <- nothing ran
88.55s  ok. 1 passed; 0 failed; 0 filtered out    RC=0   <- read 3.6 GB
```

**Same word, same exit code.** `0 filtered out` and the wall clock are the entire difference.
*A targeted test invocation must state how many tests it expected to run*, because
`0 passed, 0 failed` is the one result meaning the **command** was wrong rather than the code —
and `cargo test` spells it with the word `ok`. (`cargo nextest` refuses it by default.)

### Getting the probe to a machine that had the artifacts

ibm's `origin` is GitHub and `palw-adr0082-impl` has never been pushed, so ibm could not fetch
the tree. Instead: **check that all five of the probe's dependencies exist on `8923b354`**
(`palw_a16_context_row_profile_v5`, `qwen25_a16_profile_v2`, `decode_artifact_file_v1`,
`a16_inventory_v1`, `PALW_RC_GENESIS_QWEN25_A16_ARTIFACT_ROOT`) — they do — copy the file, watch
it fail to compile because **three other tests in it** want impl-only symbols, trim to the 55
lines that are the probe, run that. **12 KB of network against the 1.79 GB that copying the
artifact would have cost.** The copied file was removed afterwards; ibm's checkout is clean.

## LAUNCH-STOPPER, found by asking: t11 would have admitted the fused row at genesis and refused it from everyone after

The question in the previous section — *"is that registration exercised under
`palw_rc_shipped_params()`?"* — was answered by writing the test, and it is **RED**:

```
under palw_rc_shipped_params()   (court ARMED, palw_context_ladder DORMANT)
verify_class_admission_v6 refuses the graph-v5 row:
    PricedForADifferentCourt — "the class is priced for a dissection of None
                                and this ruleset's court plays 2"
```

**Mechanism.** v6 derives the priced cost shape as
`ladder.map_or_else(genesis_anchored, |r| r.cost_shape)`, and the processor's registration arm
passes `ladder: None` whenever the **context-ladder** fence is dormant. So on t11 a fused
profile gets the genesis-anchored shape (dissection `None`) and the court check refuses it.

**The genesis route never goes through v6.** `qwen25_a16_graph_v5_registration_v1` calls
`palw_class_ladder_rules_for_court_v1(profile, Some(court), ladder)` unconditionally and prices
the row *for the court*.

> **So the chain we were about to cut would register the fused class at genesis and refuse the
> same class from every later applicant.** ADR-0054's permissionless admission, the demonstration
> class, the whole *"anyone can bring a model"* sentence — refused by the gate on the shipped
> preset, while devnet says yes. **The genesis set would have worked perfectly and the chain
> would have been closed to newcomers**, which is the failure that looks healthiest from inside.

Devnet admits (ladder armed), t11 refuses. *The drill asks a network the chain is not* — and the
three near-misses 5b enumerated were all one step away from the shipped case:

```
the genesis route          prices from the bundle regardless of any fence — bypasses the gate
armed_rulesets test        passes Some(rules) for BOTH devnet and rc — never asks with None
the new SDK test           runs on devnet
```

### Why this rule change can ship tonight, and only tonight

The fix is a **consensus rule change on the acceptance path**. It is safe *because we are
re-genesising*: the behaviour it modifies is currently **"always refuse"**, so no chain holds a
post-genesis fused registration the new rule would re-judge, and every node starts from the new
genesis running the new rule. **The same change on a live chain would need a fence.**

That reasoning depends on the wipe being complete. **A missed host is now not merely a stale peer
but a node judging registrations by a different rule** — which raises the price of the wipe
defects §4b already lists, and is one more reason `verify` must be clean before `wipe` runs.

### The test to write is route-agreement, not fence-invariance

The proposed test is *"the gate prices a fused row identically with the ladder fence armed or
dormant."* **That pins fence-invariance, and fence-invariance was not the defect.** Two *routes*
priced the same row differently and nothing compared them; a fence-invariance test passes if both
routes are wrong in the same way, and it would have passed on `e5651de0` had v6 simply ignored
the fence and stayed genesis-anchored.

```
the property that broke:
    price( GENESIS assembly, row, bundle, court )  ==  price( v6, row, bundle, court )
fence-invariance is a COROLLARY of that, not a substitute for it
```

> **Third instance tonight of one object spelled twice with no equality between the spellings:**
> the preflight asked a court the chain does not run; the drill asked a network the chain is not;
> the genesis assembly and the acceptance gate price the same row by two different functions.
> **This project's most-repeated defect, and each time the two spellings were individually
> correct.**

### Confirmed twice, from two layers, by two people who did not share code

```
1c   consensus-core, verify_class_admission_v6 direct   PricedForADifferentCourt { priced: None, court: 2 }
5b   the SDK preflight, as the panel calls it           "priced for a dissection of None … court plays 2"
```

**Two entry points, no shared code between the calls, the same refusal.** The two-ways rule
delivered its answer on the load-bearing claim and the answer was red. *The thing I most wanted
to be a false alarm is now the hardest to dismiss.*

**Scope, narrowed to what is actually true** — my first phrasing above ("closed to newcomers")
is too broad and is corrected here rather than edited away:

```
genesis registration of the fused row      FINE — the genesis route prices from the bundle,
                                                  bypassing the gate entirely
post-genesis registration, NON-fused       FINE — keeps the genesis-anchored shape, unaffected
post-genesis registration, FUSED, on t11   REFUSED
```

So the floor and the non-fused rows still admit. **What is shut is precisely the family the
network is being minted around**, which is narrower than what I wrote and quite bad enough.

**And §1's ladder row takes its final form** — not *arm it*, not *leave it and all is well*:

> **Leave it dormant — and know that post-genesis fused registration does not preflight under
> t11's own shape.** Arming remains wrong (it moves t11 to the shape nothing has validated for
> t11's registered set). What changed is that t11's shape now has a **measured consequence**
> rather than being merely the untested alternative's opposite.

*How 1c avoided a false alarm at the worst hour is worth copying:* they did not re-verify that
the row is fused or that the preset was right. They verified **that their invocation asks what
the panel asks** — `palw_panel.rs` → `palw_admission_shape_at_v1` → `preflight_admission_with_chain`'s
own doc saying it probes v6 with *exactly those* inputs. **Checking the arrow, on their own
result, against themselves** — which is the failure mode that has bitten three times tonight.

## §4b, fourth defect: the wipe census invented one appdir and lost a running node

Found by re-running the census after the launch-stopper made a surviving host expensive — a
missed node is no longer a stale peer, it is **a node judging registrations by a different rule.**

**Three forms of the same enumeration, wrong in both directions:**

```
pgrep -af kaspad | grep -oE "appdir=[^ ]+"
    -> printed `appdir=[^` on ALL THREE HOSTS, for as long as this script has existed.
       The remote shell's own argv holds both "kaspad" and the literal regex, so the grep
       extracted its own pattern out of itself. THIRD instance tonight of `pgrep -f`
       answering the asker — and this one is in the wipe script.

pgrep -x kaspad
    -> the repair. It dropped `kaspad.candidate` on ibm — a RUNNING NODE on /tmp/fpchk.
       **A false positive repaired into a false negative**, which is the direction that
       loses a host on wipe night.

walk /proc, match the EXECUTABLE's basename by prefix
    -> correct. The asker's exe is `bash`, so it cannot appear; any `kaspad*` build does,
       whatever it is called.
```

**The corrected census — seven running nodes, not five and not six:**

```
169.58.39.220    kaspad                       --appdir=/root/.t11
                 kaspad                       --appdir=/root/.t11b
                 kaspad.candidate (deleted)   --appdir=/tmp/fpchk      <- invisible to both
                                                                          earlier forms
169.58.232.113   kaspad                       --appdir=/root/.t11
                 kaspad                       --appdir=/root/.t11c
                 kaspad                       --appdir=/var/lib/misaka-minerpool/slots/slot-01/appdir
5.104.81.23      kaspad                       --appdir=/root/.t11
```

**`(deleted)`** is the third thing the new form reports and neither old one could: that binary
has been **unlinked from disk while the process runs.** Nothing can be read off it, and it will
not come back after a kill — which is convenient here and would be alarming anywhere else.

> **A repair aimed at a false positive should be checked for the false negative it creates.**
> `[^` in a wipe list is noise; a missing node is the whole failure. The check that caught it was
> noticing that `/tmp/fpchk` **disappeared between two runs** and asking why, rather than reading
> the tidier output as the better one. *The output got cleaner and less true, and clean is what
> a repair is supposed to look like.*

### The ceremony's own guard grepped the tree for the answer

`scripts/ci/check-repin-predictions.sh`, first version, reported **all four values as DIFF** against
`3f9526d3`. It read `<empty>` for every one, because none of the five predicted values appears
anywhere in the tree's `.rs` files — and **they should not**:

> **These values are what the re-pin WRITES. The tree legitimately holds the OLD pins until the
> paste.** A guard that greps the source for the answer is asking the tree to already contain the
> thing the ceremony exists to put there.

It stopped, which was right, **and its reason was wrong** — it said *different* where the truth
was *absent*. Safe exactly once, misleading every other time, and it would have said the same
four DIFFs if the predictions had been perfect.

Rewritten: `derive/src` is verified from the tree (it is a property of the tree, so that half was
always sound and reads **OK** on `3f9526d3`), and the five values are compared against an
**extraction table** — `<name> <value>` lines produced by the thing that computes them. With no
table it prints what it cannot answer and exits, rather than manufacturing a verdict:

```
TABLE=/path/to/extracted-pins.txt scripts/ci/check-repin-predictions.sh palw-adr0082-impl

  source_tree_sha256  637858dba5ea5e34…
  t11_fingerprint     71efa66480211731…
  devnet_fingerprint  c0da0c9024d68b94…
  fp_golden           c940b5c36ee40846…
  premine_builds      ba2612417e7e0817
```

And it now distinguishes the two failures by name: **`<absent>` means the check did not run;
a differing hex means it ran and disagreed.** Conflating those is what the first version did.

*Four hours after writing "a rule earns its keep once it is attached to a mechanical trigger",
the trigger I attached was broken in the way the prose version would not have been — a human
following the checklist would have run the extractor first, because a human knows the pins are
not there yet.* **Mechanising a rule can lose the context that made the rule obvious.**

### Correcting my own safety argument: the timing is the other way round

I wrote that the v6 change *"is safe because we re-genesis, and the same change on a live chain
would need a fence"*, and that a missed host therefore *"judges registrations by a different
rule"*. **The conclusion is right and the timing is inverted.**

**The defect predates tonight.** `processor.rs:6161` — the acceptance path — computes the ladder
from the fence exactly as the preflight does:

```rust
let ladder = self.palw_context_ladder_at(point.daa_score).then(|| {
    palw_class_ladder_rules_for_court_v1(&carriage.profile, court, bundle.court.max_step_leaf_count())
});
verify_class_admission_v6(bundle, &carriage.profile, &carriage.canonical, object, …, ladder.flatten(), court, false)
```

and **`e5651de0` did not touch the processor** — its five files are `palw_class_admission_v2.rs`,
`palw_panel.rs` and three SDK files. So the chain has refused post-genesis fused registrations on
a ladder-dormant preset **for as long as the processor has had that arm.**

> What `e5651de0` changed is that the preflight now **agrees** with the chain. Before it, the
> preflight refused for a *different* reason (no court) — **and the disagreement hid the rule.**
> Two wrong answers that differ look like one bug in the newer component.

**So the wipe's status is:**

```
TODAY, before the fix      every node runs the same processor and refuses identically.
                           No divergence. A surviving host is an ordinary stale peer.
AFTER the fix ships        the acceptance rule differs between fixed and unfixed nodes.
                           A missed host judges the same object differently.
```

**The wipe becomes load-bearing for consensus when the fix ships, not now.** My sentence was
right about the danger and wrong about when it starts — which matters, because it is the
difference between "the wipe was already critical" and "the wipe becomes critical at a moment we
control and can therefore sequence."

### And the corollary that must gate any candidate fix

**A preflight-only repair turns both new tests green while the chain still refuses.** 1c's test
asks v6 directly and 5b's asks the SDK, and *both* would pass over a closed door if someone
patched `palw_admission_shape_at_v1` alone. **Checked, not assumed** — `97bdbf75` changes
`verify_class_admission_v6`'s own body:

```rust
-  let shape = ladder.map_or_else(|| genesis_anchored_v1(profile, bundle_ladder), |r| r.cost_shape);
+  let shape = match ladder {
+      Some(rules) => rules.cost_shape,
+      None if fused && court armed =>
+          palw_class_ladder_rules_for_court_v1(profile, court, bundle_ladder)
+              .map_or_else(|| genesis_anchored_v1(profile, bundle_ladder), |r| r.cost_shape),
+      None => genesis_anchored_v1(profile, bundle_ladder),
+  };
```

That is the function `processor.rs:6161` calls, so the acceptance path moves with it.
**Any later candidate fix gets the same check before it is believed.**

### 4,223,328 is not a stale figure — it is a quoted failure, read as a fact

The graph-v5@512 row's canonical count at the ruleset's `2^26` ladder is **6,630,544 leaves**.
An earlier assertion used **4,223,328** and the gate corrected it. That was reported to me as *"an
old SDK comment says 4,223,328 — that figure is stale."* **It is not stale.** Both places that
carry it label it as the wrong answer, and one of them prints the right one three lines above:

```
consensus/core/src/palw_class_admission_v2.rs:1891
    /// On the graph-v5 512 row the honest count is 6,630,544 and the helper answered
    /// `"the canonical job does not count against this profile: job shape yields 4223328 step
    /// leaves, exceeding the 4194304 cap"`, so the object could not be BUILT at all
```

The comment is **correct, complete, and adjacent to the truth**. The number was taken out of a
sentence whose subject is *that this number is wrong.*

> **This is the same near-miss as pasting the eight transformer ids out of a drill whose verdict
> was `FAILS`** — a value read from a context that says the value is wrong. **The context was not
> missing and it was not misleading. It was simply not part of what got copied**, and a hex string
> or a leaf count carries no trace of the sentence it came from.
>
> The defect is not a stale comment. **It is that quoting is lossy in exactly the direction that
> matters**: the number survives the copy and the word *"wrong"* does not.

*Recorded because "the comment is stale" and "the comment says this is the wrong answer" call for
opposite repairs.* The first would have someone edit or delete a correct comment — deleting the
only place the failure mode is written down, which is the precise repair that makes the next
occurrence unfindable. **Nothing here needs fixing except how the number was read.**

### The close figure, confirmed under the shape that ships — and a fourth value that never got in

5b's v6 fix verified from the third angle, green, and it printed the byte count as a side effect:

```
RC admission shape @ daa 0:  court arity 2, Flat ids, window 3000  |  ladder None (fence dormant)
t11 shape admission: class 4277d84f7d91528c admitted, close 81,312 B, 35,840 terminal MACs
test result: ok. 2 passed; 0 failed
```

**81,312 B is now measured from the genesis-registered carriage, priced under the shape the
acceptance path actually uses** — which is what §3 already said and had not yet been measured that
way. The figure has moved three times (81,599 → 82,719 → 81,312) and this is the first reading
taken under the configuration that ships.

**A fourth value existed and never reached either document.** 1c measured **83,175** and reported
it as the reproducible one, then found both of their measurements passed `ladder: Some(rules)` —
their `armed_rulesets` helper supplies it for *both* presets, and their genesis-object probe built
the rules itself and priced with them. **t11's actual shape is `ladder: None`.**

> They corrected my arity, corrected my ids form, and then priced under the wrong **ladder** —
> **the third field of the same three-field shape, and the one they had just built a test to
> expose.** Two fields read off the bundle, one supplied by the caller, and a number that looks
> derived. *That is the `kary_court` defect they named, committed by the person who named it.*

**And the announcement's decision survives its fourth number.** It carries **no byte count at
all** — one carrier and a real command instead. Checked mechanically just now: `83,175`, `83175`,
`81312` and `81,312` all appear **zero** times in
`docs/history/testnet11-relaunch-5f-announcement-draft.md`. *A figure that has moved four times under
three configurations is not a figure a launch document should carry, and the decision to drop it
was made before three of those movements were known.*

**What made this visible was the red test, not care.** It was written to check someone else's
rule, and the first thing it printed on going green was a correction to its author's own
arithmetic. **A test that asks the shipped question answers more than the question it was written
for.**

### The ceremony guard, exercised in all four directions before it is needed

A guard that has only been seen to refuse is indistinguishable from a guard that always
refuses. All four paths run, on real trees:

```
1  no `extracted_from` line          STOP  "five values from an unnamed run prove nothing"
2  all five values CORRECT, but      STOP  table says   4b0e15675c07ec1d…
   extracted from 4b0e1567 while           checking     3f9526d343892a48…  (palw-adr0082-impl)
   checking 3f9526d3                       "values from another run are not evidence about
                                            this one, however right they look"
3  correct table, correct tree       PASS  all five predictions hold
4  one value mutated                 STOP  DIFF t11 fingerprint, both values printed
```

**Case 2 is the one worth having built.** Every value in that table is correct — it is the same
five hex strings the ceremony expects — and the guard refuses anyway, because *correct values
from the wrong run are not evidence.* Before this the guard would have printed `all five
predictions hold` over exactly that table, which is how it was found: **run green against a
`4b0e1567` table while checking `3f9526d3`.**

5b wired the emitter to take `extracted_from` from **the finalize log's own closing `impl head:`
line, never from the current HEAD**, and to exit 2 without exactly one such line. *That is the
join belonging to the run rather than to the typist* — a table cannot claim a tree it was not
computed on, even by accident, and the failure mode where someone regenerates the header without
regenerating the values is closed by construction.

> **The discipline is "has it been seen to fail AND to pass", and case 2 says that is not enough
> either.** This guard passed on a table it should have refused, and every value in it was right.
> *Seeing it pass is only evidence if you also know what it would have refused.*

## The MIDI and the 3D, produced and read by something that could have disagreed

The goal names *midi / 3D / 実用的な出力*. I had been carrying that half on someone else's
report. Produced here, on `palw-testnet-5f`, and checked three ways:

```
palw-derive derive --transformer music/smf/v1 --answer corpus/music/03-overlapping-melody.json
                   scene/glb/v1               corpus/scene/02-hierarchy.json
                   cad/stl/v1                 corpus/cad/01-extrude-l-bracket.json
```

**1 — the files exist and carry content**, parsed by `scripts/verify/verify-artifacts-independently.py`,
which implements SMF, glTF-binary and binary-STL **from their published specifications** and
imports, links and shells out to nothing in this tree:

```
OK   .mid   157 B   SMF format 1, 2 tracks, division 192, 9 note-on, 1728 ticks
OK   .glb  2736 B   glTF 2.0, 2 chunks, 3 nodes, 2 meshes, 2 primitives
OK   .stl  1084 B   binary STL, 20 triangles, no degenerate facets
```

It walks every MIDI event and checks each track's declared length against where its events
actually end, checks every glTF accessor fits its bufferView and every bufferView its buffer, and
checks the STL triangle count implies exactly the file's length with no two vertices equal.
**These are the checks that fail on a plausible-looking blob**, which is the only kind worth
running.

**2 — the bytes are the ones the chain pins.** Each artifact hash equals its `golden.json` entry:

```
MATCH  music/03-overlapping-melody   6e27611c2ee15af0…   157 B
MATCH  scene/02-hierarchy            6da65dbc8f6a29fa…  2736 B
MATCH  cad/01-extrude-l-bracket      8b6c0d4389cb20cb…  1084 B
```

> **So the bytes the chain commits to are files an independent reader accepts** — which is a
> different claim from the drill's, and the one an operator cares about. `drill --check` compares
> one run's hashes against another's: it proves two runs agree, **not that the output is a file
> anything else can open.** Two runs of a broken writer agree perfectly.

**3 — the ids here are 5f's, and my re-pin predictions are impl's.** Stated because the two sets
look interchangeable and are not:

```
palw-testnet-5f     derive/src = 6b8d13ad46ebb22c…   music/smf id 4f4edd02c53ae28e
palw-adr0082-impl   derive/src = 4969f8dc051cac31…   music/smf id cb5f27b4… (predicted)
```

**The trees differ, so the ids differ**, and `transformer_id` is a function of `derive/src`'s
bytes. *A transformer id read from the wrong tree is exactly the paste this ceremony exists to
prevent* — and it would have been eight plausible hex strings.

## A valid drill on 5f — and three things it settles

```
palw-derive drill --corpus misaka/palw/derive/corpus --report drill-5f.json
{"arch":"aarch64","golden_checked":43,"golden_mismatched":[],"golden_unpinned":[],
 "bounds_enforced":8,"bounds_not_enforced":[],"refused":10,"rows":33,
 "verdict":"the corpus reproduces its goldens on this architecture and every declared bound
            refused an over-bound answer"}                                          exit 0
```

Run with **both binaries built** (`cargo build -p misaka-palw-derive`, not `--bin`), so
`palw-evm-runner` is beside the deriver and the six EVM goldens are checked rather than refused —
the defect that once produced eight plausible ids from a `FAILS` run.

**1. The report file still has no `verdict`, confirmed on a run that PASSED.** Previously I had
only compared a valid report against a failed one; this is a third, independent confirmation from
a fresh green run:

```
file keys   arch bounds golden os refused rows schema source_tree_sha256 transformers
verdict in the file      False        <- stdout has it; the artefact does not
golden.mismatched == []  True         <- the discriminator
```

**2. The report schema itself differs between trees, which my own rule did not say.** I recorded
the key set as *"…transformers **uncovered**"* and asserted `uncovered == []` is empty in both a
valid and a failed report. **On 5f there is no `uncovered` key at all** — so `r.get("uncovered")
== []` is *False* here, on a perfectly good run. That measurement was taken on impl.

> **A rule about a report's fields is a claim about a tree**, and mine did not name one. The rule
> survives — `golden.mismatched == []` is the discriminator on both — but *the sentence I wrote
> around it was tree-specific and did not say so.* Third time tonight for the same omission, and
> this one is inside the correction I made to a previous omission.

**3. `source_tree_sha256` tracks the tree exactly as the prediction assumes.** 5f's drill reports
`98265872fb7a372c…`; my re-pin prediction is `637858dba5ea5e34…` for impl:

```
palw-testnet-5f     derive/src 6b8d13ad46ebb22c…   source_tree_sha256 98265872fb7a372c…
palw-adr0082-impl   derive/src 4969f8dc051cac31…   source_tree_sha256 637858dba5ea5e34…  (predicted)
```

**Two different trees produce two different values, and neither is a coincidence** — which is the
mechanism the whole prediction rests on, demonstrated rather than assumed. *The best evidence
that a pin tracks its input is watching it move when the input does.*

## The free prompt answered — on devnet, and the stage after it failed for a script reason

The devnet e2e on `e5651de0` reached **stages 1–5**: the class registered on chain, the family
certified, the gateway healthy, and **one chat answered.** Then 5b:

```
the gateway queued no commitment … this class is not seated on the free-prompt lane
(fp_certified false)
node logs: ClassLaneCertified binding 0b8a6c35… DROPPED on all three nodes —
           "no family certified on this chain for the free-prompt lane covers every kernel
            class 4277d84f…"
```

**The chain refused correctly.** Stage 3 of `scripts/drills/misaka-palw-fp-devnet-e2e.sh` ran
`palw-certify drill --family a16` — the **graph-v2** family `PALW-QWEN25-A16` — while the row
under test is **graph-v5@512**, whose kernels are `PALW-QWEN25-A16-V5`'s. The `bind` output says
so in as many words: *"covered by the PALW-QWEN25-A16-V5 RC family."*

> **A script naming a family by hand where the catalog row already names it** — one spelling
> against the row's — and the chain caught the difference by refusing a binding whose coverage
> did not reach the class. Fixed at `21a34935` by deriving the family from the model id *the way
> `bind` does*. **This project's most-repeated defect, now at seven instances**, and the only one
> so far where the chain itself was the thing that noticed.

### `drill exit 0` while the script had died at stage 5b

5b's launcher reported success for a run that failed. **The verdict was in the log and not in
the exit code** — the same shape as `test result: ok` over zero tests, and the same shape as a
`--report` that carries ids without carrying whether the run was valid.

```
tonight's exit-code-and-verdict disagreements, all three found by reading the log:
   cargo test  "ok" in 0.00s, 2 filtered out, RC=0      nothing ran
   palw-derive drill --report                            file has no verdict at all
   the devnet e2e launcher   "drill exit 0"              the script died at 5b
```

**Three different tools, three different mechanisms, one habit that catches all of them:** read
the log, and check the wall clock against what the work should have cost.

### What this does and does not say about the goal's free-prompt item

**It answered a chat.** That is the first time the free-prompt path has produced an answer end to
end in this cut's lineage, and it is worth stating plainly — **on devnet, on `e5651de0`, with the
ladder armed.** It is not the t11 shape, it is not the cut tree, and the stage that binds the
answer to the chain is the one that failed. **The announcement's sentence still has to come from
a run on the preset that ships.**

## A red that means an exposure CLOSED — and the pattern that produced it

```
the_shipped_rc_ruleset_can_reach_the_dormant_free_prompt_retirement ... FAILED

assert!(p.palw_uncertified_weightless.is_none(),
  "the repair is dormant on the shipped RC — if this ever fails, the exposure below is
   closed and the note can go");
```

**That assertion exists to fail.** §1 arms `palw_uncertified_weightless` at genesis
(`e0255012` states both genesis fences on the RC preset), so the field is now `Some` there — and
the test whose whole job is to notice that, noticed. Its sibling documents what was open:
`known_limitation_dormant_a_spent_free_prompt_retirement_strands_its_weight` — on the shipped RC
with `claim_retirement_daa = WINDOW_COURT = 3000`, the first free-prompt claim that spends a
quantum and then retires produced **a durable tip its own node refuses on the next restart**,
with `safe_weight 40` stranded.

**Both notes can now go**, and this card's §5 line about the D7 exposure with them. Traced to the
arming commit before acting, not inferred from the timing.

### The pattern, which is the instrument I said was missing

Hours ago I found three **favourable stalenesses** — the hybrid's exclusion, the 2^22 width
table, the known-open list — and wrote that the only defence is to sweep every *"cannot"* and
*"known open"* and ask what would have to change. **That is a habit, and habits did not fire for
anyone tonight.** Someone had already built the mechanical version:

```
a claim that breaks               -> a red test               (normal)
a constraint that lifts           -> NOTHING                  (the whole problem)
a constraint that lifts, pinned   -> a red test whose message says
                                     "the exposure is closed and the note can go"
```

> **Pin the limitation, not just the behaviour.** It costs one assertion. It converts the single
> staleness class that produces *no signal at all* into one that produces a red — and the failure
> message carries what the red **means** and what to do about it, so the person who hits it does
> not have to reconstruct why a passing thing started failing.

*This is the answer to "a decision whose premise stopped applying", which has cost this card four
rewrites tonight — §1's ladder row twice, the wipe's timing, and the drill-report rule. Each of
those was prose. None of them fired.*

### State of the reds, after 1c's corrections

```
misaka-palw-base0      exit 0 — 371 across all targets, ZERO failures
                       (artifact tests 14.60s / 11.16s / 9.95s — real 1.79 GB file, not skips)
kaspa-consensus-core   5 failures:  3 re-pins        <- the ceremony performs these
                                    1 bind-window     <- a fixture branch
                                    1 exposure closing <- this one
```

**No red is a defect.** Three the ceremony writes, one fixture, one limitation lifting.

## The announcement's central "verify it yourself" command does not run on 5f

Run verbatim, on `palw-testnet-5f`, from the public draft's §3:

```
$ palw-certify drill --family a16-v5 --lane attempt --out attempt.json
palw-certify: unknown family `a16-v5`          exit 2, no file written
```

```
palw-testnet-5f     drill (--family <base0|qwen36|a16>        | --model-id <catalog model id>)
palw-adr0082-impl   drill (--family <base0|qwen36|a16|a16-v5> | --model-id <catalog model id>)
```

**`a16-v5` exists only on impl.** The command is correct for the tree that ships and wrong for the
branch the document currently lives on — and the document is the one thing a reader executes
without checking anything first. *Same class as the fabricated test name removed from this draft
earlier: a command written from knowledge rather than from a run.*

> **GATE, added to the pre-announcement list: every command in the announcement is executed on
> the cut tree, and its output pasted into the card, before the draft is published.** Not read,
> not reasoned about — run. The draft holds roughly a dozen; there is no version of "obviously
> fine" that survives tonight's record.

**And the derived spelling is the better one anyway**, for the reason 5b's script defect just
demonstrated: `--family a16-v5` is a family named by hand, and the devnet e2e died at stage 5b
because a script named `--family a16` where the row's family is `PALW-QWEN25-A16-V5`. `drill`
accepts `--model-id <catalog model id>` on both trees. **One spelling — the row's — and the
operator never types a family name that can drift from the class.** To be changed after the
merge and *after the changed command has been run*, not before.

### And my first reading of that run was wrong, in the way I have a note about

```
palw-certify … | head -4 ; echo "exit=$?"     ->  exit=0    <- head's
palw-certify … > file 2>&1 ; echo $?          ->  2         <- the tool's
```

I was one sentence from reporting *"`palw-certify` exits 0 on an unknown family"* as a defect.
**It exits 2 and writes no file — it is correct.** The pipe swallowed the status and `$?` answered
for `head`.

> **Fourth measurement artefact tonight**, after `pgrep -f` matching the asker (twice) and
> `\b` in `git grep -E` matching nothing. Every one produced *a plausible number from a command
> that was not measuring what I thought.* And this one would have been a public accusation
> against a tool that was behaving properly.

## The paste is verified by a SECOND IMPLEMENTATION, before the paste

`scripts/verify/misaka-palw-derive-stranger.py` is a Python re-implementation that reads the pins out of
`misaka/palw/derive/tests/transformer_id_pin.rs` and **recomputes them from the crate's actual
bytes.** It takes `--crate-root`, so it can be pointed at any tree. Pointed at impl's:

```
git archive palw-adr0082-impl misaka-palw-derive | tar -x -C <tmp>     # derive/src = 4969f8dc…
python3 scripts/verify/misaka-palw-derive-stranger.py --crate-root <tmp>/misaka-palw-derive selftest

  source_tree_sha256  recomputed 637858dba5ea5e34b9459a580b2b81d1361aecf450bc615a4ee9621d4953a988
  cad/stl/v1          recomputed 83e0f5088cd0f9b7e55e5add8fdfdf94…
  music/smf/v1        recomputed cb5f27b4e63d9601a3e743486ea61b6a…
```

```
AGREE  source_tree_sha256   predicted 637858dba5ea5e34b9459a580b2b81d1   recomputed 637858dba5ea5e34…
AGREE  cad/stl/v1           predicted 83e0f508                           recomputed 83e0f5088cd0f9b7…
AGREE  music/smf/v1         predicted cb5f27b4                           recomputed cb5f27b4e63d9601…
```

**Three of the values I am about to paste, recomputed by a different implementation in a different
language from the raw bytes, agreeing exactly with a prediction that came from the Rust
extraction.** This is the *two ways* rule applied to the ceremony's own output, and it is
available **before** the paste rather than after it.

`check-repin-predictions.sh` compares a prediction against a table from the same extractor — it
catches a value that *moved*, not a value that was *always wrong*. **The stranger is the only
thing in this repository that can catch the second**, because nothing in it links to, imports or
shells out to `misaka-palw-derive`.

> **PASTE PROCEDURE, amended.** After writing the pins, run
> `misaka-palw-derive-stranger.py selftest` on the cut tree. **Oracle 1 must go from MISMATCH to
> MATCH.** It reads the file the ceremony just wrote and recomputes the same numbers from the
> bytes — *if the paste is wrong, this is what says so, in a voice that did not help produce it.*

### On 5f the stranger REFUSES, and that is the correct answer

```
source_tree_sha256  recomputed 98265872fb7a372c…   pinned d2419027673f94eb…   MISMATCH
music/smf/v1        recomputed 4f4edd02c53ae28e…   pinned 24be30948de1e586…   MISMATCH
exit 2 — "This verifier may NOT be used as an independent recomputation while it disagrees:
          a second implementation that is wrong proves nothing and accuses the innocent."
```

The pin file is **pre-ceremony**; the stranger recomputes from 5f's derive/src (`6b8d13ad`) and
correctly reports the pins do not match it. **Its `98265872…` is the same value the Rust drill
reported for 5f** — two implementations agreeing on a tree, and both disagreeing with a stale
pin, which is precisely the shape a working check has.

**Oracles 2, 3 and 4 pass on 5f right now**: eight corpus goldens recomputed byte-identically
(including `03-overlapping-melody.json` at 157 B — the MIDI I derived and parsed independently
above), every corpus file covered by a golden, the `verify` round-trip consistent, and a tampered
`artifact_hash` caught with exit 2. **The disagreement is confined to the one oracle the ceremony
exists to fix.**

### Two more announcement commands that do not run as written

```
python3 scripts/verify/misaka-palw-derive-stranger.py       ->  exit 2, "the following arguments are
                                                          required: cmd"   (needs `selftest`)
palw-certify drill --family a16-v5 …                 ->  exit 2, unknown family on 5f
```

**Two of the roughly eight runnable commands in the public draft, both found by running them.**
The gate is one hour old and has paid for itself twice.

### The announcement command gate — first pass, on 5f

```
FIXED   stranger.py                     -> `… stranger.py selftest`; the bare form exits 2 on
                                           "the following arguments are required: cmd".
                                           The fixed form runs: 13 oracle MATCH lines.
PENDING palw-certify drill --family a16-v5  unknown family on 5f; impl-only. Replace with
                                           `--model-id "Qwen/Qwen2.5-1.5B/graph-v5@512"` AFTER
                                           the merge and AFTER running it there.
```

1c ran the replacement on the merged tree and it is better than a fix — **the tool prints the
derivation it made:**

```
$ palw-certify drill --model-id "Qwen/Qwen2.5-1.5B/graph-v5@512" --lane attempt --out attempt.json
palw-certify: Qwen/Qwen2.5-1.5B/graph-v5@512 reaches the kernels of PALW-QWEN25-A16-V5 —
              drilling that family
wrote …: FamilyCertified, attempt lane, family PALW-QWEN25-A16-V5 (5c22b8d0…), 76873 bytes
fits one carrier                                                                      exit 0
$ … --model-id "Qwen/Qwen2.5-1.5B/graph-v9@512"
palw-certify: this build's catalogs have no `Qwen/Qwen2.5-1.5B/graph-v9@512` row       exit 2
```

> **The operator types the ROW and the tool says which family that implies.** With
> `--family a16-v5` the operator asserts the family and nothing checks the assertion — which is
> exactly the stage-5b defect, where a script named `a16` for a row whose family is
> `PALW-QWEN25-A16-V5`. **One spelling, and the derivation printed rather than assumed.**

*And the mistyped form refuses by name with exit 2, which is what a "verify it yourself" command
owes a reader who fat-fingers it.*

## The artifact answer, corroborated across two machines and two trees

```
             wt-tm f939ddc5 (Mac)            ibm 8923b354
  shipped    artifact_digest  c00faa48…      c00faa48…
  bound      artifact_digest  158314b5…      158314b5…
  shipped    inventory_root(v5) 1a7457f1…    1a7457f1…
  bound      inventory_root(v5) 1a7457f1…    1a7457f1…
  run        1 passed, 5 filtered out,       1 passed, 0 filtered out,
             59.35s                          88.55s
```

**Two machines, two trees, four identical values.** `c00faa48…` now holds **four ways**: the raw
trailing bytes read off the file, the worker's refusal text, the ibm probe, and this one.

*The redundancy found nothing this time, and that is the correct outcome rather than a wasted
twenty-six minutes.* **A second measurement that agrees converts "one machine computed this" into
"this is a property of the artifacts."** Tonight the same habit found a launch-stopper once and
confirmed a result twice — a good rate for something whose expected yield is nothing.

## Announcement gate, defect 3: the row about independent verification could not verify

Draft line 77 claims **"4 agreed, 0 disagreed"**. Run verbatim on a clean machine:

```
SKIP  …artifact.mid   mido is not installed — nothing was learned
SKIP  …artifact.stl   numpy-stl is not installed — nothing was learned
0 agreed, 0 disagreed, 4 unchecked (a skip is not a pass)            exit 1
```

**The row asserting that foreign software opens these files is the row whose command does not
open them**, on any machine that has not already installed the libraries — and the number in the
draft was obtained on one that had. A reader gets `0 agreed` and concludes the claim is false.

Fixed by naming the dependency in the command itself:

```
pip install mido numpy-stl pygltflib && python3 scripts/verify/misaka-palw-artifact-thirdparty.py --require …
```

With them present: **`4 agreed, 0 disagreed, 0 unchecked`, exit 0.** The claim is true; the
command was not sufficient to reach it.

> **The script itself is exemplary and is why this was catchable at all.** It counts `unchecked`
> as its own column, prints *"a skip is not a pass"* on the total line, and **exits 1** when
> `--require` was given and a library was missing. That is the `skip-looks-like-pass` defect
> solved rather than documented — *a missing dependency cannot be read as success here, by
> construction.* Every other tool tonight that hid an absence hid it in a passing exit code.

### The three artifacts I derived, read by three foreign libraries

```
AGREE  …artifact.glb   pygltflib   {"meshes": 2, "nodes": 3, "accessors": 6, "blend_materials": 1}
AGREE  …artifact.stl   numpy-stl   {"triangles": 20, "volume": 36.0}
AGREE  …artifact.mid   mido        {"format": 1, "tracks": 2, "ppq": 192, "note_ons": 9, "seconds": 6.75}
3 agreed, 0 disagreed, 0 unchecked                                                        exit 0
```

**Four independent readers now agree on these files**: my own parsers written from the container
specs, plus three third-party libraries that have never seen this project. Every field lines up —
2 meshes / 3 nodes, 20 triangles, format 1 / 2 tracks / ppq 192 / 9 note-ons.

**And `numpy-stl` computes the enclosed volume as `36.0`** — which is the exact figure the
announcement's §2 claims for the demonstration corpus, *"the description's sketch has shoelace
area 12 extruded 3"*. **A library with no knowledge of this project agrees the solid is the
solid**, on an artifact derived tonight rather than on a stored one.

*That is the goal's "practical output" item, measured: a MIDI that plays 6.75 seconds and 9
notes, a 20-triangle solid of volume 36.0, and a glTF scene of 3 nodes — each produced by the
chain's deriver and each accepted by software that owes it nothing.*

## Announcement gate, defect 4 — and this one reports success while checking nothing

```
$ cargo test -p misaka-palw-derive --test corpus_width -- --nocapture
running 3 tests
SKIPPED: set MISAKA_FLOOR_TOKENIZER_DENSE to a checkpoint's tokenizer.json. No width was checked.
SKIPPED: set MISAKA_QWEN36_GGUF to the QWEN36 checkpoint's .gguf. The second lane's widths were NOT checked.
SKIPPED: set MISAKA_FLOOR_TOKENIZER_DENSE. No column was checked.
test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
                                                                                      exit 0
```

**The draft cites this as the evidence for `cad 66, music 261, scene 286`, and it prints none of
those numbers.** Three tests announce that they checked nothing, and the verdict line says `ok`,
`3 passed`, exit 0. *A reader who checks the exit code — which is the careful thing to do — is
told it worked.*

With the two variables it does exactly what the draft claims:

```
music/03-overlapping-melody.json: 261 tokens        cad/01-extrude-l-bracket.json: 66 tokens
scene/02-hierarchy.json:          286 tokens
QWEN36 vocabulary: 248320 entries
music … qwen36 261, dense 261 (+0)   scene … 286/286 (+0)   cad … 66/66 (+0)
test result: ok. 3 passed                                              finished in 0.42s
```

**0.42 s against 0.00 s.** The wall clock separates the real run from the skip, for the fourth
time tonight, and it is the only field that does — the count, the verdict and the exit code are
identical in both.

Fixed by putting the variables in the command **and** the warning beside it:
*"without both variables all three tests SKIP and still report `ok`."*

### Four commands run, four defects, none of them visible by reading

```
stranger.py                no subcommand -> exit 2 usage error                    FIXED
palw-certify drill         --family a16-v5 is unknown on 5f                       PENDING merge
artifact-thirdparty.py     0 agreed / 4 unchecked without mido + numpy-stl        FIXED
corpus_width               3 SKIPPED, "ok", exit 0, none of the cited numbers     FIXED
```

**Every one was correct-looking prose in a document about verification.** Two of the four report
success while doing nothing — and the two that *fail* (`exit 2`) are the harmless ones, because a
reader sees the failure. **The dangerous half of this list is the half that exits 0.**

> *The row asserting foreign software opens these files could not open them; the row asserting a
> corpus fits a width measured no width.* **A document's claims and its commands drift apart
> silently, because nothing runs a document.** The gate is one hour old and is 4-for-4.

## A false alarm I chased to the end, and the two real things in it

The `cargo test … the_registered_row_names_the_ladder_it_needs` run printed the same test **twice**
and a compiler warning, `duplicated attribute` at `palw_step.rs:1623`. On 5f:

```
1595   /// **A close cannot buy a four-billion-position walk on every validating node.**
1596-1607  … the doc for a DoS guard: a stranger's court close hands canonical_step_coordinates
           two u32 fields nothing compares, and a declared four billion prefill tokens buys a
           four-billion-iteration walk on EVERY validating node, in virtual processing …
1608   #[test]                       <- no fn follows
1609-1622  /// doc for the NEXT test
1623   #[test]
1624   fn the_registered_row_names_the_ladder_it_needs()
```

**I was two steps from reporting that a security-critical test is missing from the tree being
cut.** The doc is complete, detailed, names the attack precisely, and has no function under it.

**It is not missing.** `a_context_wider_than_the_profile_is_refused_before_it_is_walked` exists on
**both** trees and asserts exactly what the doc describes:

```
hostile.declared_prefill_tokens = u32::MAX;
assert_eq!(canonical_step_coordinates(&profile, &hostile, u64::MAX), None);
assert_eq!(canonical_step_coordinates(&profile, &hostile_decode, u64::MAX), None);
assert_eq!(canonical_step_coordinates(&profile, &over, 0), None, "one position past … is refused");
```

**And the guard itself is in the code and is thorough** — `profile.validate_shape().ok()?` plus a
context bound, under a comment naming the same attack. Impl's copy has a single `#[test]` at 1820;
the duplicate is 5f-only and **the merge fixes it.** Cosmetic, and the compiler already says so.

> *"No `fn` under the doc, therefore the test is missing"* is the arrow again, and this time I
> checked it before speaking rather than after. **The cost of checking was four commands. The cost
> of not checking would have been a false security alarm on a launch night.**

### Real thing 1 — the meta-test has a blind spot, in the direction this fell

`every_test_in_this_module_still_carries_its_attribute()` scans the source for `fn name() {` and
requires an attribute within the two lines above. **Someone already built a guard for this class.**

```
fn WITHOUT an attribute      caught
attribute WITHOUT a fn       NOT caught      <- exactly what happened here
```

An orphaned `#[test]` does not fail the meta-test; it silently attaches to the next function, so
**the count says two and the reality is one test run twice.** Worth the mirrored check, post-cut:
an `#[test]` whose next non-comment line is not `fn` is an orphan.

### Real thing 2 — announcement defect 5

```
cargo test -p misaka-palw-base0 --lib -- the_graph_v5_row_is_admitted_by_the_kary_court_and_refused_without_it
running 0 tests
test result: ok. 0 passed; 0 failed; 276 filtered out; finished in 0.00s          exit 0
```

**That test name does not exist on 5f** — it is impl-only, like `--family a16-v5`. Fifth defect,
third of the five that exits 0 while doing nothing.

And the one command that *does* work, `the_registered_row_names_the_ladder_it_needs`, **does not
print the `512` its row cites** — 2 passed in 0.06 s, no `512` anywhere in the output. *Sixth.*

### Correction: that is five defects, not six — I over-counted my own audit

I listed the `512` row as the sixth, on the ground that its command *"does not print the `512` its
row cites."* **It does not print it; it asserts it**, which is the stronger thing:

```
assert_eq!(widest_admissible(1 << 22), 39, "the shipped 2^22 ladder");
assert_eq!(widest_admissible(1 << 26), 574);
let row = palw_a16_context_row_profile_v1(512).expect("the registered row");
for pow in …  assert!(worst_case_step_leaf_count_capped_v1(&row, 1 << pow).is_err(),
                      "2^{pow} must not admit the registered 512 row, or the ladder below is wrong");
worst_case_step_leaf_count_capped_v1(&row, 1 << 26).expect("2^26 admits it");
```

**The command's passing IS the evidence** — a reader who runs it and sees `ok` has verified the
row. That is a different table convention from the rows whose commands *print* their value, and
the inconsistency is worth a note; **it is not a defect and I counted it as one.**

```
the audit, corrected:
  stranger.py           no subcommand -> exit 2                          DEFECT, fixed
  palw-certify drill    --family a16-v5 unknown on 5f                    DEFECT, pending merge
  artifact-thirdparty   0 agreed / 4 unchecked without the libraries     DEFECT, fixed
  corpus_width          3 SKIPPED, "ok", none of the cited numbers       DEFECT, fixed
  base0 kary_court      impl-only name -> 0 tests, "ok", exit 0          DEFECT, pending merge
  consensus-core 512    asserts rather than prints                       NOT a defect
```

**Five in six, and the sixth was my error in the direction that flatters the audit.** A count of
found defects is a number with an interest in being larger, and I did not check the last one as
hard as the first four because it fit the pattern. *Availability again, and this time in the
tally rather than in the diagnosis.*

### The orphan, scoped: it is the only one, and the obvious check would not have found it

Swept independently across both branches and the merged tree:

```
palw-testnet-5f      palw_step.rs  ORPHAN at 1608 (another #[test] at 1623, no fn between)   1
palw-adr0082-impl    same file                                                               0
the merged tree      every .rs file, tree-wide                                               0
```

**Both of my claims hold — 5f-only, and the merge fixes it — and nothing else in the repository is
in this state.** The detector walks forward from each `#[test]` past comments, blank lines and
other attributes, and flags it when the next real item is not a `fn`.

> **Counting `#[test]` against `fn` would NOT have found it**, and that is the instrument anyone
> reaches for first. 5f's copy of that file has **24 attributes and 68 functions**; impl's has
> **30 and 84**. The ratio is uninformative because most functions are helpers. **The orphan is
> only visible by asking what each attribute attaches to** — the count is exactly the wrong
> question, and it is the cheap one.

**And the consequence is the inverse of every other skip-shaped defect tonight.** An orphaned
`#[test]` attaches to the next function, so the suite reports **two tests where one ran twice**.

```
every other absence tonight    showed as ABSENCE   (0 tests, 4 unchecked, SKIPPED, 0 agreed)
this one                       shows as SURPLUS    (2 passed, where 1 test ran twice)
```

*A defect that presents as extra coverage is not going to be found by anyone looking for missing
coverage*, which is what the whole evening has trained us to look for.

### The width table quoted the UNREGISTERED row's numbers under a header that says "registered"

Two figures in §7's ladder table were the `graph-v2 @ 512` projection's, in a column headed
*"admits the registered 512 row"*:

```
                     was              is                       measured
  2^22 "needs"       59,000,848       52,778,128               v5(512) = 4277d84f… REGISTERED
  2^26 headroom      12%              21% (14,330,736)         v1/v2(512) = 8d2e6f16… NOT registered
```

**The qualitative claim survives and the numbers did not.** Both rows refuse at 2^22 and both fit
at 2^26, so *"the shipped ladder refuses it, 2^26 admits it"* is true of the registered row as
well — which is why nothing looked wrong. §3's own table at line 307 has **both** rows listed
correctly and distinguished by name; the §7 table quoted one and labelled it the other.

**And the shipped test says it three times:**

```rust
let row = palw_a16_context_row_profile_v1(512).expect("the registered row");
assert!(…is_err(), "2^{pow} must not admit the registered 512 row");
assert_eq!(need, 59_000_848, "the registered row's worst case");
```

`palw_a16_context_row_profile_v1(512)` is `8d2e6f16…` — **the exact class the `bind` fix exists to
stop the tool naming.** The citation is sound and the *subject* is wrong, which is a different
defect from the one I retracted an hour ago and lives in the same test.

> **Third class-identity confusion at width 512 tonight, all of them `v1(512)` standing in for the
> registered row**: `bind --n-ctx 512` naming `8d2e6f16…`, the ladder module's tautology hiding a
> third id, and now this. **The v1 projection at 512 is a magnet** — it is what you get by asking
> the ladder for "the 512 row" without saying which graph, and three separate pieces of code have
> now mistaken it for the registered one.

### And the number travelled one hop and got *better* evidence

I reported six announcement defects; the sixth was mine. **It came back to me sharpened** —
*"the wall clock and the content both saying the row's number was never printed"* — a more
persuasive statement of a wrong claim than I had made.

```
my  "the three palw_agent_recovery tests"   -> repeated into a peer's ledger as an address
1c's restatement of my count                 -> repeated back to me with added rigour
```

**Both times the receiver added rigour downstream of an unchecked claim, and rigour applied there
makes the claim harder to dislodge.** *A number does not look like it needs checking* — and the
sharpening, not the repetition, is the dangerous half.

### The test's own doc makes this the sharpest instance of the night

```
/// … Both were true measurements of different profiles: the disagreement was
/// `qwen25_profile_v1` against **the A16 projection that actually ships**. Two measurements
/// that cannot be reconciled by argument are reconciled by putting them in one place,
/// **so this is that place.**
#[test]
fn the_registered_row_names_the_ladder_it_needs() {
    let row = palw_a16_context_row_profile_v1(512).expect("the registered row");
    assert_eq!(need, 59_000_848, "the registered row's worst case");
```

**The test exists to be the one place where profile-versus-profile confusion is resolved, and it
resolves it with the wrong profile** — three times in its own strings, under a doc explaining
precisely why that matters. *"The A16 projection that actually ships"* is `4277d84f…`; the row it
loads is `8d2e6f16…`.

**Fix, two lines, and the number written out rather than recalled because a digit here is the
whole point:** the v5 projection at 512, and `52_778_128`.

Not made here — `consensus/core/src/palw_step.rs` is shipped-tree and belongs to whoever is
holding it tonight. **Handed over as a measurement rather than as a commit nobody asked for.**

**Document state, verified rather than assumed:**

```
59,000,848  card line 307  "graph-v2/v3 @ 512"                      correctly named
            card line 310  "the same number bind printed for the v2 row"  correctly named
            card line 3660 this correction's own before/after       correctly named
            announcement                                             ZERO occurrences
```

### Closing the propagation thread

I reported a wrong sixth defect. It came back sharpened into better evidence than I had for it.
I then caught it myself and corrected it before the sharpened version could settle.

> **Both directions of that exchange worked** — the error travelled, and so did the correction,
> and the correction was faster **because I went back to the code rather than to the tally.**
> What failed was neither of us re-reading. *It was the count having an interest in being larger,
> which is not a property anyone can read off a number.*

## §4b, fifth defect: `stop` could not reach a running node, and the procedure had no next step

The corrected census found `kaspad.candidate` on ibm. Its cgroup:

```
pid 1156471   /user.slice/user-0.slice/session-28377.scope     <- a LOGIN SESSION, not a service
```

**`stop` stops and disables every `.service`. It cannot reach that process at all.** So the
documented sequence — *stop, then verify* — ends with `verify` reporting `kaspad=1`, NOT CLEAN,
and **the procedure said nothing about what to do next.**

> That is the dangerous shape, not the missing kill. **An operator at 2 a.m. who has stopped
> everything, sees `verify` refuse, and finds no next step in the runbook, may read the refusal as
> a bug in `verify` and wipe anyway** — which defeats the one gate the whole procedure exists to
> hold. *A gate with no documented way to satisfy it teaches people to bypass it.*

`stop` now enumerates by executable basename — the same walk `census` uses — skips anything whose
cgroup contains `.service`, and reports what it finds with the cgroup attached:

```
-- 169.58.39.220 --
  would kill pid 1156471 (kaspad.candidate, in (deleted) session-28377.scope — NOT a service)
-- 169.58.232.113 --   none — every node here is owned by a unit
-- 5.104.81.23 --      none — every node here is owned by a unit
```

**One host has one; the other two have none** — which is why nobody hit this: on two of three
hosts the unit loop is complete, and the fleet looks uniform until you ask each process who owns it.

### And the backticks in my own `say` lines were command substitution

```
== and the nodes NO UNIT OWNS —  above cannot reach these ==
scripts/ops/relaunch-fleet-wipe.sh: line 135: stop: command not found
```

I wrote ``say "… `stop` above cannot reach these"`` with markdown in mind. **Inside double quotes
those are a subshell**, so the word vanished from the output and the shell tried to run `stop`.
**Third backtick substitution tonight**, after the two commit messages — and the tell is the same
each time: *a word missing from the output, and an error about a command nobody invoked.*

## Two sentences the evening earned

> **A figure with its configuration is a measurement. The same figure without it is a claim.**

That is the whole difference between §3 and §7, and it is not about the numbers. §7 said *"the
registered row"* and gave another row's figure. §3 says *"2^32 ladder"* and gives that ladder's
figure — **so §3 is safe even though its number is not the shipped one, and §7 was unsafe even
though its number was real.** It applies to code identically: `palw_admission_shape_at_v1`'s doc
said *"every field is read off the bundle"* and one field was not.

> **Two out of three hosts confirming a procedure is the most persuasive possible way to be wrong
> about the third.**

The unit loop is complete on `.113` and `5.104`. It is incomplete on ibm, where one node runs in a
login-session cgroup. **The fleet looks uniform until you ask each process who owns it** — and a
two-thirds confirmation is exactly the amount of evidence that stops anyone asking.

*Both of these are consequences of the same thing: an observation carries its conditions or it
does not, and when it does not, the reader supplies conditions that were never true.*

### And the failure in §4b was procedural, not technical

`verify` was **right**. `stop` was incomplete. The defect is that being right had **no exit**:

```
the runbook said     stop -> verify
what happened        stop -> verify says NOT CLEAN -> (nothing)
what an operator      "verify is broken" -> wipe anyway -> a survivor re-feeds the old chain
   concludes at 2am
```

> **A gate with no documented way to satisfy it teaches people to bypass it.** The gate was the
> only thing standing between a partial wipe and a chain-splitting survivor, and it was the part
> that worked.

## The runbook swept for the same five patterns, and the important one had been left in

The card and the script were fixed; **the runbook is what an operator actually follows** and it had
never been checked against tonight's findings.

**Gap 1 — it did not know the script existed.** `scripts/ops/relaunch-fleet-wipe.sh` appeared **zero**
times in 609 lines, so an operator following the runbook did steps 1–3 by hand, without any of the
five findings the script encodes. §4b now names it, lists the four commands, and carries the
naive-versus-correct table.

**Gap 2 — and this one is worse: the runbook was TEACHING the defect.** Line 400 said:

```
    pgrep -af kaspad | grep -oE 'appdir=[^ ]+' | sort -u
```

**That is the exact command proved tonight to match the asking process and print its own regex as
an appdir — and to miss `kaspad.candidate`, a running node.** Minutes earlier I had added a table
saying that command is wrong, four hundred lines below it. *The document would have contradicted
itself, and the instruction is the half an operator executes.*

Both forms now appear, the wrong one labelled with its two failure modes, and **the right one was
run against a real host before being left in the document**:

```
kaspad                      --appdir=/root/.t11
kaspad                      --appdir=/root/.t11b
kaspad.candidate (deleted)  --appdir=/tmp/fpchk        <- the node both earlier forms missed
```

**The sweep, for the other four:**

```
pgrep -f            3 hits — all three are the WRONG label, the WRONG example, and the table row
journalctl scrape   1 hit  — documented as the defect, with 3-vs-9 measured beside it
list-units          1 hit  — my own table row about --plain --all
known_hosts         3 hits — all three warn AGAINST it: "the ownership test is the ssh, and only the ssh"
```

**Clean, and clean for a reason worth stating: every one of those five had already been written up
as a failure in this runbook, and the failing command itself was still sitting in the instructions.**
*A document can contain the correction and the defect at the same time, and the correction does not
disable the defect — only editing the instruction does.*

## Devnet genesis registers the class set testnet-11 registers — decided, and it moves a pin

The devnet drill reached stage 5b and stopped on the reason its own stage 2b names: *"this class's
epoch budget is already spent."* A class registered **post-genesis** is not budgeted until the next
epoch boundary; devnet's `EPOCH_LENGTH` is 1,000 DAA and the host produces ~35 s blocks, so the
boundary is **~9.7 hours away.** Stages 5b–8 — commitment, claim, Final, receipt block, **the
derived MIDI and 3D** — are unreachable on devnet as configured, on any tree.

**Decision: (a).** Devnet's genesis registers the same class set as testnet-11 — floor,
`graph-v5@512` dense, QWEN36 hybrid — so the class is budgeted from DAA 0 and **the drill rehearses
the chain being cut.**

**Why, in tonight's terms:** the evening's most expensive finding was *the drill asks a network the
chain is not.* (a) closes that difference. **(b) — shortening `EPOCH_LENGTH` to ~50 DAA — keeps the
class-set difference and adds a second one**, a devnet whose epoch no other network has, so the
drill would diverge from the cut chain in one more dimension while claiming to rehearse it.

**And (b) carries an unmeasured quantity**, stated by the person proposing it: *"I have not checked
the dense share does not round to zero blocks."* A per-epoch budget is `share‰ × epoch work`, so a
20× shorter epoch shrinks every budget 20×, and **a share that rounds to zero produces a class that
is registered, funded, and cannot produce — which looks exactly like a healthy chain with a quiet
class.** That is the failure mode this project has already shipped once.

**The loss, stated rather than absorbed:** under (a), **no drill anywhere exercises post-genesis
registration end-to-end on a live chain** — panel → chain → certification → budget → production.
The SDK and core tests cover the *admission decision*, which is where the launch-stopper was
actually found; they do not cover that sequence. **§5 carries it in those words.** The drill could
never have caught it anyway, because devnet arms the ladder and t11 does not.

### The pin it moves, and why that is the good case

`devnet_fingerprint c0da0c90…` is one of the four predicted values, and (a) moves it by design.

> **This is precisely what `check-repin-predictions.sh` exists for: a value that differs with a
> NAMED cause, named in advance, in writing, by the person making the change.** The rule is *"name
> the change that moved it, or stop."* **A pin that moves and is then quietly re-predicted is the
> thing the script prevents — and editing the constant to the new value would be exactly that.**

So the prediction is **withdrawn, not updated**:

```
PREDICTED_DEVNET_FP=WITHDRAWN-see-above
```

The new value comes from the extraction table on the tree that carries (a), and from nowhere else.
**`t11_fingerprint`, `source_tree_sha256`, `fp_golden` and `premine_builds` all stand** — (a) never
touches the t11 preset, and the stranger has independently recomputed the source-tree value and two
of the eight ids from impl's raw bytes.

*Asked for alongside it: the devnet fingerprint printed **before and after** in the same run. A pin
that moves for a named reason should still be able to show what it was.*

### The pin-safety argument for (a), measured rather than accepted

Before withdrawing one pin and keeping four, I wanted the *"(a) never touches the t11 preset"*
claim to rest on structure rather than on an assurance:

```
devnet_shipped_params()    params.rs:8035
    palw_v2_params_from_artifacts_on_base(DEVNET_PARAMS, …)      <- the line (a) changes
palw_rc_shipped_params()   params.rs:7968
    calls NEITHER builder — it constructs from PALW_RC_GENESIS_BONDS and premine outpoints
```

**They are separate construction paths.** Changing the devnet builder cannot move the t11
fingerprint, because t11 does not go through that function. *That is a structural argument, and
the reason I wanted one is that a diff-sized argument — "the change is one line, in a devnet
function" — is exactly the shape that has been wrong four times tonight.*

### The exposure the merge closes too late

```
palw-adr0082-impl  docs/history/palw-rc-testnet11-launch-runbook.md:369
    pgrep -af kaspad | grep -oE 'appdir=[^ ]+' | sort -u        <- the bare imperative
```

5f is fixed and **the merge keeps the fix** — impl has 0 commits on that file since merge-base
`bb2bec63`, 5f has 4, `merge-tree` shows no conflict, so 5f's version wins outright. **The cut is
safe.**

**But the T1–T11 fix agents are reading impl right now**, and the merge that closes this comes
*after* them. A fix agent consulting the runbook for the wipe procedure gets the command that
prints its own regex as an appdir.

> **The mitigation is a message, not a commit.** impl's docs are inside another session's working
> set, and one writer per file holds even when the fix is one line and obviously right — *especially
> then, because "obviously right" is how two writers arrive in one file.*

*Noted because the general shape recurs: a defect fixed on the release branch stays live on the
integration branch for exactly as long as the integration branch is where the work is happening —
which is the whole of the period when the most people are reading it.*

## T1 answered by reading the definition sites: devnet chose the wrong quantity, and the shipped row IS in its gap

5b's T1: the acceptance path and boot validate compare **chunks**; `check_close_cost_v2`
compares **bytes**. On the RC they agree exactly; on devnet a 1,414-byte gap opens between
81,920 and 83,333. The question they left me: *is the ceiling a byte bound or a chunk bound, and
should devnet's 81,920 become 83,333?* **The code already answers the first half:**

```
palw_mode_v2.rs:181   "COUNT is DEFAULT_MAX_CLOSE_CHUNKS, and it is the one quantity a network chooses here."
palw_mode_v2.rs:259   pub const DEFAULT_MAX_CLOSE_BYTES: u64 = palw_close_bytes_for_chunks_v1(DEFAULT_MAX_CLOSE_CHUNKS);
palw_mode_v2.rs:269   pub const DEFAULT_MAX_CLOSE_CHUNKS: u64 = 27;            (bytes_for_chunks(27) = 2,250,000)
palw_fp_devnet_v3.rs:268   const DEVNET_COURT_MAX_CLOSE_BYTES: u64 = 81_920;   <- a literal, in BYTES
palw_fp_devnet_v3.rs:17    "palw_close_chunks_for_bytes_v1(81_920) = 1, with 1,696 carried bytes to spare"
```

**The RC chooses chunks and derives bytes. Devnet chooses bytes and derives chunks — the
documented direction, backwards.** The RC's agreement between the two readers is structural;
devnet's disagreement is the arithmetic of picking the wrong quantity, and its own doc comment
recorded the slack ("to spare") without recognising it as two readers disagreeing.

> **The fix is not "raise 81,920 to 83,333". It is `DEVNET_COURT_MAX_CLOSE_BYTES =
> palw_close_bytes_for_chunks_v1(1)`** — one spelling, the documented direction, and 83,333
> falls out. Same value 5b proposed, but as a derivation rather than a second literal that
> happens to equal the first. [[derived-sets-need-one-spelling]]. It moves the devnet ruleset
> id, and devnet is being re-pinned tonight anyway for (a) — **do it in the same re-pin.**

### And "no shipped row is in the gap" is wrong, for a reason this card already lists

5b: *"graph-v5@512 closes at 81,312 B on both presets (the 83,175 figure does not reproduce on
impl)."* Measured on their own tree (`palw-adr0082-devnet-genesis`, a superset of impl):

```
83,175   ASSERTED, ungated, twice — passes in 5b's own base0 28/0:
           classes.rs:1788   the_graph_v5_row_is_admitted_by_the_kary_court_and_refused_without_it
           artifact_names_the_genesis_row.rs:429   the_registered_row_prices_at_one_carrier_under_the_bundle_…
81,312   appears ONLY in doc comments (palw_court_deadline.rs:291, classes.rs:1360), both
           from before the dissection was priced
```

The pricing itself branches on the dissection — `palw_class_admission_v2.rs` ~960:
`Op::AttnFused if fused_dissection.is_some() => { … }`, and the close is
`opening + evidence`. **So 83,175 is the row priced WITH its arity-2 dissection and 81,312 is
the row priced WITHOUT one.** The triage's route dropped the dissection — which is the
convenience-wrapper defect §4 already lists six times (`genesis_anchored_v1` and its kin assume
the genesis shape), and is the *same* `dissection: None` pricing the launch-stopper was about,
reached from a measurement instead of from the gate.

> **Consequence:** 81,920 < **83,175** ≤ 83,333. **The shipped row's priced close is inside
> devnet's gap.** On devnet as it stands, `check_close_cost_v2` refuses the genesis-registered
> row's honest widest close, and with T1's tightening a post-genesis registration of the same
> row is refused at admission — while (a) puts it in devnet's genesis, so the drill never asks.
> The derivation fix above closes both at once: 83,175 ≤ 83,333 on every reader.

t11 is unaffected — 27 chunks, 2,250,000 bytes, gap 0. **What is affected is whether devnet
rehearses t11**, which is the whole reason (a) exists.

### `launch-integration`: a second integration line with a different `derive/src`

```
launch-integration   tip 618fa198   13 commits beyond impl; devnet-genesis is 233 beyond IT
                     derive/src  10b7eac25babbfd0     prediction  4969f8dc051cac31   <- DIFFERENT
                     75079c63  chore(derive): re-pin the eight transformer ids — PROVISIONAL
                     47d9bc0a  chore(palw): regenerate the certified set — PROVISIONAL, from tree b6e2e5e4
```

A branch forked ~233 commits back, carrying provisional re-pins over a different derive tree.
**If it merges into impl as a branch, `derive/src` moves and every pin prediction is stale at
once** — `check-repin-predictions.sh` stops on exactly that, first, before reading anything
else. 5b's stated plan (adopt fixer commits individually as they pass refuters) is the safe form;
this note exists so nobody reaches for the branch. [[merging-two-repins-yields-a-third-fingerprint]]

*And one line for the record: while reading these definition sites I typed `"$T:consensus/…"`
unbraced and zsh ate the `:c` — a tool that says "unknown revision" for a file that exists —
minutes after citing the memory that describes it. The rule held only where it was already
mechanical (the scripts brace); by hand it did not.*

### Correction, twenty minutes later: the dissection mechanism was a READING, and a measurement contradicts it

The section above states *"83,175 is the row priced WITH its dissection and 81,312 the row priced
WITHOUT one"* as though measured. It was read off the `Op::AttnFused if fused_dissection.is_some()`
branch. 3e (the impl integrator) then reported one data point that the reading does not survive:

> *"the genesis route printed **81,312 at arity 2**."*

If the genesis route prices the row **with** an arity-2 dissection and gets 81,312, the 1,863
bytes are **not** the dissection openings. They are a term one route prices and the other does not
— the ladder's window reserve, Flat-ids framing, an evidence term; unknown until the two producers
are named. **My mechanism is withdrawn to the status of hypothesis; 3e's producer measurement
outranks it.**

**And the alternative is worse than what it replaces:**

```
genesis assembly     prices graph-v5@512 at 81,312    (arity 2)
bind / admission     prices the same row at 83,175    (arity 2, Flat — classes.rs:1788, asserted)
```

**Two routes, one row, one court, two prices.** The route-agreement property that broke for the
court pricing tonight, again, in the close cost. The genesis route registers the row at a price
the admission route would not reproduce; a post-genesis re-registration of the identical class is
judged at a number the chain does not hold. On the RC both fit (gap 0). **On devnet as it stood,
whether "the shipped row is in the gap" was true depended on which route was asked** — the
genesis price fits the 81,920 literal, the admission price does not.

The derivation fix makes devnet indifferent (both ≤ 83,333). **It does not make the two routes
agree.** The assertion that would have caught this is the one already named for the court:
`price(genesis assembly, row, bundle, court) == price(bind/v6, row, bundle, court)`. Whichever
number is right, that equality is the test — and finding the two producers finds the omitted term.

*Two measurements are in flight so that neither party has to be right first:* 3e naming the
producers on impl, and this session running the ungated `classes.rs:1788` assertion on a detached
worktree of `09a71652` — a second machine's reading of the same number. [[send-the-value-with-what-produced-it]]

## GREEN: a free prompt produced an answer, committed it, and retained its trace — through the operator gateway, on the class genesis registers

Detached worktree of `09a71652` (5b's tree; the v5 worker), the tokenizer-bound artifact
`bound-candidate.palwart` (sha `3f8fc506…`, inventory root `1a7457f1…`), `NETWORK_ID testnet-11`:

```
[1] health ok — n_ctx 512, chat-segments/v1; registered/fp_certified/bond_active/exposure_room
    all present, all "unknown"; can_submit false
[2] chat answered: '2+2 equals 4.'   24 completion tokens, stop_reason exact_budget
    fp_job_id f2e78a90…  trace_root …  work_leaves 6,121,824  stream_checked True
[3] artifact ok: result.borsh + unsigned commitment (925 B) + retained trace
    (manifest.json 2,598 B + material.bin 14,694,839 B)
[4] re-ask: same answer, different job id and trace root      (anti-replay binding)
[5] SSE ok — same answer, W5 checked
[6] refusals ok
rc=0   22 s
```

**That is the sentence the launch document may carry**, and the pre-announcement gate above is
met on the tree being cut, not on a side branch — `09a71652` is a fast-forward ancestor of impl
`ce557ffc`.

### Three patches were needed, and every one is the smoke describing an older gateway

```
1. class_id = "c1" * 64        -> the v5 id 4277d84f…  (the v5 worker checks its identity)
2. no exposure declared        -> the gateway DECLINED the commitment and wrote why:
                                    not_committed_because: "the bond's exposure room is not known
                                    (--bond-exposure-room-sompi / --claim-exposure-sompi …)"
                                  passing both -> committed: True
3. asserts traces/<job>/chunk-0.bin  -> the worker retains manifest.json + material.bin
```

**Nothing on the inference path was wrong.** The gateway's rule — *written only when the chain
and the operator's exposure both allow it* — is correct and self-describing; the smoke asserted
the file without meeting the rule. All three are T7, and `ce557ffc`'s smoke carries the first two
and no longer asserts a trace filename.

### The gap claim, third and final revision — the LADDER, not the dissection

3e named the producers. **81,312 and 83,175 are the same cost walk, same profile, same arity-2
dissection, same Flat ids — priced under different ladders:**

```
81,312   the genesis route + the devnet close table   bundle.court.max_step_leaf_count() = 2^26   <- the chain's price
83,175   classes.rs:1723 and artifact_names_…:392     PALW_CONTEXT_LADDER_MAX_STEP_LEAVES = 2^32   <- six more rungs, 1,863 B
```

My run printing `binding close 83175 B` for **both** `[devnet]` and `[rc]` was exactly what a
test that ignores the preset's ladder prints — and I read it as "both presets agree". **So my
"the shipped row is in devnet's gap" was true of the tests' court and false of the chain's;
3e's "no shipped row is in the gap" was true of the chain's price. Both readings were right about
a different ladder.** The 8th constant-where-the-ruleset-belongs site, in tests, and I had it in
front of me and read it as confirmation.

Fixed on `a733b21e`: both tests price at the ruleset's ladder and assert **route agreement**
against the genesis entry — `binding.close_bytes == …registration_v1(…).entry.court_cost.max_close_bytes`
— and devnet's ceiling stays derived (`bytes_for_chunks(1)` = 83,333) because the literal was a
second unit whatever the row costs. [[send-the-value-with-what-produced-it]]

## GREEN: a 3D artifact derived from a LIVE free prompt — and the exact condition under which it does

Same gateway, same tree (`09a71652`), same bound artifact. Request: a one-shot exemplar
(`corpus/cad/01-extrude-l-bracket.json`, 141 bytes compact) and the natural-language ask *"a
rectangular box 2 wide and 3 deep, extruded from z0=0 to z1=5, sketch named box"*, with
`derive: "cad/stl/v1"`. The model answered, every run, with exactly:

```
{"v":1,"frac_bits":0,"sketches":{"box":[[0,0],[2,0],[2,3],[0,3]]},"solid":{"op":"extrude","sketch":"box","z0":0,"z1":5}}
```

**Semantically correct on the first try, and in all eight runs.** At `max_tokens 56`:

```
derivation.status        derived
derivation.transformer   cad/stl/v1        transformer_id 83e0f508…   <- the re-pin set's cad/stl id, verbatim
artifact                 fp-job-2a12c5dd9094ead1.artifact.stl   684 B   binary STL, 12 triangles,
                         84 + 50×12 = 684 — a box
committed                true   (925 B unsigned commitment + 496 B derived-unsigned.borsh)
dsl_hash / grammar_id / artifact_hash 482b2323… / derived_id 746c94ce… — all present, with the
verify recipe: recompute dsl_hash = H(grammar_id ‖ canonical dsl), artifact_hash = H(transformer(dsl))
```

**The launch document may say: a free prompt produced a committed, derivable 3D artifact through
the operator gateway on the class genesis registers.** Files saved under the session scratchpad
(`derived-stl-56/`, STL sha256 `73f0693c…`); independent `palw-derive verify` pending on a build.

### The condition, measured: derivation succeeds iff the answer fills the committed budget

Seven refusals preceded the one derivation, all named by the grammar and all the same cause:

```
max_tokens 160, fenced      grammar: unterminated string               (fence + tail)
max_tokens 160, no fence    grammar: json: trailing characters at line 1 column 121
max_tokens 72,  no fence    … trailing characters at column 121        <- the JSON is 120 chars
max_tokens 60,  no fence    … trailing characters at column 121
max_tokens 56,  no fence    DERIVED
max_tokens 52 / 48 / 44     grammar: unterminated string               (the JSON cut mid-string)
```

`answer_untrimmed` shows why: `{…}<|im_end|>\n<|endoftext|>Human: Create a JSON object that
represents a 3D model…` — **the model emits both EOG tokens and keeps generating to the exact
budget**, by ADR-0077's design (execution runs to the declared decode budget; the commitment
covers every executed token), and derive receives `result.rendered` — the **full** committed
rendering, by ADR-0078 Decision 6 (*"a DSL hashed from a trimmed answer is one no verifier
holding the ids can reach"*). Together: **a grammar sees the tail unless the budget equals the
answer's length exactly.** The fence was never the cause — a fenceless answer refused identically.

> **This is a design property, not a defect in any component, and it is the sentence the launch
> document must NOT omit:** *a free prompt with a natural stop does not derive; one whose answer
> fills the committed budget does.* The corpus-driven derive tests (17/17 conformant) feed the DSL
> directly and never see a tail, which is why nothing before tonight measured this.

*The repair is a design question for after the pin, and cheaper than it looks:*
`render_answer_v1(tokenizer, ids)` lives in **`misaka/palw/base0/src/fp_worker.rs:860`, not in
`derive/src`** — so a rule that cuts the rendering at the **first committed EOG id** (the A16
manifest declares `eog_token_ids` from `<|im_end|>`/`<|endoftext|>`, fp_worker.rs:426) would
not move `transformer_id` or `source_tree_sha256`. But it changes the bytes a verifier
recomputes the derivation over, so it is a versioned rendering rule and an ADR-0078 amendment:
D6's premise is true of the *display* trim (marker-based) and false of an EOG cut, which any
verifier holding the ids and the manifest can recompute. **Not tonight. Stated instead.**

## GREEN: a MIDI from a live free prompt — and BOTH artifacts verified BOUND to their claims (ADR-0078 D5)

Same gateway, same tree, same bound artifact. One-shot exemplar `corpus/music/01-single-note.json`
(185 B compact — `03`'s 261 tokens do not fit beside the 134-token template; `01` does), ask:
*two notes in one track, pitch 60 at onset 0 then 67 at onset 480, both velocity 100, duration 480*.

```
max_tokens 160, first ask     REFUSED  grammar: duplicate key "notes"   <- the MODEL: "v":2, a second
                                        notes array in the same track, a fourth (65) not a fifth
max_tokens 160, explicit ask  REFUSED  json: trailing characters at column 240   <- the answer is now
                                        exactly right (239 chars) and the tail is the only obstacle
84 / 92 / 94 / 96             REFUSED  unterminated string / EOF at 232 / 234 / 237  (cut short)
97                            DERIVED
98 / 100 / 108                REFUSED  trailing characters at column 240
```

```
derivation.status        derived     music/smf/v1     transformer_id cb5f27b4…   <- the re-pin set's music/smf id, verbatim
artifact                 fp-job-….artifact.mid   91 B   audio/midi
                         MThd format 1, 2 tracks, 480 ppq; track 1 tempo 500,000 µs/quarter;
                         track 2 note-on (60,100) then (67,100)   <- MATCHES the ask
committed                true
```

**The first attempt's refusal is about the model, not the path**: a 1.5B model handed a one-note
exemplar and a musical instruction wrote structurally-plausible, invalid DSL; told exactly what
the array must hold, it wrote it exactly. *The launch document should say what that is: the
DSL is derivable from live output when the prompt is explicit, and the grammar refuses by name
when it is not.*

### Independent verification — the executor is not trusted

`palw-derive verify` (a fresh build of `misaka-palw-derive` in this session's worktree) was
first run with `--answer` + `--artifact` only, and **said exactly what that does not prove**:

> *consistent-given-the-supplied-answer — binding_checked: false; NOT a statement that this
> artifact came from that inference … an executor can attach any artifact of any kind to any of
> its own claims and pass every check on this path.*

Then with the claim's own inputs — `--output-token-ids` (the gateway's `misaka` extension carries
them; the outbox summary does not), `--job-context` (764 B borsh hex from the summary),
`--tokenizer`, `--family qwen25-a16-v5`:

```
cad/stl   verdict consistent   binding_checked true   dsl_hash ✓  artifact_hash ✓  output_root_matches ✓
          recomputed_output_root 56cabdb1…   claim_id fcd119d4…   from 56 output ids
music/smf verdict consistent   binding_checked true   dsl_hash ✓  artifact_hash ✓  output_root_matches ✓
          recomputed_output_root 970ac531…   claim_id 1834ba2a…   from 97 output ids
```

**Both artifacts are proven to have come from the inference that committed them** — the
derivation and the output root recomputed from ids a chain would hold, meeting at the same
value. That is the bar ADR-0078 Decision 5 sets, and it is met on the tree being cut.

*Two things the verifier taught on the way:* its exit code is 0 for `consistent-given-the-supplied-answer`
**as well as** for `consistent`, and it says so — *"a caller that branches on the exit code alone
cannot tell a checked binding from an unchecked one: branch on `binding_checked`"*. And
`--family qwen25-a16` (the summary's spelling) is not the v5 row's family name for the verifier;
`qwen25-a16-v5` is. The summary and the verifier spell the family differently — a small
[[derived-sets-need-one-spelling]] for after the cut.

## The pins, confirmed by the finalize on `971b2eff`

3e's finalize: core **1821 passed / 3 failed = exactly the three pins** (premine commitment,
fingerprints, fp golden); base0 333/0/2; derive 186/0/5 + the transformer pin; the python gates'
only disagreements are the three transformer pins. Pinned → actual:

```
t11 fingerprint    a7baab79… → 71efa66480211731…   PREDICTED ✓ (unchanged)
fp golden          700b9036… → c940b5c36ee40846…   PREDICTED ✓
premine            → ba2612417e7e0817…              PREDICTED ✓
source_tree        d2419027… → 637858dba5ea5e34…   PREDICTED ✓
eight ids          as before                        PREDICTED ✓
derive/src         4969f8dc… before and after       the basis, unmoved
devnet             84153175… → 34c7e4829eadb996…   TWO NAMED MOVES: (a) → 24d55f6d… at 09a71652,
                                                     then T1's derived ceiling → 34c7e482… at a733b21e
```

**Every prediction held, and the one value that moved, moved for two causes each named in
writing before the extraction.** The guard carries devnet as WITHDRAWN and takes the table's
value; it will refuse a table without `extracted_from 971b2eff…`. Release build → devnet drill
with the class at genesis → table → "frozen".

## The ceremony, as commands — each already run tonight in some form, each gated on the one before

Inputs it waits on: 3e's `extracted-pins.txt` with `extracted_from <sha>` and the word "frozen".
Nothing below runs until both exist. **Every step stops the sequence on a non-zero exit; none
is skipped and none is retried "just once more".**

```bash
# 0. the guard — the table is the ONLY new input; derive/src is checked first and alone
TABLE=/path/to/extracted-pins.txt scripts/ci/check-repin-predictions.sh <frozen-sha>
#    -> "all five predictions hold, against a table computed from the frozen tree", or STOP.
#       A DIFF is not a prompt to re-predict. Name the change that moved it, or stop.

# 1. the four re-pins on 5f, one commit, values pasted FROM THE TABLE (never retyped)
#    t11 / devnet fingerprints, fp golden, premine, source_tree_sha256 + the eight ids
#    then: scripts/ci/check-doc-citations.sh docs/history/testnet11-relaunch-5f-genesis-card.md <5f-tip>
#          scripts/ci/check-derive-freeze.sh    (derive/src must still read 4969f8dc…)

# 2. the merge impl -> 5f — RE-MEASURED 2026-09-04 against impl 971b2eff x 5f ee27ef4e:
#    merge-tree exit 0, ZERO conflicts (the five once pre-ruled were resolved upstream), and the
#    merged tree's misaka/palw/derive/src is 4969f8dc… — the pin basis, verbatim. A merge
#    surface is a measurement with a timestamp; re-measure on the frozen tip. Then the pin
#    tests must go GREEN on the merged tree — the same three that were red are the proof
cargo test -p kaspa-consensus-core --lib -- every_genesis_commits_to_the_premine shipped_presets_have_pinned_fingerprints golden_vector_ids_are_frozen

# 3. transport + Linux build on ibm — bundle or push, -j 4 (the OOM table in runbook §2)
git push ssh://root@169.58.39.220/root/misakas-t11r <5f-tip>:refs/heads/cut-<5f-tip>
ssh misaka-ibm 'cd /root/misakas-t11r && git checkout cut-<5f-tip> && nice -n 19 cargo build --release -j 4 -p kaspad -p misaka-cli 2>&1 | tee /tmp/cut-build.log'
#    read the log for `error`, not the exit code; a `tail` is a display decision on a diagnostic

# 4. isolated boot on ibm MUST go green. THE TABLE CARRIES NO GENESIS HASH — do not look for one.
#    The premine re-pin (utxo_commitment 2d882275… -> ba2612417e7e0817…) MOVES GENESIS.hash (audit M-07,
#    utxo_set_override.rs:66: re-pin GENESIS.hash + utxo_commitment together). The expected hash is
#    the re-pinned tree's PALW_RC_GENESIS.hash, spelled THREE ways that must agree (3e, from the tree):
#      (1) premine.rs::print_premine_commitment — the #[ignore] printer, run with
#          cargo test -p kaspa-consensus-core --lib print_premine_commitment -- --ignored --nocapture —
#          rebuilds the header over the NEW utxo_commitment with the node's own header hasher and
#          prints 'PALW_RC_GENESIS.hash (recomputed over that commitment)'. NOT the genesis tool's
#          display, which this project has recorded as lying. The table carries it as
#          t11_genesis_hash_implied <128 hex> — ABSENT if the printer printed nothing, never a placeholder.
#      (2) config::genesis::tests::test_genesis_hashes AND every_genesis_commits_to_the_premine_this_build_mints
#          both GREEN on the re-pinned tree (the second is red before the re-pin).
#      (3) the isolated boot printing the same hash.
#    971b2eff's printer said ad30b5cb965ad305…9b33edb7 for commitment ba2612417e7e0817…; the family
#    adoption does not touch the premine, so the family tip's value is predicted UNCHANGED — and this
#    session runs the same printer on its own worktree so the prediction is independent of the table.
#    A candidate boot BEFORE the re-pin prints the old 08e9c8a4cb597145… — correct for the candidate,
#    wrong for the cut.

# 5. the fleet, in this order and no other (fleet-wipe-must-stop-every-host-first):
scripts/ops/relaunch-fleet-wipe.sh census     # enumerate from PROCESSES and ss, not journals
scripts/ops/relaunch-fleet-wipe.sh stop       # every host, every unit incl. inactive-but-enabled
scripts/ops/relaunch-fleet-wipe.sh verify     # must be CLEAN before the next line exists
scripts/ops/relaunch-fleet-wipe.sh wipe       # dnsseeders are part of it; pool slot appdirs too
#    a missed host is not a stale peer tonight: it judges fused registrations by a different rule

# 6. producer first (node0 = QWEN36 producer), then the rest; on EVERY host:
#    the printed genesis hash == the re-pinned tree's PALW_RC_GENESIS.hash (see 4); the fingerprint ==
#    t11 71efa664…; the premine == ba2612417e7e0817…

# 7. the announcement gate, both green on the merged tree, before one public word:
#    artifact-stranger (independent re-derivation) and the FP gateway smoke [1]-[6]
#    and the two sentences it may carry, no more:
#      "a free prompt answered, committed, and retained its trace on the class genesis registers"
#      "3D and MIDI artifacts derived from live free prompts and verified bound to their claims —
#       when the answer fills the committed budget; a free prompt with a natural stop does not derive"
```

*What is deliberately absent: any step that reads a value from prose, any `tail` on a build,
any `pgrep -f`, any count read as a distribution, any "probably fine".*

## The guard's first real run, and the devnet drill's stall

### The guard, against a real table

3e's finalize on `971b2eff` wrote `extracted-pins.txt` with `extracted_from 971b2eff…`. The guard:

```
OK    derive/src tree        4969f8dc…          checked FIRST and alone
OK    table provenance       extracted_from 971b2eff… == 971b2eff
OK    source_tree_sha256     637858db…          OK  t11 fingerprint  71efa664…
DIFF  devnet fingerprint     predicted WITHDRAWN-see-above   read 34c7e482…   -> STOP
```

**That STOP is the script working.** The devnet value had been withdrawn for a named cause and
the guard refused to be made to pass. The operator's move is the only kind it accepts — the
value written in **with both causes beside it**, each named in writing before the extraction:

```
(a)  09a71652  devnet genesis mirrors testnet-11's class set     c0da0c90… -> 24d55f6d…
T1   a733b21e  devnet close ceiling derived from its carrier count  24d55f6d… -> 34c7e482…
```

Re-run: **all five predictions hold, against a table computed from the frozen tree.** The word
"frozen" has not been said, and the ceremony does not start on a table alone.

### The drill stalled — and the reason is ADR-0076's equilibrium, seen from the other side

Stage 1 of the devnet drill: **three floor seats, zero blocks in twelve minutes.** Measured:

```
floor-only devnet          floor 2^119.9
mirrored devnet (= t11)    floor 2^114.4   (45x harder)    QWEN36 2^127.3    graph-v5@512 2^128 = MAX
```

**Mirroring t11's class set made devnet a chain the model tiers pace — exactly as t11 is — and
the drill's seats were all floor-only.** *The drill was once again asking a chain it was not
running.* Fix under test, script only: resolve the class id from `palw-class ledger` before
stage 1 and give node-0 `--palw-producer-class=<4277d84f…>` beside its artifact — the same
shape as t11's node0.

> **On the mirrored devnet, a floor-only seat set does not produce; the drill needs a
> model-capable producer.** This is the mirror image of the rule already in this project's
> notes — *on t11 the floor must have a producer or DAA stops* — and both are the same
> equilibrium: the class-target seed puts each tier where the *registered set* pays it, so a
> chain whose set includes model tiers is paced by them, and a rehearsal that only seats the
> floor rehearses nothing.

The final table will be regenerated on the tip that carries the script fix — the pins do not
depend on the script, but the join rule says a table names the commit its run ran on, and the
guard enforces that. It will be re-run there before anything is pasted.

## While waiting on "frozen": the fleet measured, a warm-up build, and two facts from the drill session

### The census, from processes and sockets (not journals)

```
169.58.39.220 (ibm)   kaspad --appdir=/root/.t11   kaspad --appdir=/root/.t11b
                      kaspad.candidate (DELETED binary) --appdir=/tmp/fpchk     <- a leftover isolated
                      units: t11-node0, t11-node1, faucet running; miner/validator/kaspad dead     boot; wipe must kill it
169.58.232.113        kaspad .t11   kaspad .t11c   kaspad /var/lib/misaka-minerpool/slots/slot-01/appdir
                      units: dnsseeder, minerpool, pool-slot@01, t11-node, t11-seat4 running
5.104.81.23           kaspad .t11
                      units: dnsseeder, miner-c, validator-c, t11-seat2 running; seat3 dead
external peers        111.67.115.228  183.176.36.141  5.104.81.228  60.114.127.4   <- CANNOT be wiped;
                                                                                   the handshake fingerprint rejects them
live binaries         every running kaspad on ibm execs /root/t11/kaspad — NOT the build target. The wipe
                      replaces THAT path; a rebuild into target/ changes nothing a restart would pick up.
```

### A warm-up build on ibm, under a watchdog

`candidate-971b2eff` (a **sha-named** ref — a name that carries its own claim) pushed to ibm's
repo over ssh; `cargo build --release -p kaspad -j 4` (runbook §2's recipe; EVM is in the default
build) started nice'd, so the final release build is incremental. Safe because no live kaspad runs
from that target (checked by `/proc/<pid>/exe`, not assumed). **Available memory read 11 → 10 →
9 GiB against the 11.8 GiB floor §2 measured**, so a watchdog on ibm itself kills only the build
(cargo/rustc/cc1plus) below 8 GiB — the producers are the largest processes and the OOM killer
would take one of them, not the build. *The build is an optimisation; the chain is not.*

### Two facts from 5e (the acceptance-drill session), one verified and one open

**Verified on impl:** *"the 2^26 ladder forces `court_turn_deadline` 60 → 42 or the RC bundle does
not assemble (54 × 60 + 216 = 3,456 > 3,000; 59 tests red until it moved); 42 not 51 because 51
is illegal once the 2^32 fence arms."* `palw_fp_devnet_v3.rs:196 court_turn_deadline: 42`,
`palw_context_ladder.rs:1351 1 << 26`, and `the_rc_ladder_spends_2484_of_its_3000` — 54 × 42 +
216 = 2,484. **The basis carries 42; that is why the finalize was 1821/3 and not 59 reds.**

**Open, and a merge-time blocker for any family commit:** 5e's drill certified the a16-v5 family
at **409,069 B over five carriers**; 3e's drill certified impl's entry at **one carrier**. Two
family entries of different sizes for one class is one object spelled twice. **The cut ships
exactly one, chosen by measuring which route produced which — and no family commit is adopted
until 5e and 3e name the survivor.**

5e's other drill facts, with the bound artifact as their next input: stage 2 PASS (the panel
registered `4277d84f…`), stage 3 PASS (family + ClassLaneCertified on every validator), stage 4
refused the unbound artifact — the same gate this card closed with `bound-candidate.palwart`.

### The rehearsal armed on ibm, and what it can and cannot prove

Self-gating on the warm-up build: when `/tmp/warmup-build.log` carries `BUILD rc=0`, ibm copies
`target/release/kaspad` to `/root/t11/kaspad.candidate-971b2eff` (never over the live
`/root/t11/kaspad`), boots it on **loopback only** — `--testnet --netsuffix=11 --nodnsseed
--listen=127.0.0.1:39321 --rpclisten=127.0.0.1:39322`, a fresh `/tmp/fpchk-971b2eff` — captures
the `Consensus params fingerprint:` line and any genesis line, compares the fingerprint with the
table's `71efa664…`, stops the node, and writes `/tmp/rehearsal-971b2eff.result`. The recipe is
the one the previous rehearsal used (its process is still alive from 2026-08-30, running a
deleted binary, printing the *old* fingerprint `f3bf86b4…` — the wipe kills it).

**What it proves:** the candidate builds, boots in isolation, and announces the fingerprint the
table predicts. **What it cannot prove:** the genesis hash of the cut — the candidate is
pre-re-pin, so it prints `08e9c8a4…`; the cut's hash exists only after the premine re-pin, and is
proven by the M-07 test turning green, not by any table.

## The family decision, and the second withdrawn pin — both by the procedure this card demands

### Six leaves cannot have adjudicated ten kernels

Two trees certified the a16-v5 family at two sizes, and 3e measured why before choosing:

```
impl's drill    plants one fault per (table, call class)          -> 6 leaves   -> ONE carrier
5e's rig        plants one fault per (table, KERNEL, call class)  -> 28 vectors -> 409,069 B, FIVE carriers
the V5 entry    declares TEN kernels via reachable_kernels_v1; impl's only gate is reachable ⊆ declared
```

**Nothing on impl can tell a drilled kernel from a declared one, and six leaves cannot have
scored ten kernels** — whether the fused `09b81d17…` was among the six was walk-order luck. A
certificate naming a kernel the court has never been shown to score is **ADR-0069's forbidden
object**. The survivor is the per-kernel family, with `drilled_kernel_ids` and the gate
**`reachable ⊆ drilled`**. The 409 KB is the price of the fused kernel being *provably*
adjudicable rather than declared so. T4 (the drill's fixed 600 s wait against five carriers)
becomes pre-cut and lands with it.

### Consequence, named BEFORE the extraction that will move it

> The certified-set root (`court_e2e_root`) moves, and with it the **testnet-11 fingerprint.
> `71efa664…` is WITHDRAWN.** The eight transformer ids, `source_tree_sha256`, the fp golden and
> the premine do not move — none of them read the family. The new value comes only from a table
> whose `extracted_from` is the tip that carries the family.

Encoded in the guard at `db11993a`, the old value kept in the comment. **Two pins have now
moved tonight, both named in writing by the person moving them before the extraction, both
refused by the guard until named** — which is the only kind of move this ceremony accepts.

### What that does to the rehearsal, stated so its green cannot be misread

The warm-up build and the self-gating rehearsal target `candidate-971b2eff`, one adoption behind.
**Their fingerprint comparison now proves "matches the `971b2eff` table" — true, and not the
cut.** The rehearsal still proves the candidate builds and boots in isolation; the final tip
is re-pushed for the real build (incremental) and the real boot compares against the family
tip's table. *A green line whose meaning moved is the favourable staleness that survives; this
one is named here so it does not.*

### Two independent confirmations, and a test that guards the wrong rows

5e's rig (a tree that never saw the table) computes `premine ba2612417e7e0817…` and
`fp golden c940b5c3…` — its own pins red only because its literals lag. **Two of the five pins,
confirmed by a second tree's computation rather than a second reading of the same one.**

And a finding from 5e's T1 work, for whoever owns `palw_court_deadline.rs` on impl to mirror:
`the_devnet_close_ceiling_admits_every_shipped_row` iterates `palw_shipped_court_rows_v1()`, which
lists BASE-0, A16 graph-v2 and three QWEN36 geometries — **not the graph-v5 512 row, the one
that sits 158 bytes under the ceiling** (83,175 of 83,333). *The test that guards the ceiling
does not watch the row nearest it.* The row goes in so that test is the one that notices when
a future re-pricing crosses the carrier line.

### The genesis hash now has a producer, and the guard gains a sixth line

Answered by 3e from the tree, not memory: `premine.rs::print_premine_commitment` recomputes
`PALW_RC_GENESIS.hash` over the new `utxo_commitment` with the node's header hasher; the finalize
runs it as step 5b and the table carries `t11_genesis_hash_implied` — **absent if the printer
printed nothing, never a placeholder.** The 971b2eff value was `ad30b5cb965ad305…9b33edb7` for
commitment `ba2612417e7e0817…`. The family adoption does not read the premine, so the family
tip's value is **predicted unchanged**; this session is running the same printer on its own
worktree (`09a71652`, `premine.rs`/`genesis.rs` byte-identical to `971b2eff`) so the prediction
is a second computation, not a copy of the table. **The guard will check it as a sixth value
and refuse `<absent>`.**

Impl now carries the drill-seat fix (`0a9068d4`, script only; `derive/src` unmoved). 3e takes
5e's missing-row test onto impl beside T1 so `consensus/core` keeps one writer; 5e's family
commits (fault rule + covering type/gate) still come one at a time with file lists.

## The genesis hash, computed twice; the guard at six lines; and the handover rules the drill session wrote down

### A second computation, not a second reading

```
premine.rs::print_premine_commitment on this session's worktree 09a71652
  (premine.rs, genesis.rs byte-identical to 971b2eff — git diff --quiet, not assumed)
PALW_RC_GENESIS.utxo_commitment              ba2612417e7e0817…                         = the table's premine
PALW_RC_GENESIS.hash (recomputed over it)    ad30b5cb965ad305dfa1dc7516935763ea2623105581b83bb9359c7247157d36
                                             b0f8003b337cdad366e3895c8f159e99332be16e258b144dddf483bf9b33edb7
hash_merkle_root (unchanged by it)           4fb0ecf43674655f…c605d197
```

3e's finalize reported `ad30b5cb965ad305…9b33edb7` from `971b2eff`. **Prefix and suffix agree
across two trees and two machines; the guard now carries all 128 hex as its sixth line and
refuses `<absent>`.** The family adoption does not read the premine, so the family tip's value is
predicted unchanged — and if 3e's step-5b line disagrees, the disagreement is the finding.

Against the old `971b2eff` table the six-line guard stops on **exactly two** lines — the withdrawn
t11 fingerprint and the not-yet-present genesis line — with the other four OK. *That is the guard
distinguishing "withdrawn for a named cause" and "the table predates the field" from "wrong".*

### The invocation that ran zero tests and said `ok`, a third time tonight

3e's message called the printer "the `#[ignore]` printer". On both trees it is `#[test]` without
`#[ignore]`; `-- --ignored` therefore selected nothing:

```
test result: ok. 0 passed; 0 failed; 1832 filtered out; finished in 0.00s     TEST rc=0
```

The second run stated its expected count — **exactly 1** — and ran one. *This time the wrong
attribute came from a sentence rather than a file; the discipline is the same: state how many
tests the command should run before reading its colour.*

### Handover rules from the drill session (5e), verbatim where it matters

- **Never cherry-pick `618fa198` or `e23ad361`.** The first sweeps the 12-file k-ary-court reader
  under a drill-script subject; the second sweeps four unblock fixes **plus a rig-only
  `transformer_id_pin.rs` re-pin**. Either sha onto impl imports a pin with the code. Per-unit
  diffs only. (A `1fd6a30a` and B `0cdc4e15` are clean and with 3e; E/T4 and F/DENSE_FAMILY are
  scripts-only and went to 3e too, because 3e is the drill script's writer on impl tonight.)
- **Apply order on impl: A → B → H1 → D; H2, H3 free-standing; H5 (tests) last.** D calls
  `palw_post_genesis_registration_v2`, which H1 introduces — 5e's first sentence to 3e said D
  needed nothing from H1–H4, and a cross-reference check run *alongside* the claim refuted it.
  *"I ran the check alongside the claim instead of before it; the card should carry the order,
  not my first sentence."* It does.
- **The missing-row test was the rig's omission, not impl's** — impl's `palw_shipped_court_rows_v1`
  already pushes the v5 512 row. What remains is a rule to weigh after the cut, both producers
  named: *impl's shipped-rows test prints the row at 81,312 (undissected) while the k-ary court
  tries the dissected close at 83,175.* Under the derived devnet ceiling (83,333) and the RC's
  2,250,000 both fit; it is the same object priced by two routes, written down before it bites.

Drill with `bound-candidate.palwart` on the rig: `fb49d541` built clean; stage 0 PASS (18/18,
stranger agrees); 0b PASS; stage 1 running — the first boot of a devnet bundle with the k-ary
reader wired **and** the derived ceiling. Stage 4 is the verdict this card wants to read.

## The rehearsal fired: the fingerprint line, then M-07 refusing the un-re-pinned genesis — by design

```
candidate binary  /root/t11/kaspad.candidate-971b2eff   53,886,936 B   sha256 5f28a4d9…
17:41:07.240  [INFO ]  Consensus params fingerprint: 71efa664… (network testnet-11)   <- = the 971b2eff table
17:41:07.686  [ERROR] panicked at consensus/src/consensus/utxo_set_override.rs:60:9:
              genesis utxo_commitment mismatch (audit M-07): the pinned GENESIS.utxo_commitment
              does not match the premine UTXO set — re-pin it after any premine change
node stopped after 11 s
```

**Both lines are correct.** The candidate is pre-re-pin: its pinned `utxo_commitment` is the old
`2d882275…` while the build mints `ba2612417e7e0817…`, and **the M-07 guard refuses to boot a node
whose genesis does not commit to its own premine.** That is the audit fix working, and it is the
proof — from the binary rather than from a test — that a launch on an un-re-pinned tree cannot
happen by accident. It fixes the ceremony's order: **step 1 (the re-pins, `GENESIS.utxo_commitment`
and `GENESIS.hash` together) before step 4 (the boot), never the reverse.**

### Two defects in my own instruments, found by that run

**The rehearsal script reported `fingerprint OK` over a node that panicked 0.4 s later.** Its wait
loop broke on the fingerprint line before asking whether the process was alive. A green line over
a dead process — the family every false green tonight belongs to, in a script written for the
ceremony's boot step. Fixed: liveness (`kill -0`) and a `panicked at` scan are checked **before any
verdict is written**, and a dead or panicked node reads `BOOT FAILED` with the panic's location.
The fixed script is on ibm for the real boot; the candidate was not re-run — its outcome is known.

**`pkill -f "kaspad.candidate-971b2eff"` killed the ssh shell that issued it** — the shell's own
command line carried the string — and returned 255, an hour after I wrote *"a process census that
includes the censor is off by one"* into this card. The census that cannot match the asker reads
`/proc/*/exe`; it found **zero** leftovers, so the "2" the substring count reported were both
askers. The rule moved from prose to the only form that held tonight: the command itself.

### Scripts from the drill session: F and E adopted, reverted, replaced by G

F applied cleanly; E's hunk had moved, and I ported it by hand after asserting its two anchor
lines unique and adjacent — **necessary, not sufficient**: 5e then showed 5f's drill script lacks
the family-first ordering (`baseline_of "…FamilyCertified"` does not exist there), so the ported
wait sat on a structure the drill does not perform. Both reverted (`1d54629e`, `6ab20fa4`; the
scripts byte-identical to pre-adoption 5f, checked); **G** — the full ordered delta versus 5f's own
copies, eight drill commits, E and F subsumed — applied clean at `77d886b6`. `bash -n` and
`py_compile` clean (and `py_compile` writes `scripts/__pycache__/`, which impl now ignores and 5f
does not yet; removed, never committed). **Merge surface with G: exit 0, zero conflicts, merged
`derive/src` = the basis, and the merged drill script equals 5f's — G survives the merge.**

### From the drill session, in its own words

*"Two-minute gaps in a log at a two-minute cadence are not silence. I know that rule; I said
'hang' before applying it."* — retracting a silent-hang call five minutes after making it, on
measurement (`produced block #4` at 00:45:11; the "10 accepted" counted peers' blocks and
heartbeats, not the producer's own). **Stage 1 PASS; stage 2 (registering graph-v5@512) in flight
on the k-ary-wired, T1-derived bundle; stage 4 with `bound-candidate.palwart` ~15–20 min behind.**

## The per-kernel rule, measured on impl: a family the genesis can pin and the chain can never certify

With 5e's (table, kernel, call class) rule, impl's drill plants **BASE-0 26 / QWEN36 74 / A16 32 /
A16-V5 28** vectors — every declared kernel drilled (10/10, 23/23, 12/12, 10/10), root
`40c1feac…` identical to 5e's tree. And two consensus caps refuse the QWEN36 family's evidence:

```
PALW_CERTIFICATION_MAX_VECTORS = 32     palw_state_v2.rs:3001    TooManyDrillVectors { got: 74, max: 32 }
carriage ceiling 800,000 B              74 vectors = 1,442,857 B  ObjectTooLargeToChunk
```

> **A family that can be pinned at genesis but never certified through the chain.** The
> permissionless path for a hybrid-sized model closed by the certificate's own size — and three
> base0 tests say so by name. **This is the third instance tonight of the genesis route minting
> what the acceptance path refuses:** v6 priced fused rows genesis-anchored while the genesis
> assembly priced them for the court; the close ceiling's two readers disagreed by unit; now the
> certification caps bound post-genesis families and not the genesis set.

**What impl does instead — the rule's purpose, not its enumeration:** a minimal cover. Pass 1,
one leaf per (table, call class) for the court's covering check; pass 2, one leaf for each
declared kernel no chosen leaf carries; both in leaf order; the probe and the exhaustive-walk test
share one selection function, and the test asserts every declared kernel has a drill leaf.
`drilled_kernel_ids` stays equal to the declared set, so `reachable ⊆ drilled` becomes an
**equality** re-measured by the pin tests. The counts shrink to what the cover needs (QWEN36
expected well under 32); the V5 family stays one carrier or a few, never five; **the root moves
again** — from impl's own printout, into the table. The t11 fingerprint was already withdrawn;
the value that lands is whatever the printer says on the tip.

**The test this shape asks for, the same one it asked for twice already:** the genesis assembly's
families must satisfy the acceptance path's caps — `vectors ≤ PALW_CERTIFICATION_MAX_VECTORS`,
`bytes ≤ the carriage ceiling` — asserted against the *genesis set*, not only against post-genesis
submissions. Route agreement between the two spellings of "certifiable", or the genesis will
again be allowed something the chain is not.

For 5f's G: its per-carrier wait multiplies by the carrier count read from the certify log, so a
one-carrier V5 family leaves it at `parts=1` — harmless, and correct if a family ever needs more.

### Checked on impl: where the caps live, and the assertion that does not

```
PALW_CERTIFICATION_MAX_VECTORS = 32       palw_state_v2.rs:3001
  enforced at acceptance                   palw_state_v2.rs:8566    TooManyDrillVectors { got, max }
carriage ceiling, enforced at chunking     palw_state_v2.rs:3203    ObjectTooLargeToChunk { bytes, max }
per-vector byte budget, DERIVED from both  palw_state_v2.rs:3066    (CHUNK_MAX_BYTES × CHUNK_MAX_COUNT) / MAX_VECTORS
```

The three tests whose names touch the genesis set and certification —
`a_mainnet_equivalent_genesis_carries_the_certification_rules` (params.rs:11395),
`a_chain_certified_class_takes_fp_commitments_under_the_genesis_gate` (palw_state_v2.rs:15725),
`the_shipped_genesis_grants_weight_only_to_certified_families` (e2e_drill.rs:1168) — are about
rules and weight, not size. **No test on impl names both the genesis set and either cap.** A name
search, so a differently-named one could exist; but had it existed, the 74-vector family would
have been red there rather than found by three base0 tests afterwards — which is the evidence it
does not. Sent to 3e as a location for the cover tip: *for every family the genesis assembly
pins, `vectors ≤ MAX_VECTORS` and `evidence bytes ≤ CHUNK_MAX_BYTES × CHUNK_MAX_COUNT`, through
the acceptance path's own refusals.*

### The assertion exists on the tip, and the cover's numbers

`every_pinned_family_is_certifiable_through_the_chain` (base0 pin test): for every family the
genesis pins, on both lanes, build the `FamilyCertified` object from the drill's own evidence and
ask the acceptance path's own two rules — `vectors ≤ PALW_CERTIFICATION_MAX_VECTORS` and
`palw_object_chunks_v1(&object)`, the chain's own chunker — printing each family's vectors, bytes
and carrier count. **Red on the triple rule (QWEN36 74 / 1,442,857 B); expected green on the
cover.** B's core test inverted per its own instruction
(`every_pinned_family_shows_every_kernel_it_declares_as_drilled`: non-empty, declared ⊆ drilled,
equal), with base0's drilled-vs-pinned equality tests as the measurement that keeps it honest.

```
with the cover, both lanes identical:
BASE-0   14 vectors  (10/10 kernels)     QWEN36   29  (23/23 — under the cap of 32)
A16      16          (12/12)             A16-V5   14  (10/10)
court_e2e_root  e649e7c08de4e1dc3abc3ca3b5ab8e503f2d64b9fa1e909bfd7baa18afbfa651
                9711f7723bcea53523bddcc8a5690ad70a9b3aa39ce98d07d9c0391dee31de4a   PALW_RC_COURT_E2E_ROOT_BYTES
```

Suites running on it → the family commit → finalize → the six-row table with `extracted_from` on
that tip → the word. The t11 fingerprint stays withdrawn until the table spells it.

### A second computation of the tokenizer id, and one zero explained

5e ran the shipped worker in manifest mode against `bound-candidate.palwart` with the drill's
tokenizer: `shape_profile_id 4277d84f…` (the registered class, byte for byte), `model_profile_id
158314b5…` (the bound artifact's digest), `n_ctx 512`, **`tokenizer_id fa9a43521e324f84…`** —
the value this project's notes carried as the tokenizer commitment, now shown to be the
*derived id* (sha256 and blake2b of the file match neither), from a tree that never saw the table.
The file: ibm's `/root/palw-class/qwen25-src/tokenizer.json` is sha256 `c0382117ea329cdf…`,
7,031,645 B, **byte-identical** to the Mac's `models/qwen2.5-1.5b/tokenizer.json` — Qwen2.5-1.5B
base and Instruct ship one tokenizer, so the base checkpoint on the Mac never mattered for the
tokenizer, only for the weights. Stage 4's tokenizer gate is open before the drill reaches it.

`runtime_manifest_hash` is all zeros in manifest mode — and in every mode for the A16 family:
`fp_worker.rs:442 runtime_manifest_hash: Hash64::default()`, and `/health` printed `0000…` in
serve mode during this session's runs. A seat comparing it compares zero to zero. Named, not a
problem tonight.

### The certifiability test fired again under the cover, and the carriage moves — with one fact about what the fingerprint does not see

```
both lanes, with the cover:
BASE-0   14 vectors   754,377 / 531,397 B   (8 / 6 carriers)
QWEN36   29 vectors   914,168 / 931,572 B   REFUSED — ObjectTooLargeToChunk over 800,000 B
                                             (PALW_OBJECT_CHUNK_MAX_BYTES 100,000 × PALW_OBJECT_CHUNK_MAX_COUNT 8)
A16      16 vectors   227,425 / 236,837 B   (3)
A16-V5   14 vectors   190,438 / 198,754 B   (2)
```

The court's cap of 32 vectors holds everywhere; **the carriage does not hold a 23-kernel family
whose vectors are ~32 KB each.** So under the cover the genesis would still pin one family the
chain refuses to carry — the assertion written an hour ago for exactly this caught it before the
printer ran.

**Decision (3e), at the rule's location:** `PALW_OBJECT_CHUNK_MAX_COUNT` 8 → 16 (1.6 MB; QWEN36
becomes 10 carriers, BASE-0 stays 8) — a consensus rule change on lifecycle carriage, safe by the
re-genesis argument, its doc naming the measurement. Consequences **derived, not retyped**:
`PALW_CERTIFICATION_MASS_PER_VECTOR` (carriage ÷ 32) 25,000 → 50,000 and
`PALW_OBJECT_CHUNK_SLOT_MASS` 800,000 → 1,600,000 — a family that fills its carriage pays for the
carriage it fills (ADR-0075 SA-2); pending chunk groups hold 16; the admission test's pinned "8"
says 16 with the reason; 16 < 27 keeps the close's own table above it.

> **What the fingerprint does not see, measured:** none of the three constants is read by
> `params.rs`, the identity module, or the bundle — so neither the fingerprint nor the ruleset id
> covers the carriage. A node on 8 and a node on 16 would **handshake and then diverge silently**.
> Tonight that is covered by accident of ordering: the family root moves the t11 fingerprint
> anyway, so every old binary is refused at the handshake. **A future change to the carriage
> alone would not be** — post-cut, the carriage constants belong in the ruleset id or behind a
> fence, so a rule that decides what a chain carries is a rule the handshake can see.

### impl took the carriage commit — `4d572142` — measured against 5f before anything else

derive/src in its diff: 0 lines; `derive/src` tree still `4969f8dc…`; fingerprint / version / pin
constants touched: 0. Merge surface impl `4d572142` × 5f `873ef2a9`: exit 0, **0 conflicts**, merged `derive/src`
= the basis, G survives. The five predicted guard lines are unmoved by it, as measured rather than assumed.

### Both commits are on impl; the finalize runs on `4d572142`; the devnet fingerprint moves a third time

```
e4f97110  the family: A+B merged onto the probe helper as the minimal cover; pinned 14/29/16/14 with
          drilled = declared; PALW_RC_COURT_E2E_ROOT_BYTES = e649e7c0…; B's test inverted; the
          certifiability route-agreement test                                derive/src: 0 lines
4d572142  PALW_OBJECT_CHUNK_MAX_COUNT 8 -> 16 with the measurement in its doc; the admission pin
          says 16 with the reason; the derived fee constants doubled           derive/src: 0 lines
suites before the commit: core state/admission/ladder/e2e/mass 152/0; base0 e2e_drill 22/0 incl.
every_pinned_family_is_certifiable_through_the_chain — BASE-0 8/6 carriers, QWEN36 10/10, A16 3/3,
A16-V5 2/2, all under 32 vectors and 1.6 MB
```

**Named before the extraction:** the family root is in devnet's bundle too, so `e4f97110` moves the
devnet fingerprint a **third** time (after (a) and T1). Withdrawn in the guard with the cause and the
held value `34c7e482…`; **the guard now carries four predictions** — source_tree `637858db…`, fp
golden `c940b5c3…`, premine `ba2612417e7e0817…`, implied genesis `ad30b5cb…9b33edb7` — **and two
withdrawn lines** (t11, devnet), which is precisely the shape of the table 3e expects. Finalize →
the six-row table with `extracted_from 4d572142…` → the word, in about fifteen minutes; the drill
runs behind it with two dense producers and does not gate the word.

### ibm pre-staged on `4d572142` — the boot's fingerprint line will be the second reading of the one value that moved

`candidate-4d572142` pushed (sha-named); incremental warm-up on top of the `971b2eff` build into a
**new** log (`/tmp/warmup-build-4d572142.log` — the old log's `BUILD rc=0` would have satisfied the
rehearsal's wait at once, a self-gate reading the wrong file); the memory watchdog re-armed; the
corrected rehearsal script re-keyed to the sha and that log (8 sha occurrences, 0 stale). Its boot will
M-07 by design — pre-re-pin — and its `Consensus params fingerprint:` line is the new t11 fingerprint
from a node, a binary and a second machine, to be compared by hand with the table's row when it lands.

### The drill session: stage 3 PASS on the 512 row, the pairing check agreed, and stage 4 handed the wrong file

*"the registration and the certification agree on `4277d84f7d91528c…` — two independent derivations,
one value."* All five a16-v5 carriers landed (00:55:10 → 01:12:11), the family applied, and
`ClassLaneCertified` reached all three validators at 01:12. **Stage 4 had no colour because the
rig's wrapper re-assigned `MISAKA_PALW_ARTIFACT` to the UNBOUND file** — the worker refused it with
the same "declares no tokenizer commitment" as before. Stages 2–3 were unaffected (identical inventory
root, identical class id); the wrapper now honours the caller's environment and the run was relaunched
on `bound-candidate.palwart`. In 5e's words: *"the value to verify is the one in the gateway's log, not
the one on the invocation."*

Measured on the way and worth keeping: **chunk carriers land in the submitting node's OWN blocks** —
4 of 5 in node-0's, and six consecutive peer-produced blocks carried none of node-0's queued parts.
On this devnet the stage-3 clock is the submitting producer's block interval, not the chain's; T4's
×parts absorbed it (5 parts in 17 min against a 3,000 s wait). *Post-cut question: whether peers should
carry a submitter's queued chunk parts, or the clock should be stated as the producer's.*

## THE TABLE LANDED — `extracted_from 4d572142`, six rows, 01:20

```
  extracted_from 4d57214222953bdd96d0f94e3693e09d01a995f3
  source_tree_sha256 637858dba5ea5e34b9459a580b2b81d1361aecf450bc615a4ee9621d4953a988
  t11_fingerprint a5291e005aca6068d465434c317e05ad24f054faa04a68c38ec0857566c38fa9
  devnet_fingerprint b40976b27c3bfbd3d6c590b33824f15c4959d6bcfba3676630919b964e94ad34
  fp_golden c940b5c36ee40846087e6c5927d6e6b5
  premine_builds ba2612417e7e0817
  t11_genesis_hash_implied ad30b5cb965ad305dfa1dc7516935763ea2623105581b83bb9359c7247157d36b0f8003b337cdad366e3895c8f159e99332be16e258b144dddf483bf9b33edb7
```

**The guard's first pass, before any value was written in:** provenance OK; `source_tree`, fp golden,
premine OK; **`t11_genesis_hash_implied` OK against this session's independent `ad30b5cb965ad305…`** —
the finalize's printer and my worktree's printer computed the same genesis hash over the same
premine, on two trees; and **DIFF on exactly the two withdrawn lines** (t11, devnet — the family
root), which is the guard refusing to compare a withdrawn value, not a disagreement. **Two values
moved tonight and both were named before the extraction**; their table values are now written in
beside the causes, and the guard reads **six OK**.

The word "frozen" has not been said. The ceremony's first step — the six re-pins — waits for it. The
rehearsal on ibm (`candidate-4d572142`) will print the t11 fingerprint from a node on another machine;
it must equal `a5291e005aca6068…` from this table.

## FROZEN — 4d57214222953bdd96d0f94e3693e09d01a995f3

3e's word, with the finalize read from its log: CI clippy 0; core 1822/3 = exactly the three pin
tests; base0 0; derive 0 with only the transformer-id pin red; sdk/cli/kaspad/gateway/certify-bin/
probe/artifact-names/answer-binding all 0; conformance selftest 0 disagreed; stranger 15/18 with
the three transformer pins the only disagreements; **the premine printer ran exactly one test.**
`derive/src` unchanged since the basis. The into-5f merge `ef50c376` = 5f + tip, zero conflicts.

### Ordering correction, made before the step: merge first, then the six re-pins

The run-sheet said re-pins then merge. The pin sites exist in their final form only on the merged
tree, so the merge comes first and the re-pins are applied to it. A dry-run worktree on the
*computed* merged tree (a dangling commit; no branch touched) carries the patch — **4 files,
12 insertions / 12 deletions** — and the five pin tests run there first; only green there lets the
patch touch 5f, where the same five run again after the real merge + apply.

*A generator defect caught by its own output:* the first patch matched the two `genesis.rs` byte
arrays with whitespace joins and no commas, edited nothing there, and produced a 48-line "patch"
that was four-sixths of one. Regenerated with commas: 82 lines, all six sites, every old value
grep-checked absent from the tree before the tests were read.

## The dry-run merge caught the extraction order: the fingerprint hashes the genesis, so every table extracted before the genesis re-pin is stale by construction

On the computed merged tree (zero 5f-only commits touch consensus — its code is the tip's), the six
re-pins from the table, then the five pin tests:

```
every_genesis_commits_to_the_premine_this_build_mints   ok        GENESIS.hash + utxo_commitment right
test_genesis_hashes                                     ok
palw_derived_v1::golden_vector_ids_are_frozen           ok
shipped_presets_have_pinned_fingerprints                FAILED    testnet-11: pinned a5291e00… (the table)
                                                                  GOT 2222e054f87bed7a33e9c017f5403cd52070d0778776b5bd78143e7f82ff92b7
                                                                  devnet: held (b40976b2…)
palw_freeprompt_v3::golden_vector_ids_are_frozen        FAILED    job_id c940b5c3… PASSED; claim_id got e75b8d2e… vs pinned a7c87ce3…
```

**Mechanism, from the tree:** `consensus/core/src/config/params.rs:3058 — h.write(genesis.hash.as_bytes())`.
The consensus fingerprint hashes the genesis hash; the finalize extracted `t11_fingerprint` while
`GENESIS.hash` was still `08e9c8a4…`; the ceremony re-pins it to `ad30b5cb…` (M-07 demands it) and
the fingerprint moves with it. Devnet's genesis did not move and devnet's row held — the same
mechanism seen from the other side. **The cut's t11 fingerprint is the value printed after the
genesis re-pin, `2222e054…`; the table's row is a prediction for a tree that no longer exists once
step 1 runs.** Rule for every future ceremony: **extract after the genesis/premine re-pin — genesis
first, then everything that is a function of it.**

**Second finding, the report-without-verdict shape inside one test:** `golden_vector_ids_are_frozen`
pins **four** values (job_id, claim_id, spend_id, ticket). On the tip the first assertion failed on
job_id, so the other three never ran — the finalize's red described one pin of four. With job_id
fixed, claim_id surfaced; spend_id and ticket are still behind it. Extracted in one run with a
temporary `eprintln!` in the dry-run tree only, so fail-fast cannot hide the next value. **Nothing
has touched 5f.** The merge + re-pins land only when all five are green on the dry-run tree, and
then again on 5f.

### Three more values the table could not carry, extracted from the tree that ships

**The derive pin's `PINNED` ids were stale in content, not only in order.** The file pinned
`cad/stl … cde32f30…` where `actual()` computes `83e0f508…` — the eight ids in my drill report,
verbatim. 3e's "the eight ids are unchanged" was true of `actual()` and false of the file; the
tip's derive pin was red for content. Line 122 compares `actual()` **sorted by name** against
`PINNED` in file order, so the array is rewritten sorted, from the test's own printout.

**`golden_vector_ids_are_frozen` pins six values, and fail-fast hid five behind one.** Extracted
in one run on the patched merged tree — after the genesis re-pin, which several of them are
functions of:

```
job_id    c940b5c36ee40846087e6c5927d6e6b5    (= the table's fp_golden; the only one the finalize could see)
claim_id  e75b8d2e3c590e6df59fe1b0db52676b    was a7c87ce3…
spend_id  87a0c79c36bf8ff80678a7c3bc48326e    was 7c3e3de7…
ticket    9a3ed14b531af14a6e2071e206f8e711    was 24a7acb7…
tag[..8]  24e4a611d9d25f45                    was f0a32ed1…   <- the one nobody had mentioned
tag.len() == PALW_FP_V3_L1_TAG_BYTES          a constant, not a pin
```

**Patch v3 on the dry-run merged tree: 4 files, 24 insertions / 48 deletions; every old value —
thirteen patterns including both byte-array heads and the probe — grep-checked absent.** The five
pin tests run on it now; only green there lets it touch 5f.

### The mechanism from the binary, and the guard's t11 line corrected

ibm's un-re-pinned `candidate-4d572142` booted, printed `Consensus params fingerprint: a5291e005aca6068…`
— the table's value, computed by a node on another machine — then M-07 refused it (`genesis
utxo_commitment mismatch`), and the corrected rehearsal script reported **`BOOT FAILED (alive=0
panics=4)`** instead of a green fingerprint line. Three sides, one mechanism: `a5291e00…` is the
pre-genesis-re-pin fingerprint wherever it is computed; `2222e054…` is the cut's. The guard's t11
line now holds `2222e054…` with `params.rs:3058` as its cause and the pre-re-pin value kept beside
it; a table row extracted before the genesis re-pin is *expected* to differ from it.

v3 pin tests on the patched dry-run tree: CORE rc=0, DERIVE rc=0 (read at 01:34).

## STEPS 1–2 DONE ON 5f: the merge, then the re-pins — proven green on a dry run of the same tree first

```
11241594  Merge palw-adr0082-impl at 4d572142 into palw-testnet-5f   zero conflicts, derive/src 4969f8dc…
6e01ba07  the re-pins for the cut — genesis first, then everything that hashes it
          GENESIS.hash 08e9c8a4… -> ad30b5cb…   utxo_commitment 2d882275… -> ba261241…
          t11 a7baab79… -> 2222e054…   devnet 84153175… -> b40976b2…
          six fp goldens; source_tree d2419027… -> 637858db…; PINNED ids from actual(), sorted
```

Dry run of the identical consensus tree: **core 5 passed, derive 3 passed** before the patch
touched 5f; every superseded value grep-checked absent on 5f after it. The same five run on 5f
itself now. The freeze checker's standing caveat (formatting is inside the hash) is met by 3e's
fmt being a no-op on the tip; the citation checker caught one line number of mine that moved with
the merge, fixed against HEAD.

## STEP 3 RUNNING: the real tip on ibm

`candidate-6e01ba07` pushed (sha-named), checked out on ibm, `cargo build --release -p kaspad
-p misaka-cli -j 4` incremental over the two earlier warm-ups, the memory watchdog re-armed, the
corrected rehearsal keyed to it with **`EXPECT_FP = 2222e054…` and `EXPECT_GEN = ad30b5cb…`**. This
boot must come up **without** M-07 and print both — the two values the un-re-pinned binary could
not produce an hour earlier. Its verdict is read as evidence only once 5f's derive pin is green too.

**5f after steps 1–2: core 5 passed, derive 3 passed** — `every_genesis_commits_to_the_premine_this_build_mints`,
`test_genesis_hashes`, both `golden_vector_ids_are_frozen`, `shipped_presets_have_pinned_fingerprints`,
and the three transformer-pin tests — on the release branch itself, after the real merge and apply.

## STEP 5, measured before it is taken

```
hosts        all x86_64 / glibc 2.39 / Ubuntu 24.04; /root/t11/kaspad byte-identical (52,295,128 B) on all three
             -> ibm's release build runs everywhere by copy
stop         10 units on ibm, 6 on .113, 9 on 5.104 — listed by the script's dry run, verbatim
wipe gate    `wipe --genesis 08e9c8a4…` (the backup is named by the OLD genesis) re-verifies nothing runs and
             ABORTS while any host does — "a live host would re-feed the old chain". Shown refusing in dry run.
producers    node0: --palw-produce --palw-panel, class 5bd9ae3d… (QWEN36), artifacts qwen36.palwq36 +
             qwen25-1.5b-a16.palwart + qwen25-coder-a16.palwart, bond …:0, fee outpoint …:41
             node1: --palw-produce --palw-panel + heartbeat miner, bond …:1
             (the unbound A16 artifact is fine for producing/certifying — inventory root identical; only the
             operator FP gateway needs bound-candidate.palwart)
stale        5.104's misaka-dnsseeder and misaka-miner-c are TESTNET-10's (network-id testnet-10, t10 anchors,
             kpq-t10-bin/misaminer) — stopped by the wipe, not restarted. .113's dnsseeder is the only t11 seeder
             (anchors ibm + .113) and is restarted after the wipe.
step 6 check whether the bond outpoints (…:0, …:1) and the fee outpoint (…:41) exist in the NEW premine is the
             producer's own refusal at start; it is not assumed here.
```

*Card hygiene, post-cut:* `check-doc-citations.sh` resolves all 64 of this card's `file.rs:NNNN`
citations against HEAD (cited set == resolved set) and still prints its "at least one does not exist"
summary — the checker's summary logic is wrong, not the citations. A tool built to catch a class of
defect carrying one of its own in the verdict line; fixed after the announcement, not before.

## STEP 4 GREEN: the release binary of the cut booted in isolation and printed the cut's fingerprint

```
18:54:34  [INFO] Consensus params fingerprint: 2222e054f87bed7a33e9c017f5403cd52070d0778776b5bd78143e7f82ff92b7 (network testnet-11)
verdict   fingerprint OK — and NOT "BOOT FAILED": the corrected script checks liveness and scans for
          `panicked at` before writing any verdict; M-07 did not fire
genesis   the node prints no genesis-hash line; the genesis is proven by M-07's silence at boot plus
          every_genesis_commits_to_the_premine_this_build_mints and test_genesis_hashes green on 5f
```

Three readings of the one value that moved: the pin test's `got` on the merged tree, the mechanism at
`params.rs:3058`, and now a node's own line from the release binary on another machine. The un-re-pinned
binary printed `a5291e00…` and died under M-07 an hour earlier; this one printed `2222e054…` and lived.

## STEP 5 IN PROGRESS: stop → verify → wipe

`relaunch-fleet-wipe.sh stop --execute` on all three hosts (10 / 6 / 9 units), the stray deleted
`kaspad.candidate` on ibm killed by executable path; `verify` must read CLEAN before `wipe --genesis
08e9c8a4…` (appdirs renamed in place, never deleted).

### From the drill session, for the launch document: "add a model" on a running network produces nothing until the next epoch boundary

5e's stage 4 PASSED with `bound-candidate.palwart` (the gateway serves the 512 class; `/health`
names the four chain facts at n_ctx 512); stage 5 refused: *"the executor bond is not producible:
this class's epoch budget is already spent (bond_active false)"* — a class registered mid-epoch holds
share but has no entry in the epoch budget table until the boundary (`EPOCH_LENGTH = 1_000` on
devnet, ~11 h at its cadence), and `unwrap_or(0)` renders "never granted" as "already spent".
**The launch's own classes — floor, A16 512, QWEN36 — are genesis classes and hold budget from
epoch 0; the wall belongs to later permissionless additions.** And the distinction this card keeps:
tonight's STL and MIDI were committed **locally** by the offline gateway and verified bound (D5) —
never submitted, never budgeted; 5e's stage 5 is the first real job to reach the chain's budget gate.

## Step 5 — executed 2026-09-03 17:14 UTC (2026-09-04 02:14 JST): stop, verify, wipe, install

**5a stop (`relaunch-fleet-wipe.sh stop --execute`)** — every listed unit on the three hosts stopped *and disabled*
(a unit that restarts on boot un-wipes its host): ibm's producer/seat/drill/ibd-join/liveness units; `.113`'s
dnsseeder, minerpool, mtp, pool-slot@01, t11-node, t11-seat4; 5.104's kaspad-tn, dnsseeder, miner-c, t11-seat2/3,
validator-c, drill-attest/watch, liveness-watch. 5.104's dnsseeder and miner-c are testnet-10 leftovers and stay
down. ibm's stray `kaspad.candidate (deleted)` (pid 1156471, `--appdir=/tmp/fpchk`, no unit) was killed **by
executable path** — `pgrep -f` would have matched the asker. `.113`'s node took the SIGTERM slowly; nothing was
forced.

**5b verify** — measured `kaspad=0 p2p-sockets=0` on all three hosts and printed **NOT CLEAN**. The counts arrived as
two lines: `pgrep -c … || echo 0` and `grep -c … || echo 0` both *print* `0` and *exit 1* on no match, so the
fallback printed a second `0` and the comparison read `"0\n0"`. A check that had only ever seen live hosts had never
had the chance to be wrong in this direction. Fixed at the fallback (`|| true`, `${n:-0}`) in `bb754d12`; an
independent census (exe path + `ss`) agreed: 0 chain processes, 0 listening chain ports. The one remaining
kaspad-family process on ibm is the **Aug-31 offline free-prompt gateway** (`misaka-palw-gateway (deleted)`,
`--anchor` form, no chain, no p2p) — not a node; it holds a port a step-7 gateway may want.

**5c wipe** — the **dry run** (the script's default) would have moved a directory literally named `[^` on every host:
the wipe enumerated appdirs of *running* nodes with `pgrep -af kaspad | grep -oE "appdir=[^ ]+"`, which matches the
remote shell running it (its own cmdline holds the pattern), returned `[^`, and — being non-empty — masked the
static fallback. Under `--execute` that is a wipe that moves nothing and prints nothing, and the old chain is still
on disk when the nodes restart. The rule's location: `wipe` runs only after `verify` proved nothing runs, so "the
appdirs of running nodes" is empty by construction; the list is now the census's static set (`b1b98c63`). The dry
run then listed exactly the census's six, and `--execute` moved them:

    ibm    /root/.t11  /root/.t11b
    .113   /root/.t11  /root/.t11c  /var/lib/misaka-minerpool/slots/slot-01/appdir
    5.104  /root/.t11
    -> <dir>.old-08e9c8a4…16934a-20260903-1714     originals after: 0 / 0 / 0    backups: 2 / 3 / 1

The seeder state dirs the script checks were absent on every host (seeders are stopped+disabled; their state is an
address list, not chain data). `/tmp/fpchk` (my rehearsal scratch on ibm, holds the *new* genesis) was excluded on
purpose — naming it with the old genesis would mislabel it.

Two instrument defects in one step, opposite directions: verify said "not clean" over clean (the safe error), wipe
would have said nothing over nothing (the unsafe one). Only the dry run, read before the real run, saw the second.

**5d install** — `kaspad.6e01ba07` (sha256 `14065c93…`, 53,913,240 B) and `misaka.6e01ba07` (`5fd49aca…`) were
staged on all three hosts under sha-named paths before the wipe (independent of it), sha-checked against ibm's
build, then copied to `/root/t11/kaspad` and `/root/t11/misaka`; the 5e binaries are kept beside them as
`kaspad.old-5e` (52,295,128 B) / `misaka.old-5e`. x86_64 / glibc 2.39 / Ubuntu 24.04 on all three.

**Outpoints across the re-pin** — the wrappers' `--palw-fee-outpoint` tx id is the constant `misaka-premine`
(`6d6973616b612d7072656d696e65…`), not a hash of the outputs, so only the *index layout* could move them.
`MAIN_PREMINE_INDEX = 40` on both 5e's tree and the cut, the eight bond cards are byte-identical (indices 0–7,
floats 41–48), and the community rows live under their own `TESTNET11_COMMUNITY_TXID` (now 13 rows: Nusi 100M and
The Witch King 1M appended, tetsu31's address replaced in place, 648M total). Every wrapper's `:41`–`:47` names the
same output on the cut as on 5e. The producer's own refusal remains the last check.

**Shared loss, in 5e's sentence:** with the 512 row in devnet genesis, no live drill exercises post-genesis
registration end to end; the admission decision is covered by route-agreement, `palw_rc_admission_shape` and SDK
tests, and the live evidence for the path itself is 5e's drill stages 2–4 on the floor-only card — registered →
certified → served → refused at the budget gate as `palw_admission_v2.rs:1408` documents. t11's three classes are
genesis classes and hold budget from epoch 0; the wall belongs to later additions.

## Step 6 — producer first, then the seats (2026-09-03 17:16 UTC onward)

**6a node0 (ibm, `misaka-t11-node0`, QWEN36 producer + panel + heartbeat lane).** Started 17:16:30 UTC. P2P `26311`
listening after **344 s** — the 33.99 GiB QWEN36 artifact is mapped and its root derived in one pass over the file
(`computed root f4aad4fd…`), then the two A16 artifacts (1.67 GiB each); the panel shares the producer's holdings
rather than mapping a second time. rss 4.5 GB. The four lines the run sheet asks of the producer:

    fingerprint   2222e054f87bed7a33e9c017f5403cd52070d0778776b5bd78143e7f82ff92b7 (network testnet-11)
    court         PALW court certified end-to-end for: PALW-BASE-0, PALW-QWEN36, PALW-QWEN25-A16, PALW-QWEN25-A16-V5 (court_e2e_root e649e7c0…)
    genesis       "local: ad30b5cb965ad305dfa1dc7516935763ea2623105581b8…" — read from the rejects THIS node generated
                  for inbound peers (the 'local' of a generated reject is ours; of a RECEIVED reject it is the peer's)
                  = PREDICTED_T11_GENESIS. M-07 silent, 0 panics.
    outpoints     panel and producer started on bond misaka-premine:0 (float :41 accepted by the producer's own start)

Nine distinct external community nodes were refused on genesis mismatch within the first minute (one, 169.58.13.16,
still carries Relaunch 4's `8d2002cc…`). They need the announcement: new genesis, wipe, new binary.
`getBlockDagInfo` over `--rpclisten-json` failed as an HTTP POST: that port is wRPC over WebSocket. The instrument is
`misaka node liveness --rpc 127.0.0.1:26313` (borsh). At +2 min: `ALIVE: daa=0 blocks=0`.

**6b node1 (ibm, `misaka-t11-node1`, floor producer + panel).** Listening after 56 s (no model class to map),
fingerprint `2222e054…`, **connected to node0** on both `127.0.0.1:26311` and `169.58.39.220:26311` — a completed
handshake is the same-genesis proof, stronger than a reject line. 0 panics. Liveness right after:
`ALIVE: daa=1 blocks=1 advanced` — the new chain's first block.

**6c `.113` public node (`misaka-t11-node`, panel + heartbeat, artifacts present).** Listening after 73 s,
fingerprint `2222e054…`, own genesis `ad30b5cb965ad305…`, connected to node0 and node1, panel loaded the artifacts,
0 panics, `ALIVE: daa=1 blocks=1 advanced`. 5.104's seat2 (`c-seat2.sh`: producer class `71bbb755…`, all three
artifacts, panel) started 17:27:26 and was still in its artifact pass at 17:36 — unmeasured, not failed; its watch
reads a wide window (the first watch's `--since "8 min ago"` fell one minute after its fingerprint line, and a unit
whose `ExecStart` is `bash <wrapper>` was parsed as a wrapper named `bash`).

**The seats' artifacts are a launch item, not a note.** 5e's live finding (2026-09-02): a panel seat launched
without `--palw-class-artifact` files an `Incapable` receipt for every claim, which counts toward neither side of
the quorum; with five seats, quorum 3 and the executor excluded, no claim could ever reach Final and
`final_claims` stayed 0. The 5e launchers on the hosts still lacked them on node1. Every host holds all three
(`qwen36.palwq36` 33.99 GiB, `qwen25-1.5b-a16.palwart`, `qwen25-coder-a16.palwart`; 23 GB RAM each, page cache
shared per file), so node1's launcher got the three flags (`ibm-node1.sh.pre-5f-artifacts` kept) and was
restarted; seat4's is checked and fitted the same way before it starts. The announcement may not say "finality"
until `final_claims` is read non-zero within the bind+challenge windows — that sentence has to be earned by a read,
not by "the seats are running".

**Liveness watchdogs come last on purpose:** `misaka node liveness` reads a node in its artifact pass as WEDGED
(RPC refused), and a watchdog armed then would restart the node it is waiting for.

### 6d — the fleet, measured 17:48 UTC (fingerprint from each node's own log; genesis from the rejects it generated; liveness over borsh)

    host   unit                 role                         fp        genesis   peers      Incapable  panic  liveness
    ibm    misaka-t11-node0     QWEN36 producer+panel+hb     2222e054  ad30b5cb  in 9       0          0      ALIVE daa=26
    ibm    misaka-t11-node1     floor producer+panel (refit) 2222e054  (no inbound rejects; handshakes with node0/.113/seat4)  0 since refit  0  ALIVE daa=26
    .113   misaka-t11-node      public entry, panel+hb       2222e054  ad30b5cb  out 2 in 5 0          0      ALIVE daa=26
    .113   misaka-t11-seat4     panel (artifacts already)    2222e054  —         out 3 in 1 0          0      ALIVE daa=26
    .113   misaka-pool-slot@01  pool floor node              2222e054  —         out 3 in 3 0          0      —
    5.104  misaka-t11-seat2     producer class 71bbb755…     2222e054  —         out 3      0          0      ALIVE daa=26

All six hold the same `daa=26 blocks=26` at the same read — a node on another genesis cannot accept these blocks, so
the lockstep is the same-chain proof for the four that generated no inbound rejects. node1's six `Incapable`
receipts in its journal window are stamped 16:49–16:57 UTC — the 5e node1, before the stop — and none since the
refit; no panel on any seat has filed a receipt of any kind since the cut, i.e. no claim block has been adjudicated
yet. The 5.104 `validator-c` unit describes itself as a **testnet-10** validator and stayed down; 5.104's dnsseeder
and miner-c likewise. `.113`'s t11 dnsseeder serves its two anchors; minerpool + pool-slot@01 are up. Watchdogs
(`palw-liveness-watch` on ibm and 5.104) were armed last, after every node's RPC answered. VLT reports `0 validators
with credit` — the overlay had no running validator before the cut either (`misaka-mtp` was not in the pre-cut
census); not a regression, not a claim the announcement may make.

**Cadence, as measured:** 26 blocks in the first 31 minutes (17:17 → 17:48 UTC), the floor seat down for 12 of them
during its refit. Reported as measured; nothing about block time is claimed.

**Faucet** (`misaka-faucet` on ibm): active, `balance_msk: 0.0`, address `misakatest:qgklfukcp0aj…`. Its key has no
premine row by design (5e funded it by a `wallet send` from the producer's pay address); it reports `funded: false`
honestly until the operator funds it on the new chain after coinbase maturity. Not performed by this session.

**Explorer** (`.113`): `kaspa-t11-db-filler` and `kaspa-t11-rest-server` were never in the fleet stop's unit pattern
and kept writing the new chain into 5e's `kaspa_t11` (378 rows, blue 1–299, two lineages). Rotated the way every
previous re-genesis did (`kaspa_t11_old_08e9c8a4_20260903` kept; fresh `kaspa_t11` owner `kaspa`); the filler
starts at the tip when its `vars.vspc_last_start_hash` is empty, so that key was seeded with the genesis on the
fresh DB — it now indexes from block 0 (34 blocks, blue 0–22 at 17:52 UTC). REST answers `misaka-testnet-11`.
Post-cut: add the explorer units to the stop list, and seed-from-genesis to the rotation script.

**CLI** at `/usr/local/bin/misaka` on all three = the cut's (`5fd49aca…`, `misaka 1.1.0`); 5e's kept as
`misaka.5e-af50be7b`. `/root/t11/misaka` had no predecessor. The stale Aug-31 free-prompt gateway on ibm
(`misaka-palw-gateway (deleted)`, `127.0.0.1:8791`) is still running and is not the cut's; step 7's gateway replaces it.

## Step 7 — the announcement: draft, UNPUBLISHED, one sentence per piece of evidence

Each sentence below is tied to the reading that earns it. A sentence whose reading has not happened is marked
`[UNEARNED]` and is not published until it has. Nothing is posted by this session; the operator publishes.

**Earned by steps 1–6 (readings in this card):**
- testnet-11 relaunched on 2026-09-03 17:17 UTC from a new genesis; every earlier chain (`08e9c8a4…`, `8d2002cc…`)
  is retired. Genesis `ad30b5cb965ad305dfa1dc7516935763ea2623105581b83bb9359c7247157d36b0f8003b337cdad366e3895c8f159e99332be16e258b144dddf483bf9b33edb7`,
  consensus fingerprint `2222e054f87bed7a33e9c017f5403cd52070d0778776b5bd78143e7f82ff92b7`. A node on the old
  genesis is refused at handshake (nine community nodes were refused in the first minute): **wipe your appdir and
  run the new binary** (`kaspad` sha256 `14065c93…`, 53,913,240 B; built from `6e01ba07`).
- The genesis premine carries 13 community allocations (648M) and eight bonded seats; every wrapper's outpoints are
  unchanged (`misaka-premine:0–7` bonds, `:41–48` floats).
- Three classes are genesis classes with budget from epoch 0: the floor (BASE-0), the dense A16 tier (v5,
  `4277d84f…`) and Qwen3.6 (`5bd9ae3d…`). The court certified the four families end-to-end in genesis
  (`court_e2e_root e649e7c0…`). Qwen3.6's free-prompt lane is CERTIFIED on chain; the v5 lane's binding is
  `[PENDING — bind object submitted at daa …, read back with `misaka palw certified`]`.
- Six fleet nodes (ibm ×2, `.113` ×3, 5.104 ×1) on the cut, every panel seat holding all three class artifacts;
  the explorer at misakascan indexes the new chain from block 0; the t11 seeder serves the new peers.
- Block production is live; the first hour's blocks are hash-floor blocks (`powAlgoId 3`), 41 in the first 40 minutes,
  with the floor seat down for 12 of them. `[UNEARNED: any statement about block time, or that a model class has
  produced a block — no algo-9 block has been read yet]`
- Cadence, faucet, finality: the faucet is up and **unfunded** until the operator funds it after the first coinbase
  matures. `[UNEARNED: "finality" — no claim has been adjudicated; earned only when `final_claims` reads non-zero]`

**Earned only by step 7's own readings (pipeline on the cut's binaries, ibm):**
- `[GATE]` A free prompt to the dense tier's gateway was answered, committed locally (offline gateway, D5-bound),
  derived to a 3D artifact (STL, `cad/stl/v1`) and to a MIDI file (`music/smf/v1`), each verified
  `binding_checked: true` by `palw-derive verify` on the cut, and each recomputed by the independent stranger
  (`misaka-palw-derive-stranger.py`, links nothing) — with the exact-budget condition stated plainly: today the
  derivation succeeds when the answer fills the decode budget exactly (56 tokens for the STL, 97 for the MIDI);
  the EOG-cut amendment to ADR-0078 is post-cut.
- `[UNEARNED until read on chain]` a free prompt committed ON the public chain and taken to Final — 3e's tip drill
  and 5e's rig are producing that value on devnet; the public chain's first is not claimed here.
- Adding a model: registration is permissionless (ADR-0054) but a class registered mid-epoch has no budget until the
  next epoch boundary — say so, so nobody reads "no blocks" as "refused".

**Never in the announcement:** block time, "finality", "N nodes" beyond the fleet's six, anything about VLT credit.

### 6e — chain-state readings that changed the seats (18:00–18:05 UTC)

`misaka palw certified <class>` against node0, at daa 40:
- QWEN36 `5bd9ae3d…`: **free-prompt lane CERTIFIED** — a commitment on this class enters the state.
- v5 `4277d84f…`: class known; **free-prompt lane uncertified** — `FreePromptCommitted would be refused`. The court
  certified the a16-v5 *family* in genesis; the class→lane binding (ADR-0075 `ClassLaneCertified`) is not in genesis.
- seat2's launcher class `71bbb755…`: **this chain does not know it** — a 5e-era id. seat2 had produced nothing and
  could not. Re-pointed at the v5 class (`c-seat2.sh.pre-5f-v5class` kept), restarted: listening after 343 s, no
  refusal, producer started on `4277d84f…`, ALIVE at daa 53. **A launcher's class id dies with a re-genesis; read
  `palw certified <id>` for every producer class at every relaunch.**
- fp decode rules: `dormant — the pre-ADR-0082 job shape` on this chain (ADR-0082 not armed).

**The v5 lane binding is built and waiting for funds.** `palw-certify bind --artifact bound-candidate.palwart --lane fp`
wrote `ClassLaneCertified` (3,961 B; row `Qwen/Qwen2.5-1.5B/graph-v5@512` MATCHED in the build's registry, 10
kernels covered by the RC family's drill, ladder 52,778,128 leaves inside the 67,108,864 cap, seat window 34 ms/pos).
`misaka palw submit-object` dry run from node0's key: `no mature, unbonded, unspent UTXO at misakatest:qf6hf5v0…` —
the bond is bonded, the float is the panel's, and no coinbase has matured on an hour-old chain. node0, node1 and
seat2 all pay coinbase to that address, so the broadcast becomes fundable when the first coinbase matures
(~daa 110 at the current cadence). Until it lands, free prompts on the public chain are accepted on QWEN36 only.

**Lanes so far:** 59 blocks at daa 57, every one `powAlgoId 3` (`POW_ALGO_ID_BLAKE2B_SHA3`, the hash floor). No
`8` (heartbeat) and no `9` (`PALW_EXEC_V3`, a model class) yet — QWEN36 since 17:24, v5 since 18:03. The explorer's
`transactions_outputs` is still empty (the filler writes outputs on acceptance), so the miner census by address
waits.

### 6f — producer facts from the chain, and a correction (18:10 UTC, daa 65)

`getPalwProducerFacts` over wRPC JSON (`26314`; a 40-line stdlib WebSocket client in `/root/fp-smoke-5f/wrpc.py`,
ibm has no client library), node0:

    class        available  epochBudget  produced  fpCertified  classTarget
    QWEN36       true       489          0         true         208075503442540174204994800459846778879   = 0.61 · u128::MAX
    v5           true       489          0         false        340282366920938463463374607431768211455   = u128::MAX exactly
    bondKnown true · notReadyReason "" · pwu 2,685,360 / 6,630,544 · minTraceRetentionDaa 5400 · fpDecodeRulesArmed false

- The PALW state store is seeded on the cut before any attempt block exists (5e's rig deadlock is rig-specific).
- **5e's finding is confirmed on the cut:** the v5 class's target is `u128::MAX` to the digit — `palw_seed_attempt_targets_v1`
  skips the fused row. Post-cut (a target moves by retarget, not by re-genesis); in the audit list.
- **Correction to 6e:** the heartbeat lane's blocks carry `powAlgoId 3` (`POW_ALGO_ID_BLAKE2B_SHA3`) at the fixed
  `bits 545259519`; the 59 blocks I called "hash-floor" are the five seats' heartbeats (one per ~2 min each; node0
  `heartbeat #15` at 18:06 is block `a43c2194…`, algo 3 in the explorer). No lane has produced an attempt block
  (algo 9): not node1's floor, not QWEN36 since 17:24, not v5 since 18:03. With class targets at 0.61·MAX and MAX
  the class ticket is not the constraint; the Layer-0 digest against `bits` and inference time are.
- **Named expectation, to be read rather than assumed:** 5e's measured rate was 6 QWEN36 + 2 floor blocks in 7 h, so
  zero attempt blocks in 50 min is a ~40% outcome. If no algo-9 block exists by ~20:10 UTC (≈2 h of QWEN36
  production), investigate `produce_one`'s silent `continue` paths (`palw_producer.rs` 383/401/414/461 on the cut)
  before anything else. The announcement does not say a model class produced a block until one is read.

### 7a — the gate, measured on the cut's binaries (ibm, 18:02–18:20 UTC)

Binaries built from `candidate-6e01ba07` on ibm at 19:44–19:55 CEST: `misaka-palw-gateway` sha `bd9c9150…`,
`palw-a16-fp-worker` `a113d351…`, `palw-derive` `c6e6b608…` (the Aug-31 gateway file and the 14:11 workers were NOT
these; `misaka/palw/base0/src/classes.rs` had moved since my Mac smoke tree, so only a rebuild counts). Inputs:
`bound-candidate.palwart` (v5 class `4277d84f…`), tokenizer `/root/palw-class/qwen25-src/tokenizer.json`,
`MISAKA_PALW_NETWORK_ID=testnet-11`; offline `--anchor` form, identity with the v5 class id (no chain, no bond).

    stage 0   stranger selftest on the cut tree (294128ba)           PASSED — 18 checks, agrees with the shipped Rust
    smoke     fp-smoke-v5.py [1]–[6]                                  ALL PASS  (health, chat "2+2 equals 4.", artifact,
                                                                       anti-replay re-ask, SSE + W5, userless refusal)
    cad       derive cad/stl/v1, max_tokens 56                        stop_reason exact_budget · 684 B STL
                artifact_hash 482b23231a42dc5689bb3983…  == the Mac run's (09a71652 build, Apple silicon) — same bytes
                palw-derive verify: consistent | binding_checked: true
                stranger derive: UNIMPLEMENTED — cad op 'extrude' outside its subset (named refusal, not a failure)
    music     derive music/smf/v1, max_tokens 97                      stop_reason exact_budget · 91 B MIDI
                artifact_hash 7a4f0eba065508e098cfccd9…  == the Mac run's
                palw-derive verify: consistent | binding_checked: true
                stranger derive (links nothing, crate-root = the cut checkout, derive/src 4969f8dc…):
                  bytes IDENTICAL to the gateway's (sha256 8a23a44a…), artifact_hash ==, dsl_hash 3f64e301… ==,
                  transformer_id cb5f27b4… (the pinned music transformer)

The stranger's `verify` subcommand refused both with "the chain read says this claim is not on that chain" — correct:
it is stage 10's tool for an on-chain derivation (`--chain` = `misaka palw derived <claim> --json`), and these
commitments are local. The on-chain form is the `[UNEARNED until read on chain]` line of the draft.

**Earned sentences (7):** a free prompt to the dense tier was answered on the cut's binaries, committed locally
(D5-bound), derived to a 3D artifact and to a MIDI file at exact budget, each verified bound by the shipped verifier;
the MIDI was recomputed byte-for-byte by an independent path that links nothing; the STL's bytes are identical across
two builds on two architectures. Condition stated with it: today the derivation succeeds when the answer fills the
decode budget exactly (56 / 97 tokens); the EOG-cut amendment is post-cut.

**Correction to 6f (18:30 UTC, from 5e's reading of `attempt_target_seed_v1`, `palw_class_daa.rs:745`, checked by
recomputation):** the v5 class's `u128::MAX` target is **not** a skipped row. The seed is the documented clamp
`T = MAX · (share_permille · pwu_per_inference) / UNIT`, `UNIT = 2^31`, saturating at MAX when share·pwu ≥ UNIT:
v5 489 × 6,630,544 = 3,242,336,016 ≥ 2,147,483,648 → MAX; QWEN36 489 × 2,685,360 = 1,313,141,040 → 0.611·MAX —
both to the digit of the chain's readings. The heaviest inference rides at the ticket floor by design. Nothing for
the audit; the "skips the fused row" line sent to 3e is withdrawn. The value was right, the mechanism was borrowed
unread — [[send-the-value-with-what-produced-it]] again.

### 7b — the on-chain sentence's reading: the rail cannot fund a claim (3e's drill, 18:40 UTC)

3e's tip drill on the cut's code passed stages 3–5 (V5 `ClassLaneCertified` on 3/3 nodes; `/health` naming all four
chain-side reasons; a chat answered — job `4916876c…`, claim `1bd0e0a7…`) and **failed stage 5b on the shipped path**:

    Rejected transaction f89b61c7…: transaction … is not standard: transaction output #0: non-standard script form

Mechanism (read by 3e in both directions): `misaka/palw/gateway/src/bin/rail.rs:288` builds the funding `UtxoEntry`
with `ScriptPublicKey::default()`; `build_funded_overlay_tx` mirrors that script into the change output →
`ScriptClass::NonStandard` → `check_transaction_standard.rs:156`; and `calc_mldsa87_signature_hash` commits to the
entry's script, so the signature was over the wrong digest — the tx could never have been valid. No drill had reached
a live submit before tonight. Fix is gateway-crate only (the entry's script = `pay_to_address_script(funding_address)`,
plus a named refusal if the derived script is not `is_pq_standard()`); **no consensus, kaspad or validator-core bytes
move, the fingerprint is untouched, the chain does not move.** The rail binary on ibm is rebuilt from 3e's fix commit
before any public on-chain free-prompt claim is attempted, and the card records which sha it came from.

So the announcement's `[PENDING] a free-prompt job committed ON the public chain` line has its reading: unreachable
tonight with the shipped rail; the local (D5-bound) commitments and derivations of 7a stand as stated.

**7b, continued (18:45 UTC).** 3e's fix is `b037cdc2` on `palw-adr0082-impl` (= `7aa3d5ad` the fix + the `Cargo.lock`
follow-up; parent the frozen `4d572142`; files `misaka/palw/gateway/Cargo.toml`, `misaka/palw/gateway/src/bin/rail.rs`,
two `Cargo.lock` lines — verified locally before it was carried anywhere). It closes **two** defects found live, one
behind the other:
1. the empty funding script (above);
2. `transaction has 250000 fees which is under the required amount of 263870` — the rail's flat `--fee` default sat
   under the node's mass-based relay minimum for a commitment whose payload carries the prompt token ids (8,186 B).
   `--fee` is now optional: the rail builds once at the floor, sizes the fee with `estimate_overlay_fee` from the
   probe's payload length, rebuilds at that fee, and prints `fee_sompi`.
With `--fee 300000` by hand, run-1's devnet nodes **accepted the commitment** — `submitted 944fbf1bf7e59a07…`
(claim `1bd0e0a7…`, subnetwork 0x4a) at 18:27:33Z — the first free-prompt commitment a mempool has taken on this
code; the run's stage-6 window closed 60 s later and its cleanup tore the nodes down before a block carried it.
Run 2 launched 18:31:20Z on the fixed rail (unmodified drill script; kaspad/worker/gateway unchanged from the cut);
"carried in a block / Final / receipt" wait for it.

True now, in the card's words: *a free-prompt commitment transaction was accepted by a devnet mempool on the cut's
consensus code (rail fixed post-freeze, tool crate only).* On ibm the series is applied over `candidate-6e01ba07` on
the branch `candidate-6e01ba07+rail-b037cdc2` and `misaka-palw-fp-rail` alone is rebuilt with `--locked`; the sha of
that binary is recorded below when the build lands. The kaspad in service stays `14065c93…`; the fingerprint does not
move.

### 6g — why the model lanes are silent: they are inferring (18:33 UTC)

Two hypotheses were live at 18:20: (a) producer wrappers without `--enable-unsynced-mining` `continue` silently when
`should_mine` is false (node0 and node1 carry the flag; `.113`'s node, the pool slot and seat2 did not; 3e's drill gives
every node the flag and produced a v5 block 3 min after boot); (b) the producers are inside `produce_one`, inferring
slowly on CPU hosts. Genesis `bits` are `0x207fffff` on both t11 and devnet, so Layer-0 does not separate the chains.

Test: seat2 restarted 18:22:27 UTC with the flag added (`c-seat2.sh.pre-5f-unsynced` kept). After its 34 GiB pass
its producer printed **no** "producing anyway" — with the flag present that line prints only when `should_mine` is
false — so `should_mine` was already true (node1 printed it on the empty chain at 17:27 and never after its refit).
**(a) is refuted for this chain.** A 5-second CPU sample of the producer processes:

    seat2  v5 dense (5.104)   ≈ 214 % of one core, 58 threads     8-core VM
    node0  QWEN36  (ibm)      ≈ 194 % of one core, 58 threads     8-core VM
    node1  floor   (ibm)      ≈  87 % of one core, 55 threads

All three are computing. **(b) holds:** 3e's dense job took ~3 min on an Apple-silicon Mac; on these 8-core x86 VMs at
~2 cores of engine work the same job is plausibly tens of minutes, and a QWEN36 job over 33 GiB of mapped weights
likewise. At class target MAX the draw is not the constraint. The named expectation becomes: **the first v5 attempt
block is seat2's first completed inference after 18:28 UTC**; if none exists by 20:10, read the engine's per-job
time on these hosts, not the producer loop. `.113`'s node and the pool slot keep their wrappers; nothing else is
restarted. Post-cut: the per-host inference time of every registered class belongs in the seat runbook, and a
producer should log "job N: started / finished in T s / draw lost|won" at INFO — an hour of silence should not need
a CPU sampler to read.

### 6h — DAA 110, the funding key, the engine's own timing (18:34–18:40 UTC)

- DAA 110 at 18:34:38 UTC: 110 blocks, every one `powAlgoId 3` (heartbeats). No attempt block yet.
- The funding key (node0's, `misakatest:qf6hf5v0…`, also node1's and seat2's pay address) holds **one immature
  coinbase of 2,756.28 MSK** — the merged heartbeat rewards paid in one chain block's coinbase (the heartbeat lane's
  blocks do earn subsidy) — and nothing mature; `submit-object` for the v5 lane binding was refused again at DAA 112
  for exactly that reason. A retry loop on ibm dry-runs each minute and broadcasts when the refusal stops, then
  reads `palw certified 4277d84f…`. The binding is therefore a matter of coinbase maturity, not of a missing subsidy.
- ibm's dense engine, measured from the step-7 pipeline's own work dirs: 56 tokens (147-token prompt) in **172 s**,
  97 tokens (198-token prompt) in **247 s** — about two seconds per token on this 8-core VM. A 512-context producer
  job is minutes to tens of minutes here; 3e's Mac produced v5 blocks 2.8–11 min apart on one producer.

**Rail (7b) — the sha.** Series verified locally (parent `4d572142`; exactly `Cargo.lock`, `misaka/palw/gateway/Cargo.toml`,
`misaka/palw/gateway/src/bin/rail.rs`), carried to ibm as two patches, `git am` over `candidate-6e01ba07` on the branch
`candidate-6e01ba07+rail-b037cdc2` (HEAD `d272eb57`; 3 files, 46+/9−; 0 files under consensus/, kaspad/,
kaspa-pq-validator-core/), `cargo build --release --locked -j 2 -p misaka-palw-gateway --bin misaka-palw-fp-rail` in 3 m 25 s:

    misaka-palw-fp-rail   9,168,384 B   sha256 976de9ceabfc0e81…   built 20:36 CEST from d272eb57
    kaspad (in service)                 sha256 14065c9348a958a1…   unchanged
    misaka-palw-gateway                 sha256 bd9c91500872…       unchanged

No public on-chain free-prompt claim is attempted before the v5 lane binding lands and 3e's run 2 has read 5b–8.

### 6i — Qwen3.6 produced the chain's first attempt blocks; the explorer's lane field is not the header's (19:00 UTC)

**Correction to 6f, 6g, 6h:** every lane census taken from the explorer (`/blocks/<hash>` → `header.powAlgoId`) reported
`3` for **every** block, including the two blocks node0 logged as produced. The REST/filler does not carry the header's
`pow_algo_id`; the field is a constant. "Heartbeat blocks carry algo 3" (6f) was that instrument, not the chain. The
census from node0's own `getBlocks`, paged from the genesis (`/root/fp-smoke-5f/lanes.py`), at 19:00 UTC:

    blocks 157 = genesis (algo 1) + 154 heartbeats (algo 8, POW_ALGO_ID_HEARTBEAT_V1 — as ADR-0066 says) + 2 attempt blocks (algo 6)

    c90b028c…  algo 6  daa 40  blue 26  template ts 17:54:57Z  produced 18:18:31Z  claim e78441c7…   (node0 "produced block #1")
    7e11fa05…  algo 6  daa 80  blue 50  template ts 18:18:31Z  produced 18:43:56Z  claim 5bc8f1cf…   (node0 "produced block #2")

- Algo **6** is `POW_ALGO_ID_PALW_COMMITTED_V2`, the attempt id this ruleset pins (`PalwRulesetV2::validate` pins
  `algorithm_id` at 6; the beacon's fence to `PALW_EXEC_V3 = 9` is not crossed on this network). The producer's own line
  says "class ticket + Layer-0 both under target".
- **Qwen3.6 runs one job every ~25 min on ibm** (execution materials at 18:17:58 and 18:43:42 UTC, 253 MB each) and won
  both draws at its 0.61·MAX ticket. The template is taken at job start ("one template, one inference, one draw"), so a
  25-minute inference lands a block whose parents are 25 min old — `isChainBlock false`, a deep side block, accepted.
- No floor block yet (node1, the pool slot) and no v5 block yet (seat2's first 512-context job had not completed after
  30 min); `[palw-producer] palw weight=0 live_total=0 final_claims=0 unresolved=0 courts=0` after both.

**Adjudication of those two claims:** `.113`'s public node filed `Incapable` receipts for both (18:32:50, 18:33:22,
18:57:07 UTC) — its wrapper listed only the two A16 artifacts, so it cannot resolve the QWEN36 backend. With five
seats, quorum 3 and the executor excluded, node1, seat4 and seat2 must all file capable receipts for a QWEN36 claim
to reach Final; none has yet (their replay of a 33 GiB class takes its own time). `qwen36.palwq36` was added to
`node.sh` (`node.sh.pre-5f-qwen36` kept) and the node restarted. **Every panel seat must hold all three artifacts**
was the rule in 6b; `.113`'s node was the seat it had not been applied to.

The explorer-based watch for a non-heartbeat block cannot fire (the field it reads is constant) and is left to expire.
Post-cut: the filler must store the header's `pow_algo_id`, or the explorer must not show one.

**6i, continued — the two Qwen3.6 blocks were merged red (19:05 UTC, node0's `getBlocks` mergesets):**

    c90b028c…  blue 26, daa 40, 6 children   → in mergeSetRedsHashes of chain block c71b0f1e… (daa 82) and of five side blocks
    7e11fa05…  blue 50, daa 80, 1 child      → in mergeSetRedsHashes of chain block b73f8c14… (daa 127)

A 25-minute inference on a template taken at job start yields parents 25 minutes old; under k=1 the DAG merges such a
block red — the case the ADR-0058 note names ("a slow class is structurally red"). The state nonetheless counts them:
`epochProducedBlocks 2` of budget 489, `bondReservedExposure 26,853,600 = 2 × 13,427,200` — ADR-0058's merged work
counted, as written. Whether a red block's claim is adjudicated is a reading not yet taken: node1, seat4 and seat2
(capable) have filed nothing for either claim; `.113`'s node filed Incapable (refitted). `live_total=0` in node0's own
state line after both. Post-cut, for the seat runbook and the ADR: on CPU-class hosts every attempt block of a model
class will be red by construction; the announcement says "produced and merged as red blocks", not "chain blocks".

**6i, continued — `.113` refitted (19:05:52 UTC):** `node.sh` now carries `qwen36.palwq36` + both A16 artifacts
(`node.sh.pre-5f-qwen36` kept); listening after 229 s, fingerprint `2222e054…`, Qwen3.6 mapped, connected to node0,
node1, seat4 and the pool slot, 0 panics, ALIVE; rss 8.2 GB with 5 GB free on the host (seat4 + node + pool share the
33 GiB file through the page cache). Every panel seat now holds all three class artifacts.

**6i, continued — the instrument for "is a red claim live?" (19:08 UTC, 3e's reading of `palw_producer.rs:466/477`):**
the producer's `palw weight=… live_total=… final_claims=… unresolved=…` line prints the `PalwProducerFactsV2` computed
**before** the attempt — the state at the job's start, the template's point of view — so `live_total=0` after both
blocks says only that neither block was in the other's past when its job started (job #2's template was taken
18:18:31Z, the second block #1 was produced). It says nothing about red. `getPalwProducerFacts` over the wire maps a
subset of the internal facts (no `liveTotal`, `unresolvedClaims`, `finalClaims`, `safeWeight` keys), so the reading
is the facts line at node0's **next** produced block: job #3 began 18:44Z, after #1 was merged red at daa 82 and
before #2 was merged at daa 127. `unresolved=1, live_total>0` → red claims are live and the seats' silence is replay
speed; `unresolved=1, live_total=0` → a maturity condition the reds have not met; `unresolved=0` → the fold did not
admit it (though `bondReservedExposure = 2 × 13,427,200` says the carriage reserved for both). A watch is on that line.
Reference from 3e's drill (blue claims, v5): `live_total` +663,054 per claim one job later, `unresolved 15` after #9,
`final_claims 0` throughout run 1 — Final needs receipts + quorum + ReceiptLicensed, run 2's stage 6.

**Post-cut list additions:** expose `liveTotal` / `unresolvedClaims` / `finalClaims` / `safeWeight` in
`GetPalwProducerFactsResponse` (the operator's only liveness view without a log); the explorer's filler must store the
header's `pow_algo_id` or the REST must not show one; the producer should log job start/finish/draw at INFO; the seat
runbook carries per-host inference time for every registered class.

**`.113` after the refit (19:10 UTC):** 17.4 GB used of 24 GB, 6.6 GB available, 99 MB of swap touched, 0 OOM kills
in the kernel log; `misaka-t11-node` 8.6 GB resident, `misaka-t11-seat4` 10.4 GB (both map the 33 GiB Qwen3.6 file;
the page cache is shared), pool slot small. Tight but stable; `.113` has no liveness watchdog — post-cut: give the
public entry the same `palw-liveness-watch` as ibm and 5.104, and read its memory before adding any further mapping.

**7b, continued — run 2 on the fixed rail (3e, 19:14 UTC):** stages 1–5 OK (3 blocks; genesis class `4277d84f…`;
V5 family + `ClassLaneCertified` on 3/3; `/health`; job `56b67039…`, claim `a4257df4…`), and **5b OK: "commitment
submitted in tx f8653448…"** with no operator flags — `fee_sompi 329837` auto-sized from the 8,186-byte payload
(run 1's node minimum was 263,870; the estimator's 25 % margin), `pwu 1657636`, `quanta 2`. So the on-chain sentence's
first half is earned on the shipped path **on devnet**: a free-prompt commitment built, signed and accepted by a
mempool on the cut's consensus code (rail fixed post-freeze, tool crate only). Stage 6 (FreePromptCommitted →
PanelBound → ReceiptLicensed → Final on every node), 7 (a receipt block) and 8 (the artifact derived from the claim's
own answer) follow as they land. The public chain's own claim still waits for the v5 lane binding.

### 6j — DNS seeds after the cut (21:15 UTC, asked by the operator)

testnet-11's shipped seed list is `seeder1–4.misakascan.com` (`params.rs:8139`, outside `consensus_params_id`; the
bare `TESTNET11_PARAMS` carries none). The parent zone at xdomain delegates each name to its own host:

    seeder1.misakascan.com → ns-seeder1 = 169.58.232.113   .113's misaka-dnsseeder: active since 17:30 UTC, backed by the cut node
                                                          (--node-wrpc-borsh 127.0.0.1:26313, --anchors-only), answers 169.58.232.113 169.58.39.220   OK
    seeder2.misakascan.com → ns-seeder2 = 217.76.57.217    port 53 closed → SERVFAIL                                                              DEAD
    seeder3.misakascan.com → ns-seeder3 = 95.111.236.186   a seeder outside the fleet (the game host; 53 open, no node on 26311),
                                                          answers the same two anchors                                                            OK
    seeder4.misakascan.com → ns-seeder4 = 217.178.101.111  port 53 closed → SERVFAIL                                                              DEAD

`node doctor` on node0 confirms: "Seeder-advertised peers 2 (169.58.232.113, 169.58.39.220)". A joiner resolves the
new chain's anchors from seeder1/seeder3 and waits out two SERVFAILs; the fleet's own nodes use `--nodnsseed
--addpeer`. The seeder daemon verifies nothing about the chain itself — it relays its backing node's `is_synced` and
the configured anchors — so its Aug-31 binary (not part of the cut's build; `misaka-dnsseeder` is not in the release
targets) is not a correctness question. ibm runs no seeder (port 53 is systemd-resolved); 5.104's unit is testnet-10's
(`--network-id testnet-10`, anchors 160.16.131.119 / 95.111.236.186) and stays down. `seeder1–3.misakachain.com`
(mainnet's and testnet-10's lists) resolve to `85.131.213.182` — the registrar's wildcard A record → the web host,
not a seeder; irrelevant to testnet-11, stale for the others. The seeder on `.113` was in the stop list and was
restarted in step 6 with the fleet.

Only the operator can change: the two dead delegations (repoint `ns-seeder2`/`ns-seeder4` at xdomain to live
seeders — e.g. a testnet-11 seeder on 5.104 backed by seat2's borsh 26313, which this session can set up on request)
and the misakachain.com wildcard.

### 6k — the dense tier produces, and its blocks do not enter the fleet's DAG (21:35 UTC)

seat2 (5.104, v5 `4277d84f…`, bond 2) has produced four attempt blocks — `48c19d67…` 19:19:53Z, `134dd1fb…`
20:25:20Z, `4b303400…` 20:58:11Z, `21bf34e4…` 21:31:23Z (~33 min per 512-context job at ~2 cores) — and its own
state counts them (`unresolved` 2 → 3 → 5 → 6, `live_total` 537,072 → 2,794,770 at successive job starts). node0's
state holds **none**: `getPalwProducerFacts` for bond 2 reads `epochProducedBlocks 0, bondReservedExposure 0`;
node0's `getBlock` cannot find the hashes; node0's and `.113`'s logs never mention them. Every seat2 production
coincides with 120-second flow timeouts on **both** sides — seat2's `HandleRelayInvsFlow` / `SendPingsFlow` to
node0, node1, seat4 and the pool, and the fleet's `SendPingsFlow` to 5.104 — followed by reconnects. QWEN36's blocks
from node0 propagate normally (seat2 counts them). So the dense tier's blocks are made and are not accepted by the
peers, and the explorer's "few LLM blocks" is this, not a slow class. Open, code-side: what a receiving peer does
synchronously when a v5 attempt block arrives (validation of its commitment, or the panel's receipt on the claim)
that exceeds the 120 s flow budget on inference-loaded hosts; 3e's devnet run 2 (three dense producers on one Mac)
did not show it. With 3e.

**6k, continued (21:50 UTC).** Bounds on the stall: seat2's 748 MB retention material is written ~9 s *before* its
produced-block line (mtimes 21:19:46 / 22:25:11 / 22:58:02 / 23:31:11 local vs blocks at :53 / :20 / :11 / :23), so the
write is not the stall; seat2's heartbeats continue through each window (#68 23:00:02, #69 23:01:38 local), so its
runtime is not stalled; node0 accepts other peers' relay blocks and mines heartbeats through the same window. The
stall is per-connection and symmetric. 6a's loopback devnet (three kaspads, two v5 producers, the same cut and rail,
the same ~750 MB material per job): run 1 19/19 and run 3 13/13 v5 blocks accepted by the third node within
seconds. So neither v5 validation nor the block's own bytes; **what moves with a v5 block over a real link inside the
120 s flow window** — the material/close serving path (ADR-0082 flat close, 748 MB per v5 job against QWEN36's
smaller material) pulled through the same connection the relay flows share; the 2026-08-28 gossip-cap incident
(`PALW_MATERIAL_MAX_BYTES` 8 → 16 MiB) was the previous member of this family. A sampler on 5.104 records TX/RX
bytes per 15 s across its next production to see whether a multi-hundred-MB transfer starts at the block.
3e's and 5e's sessions are gone; the code read is with 6a. Seat table for the explorer (bond → seat): 0 node0,
1 node1, 2 seat2, 6 .113 node, seat4 bond 4, pool slot bond .

### 6l — the mechanism, read in code by 6a; and the seats' "Unavailable" (21:45 UTC)

`kaspad/src/palw_producer.rs:734–736`: after the draw wins the producer calls `broadcast_palw_material(message,
material)` and only then sets the header and submits the block. `protocol/flows/src/flow_context.rs:686–696` builds one
`PalwTraceMaterialBroadcast` with the **whole** material and `hub().broadcast(msg, None)` — no size check on the push
path; the receiver's `admit_material` (`palw_gossip.rs:619`) refuses `> PALW_MATERIAL_MAX_BYTES` (16 MiB) only after
the message has arrived (gRPC decode cap 1 GiB). On 6a's loopback devnet that step is a constant 35 s (produced →
peers' "Accepted … via relay", nothing logged in between); on seat2's links (RTT 250–356 ms, cwnd 2–4, retransmits on
every peer socket) 748 MB × five peers does not finish in 120 s, `SendPingsFlow` on both ends and the peer's
`HandleRelayInvsFlow` time out, the routers are torn down, and the block — announced once, queued behind the
material — is gone. The same floods explain seat2's lag (daa 316 against the fleet's 410 at 21:39 UTC): its links
die and re-form around every production. QWEN36's blocks cross because ibm's DC links carry its 253 MB material to
the near peers before the window closes (the 5.104 leg still times out, which is the `SendPingsFlow` node0 logs).

**Second consequence, already visible:** the serve path refuses > 16 MiB too ("never serve what the transport would
refuse"), so no seat can obtain a 253 MB QWEN36 material or a 748 MB v5 material by gossip. At 21:34 UTC node1 and
`.113`'s node filed **"Unavailable"** receipts for QWEN36's first claim `e78441c7…` (the half-window); node1's other
8 receipts are the pre-cut Incapables. **No model-class claim can reach Final on this network with the shipped
transport cap**, and the window's end defaults the producer — whether that default slashes collateral is read
below and decides whether node0's production is paused tonight. Fix, post-cut and consensus-inert: cap at broadcast
(skip + warn above `PALW_MATERIAL_MAX_BYTES`) and submit the block before broadcasting; and verification of
attempt-lane claims riding the ADR-0077 interval lane (`IntervalOpening`, size-bounded) rather than whole material —
the "one ceiling, two units" instance (748 MB per 512-context job against a 16 MiB transport cap; 2026-08-28's
8 → 16 MiB was the previous member).

### 6m — what an Unavailable quorum does on testnet-11, and the decision (22:00 UTC)

The seat's attempt-lane verdict (`kaspad/src/palw_panel.rs:2405–2735`, read by 6a) uses only whole materials from
`PalwGossipEvent::Material` and the signed pull; the free-prompt arm alone rides the ADR-0077 interval lane. Both push
and serve refuse > `PALW_MATERIAL_MAX_BYTES` = 16 MiB; the floor's material is 2.27 MB (unaffected), QWEN36's 253 MB and
v5's 748 MB never arrive. So every LLM attempt claim on this chain reaches its half-window as Unavailable × quorum.

ADR-0065 D4 — "an Unavailable receipt stops convicting the producer" — is a top-level fence
(`palw_unavailable_abstains`) that is **`None` on every shipped preset** ("byte-identical to not having the
field at all", pinned by a test); its doc names exactly this failure ("a seat cannot distinguish a producer that
withheld from a fetch that was lost … on testnet-11 roughly a third of every remote seat's verdicts were the second
wearing the first's clothes"). Unarmed, the state's `ProducerDefaulted` arm is live: `slash_dissenting_seats`,
`slash_silent_seats`, then `void_and_slash(ProducerWithholding)`, which takes `claim.reserved` from the producer's bond:

    QWEN36  reserved 13,427,200 sompi = 0.134 MSK per claim      v5  33,152,720 sompi = 0.332 MSK per claim      collateral 10,000 MSK

Economically small on a testnet; structurally an honest producer convicted for the transport's failure. The three
QWEN36 claims already open (18:18Z, 18:43Z, 20:06Z) default on the clock whatever happens now.

**Decision (fleet side, reversible):** seat2's v5 *production* is paused as soon as the 5.104 sampler has captured one
burst (its blocks never enter the DAG and each production floods its links); its panel and heartbeat stay. node0's
QWEN36 production is the operator's call — its blocks do propagate and are the chain's only visible LLM work, at
0.134 MSK of defaulted reserve per claim until the transport is fixed — and is left running until they decide.
**Post-cut, both consensus-inert in the sense the ADRs use:** (a) cap at broadcast + submit the block before the
material, or chunk/interval the attempt-lane material as the FP lane already does; a cap sized to the largest
registered class as the 2026-08-28 fix intended; (b) arm ADR-0065 D4 by activation on testnet-11 — a top-level fence
normalised in `consensus_identity_id`, so it does not move the fingerprint — so that Unavailable abstains and the claim
voids by `ReceiptTimeout` with nobody slashed. Until (a), no LLM claim can reach Final on the public chain; the
announcement already says finality is not claimed.

**6m, continued — seat2's link (22:25 UTC).** seat2 is not in IBD and has no orphans; in 40 minutes it accepted 24
blocks by relay against ~68 the fleet produced, its sink's past-median age is 1,950 s, and every peer socket reads
cwnd 2–4 at 250–356 ms RTT with retransmits — about 10 KB/s per connection. The lag (daa 335 vs the fleet's 489)
is the link, not the DAG: either the four never-completed 748 MB broadcasts still occupy the transport, or the path
is lossy on its own; a sysfs byte sampler is measuring the steady rate (the first sampler read `/proc/net/dev` with a
field match that fails once a counter grows past the column width — `eth0:123…` with no space — and printed
`rx +0 tx +0` for 45 minutes on a live node; the memory note on tools that report an absence they cannot see has it).
6a's exposure correction: `palw_exposure_pwu_v1` reserves one inference's pwu (7,708 for the floor → 38,540 sompi
per floor claim until Final); the chain's bond minimum is 400,000 sompi, the pool's 10 MSK ask is the pool's policy.

**7b, continued — run 4 (6a, 22:06Z): the devnet's "carried in a block" is measured.** On `b037cdc2`'s rail with the
script unmodified: 5b OK (`submitted a02a3334…`, claim `b557bce8…`, fee 329,837 auto-sized), then **block
`e7a1c9c7…` carried it — every drill node logs "PALW lifecycle carried 1× FreePromptCommitted"** (node-0 07:16:39,
node-1 07:17:39, node-2 07:17:37 JST), and node-0's panel logged "recovered funding at a02a3334…:0" — the state
seeing the same transaction. The drill printed "NOT on every node" because its stage-6 regex wants the claim id and
the kind on one line while the node's lifecycle line names the block and the kind — a check shaped to agree with its
doc (the memory note by that name), which could never pass; 6a is fixing the script and re-running for PanelBound →
ReceiptLicensed → Final → receipt → derived artifact. Card wording: "a free-prompt commitment was built, accepted
and carried in a block on the cut's consensus code (devnet)"; "Final / receipt / derived from the chain" are the
next run's.

**6m, continued — the pause executed (22:28 UTC).** seat2's fifth production was an hour overdue and the sysfs
sampler read its total traffic under ~70 KB/s (no stuck broadcast saturating the uplink; the path itself is slow and
lossy). `c-seat2.sh` lost `--palw-produce` and `--palw-producer-class` (`c-seat2.sh.pre-5f-pause` kept), keeping
`--palw-panel`, the three artifacts and the heartbeat address; restarted. Reversible in one line when the transport
carries 5f-sized materials.

**6m — correction (22:40 UTC): nobody is slashed on the shipped path.** `ProducerDefaulted` is constructed only in
test regions across the tree (`palw_state_v2.rs` 11860…, `palw_panel_da_v1.rs` 497/561, `processor.rs` 5658); the
node names it only as a label (`palw_panel.rs:3230`) and neither `palw-certify` nor the CLI builds it. So the
`void_and_slash` arm read in 6m is reachable only by an operator hand-submitting that object with an Unavailable
quorum — nothing shipped does. What the state does by itself at a claim's receipt deadline
(`palw_state_v2.rs:8015–8030`): not yet rebound → one redraw (revived Provisional, a fresh bind deadline); already
rebound → `slash_silent_seats` — which on the cut is a ten-line no-op whose doc says "an economics gap, not a missing
slash, deliberately not repaired here" (`a_v2_panel_seat_is_never_paid` pins it) — then `void_claim(ReceiptTimeout)`,
whose doc says "the hold is a DELAY, never a confiscation": immature weight and the reserve are released. So an LLM
claim with Unavailable receipts on this chain **voids after one redraw (bind 600 + receipt 600 DAA per pass) and
slashes nobody**; the "0.134 MSK per claim" line above is withdrawn as a shipped-path consequence. node0's continued
QWEN36 production costs its bond nothing; it produces claims that cannot be verified until the transport fix, and
that is the honest description. The pause of seat2's production stands on its own grounds (its blocks never enter
the DAG; its link cannot carry the broadcasts).

**7b, continued — run 5 (6a):** stage 6 fixed as `ee252944` (polls `misaka palw derived --json` per node and walks
`phase` provisional → panel_bound → receipt_licensed → final). The RC windows bound what any session can prove on
the devnet preset (bind 600, receipt 600, challenge 1,200 DAA; one DAA per ~2.5-min dense block): PanelBound ~50 min
after acceptance, ReceiptLicensed inside ~2 days, Final after ~4 — "carried" (run 4) and "panel bound" are what a
session measures; the rest it watches. Run 5 is recording the panel binding.

**6m, continued — the pause's result (22:39 UTC).** `systemctl restart` at 22:26:33 UTC: the old process ignored
SIGTERM for the whole 180 s stop timeout (mid-inference; systemd reports a 22.6 GB memory peak and 903 MB of swap over
its 7 h 17 min of CPU) and was SIGKILLed at 22:29:33; the new process listened at 22:36:49 after its 433 s artifact
pass. Its current boot carries **no `[palw-producer]` line** (production is off), the panel and the heartbeat lane
started, fingerprint `2222e054…`, and **zero flow errors since** — the first quiet stretch on its links since 19:19.
What the pause does not repair: seat2's DAA is 338 against the fleet's 512 with a fresh sink (past-median age 237 s);
it missed ~170 blocks while its links died and re-formed, and because its sink stays recent no IBD is triggered —
it back-fills one orphan's parent at a time (3 orphaned, 2 unorphaned in nine minutes). Its panel cannot obtain LLM
materials in any case (16 MiB), so as a seat it contributes heartbeats and floor-claim duty until the transport fix;
post-cut: a node whose DAA lags its peers by more than the DAA window while its sink is fresh should IBD anyway.

**6m, continued — seat2's link baseline, and a correction of the sampler note (23:10 UTC).** The sysfs sampler over
22:23–23:08 UTC (spanning the restart and the artifact pass): **1 MB received, 2 MB sent in 45 minutes**, no
15-second interval above 3 MB, no production in the window — so no 748 MB burst was captured, and nothing floods the
link; the mechanism stands on 6a's code read (`broadcast_palw_material` before `submit`) and the loopback timing
(35 s constant). The earlier line calling the first sampler an instrument error is withdrawn: `/proc/net/dev` on
5.104 has its space after `eth0:` and `awk` split it correctly; its zeros were true (under 1 MB per 15 s) and its
"0 MB total" was integer division of ~1 MB over 45 minutes. The constant `flow-timeouts=16` in both samplers was a
string comparison of times across the local-midnight rollover, not a parse failure. On a link that moves kilobytes
per second a 748 MB broadcast would take hours, which is the same conclusion by a different arithmetic.

### 6n — node0 stalled by memory pressure on ibm; node1 loses its Qwen3.6 mapping (23:12 UTC)

node0 produced nothing after block #3 (20:06 UTC) for three hours against a ~25-minute job cadence; its third
material is the last (18:17 / 18:43 / 20:06 UTC, 241 MB each). Not the transport: 30 KB sent toward 5.104, cwnd 10,
no send queue. The host: **24 GB total, 541 MB free, 8.2 GB of swap in use**; node1 12.9 GB resident (it maps the
same 33.99 GiB Qwen3.6 file since its 17:30 refit and touches it while trying to verify claims it can never obtain
materials for), node0 9.2 GB; node0's CPU fell from ~194 % to 96 % of one core — its inference working set is being
paged. So the seat-artifact rule (6b) and the producer compete for one 24 GB host, and until the transport carries
5f-sized materials the panel side of that trade is worth nothing. **Action (fleet, reversible):** node1's launcher
drops `qwen36.palwq36` (`ibm-node1.sh.pre-5f-noqwen36` kept), keeps the two A16 artifacts, the floor producer and
the panel; restarted. Expected: swap drains, node0 returns to ~2 cores and a fourth block within the hour. Post-cut:
one 24 GB host cannot carry a Qwen3.6 producer and a Qwen3.6-capable panel seat together; the seat runbook says so.

**6n, continued (23:40 UTC).** A second contributor, found and removed by 6a: the explorer's `llm-jobs.json` cron on
ibm (`/root/llm-jobs-publish.sh`, every two minutes) read the three 253 MB retention materials into memory on every
run — a swap event every two minutes — and stalled each run on a dead `rsync` to 160.16.131.119; it now runs with
`--retention /root/palw-class/retention-empty`, publishes 3 rows, and any text column is derived off-host. Right
after node1's restart the host read 13.9 GB free, 15.5 GB available, swap 4.2 GB and draining. Two mappings of a
33.99 GiB file plus a two-minute 760 MB read on a 24 GB host was the whole of the pressure.

**6n, continued — node1 back (23:15 UTC):** stop completed in 103 s this time; listener up; the two A16 artifacts
only. At +30 s: node1 9.9 GB resident (the first artifact pass touches its files; expected to settle), host 3.1 GB
free / 5.4 GB available, swap 4.2 GB and draining, node0 at 103 % of one core. A twelve-minute deferred read follows
for node0's recovery (target: ~2 cores, a fourth material and block).

**6n, continued — recovery, partial (23:28 UTC):** host 14.0 GB used / 10.0 GB available, swap 3.8 GB (down from
8.2); node0 130 % of one core (from 96 %), 11.4 GB resident with **3.7 GB still swapped** — its fourth job continues
and will finish as its working set pages back; node1 11.2 GB resident with the two A16 artifacts only, no swap,
floor producer at 0 blocks. Fleet daa 592: the first coinbase matures near 00:15 UTC; the first QWEN36 claim's
receipt deadline (daa 640) falls near 23:52 — its redraw is readable in node0's next facts line.

**6n, continued (00:09 UTC, 2026-09-04):** host 13.6 GB used / 10.4 GB available, swap 4.05 GB and no longer draining
(node0's 3.8 GB swapped pages are not being touched); node0 117 % of one core, 9.1 GB resident, still on the job it
began after block #3 — three materials, three blocks, four hours into the fourth job; node1 **13.0 GB resident** with
the two A16 artifacts only (9.9 → 11.2 → 13.0 GB in 55 min) — a deferred read compares anon against file-backed
pages to tell growth from a settled mapping. Fleet daa 653: the first QWEN36 claim's receipt deadline (640) has
passed — its redraw is readable in node0's next facts line; the first coinbase matures at 686 (~00:25 UTC).

### 7c — the v5 lane binding: broadcast, carried, and dropped by the chain's grading (00:32–00:52 UTC, 2026-09-04)

The first coinbase at bond-0's address matured at daa 686 (settlement window 600 over the coinbase at daa 86); the
retry loop's dry run passed at 00:32:24 UTC and the `ClassLaneCertified` object was broadcast as carrier `bc6637d3…`,
funded from `c41e45ea…:0`. The explorer shows the carrier accepted in block `478bbcbf…` (00:35 UTC). node0's log at
that block:

    a PALW lifecycle object was dropped, and the block stands: no family certified on this chain for the free-prompt
    lane covers every kernel class 4277d84f…

So the object was carried and refused by the grading it asked for: the genesis carries the a16-v5 family's *court*
(attempt-lane) certification (`court_e2e_root e649e7c0…`), not a free-prompt-lane `FamilyCertified`; the drill's stage
3 submits that family object before the bind (3e's minimal-cover V5 family, two carriers), and on the public chain it
was never submitted. Order now: `palw-certify drill --family a16-v5 --lane fp` (the shipped court grades the family's
vectors and writes the chunked object), `misaka palw submit-object` with its carriers, then the bind again; each is a
spend from bond-0, so the key stays reserved. The lane reads uncertified at daa 717; bond-0 holds one mature UTXO
(2,756 MSK change) and three immature.

**ibm at 00:52 UTC:** used 15.4 GB / available 8.7 GB, swap 4.5 GB; node0 9.1 GB resident, still on its fourth job
(three materials); node1 12.6 GB resident of which **12.5 GB anonymous** — a heap, not the A16 mappings — to be
compared over time and restarted if the host's available memory falls under ~4 GB.

**7c, continued (01:00 UTC).** `palw-certify drill --family a16-v5 --lane fp` on ibm: exit 0 in 2 s, `FamilyCertified`
free-prompt lane, family `5c22b8d0…`, 14 fault vectors, 198,754 B → two carriers (100,071 + 98,825 B, group
`63ae283e…`). A chained job submits the two chunks from bond-0, waits for the grading line at the completing block,
then re-submits the bind and reads the lane. 6a's session ended before the result; the bond-0 reservation was relayed
to the two successor sessions (`misaka-testnet-e1`, `-ff`) so no wallet send races the carriers.

## Step 8 — verification pass before the push to main (00:59 UTC, 2026-09-04)

    host   unit               role              fp        genesis   panic  liveness
    ibm    misaka-t11-node0   QWEN36 producer   2222e054  ad30b5cb  0      ALIVE daa=729
    ibm    misaka-t11-node1   floor + panel     2222e054  (handshakes)  0  ALIVE daa=729
    .113   misaka-t11-node    public + panel    2222e054  ad30b5cb  0      ALIVE daa=729
    .113   misaka-t11-seat4   panel             2222e054  (handshakes)  0  ALIVE daa=729
    5.104  misaka-t11-seat2   panel (paused)    2222e054  (handshakes)  0  ALIVE daa=400, catching up
    explorer misaka-testnet-11 at 729 (db 733 rows from blue 0) · seeder answers 169.58.232.113 169.58.39.220, publicly too
    pool active · faucet active, grant 12, balance 0 (operator funds it) · QWEN36 3 blocks · kaspad sha 14065c93 on all hosts
    ibm 9 GB available / swap 4.5 GB · .113 10 GB available

Normal: the chain, the six-node fleet on the cut, discovery, the explorer, the gate (7a). Known and documented, not
blockers to publishing the code that runs: the dense tier's blocks do not cross real links and LLM claims cannot be
verified by the seats until the material transport carries 5f-sized materials (6k–6m, post-cut code); the v5
free-prompt lane binding is being carried now (7c). **What goes to `main`:** `palw-testnet-5f` — the cut `6e01ba07`
(the kaspad every host runs), the card and the announcement draft, the fleet-script fixes, and five verified tool
commits cherry-picked from `palw-adr0082-impl` (the rail pair `7aa3d5ad`/`b037cdc2`, built on ibm and proven on
devnet runs 4–5; the exporter's class ids `1b2bff36`, in service on ibm; the drill's stage-6 fix `ee252944`/`0e175f9b`).
Left on its branch: `f1604dd3` (kaspad's default pay address — not what the fleet runs). The push is a fast-forward
(`origin/main` `dcbfe361` is an ancestor; 0 commits behind) and carries the tag `testnet-11-relaunch-5f` at `6e01ba07`.

**7c, continued (01:02 UTC).** The family's two carriers (`3631d02c…`, `e62e7cb0…`, funded in chain from the
dropped bind's change) were accepted, and block `f9af403c…` at 00:59:01 UTC logs "PALW lifecycle carried 1×
FamilyCertified" with no drop line — the a16-v5 family is free-prompt-lane certified on the public chain. The bind
was re-broadcast as carrier `bf3e37fc…` (funded from `e62e7cb0…:0`); the lane flips in the block that carries it.

**7c — closed (01:03 UTC, 2026-09-04): the v5 free-prompt lane is CERTIFIED on the public chain.** Block `5e265a6e…`
at 01:03:12 UTC (and `6e461441…` nine seconds later) log "PALW lifecycle carried 1× ClassLaneCertified"; `misaka palw
certified 4277d84f…` reads *CERTIFIED — a commitment on this class enters the state*. Sequence on chain: fp-lane
`FamilyCertified` for the a16-v5 family (`f9af403c…`, 00:59 UTC) → `ClassLaneCertified` (`5e265a6e…`). Three carriers
from bond-0, fee-sized, chained from one matured coinbase; the key now holds two mature UTXOs (5,512 MSK) and is
free for the operator's funding of the faucet and the pool slot. The announcement's pending line for the lane is
resolved; the on-chain free-prompt claim itself (gateway identity for this chain + the rebuilt rail) remains the
next step, not claimed.

**Step 8 — pushed.** `palw-testnet-5f` → `origin/main` as a fast-forward from `dcbfe361`, with the tag
`testnet-11-relaunch-5f` at the deployed cut `6e01ba07`; the sha below is main's head after the push.

**Step 8 — verified on GitHub (01:07 UTC):** `git ls-remote origin refs/heads/main` → `efbef639`; the tag's peeled
commit → `6e01ba07`. https://github.com/MISAKA-BTC/misakas/commit/efbef639d9d2c5453c126e3e0f6002a930dea853 ·
https://github.com/MISAKA-BTC/misakas/releases/tag/testnet-11-relaunch-5f. (A plain `git fetch` in this repo does
not move `origin/main` — its fetch refspec is a single tag, the memory note's trap — hence `ls-remote`.)

**7c — what the open lane holds (e1, 01:15 UTC):** the v5 512 row is the class wide enough for the grammar floors —
cad/v1 38, music/v1 60, scene/v1 104 decode tokens after the 134-token prompt — which the n_ctx-16 graph-v2 row never
was; that is why certifying this lane, not the older A16 row, is the practical-output capability. e1's devnet rig is
stopped for good with its ledger stated: the static port matching impl, four floor-only drill runs (register →
certify → serve → budget gate), the sentinel-guard fix `0f12727a`, and two shapes handed to the integrators (the
`load_tip(...).ok()` silent swallow; a genesis state written under one ladder and read back under another fails
silently). Its last hypothesis — that the 2^32/2^26 ladder divergence explained the v5 registration's Decision F
mismatch — was refuted by test (`9c853d31`: numbers unmoved), leaving the mismatch on the engine's recording side.

## Step 9 — a free-prompt job on the public chain (01:09 UTC onward, 2026-09-04)

**Faucet funded (ff, 01:05 UTC):** 2,000 tMSK from bond-0's matured coinbase by `wallet send --coinbase-only`
(tx `316edbd4…`); `/faucet/v1/status` reads funded, grant 12, and a Studio pool slot (slot-02 on `.113`) took the
first grant (`bc2a3daf…`). The operator's remaining money call is only whether to add more later.

**The gateway, online on the public chain:** the Aug-31 leftover on `:8791` stopped; sibling directories
`/root/fp-5f/{identity,outbox,work}`; identity built the drill's way — `network_domain` = blake2b-512 keyed
`misaka-palw/attempt-v2/network-domain/v1` over `u64le(len) ‖ "testnet-11" ‖ genesis` (`d8ef6446…`), class
`4277d84f…`, bond `misaka-premine:0`, `executor_pubkey` from the rail's `--print-bond-pubkey` (2,592 B) **equal to the
chain's registered pubkey for bond 0**, `operator_id` the chain's own (`0f00d433…`). The worker's manifest on
`bound-candidate.palwart`: `shape_profile_id 4277d84f…` = the certified class, `model_profile_id 158314b5…`,
`tokenizer_id fa9a4352…`, n_ctx 512. Started as a transient unit (`fp-gateway-5f`) with `--rpc 127.0.0.1:26313`
(node0's borsh), `--derive-seed` the hex key file, worker stderr logged; resident after 27 s. `/health`:

    chain rpc ws://127.0.0.1:26313 | registered true | fp_certified true | bond_active true | exposure_room 499,959,719,600
    can_submit true · commit_refusal none · anchor_daa 745 · n_ctx 512 · template chat-segments/v1 · one job slot, 8 may queue

e1's seven traps (network-domain preimage with `testnet-11`, sibling dirs, hex seed files, the worker env allowlist,
worker stderr, the rail's auto-sized fee, the manifest's shape id) were followed in order; none bit.
First request: the cad exemplar prompt at max_tokens 56 with `derive: cad/stl/v1`, temperature 0.

**Step 9, job #1 (01:11–01:13 UTC):** answered in 102 s (prefill 116, decode 56/56, 18,679,264 leaves, exec root
`08e426e8…`), **committed** locally under the public chain's identity — job `259d032b…`, claim `6e5b3c91…`, output
root `895061f8…`, trace root `3a6055a4…` — and its **derivation refused**: the answer came back as a fenced,
pretty-printed JSON (` ```json\n{\n  "v": 1, …`) cut mid-object at the budget, whereas the derivable runs of 7a had
produced the compact one-line DSL. The difference is the derive script's `nofence` prefix ("Output the raw JSON only.
Do not use Markdown, code fences or backticks."), omitted from this request by hand. Job #2 re-sends the exact
construction; the on-chain carriage goes to the job whose derivation succeeds, since every commitment reserves
exposure and pays a fee. Not submitted to the chain.

**Step 9, jobs #2 and #3 (01:14–01:20 UTC) — two more of the drill's documented traps, hit and named.** Job #2
(with the `nofence` prefix) answered `{"v":1,"sketch":"box","extrude":{"z0":0,"z1":5}}}` and its derivation refused
with its own reason — `grammar: json: trailing characters at line 1 column 49` — because the prompt was still 14
tokens short of the derive script's: the sentence "You output only one JSON object in this exact DSL and nothing
else." between the prefix and the example. And the gateway had been started **without `--class-leaves`**, which the
gateway and the rail each default to the floor's 7,708 (the e2e drill's own comment: "a drill that omitted it
priced a dense class's quanta as the floor's — in two places"); the class's canonical job is
`PalwPwuRuleV2::canonical_leaves_v1()` = `pwu_per_inference` under `DerivedV1` = **6,630,544** for v5 (the facts'
`pwu`), read from the source rather than from `kaspad --palw-dump-classes`, which is a full node start (DNS seed,
P2P, a datadir) and was killed before it could become a seventh node. Jobs #1 and #2 stay local. The gateway was
restarted with `--class-leaves 6630544`; job #3 carries the exact prompt at max_tokens 56.

**Step 9, job #3 (01:19:43–01:22:12 UTC) — answered, committed and derived under the public chain's identity.**
The exact derive prompt at max_tokens 56 (prefill 147, decode 56/56, `finish: length` = the exact budget) on the
gateway restarted with `--class-leaves 6630544`: the compact DSL
`{"v":1,"frac_bits":0,"sketches":{"box":[[0,0],[2,0],[2,3],[0,3]]},"solid":{"op":"extrude","sketch":"box","z0":0,"z1":5}}`,
job `a50b79d38e62db2e…`, claim `b15ef21cf1f55581…`, 21,872,512 work leaves, output root `a07775eafc72939b…`;
derivation `cad/stl/v1` → the STL artifact, its DSL and a signed `derived-object.borsh` in `/root/fp-5f/outbox`.
The chain sequence that follows: the rail's `--submit` of the commitment (funding `bf3e37fc…:0`, class leaves
6,630,544, retention dir the gateway's traces), the FreePromptCommitted carriage, `submit-object` of the derived
object, and the claim's on-chain record.

**Step 9 — the commitment is on the public chain's mempool (01:23:08 UTC).** `misaka-palw-fp-rail --artifact
<stem> --bond-key-seed <hex> --funding-outpoint bf3e37fc…:0 --funding-amount 275587894580 --class-id 4277d84f…
--class-leaves 6630544 --retention-dir /root/fp-5f/outbox/traces --submit --rpc 127.0.0.1:26313`, exit 0:

    submitted tx  44227bdc9ade5c0f2b730dce3c0c0f386aac59806f473db71dd689b393798e982cf39a813af2bf5177859b1a6d782de1fd85fae9569e38031ff732f6f5e2fb67
    subnetwork 0x4a (PALW_FP_COMMITMENT) · fee 336,387 sompi auto-sized from 8,710 B of payload (the b037cdc2 rail) · 26 quanta
    pwu 21,549,268 · work leaves 21,872,512 · decode 56 · trace manifest root 4c0f6ca4… · trace retention daa 500,760
    commit-by anchor daa 3,760 · material file under /root/fp-5f/outbox/traces · claim b15ef21cf1f55581…

The derivation's ids, local for now: derived id `e154bd36541ed808…`, artifact hash `482b23231a42dc56…` (the same
684-byte STL the Mac and ibm produced from this prompt all night), signed by the gateway's `--derive-seed`. Next in
the running job: the block that carries `FreePromptCommitted`, then `submit-object` of the derived object, then
`misaka palw derived b15ef21c… --json`.

**Step 9 — carried (01:25:20 UTC).** node0: `Block 8a1a6c5361624c732750005dfecfd83390322c8736406499fae8a32767b913d1789c1e01832f0a51b72a3e869d22dd2ba250a9a42cc5998732de74f193206c26:
PALW lifecycle carried 1× FreePromptCommitted`; tx `44227bdc…` out of the mempool, the explorer's row accepted. **The
first free-prompt claim on the public testnet-11 is on chain**: claim `b15ef21cf1f55581…` in block `8a1a6c53…`, from
a 147-token prompt answered in 56 tokens by the v5 512 class on the certified lane. The derived object's carriage
(the third hash) is the running job's next step; a MIDI job (music/smf/v1, 97 tokens) runs on the gateway in parallel.

**Step 9 — the claim's record and the derived object (01:25:45 UTC).** `misaka palw derived b15ef21c… --json`:
`claim_phase provisional`, `claim_accepted_block 8a1a6c53…`, `claim_accepted_daa 768`, class `4277d84f…`, executor
bond `misaka-premine:0`, `artifacts []`. `submit-object` of the gateway-signed `DerivedArtifactV1` (kind 3, cad):
carrier `1c866e31d50411237ce87f710c0defaca7d0bd0f5744ce6e49ce37893c93dc644918a67c22d10e555cb38a5c4f053fd07c90e74b0b4349b639c042698e9140bc`,
funded from the commitment tx's change; "the chain grades them when the carriers are accepted". Its carriage is the
third hash.

**e1's pin finding, withdrawn (01:26 UTC):** the red `transformer_id_pin` gate and the zero-pin stranger regex are
impl-tip artifacts (`22bcafb5` sits on `4d572142`, before the cut); main carries the re-pin from `6e01ba07`
(`SOURCE_TREE 637858db…`) and a stranger whose regex reads all eight pins. Recorded as withdrawn, not open. The
one-line residue: a verifier whose regex cannot parse its own pin table passes unconditionally — true of impl's older
copy, closed on main. e1's control run on impl's tip with the pins re-pinned locally: stage 0 18/18, stage 0b PASS,
v5 producers committing legs with zero Decision-F lines — their rig's 24-vs-27 narrowing was its own divergence.

**Step 9, job #4 — MIDI (01:25:07–01:28:29 UTC).** The exact music prompt at max_tokens 97 (prefill 198, decode 97/97,
`finish: length`): the compact two-note DSL, job `93e130f5661e93dd…`, claim `d575928f8e0f220c…`, 32,128,904 work
leaves, committed; derivation `music/smf/v1` → the 91-byte MIDI with `artifact_hash 7a4f0eba…` (the bytes the Mac,
ibm's offline gateway and the stranger all produced), derived id `2ad3940d31120eef…`, its signed object in the outbox.
Its chain steps run in a second job funded from ff's untouched change `316edbd4…:1`, so nothing races the STL claim's
carriers.

## Step 9 — closed: the public chain records an artifact a free prompt produced (01:29:18 UTC, 2026-09-04)

    claim        b15ef21cf1f55581363c2426ae8f0b256f1f6b2b150c94fdd6021a47d4f597ffa644707d686e80cd96452280ae03efec047ea42fb46915b7a1355fbf62f32e1c
    carried in   8a1a6c5361624c73…  (01:25:20 UTC, "PALW lifecycle carried 1× FreePromptCommitted")   accepting chain block 8e2a83f53fb62501…  daa 768
    derived id   e154bd36541ed808aa7cb17b1128e2b266785ef9783d8208748bfbd58d8531cc6cb8025842318e152b0f23fb7945a8bc2a55c4cc591fb0424de3074e1e1bfdd4
    carried in   f38a861c6338b3cb…  (01:29:18 UTC, "PALW lifecycle carried 1× DerivedArtifactV1, 1× PanelBound")   accepted_daa 774
    artifact     cad/stl/v1, 684 B, artifact_hash 482b23231a42dc5689bb398380b06c84627f0c7e3bcf95f0845dd4e758cd9cc8d1f410fecdfa2564c8207b242f8b541c5c1e24ac298fc0095c055b7c346b57f3
                 dsl_hash 0f00e0f9b1be00dc…  grammar_id a4ec02b12c7cc3ff…  transformer_id 83e0f5088cd0f9b7… (the pinned cad transformer)

`misaka palw derived b15ef21c… --json` on node0 lists the artifact under the claim; the artifact bytes never touched
the chain (the chain holds the derivation's ids; the STL is in `/root/fp-5f/outbox` and in the operator's hands).
The same block bound the panel (`PanelBound`), so the claim's adjudication has begun on the seats. The MIDI claim
`d575928f…` (derived id `2ad3940d…`, artifact hash `7a4f0eba…`) follows the same path in a second job.

**Step 9 — the MIDI claim, closed (01:37:30 UTC).**

    claim        d575928f8e0f220c7af2254d00e6a00e7e5c333a3673432cfea44af926692e8df2a9d8a75b3ed9a9714055932e22ad95621682c48aa02…
    commitment   tx 197ea823085d154b…  fee 338,937 sompi auto-sized (8,914 B payload) · 38 quanta · pwu 31,495,084 · 32,128,904 work leaves
    carried in   cc8ff79cb51ddbd6…  (01:33:24 UTC, "1× FreePromptCommitted")  daa 780
    derived id   2ad3940d31120eef76435b7d…  carrier 0484005c08f5270e…  carried in fad34dc6a0dec2c0…  (01:37:30 UTC, "1× DerivedArtifactV1")  accepted_daa 787
    artifact     music/smf/v1, 91 B, artifact_hash 7a4f0eba065508e098cfccd9…  dsl_hash 3f64e301dc5925e5…  (the stranger's own recomputation of 7a)  kind 6

Both practical outputs the goal names — a 3D artifact and a MIDI file — are recorded on the public testnet-11 from
free prompts to the dense tier's certified lane, each as a claim and a derivation whose ids anyone can recompute from
the committed answer. The gateway (`fp-gateway-5f`) is stopped; ibm's memory returns to the two nodes. What remains
post-cut is unchanged: the material transport (6k–6m) for the seats' verification and the dense tier's own attempt
blocks, and ADR-0065 D4.

## Step 10 — the first public newcomer, and its first wall (01:45 UTC, 2026-09-04)

ff (the Studio integrator) pointed a Studio-supervised kaspad at testnet-11 from a Mac. The binary was built from
`palw-adr0082-impl` — the frozen cut plus tool commits, **without the genesis re-pin** — so it printed
`Consensus params fingerprint: a5291e00…` (the pre-re-pin value) and then **panicked**:
`consensus/src/consensus/utxo_set_override.rs:60: assertion left == right failed: genesis utxo_commitment`. That is
audit M-07's guard (a node must not boot when its pinned genesis disagrees with the premine it mints) — the same
line ibm's un-re-pinned binary died on in step 4 — and it is the right refusal in the wrong voice: a newcomer who
builds from a checkout one commit stale gets a stack trace, with the fingerprint line above it as the only clue,
before any peer is contacted. **Fourth newcomer wall**, beside the three the memory names; post-cut: a named refusal
("this build's genesis is X; the network's is Y; build from tag …"), not an assertion. ff is rebuilding from the tag
`testnet-11-relaunch-5f` (`6e01ba07`), which is also the binary a Studio user needs — the argument for a GitHub
release carrying binaries, which is the operator's to cut. Nothing was spent; bond-0 untouched. The join readings
(which seed names answer, whether the two anchors handshake, whether pruned-IBD or the registration meets a wall)
come from the tagged build's run, with the bond outpoint.

**Step 9 — a second reader (01:45 UTC).** e1 read `transformer_id_pin.rs` on main without looking at the reported
value: the STL's on-chain `transformer_id 83e0f5088cd0f9b7…` is the pinned `cad/stl/v1` row under
`SOURCE_TREE 637858db…`. Then, from `.113`'s node (borsh 26313) and its explorer — not node0 — the same records:

    STL   claim b15ef21c…  phase panel_bound  accepted block 8e2a83f5… daa 768  artifact cad 684 B  derived e154bd36…  hash 482b2323…  transformer 83e0f508…  accepted_daa 774
    MIDI  claim d575928f…  phase provisional  accepted block cc8ff79c… daa 780  artifact music 91 B  derived 2ad3940d…  hash 7a4f0eba…  transformer cb5f27b4… (= the pinned music/smf/v1 row)  accepted_daa 787
    blocks 8a1a6c53… (daa 768, blue 457) · f38a861c… (774, 461) · cc8ff79c… (780, 465) · fad34dc6… (787, 469) — all present in .113's explorer
    .113's own log: "PALW lifecycle carried 1× …" at 01:25:20, 01:26:12, 01:29:18, 01:33:24, 01:37:30 UTC — the same seconds as node0's

Two nodes, one explorer and the pin table agree; the artifacts' transformers are the rows this repository pins.
e1's devnet drill on impl's tree, in their words: stage 0 18/18, stage 0b PASS (ADR-0080 W1b in force), Decision F = 0,
stage 1 FAIL by their own configuration (t11's calibrated floor target on three local nodes) — not offered as
acceptance evidence; the public chain's is the evidence that counts. Their wrapper's exit 0 over the drill's
`DRILL_EXIT=2` (a trailing `echo` ate the status) is the "green result that means nothing" family, noted for the
runbook.

### 10b. Why no floor block, ever — heartbeat rows in the difficulty window price every attempt lane off the chain (2026-09-04 02:00–04:10Z)

ff's report was "slot-02 has drawn nothing since it registered". The answer is not slot-02's: **no attempt lane can win on this chain any more, and the chain cannot recover by itself.** Measured on node0 (wRPC 26314, `getBlocks` from genesis, 829 blocks, sink DAA 826):

| what | value | where it comes from |
|---|---|---|
| floor class id | `f1c5635c…f623c8` (base=true, share 22, budget 22, leaves 7,708) | `--palw-dump-classes` on a scratch node `--connect`ed to node0 (DAA 812) |
| floor class target | 26,870,389,773,037,778,623,525,617,844,355,071 = **7.9e-5 · u128::MAX** (1 win per 12,664 draws) | `getPalwProducerFacts` (`classId`/`bondTransactionId`/`bondIndex`/`withBond`) — equals `u128::MAX · 22·7,708 / 2³¹` to the digit |
| floor facts, bond premine:1 and :0 | available true, notReadyReason "", epoch 0 produced **0** / budget 22, collateral 1e12, exposure 38,540 of 5e11 | same RPC — the chain permits the floor |
| genesis bits | `0x207fffff` → Layer-0 p = **0.5** | `getBlock(genesis)` |
| sink bits (DAA 826) | `0x1f65bd04` → Layer-0 p = **1.5e-3**, difficulty 320.7 | `getBlock(sink)`, `getBlockDagInfo` |
| bits over the chain | constant to DAA 150 (`MIN_DIFFICULTY_WINDOW_SIZE`), then p = 0.14 (slot 50) → 0.065 → 0.017 → 0.005 → 0.0017 → 0.0015: **halving every ~50 slots** | selected-chain sweep |
| selected chain | 256 rows: genesis + **255 heartbeats (algo 8)**, interval 122 s (p10 = p50 = p90) | sweep |
| non-chain blocks | 572: 569 heartbeats, **3 attempt blocks (algo 6, QWEN36)** at DAA 40 / 80 / 226 — none after Layer-0 p fell under 0.11 | sweep |
| blocks per slot | 3.3 / 3.4 / 3.3 / 3.1 / 3.1 / 2.7 (50-slot bins): chain heartbeat + 2–3 sibling heartbeats (`PALW_HEARTBEAT_MAX_PER_MERGESET` = 4) | mergesets |
| heartbeat emitters | **5**: ibm node0 + node1, .113 node + seat4, seat2 (`--palw-heartbeat-miner-address` on each) | `ps` on the three hosts |
| t11 block time | **120 s** — `DnsParams … with_two_minute_cadence()` (params.rs:8181), not the 10 s the preset comment describes | params.rs |

**The mechanism, reproduced to 2–3 %.** The DAA (`SampledDifficultyManager::calculate_difficulty_bits`, difficulty.rs:216) sets `new_target = avg_target · measured_span / (120 s · 263)` over the last 264 DAA rows. Heartbeat rows enter that window as ordinary rows (ADR-0066 Decision 1 said so, deliberately). One emitter per slot is exactly on pace; **every additional emitter adds a row per slot without adding time**, so five emitters give ~3.2 rows per 122 s slot, the DAA reads "three times too fast" and tightens bits by ×3 per window — forever, because the heartbeats themselves are priced by a network constant (2²⁴) and never feel it. Only the lanes priced by `bits` pay: the floor's combined chance per draw is now 7.9e-5 × 1.5e-3 ≈ **1.2e-7**, ~18 days per win per node, and it halves every two hours. Emulating the window from node0's blocks with T = 120 s predicts the next chain block's bits within 2–3 % at DAA 815/819/821/823 (1.62e-3 vs 1.58e-3, 1.57 vs 1.56, 1.57 vs 1.55, 1.54 vs 1.52); with T = 10 s the same emulation predicts *easing* to 1.9e-2, so the 120 s cadence is what the deployed chain runs.

**Why it cannot recover.** `heartbeat_interval_ms` (palw_heartbeat_v1.rs:107) is one cadence after a heartbeat parent and only backs off after a *bonded* parent — "in a crisis, every bonded lane silent, the slot ladder tightens to the full cadence". The bonded lanes are silent *because* bits is tight; bits is tight *because* the heartbeats run at full cadence from five nodes. Cutting emitters to one stops the tightening (ratio 122/120 = 1.017) but recovery at 1.7 % per window from ×320 is ~340 windows ≈ 90,000 blocks. Pausing every heartbeat makes a gap, and a gap eases only linearly (a 12 h gap is ×1.7 once). The heartbeat miner's own doc has the blind spot in one line: *"the more that do, the harder the lane's own retarget"* — after ADR-0066 the lane has no retarget of its own, so the extra emitters harden the **global** `bits` instead. ADR-0066's table listed this as F1 ("the lane can price the bonded lane off its own chain, permanently"); Decision 1 removed the heartbeat's *price* from `bits` and left its *count* in the window, and the count is what carries F1.

**What this changes in the announcement.** The claims it names were real and are on the chain (STL, MIDI, the v5 lane certification — all at DAA ≤ 700, all carried by heartbeat blocks' mempool). "Produced and counted" for QWEN36 stands (3 blocks, DAA 40/80/226). What the draft must not imply is that attempt lanes are live now: since DAA 226 no attempt block exists and none is possible at the current bits. Line added to the draft.

**The fix is a consensus change, not an operator knob.** The difficulty window's *rate* must count only rows whose lane is priced by `bits` (exclude algo 8 from the count and the span), and when fewer than `min_difficulty_window_size` such rows exist the V2 answer is `max_difficulty_target` (ADR-0066: "a V2 network runs at MAX because the class lottery is its throttle"), not the selected parent's bits — otherwise a chain whose attempts died stays dead at whatever bits killed them. Both halves change `bits` on every header past the point they apply, so they ship either as a `ForkActivation` in `DnsParams` (fingerprint moves, genesis does not — a flag-day restart of the six seats, no wipe) or folded into a 5g re-mint. That is the operator's decision; the branch and its tests are the next entry. Until one ships, the only thing worth doing operationally is stopping the bleed: leave **one** heartbeat emitter running and remove `--palw-heartbeat-miner-address` from the other four, so the bits an activation inherits is not another 2¹⁰ tighter.

### 10c. The fix, written and tested, not armed — ADR-0083 on branch `palw-daa-bits-priced-rows` (2026-09-04 04:10–05:40Z)

Two commits, local (the branch is not pushed; the operator decides §5 of the ADR first):

| commit | what | fingerprint |
|---|---|---|
| `55b13b77` | ADR-0083 Decision 1: `Params::palw_difficulty_priced_rows` (top-level `Option<ForkActivation>`, `None` everywhere, Some-only in `consensus_params_id`, `never()→None`, on the `for_each_fence` walk); past it `calculate_difficulty_bits` multiplies the expected duration by the rows whose lane satisfies `algo_id_is_priced_by_bits` (everything but algo 8), and a window with no priced row answers `max_difficulty_target`. `retarget_bits_from_rows` is public for replay. ADR text + README row. | unchanged on every preset — `shipped_presets_have_pinned_fingerprints` and the t11 announce-pin test green |
| `0547677d` | kaspad only: the two `trace!` holds become deduped INFO lines carrying the three predicates; every five minutes the loop prints draws / produced / "won the class ticket, lost against bits" / class p per draw. | none (no consensus change) |

Verified: core lib tests 65/65 on the fence + pin + params-id suites; `processes::difficulty` 3/3
including the new shape test (5f window: legacy tightens, fenced eases ×2.95; no priced row → MAX;
all priced → identical to legacy; attempts every 30 s against 120 s still tighten); kaspad builds;
`cargo fmt` clean on the three crates. The fuller sweep (whole consensus + core lib suites, clippy)
is running as this is written and is recorded in the next entry.

**What the second reader can do that the author cannot:** replay the chain's own 841 rows through
`retarget_bits_from_rows` with both flags — ff holds those rows and offered exactly that.

**Second finding carried from ff:** slot-02 on .113 at 5 % CPU with a healthy chain view was HELD
(the silent `should_mine` trace), while ff's Studio node drew at 41 %; the pool's kaspad has no
borsh listener so `getPalwProducerFacts` cannot be asked of it. `0547677d` makes the hold and its three
predicates visible; `--rpclisten-borsh` in the pool's `run-slot.sh` is the pool owner's change.
ff stopped their node's producing run (the bond `ffbeb993…:0` stays registered) — nothing to win
until the rule ships.

### 10d. The sweep on `palw-daa-bits-priced-rows` (2026-09-04 02:29–02:38Z)

| suite | result |
|---|---|
| `kaspa-consensus-core --lib` (all) | **1826 passed**, 0 failed, 9 ignored |
| `kaspa-consensus --lib` (all) | **279 passed, 1 failed**: `pipeline::virtual_processor::tests::palw_v2_certification_and_chunk_carriage_pay_rent_past_the_fence` — "the same chunk, having paid the room, opens the group: left 0, right 1" (tests.rs:10392) |
| the same test on the base commit `0870b7ee` (= main) | **fails identically** — pre-existing on the cut, not this branch's; twice on the branch, once on base, same message |
| clippy (consensus, core, kaspad, all targets) | one warning, in the new test (`slot % 3 == 0` → `is_multiple_of`), fixed in `b2c12aa2` |
| `cargo fmt --check` on the three crates | clean after `cargo fmt` (worktree is this session's alone) |

The pre-existing failure is a chunk-group-rent assertion in the virtual processor; the last commit
on the cut touching that carriage is `4d572142` (`PALW_OBJECT_CHUNK_MAX_COUNT` 8 → 16). It is not
in ADR-0083's scope and is flagged separately; it does mean main's `kaspa-consensus` lib suite is
not green as shipped, which the 5f verification pass (§8) did not run — §8 ran the fleet, not the
suites. Recorded so the next reader does not count this branch's sweep as the first red.

Branch head: `b2c12aa2` (three commits over `0870b7ee`: 55b13b77 consensus + ADR, 0547677d producer
visibility, b2c12aa2 lint). Not pushed; not armed anywhere.

### 10e. The exact replay: legacy bits reproduced 273/273, and the fence holds MAX through the whole history (2026-09-04 02:45–02:55Z)

ff's replay from `getBlocks` rows did not reproduce the chain's bits (first divergence at DAA 150,
four row-order variants, best 7 % off), so "the fenced trajectory" was not yet evidence. The
header processor's construction, read from `window.rs:138–335` and `difficulty.rs:216`, is:

* **window(B)** = the 264 largest rows by `(blue_work, hash-bytes)` over
  **window(SP(B)) ∪ {SP(B)} ∪ mergeSetBlues(B) ∪ mergeSetReds(B)**, minus rows whose
  `blue_score < blue_score(B) − 264` and minus genesis (marked non-DAA by the builder). B itself is
  not in its own window. `blue_work`, `blue_score`, `timestamp`, `bits`, `powAlgoId` are all on the
  RPC **header** object; the mergeset and selected parent are in `verboseData`.
* **bits(B)** = legacy retarget over window(B) when it holds ≥ 150 rows, else `bits(SP(B))`
  (genesis bits when SP(B) is genesis). The min-timestamp row leaves the average, tie-broken by
  `(timestamp, blue_work, hash)`; `T = 120 000 ms`, sample rate 1, cap at `target(0x207fffff)`;
  the compact encoding is `math/src/lib.rs::compact_target_bits`.

Run on node0 (`/root/fp-smoke-5f/exact-window.py`, 885 blocks, chain of 274):

| tie-break on equal blue work | legacy replay vs the chain's bits |
|---|---|
| hash bytes descending (= `Hash64::Ord`) | **273 / 273 exact**, DAA 150 → 882 |
| hash bytes ascending | 194 / 273 — first miss at DAA 275, one unit of mantissa |

With the same windows and `priced_rows_only = true`: **`0x207fffff` at all 273 rows.** The
three attempt rows at DAA 40/80/226 are 1–3 priced rows in windows spanning ~10 000 s, ratio ≥ 27,
capped; every window after DAA ≈ 310 holds no priced row at all (ff's independent bound) and
answers MAX by construction. So the rule, applied from genesis, would have kept `bits` at MAX
through the entire 5f history, and armed now it carries MAX from its first block.

Row order was the whole difference between "2–7 % off" and exact: the window is a heap by blue
work with a byte-order hash tie-break, not the last 264 rows in mergeset order; on a heartbeat
chain blue work grows by ε = 1 per block, so the tie-break decides membership at the margin.

### 10f. The operator's decision and the flag day — ADR-0083 path (a), fence at DAA 1150 (2026-09-04 02:50Z →)

**Decision (operator, 02:5xZ):** ADR-0083 ships as a scheduled fence on the live chain — no re-mint —
and `f1604dd3` (kaspad derives its pay address from the producer key) goes to main and the release.

| item | value |
|---|---|
| height H | **1150** — chosen at DAA 894 (02:50Z) at ~93 DAA/h: ~2.7 h of lead over a 15-minute build and a six-seat restart |
| tree | branch `palw-daa-bits-priced-rows` tip **`cef2ecdb`** (rebased on main `3c41abc2`): 1edfc956 ADR-0083 rule (dormant) · b6edd936 producer holds visible + draw counter · a8729a94 lint · 3341ccfd = f1604dd3 · c6ad999d **arming** (`palw_rc_base_params`: `palw_difficulty_priced_rows = Some(ForkActivation::new(1150))`) · cef2ecdb chunk-rent test fix |
| t11 fingerprint | `2222e054…` → **`71b35c25…`** (`consensus_params_id`, the fence's Some-only write); re-pinned in `shipped_presets_have_pinned_fingerprints` and NAMED in `scripts/ci/check-repin-predictions.sh` before the paste; genesis `ad30b5cb…` unchanged; fence-normalised identity unchanged → a seat on `14065c93…` peers with the new build until 1150 |
| build | ibm, worktree `/root/misakas-cef2ecdb` (so no peer's checkout moves), `nice -n 19 cargo build --release -j 4 -p kaspad` — the 5f recipe — staged as `/root/t11/kaspad.cef2ecdb`, never over the live binary |
| seats to restart before 1150 | ibm node0 + node1; .113 node + seat4 + pool slots 01/02/03 (all on `/root/t11/kaspad`); seat2. ff's Studio node rebuilds from `cef2ecdb` on its own (told the hash and H) |
| order | node0 first — it is the `--addpeer` for the others and the empirical check that old/new peer with a warning — then node1, seat2, .113 |
| pre-push gate | core 1826 + the new fence test; consensus lib whole suite (now green: the one red was the chunk-rent test, fixed in `cef2ecdb` — the floor's evidence is 754,377 B and the test cut it into 188,595-B quarters over the 100,000-B carriage, `ChunkTooLarge`, not rent); kaspad builds; clippy clean |

**What "peers until H" is and is not.** The handshake compares `consensus_identity_id`, which
normalises every scheduled fence to "not yet" (M1-6), so old and new builds connect and log a
schedule warning. At 1150 the new build computes `bits = MAX` for the first fenced block; the old
build's heartbeat blocks carry legacy bits and are refused as `UnexpectedDifficulty` by every
upgraded seat — the un-upgraded seat forks off. A seat that runs the OLD build past 1150 and is
upgraded afterwards would keep its old-rule blocks in its DB, so every seat restarts BEFORE 1150,
and if a restart is late the fallback is to stop that seat rather than let it cross the height.

**Chunk-rent test (chip), closed in the same tree:** root cause the test's cut, not the rule (§10d's
red). `4d572142` exonerated by ff's experiment (fails identically at 8). The underpay assertion had
been passing vacuously — the rent check runs before the transition, so an opener that could never
open was "dropped" at both prices; the fixed test asserts the parts ride the carriage by name.

**Provenance addendum (03:1xZ).** The sweep found one more pin that the scheduled fence moves:
`fork_id_v1::tests::the_shipped_schedules_are_measured_not_assumed` (testnet-11's fence schedule is
now `[1150, 2_125_000]`). Re-pinned as `16a2f277`, a test-only commit on top of `cef2ecdb`; the fence is
**on the schedule and off the fork-id gate** (`fork_id_gate_fences_v1` still names only ADR-0072's
fence), so this build refuses no peer at 1150 — the separation is at the block level, as on every
previous relaunch — and arming the gate on it is a chip for the operator (first arming of that gate
on a shipped preset; the module's own test forbids it today). The fleet's binary is built from
`cef2ecdb`; main's tip is `16a2f277` = `cef2ecdb` + that pin. Functionally identical binaries; the
provenance line in every seat's log names `cef2ecdb`.

### 10g. The fork-id gate follow-up (chip), written — not in the flag-day binary (03:1xZ)

ADR-0083's fence goes on `fork_id_gate_fences_v1` (branch tip after `16a2f277`): the first shipped
preset whose fork-id gate is armed, by exactly [1150]. Below the height every verdict is a warning
or `Agree` (old build, absent fork id, stranger); from it the old build is refused **on that fence**
with a named reason, and the fresh syncing node / the node already past 1150 stay prefix peers in both
directions (`the_gate_is_armed_only_where_a_shipped_preset_schedules_a_gate_fence`, 14/14 in the
module). Deliberately NOT built into `cef2ecdb`: one change per deploy on a flag day. A gate build
past 1150 agrees with a `cef2ecdb` node past 1150 and refuses only `14065c93…`, so it rolls out after
the height at any pace. Gates for it are running as this is written.

### 10h. The flag-day restart, executed (2026-09-04 03:10–03:36Z) — every seat on `cef2ecdb` before H

| step | when (Z) | what happened |
|---|---|---|
| build | 02:56–03:10 | ibm, worktree `/root/misakas-cef2ecdb`, `cargo build --release -j 4 -p kaspad`: 13 m 36 s, 1.1 GB peak; `kaspad.cef2ecdb` sha256 `002cee6a…`, 53,938,328 B |
| stage | 03:15 | copied via the Mac to .113 and seat2; sha equal on all three hosts before any install |
| ibm | 03:18 node0 SIGINT; 03:22 node1 SIGINT | node1 respawned in 39 s on the new file, fingerprint `71b35c25…`. node0 logged "shutting down", stopped its servers in 1 s, `[palw-producer] stopping (3 blocks this run)` at +2.5 min — then sat at 128 % CPU with no further line for 14 min (the 34 GB mapping's unmap tail) |
| seat2 | 03:24 SIGINT | same tail (11 GB RSS, 63 % CPU, still alive at +7.5 min) |
| .113 | 03:27–03:34 | node respawned in 21 s; seat4 in the tail; pool slots 01/02/03 respawned in 21–27 s (their wrappers are the main pids; the child kaspads verified on the new file) |
| kills | 03:35 | node0: no log line for 845 s → SIGKILL, respawned as pid 2701995, fingerprint `71b35c25…`, mapping QWEN36. seat2 and seat4: SIGKILLed on the same rule — **but their journals were empty because their wrappers log to files, so for those two the "no progress for 4 min" test read absence, not evidence**. Same outcome (both respawned cleanly on the new file, seat4 in 45 s), wrong basis; the rule to keep is the memory's — a check that returns nothing is not a measurement. |
| verify | 03:37 | 8 kaspad processes, 0 `(deleted)`: ibm 2700312 (node1) + 2701995 (node0); .113 1113131 (node) + 1115457 (seat4) + 1114389/1114653/1114931 (slots); seat2 1742602. Fingerprint `71b35c25…` on node0, node1, .113 node, seat2 (the journal-logging seats); seat4/slots run the same file |
| peering | 03:09–03:35 | both directions of "peers until H" seen live: ff's new-build node logged the FUTURE-fence warning against the fleet's old anchors at 03:09; .113's OLD node logged it against a new-build peer at 03:26 (`peer dbfc99dc… agrees on every rule in force now and schedules a FUTURE fence differently`). No refusals |

The old-build stragglers refused nothing and were refused by nothing (the gate is not in this
binary — §10g); the chain simply keeps ticking on the new-build heartbeats through the cycle.
External nodes on pre-5f genesis kept knocking on node0 (`Genesis mismatch on network
misaka-testnet-11`, three addresses) — the M-07 guard doing its job, unrelated to the flag day.

### 10i. The public add-a-model path, walked as a user: Qwen3.8-27B (2026-09-04 05:00Z →)

Operator's ask: add Qwen 3.8 27B as an ordinary user would, through the documented path, and check
that registration and certification work — stop before block production. Host: `.113` as the
user's machine (`/root/misakas-user`, a fresh clone of main; `/root/palw-user` for everything else).

| step (doc) | what happened | evidence |
|---|---|---|
| model | `Qwen/Qwen3.8-27B` exists (2026-08-14): `model_type qwen3_5`, 64 layers, hidden 5120, full attention every 4th, attn 24/4 @ 256, rotation 64 @ 1e7, GDN 16k/48v @ 128 conv 4, DENSE FFN 17,408, vocab 248,320 | config.json; ggml-org GGUF metadata (`arch qwen35`) agrees field for field |
| SDK step 1–3: geometry + row + conformance | **needs a code change** — the class table is node-local, so a user forks: `QWEN38_27B` in `palw_qwen36_profile.rs`, one graph-v3 row `Qwen/Qwen3.8-27B/graph-v3` (dense FFN as the one-expert mixture, the Qwen3.5-2B precedent); consensus untouched, fingerprint unchanged. `misaka-palw-sdk` 23/23; consensus-core qwen36 30/30; base0 class/plan 27/27 after moving one pin from "three servable rows" to four — **the interpreter planned the 27B graph and its planned and compiled forward passes agreed** | branch `palw-add-qwen38-27b` (ea5f48a6 row, d0d0822c test pin), pushed |
| SDK step 4: convert | `qwen36-convert --url … --header … --out qwen38-27b.palwq36 --context 512`, streaming the 18,973,870,432-byte Q4_K_M by HTTP range; the converter read "64/64 layers (48 linear, 16 full) … gdn 16k/48v @ 128 … moe 1/1 @ 17408 + shared 0", plan 1,395 tensors, **25.79 GiB of int8** | running from 05:17Z, ~1.2 GiB/min |
| join doc §2: key + funds | `misaka key gen` → `misakatest:qtqtgeu0…`; the public faucet paid **12 tMSK** (txid `3f94fd76…`) | faucet `/faucet/v1/claim` 200 |
| join doc §3: bond | user node on the flag-day binary (`--palw-register-bond --palw-producer-key`, pay address defaulted from the key — f1604dd3): fingerprint `71b35c25…`, seeders 1/3 answered (2/4 dead, known), anchors connected, IBD in ~1 min, **bond `d9067d09…:0` registered with 8,333,751 sompi collateral**, carried by the chain ("PALW lifecycle carried 1× BondRegistered") | node.log |
| next | `qwen36-run --root-only` → `palw-class inspect` / `preflight --network testnet-11 --model-id Qwen/Qwen3.8-27B/graph-v3` (the admission gate, before any fee) → `--palw-register-class` from the user node → `palw-certify drill` (family evidence) → `FamilyCertified` / `ClassLaneCertified`. No `--palw-produce`. | |

**First finding for "does the path work":** the chain side is permissionless as ADR-0054 says, but
the tooling side is not "no code": a new checkpoint of a known lineage needs a geometry constant and
a table row in the node's own crates (the SDK doc says so; the `Adding a model` paragraphs in README
and the announcement do not). A user who cannot build the node cannot add a model. Everything up to
the bond needed no code and worked first time on the doc's commands.

**§10i, continued (05:35Z): the class is covered by an already-certified family.**
`palw-certify bind --model-id Qwen/Qwen3.8-27B/graph-v3 --lane attempt|fp` (the `--model-id` form is
the one for a `.palwq36` row) wrote both `ClassLaneCertified` objects (11,147 B each) for class
**`2705b8f6…7755f3`**: 23 reachable kernels, **covered by the PALW-QWEN36 RC family's attempt-lane drill
and by its free-prompt-lane drill**; worst case 9,000,776 step leaves inside the ruleset's 67,108,864
cap. So the operator's two questions have their answer for this model: the graph is statically
adjudicable (the gate's coverage and ladder checks) and its kernels sit under a family the chain already
certifies end-to-end — the registration will not be weightless, and no new family drill is needed;
"certified" here is the two lane bindings, submitted once `ClassRegistered` is on the chain.
`palw-class ledger --network testnet-11` lists the row beside the genesis ones. Bond change
`d9067d09…:1` (11.913 tMSK) is the fee outpoint for registration and the objects' rent.

### 10j. H — the fence fired (2026-09-04 05:44:54Z, virtual DAA 1150)

| block | algo | bits | Layer-0 p |
|---|---|---|---|
| DAA 1114 | 8 | `0x1f0d2b4e` | 2.0e-4 |
| DAA 1147 (last before the fence) | 8 | `0x1f0a96a7` | 1.6e-4 |
| **DAA 1151 (first fenced)** | 8 | **`0x207fffff`** | **0.5** |

Difficulty 1.00 on .113's node. The tightening had reached ×3,100 by the fence (p 0.5 → 1.6e-4 in
1,147 blocks); the first fenced window held no priced row, so it answered `max_difficulty_target` in
one block — ADR-0083 §4.3 as written, and the recovery path (a) was chosen for. Every seat was on
`cef2ecdb` (§10h); no refusals, no forks among the eight; the old-build external node at
113.155.23.105 is the only party expected to part here. The floor's chance per draw is back to
7.9e-5 × 0.5; the first attempt-lane block after H, from any seat, is being watched for.

**§10i, continued (05:50Z): root, inspect, preflight — ADMISSIBLE.** `qwen36-run --root-only` over the
27,880,974,336-byte artifact (sha256 `5afbfbe2…`, 25.79 GiB of int8 in 25 m 15 s, 6.7 GB peak) computed
root **`811af53e…f4d9`**; `palw-class inspect --network testnet-11` PAIRS the file with
`Qwen/Qwen3.8-27B/graph-v3`; `palw-class preflight … --model-id Qwen/Qwen3.8-27B/graph-v3` →
**ADMISSIBLE**, pwu/inference 9,000,776 — the chain's own admission gate, before any fee. The user node
was then restarted on the row-aware `kaspad` (sha256 `3b0cf7a7…`, built on .113 from `d0d0822c`) with
`--palw-class-artifact … --palw-register-class "Qwen/Qwen3.8-27B/graph-v3" --palw-producer-bond
d9067d09…:0 --palw-fee-outpoint d9067d09…:1`, no `--palw-produce`; it maps the artifact (minutes) and then
registers. Also observed: the floor's target eased ×4 at the epoch-1 boundary (`converge_idle_target_v1`),
3.1586e-4 of u128::MAX = 1 in 3,166 — ff's node reads the same; their expected time to a floor block at
3.25 draws/s is ~32 min.

### 10k. The join path re-pinned and the release published (05:55Z)

README, `docs/history/testnet11-join-mining.md`, `docs/history/testnet11-node-operator.md` now name genesis `ad30b5cb…`,
fingerprint `71b35c25…`, floor `f1c5635c…`, the tag, the DAA-1150 parting rule, the optional pay address,
and the withdrawn `.114` entry node is gone (main `03c90495`). GitHub release
**`testnet-11-relaunch-5f-adr0083-h1150`** carries `kaspad-linux-x86_64` (53,938,328 B, sha256
`002cee6a…`, built from `cef2ecdb`) with the identity, the flag-day facts and the parting rule in its notes.

### 10l. After the fence: the first attempt blocks, the cadence, and a same-key trap (06:00–06:30Z)

| DAA | block | lane | producer | when |
|---|---|---|---|---|
| 1169 | `9499375e…` | attempt (algo 6), chain block | **.113 pool slot-02** (the Studio's pool path; the seat ff reported held at 5 % CPU) | 05:56:25Z, 13 min after the fence |
| 1174 | `4b22ca52…` | attempt, chain block | ibm node1 (floor; its counter read 3,982 draws / 1 produced / 3 class wins) | 05:59:34Z |
| 1175 | `598b3635…` | attempt, chain block | **ff's Studio desktop node** — the first block a non-fleet producer has won on the public testnet (bond `ffbeb993…:0`, 16,599 draws in 22.7 min) | 06:07:34Z |

All three carry `bits 0x207fffff`; coinbases hold zero outputs (escrow until Final). `palw weight=0
live_total=… final_claims=0 unresolved=6–7`: the claims are counted and not yet Final.

**The cadence changed with the first bonded block — by design.** `heartbeat_interval_ms` is one hour
after a bonded parent (`HEARTBEAT_NOMINAL_INTERVAL_MS`), so the heartbeat lane stepped back and the
chain's clock is now the attempt lanes' win rate: no block from 06:07:34 to past 06:22, DAA parked at
1176. With ~6 floor producers at 1 in 6,332 per draw the expected gap is minutes, with a long tail;
the floor's class target eases only ×4 per 1,000-DAA epoch, which at this pace is days. This is
ADR-0060/0066's "calm weather" and ADR-0071/0076's economics doing what they say; whether a public
testnet wants an hour-long heartbeat interval while the floor converges is an operator question, not a
defect to fix here.

**A newcomer trap found by walking the path (recorded, not fixed):** `misaka palw submit-object` on
the SAME key the node's panel uses refuses to fund the carrier — "no mature, unbonded, unspent UTXO" —
although the wallet holds 11.9 tMSK of ordinary change. The wallet's bonded set is `getStakeBonds`
(empty) ∪ the empty-class `getPalwProducerFacts.lockedBondOutpoints`, which on the node that runs the
panel includes **the output the panel has reserved as its own fee chain** — after the class
registration that is the registration's change `2803209b…:0`, the user's only spendable output. Correct
as double-spend prevention, silent as a message: the CLI names the output "bonded" (`wallet utxo list`:
bonded 2, mature 0) while the chain's locked set (13 outpoints) does not contain it. Workaround used:
submit through a node that does not reserve it (the fleet node on the same host). The right fix is
either a named reason ("reserved by this node's panel as its fee outpoint") or letting the CLI chain on
the panel's reservation the way `spendable_candidates_v1` already chains on the mempool.

**§10i, continued (06:50Z): the chain's certified set does not cover the class — the tool's view did.**
Both lane bindings were submitted through the fleet node (attempt tx `4efe3fbb…`, fp tx `20799b0a…`). The
block at 06:40:51Z (`adaf6b71…`) carried the attempt binding and **dropped it**: *"no family certified on
this chain for the attempt lane covers every kernel class 2705b8f6…"*. `palw-certify bind` had said the
opposite ("covered by the PALW-QWEN36 RC family's attempt-lane drill") because it reads the BUILD's fixture
families, while the chain reads genesis ∪ carried objects — and whatever the 5f genesis certified for the
QWEN36 family does not reach every kernel the 27B graph reaches. So the documented family-first route
applies (the one a16-v5's free-prompt lane took in §7): `palw-certify drill --family qwen36 --lane attempt`
(the fixture drill, 15 s; family `c22beec9…`, 29 vectors, 914,168 B → 10 chunks) submitted as chained
carriers through the fleet node, then the binding again. **Finding for the doc:** the bind tool's coverage
sentence is a build fact, not a chain fact, and it should say so — or read the chain's certified set through
the node it is pointed at.

### 10m. "My Studio chat is not on #/llm" — three layers, two fixed, two decisions (2026-09-04 07:50–08:35Z)

The operator chatted in the Studio and expected the exchanges on misakascan.com/#/llm, which listed
QWEN36 canonical jobs only.

| layer | fact (measured, ff on the operator's Mac for the Studio half) | state |
|---|---|---|
| Studio chat | `ChatView` → `/api/v1/chat/completions` → the Studio's **llama.cpp** (123 tok/s, first token 53 ms); the path contains no gateway/commit/palw code; the gateway is not running there | by design: chat commits nothing |
| Studio prompt-mining | `PromptMiningPanel` → gateway → palw-worker → a signed commitment in the outbox; `api/prompt_mining.rs`: "whether anything reached the chain … nothing does. The rail signs and deliberately stops" (`ChainReach::CommittedNotSubmitted` is its only variant) | no submitter exists; ff owns adding one (operator's instruction to ff at 08:2xZ) |
| explorer | the exporter decoded attempt-lane headers only; the page's client-side lifecycle decoder had a variant table one behind the enum from `BondCapabilityDeclared` on (`ClassRegistered` rendered as `ClassFrozen`, `FreePromptCommitted` as `object#12`, the four ADR-0075/0078 objects unknown) | **fixed**: deployed `app.js` (backup `app.js.bak-llmfp-…`, mirrored as explorer repo `c3d4aa5`): table in the enum's order, `FreePromptCommitted` rows typed "free-prompt" with class and leaves, event descriptions for the new kinds, QWEN38-27B in the class table; exporter branch `palw-jobs-export-fp` (`6d2b2794`) adds `--fp-outbox`: 4 free-prompt rows now published (STL `b15ef21c…` → derived cad 684 B, MIDI `d575928f…` → music 91 B, and the two refused-derivation claims) with the gateway's answer text; ibm cron carries it every 2 min |

What the page cannot do: show a chat that never left the Mac, or the text of anyone's free prompt —
the chain carries `prompt_token_ids_hash` and `output_root`, the text stays with the executing gateway
(the site shows it only for the fleet gateway's own claims). Prompt text for those four is still empty:
the v5 retention is the dense tuple, which carries no prompt ids — next entry.

Two decisions for the operator, stated in the report: (1) a submitter for the Studio's outbox — ff owns
it (rail `--submit`, funds split from the panel's fee chain, the same-key reservation caveat handed over);
(2) chat is NOT routed through the gateway (ff and I both recommend an explicit "commit this answer"
action instead). And the blocker nobody's Studio can fix: a v5 free-prompt claim voids at the receipt
deadline today because its ~750 MB material exceeds the 16 MiB serve cap (§6a) — a submitter makes the
claim exist on chain; Final waits for the transport fix.

### 10n. ADR-0084 — the material cap, closed at the seat and the resolver, not at the constant (2026-09-04, `palw-adr0084-served-answer`)

§6l/§6m's post-cut item (a) is designed and implemented on `palw-adr0084-served-answer` (from this card's head
`b52502a6`; ADR text `docs/adr/0084-the-ids-ride-the-capture-stays-home.md`). **Three findings the ADR records that
§6l/§6m did not have:** (1) the free-prompt interval arm (ADR-0077 D8 / ADR-0082 D9) exists and fetches `O(k ×
interval)` bytes, but its two inputs came off the whole-capture pull — the job+prompt off `FPM1`/`FPC1`, and the
committed output ids off the `FPC1` CAPTURE through the DENSE decoder, which returns nothing for a graph-v5 FOLD; (2)
the STL/MIDI claims (§7b step 9) were staged by a rail run WITHOUT `--capture` and with `--retention-dir` = the
gateway's `traces` directory — a question-only `FPM1` in a directory the node never reads, so every pull was `NotHeld`,
not `TooBig`; the "750 MB" reading for those two claims was wrong; (3) nothing on the shipped path names the node's
retention directory (it is `<appdir>/<network>/palw-retention`, derived, no flag). **What the branch does,
consensus-inert:** a served answer envelope (`FPA1`: job, prompt ids, answer ids; `ATA1` on the attempt lane: anchor,
prompt ids, answer ids) bound by the seat to the claim's `output_root` by the ADR-0078 X6 recompute; the resolver
serves it in place of any material over 16 MiB; nothing over the cap is pushed and the block goes before the
announcement; the interval arm runs on the attempt lane too (QWEN36 / v5 blocks); the node reports its retention
directory over `getPalwProducerFacts` (v5) and the rail/CLI stage `<claim>.answer` beside `<claim>.material` there by
default. Unit suites green; the loopback-devnet run that measures Y1/Y6 (a v5 claim certified through the interval arm
with no capture moved) is the next step, then the fleet rebuild — after which §6m's pause of seat2's v5 production is
reversible and QWEN36 claims can reach Final.

**Correction to §6m (b), read in `params.rs` while implementing:** ADR-0065 D4 IS armed on the live chain.
`palw_rc_shipped_params()` — the function `--netsuffix=11` resolves to — calls `palw_rc_arm_phase1`, which sets
`palw_unavailable_abstains = Some(ForkActivation::always())`, and the test
`the_rc_ruleset_arms_the_unavailable_abstains_rule_from_genesis` pins it. §6m's "None on every shipped preset, pinned
by a test" read the pin on the RAW preset (`MAINNET_PARAMS.palw_unavailable_abstains.is_none()` — the assembly's input).
Item (b) therefore needs no activation; an Unavailable quorum already abstains here.

**§10n, continued (22:05 JST):** the loopback devnet on the branch (three nodes, two v5 producers, this Mac) measured before
the fix: v5 material **784,693,059 B** per attempt block with a 336-B `ATA1` beside it; the push guard refused every
announcement and all three nodes still accepted every block (Y4); each seat pooled the other executor's envelope under
`foreign/` (D2 on the attempt lane); node-2 (no artifact) filed Incapable. **No interval ever opened**: the raw-capture opener
picked the FLOOR's backend (every base0 codec decodes a v5 tuple) and derived a floor prompt. Fixed in `75bac7be` (the
capture's own shape profile id must be the class row's) with interval-lane log lines on chain facts; the fleet binary is
being rebuilt on ibm from it (the `d1ec6dcb…` staged earlier is superseded); the devnet run restarted on the fix at 22:05.

**§10n, continued (22:50 JST):** run 3 answered the seats for every a16 claim with "the capture's leaves do not reproduce
the step root" — and the material was fine (6,630,544 leaves, one root three ways). The opening assembler, the seat-side
verifier, the challenger replay and the material verifier all reached for the UNCAPPED step-leg roots, bounded by the
default ladder 2^22; the class's space is 6.6 M. Fixed in `1fcb209a` with two boundary tests (2^22+1 leaves under a 2^23
cap), ibm rebuilding from it; `082b47f7…` (the 75bac7be build) is superseded and NOT deployed. Two consensus-side
siblings (the court's refutation walkers) have the same bound and no ruleset in scope — U-08, needs an activation. Measured
on the same material: interval 0 = prefill + call 1 = 424 MB of leaf hashes, a decode interval = 7.8 MB, the opening cap is
4 MiB — no a16 opening can be served under ADR-0077 D8's format; Y1 is not reachable on this class without a design change
(ADR-0084 §7.2 lists the two). The fleet is therefore NOT restarted and seat2's v5 production stays paused (§6m).

**§10n, continued (23:45 JST) — Decision 7, and why the fleet was NOT restarted onto `cad4dd6f…`:** a seat licenses an
attempt claim only from a material it holds (pool / own retention / foreign file) and otherwise asks the opening lane; on
5f the 784 MB v5 material reached every seat through the UNCAPPED push, and ADR-0084 D3 closes that push. Deployed as it
stood, the branch would have stopped v5 attempt-lane licensing on this chain (the Studio's rewards). ADR-0084 Decision 7
(`3c6ea28b`, `c24c3b9d`): a seat that holds nothing replays the anchor's job from the fold and licenses on the roots — run
5 reproduced both roots exactly on the first try and was refused by a work comparison that does not apply to an unpriced
attempt claim; fixed, run 6 pending. The fleet binary is rebuilt from `c24c3b9d`; the restart waits for run 6's licence.

**§10n, closed (2026-09-05 00:50 JST) — the fleet runs `c24c3b9d` (sha `5c21b1a87fb2e868`), seat2 produces v5 again:** gate = devnet
run 6 licensed an a16 attempt claim by replay in 7 s with no material moved. Order seat2 → .113 (node, seat4, pool-slot@01–03)
→ ibm (node1, node0) → verify; fingerprint `71b35c25…` unchanged everywhere. **node0 wedged on shutdown** (servers stopped
15:31:14Z, then 16 min at 0 % CPU, 47 threads in futex wait — the §10-era hang signature): SIGKILL 15:46:56Z, respawned in
21 s. seat2's two production flags restored from `c-seat2.sh.pre-5f-pause`, respawned 15:48:48Z. What the new binary changes
for this chain: no material over 16 MiB is pushed (D3); seats license v5 attempt blocks by replaying the anchor's job (D7)
instead of from a 784 MB push; a served `.answer` envelope beside every material; the ladder fix for any pulled dense
material. What it does NOT change: v5 FREE-PROMPT claims still void (no a16 interval opening fits the 4 MiB lane — ADR-0084
§7.2, user decision pending), and the court still cannot refute a class above 2^22 leaves (U-08, activation needed).

### 10o. ADR-0086 — the opening carries the fold, not the leaves (2026-09-05, `palw-adr0084-served-answer`)

The operator chose ADR-0084 §7.2's first option on 2026-09-05; ADR-0086 designs it and `3d56b57a`/`62fec794` land it: the
interval opening carries the fold's digests and the Merkle frontier, the named checkpoint claim for every class, the seed row —
and no leaf hash and no state chunk; the seat replays and supplies its own leaves. **Measured on the devnet (run 7):** a
24,423,539-byte free-prompt capture (over the 16 MiB cap) was licensed `Valid` by a seat that fetched four openings of
1,110,705 / 1,110,513 / 33,655 / 1,110,449 bytes and "no history"; the attempt lane's interval 0 opening fell from
424,359,978 to 108,791 bytes. The fleet binary is rebuilt from `62fec794` (sha `7a67157217379f87`) and staged on all three
hosts; the restart follows the same order as §10n (seat2 → .113 → ibm → verify; node0 may need SIGKILL after a stuck
shutdown). What this closes on the public chain: v5 free-prompt claims can be licensed without moving their material. What
it does not: the court's refutation walkers (U-08) and the annex's P2P wiring (ADR-0085 items 4–5, ADR-0086 D6's transport).

### 10p. The free-prompt manifest was another lane's (2026-09-05, `0001f34c`)

The operator's Studio measured the edge: a free-prompt run of 256 tokens is accepted and one of 257 is refused as "the
retained-trace chunk count is not the executed shape's". The producer's `Base0ExecutionV1` carried the ATTEMPT lane's
manifest — `attempt_trace_manifest_root_v1(trace_root, 1)` and a chunk count fixed at 1, which admission pins attempts to
by equality — while the free-prompt verifier requires `chunk_count == ⌈events / 256⌉` and only checks the root for being
non-zero; every free-prompt claim on this chain so far carried a root derived by the wrong lane's function, unnoticed
because nothing recomputes it and every fixture was exactly one chunk. `0001f34c` gives the free-prompt lane its own
derivation in `produce.rs` (events = the trace's selecting-row roots, the leaves `rows_root` is the Merkle root of;
binding = the job id; `fp_trace_manifest_v3`) and routes the three backends' free-prompt outcomes through it. The Studio's
256-token cap (their `02c5bb0`) can be lifted once the gateway host's `palw-a16-fp-worker` carries this build; the fleet's
kaspad does not verify the root, so the fleet needs nothing for it. Devnet run 8 (`MAX_TOKENS=300`, two chunks and over
the material cap) is the check.

### 10q. The court reaches an over-cap class: the ruleset's ladder behind a fence, the close from served intervals, the block's leaf (2026-09-05, `palw-adr0084-served-answer`)

Three pieces the 0084/0085/0086 lane had left as "not landed", now in the tree. **ADR-0084 U-08:** the court's two
refutation walkers were pinned at `2^22` leaves by validity rules with no ruleset in scope, so no node could adjudicate a
close against a graph-v5 class (6.6 M leaves). `Params::palw_court_ladder: Option<ForkActivation>` (the `palw_da_court`
contract — `None` on every preset, absent is byte-identical, `never()` collapses, a scheduled height keeps old and new
builds peers) is read in one place at the block's own DAA and threads `step_ladder` through `adjudicate_court_close_v2`
to the leg; the tests pin the boundary at the refutation's own leaf count (one short refuses by name, at it `NoFaultFound`,
at `2^22` the uncapped answer). Arming it on testnet-11 waits for the close path below to exist live and for an operator's
height. **ADR-0085 §6 items 4–5:** the executor fills the close annex from the open court sessions on the claim (read off
the chain under its own bond, never off the request) with the accused's own tiles — replayed for the interval from a fold —
and the capture path's anchoring rule; the closer, holding no capture, asks for the interval owning the terminal leaf and
the one before it, and assembles the close from the served openings and its own replay (`refutation_from_served_intervals`,
byte-identical to the capture path's on the floor fixture under one pin). A seat's fault is remembered and the challenger's
half prosecutes that claim without `--palw-challenge` challenging everything. **ADR-0086 Decision 6:** a block-leaves
request rides the interval lane under a packed index (bit 31 | interval | block); the executor answers the block's 4,096
leaf hashes from the same span replay; the seat checks they fold to the digest it holds and names the first leaf that
differs from its own. Nothing here has been walked to a live verdict — that needs a producer that lies on a devnet.
Devnet run 9 (300 tokens) ended at the drill's `WAIT` before the panel binding at that hour's ~3-minute cadence. **Run 10
(WAIT 1800) reproduced run 8 and named it:** the seat asked node-0 for intervals 198/110/132/72 of 299 for 22 minutes and
node-0 never answered, because a fold retention carries no checkpoint state and the executor's opener replays from GENESIS
with tile capture — the offline probe on run 10's material measured interval 0 in 21 s, 57 in 298 s and 187 in 1,991 s
(5→10 s per call as the cache grows), against a 120 s solicitation window. Interval-lane refusals now log at INFO. The fix (ADR-0086 §7): the executor opens from the anchor
state it recomputes without capture and memoizes, as the seat does; not in this tree yet, so free-prompt claims past ~20
decode tokens on graph-v5 cannot be licensed by the interval lane — Studio's 256-token cap stands, for this reason now.

### 10t. What testnet-11 added to the devnet's proof: four operator defects between an honest answer and a receipt (2026-09-05)

The devnet licensed a 300-token claim ten minutes after the binding (§10s). Taking the same claim through testnet-11 found
four things the devnet could not, because on the devnet one process is executor, seat and producer at once:

1. **A bond sized for the canonical job cannot carry a long one.** Exposure is `pwu × slash 5`; a 300-token graph-v5 claim
   is ~42 M leaves ≈ 211 M sompi, and a bond may hold half its collateral. slot-04 (265 M, sized from the class's 6.6 M-leaf
   canonical job) had every long commitment dropped by the chain with `FreePromptExposureCeiling`. slot-05 was created at
   600 M (`POST /pool/v1/slots {"mode":"fp","bond_collateral":…}`, new) and carries exactly one such claim at a time.
2. **The pool's submitter staged the question, not the answer.** `fp-autosubmit.py` called the rail without `--capture`, so
   the node retained a 3,372-byte `FPM1` beside a 183 MB capture in the gateway's traces — no seat could ever have been
   served an interval. Fixed; the live claim's `FPC1` was assembled by hand (it is the `FPM1` body plus the capture as a
   borsh `Vec<u8>`).
3. **A free-prompt slot's node could not open what it retained.** `run-slot.sh` passed no `--palw-class-artifact`, so
   `resolve_backend` failed and every interval request was answered "not held". Fixed for `mode=fp` slots.
4. **Two artifacts of one class, and the seats resolved the wrong one.** `qwen25-1.5b-a16.palwart` and
   `bound-candidate.palwart` differ only in the tokenizer commitment; the node's holding map keeps the FIRST file loaded for
   the family, so every seat resolved the unbound one, recomputed a different job context, and refused the executor's honest
   answer: "a served answer's ids recompute output root 91cfcdaa… and the claim committed 0658d893…". The probe
   `probe_output_root` (new, ignored) recomputed `0658d893…` from the served envelope with the bound artifact and
   `91cfcdaa…` with the unbound one, which named the defect in one run. The seats now list only the bound artifact, and the
   first seat to do so drew `[212, 189, 130, 195]` of 299 and asked the executor.

**And one bound that was simply too small.** An interval opening is computed, not fetched: on .113 (eight shared cores)
interval 212 took 398 s where the devnet's quiet machine takes 17–90 s, so every answer arrived after the seat's 120 s
solicited window and was dropped as unsolicited. `PULL_SOLICITED_TTL` is now 900 s (`85e44275`), and the fleet runs
`c71613157fd396d6`. The first claim (`019efe78…`) still ran out its receipt window during the diagnosis and voids
unanswered; the retry fires as soon as the bond's exposure is released.

### 10s. The 300-token free-prompt claim licenses again: the opener resumes from a recomputed anchor (2026-09-05, `594015b9`, fleet `56f77a3d`)

Run 10 named the cause (§10q addendum): a fold holds no checkpoint state, so the executor's opener replayed every
interval from genesis with tiles captured — 5–10 s a decode call, 1,991 s for interval 187. `594015b9` hands the fold
opener an anchor-state closure: the three backends recompute the span's starting anchor with their recompute kernels
(a plain forward, memoized as the seat's own state is) and replay only the interval's calls with tiles; the lane also
refuses a re-ask while an opener for that `(claim, interval)` is in flight. Offline on run 10's material: interval 0
17 s, 57 19 s, 187 69 s, 253 90 s, 298 54 s. **Devnet run 11 (300 tokens): node-0 opened `[34, 105, 134, 209]` in
17–65 s, node-1 replayed all four against its own state and filed `Valid` ten minutes after the binding.** The
fleet runs it: kaspad `56f77a3d75f376de` on seat2, .113 (node, seat4, slots 01–04), ibm (node1, node0); the pool's
`palw-a16-fp-worker` `69c0e194955cc41c` on .113. **Testnet's next wall is economics, not code:** a 300-token
free-prompt claim is ~41 M leaves, exposure `pwu × 5` ≈ 207 M sompi, and a bond may hold half its collateral — the
pool's slot-04 bond (265 M, sized for the class's canonical 6.6 M-leaf job) cannot carry one, which is also why the
257/300-token jobs it submitted at 03:06Z/03:11Z never reached the chain. The pool now accepts a caller-sized bond;
slot-05 (600 M sompi, token `78ffd436…`, gateway port 18795) was funded 8.5 MSK from the faucet wallet, registered its
bond `8c52206c…:0` at 06:12Z (its panel gives a carrier ten minutes and testnet-11 mines a block about every ten, so the
first attempt timed out and the second found the bond already there), and answered a 300-token request in 222 s
(42,272,640 leaves, claim `019efe78…`, submitted as tx `0415254c…`). **A second pool defect surfaced there:** the
autosubmitter called the rail without `--capture`, so it staged the question-only `FPM1` — 3,372 bytes of retention
beside a 183 MB capture sitting in the gateway's own traces — and no seat could have opened an interval. The capture is
now staged for the live claim (`FPC1` is the `FPM1` body plus the capture as a borsh `Vec<u8>`, so it assembles from the
two files) and `fp-autosubmit.py` passes `--capture` from now on (`/opt/misaka-minerpool/`, backups `.pre-capture`,
`.pre-anchor`). Studio needs the slot token and the 256-token clamp lifted (`backend/gateway.rs`) to use this lane.

### 10r. ADR-0087 implemented: a position is bought from the curve and sold back to it (2026-09-05)

The model market is in the tree behind `Params::palw_model_market` (`None` everywhere): a class's
market is a constant-product curve over its reserve plus a 1,000 MSK virtual reserve, opened by the
first `ModelBuy` (a carrier paying into the class's `OP_RETURN "MSKMDL01" <class>` sink), drained by
`ModelSell` (signed by the holder's key, paid through the coinbase like every escrowed reward), 5 %
burned and 1 % to the registrant on every leg, no transfer object of any kind. The state root takes
the two collections only once a move exists — the root rides in headers, so a dormant chain commits
byte-identical roots — and the served carriage grows a tagged tail rather than a field. Two RPCs and
four CLI verbs read and move; 12 tests pin the ADR's invariants, and the design's worked table was
corrected by them (the second buy releases 16,824 positions, not 12,846; a full sell returns the
1,880 MSK reserve, not 3,014). Not done: the explorer page, the devnet buy/sell/retire/drain drill,
and the activation height on testnet-11.

### 10u. The first 300-token free-prompt receipt on the public chain — and the two defects between it and a quorum (2026-09-05)

**`ibm-node0` filed a `Valid` receipt for claim `019efe78…` at 16:06:39+02:00**: four drawn intervals
(187, 101, 62, 11 of 299) replayed against state the seat recomputed for itself, no history fetched.
That is the devnet's proof repeated on the public chain — the fold opener of `594015b9` works where
the 1,991 s genesis walk could not. Two things stood between that receipt and the panel's quorum of
three, and both were found by reading the seats rather than the executor.

**One class, two artifacts — the fifth instance, on the seat that never drew.** `seat2` warned every
three minutes that "a served answer's ids recompute output root `91cfcdaa…` and the claim committed
`0658d893…`", and refused the answer before any replay. Nothing was wrong with the answer: the seat
loaded `/root/palw-class/qwen25-1.5b-a16.palwart` where every other seat loads
`bound-candidate.palwart`, holdings deduplicate per family so the unbound file won, and the class
facts that go into `palw_fp_job_context_v3` were a different model's. The two files are the same
size and differ in sha256 (`a8c4e53e…` vs `3f8fc506…`) — a difference nothing on the host printed.
Copied and swapped (`c-seat2.sh.pre-bound`), the seat drew intervals on its first tick.

**Nothing bounded the number of intervals one executor opens at once.** The gossip lane refuses a
second asker for a pair already being opened, but three seats × four drawn intervals are twelve
DISTINCT pairs, and the executor ran six to eight fold replays concurrently. On a 24 GB host that is
12 GB of swap: openings went from ~30 s to 137–398 s, the same interval was recomputed for each
asker (187 twice, 101 twice, 11 three times), and twice the node stopped answering for forty minutes
with no line in its log and would not take SIGINT — SIGKILL both times. `1d81feec` gives the panel a
`served_openings` cache keyed by the request as served and an `opening_gate` that puts one opening
at a time on a node; the same work then costs the same CPU and the first answer arrives in a
fraction of the time. **Fleet load is a live variable, not a constant:** four hosted producer slots
sharing the executor's box is what put it into swap in the first place.

### 10v. LICENSED: the 300-token free-prompt claim carries a panel quorum on the public chain (2026-09-05 16:59Z)

Claim `019efe78…` — 300 decode tokens, 299 intervals, class `4277d84f…` (`qwen25-a16`), executor bond
`8c52206c…:0` on pool slot-05 — is **`receipt_licensed`**. Three seats replayed four drawn intervals
each against state they recomputed for themselves, and **not one of them fetched a capture**:

| seat | drew | `Valid` filed |
|---|---|---|
| ibm node0 | 187, 101, 62, 11 | 14:06:39Z |
| .113 node (seat 6) | 90, 218, 287, 206 | 15:21:26Z |
| seat2 (5.104.81.23) | 278, 222, 159, 47 | 16:52Z |

The answer the gateway returned at 06:22Z recomputes the root the chain licensed —
`output_root 0658d893…` on both sides, `job_context_hash acf9093d…`, 300 ids. `derived-verify`
declines it by design (ADR-0078 X4: a prose answer carries no derivation and still certifies), so
the check is the root, not the DSL.

**A third serving defect, and the one that explains the silence.** `serve_interval_opening` marked a
pair in flight, awaited the blocking opener, and cleared the mark on the NEXT LINE — which never
runs when the future is dropped. Two of seat2's intervals were computed, not delivered, and then
permanently unaskable: every later ask was refused as `Throttled`, which is logged at debug, so the
lane went silent rather than wrong. The fact that named it was **zero cache hits** while a seat
asked every minute for bytes the executor was holding. `16df8d7e` makes the mark an RAII guard;
the blocking task is not cancellable, so the opening still lands in the cache — and the moment
seat2 asked again, `request 0x9f` and `request 0x2f` were answered from cache in milliseconds and
the seat held four. **A slow answer is a lost answer on this lane; the cache is what makes the
second ask cheap enough to win.**

### 10w. The pair is seeded, and the reward buys it: ADR-0090 and ADR-0091 (2026-09-06, `palw-adr0088-0089-impl`)

10r above is the ADR-0087 design as first built, and two ADRs have moved it since. Both are behind
the same three dormant fences (`palw_model_market`, `palw_model_lines`, `palw_model_evm`, `None`
on every shipped preset), so this section changes nothing about the live chain until they are armed
— which is one release, and the only thing still outstanding for either ADR.

**[ADR-0090](../adr/0090-the-pair-is-seeded-with-real-msk-locked-for-good-and-a-position-is-whole.md)
— the pair is made, not conjured.** The virtual reserve and the lazy opening are gone: a line's
market exists only once a **seed of at least 100,000 MSK** reaches its sink, and the whole seed
becomes the reserve, fee-free and never payable out (the curve's product never falls, so the
reserve never falls under the seed). A position is **whole** — one unit, no fraction — and there
are **500,000** a line, so 10r's worked numbers (positions of 10^6 units, a 1,000 MSK virtual
reserve) do not describe today's curve. A third move rides beside the buy and the sell on both
lanes: the carrier object `ModelSeed`, the writer's action 3, the facade's `seed()`.

**[ADR-0091](../adr/0091-the-reward-buys-the-pair-and-no-holder-is-paid.md) — the reward buys the
pair, and no holder is paid.** At a claim's `Final`, **5 % of its escrowed worker reward** (the
ADR-0042 Decision 10 carve, which on every shipped preset is the miner's whole subsidy reward)
buys from the pair of the **line the claim ran**, and the miner is named the other **95 %**. The
slice takes no leg and gives nobody a position: what the curve gives up is **retired**, held by
the chain for good, so `positions in the curve + every holder's + retired = 500,000`. A line with
no pair, a pair closed to buys, or a claim the registry attributed to nothing pays its miner in
full — nothing is burned for a model. Nothing is ever distributed to holders; the only thing
mining does for a holder is raise the price the curve will pay them when they sell. On this
network's pre-deflationary subsidy the escrow is 2.29690373 MSK a block, the slice 0.11484518 MSK
and the miner's 2.18205855 MSK, which lifts a freshly seeded pair from 0.2 to 0.20000022 MSK a
position and about +2.5 % over a month of such blocks.

Read on the row and both windows as `seedSompi` / `seededBy` / `seedMinSompi` (wire 3) and
`buybackSompi` / `retiredUnits` (wire 4; the AMM window's `market()` appends two words, so every
earlier offset holds). The market's front end is <https://misakaoptions.com>. Both ADRs are drilled
on a private devnet with the three fences armed from genesis
(`scripts/drills/misaka-palw-model-market-devnet-e2e.sh`, `--palw-model-devnet=0`).
