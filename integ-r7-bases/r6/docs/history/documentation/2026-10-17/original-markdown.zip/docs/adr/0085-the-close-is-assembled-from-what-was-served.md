# ADR-0085: The close is assembled from what the executor served — a disputed tile, not a capture

> **PALW共通前提 — 2026-10-10:** [ADR-0176](0176-bond-bounds-palw-production-rewards-and-final-weight.md)を適用する。確率的検証・公開反証・客観裁定に加え、bondと共通DAA期間がclaim発行能力、ブロック数、報酬総額、Final後の確定weightの上限を決める。
> モデル計算はその枠を使用するための正当な仕事であり、同額bond・同期間・同倍率なら計算省略や高速偽造で枠は増えない。有罪なら報酬失効と適用規則上の担保損失を負う。claim容量の倍率を上げてもbond当たりの総経済・consensus creditは増やさない。
> 将来のPALW設計・受入条件に適用し、過去の実測・実装記録・旧claim規則は保持する。上限は検出能力の証明ではなく、公開検証・徴収可能担保・責任保持・独立試験と明示的upgrade/activationを要する。
> **モデル入手への不介入 — 2026-10-10後続改定:** [ADR-0177](0177-model-bond-allocation-without-availability-consensus.md)を優先する。MISAKA Torrent・専用Seeder・Seeder報酬の概念を廃止する。モデル配布・取得可否を合意で管理せず、PoR/全量取得監査/TRDC/FPRによる資格・weight停止も撤回する。モデル別coinbaseは重複のない拘束miner bond元本に連動し、総発行予算と個別bond上限を維持する。
> 固定モデル同一性とclaim固有証拠の裁定は維持する。外部検証は正しいモデルを入手できた条件で成立し、公開参加の経済優位は倍率式・敵対的評価で立証する未完の目標である。過去の実装/試験/旧規則は保持し、新配分は未実装・未有効化である。


> **Mission alignment, 2026-10-07:** [ADR-0173](0173-public-verifier-dispute-completeness-is-misaka-purpose.md) governs future PALW design. Where the earlier body conflicts with ordinary non-Panel public-bond prosecution from authenticated public material, without producer-private state, the dated amendment at the end supersedes that direction. Earlier Status, measurements and activation records are preserved; this is not a claim of implementation or activation.


**Status:** PROPOSED (2026-09-04). §6 items 1–3 LANDED 2026-09-04 (see §7); items 4–5 are being built under the 2026-09-05 goal, with ADR-0086 Decision 6's transport (the block-leaves annex) riding the same lane. Consensus-inert
by construction: the refutation object (`PalwExecutionStepRefutationV1`), the adjudicator
(`check_execution_step_refutation_v1`) and every court object are unchanged; what changes is how a
party that holds no capture ASSEMBLES the close, and what the executor serves it.
**Builds on:** ADR-0084 (the seat needs the answer's ids, never the history; the material lane
serves the envelope for a capture over the cap), ADR-0077 Decision 8 / SA-2 (the interval lane,
authenticated), ADR-0082 Decisions 4, 7 and 9 (the tile-addressed bottom; the fold; the seat
recomputes the cache), ADR-0073 Decision 1c (a free prompt is carried into the close), audit3 S-01
(the close is assembled from the ACCUSED's bytes by whichever party makes it).
**Amends:** nothing. ADR-0084 §8 named this as U-07c and left it undecided; this decides it.

## 1. What was measured

On the ADR-0084 branch, a v5 attempt claim's material is **784,693,059 bytes** (the loopback
devnet, 2026-09-04 19:30 JST — the card's 748 MB to the byte), the executor stages a 336-byte
`ATA1` beside it, the transport refuses to announce it, and a seat obtains the envelope, binds it
and can certify without the capture. The court cannot close the same claim from the challenger's
side. `kaspad/src/palw_panel.rs`'s terminal arm reads:

```
let Some(accused) = accused_capture.as_deref() else {
    // **And ASK for it.** … pull_for_close.push(duty.claim_id) …
    "the close needs the ACCUSED capture and this node holds none — pulling"
```

and the pull now answers with the envelope, which `verify_material` does not match, so the arm
stalls at that line until `window_court` ends. `refutation_for_free_prompt_index(&accused_bytes,
index, ids)` (`qwen25_a16_backend.rs::refutation_with_prompt`) needs the WHOLE retention: it
re-derives every step tile (`tiles_from_material_v1`, which on a fold replays the run), the rows
root over every logits row, and the checkpoint chunks. For a class over the cap the only party that
holds those bytes is the accused. An honest executor closes its own case; a dishonest one does not
close it, and nobody else can. ADR-0084 moved that failure from certification to the court; this
ADR removes it from the court.

## 2. What a close actually needs, term by term

`base0_refutation_from_capture_capped_v1` builds the refutation from six things. Where each can
come from when the challenger holds no capture:

| term | in the refutation | source without the capture |
|---|---|---|
| the binding | `binding` | every interval opening carries it (`Base0FpIntervalOpeningV{1,2}.binding`), and it is what `execution_root` commits |
| the target's output tile | `output_preimage`, `output_opening` | **the accused's, and only the accused's**: for a real fraud the challenger's recompute differs at exactly this leaf, so its own tile opens against nothing. Must be SERVED. The opening path is derivable from the interval's range opening (leaf hashes + siblings, `step_merkle_range_siblings_v1`) once the leaf hash is known |
| the activation inputs (prior tiles of the same interval) | `inputs` rows opened against the step leg root | the challenger's own replay of the interval (`base0_fp_replay_interval_v1` with tiles captured), CHECKED against the accused's committed leaf hashes in the range opening — the dissection stops at the FIRST disagreement, so every prior leaf of the accused equals the challenger's; a prior leaf that does not is a different first fault, and the seat's `Fault { leaf_index }` names it |
| the KV anchor (checkpoint operands) | `kv_checkpoint` | the challenger's recomputed state at the interval's checkpoint (ADR-0082 D9), whose tiled root the seat already compared to the accused's committed checkpoint leaf; the leaf and its opening come with a V2 opening (`Base0FpCheckpointClaimV1`) |
| the weights | `operand_openings_for` | the challenger's own artifact, against the class root — unchanged |
| the decode pin | `decode_tokens: TiledV1 { rows_root, generated_token_ids }` | `generated_token_ids` off the ADR-0084 envelope; `rows_root` is a 64-byte value the accused committed inside `trace_root` (`tiled_logits_outer_root_v1(ctx, rows, rows_root, generated)`) and is verifiable against the binding by `check_tiled_decode_pin`. Must be SERVED — it is a function of every row |
| the prompt | `prompt_token_ids` | the envelope (`FPA1`) or the anchor's derivation (attempt lane) — ADR-0084 |

So exactly two things must come from the accused: **the disputed tile's preimage** and **the rows
root**. Everything else the challenger recomputes and checks against roots the accused committed.

## 3. Decisions

**Decision 1 — the interval opening gains a close annex, served on the same authenticated lane.**
`Base0FpIntervalOpeningV3` = V2 + `close: Option<Base0FpCloseAnnexV1 { rows_root: Hash64,
disputed: Vec<(u64, PalwStepTileLeafV1)> }>`. The executor's `open_retained_interval` consults the
chain for open court sessions on the claim (`palw_court_duties_v2` names the session and its
`terminal_index`); when a terminal index falls inside the interval being opened, the annex carries
that leaf's tile and the rows root. No new P2P message and no new request tag: a challenger asks
for the interval containing the terminal index over the existing `PalwIntervalOpeningRequest`,
and the answer is one opening, bounded by the same cap (`PALW_INTERVAL_OPENING_MAX_BYTES`; a tile
is one `PalwStepTileLeafV1`, kilobytes). A V3 opening without an annex is a V2 opening to every
existing reader: the seat's replay ignores the annex.

**Decision 2 — the refutation is assembled from an opening and the challenger's own replay.**
`base0_refutation_from_opening_v1(profile, ctx, opening_v3, replay: &Base0StepTilesV1 (the
challenger's tiles for the interval, hashed and CHECKED leaf by leaf against `opening.range.
leaf_hashes` up to the target), checkpoint_state, target, prompt_ids, cap)`:
1. every leaf hash of the challenger's replay below the target must equal the accused's committed
   hash in the range opening — otherwise the first unequal leaf is the real target and this call
   refuses by name (the caller reopens the court's question there);
2. the output tile is the annex's, its opening is derived from the range opening;
3. the inputs are the challenger's prior tiles with openings derived the same way; the KV anchor
   is the recomputed state's chunks opened against the checkpoint leaf the V2 anchor names;
4. the pin is `TiledV1 { rows_root: annex.rows_root, generated_token_ids }`, which
   `check_tiled_decode_pin` binds to the binding before any arithmetic.
The object this produces is byte-for-byte the object the capture path produces for the same
(claim, index) — pinned by a test that builds both from one fixture run.

**Decision 3 — the terminal arm tries the opening path before it pulls.** When the closer holds no
matching capture: derive the interval containing `terminal_index`, request it (the interval lane
the seat already drives), and on arrival assemble with Decision 2. The whole-capture pull stays as
the fallback for classes whose captures fit. The stall reason changes from "holds none — pulling"
to "waiting for the interval's close annex", which is a fact about the accused's serving.

**Decision 4 — a seat's `Fault { leaf_index }` is a court case it can prosecute.** The seat that
found the first unequal leaf during its interval replay already holds the challenger's side of
Decision 2's inputs (its own tiles for that interval and its recomputed state). ADR-0077 Decision 8
says a sampled verdict never slashes; this ADR does not change that. It says the seat may open a
court AT that leaf with `--palw-challenge`, and Decision 3 lets it close.

## 4. Costs

* Per close: one interval opening (≤ 4 MiB by the lane's cap, kilobytes in practice) plus the
  challenger's replay of one interval with tiles captured — the interval's rows, not the run's.
* Executor: one chain read (open sessions on the claim) per interval served; one tile per open
  session in the interval.
* Nothing on chain moves.

## 5. Invariants the tests must hold

```
X1  For one fixture run, base0_refutation_from_opening_v1 and base0_refutation_from_capture_capped_v1
    produce byte-identical refutations at every main-step leaf, on both retention forms.
X2  A tampered tile at leaf t: the seat's replay names Fault { t }; the refutation assembled from
    an opening whose annex carries the accused's tile at t convicts under
    check_execution_step_refutation_v1; the same assembly with the challenger's own tile at t
    refuses to assemble (its hash is not the committed one).
X3  A V3 opening without an annex verifies as a V2 opening on every existing seat path.
X4  The annex is served only for a leaf an open court session names; a request for any other
    interval carries none.
```

## 6. Order of work

1. `Base0FpIntervalOpeningV3` + `Base0FpCloseAnnexV1`, encode/decode, X3.
2. Per-interval replay with tiles captured (the fold's `dense_capture_from_fold_v1` restricted to
   one interval), and the leaf-path derivation from a range opening.
3. `base0_refutation_from_opening_v1`, X1, X2.
4. Executor: the annex in `open_retained_interval` (chain read of open sessions), X4.
5. Challenger: the terminal arm's opening path (Decision 3); Decision 4's seat-opened court.

## 7. Implementation record (2026-09-04, `palw-adr0084-served-answer`)

**Landed — §6 items 1–3, base0 and consensus-core only, no node wiring:**

| item | where | what |
|---|---|---|
| 1 | `misaka/palw/base0/src/fp_interval.rs` | `Base0FpIntervalOpeningV3` = v2 + `Option<Base0FpCloseAnnexV1 { rows_root, disputed: Vec<Base0FpDisputedLeafV1 { leaf_index, tile, anchor }> }>`, magic `MSKFPIV3`; the any-decoder hands every seat the v2 view (X3); `base0_fp_interval_close_annex_v1` is the closer's read. The annex names, per disputed leaf, the checkpoint claim its step is anchored to — the leaf and its opening against the checkpoint leg root are the accused's leg's, and an interval opening's own anchor names only the interval's START |
| 2 | `consensus/core/src/palw_step_leg.rs`; `fp_interval.rs` | `step_opening_from_range_v1` and `step_range_siblings_from_range_v1` (paths derived from a range opening, pinned byte-identical to the built ones over every leaf/sub-range of every leaf count ≤ 24/20); `base0_fp_replay_interval_tiles_v1` and `Base0FpIntervalKernelsV1::replay_interval_tiles` (the one required verb; the seat's hash check is provided over it); `base0_fp_challenger_replay_tiles_capped_v1` (the seat's derivation up to the replay, returning the v2 opening and the challenger's tiles) |
| 3 | `misaka/palw/base0/src/legs.rs` | `base0_refutation_from_opening_capped_v1(profile, ctx, intervals: &[(opening, replay)], annex, target, prompt, pin, recomputed_chunks, cap)`; `LegError::CloseFromOpening(&str)`. **X1 holds on the floor fixture**: at every main-step leaf of every interval, the refutation equals the capture path's byte for byte, and a forged annex tile is refused by name |

**Two things the implementation taught the design (recorded in the code):**

* **A step at an interval's first call reads the call before it**, whose tiles sit in the PREVIOUS
  interval's range — so the closer holds two served intervals, the disputed one first and its
  predecessor, and the builder finds each input's holder among them (an input run that straddles two
  ranges is refused by name; none occurred on the fixture).
* **The annex's anchor IS the anchoring decision.** The capture path anchors when the executor's leg
  holds a checkpoint covering the call before the disputed one and builds the long form otherwise;
  the executor applies the same rule when it fills the annex, and the closer anchors exactly when an
  anchor was served.

**Landed — §6 items 4–5 (2026-09-05, node wiring on `kaspad/src/palw_panel.rs`, base0 seams in
`fp_interval.rs`, four backend methods):**

| item | where | what |
|---|---|---|
| 4 | `open_retained_interval` → `PalwExecutionBackendV1::open_fp_interval_with_close` | The executor reads the open court sessions on the claim off the CHAIN (`palw_court_duties_v2` under its own bond, `terminal_index`), never off the request, and serves the interval with `Base0FpCloseAnnexV1` for the named leaves inside it. `base0_fp_close_annex_v1` builds the annex from the accused's own tiles — replayed for the interval from a fold (`base0_fp_interval_tiles_from_fold_capped_v1`), held by a dense retention, the seed row off the opening itself — with the capture path's anchoring rule (a cache-reading step past call 0 carries the checkpoint before it); `base0_fp_interval_opening_with_close_v1` attaches it to the V4 (or V3) bytes. A leaf outside the interval is another interval's; a leaf no session names is served no tile. |
| 5 (D3) | the terminal arm → `close_source_from_served_intervals_v1` → `refutation_from_served_intervals` | When the closer holds no capture matching the claim's roots and the claim is free-prompt: the interval owning the terminal leaf (`fp_interval_of_leaf_v1`) and the one before it are looked up in the held openings; the primary must carry an annex naming the leaf. Missing ones are asked for on the interval lane (25-DAA throttle per pair, `intervals_for_close`, after the loop like the pull) and the stall reads "waiting for the interval's close annex". Held, `base0_refutation_from_served_intervals_capped_v1` replays each with the family's kernels from the seat state (memo warmed as the row check warms it), hands ADR-0085's builder the V2 views and tiles, the annex, the tiled pin (`rows_root` from the annex, the answer's ids off the served payload), and the primary interval's anchor chunks. Attempt-lane claims keep the pull. |
| 5 (D4) | `interval_seat_outcome_v1` → `seat_faults` → the challenger's half | A seat's `Fault { leaf }` / `FaultInRange` is remembered per claim (bounded); the challenger's loop prosecutes a remembered claim whether or not `--palw-challenge` challenges everything (the disputable-claims list is still the chain's, the fault only selects). With ADR-0086 Decision 6 the block is refined to a leaf first. |

Pinned at the base0 layer (`a_close_from_served_intervals_is_the_close_from_the_capture_and_the_annex_changes_no_verdict`):
on the floor fixture, for every main-step leaf of every interval, the served path's close equals
the capture path's byte for byte under the same tiled pin; the annexed V4 verifies exactly as the
plain one (X3 on V4); an annex naming another leaf does not close this one. What is NOT
exercised: a live court reaching a close through this path — that still needs a faulty producer
on a devnet (the two-node court harness §7's first paragraph names does not exist).

**What the implementation taught.** The chunks a served-interval close hands the builder are the
primary interval's anchor state — the checkpoint before the interval's first call — which on a
per-call class at checkpoint interval 1 (graph-v5) is the checkpoint before every step in the
interval. On a wider cadence a mid-interval step's anchor is a state the seat's replay passes
through and does not keep; the builder's anchor check refuses it by name rather than closing
wrongly. Recorded in §8.

**2026-09-11 — against a liar ([ADR-0111](0111-a-seat-may-demand-the-committed-leaf-it-needs-to-judge.md) §8.5).**
The pin above runs an honest executor, and the path it pins could not close a lying interval. A
V4 opening carries no leaf hashes, so the replay walked the committed root with the closer's OWN
leaves, and a lie inside the interval is exactly what stops that walk. The close now also holds
the executor's leaves for the one block the closer's leaves differ in (ADR-0086 Decision 6's
block-leaves lane). It substitutes them once they fold to the opening's digest, and walks the root
over the committed range. The node asks for that block beside the interval. Against the drill's
one-tile lie on the graph-v5 dense row, the served close is the capture path's object and
convicts.

## 8. What is deliberately not decided

* A served-interval close for a mid-interval step on a class whose checkpoint cadence is wider
  than one call: the seat state the builder needs is transient in the replay; keeping it is a
  recompute-kernel change, taken when such a class exists.
* Whether the annex should ride the answer envelope instead (`rows_root` could; the disputed tile
  cannot, because it is not known until a court names a leaf).
* The attention dissection's bottom (`PalwAttnDissectBottomV1`) already opens tiles on chain for a
  fused node; whether Decision 2 should read the bottom disclosure for those nodes instead of the
  annex is left to the implementation, which will find out which is smaller.

## 9. Number hygiene

This is ADR-0085; ADR-0084 is the last on this branch. A concurrent claimant renumbers the later
writer, per ADR-0036 Decision 5.

## Mission alignment amendment — 2026-10-07

close assembled from served materialという原則を普通の非Panel bondまで適用する。close annexの取得をseatだけに限定したり、court前に必要なmaterialが取れない循環を残したりしない。served valuesはproducerのcommitmentに認証する。

* 必要なinput/weights/state/trace/openingは、選出されていない普通のpublic bondがclaim commitmentに対して認証・取得できなければならない。producerだけのcapture、FOLD prefix、tile preimageや内部proverを前提にしない。ローカル保管・off-chain配布は可能だが、開示または有界の客観的非開示裁定を最後まで持つ。
* 不正の発見と、その後の客観的局所化・裁定の成立を分ける。honest seatの存在、raw sampling、選出outsider、quorumだけで全不正の検出を保証しない。ADR-0171の全constraint検査とresidual error、ADR-0172のversioned Kernel境界を維持し、巨大な無界replayやVM/TEE/BFT authorityを代替条件にしない。

本amendmentは衝突する将来の設計・受入条件を改定する。既存の実装・測定・fenceの記録はそのまま保持する。変更する合意規則は別のversioned移行を必要とする。Panel=0は[RFC14](../rfc/0014-panel-independent-fraud-prosecution.md)の全completion gatesと[RFC15](../rfc/0015-panel-free-permissionless-verification.md)固有gateが成立するまで有効化しない。
