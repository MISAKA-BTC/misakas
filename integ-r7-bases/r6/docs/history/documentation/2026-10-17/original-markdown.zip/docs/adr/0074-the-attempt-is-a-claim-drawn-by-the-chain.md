# ADR-0074: The attempt is a claim, drawn by the chain

> **PALW共通前提 — 2026-10-10:** [ADR-0176](0176-bond-bounds-palw-production-rewards-and-final-weight.md)を適用する。確率的検証・公開反証・客観裁定に加え、bondと共通DAA期間がclaim発行能力、ブロック数、報酬総額、Final後の確定weightの上限を決める。
> モデル計算はその枠を使用するための正当な仕事であり、同額bond・同期間・同倍率なら計算省略や高速偽造で枠は増えない。有罪なら報酬失効と適用規則上の担保損失を負う。claim容量の倍率を上げてもbond当たりの総経済・consensus creditは増やさない。
> 将来のPALW設計・受入条件に適用し、過去の実測・実装記録・旧claim規則は保持する。上限は検出能力の証明ではなく、公開検証・徴収可能担保・責任保持・独立試験と明示的upgrade/activationを要する。
> **モデル入手への不介入 — 2026-10-10後続改定:** [ADR-0177](0177-model-bond-allocation-without-availability-consensus.md)を優先する。MISAKA Torrent・専用Seeder・Seeder報酬の概念を廃止する。モデル配布・取得可否を合意で管理せず、PoR/全量取得監査/TRDC/FPRによる資格・weight停止も撤回する。モデル別coinbaseは重複のない拘束miner bond元本に連動し、総発行予算と個別bond上限を維持する。
> 固定モデル同一性とclaim固有証拠の裁定は維持する。外部検証は正しいモデルを入手できた条件で成立し、公開参加の経済優位は倍率式・敵対的評価で立証する未完の目標である。過去の実装/試験/旧規則は保持し、新配分は未実装・未有効化である。


> **New verification-challenge scope — 2026-10-08:** The chain-derived/no-attestation principle remains. [RFC07 Part VI](../rfc/0007-palw-verification-certificates-and-algebraic-checks.md#post-commit-challenge-protocol) owns the new conformance/algebraic challenge source and seed. Its qualifying future independently Final useful work is not the legacy first-algo-6 ticket/Panel draw or a cheap fallback floor. Do not inherit unpredictability from algo id or inference cost alone, or reinterpret this ADR's legacy seeds. Source scarcity leaves the new checks pending while current heartbeat/BASE-0/transaction liveness continues; no BFT/DNS beacon authority is added.

> **Mission alignment, 2026-10-07:** [ADR-0173](0173-public-verifier-dispute-completeness-is-misaka-purpose.md) governs future PALW design. Where the earlier body conflicts with ordinary non-Panel public-bond prosecution from authenticated public material, without producer-private state, the dated amendment at the end supersedes that direction. Earlier Status, measurements and activation records are preserved; this is not a claim of implementation or activation.


> **Status amendment (2026-09-18, ADR-0137):** past `Params::palw_work_target` — testnet-11's DAA 6,001 flag day —
> a class's *share* is a **result**, not a lottery input. The class target, the class DAA, the epoch budget, the
> admission-derived share and the seat price this ADR specifies are **not read** past the fence: a block draws
> against `CCU / W` (one network-wide work target) and the readers report the rolling share of finalized work.
> Below the fence the text stands as the rule it was; see ADR-0137 §3–§5 and §22.

**Status:** PROPOSED (2026-09-02), decided by the user on two points that this ADR only spells
out: (1) the attempt lane adopts the beacon draw (ADR-0073 Decision 3c's open option), and
(2) **the beacon is a fact derived from the chain a node already holds — never an attestation, a
quorum, a validator set, or a finality overlay.** The last beacon this project built was wired to
validators and the design became BFT-dependent; this one is forbidden from reading anything a
validator says. Ships in the Relaunch 5 re-genesis (5d) together with ADR-0072 + D8 and
ADR-0073 Phase ①, deployed as a rolling host swap (the fingerprint moves, so un-wiped peers are
refused at handshake and cannot re-feed the old chain).
**Builds on:** ADR-0044 (the receipt lane: commit, beacon, quantum, spend), ADR-0072 (+ D8: the
self-drawn ticket and its pins), ADR-0073 (court → unit → weight → share).
**Amends:** ADR-0073 Decision 3 (this is the "one unit" and the "lottery discipline" made
concrete), ADR-0044 Decision 7 (CU weights withdrawn), ADR-0071/0072's premise that the attempt
lane is the primary lane.

> **Landed, then amended (index reconciliation, 2026-09-02).** §7 records what landed; Decision 5
> is as landed (`7676d461`: the quantum is an eighth of the class's own canonical job). Decision 6
> is amended by [ADR-0075](0075-certification-is-a-consensus-object.md) (the certified set is chain
> state; a class's free-prompt lane is opened by `ClassLaneCertified`), and
> [ADR-0076](0076-the-attempt-lanes-seed-is-the-retargets-equilibrium.md) seeds the attempt lane's
> per-class target on top of this ADR's draw. Map: [`README.md`](README.md).

## 1. Why a beacon, and why not a validator

The ADR-0072 review found that a ticket drawn from the executor's own hash is only as strong as
every field inside it being pinned; one unpinned u64 made one inference worth 2^64 draws. D8
closed the field, and the invariant ("every priced field is an equality against chain state, a
function of the execution the panel replays, or the position") is now a test. But the receipt
lane has no such surface at all: a claim is fixed on chain first, the beacon that draws it does
not exist yet, and the ticket is `H(beacon ‖ claim ‖ quantum)`. Nothing the executor controls is
inside the draw. That is the discipline both lanes are held to from here: **a draw is a paid
execution, drawn from a value the executor cannot vary after paying.**

A beacon is only as good as its independence from every party that wants a particular value.
The receipt lane's beacon is the first self-drawn (algo-6) chain block at or after the claim's
slot, derived by walking the chain (`derive_beacon_fact_v3`) and validated by two inequalities
(`validate_beacon_fact_v3`): its producer paid an inference for the block, so grinding a beacon
costs an inference per candidate, and its identity is a fact every node that validates the chain
computes for itself. Nobody signs it, nobody votes on it, nobody is asked. **A node that can
validate the chain can derive the beacon; a node that cannot has no business licensing a block.**
The validator-wired beacon of the past failed exactly here — it made block licensing depend on a
liveness assumption about a set of signers — and this ADR names that as the thing it forbids.

## 2. Decisions

**Decision 1 — Every paid unit of LLM work is a claim committed before its draw.**
The claim is the receipt lane's 0x4a commitment (`PalwFreePromptCommitmentV3`), in one of two
prompt modes carried on the job:
* `User` — the prompt is the user's; the ids travel in the payload (PublicDA) and in the job
  material, hash-bound to `prompt_token_ids_hash`. Today's lane, unchanged.
* `Canonical` — the prompt is the family's canonical prompt for the claim's own anchor,
  `fp_canonical_anchor_v1(job) = H(domain ‖ network ‖ class ‖ bond ‖ anchor_block ‖ anchor_daa ‖
  job_nonce)`, derived by the same `job_for_anchor` the attempt lane uses; the ids do NOT travel
  on chain (they are a pure function of the job) but DO travel in the job material, so seats and
  courts take one path for both modes. `prompt_token_ids_hash` must be the derived prompt's hash
  and `prompt_tokens` its length; a seat checks by deriving. Canonical claims are the work queue
  when nobody is asking: an executor keeps earning by running the network's own jobs, and those
  jobs are drawn, priced, verified and tried exactly as a user's.

**Decision 2 — The draw is the chain's beacon.** `fp_quantum_ticket_v3(network, beacon, claim,
quantum) ≤ receipt_target[class]`, with the beacon derived by `derive_beacon_fact_v3` — the
first algo-6 chain block at or after `final_daa + receipt_maturity_daa`, witnessed by the last
algo-6 block before the slot. Stated as law, because it was broken once: **the beacon MUST be a
function of the chain's own blocks and MUST NOT read an attestation, a quorum, a validator set,
a finality overlay, a DNS or MTP or VLT fact, or any value one party can set.** The two
inequalities are the whole validation; a node with the chain has everything.

**Decision 3 — The self-drawn lane stays, as the liveness-and-beacon lane.** Algo-6 blocks are
not retired: they are what makes beacons exist (the floor produces them at milliseconds per
inference, so a class with no self-drawn producer still gets beacons) and what makes beacons
ungrindable (a candidate beacon costs an inference under ADR-0072 + D8). Their share moves to the
claim lane under ADR-0073 Decision 4; their weight is unchanged by this ADR.

**Decision 4 — One inference, one claim.** A claim's work identity is
`H(domain ‖ class ‖ prompt_token_ids_hash ‖ decode_tokens_executed ‖ executor_bond)`; a
commitment whose work identity is already held by a claim that has not retired is refused at the
transition. Canonical claims are unique per (bond, nonce) by construction. What this prices: one
execution committed under N nonces, N retention values or N anchors was N lottery entries at the
cost of hashing. What it does not price: two bonds sharing one set of tiles (each re-hashes the
leaves under its own context) — collusion that costs each party a fee and `reserved` exposure per
claim, recorded here as the residual; it is closed by executor-dependent computation if it is
ever measured to pay.

**Decision 5 — The price is the capture's leaf count, and a quantum is a fraction of the
class's own job.** The commitment carries `work_leaves`, which must equal the binding's
`step_leaf_count`. The quantum is not a network-wide leaf count: it is
`max(1, canonical_leaves / quanta_per_canonical_job)` of the class's own canonical job (the
bundle says `8`; `canonical_leaves` is the class's `pwu_per_inference`, its canonical step leaf
count by genesis rule), so `quanta = min(⌊work_leaves / quantum⌋, max_quanta)` and
`pwu = quanta × quantum`. A job the size of the canonical one is eight draws on every class — the
per-class receipt retarget normalises across classes anyway — while `pwu` stays in leaves, so a
floor claim and a QWEN36 claim weigh in one unit. The class state holds no profile, so the
transition prices from the class's rule and the bundle's `quanta_per_canonical_job`
(`PalwStateParamsV2::with_fp_quanta`, held equal to the free-prompt params by `validate()`).
`PalwFpCuWeightsV3`, `fp_cu_v3`, `QUANTUM_CU` and `PWU_PER_QUANTUM` are withdrawn (ADR-0044 retains the withdrawal reason). A free-prompt claim's exposure is its own `pwu` — the work it
claims — not a whole canonical job. The attempt lane's
pwu is already leaves (`pwu_per_inference = canonical_step_leaf_count` by genesis rule), so
`safe_weight` becomes one unit and ADR-0073 Decision 3 is discharged. The seat verifies the price
against the capture it has authenticated (`verify_material` → `capture_shape().step_leaf_count`),
not against a declared shape: the class state holds no profile, only the family can count leaves,
and a claim whose price the seats refuse never licenses — the same standing the roots have had
since ADR-0044. Shape-crafting is gone by construction: leaves are the work.

**Decision 6 — The floor's free-prompt lane bears weight** (ADR-0073 Decision 2 for
PALW-BASE-0): `palw_rc_fp_certified_families_v1` gains the floor from its drill
(`the_floor_free_prompt_lane_certifies_…`). QWEN25-A16 and QWEN36 join when their free-prompt
paths exist and drill (the registered A16 graph refuses `execute_free_prompt`; QWEN36 has none).

**Decision 7 — Rollout.** Job version 3 → 4 (the mode field and the price field are inside the
job and the commitment), the bundle's free-prompt params change shape, the certified free-prompt
set is non-empty: three fingerprint moves, folded into ONE re-genesis with ADR-0072 + D8 and
ADR-0073 Phase ①. Rolling swap per the Relaunch 5 runbook; the new testnet-11 fingerprint is read
from the pin test in an isolated worktree and handed to the fleet operator before any host moves.

## 3. What this costs, stated before it is measured

* **Cadence.** Unchanged in mechanism: claims draw per quantum against `receipt_target[class]`,
  which the per-class retarget already maintains for the receipt lane; canonical claims add
  supply to that lane, so the silent-lane renormalisation in `apply_class_retargets` stops firing
  for classes with an idle executor.
* **Latency to a licensed block** for a claim: bind + receipt + `receipt_maturity_daa` +
  `use_window` — hours at the frozen 120 s cadence, as today for user claims. The attempt lane
  keeps the chain moving in between (Decision 3).
* **Seat cost** is Phase ①'s (hashing plus sampled leaves); pricing adds one equality.
* **State.** One `BTreeMap` of work identities keyed to claims, released at claim retirement.

## 4. Invariants the tests must hold

* The beacon derivation reads only `PalwChainBlockFactV3` items (block, DAA, algo id) — no other
  input type exists on that path, and a test asserts the function's signature by construction.
* A commitment whose work identity is live is refused; the same commitment after the earlier
  claim retires is admitted.
* A canonical claim whose `prompt_token_ids_hash` is not the derived prompt's hash is not
  certified by any seat; one whose hash is derived certifies through the Phase ① path.
* `work_leaves ≠ capture_shape().step_leaf_count` → the seat refuses; equal → `Valid`.
* One floor free-prompt job and one floor canonical claim price in the same unit as one floor
  attempt: `pwu` values are comparable by ratio of leaves, not by lane.

## 5. Supersession

| Decision | Status after this ADR |
|---|---|
| ADR-0044 Decision 7 — CU weights price the lane | withdrawn (Decision 5) |
| ADR-0044 "only attempt-class blocks can be beacons" | kept and named as law (Decision 2) |
| ADR-0072 §3 "the attempt lane is still the canonical-job lane" | the canonical job is a claim too (Decision 1); the attempt lane is the liveness-and-beacon lane (Decision 3) |
| ADR-0073 Decision 3 (a, b, c) | discharged by Decisions 5, 5 and 2 respectively |
| ADR-0073 Decision 2 activation gate | met for PALW-BASE-0 (Decision 6); open for A16 and QWEN36 |

## 7. What landed (2026-09-02, branch `palw-adr0073-fp-weight`)

* **Decision 1:** `PalwFreePromptJobV3::prompt_mode` (`PALW_FP_PROMPT_MODE_USER` / `_CANONICAL`),
  `fp_canonical_anchor_v1`; the chain refuses a canonical payload that carries ids; seats, the
  court arm and the challenger derive and verify the canonical prompt (`fp_prompt_for_job`). The
  work queue is the node panel's: `--palw-canonical-claims`, `--palw-canonical-class`,
  `--palw-canonical-interval-daa`, funded from `--palw-fee-outpoint`; the commitment is assembled
  from the capture's own context (`palw_fp_commitment_from_context_v3`) and the `FPC1` material is
  retained and broadcast under the claim id.
* **Decision 2:** no code change — `derive_beacon_fact_v3` is the beacon; this ADR is its law.
* **Decision 3:** algo 6 unchanged (ADR-0072 + D8 on main).
* **Decision 4:** `fp_work_id_v1`, `PalwClaimStateV2::work_id`, the state's derived work-id index,
  `DuplicateWork`.
* **Decision 5:** `work_leaves` replaces `cu`; `fp_class_quantum_leaves_v1` (⅛ of the class's job,
  `PalwPwuRuleV2::canonical_leaves_v1`); the transition prices from `PalwStateParamsV2::with_fp_quanta`
  and the bundle's `validate()` holds the two readers equal; exposure = the claim's own pwu; the
  seat's pricing check is `capture_shape().step_leaf_count == work_leaves`; worker results carry
  `step_leaf_count`; CU weights, `QUANTUM_CU`, `PWU_PER_QUANTUM` withdrawn.
* **Decision 6:** `palw_rc_fp_certified_families_v1` = {PALW-BASE-0}, pinned from the floor's own
  drill; presets carry `with_fp_certified_classes`; `FreePromptLaneUncertified`.
* **Found on review (ac), closed:** the free-prompt lane never had admission item 8 — a
  commitment meets no admission list, and `reserve_for_claim` only added — so a bond could pile
  free-prompt reserves past its collateral, and Decision 5 made each claim up to eight jobs'
  worth. The ceiling is now the transition's (`PalwStateParamsV2::with_fp_exposure_ceiling`,
  `FreePromptExposureCeiling`), the same expression as the attempt lane's item 8, held equal to
  the admission ratio by the bundle's `validate()`; every preset carries it.
* **Decision 7:** FP wire version 3 → 4, `PALW_STATE_V2_VERSION` 14 → 15, golden ids and roots
  re-taken; the preset fingerprints are re-pinned on the re-genesis build (rebased on main's
  ADR-0072 + D8) and handed to the fleet operator before any host moves.
* **Outside this repo:** MISAKA Studio's worker request must carry `prompt_mode` (wire version 4),
  and its rail must pass the class's canonical leaves to `build_fp_commitment_tx`.

* **Decision 6, continued by ADR-0075:** the free-prompt-certified set gains a chain half —
  `FamilyCertified` / `ClassLaneCertified` objects graded by the court in the transition — and
  the genesis half is derived by kernel coverage from fixture free-prompt drills of all three RC
  families, so the real models take free-prompt claims from the 5e genesis and every later model
  takes the on-chain route (`docs/adr/0075-certification-is-a-consensus-object.md`).

## Mission alignment amendment — 2026-10-07

* Panel/jury/validatorの選出やquorumは担当割当・既存処理の条件であり、算術的真実や外部訴追の権限を決めない。有効なobjective proofは多数派のlicense後も独立に処理する。新たな訴追をgenesis operator、owner承認、bound-seat専用の権限に依存させない。
* 将来のlicense/Final、early weight、slice/claimの報酬解放は、証拠保持・proof期間・clock・collectible collateralと整合させる。多数派の署名で有効なfraud proofを無効にしない。DA default、算術conviction、false Validのscope別責任は区別し、verifier不在やローカルtimeoutをproducer fraudにしない。
* 不正の発見と、その後の客観的局所化・裁定の成立を分ける。honest seatの存在、raw sampling、選出outsider、quorumだけで全不正の検出を保証しない。ADR-0171の全constraint検査とresidual error、ADR-0172のversioned Kernel境界を維持し、巨大な無界replayやVM/TEE/BFT authorityを代替条件にしない。

本amendmentは衝突する将来の設計・受入条件を改定する。既存の実装・測定・fenceの記録はそのまま保持する。変更する合意規則は別のversioned移行を必要とする。Panel=0は[RFC14](../rfc/0014-panel-independent-fraud-prosecution.md)の全completion gatesと[RFC15](../rfc/0015-panel-free-permissionless-verification.md)固有gateが成立するまで有効化しない。
