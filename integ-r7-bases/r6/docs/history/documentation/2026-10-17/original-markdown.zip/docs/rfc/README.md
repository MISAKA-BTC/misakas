# RFC index

> **凍結前提(2026-10-15):** genesis・年次フォーク指定モデルは 1.0、後から登録したモデルは登録時点から審査なしで 0.3 固定(1.0 への経路は年次フォーク指定のみ)。モデル単位の検証は不採用([PRINCIPLES §9](../PRINCIPLES.md))。claim 単位の検証は全モデルで維持。

> **恒久決定(2026-10-15):** LLM・モデル計算の正しさを暗号学的に証明する仕組み(ZK、zk-SNARK/STARK、zkVM・zkML、PCS ベースの succinct proof など)は一切使用せず、今後も使用しない([PRINCIPLES §8](../PRINCIPLES.md))。

> **設計前提(ADR・RFC より上位)— [MISAKAの不可侵原則](../PRINCIPLES.md):** 確率的に検出し、公開証拠で局所化し、決定論的に裁き、経済的に不正を抑止する。この索引のすべての文書はこの前提の下にあり、衝突する場合は前提が優先する(2026-10-09)。

> **PALW共通前提 — 2026-10-10:** [ADR-0176](../adr/0176-bond-bounds-palw-production-rewards-and-final-weight.md)を適用する。確率的検証・公開反証・客観裁定に加え、bondと共通DAA期間がclaim発行能力、ブロック数、報酬総額、Final後の確定weightの上限を決める。
> モデル計算はその枠を使用するための正当な仕事であり、同額bond・同期間・同倍率なら計算省略や高速偽造で枠は増えない。有罪なら報酬失効と適用規則上の担保損失を負う。claim容量の倍率を上げてもbond当たりの総経済・consensus creditは増やさない。
> 将来のPALW設計・受入条件に適用し、過去の実測・実装記録・旧claim規則は保持する。上限は検出能力の証明ではなく、公開検証・徴収可能担保・責任保持・独立試験と明示的upgrade/activationを要する。
> **モデル入手への不介入 — 2026-10-10後続改定:** [ADR-0177](../adr/0177-model-bond-allocation-without-availability-consensus.md)を優先する。MISAKA Torrent・専用Seeder・Seeder報酬の概念を廃止する。モデル配布・取得可否を合意で管理せず、PoR/全量取得監査/TRDC/FPRによる資格・weight停止も撤回する。モデル別coinbaseは重複のない拘束miner bond元本に連動し、総発行予算と個別bond上限を維持する。
> 固定モデル同一性とclaim固有証拠の裁定は維持する。外部検証は正しいモデルを入手できた条件で成立し、公開参加の経済優位は倍率式・敵対的評価で立証する未完の目標である。過去の実装/試験/旧規則は保持し、新配分は未実装・未有効化である。


**トークン名は Misaka、ticker は BILI。** アドレスの `misaka` 系プレフィックスと既存のチェーンID・コマンド・wire/API識別子は維持する。過去の実測・出力のMSKは旧表記として保存する（[ADR-0174](../adr/0174-token-name-misaka-ticker-bili-address-prefix-unchanged.md)）。

## MISAKAの中核目標と設計の優先順位（2026-10-07）

[ADR-0173](../adr/0173-public-verifier-dispute-completeness-is-misaka-purpose.md)を優先する。**普通の非Panel public bondが、producerの秘密状態を使わず、public authenticated materialだけから不正をlocalizeしobjective convictionまで完結できること**を中核目標にする。[RFC14](0014-panel-independent-fraud-prosecution.md)が主実装設計、[RFC15](0015-panel-free-permissionless-verification.md)はその全gate成立後も別途受入・activationを必要とするPanel=0設計である。全RFC/ADRの確認・改定範囲は[監査記録](../adr/evidence/0173-mission-alignment-audit-2026-10-07.md)に記載する。文書の追加・改定でruntimeを更新したとは扱わない。

An RFC is a proposal under discussion. [INDEX.md](../INDEX.md) §3 explains how an RFC becomes an ADR
and a Spec change. Take the next number from this table, not from `ls`: an RFC can live on a branch
before it reaches `main`.

**2026-10-10追加前提:** [ADR176](../adr/0176-bond-bounds-palw-production-rewards-and-final-weight.md) / RFC15 §8は、確率的検証・公開prosecutionとbond/DAA採掘予算をANDで要求する。claim容量を増やしてもblock/reward/Final weight総量は増やさない。[全RFC/ADR改定・文書検証記録](../adr/evidence/0176-bond-budget-policy-alignment-2026-10-10.md)。

| RFC | Title | Status | Where |
| --- | --- | --- | --- |
| 0001 | PALW inference surface gaps: deterministic decode controls, serving and input extensions (FP Job V4) | §A (the FP Job V4 release) Implementation Frozen, 2026-09-27 (G0). §0–§7 (P1–P3) Draft, for a later release | [0001-palw-inference-surface-gaps.md](0001-palw-inference-surface-gaps.md). The former branch reservation is historical; the file is included in this reviewed document set. |
| 0002 | PALW Canonical Tensor IR v1 (PALW-TIR): a bounded, deterministic integer tensor program as the consensus meaning of a class, with a reference evaluator and optional fused kernels; v1 frozen on an architecture corpus; Pre-beacon immutable class/plan/challenge-policy binding added in §II.13; actual beacon/transcript remains evidence | Revised 2026-10-08 — existing implementation/test records keep their scope; new policy binding unactivated | [0002-palw-tensor-ir.md](0002-palw-tensor-ir.md) (branch `rfc/0002-tensor-ir`) |
| 0003 | PALW Generative Model Classes: one job, determinism and output layer (deterministic randomness R, canonical tensors and why no execution profile, canonical outputs), and the class profiles on top of it (image generation in detail; text, embedding, multimodal input, audio, video); Generation R strictly separated from RFC07 post-commit verification randomness | Revised 2026-10-08 — new challenge-policy boundary; historical profile/tests unchanged | [0003-palw-generative-model-classes.md](0003-palw-generative-model-classes.md) (branch `rfc/0003-image-generation`) |
| 0004 | モデル改善：学習・評価を継続し、改善版は独立した不変モデルとして登録。既存head/version・Position/AMMの置換は禁止 | Revised 2026-10-09 — 独立immutable fenceとcandidate選択をpreに実装、全preset休眠。memory materialの担保条件・kind別MEASは未決/未測定 | [0004-palw-model-improvement.md](0004-palw-model-improvement.md), [ADR-0175](../adr/0175-registered-models-are-permanently-immutable.md) |
| 0005 | Versioned model/verification kernels, not BVM/GVM: declarative plans within active families, coordinated SegWit-class extensions for missing semantics, encoded probabilistic checks and bounded exact court; Immutable approved checker/challenge/soundness tuple; Kernel differential conformance only after completeness | Revised Draft, 2026-10-08 — §§K.2/K.4 use RFC07; no VM fallback or activation | [0005-palw-ml-vm.md](0005-palw-ml-vm.md) (stable filename) |
| 0006 | Layer-sharded verification: authenticated boundaries, scope-bound receipts and conditional public-bond court; model acquisition outside consensus | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0006-palw-layer-sharded-panels.md](0006-palw-layer-sharded-panels.md) (branch `rfc6/gpu-shard`) |
| 0007 | PALW constraint verification: Part VI is the sole post-commit PALW-work beacon/challenge protocol; Part V remains scoped Freivalds/GKR verification. Parts I–IV preserve their historical/prototype evidence | Revised Draft, 2026-10-08 — source/codec/security/implementation gates open; no beacon or activation proof | [0007-palw-verification-certificates-and-algebraic-checks.md](0007-palw-verification-certificates-and-algebraic-checks.md) |
| 0008 | Unified EXEC_TX / EXEC_SLICE: one root settlement, unique work, zero EXEC weight/DAA, model-bond allocation and Rule E | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0008-palw-claim-backed-consensus-blocks.md](0008-palw-claim-backed-consensus-blocks.md) |
| 0009 | Node-less registration / signed remote claims: explicit GAS/bond, optional off-chain supply and finite claim-evidence duties | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0009-palw-remote-miner.md](0009-palw-remote-miner.md) |
| 0010 | Permissionless Panel binding: sealed claims, snapshots, shared challenge protocol and completion; no model-availability gate | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0010-permissionless-palw-panel-and-claim-completion.md](0010-permissionless-palw-panel-and-claim-completion.md), [implementation](0010-dormant-implementation.md) |
| 0011 | Permissionless full-task onboarding: immutable identity, conditional G14 and model-bond allocation; 9B/2M/HF historical scope retained | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0011-permissionless-model-and-long-context-onboarding.md](0011-permissionless-model-and-long-context-onboarding.md) |
| 0012 | PALW-only / native EVM: legacy DNS wind-down, model-bond allocation, Rule E and zero extra issuance | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0012-palw-only-consensus-and-native-evm-settlement.md](0012-palw-only-consensus-and-native-evm-settlement.md) |
| 0013 | Resource-bounded tools: conformance/resume, identity, distinct model capital and allocation evidence; fetch telemetry stays off-chain | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0013-reproducible-layouts-and-resource-bounded-onboarding-tools.md](0013-reproducible-layouts-and-resource-bounded-onboarding-tools.md) |
| 0014 | Conditional public-verifier prosecution; §16 model-acquisition non-interference, distinct miner capital, coinbase allocation; MISAKA Torrent / Seeder rewards / FPR abolished | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0014-panel-independent-fraud-prosecution.md](0014-panel-independent-fraud-prosecution.md) |
| 0015 | Deferred Panel=0: bond/time Q/B/R/F budgets, capacity subdivision and §8.5 model-bond coinbase allocation; no acquisition consensus | Revised Draft / deferred where applicable, 2026-10-10後続改定 — ADR177 economics/allocation/implementation gates open; old runtime/tests retain scope; no activation | [0015-panel-free-permissionless-verification.md](0015-panel-free-permissionless-verification.md) |
| 0016 | Bond-weighted block opportunity and elastic Final capacity: V+ adopted as the physical-layer design (pre-issued per-model block rights from `P_m`, sigma-capped reissue, required pre-Attempt; other options and B+ kept as considered alternatives); Panel=0 settled (Kernel claims: one transaction each, B = F = 0, user-paid escrow only, never clipped); hold Panel=0 7 d / Panel=1 1 d; verifier-scaled capacity, quote and bounded queue; sigma/k derivation by measurement | Accepted design (V+), values pending measurement, 2026-10-15 — implemented dormant on `integ/rfc0016-impl` (unbuilt; fences refused when armed until measured values are pinned); not activated | [0016-bond-weighted-block-opportunity-and-elastic-final-capacity.md](0016-bond-weighted-block-opportunity-and-elastic-final-capacity.md), [status](../design/palw/rfc-0016-implementation-status-2026-10-15.md) |
| 0016 | Bond-weighted block opportunity and elastic Final capacity: physical block opportunity vs reward rights; Panel=0 settled (Kernel claims: one transaction each, B = F = 0, user-paid escrow only, no coinbase leg, escrow never clipped); physical-layer design space with leading candidate V+ (pre-issued per-model block rights from `P_m`, sigma-capped reissue, required pre-Attempt); hold Panel=0 7 d / Panel=1 1 d with equal per-day issuance and no re-acquisition on mode switch; verifier-scaled capacity and a bounded queue | Draft, 2026-10-15 (two user reviews recorded as design decisions, not value or activation approval) — V+ not adopted; P4 code fix `eee1710ce` dormant and unbuilt; values V1–V11 pending | [0016-bond-weighted-block-opportunity-and-elastic-final-capacity.md](0016-bond-weighted-block-opportunity-and-elastic-final-capacity.md) |
| 0017 | Model tiers (revised 2026-10-15, rounds 4–5; governing premise PRINCIPLES §9, frozen): `ApprovedModels(h)` — genesis + add-only annual fork lists — weigh 1.0; every on-chain registered model is fixed at 0.3 from registration; model-level review (the former Registered / Probation / Eligible / Lapsed exam) is abolished for all models; `c_m` applied once in `A_m = c_m · S̄_m^1.5` with a registered-tier aggregate cap; per-claim certification (RFC-0018 Gate C) for every tier | Draft, 2026-10-15 — tier fence `palw_model_tier_v1` implemented, dormant, unverified ([ADR-0179](../adr/0179-model-tiers-genesis-annual-1-0-registered-0-3.md)); the old review code dormant and unreachable under it; no activation | [0017-model-eligibility-examination-and-renewal.md](0017-model-eligibility-examination-and-renewal.md) |
| 0018 | DAG parallel multi-model consensus: concurrent sibling blocks of different models all retained and merged with a merge-order-independent canonical admission order; a permissionless aggregated Panel anchor replacing the genesis-operator anchor; **Gate C — `Final` and `SecurityCertified` separated (adopted by the user 2026-10-15): only claims certified by commit-then-draw m-of-k positive attestations from the global verifier pool plus the G14 prosecution window add consensus credit — premise-based (honest fraction of drawn verifier stake at least the threshold), no computation proof**; rule E v2 (capital-weighted, split-resistant, certified-only) as the post-DNS convergence rule; no reliance on DNS-BFT; DAG width schedule spec/stub; the mandatory 300M closed-model / self-Panel acceptance test | Draft, 2026-10-15 — implemented, dormant, unverified (fences `palw_dag_sibling_attribution_v1`, `palw_panel_anchor_permissionless_v1`, `palw_rule_e_participation_v2`, `palw_independently_work_certified_v1`, `palw_dag_width_schedule_v1`; aux 136); values unapproved; no activation | [0018-dag-parallel-multi-model-consensus.md](0018-dag-parallel-multi-model-consensus.md) (branch `integ/rfc0018-dag`), [status](../design/palw/rfc-0018-implementation-status-2026-10-15.md) |
| 0019 | Annual model upgrade: three things kept apart — a Solana-style staged software rollout (code behind a fence, operators install at their own time, a signed release manifest, readiness MEASURED and never voted), an add-only annual model catalog (`AnnualModelCatalogV1` chained by `previous_catalog_root`, genesis = edition 0) that IS ADR-0179's `ApprovedModels(h)`, and PALW + DAG consensus (unchanged). Tier 1000 ‰ for catalog members / 300 ‰ otherwise, applied once in `A_m` at the allocation roll; accepted-DAA boundary rule for RED merges across an activation; old and new builds share the identity until the switch, the fork id refuses a build without the edition after it. First use: the testnet-12 DAA 14,000 upgrade with the same catalog | Draft, 2026-10-15 — implemented, dormant, unverified (no new fence: the catalog chain is `palw_model_tier_v1`'s value; RPC `getPalwModelRegistry` wire v4 `annualCatalog`, gRPC field 41; release tools `misaka-release-manifest.py` / `misaka-release-readiness.py`; drill `rfc0019_rolling_upgrade_drill.py`); values unapproved; no activation | [0019-annual-model-upgrade.md](0019-annual-model-upgrade.md) (branch `integ/rfc0019-annual-catalog`) |
| 0020 | Long-context calibration memory (32K genesis context, user decision 2026-10-16): keep the full 32K dependency structure — never split the sequence or shrink attention scope (no `Op::Attention` `chunk` / `max_window` for memory) — while not holding what need not be held: a RAM accounting mode (live/peak bytes by kind and stage, RSS); consumed carries (the user's `reduce_calibration_carries` patch: one full-sequence carry instead of two); lazy weights off by default with a re-read warning; an audit finding no full-sequence score matrix on the genesis text paths (tiled exact attention, its reference-identical multi-pass and labelled online-softmax variants and a chunk-aware observer specified only); opt-in bit-identical carry disk spill; KV spill specified for >32K; a 32K held-out drift check in the fit guard | Draft, 2026-10-16 — tooling only, no consensus surface; implemented, unverified (`ram_account.rs`, `float_ref/stream.rs`, `palw-tir-convert`/`palw-tir-fidelity` flags); tiled attention and KV spill not implemented | [0020-long-context-calibration-memory.md](0020-long-context-calibration-memory.md) (branch `integ/genesis10`) |

**Next free number: RFC-0021.**

## Model acquisition non-interference and model-bond allocation — 2026-10-10後続改定

[ADR-0177](../adr/0177-model-bond-allocation-without-availability-consensus.md) is the governing direction.
**MISAKA Torrent adoption/integration, dedicated Bonded Seeders and Seeder rewards are abolished.**
PoR, Full Fetch, availability leases, TRDC/FPR, whole-model disclosure funding and availability-driven
qualification/weight suspension are withdrawn. General off-chain model sharing is optional.
The chain neither manages nor guarantees acquisition; non-publication alone triggers no reward loss or Slash.

Preserve immutable Model ID/root/weights/spec and finite claim-specific evidence/court responsibility.
G14 prosecution is conditional on acquiring the registered model; the all-owner-refusal retrieval guarantee is withdrawn.
Compute distinct `S_m=sum_b C_{b,m}` with `sum_m C_{b,m}<=C_b_effective_locked`.
Allocate `R_m=R_PALW*f(S_m)/sum_j f(S_j)` inside the existing total coinbase budget, with defined zero/rounding/unused rules.
Valid computational work is required for payment; retain ADR176's individual Q/B/R/F ceilings and common DAA hold.
Coinbase allocation alone changes neither block cadence nor DAA/difficulty/fork choice.

The goal is an overwhelming economic advantage for publication that attracts external capital.
Equal capital gives equal allocation irrespective of ownership; wallet count is not independence evidence.
The multiplier curve, self-funding/Sybil/concentration, incumbent caps, competition and closed-model detection
must be evaluated before claiming that goal achieved. Allocation and economic implementation remain pending.
See [RFC14 §16](0014-panel-independent-fraud-prosecution.md), [RFC15 §8.5](0015-panel-free-permissionless-verification.md)
and the [current document validation](../adr/evidence/0177-model-distribution-policy-alignment-2026-10-10.md).

The earlier [Seeder](evidence/0014-independent-bonded-seeders-audit-2026-10-10.md) and
[FPR](evidence/0014-forced-public-retrieval-alignment-2026-10-10.md) checks are historical withdrawn-policy records.
Their PASS does not prove this economic goal, new allocation, G14 under closure or activation.

## Shared post-commit challenge protocol (2026-10-08)

[RFC07 Part VI](0007-palw-verification-certificates-and-algebraic-checks.md#post-commit-challenge-protocol) is the
sole proposed source/seed/sampling/transcript protocol for Kernel/model conformance, claims, EXEC slices and public
checks. Future independently valid canonical PALW useful work supplies the proposed beacon; no committee/DNS/BFT
signature or heartbeat/BASE-0/EXEC-hash fallback. Source unpredictability/bias/bootstrap and all implementation gates
remain open. [ADR171](../adr/0171-probabilistic-constraint-checks-and-court-on-dispute.md),
[ADR172](../adr/0172-model-extensibility-uses-versioned-kernels-not-a-universal-vm.md) and
[ADR173](../adr/0173-public-verifier-dispute-completeness-is-misaka-purpose.md) bind this direction.

RFC02 and the [Kernel design](../design/palw/versioned-kernels.md) bind immutable class/Kernel/policy identity; RFC11 §17 separates Static Admission, Beacon Conformance and
Active Eligibility; RFC13 §9 records commitments/evidence/resume; RFC14 §3.4 and RFC15 §1.1 extend G14 challenge replay
and exact escalation. RFC03/04/06/09/10/12 keep generation/hold-out/Panel/ticket/settlement authority distinct; RFC08
inherits the shared policy while keeping EXEC weight/DAA zero and main heartbeat/BASE-0/liveness unchanged.
See the [alignment and validation scope](evidence/0007-post-commit-randomness-alignment-2026-10-08.md).
This is a documentation revision, not a secure-beacon proof, conformance run, runtime release or activation.

## Model-extension precedence (2026-10-06)

[ADR0172](../adr/0172-model-extensibility-uses-versioned-kernels-not-a-universal-vm.md) governs
RFC01–12's model extension: active versioned kernels and bounded declarative plans, never a model
VM fallback. [RFC11 §15.9](0011-permissionless-model-and-long-context-onboarding.md) defines the
MatMul-first probabilistic-check research/benchmark basis; TEE validity trust and BFT orchestrator
authority are excluded. The [consistency audit](evidence/0012-kernel-only-design-audit.md) lists
all twelve RFCs and relevant ADR dispositions. RFC05 retains only the VM withdrawal reason;
selected Kernel schemas and gates are in the [Kernel design](../design/palw/versioned-kernels.md). No activation is implied.

## Withdrawn designs

不採用・撤回済みの案は理由と後継文書へのリンクだけを残し、仕様・実装手順・見積もりは削除する。旧版は Git 履歴で参照できる。
RFC05 の VM、RFC14 §16 の MISAKA Torrent、ADR0023 の三 lane 案は実装対象外。DNS validator の旧設計は [RFC12](0012-palw-only-consensus-and-native-evm-settlement.md) の移行方針に従い、移行前の規則と将来の採用方針を区別する。

## ADRs that read as proposals

These ADRs decide nothing, or were forward-looking designs with nothing built. They keep their ADR
numbers. Reopening one means filing a new RFC that cites it.

| ADR | Why it reads as an RFC |
| --- | --- |
| [0141](../adr/0141-can-an-inference-be-the-ticket-without-a-hash-lottery.md) | "Decides nothing and changes no rule". It asks whether an inference can be the ticket without a hash lottery |
