# ADR-0055 — Chain position is earned, and the question is set by the block

> **PALW共通前提 — 2026-10-10:** [ADR-0176](0176-bond-bounds-palw-production-rewards-and-final-weight.md)を適用する。確率的検証・公開反証・客観裁定に加え、bondと共通DAA期間がclaim発行能力、ブロック数、報酬総額、Final後の確定weightの上限を決める。
> モデル計算はその枠を使用するための正当な仕事であり、同額bond・同期間・同倍率なら計算省略や高速偽造で枠は増えない。有罪なら報酬失効と適用規則上の担保損失を負う。claim容量の倍率を上げてもbond当たりの総経済・consensus creditは増やさない。
> 将来のPALW設計・受入条件に適用し、過去の実測・実装記録・旧claim規則は保持する。上限は検出能力の証明ではなく、公開検証・徴収可能担保・責任保持・独立試験と明示的upgrade/activationを要する。
> **モデル入手への不介入 — 2026-10-10後続改定:** [ADR-0177](0177-model-bond-allocation-without-availability-consensus.md)を優先する。MISAKA Torrent・専用Seeder・Seeder報酬の概念を廃止する。モデル配布・取得可否を合意で管理せず、PoR/全量取得監査/TRDC/FPRによる資格・weight停止も撤回する。モデル別coinbaseは重複のない拘束miner bond元本に連動し、総発行予算と個別bond上限を維持する。
> 固定モデル同一性とclaim固有証拠の裁定は維持する。外部検証は正しいモデルを入手できた条件で成立し、公開参加の経済優位は倍率式・敵対的評価で立証する未完の目標である。過去の実装/試験/旧規則は保持し、新配分は未実装・未有効化である。


> **Mission alignment, 2026-10-07:** [ADR-0173](0173-public-verifier-dispute-completeness-is-misaka-purpose.md) governs future PALW design. Where the earlier body conflicts with ordinary non-Panel public-bond prosecution from authenticated public material, without producer-private state, the dated amendment at the end supersedes that direction. Earlier Status, measurements and activation records are preserved; this is not a claim of implementation or activation.


- Status: Accepted
- Date: 2026-08-27
- Supersedes: nothing. Extends ADR-0044 Decision 6; reverses one relaxation recorded in
  `palw_state_v2.rs` (the court's opening rung).
- Declared by: `PALW_ATTEMPT_V2_VERSION` 4 → 5.

> **Note (index reconciliation, 2026-09-02).** "No shipped preset carries `ConsensusV2`" was
> written on 2026-08-27 and is no longer so: testnet-11 and devnet ship the V2 bundle
> (`palw_rc_shipped_params`, `devnet_shipped_params`), so Decision 3's window is the RC genesis's.
> Decision 1's "a receipt header buys no chain position" is the state [ADR-0073](0073-real-demand-work-bears-the-weight.md)
> Phase ④ proposes to change (open). Map: [`README.md`](README.md).

## Context

The 2026-08-21/08-27 adversarial audit returned eleven criticals. Three of them are the same
mistake told three ways: **a party was allowed to supply the thing it was going to be judged
against.**

1. A receipt-lane (algo-7) header's digest is free to re-roll — nothing in it costs anything to
   produce. `calc_block_level_check_pow_layer0` already refused to sell pruning-proof LEVEL for
   that price. Nothing refused to sell fork-choice WEIGHT: every merged receipt block still added
   `calc_work(bits)` to its descendants' blue work. The lane's meter, the ADR-0044 quantum ticket,
   draws against a beacon derived from the candidate's own chain — so it can only run on a chain
   candidate and cannot gate DAG entry at all. A merged-but-never-candidate receipt block never
   faced it.

2. A capture states its own job id. The seat compared the capture's roots against the claim's
   roots; the challenger re-executed the anchor **named inside the capture** and compared. Both
   agreed for material that answered a question no block ever asked, so one gossiped capture was a
   re-usable asset: mine a fresh block, announce the borrowed roots, and neither half objects. One
   inference, unlimited blocks, by parties that ran nothing.

3. The court's opening rung ran on the whole session budget rather than the rung clock. That was
   right when it was written — `CourtDisclosed` was constructed nowhere, so silence there could not
   fairly convict — but by the time a responder shipped, the backstop's effect had inverted: it
   ended the dispute on the CHALLENGER's side, which makes silence the winning move for a guilty
   producer.

## Decision

**D1. A receipt header buys no chain position of either kind.** One predicate,
`pow_layer0::algo_id_carries_no_chain_position`, answers for both the block level and the blue
work, and both sites call it. A receipt block contributes zero added blue work.

**D2. The anchor is derived from the claim's block, never read off the material.** Its four inputs
— network domain, the accepted block's pre-PoW hash, the class id, the executor bond outpoint — are
all facts a third party reads from the chain, so every verifier derives the value the producer was
forced to use. `PalwClaimRootsV1` carries it; `verify_material` refuses material whose
`job_context.job_id` is not it; the challenger re-executes the derived anchor. A verifier that
cannot derive it (pruned block, family with no canonical job) declines to judge rather than judging
without it.

**D3. The opening rung takes `turn_deadline_daa` like every other rung.** A silent responder loses
the claim, as it does at every later rung. This is a genesis-time obligation on the bundle: the
window must be wider than the responder's own cadence (the panel wakes on a 2-second tick and
answers from a capture it already holds), and a bundle whose window is tighter than its own
software convicts honest producers.

**D4. A production close carries the operand rows the court will read** — recorded by running the
real adjudicator through `PalwRecordingOracleV1` against the full inventory and opening exactly
what it resolved. The enumeration is asked of the adjudicator rather than written a second time on
the prover side, because a second enumeration agrees today and diverges the first time a kernel
changes which operand it touches — in the direction where an honest producer cannot close.

## Consequences

- D1 and D3 change consensus outcomes without changing any params field, so neither would have
  moved `palw_ruleset_id_v2` on its own. An old binary and a new one would have agreed on every
  block and disagreed on whether a producer was slashed and on which chain was heavier — a silent
  fork rather than a refused handshake. `PALW_ATTEMPT_V2_VERSION` 4 → 5 is where that is declared;
  it moves the fingerprint of every network carrying `ConsensusV2` and re-mints them.
- D2 adds `accepted_block` to the seat-duty, disputable-claim and court-duty views, and one header
  read per claim under judgement on the panel's cadence.
- No shipped preset carries `ConsensusV2`; a V2 bundle arrives with a network's genesis, so D3's
  window is chosen there.

## Mission alignment amendment — 2026-10-07

* Panel/jury/validatorの選出やquorumは担当割当・既存処理の条件であり、算術的真実や外部訴追の権限を決めない。有効なobjective proofは多数派のlicense後も独立に処理する。新たな訴追をgenesis operator、owner承認、bound-seat専用の権限に依存させない。
* 将来のlicense/Final、early weight、slice/claimの報酬解放は、証拠保持・proof期間・clock・collectible collateralと整合させる。多数派の署名で有効なfraud proofを無効にしない。DA default、算術conviction、false Validのscope別責任は区別し、verifier不在やローカルtimeoutをproducer fraudにしない。
* 不正の発見と、その後の客観的局所化・裁定の成立を分ける。honest seatの存在、raw sampling、選出outsider、quorumだけで全不正の検出を保証しない。ADR-0171の全constraint検査とresidual error、ADR-0172のversioned Kernel境界を維持し、巨大な無界replayやVM/TEE/BFT authorityを代替条件にしない。

本amendmentは衝突する将来の設計・受入条件を改定する。既存の実装・測定・fenceの記録はそのまま保持する。変更する合意規則は別のversioned移行を必要とする。Panel=0は[RFC14](../rfc/0014-panel-independent-fraud-prosecution.md)の全completion gatesと[RFC15](../rfc/0015-panel-free-permissionless-verification.md)固有gateが成立するまで有効化しない。
