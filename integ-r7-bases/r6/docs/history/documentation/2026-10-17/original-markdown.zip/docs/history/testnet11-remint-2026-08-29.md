# testnet-11 re-mint onto the audit3 build (2026-08-29)

> **Token identity (2026-10-07):** The token name is **Misaka** and its ticker is **BILI** ([ADR-0174](../adr/0174-token-name-misaka-ticker-bili-address-prefix-unchanged.md)). MSK in retained measurements, quotations, command/output examples, identifiers or chain-ID mnemonics is a legacy label for the same coin; it does not change amounts, units, protocol IDs or address prefixes.

> **SUPERSEDED 2026-08-30** by the 10B-premine-cap re-mint
> ([ADR-0059](../adr/0059-the-10b-premine-cap.md), "Relaunch 3"): fingerprint
> `95265934…` → `f3bf86b4e9327f8b02ab2ad1d121d62ecd11bd78cca1455d8bcd7372595153d8`, genesis
> `c664a224…` → `d2789338…` (marker `11,3`). Unlike this re-mint, THAT one moves the genesis:
> the vault block is deleted, the premine is exactly 10B on every network, and the community
> allocation (11 addresses, 547M — this document's "nine addresses / 347M" was already stale
> when written) is carved out of the main wallet. The migration procedure below still applies
> verbatim (stop all → wipe → redeploy), with the new fingerprint substituted.

**What moves.** The consensus fingerprint, from what the fleet runs today to what this build
announces:

| | |
|---|---|
| fleet today | `15bab795442ec3efc3a58e02dd9c7a6f3015ff0634bc4a50a7af589338857ad0` |
| this build | `95265934e8965e91f3c22281af735bcd38527b5ee89fa09a05290db566d444a3` |
| branch | `palw-audit3-2026-08-29` @ `7457cff3` |
| `PALW_STATE_V2_VERSION` | 10 → 12 |

**What does NOT move: the genesis.** `git diff 8e982b7e 7457cff3 -- consensus/core/src/config/genesis.rs consensus/core/src/config/premine.rs`
is empty. The genesis block, the 13B premine and the **347,000,000 MSK community allocation across
nine addresses** are byte-identical. Participants keep their block-0 coins; what is discarded is the
chain built on top of them.

So this is a **wipe and restart from the same genesis**, not a new genesis. Nobody needs a new
address and nobody's allocation changes.

## Why it cannot be a rolling upgrade

`/root/deploy-t11.sh` gates on the only question that decides it: *the candidate must have synced
this chain from nothing and disqualified NOTHING.* This build cannot pass that gate and should not
— three rules changed about which blocks and which state are valid (S-03, S-04, H4 under
`PALW_STATE_V2_VERSION` 12), so it necessarily refuses blocks the live chain accepted. The script
refusing is the script working.

Nodes on the two fingerprints will not peer, which is the correct failure direction: they find out
at the handshake instead of at consensus.

## The fleet, as measured on 2026-08-29

| host | unit | appdir | reachable from here |
|---|---|---|---|
| `169.58.39.220` (ibm) | `misaka-t11-node0` | `/root/.t11` | yes, directly |
| `169.58.39.220` (ibm) | `misaka-t11-node1` | `/root/.t11b` | yes, directly |
| `160.16.131.119` (A) | `misaka-t11-node-b` | `/home/ubuntu/.t11` | yes, via ibm as `ubuntu` |
| `169.58.232.113` | `misaka-t11-node` | `/root/.t11` | yes, via ibm as `root` |
| `5.104.81.23` (C) | — | — | **NO** — publickey denied as `root` and `ubuntu` |
| `169.58.232.114` | — | — | **NO** — publickey denied |

Plus community nodes, seen as inbound peers at the producer: `113.155.23.105`, `133.18.141.168`,
`183.176.36.141`, `207.180.230.3`, `217.178.131.170`, `60.114.127.4`.

**Correction to an earlier draft of this file.** It said a partial wipe is worse than none, because
an un-wiped peer re-supplies the old chain by IBD to every host that was wiped. That is the rule for
a re-mint at an UNCHANGED fingerprint, and it does not apply here.

`PALW_STATE_V2_VERSION` is not a fence, so it survives `consensus_identity_id`'s normalisation and
the two rulesets carry different identities — asserted by
`the_palw_state_version_moves_the_identity_and_not_only_the_params_id`. `flow_context` returns
`WrongConsensusParams` on an identity mismatch, so an un-upgraded node and an upgraded one never
complete a handshake. **An un-wiped peer cannot feed the new chain.** Ordering is therefore an
operational preference, not a safety constraint, and a host that cannot be reached today does not
have to hold up the ones that can.

What it does mean is that every un-upgraded node keeps running the OLD chain among themselves —
a fork that persists until each operator upgrades. That is a communications problem, not a
contamination one, and it is why the announcement matters.

## Preconditions

1. **C and .114 cannot be driven from this session.** Someone with credentials must upgrade them.
   Not a blocker for the others — see the correction above — but until they do, they stay on the
   old chain and are refused by every upgraded node.
2. **Community participants must be told**, and must wipe their own datadir. Without that they hit
   the startup genesis-mismatch guard — or, worse, keep a fork alive that new nodes can still reach.
3. **ibm's root disk is at 96%** (13 GB free on 290 GB). A fresh datadir plus the retained build
   tree needs headroom that is not there today.
4. **`misaka-t11-node1` is in an OOM restart loop** — `NRestarts=50`, `Failed with result
   'oom-kill'`. Re-minting does not fix it; it will resume looping on the new chain.
5. **Downstream state on .113 references the old chain**: the explorer DB filler, the REST API, the
   DNS seeder and the MTP service. The explorer DB and the MTP ledger need their own reset, or they
   will serve rows for a chain that no longer exists.

## The sequence, once those are settled

```bash
# 1. stage the candidate on every host (non-destructive, do it first and verify)
/root/host-build-from-branch.sh palw-audit3-2026-08-29
grep -E '^HEAD=|^EXIT=|^STAGED' /root/deploy-build.log
# `--version` prints only "kaspad 1.1.0". The fingerprint is a STARTUP line, so ask the binary the
# only way it answers: boot it against a throwaway appdir, read the line, stop it. kaspad ignores
# SIGTERM and handles SIGINT.
rm -rf /tmp/fpcheck && /root/t11/kaspad.candidate --testnet --netsuffix=11 --appdir=/tmp/fpcheck \
    --nodnsseed --disable-upnp --listen=127.0.0.1:39311 --rpclisten=127.0.0.1:39312 \
    > /tmp/fpcheck.log 2>&1 &
sleep 20; grep -a 'Consensus params fingerprint' /tmp/fpcheck.log; pkill -INT -f 'appdir=/tmp/fpcheck'
# must read: 95265934e8965e91f3c22281af735bcd38527b5ee89fa09a05290db566d444a3 (network testnet-11)

# 2. STOP EVERY HOST FIRST. kaspad ignores SIGTERM and handles SIGINT.
systemctl kill -s INT misaka-t11-node0 misaka-t11-node1     # ibm
systemctl stop misaka-t11-node0 misaka-t11-node1
#   …and the same on A (misaka-t11-node-b), .113 (misaka-t11-node), C, .114

# 3. only when every host is confirmed down: wipe
rm -rf /root/.t11/misaka-testnet-11 /root/.t11b/misaka-testnet-11        # ibm
#   /home/ubuntu/.t11/misaka-testnet-11 on A, /root/.t11/misaka-testnet-11 on .113

# 4. swap the binary
cp -a /root/t11/kaspad.candidate /root/t11/kaspad.incoming && mv /root/t11/kaspad.incoming /root/t11/kaspad

# 5. start, and confirm the announced fingerprint on each node before starting the next
systemctl start misaka-t11-node0
grep -a 'Consensus params fingerprint' /root/.t11/misaka-testnet-11/logs/rusty-kaspa.log | tail -1
```

`cp`, not `mv`, at step 4: the running process held that inode, and replacing the file under a live
mapping is how a node comes back as something nobody built.

## Also worth clearing in the same window

A node at `169.58.13.16` answers to the testnet-11 network name on a **different genesis**
(`d25a80b9…` against the fleet's `c664a224…`) and retries the handshake about every two seconds. It
is being refused correctly, but it is a stale deployment that somebody should stop.

## What the re-mint carries

Everything in `docs/palw-mainnet-audit3-2026-08-29.md`: four criticals, eleven highs, the M2-10
producer gate, and the R-3 acceptance test made deterministic. Two items are explicitly recorded as
fixed-but-untested, in the source rather than in a table — S-04's refusing half (needs a two-bond
harness) and S-01's court round trip (needs a two-node one).


---

## Outcome (2026-08-29, same day)

**Migrated to `95265934…`:** `169.58.39.220` node0 (producer), `160.16.131.119` (A, producing),
`169.58.232.113` (node + explorer + seeder + MTP), `5.104.81.23` (C, seat2).

**Withdrawn from the network:** `169.58.232.114` — stopped, `systemctl disable`d and its datadir
removed at the operator's instruction. It is a games host and no longer participates. No DNS name
resolved to it, so nothing needed changing there; the join doc's fallback-entry list did name it and
has been corrected.

**Reachability, corrected.** The earlier table said C and `.114` were unreachable. That was an
artefact of driving them *from ibm with ibm's key*; both answer directly to `~/.ssh/claude_key`.
The right lesson is to try the key you have from where you are before recording a host as
unreachable.

**Second nodes stopped, one per host.** `misaka-t11-node1` on ibm and seats 3/4 on C each map the
34 GiB Qwen3.6 artifact; two of those on a 23-24 GB host is an OOM loop, and on ibm it was killing
the *producer* (node0 restarted 3x, node1 4x). Stopping node1 took ibm from 20.0 GB used to 9.9 GB
with 14 GB available. This is reversible (`systemctl enable --now`) and is a capacity fact, not a
consensus decision: the host cannot hold both.

**Disk.**

| host | before | after | what was freed |
|---|---|---|---|
| ibm `169.58.39.220` | 97% (12 GB) | 80% (59 GB) | 6 superseded datadir backups, journal + rotated syslog, `/tmp` algo-4 GGUFs, 3 rebuildable `target/` dirs |
| C `5.104.81.23` | 99% (5.7 GB) | 42% (227 GB) | `/home/Azaraseal/.rusty-kaspa/misaka-testnet-10` — 215 GB, last written 2026-07-30, no unit referencing it, no open files — plus the old-fingerprint t11 datadirs |
| A `160.16.131.119` | 20% | 17% | two closed June logs (15 GB + 1.3 GB) |
| `.113` | 4% | 4% | nothing needed |
| `.114` | 10% | 9% | its t11 datadir, on withdrawal |

No model artifact was deleted on any host.

**DNS.** `seeder1.misakascan.com` → `169.58.39.220`, `169.58.232.113`; `seeder3.misakascan.com` →
`5.104.81.23`, `169.58.39.220`. All four are on the new fingerprint, so the seed names hand out only
nodes a joiner can actually reach. `seeder2`/`seeder4.misakascan.com` and `seeder1.misakastake.com`
do not answer, and `seeder{1,2,3}.misakachain.com` all resolve to `85.131.213.182`, a registrar
wildcard rather than a seeder — both pre-existing and both a registrar-side fix. Note that
testnet-11 ships `dns_seeders: &[]`, so none of this is on the joining path for t11 today; the
fleet uses `--addpeer`.
