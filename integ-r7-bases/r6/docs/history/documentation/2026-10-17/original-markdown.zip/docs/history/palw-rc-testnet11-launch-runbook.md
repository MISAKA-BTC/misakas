# PALW-RC (testnet-11 / ConsensusV2) — launch runbook

> **Token identity (2026-10-07):** The token name is **Misaka** and its ticker is **BILI** ([ADR-0174](../adr/0174-token-name-misaka-ticker-bili-address-prefix-unchanged.md)). MSK in retained measurements, quotations, command/output examples, identifiers or chain-ID mnemonics is a legacy label for the same coin; it does not change amounts, units, protocol IDs or address prefixes.

**Status: the code path is complete and tested end to end; every remaining step is an operator
decision this repository cannot make.** A block produced by the real production path — a real
BASE-0 inference, the real ruleset, an ML-DSA-87 signature under a registered bond — is accepted by
consensus and becomes the sink
(`palw_rc_a_real_execution_produces_a_block_the_chain_accepts`).

This document is the list of things a binary cannot do for you, in the order they have to happen.

---

## 0. What testnet-11 is, and what it is not

`NetworkId` **testnet-11** is the PALW **ConsensusV2** ruleset (ADR-0042): PALW is the consensus
work, algo-6 (`POW_ALGO_ID_PALW_COMMITTED_V2`) is the attempt lane, BASE-0 is the permanent liveness
floor (ADR-0039 W6′), and the class economy is on chain (ADR-0045/0046).

It is deliberately **not** testnet-10 or testnet-11 with a flag flipped. Those networks run V1 PALW
proof-of-work, and `validate_palw_v2` refuses to install a V1 fence beside a V2 ruleset — which is
exactly why this is a new identity rather than a fork of an old one. Nodes of the three networks
reject each other at the handshake, on purpose.

Two properties worth knowing before anything else:

* **The EVM lane is ON from DAA 0 — and the lane ships in the default build (2026-08-21).**
  testnet-11 carries the lane and the RC is the network t11's traffic moves onto, so the RC carries
  it too. `MAINNET_PARAMS` never activates it, so the RC and mainnet differ here — a known,
  deliberate difference rather than an inherited accident.
  **`build_block_template` cannot construct a valid template without the feature.** A non-evm
  binary is now refused at STARTUP with the rebuild command rather than panicking at its first
  template, which is after boot, after IBD, and after an operator has every reason to think the
  node is fine.
* **`dns_seeders` is empty and cannot be filled from code.** Inheriting the other testnets' seeders
  would be worse than empty: those records answer with testnet-10/11 nodes, which this network
  rejects, so discovery would look configured and find nobody.

---

## 1. The genesis card — a REGISTRY, not a bond

**Six rows, six distinct operator keys.** `derive_panel_v2` excludes a claim's own executor by
bond, by operator and by key and seats one bond per operator, so a 5-seat panel needs six — and
`BondRegistered` may not ride a transaction, so a registry too small has no later repair. A
one-row card is refused by the genesis gate (`PanelCannotBeSeated`), which is what the tool used
to produce every single time before 2026-08-22.

Two commands, split along the secrecy line: **rows are emitted where the secrets live, assembled
where they do not.**

```bash
# ON EACH OPERATOR'S HOST — two keys, secrets never leave it
misaka key gen --out /etc/misaka/t12-bond.key
misaka key gen --out /etc/misaka/t12-operator.key

# ON THE SAME HOST — one public row (two verification keys + an address payload, nothing signable)
palw-rc-genesis --emit-row --bond-index 3 \
    --bond-seed /etc/misaka/t12-bond.key --operator-seed /etc/misaka/t12-operator.key
#   the payout DEFAULTS to the bond key's own address — matured rewards are then spendable
#   by the seed that signs for them, with no second key to get wrong

# ANYWHERE — collect the six rows into a file and assemble
palw-rc-genesis --rows /tmp/t12-rows.txt
```

`--rows` puts the registry through `palw_rc_params_from_artifacts` — the same call a node makes at
boot — so an ACCEPTED card is one a node accepts, and it prints the `consensus_params_id` a node
will log. **Changing the premine (which the bond fee floats do) requires re-pinning
`PALW_RC_GENESIS`**; the M-07 guard refuses to boot on a mismatch and
`cargo test -p kaspa-consensus --lib repin::print -- --ignored --nocapture` recomputes it.

Everything else about the genesis is derived. Run it with no arguments to see what:

```bash
cargo run --release -p misaka-palw-base0 --bin palw-rc-genesis
```

It prints what this build derives, and this is the same on every machine — nothing to host, nothing
to mirror:

```
base0 seed          0x50414C575F524330
geometry            4 layers, hidden 256, ffn 512, heads 4x64, vocab 4096, n_ctx 512, tile 64
execution_class_id  c185df95388739dc549777a9ca43866ddf773f1c84df77479a9eb59ba8d1d2b2…
artifact_root       204fea7788fd4c2dc20812d0c07e0aa3b9edea60baa7c89f741bf995bc6044ab…
One block's work — canonical job (8 prefill, 4 decode):
  step leaves         7900
  wall time           0.038 s
```

`artifact_root` used to be described as "the one input code cannot mint". Half of that stopped
being true: `palw_base0_profile`'s own doc says *BASE-0 has no file: it is a specification*, and a
specification's artifact can be **produced** by a rule. Every weight byte derives from one pinned
seed, so the root is re-derivable by anyone in any language rather than being a 4.5 MiB blob every
participant must be handed a correct copy of.

The half that really cannot be minted is the **bond**:

| fact | what it is | who makes it |
|---|---|---|
| `--bond-index` | which premine output backs the genesis bond (0..=40) | you |
| `--bond-pubkey` | the ML-DSA-87 **verification** key that signs attempts under it | `misaka-cli` |
| `--operator-pubkey` | the operator identity key — panel dedup is keyed on it | `misaka-cli` |
| `--payout-payload` | the 64-byte P2PKH-ML-DSA-87 owner payload matured rewards pay to | you |

> ### It is a REGISTRY, and one bond is not a network
>
> `PALW_RC_GENESIS_BONDS` is a **list**, and the genesis gate refuses a list that cannot run a
> chain. Two properties, both checked at assembly rather than discovered at block three:
>
> * **`seat_count + 3` distinct operators — `seat_count + 1` is the floor, not the target.**
>   A panel seats one bond per OPERATOR and never the claim's own executor, so a 5-seat panel needs
>   six *to draw at all*. Below six no claim is ever licensed: every one voids at `BindTimeout`,
>   `safe_weight` stays zero forever, and each block's escrowed worker carve is burned.
>   **Ship eight.** At exactly six, one seat leaving eligibility — a retirement, or a slash under
>   `min_collateral_sompi` — halts every panel, and ADR-0065 D1 (seat maturity) cannot be armed at
>   all: `validate_palw_v2` refuses an armed maturity fence on a registry with no spare seat, so the
>   node will not boot. `palw-rc-genesis` prints both numbers and says which is which.
>   **A registry of clones is one operator however long it is**: each row needs its own
>   `--operator-seed`.
>
>   **And every row you ship has to be STAFFED.** The draw is liveness-blind: an offline bond still
>   takes a seat, and a panel reaches quorum by presence alone. With `seat_count = 5, quorum = 3`,
>   at most `seat_count - quorum = 2` registered bonds may be unattended before panels start
>   failing on absence. At eight registered that means **six hosts actually running the seat
>   service** — growing the registry past what the fleet can staff makes panels fail MORE often,
>   not less. Assign the two seats added on 2026-08-31 before the relaunch, or the network runs at
>   exactly zero quorum margin.
>
>   *(Corrected 2026-08-31: this used to say "`BondRegistered` may not ride a transaction, so there
>   is no later repair — the registry you ship is the registry the network has for its whole life."
>   That is false in this build. A `BondRegistered` carrier IS admitted on a live chain once it
>   locks the collateral it declares — `virtual_processor/processor.rs:4922` — so a thin registry
>   can be grown later. Two things the repair does NOT fix, which is why the genesis size still
>   matters: a chain that is already halted produces no blocks, so no carrier can land, and D1's
>   arming guard reads the GENESIS registry, so a network that grew post-genesis still cannot arm
>   the fence.)*
> * **Collateral that outlasts the bind window.** A claim holds its reservation for `window_bind`
>   (600 DAA) and DAA advances only when blocks are produced, so a ceiling admitting fewer
>   concurrent claims than the window is long is a deadlock with no timeout. The requirement is
>   derived (`palw_v2_collateral_for_bind_window_v1`) and the gate names the number if you are
>   short.
>
> The shipped bundle failed both: one bond, 400,000 sompi, `supported: 2`. It would have made two
> blocks and stopped.

**Generate the keys with `misaka-cli` and keep the secrets there.** `palw-rc-genesis` generates no
keys and touches no key material: a tool that minted a key would be minting an identity, and the
whole point of a bond is that somebody holds one. Pass only verification keys.

Then run it again with all four, and it prints the paste-ready block for
`consensus/core/src/config/params.rs`:

```
PALW_RC_GENESIS_ARTIFACT_ROOT     (already pinned)
PALW_RC_GENESIS_BOND_INDEX
PALW_RC_GENESIS_BOND_PUBKEY
PALW_RC_GENESIS_OPERATOR_PUBKEY
PALW_RC_GENESIS_PAYOUT_PAYLOAD
```

Until those are pasted, `Params::from(testnet-11)` returns the **bundle-free base identity** — a
hash-only chain with the RC genesis — and `kaspad` says so at startup. That is the shipped state on
purpose: a placeholder key would be an identity nobody holds the secret for, which looks like a
network and is not.

A filled card and an empty one differ at `consensus_params_id()`, so which one a node is running is
a fact the **handshake reports** rather than something an operator has to be trusted to have done.

> A card that is set but does not assemble panics at startup with the genesis gate's own message.
> Falling back to the base would put the node on a chain it cannot join and tell it nothing.

---

## 2. Build

```bash
cargo build --release -p kaspad -j 4
```

**A seat's honest replay needs 424 MB on this fleet, and that is measured rather than bounded.**
Raised because the memory picture below is tight and a 4.3 GB figure was circulating: 4.3 GB is the
allocation for a class at the LADDER TOP (n_ctx ≈ 16,384 dense), which this genesis does not
register. The 512 row's own job allocates `step_leaf_count × 64` bytes = **424 MB**, and the count is
the binding's own — the price equality pins it to the job's enumeration, so nobody can inflate it.
Above the handed ladder the seat refuses **by name, before any allocation**
(`base0_fp_binding_step_space_v1` → `LeafCountOutOfRange { got, max }`). So a seat replay is not a
memory risk on these hosts; the build is.

**`-j 4`, not the default, and this is a relaunch hazard rather than a preference.** Every host in
this fleet is a **23 GB, 8-CPU** machine, and every one of them is already running the chain it is
about to be wiped of. Measured 2026-09-03, before touching anything:

    169.58.39.220 (ibm)   8 cpu   23 G ram   13 G available   swap 4/7 used    kaspad RSS 18.0 G
    169.58.232.113        8 cpu   23 G ram   10 G available   swap 2/15 used   kaspad RSS 22.4 G
    5.104.81.23           8 cpu   23 G ram   12 G available   swap 4/19 used   kaspad RSS 20.1 G

A default `cargo build --release` takes one rustc per CPU. Eight concurrent rustc on this workspace
against 10–13 GB of headroom, with swap already a third to a half consumed, races the producers into
swap — and the process the kernel reaches for when it runs out is the **15 GB kaspad**, not the
build. So the failure is not a slow build: it is the live chain being OOM-killed during the build
that precedes its own replacement, which then looks like an unrelated outage.

The build step sits **before** the fleet stop in §4b for a good reason — you want to know the binary
compiles while the old network is still up — so the fix is the job count and not the ordering.
`-j 4` was measured on ibm alongside both live producers: four rustc, minimum free memory 11.8 GB,
no swap growth, no producer disturbance.

*(If you have already stopped the fleet, the ceiling is gone and the default `-j` is fine. The rule
is: bounded while anything is producing.)*

The `evm` feature is a **default** feature of kaspad, so the plain build is the fleet build — the
revm executor runs in-process, no separate daemon. Only a `--no-default-features` binary lacks the
lane, and it refuses to start on this network rather than failing later. `--features evm` in older
scripts is a harmless no-op.

No other feature flags. A `ConsensusV2` node needs no model runtime to **verify** — ADR-0042
Decision 4. Only a producing node links the engine, and it links it because it is producing.

---

## 3. Bring up the first node — and it must be the producer

A `ConsensusV2` network with a genesis and no producer has one block forever. The producer is
in-process:

```bash
kaspad --testnet --netsuffix=11 \
  --palw-produce \
  --palw-producer-key=/path/to/bond-seed.hex \
  --palw-producer-bond=<txid>:<index> \
  --palw-producer-pay-address=<ML-DSA-87 P2PKH address> \
  --utxoindex
```

* `--palw-producer-key` is the **32-byte hex seed** whose verification key you registered in §1.
  It is loaded with the same hardened path the validator uses: owner-only permissions at creation,
  symlinks refused, fail closed.
* `--palw-producer-bond` is the same outpoint the genesis card names.
* `--palw-producer-pay-address` **must** be ML-DSA-87 P2PKH. A legacy or ECDSA address puts a
  non-PQ script in the coinbase; the block is dead on arrival and its reward poisons descendants'
  fan-out. The producer refuses at startup rather than at the first template.

The producer holds and says why when it cannot produce — a wrong key, a spent epoch budget, or a
full exposure ceiling are each reported by name. **A held producer is not a broken one**: the
exposure ceiling is the ruleset's rate limit on how many claims one bond may have open at a time,
and it clears as claims resolve.

### What a block costs

One template and one nonce bucket is one job. The job is anchored on the template's **pre-pow
hash** and the bucket — not on the challenge — and since ADR-0072 the job's execution IS the draw:

* one inference per draw (~38 ms on the RC floor, ~9 s on the hybrid tier), then
* two hashes: the class ticket and the Layer-0 digest are both functions of the execution
  commitment, which no nonce inside the bucket and no timestamp moves, so there is no nonce
  search — a lost draw is re-rolled by the next bucket, which is a different job and a second
  inference;
* one ML-DSA-87 signature, on a hit only.

A producer can still grind jobs by reshuffling the block it builds, which moves the pre-pow hash —
and that costs a full inference per try, which is now the price of EVERY draw, not only of a
reshuffle. Expect roughly `1 / (P_class × P_bits)` inferences per block per producer; the DAA
relaxes `bits` as the network's draw rate is now its inference rate.

---

## 4. Bring up the rest, and connect them

`dns_seeders` is empty (§0), so nodes find each other by `--addpeer`. `kaspad` WARNS at startup when
it has neither seeders nor explicit peers rather than sitting alone in silence.

```bash
kaspad --testnet --netsuffix=11 --addpeer=<producer-host>:26411 --utxoindex
```

Adding seeders later is a plain edit, not a flag day: `dns_seeders` is deliberately **outside**
`consensus_params_id` — where to find peers is not a rule about blocks.

**Public reachability is its own problem and this repo has been bitten by it before.** See
[t10 public P2P reachability] in the operator notes: a proxy in front of the P2P port masks peer
IPs, and a socket bridge is not the same thing as a delegated seed name. Test reachability from
outside your own network before announcing anything.

**Start every seat BEFORE the producer.** Trace material is gossiped once and never replayed, so
a seat that is still catching up when a claim is made never sees that claim's material — and it is
*right* to file `Unavailable`, because it genuinely cannot verify. Three such verdicts are a quorum,
and the claim voids for `ProducerWithholding` with its escrow destroyed. testnet-11's relaunch
measured this exactly: the seats brought up after the producer each filed **158** `Unavailable`
verdicts covering the same claims, and then filed nothing but `Valid` once caught up. Nothing was
wrong with the network; the launch order was wrong. Bring every seat to a synced tip first, and
only then start producing.

**Every registered bond needs a node, and the registry has no spare.** `derive_panel_v2` seats
`PALW_V2_PANEL_SEATS` bonds and excludes the executor, so a six-row registry seats *all five*
non-producing bonds on *every* claim. A bond whose node is not running is not idle — it is a silent
seat, and `slash_silent_seats` takes `claim.reserved` from it on every licensed claim. It drains,
and a drained bond cannot be replaced: `BondRegistered` may not ride a transaction, so the only
repair is a flag-day relaunch. **Decide where each bond's node will run BEFORE generating its
seed**, because the seed is generated on the host that will run it and does not move afterwards.
testnet-11 had to re-mint over exactly this: bond 4's seed was on a host whose egress to the fleet
turned out to be filtered upstream.

**Reachability measured for testnet-11** (2026-08-22, from outside the fleet):

    169.58.39.220:26411
    5.104.81.23:26411

Two public entry points, which is what an announcement needs; a third fleet host peers outbound
only. Which bond each host carries is deliberately not published — on a fleet this small the map
would name the machine to attack for a panel quorum.

---

## 4b. RELAUNCHING over a network that already exists

§§1–4 describe a first launch. A relaunch is a different procedure with one hazard that has bitten
this fleet before, and it is not a variation on "restart the nodes".

**A relaunch whose genesis moves is not an upgrade.** Adding premine or community entries changes
the genesis UTXO set, so the genesis hash moves, and then **no earlier appdir and no earlier binary
can join at all** — the failure is at handshake, not at a rule, which is strictly less legible than
a ruleset mismatch. Everything below assumes that case.

### The wipe list is what the RUNNING NODE connects to — and the journal does NOT tell you that

Before stopping anything, ask the node. An ssh config, a systemd unit and a launch script all record
intent; only the live connection set records fact, and a relaunch is only as complete as the set of
hosts that actually carry the chain.

**An earlier version of this runbook prescribed a journal scrape, and it undercounts. Measured
2026-09-03 on the live fleet, the two methods disagree badly:**

    journalctl 'Connected to (incoming|outgoing) peer', 3h window  ->  3 addresses
    ss -tnp state established, on the p2p ports                    ->  9 addresses

The journal line is emitted at connection ESTABLISHMENT. A peer that connected before the window
opened and has stayed connected since never appears in it again. The scrape measures the shape of
the log, not the thing the log describes — and the single most-connected peer on this fleet
(`169.58.232.113`, which we dial OUTBOUND four times, and which runs three kaspad of its own) had
**zero journal lines in three hours**. A wipe driven by the journal list would have left it running,
and an unwiped peer re-feeds the old chain by IBD to every host you just cleaned.

**Ask the sockets, in both directions:**

    ss -tnp state established | grep -E '263[0-9][0-9]' \
      | awk '{split($3,l,":"); split($4,r,":"); \
             print (l[2] ~ /^263/ ? "INBOUND " : "outbound"), r[1]}' | sort -u

Then split that list in two, because the halves need opposite treatment:

| | how to tell | what to do |
|---|---|---|
| **ours** | **answers a key you hold, today**: `ssh -i ~/.ssh/claude_key root@<ip> hostname` | stop, then wipe — every appdir, not "the" appdir |
| **not ours** | does not | cannot be wiped, and does not need to be — see below |

**The ownership test is the ssh, and only the ssh.** `known_hosts` is useful for building the
CANDIDATE list and is worthless as the test, for two independent reasons and both of them bit
someone today:

- **It is per-machine and per-user.** It records what THAT account has SSH'd to, which is not fleet
  membership. Run the rule while logged into a node and you may conclude nothing is yours, wipe
  nothing, and hand the old chain back to every host you just cleaned by IBD.
- **`grep` cannot read it.** With `HashKnownHosts yes` — the default on most distributions, and the
  case on every entry of ibm's file — every line is `|1|<salt>|<hash>` and a plain `grep <ip>`
  returns **zero for hosts that are present**. Use `ssh-keygen -F <ip> [-f <file>]`, which hashes
  the query before comparing. Measured on ibm: `grep` 0, `ssh-keygen -F` 1, same host, same file.

That second one is the same failure shape as everything else in this section — a tool that reports
ABSENCE when it merely cannot see — and it is the more dangerous of the two, because the per-machine
problem at least gives you a suspiciously empty list, while the hashing problem gives you a
confidently wrong one on the machine you trust most.

### "Connected" is three different numbers, and only one of them is peers

A reader who counts `ss` output and compares it to `/health` will get a disagreement and conclude
something is broken. Nothing is. Measured on the public entry, all three at once:

    10  established TCP sockets on the p2p ports
     6  handshake-complete peers
    10  distinct dialers presenting a foreign genesis

A peer can hold an ESTABLISHED socket and never complete a handshake — a foreign-genesis dialer is
refused at the handshake and keeps the socket. So the TCP list is the right instrument for the WIPE
list (it is the set of machines that could re-feed a chain) and the wrong one for "how many peers do
we have". The loudest talker on this fleet, `111.67.115.228`, holds an established socket and is
being refused ~3,000 times a day: it is foreign, we cannot wipe it, and it is not feeding anyone the
old chain — it is being turned away by us.

**Wipe by ENUMERATING each host's kaspad processes, never by naming an appdir.** The fleet does not
hold one appdir per host:

    169.58.39.220  (ibm)  /root/.t11  /root/.t11b
    169.58.232.113        /root/.t11  /root/.t11c  /var/lib/misaka-minerpool/slots/slot-01/appdir
    5.104.81.23           /root/.t11

The miner-pool slot on `.113` carries a full appdir under `/var/lib/`, nowhere near the others, and
is invisible to anything that greps for `.t11`. Get the list from the processes themselves — and
**not with the obvious command**, which this runbook carried until 2026-09-03:

    # WRONG. `pgrep -f` matches the command ASKING: the remote shell's own argv holds both
    # "kaspad" and the literal regex, so this prints `appdir=[^` as an appdir on every host.
    # It also misses `kaspad.candidate`, which is a RUNNING NODE.
    pgrep -af kaspad | grep -oE 'appdir=[^ ]+' | sort -u

    # RIGHT: walk /proc and match the EXECUTABLE's basename. The asking shell's exe is `bash`,
    # so it cannot appear; any `kaspad*` build does, whatever it is called.
    for d in /proc/[0-9]*; do
        exe=$(readlink -f "$d/exe" 2>/dev/null) || continue
        case "${exe##*/}" in kaspad*) ;; *) continue ;; esac
        printf '%s  %s\n' "${exe##*/}" "$(tr '\0' '\n' < "$d/cmdline" | grep '^--appdir=')"
    done | sort -u

`scripts/ops/relaunch-fleet-wipe.sh census` does exactly this across all three hosts.

**And the seeders are part of the wipe.** Two hosts run `misaka-dnsseeder` (`.113` and
`5.104.81.23`). A seeder that survives the relaunch keeps handing out old-genesis peers to every new
joiner, so the first thing a newcomer meets is the dead chain — with a handshake failure that looks
like the joiner's fault. Stop both, and clear their peer databases, before the producer starts.

**The units are what restart them.** Stopping a process without masking its unit is not stopping it:

    ibm    misaka-t11-node0  misaka-t11-node1  misaka-faucet  palw-drill-attest  palw-drill-watch
    .113   misaka-t11-node   misaka-t11-seat4  misaka-minerpool  misaka-pool-slot@01  misaka-dnsseeder
    .23    misaka-t11-seat2  misaka-miner-c    misaka-validator-c  misaka-dnsseeder

**`5.104.81.228` looks like ours and is not — settled, not assumed.** It connects INBOUND to both
of ibm's ports and it IS in `known_hosts`, which is how it got onto the candidate list. But port 22
is open and refuses `claude_key` for both `root` and `ubuntu` (port 2222 is filtered). We hold no
credential for it. A `known_hosts` entry records that we once accepted a host key, not that we can
log in — so it is evidence of contact, never of control, and it is exactly the kind of entry that
makes a candidate list longer than the wipe list. **It cannot be wiped, so it is external**, and the
paragraph below covers it. The general rule: an address is "ours" only if it answers a key you hold
*today*; anything else is a stranger with a familiar address, and the check is one ssh, not a memory.

**And the converse is the part that cannot be fixed by wiping:** the five external peers
(`60.114.127.4`, `183.176.36.141`, `121.81.248.189`, `111.67.115.228`, `5.104.81.228`) are not ours
and cannot be stopped. They will keep answering to this network name on their own genesis after the relaunch,
which is exactly the state §"the name is already contested" describes. That is not a fault to
resolve before launching; it is the reason the genesis hash is the value a joiner checks.

### The ordering hazard: stop EVERY host before wiping ANY

Wiping hosts one at a time does not work, and the reason is not obvious: **an un-wiped peer
re-supplies the old chain by IBD to a host that has just been wiped.** The wiped node syncs the
chain it was wiped to escape, the operator sees a working node, and the network is the old one. It
has happened here.

    1. stop the service on EVERY host          # all of them, before step 2 anywhere
    2. verify none is running                  # a host that failed to stop is a host that will re-seed
    3. wipe each appdir                        # only now
    4. install the new binary on every host
    5. start the producer FIRST (see below)
    6. start the rest

**Do not do steps 1–3 by hand.** `scripts/ops/relaunch-fleet-wipe.sh` encodes five findings that cost a
night to measure, and every one of them is a way to believe a host is stopped when it is not:

    scripts/ops/relaunch-fleet-wipe.sh census        # changes nothing; read it before anything else
    scripts/ops/relaunch-fleet-wipe.sh stop          # dry run; add --execute
    scripts/ops/relaunch-fleet-wipe.sh verify        # THE GATE. Do not proceed while it refuses.
    scripts/ops/relaunch-fleet-wipe.sh wipe --genesis <hash>

| the naive form | what it misses |
|---|---|
| the peer set from `journalctl` | the line is emitted at CONNECTION, so the longest-lived peer is invisible. It found 3 of 9; `ss -tn state established` finds all of them |
| appdirs named by a `.t11` glob | one host carries a full appdir under `/var/lib/misaka-minerpool/slots/…` |
| `systemctl list-units` without `--plain --all` | a FAILED unit's name is the bullet glyph, and every ENABLED-but-inactive unit is absent — those are exactly the ones that come back at the next boot |
| `pgrep -af kaspad \| grep appdir=` | matches the command ASKING, and prints its own regex as an appdir |
| `pgrep -x kaspad` | misses `kaspad.candidate` — a *running node* dropped from the list. Walk `/proc` and match the executable's basename |

### A node that no unit owns survives `stop` entirely

Measured on ibm, 2026-09-03: a `kaspad.candidate` on `/tmp/fpchk`, cgroup
`/user.slice/user-0.slice/session-28377.scope` — **a login session, not a service.** Stopping every
`.service` leaves it running and `verify` then refuses, correctly.

**Before this was fixed the procedure had no next step**, and that is the dangerous part rather
than the missed process:

> **A gate with no documented way to satisfy it teaches people to bypass it.** An operator who has
> done everything above and is still told NOT CLEAN will conclude the gate is broken — and the
> gate is the only thing between a partial wipe and a survivor that re-feeds the old chain.
> **`verify` was right. `stop` was incomplete. Being right had no exit.**

`stop` now walks `/proc`, skips anything whose cgroup contains `.service`, and reports the rest by
pid with its cgroup, so an operator can see the thing is not a unit rather than guess.

**One host had one; the other two had none.** That is why it survived a working procedure:
**two of three hosts confirming a step is the most persuasive possible way to be wrong about the
third.**

### The producer starts first, and it is not a preference

The floor class must have a producer or **DAA does not advance and the chain cannot leave that
state by itself.** A network of seats with no producer looks healthy in every log line and produces
nothing. Start the producing node, confirm `[palw-producer] produced block #N`, and only then bring
up the seats.

### Before declaring it up

| check | how | what a bad answer means |
|---|---|---|
| **this is the new chain** | the genesis hash in the startup log equals the card's | a host was not wiped, or the binary is the old one |
| **every host agrees** | `consensus_params_id` identical across all startup logs | a host has the old binary — it will reject or be rejected |
| the old chains are refused, not absent | genesis-mismatch warnings for foreign peers | **this is expected and healthy.** At least four chains answer to this network name; a node that sees none of them may not be reachable at all |
| a peer actually connected | `P2P Connected to incoming peer` / `Registering p2p flows` | zero of these AND zero mismatches means nothing is dialling you |

**That third row is the one to read carefully.** Genesis-mismatch warnings after a relaunch are not
a problem to fix; they are other people's chains being correctly refused. A log full of them and a
node with peers is the healthy state. What is NOT healthy is silence in both columns.

## 5. Verify the network is what you think it is

| check | how | what a bad answer means |
|---|---|---|
| the ruleset | compare `consensus_params_id` in the startup log across nodes | a node is running a different card, or an unfilled one |
| the lane | the producer's first log line names algo 6 | the bundle did not install; §1's constants are unset |
| production | `[palw-producer] produced block #N …` | see the hold reason it prints instead |
| **the lattice is turning over** | `[palw-producer] palw weight=… live_total=… final_claims=… unresolved=…` | **`live_total` at zero is the failure.** `weight` at zero is NOT — see below |
| the seats are answering | `[palw-panel] filed a "Valid" receipt for claim …` on the NON-producing nodes | no material is reaching them, or their bond holds no seat |
| the quorum reaches the chain | `[palw-panel] submitted ReceiptLicensed for claim …` | `no fee UTXO resolves` ⇒ the genesis float was spent or the card is unset |

**The weight line is the one that matters — and it must be read in two stages.** A network can
produce blocks, gossip material, file receipts and still certify nothing, and nothing else in the
log says so.

*Before the first `Final`, which is `window_challenge` (1200 DAA ≈ **40 hours** at the frozen 120 s
cadence) after the first licensed claim:* `weight` and `final_claims` are zero **by construction**,
on every healthy chain, and a young network cannot be judged by them. Read `live_total` instead —
it is the third key of the fork-choice order and carries the bounded immature contribution, so it
climbs from the first block. `live_total` rising with `weight` at zero is correct. Both at zero is
a lattice that never started: check that a funded submitter exists and that
`[palw-panel] submitted ReceiptLicensed` appears.

*After that:* `weight` must leave zero and `final_claims` must climb. A flat zero `weight` past
DAA 1200, with `unresolved` still rising, is a hash chain wearing PALW's clothes.

---

## 5b. What testnet-11 carries, and the one lane it does not

Checked against the shipped bundle rather than asserted, because "all of PALW works" is a claim
somebody should be able to verify:

| capability | on t12 | evidence |
|---|---|---|
| BASE-0 attempt lane (algo 6) | **live** | every block is a real inference; `[palw-producer] produced block` from block 1 |
| the claim lattice — panel, receipts, quorum, `Final` | **live** | `submitted ReceiptLicensed` and `live_total` climbing; `weight` follows at DAA 1200 (§5) |
| the court (step dispute, interactive ladder) | **armed, one-sided** | the ladder narrows and an arithmetic close adjudicates, and a close is now bound to the step the ladder reached. But NOTHING IN THIS TREE CONSTRUCTS `CourtDisclosed` — there is no responder — so a dispute that is opened cannot be answered, only run out. Opening costs the challenger the claim's own stake and the opening rung runs on the session budget, so an unanswerable accusation ends against the accuser rather than convicting the accused; it is a real cost on both sides, not a working two-party protocol |
| bond retirement | **live** | an owner ML-DSA-87 signature over the bond key releases the collateral lock |
| bond registration, post-genesis | **live** | `palw_bond_registration_binds_its_carrier_v2` is the collateral lock: the registration names an output of its own carrying transaction BY INDEX, with a zero transaction id — naming it by id is a hash fixed point, since the object rides in the payload and the payload is in the id — and the chain substitutes the id it observes. That output must hold at least the collateral declared and pay to the P2PKH of the payee named. The carrier proves the money, the signature (made over the zero form) proves the owner. `--palw-register-bond` builds one. Genesis bonds remain necessary only to seat the FIRST panel |
| pruned sync (serving the pruning point's PALW state) | **live** | captured at pruning-advance and served from its own store row; a node that joined by a pruned sync can hand it on |
| every lattice window | **real values** | bind 600, receipt 600, challenge 1200, court 2400 — none fenced to `u64::MAX` |
| claim retirement | **live** | `CLAIM_RETIREMENT = WINDOW_COURT` |
| free-prompt COMMITMENT (0x4a) | **open, unclienced** | consensus admits and routes the band (`palw_fp_objects_v3`), so anyone can carry one and have a claim created and licensed — but nothing in this tree BUILDS the transaction, so no first-party client offers it |
| the EVM lane | **live** | active at DAA 0 and in the default build — no `--features evm` to forget |
| lifecycle objects (0x4b) | **live** | the receipt quorum rides one |
| ADR-0144 §9 objective offence (Valid lock, Final liability, PanelFalseValid debit) | **armed at DAA 8,500** | `Params::palw_objective_offence` is `Some(8_500)` on this build. Identity is unmoved, so hosts roll before that height; after the clock at 7,780 the next fork-id height is 8,500. Genesis 10,000 MSK covers one dense-row lock (`required = max_gain/3+1` ≈ 997 MSK). The 400k sompi registry floor is unchanged. Mainnet is `None`. |
| **free-prompt receipt SPEND (algo 7)** | **not producible** | see below |

**The one gap, stated plainly.** ADR-0044's receipt lane is fully implemented in consensus — the
header gate decodes and position-binds an algo-7 carriage, `PalwFreePromptParamsV3` is a required
part of the bundle, and a licensed free-prompt claim's weight is defined to arrive per spent
quantum at the receipt block that spends it. What does not exist anywhere in the tree is anything
that PRODUCES such a block: no `--palw-receipt-produce`, no receipt-spend builder, no miner arm.

**This is not a fence set for testnet-11.** `algorithm_id == POW_ALGO_ID_PALW_COMMITTED_V2` is
part of what ConsensusV2 *is* — the mode's own doc calls it "the only algorithm a V2 network
demands or accepts", and `validate` refuses any bundle that says otherwise. Nothing about this
deployment was narrowed to close the lane; a network that produces algo-7 blocks is a different
ruleset, and the code says so where the check lives: *when the receipt lane becomes producible this
becomes a two-sided check again — and it will be a ruleset change.*

The reason it must stay shut until then is liveness, not caution. Opening it without a producer
would hand cadence share to a lane nobody can fill, and the per-class
DAA retarget then reads the floor as an over-producer at every epoch boundary — dividing its target
by four each time until the class lottery refuses every attempt. That is the exact wedge §6 of the
[launch blockers](../palw-rc-launch-blockers-2026-08-21.md) records, and it is why
`ATTEMPT_SHARE_PERMILLE` is 1000: **a lane that cannot produce holds no cadence.**

Opening it is therefore one piece of work, not two: build the receipt producer, split the share,
re-mint genesis. Until then a free-prompt commitment can be made and licensed on testnet-11, and
its licensed quanta cannot be spent.

---

## 5c. The release gate: no fence is armed without a drill that crosses it

**Standing rule, added 2026-09-18 after two liveness bugs at the same height, both with a fully
green test suite.**

A fence that retires whatever was pacing the chain can leave nothing pacing it, and no unit test
sees that. The rule is right per block. The chain keeps producing. Only the score stops. Both of
these got through every suite in the tree and were caught by a running network:

| what | how it showed |
|---|---|
| ADR-0138's first draft exempted the heartbeat from the DAA score | DAA frozen at 20 with 183 blocks accepted |
| ADR-0105's yield made the miner stand aside for blocks that no longer paced the clock | DAA frozen at 20, miner running, nothing minted |

So, before any build that arms a fence is rolled out:

1. **The drill must cross that fence**, on the devnet, with the fence armed at a low height. Crossing
   it is the test; reaching it is not.
2. **The drill's lanes must be the target network's lanes.** The first bug above was masked once by
   a drill carrying a Layer-0 hash miner that testnet-11 does not have — a devnet with an anchor lane
   never reaches the state a PALW-only chain reaches at the same fence. Read the target's profile
   from the chain with `scripts/drills/misaka-t11-lane-walk.py`, which walks the selected parent back from
   the sink and counts `powAlgoId`, and pass it to the drill as `LANE_PROFILE`; a mismatch is a
   refusal, not a note in a log.
3. **The clock gate must pass.** The drill's step 1b requires the DAA to advance within a bounded
   wait from the first tip past the fence, and prints per-node lane counts when it does not.
4. **Measurements come from the run's own logs**, never from the settings that produced it.
5. **A fence whose activation rewrites existing rows carries a size question, and it is answered
   from the chain.** ADR-0143's is the first: the block that crosses `palw_artifact_root_ownership`
   builds the whole artifact-owner index in one transition, one delta entry per distinct root. The
   count is bounded by the state rather than by a constant, so the roots on the TARGET network at
   the arming height are read before a height is picked — a few hundred crosses in one ordinary
   block, and a number far past that needs the question asked again. This is the same discipline as
   item 2: the drill is held to what the target actually is, not to what it is assumed to be.
   Measured on testnet-11 at DAA 6,263 (2026-09-19): five classes, six lines, **six** distinct
   roots — six delta entries in the crossing block.

```bash
# the target network's lane profile, from the chain
python3 scripts/drills/misaka-t11-lane-walk.py 300 26314

# the drill, held to it
LANE_PROFILE=palw+heartbeat ANCHOR_CLOCK_AT=20 bash scripts/drills/misaka-palw-model-registry-devnet-drill.sh
```

A green suite is evidence that each rule is right on its own. It is not evidence that the chain
still has a clock.

## 6. What is NOT in place, and should be said out loud

> **The complete, evidenced list is
> [palw-rc-launch-blockers-2026-08-21.md](../palw-rc-launch-blockers-2026-08-21.md).** This section is
> the short form; that document is the authority on current state.
>
> **Status 2026-08-22 (`9d8c7645`): the consensus blockers this section used to warn about are
> CLOSED.** Named, because each once made this runbook unable to produce a working network:
> * *pruned-sync fail-open* — a joining node ran with NO PALW rules; now it imports the
>   root-verified state at the pruning point (`e52a1234`) and refuses to run without one
>   (`0cf7ead2`), and the reply's missing wire route — which killed every pruned IBD — is fixed
>   and drilled over real TCP (`bce0f4e4`).
> * *pruning-point import* — the state transfer itself: message pair, serving flow, all-or-nothing
>   IBD fetch, root verified against the child header before any write.
> * *the unauthenticated lifecycle doors* — `ProducerDefaulted`/`ReceiptLicensed` with empty
>   receipt sets, bond retirement, forged class freezes, courts nobody authorized: all refused at
>   both layers (`40002ddd`, `4724863a`), and class registration now demands its registrant's
>   signature and a servable coverage profile (`cb131570`).
> * *no claim could reach `Final`* — the whole seat/receipt/quorum subsystem now exists
>   (`9d8c7645`): material broadcast, `--palw-panel`, and the funded submitter whose object comes
>   from the acceptance validator itself.
>
> What still stands between this runbook and a public weight-bearing network is OPERATIONAL: the
> multi-node drill (§ below), the genesis re-mint the ruleset-id change forces (settle M-02 first),
> and fleet deployment.
>
> §4's port reads **26411** and matches `NetworkId::default_p2p_port` (`network.rs:280`); an
> earlier revision said 16311, and with `dns_seeders` empty `--addpeer` is the only discovery
> path — the published number has to be the real one.


* **Third-party mining: the facts are on the wire now; no external miner has been written.**
  The blocker this bullet used to name is closed — `getPalwProducerFacts` (op 167, the full grpc
  and wRPC stack) serves the class's artifact root, its target, the pwu that target implies, the
  bond's registered key and operator id, its exposure room and a readiness verdict, all DERIVED
  (ADR-0046) so a miner cannot disagree with admission by multiplying its own. With it the wire
  path is complete: `getCurrentNetwork` → `getPalwProducerFacts` → `getBlockTemplate` → run the
  inference for the bucket's job and check its two hashes (ADR-0072: no nonce search) →
  `submitBlock` with the envelope in `palw_commitment`
  (`network_domain` is `H(network_id)`, derivable from what the node already publishes).
  What remains is not protocol: `misaminer` and `pq-miner` still branch on algo 4 and 5 only, and
  an algo-6 miner has to implement the BASE-0 engine, the carriage build and the retention
  obligation the facts advertise. Until someone writes one, the producing node is the producer —
  by absence of a client, not by absence of an interface.
* **The court's other two legs.** `full_logits_trace_root_v2` hashes f32 rows and
  `PalwActivationTapProfileV1` requires a non-empty f32 tap list; BASE-0 is an integer class and
  taps nothing, so it commits integer roots of its own in those two slots. The arithmetic court —
  the one that adjudicates a tile — is complete and round-tripped. A court that one day adjudicates
  the logits leg has to know which scheme a class uses.
* **Gate 3 (the second class) is not open.** The RC ships one weight-bearing class, the floor.
  Qwen is registered weightless until its calibration justifies activation
  (`palw-qwen-class-static-ptq-and-rc-boot`).
* **The soak clock resets on redeployment.** Every previous rollout learned this the hard way: a
  soak measured in "days since launch" restarts the moment you push a binary. Measure it against
  something the deployment does not touch.

---

## Appendix — the facts a producer reads, and why they are handed over whole

A V2 attempt is refused unless six fields equal values the chain already holds: the class's
registered artifact root, the class target the per-class retarget maintains, the pwu
`palw_pwu_v1` derives from that target, the bond's registered key, the operator id minted at
registration, and — as a bound — the exposure the bond still has room to back.

`palw_producer_facts_v2` reads all six from the state store at virtual's selected parent, using the
same accessors admission uses, and hands them over **derived**. Exposing the ingredients and letting
a producer multiply them would give every producer an independent chance to disagree with
admission — the exact shape of the correspondence defects this codebase has found repeatedly.
Derive, never declare (ADR-0046).

The DAA score in those facts is the **candidate's**, not the tip's: admission's epoch index comes
from the candidate, so a producer handed the tip's would check its budget against the wrong epoch at
every boundary.
