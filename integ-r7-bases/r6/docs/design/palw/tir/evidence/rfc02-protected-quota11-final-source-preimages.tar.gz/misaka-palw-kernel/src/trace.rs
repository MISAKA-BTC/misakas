//! **The producer's trace, the evidence it commits, and the wiring every check authenticates by.**
//!
//! A claim's evidence is the commitment of **every node value of every block occurrence of every
//! position**, fixed before any challenge exists. Nothing else needs committing: every input of a
//! relation is *wired* to something already committed or public ([`SourceV1`]):
//!
//! * a node input → that node's committed value at the same position and occurrence;
//! * a carry-in → the previous occurrence's carry-out node, committed;
//! * a param → the artifact's param commitment; a const → the program's bytes;
//! * a `Fixed` state → the committed `StateWrite` output of the previous position, or zeros at
//!   position 0 (initialization), so continuity is not a separate claim the producer could fabricate;
//! * a `Hist` window's prior rows → the committed appended rows of the earlier positions, in order;
//! * the token and position inputs → the job's public input;
//! * a pipeline stage's input tensor (a TIR v2 program's `Input(2 + k)`, a param of its version-1 view) → the stage's committed
//!   input at that position, whose binding (a job value, an earlier stage's committed output, `R`) is the media-pipeline
//!   family's relation ([`crate::pipeline`]);
//! * a v2 `post` write → the next position's state read, like a `StateWrite`.
//!
//! A verifier therefore never trusts an "entry state" the producer states for a segment: it opens the
//! predecessor's committed exit (RFC-0011 §15.2's boundary row).
//!
//! **Derived values** ([`derived_nodes_v1`]): a `Hist` window (a `HistAppend` output) and the pure views of one (`Transpose`,
//! `Reshape`) are committed like every node, but never served: anyone rebuilds them from the committed appended rows. A window at
//! position `p` is `O(window · row)` bytes, so serving it at every position would make a long-history (held) claim's public
//! material quadratic in its length; derived, it is linear (one row per position), and a wrong commitment of a derived value is
//! convicted from the rows alone ([`crate::verify::FaultKindV1::Misderived`]), never from bytes only the producer holds.

use std::collections::{BTreeMap, BTreeSet};

use misaka_palw_tir::eval::eval_primitive;
use misaka_palw_tir::program::{INPUT_TOKEN, Ref, StateKind, TirProgramV1};
use misaka_palw_tir::validate::ProgramInfo;
use misaka_palw_tir::{DType, ParamSource, Prim, Tensor, TirError, TirResult};

use crate::hash::{Digest, finish, keyed};

pub const EVIDENCE_ROOT_DOMAIN_V1: &[u8] = b"misaka-palw/kernel/evidence/v1";
pub const OUTPUT_ROOT_DOMAIN_V1: &[u8] = b"misaka-palw/kernel/output/v1";
pub const PARAM_ROOT_DOMAIN_V1: &[u8] = b"misaka-palw/kernel/params/v1";
pub const STATE_ROOT_DOMAIN_V1: &[u8] = b"misaka-palw/kernel/state-root/v1";

/// A node value's commitment: the row/column Merkle commitment of [`crate::merkle`] (dtype, shape, row root, column
/// root), so a court can open one row or one column against it as well as the whole tensor.
pub fn tensor_commitment(t: &Tensor) -> Digest {
    crate::merkle::tensor_commitment_v2(t)
}

/// The commitment of every param instance the artifact holds: `(param, layer) → commitment`.
#[derive(Clone, Debug, Default, PartialEq, Eq, borsh::BorshSerialize, borsh::BorshDeserialize)]
pub struct ParamCommitmentsV1 {
    pub by_instance: BTreeMap<(u16, Option<u16>), Digest>,
}

impl ParamCommitmentsV1 {
    pub fn of(params: &misaka_palw_tir::MapParams) -> Self {
        Self { by_instance: params.tensors.iter().map(|(k, t)| (*k, tensor_commitment(t))).collect() }
    }

    /// **K2-TIR-v4**: the tiled (v3) commitment of every param instance ([`crate::merkle3::tensor_commitment_v3`]).
    pub fn of_v3(params: &misaka_palw_tir::MapParams) -> Self {
        Self { by_instance: params.tensors.iter().map(|(k, t)| (*k, crate::merkle3::tensor_commitment_v3(t))).collect() }
    }

    /// The root an artifact binding commits to.
    pub fn root(&self) -> Digest {
        let mut s = keyed(PARAM_ROOT_DOMAIN_V1);
        s.update(&(self.by_instance.len() as u64).to_le_bytes());
        for ((j, l), d) in &self.by_instance {
            s.update(&j.to_le_bytes());
            match l {
                Some(l) => s.update(&[1]).update(&l.to_le_bytes()),
                None => s.update(&[0]),
            };
            s.update(d);
        }
        finish(s)
    }
}

/// A claim's evidence: `commitments[position][occurrence][node]`, and for a pipeline stage `inputs[position][k]` (empty for a
/// single-program claim).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EvidenceV1 {
    pub commitments: Vec<Vec<Vec<Digest>>>,
    pub inputs: Vec<Vec<Digest>>,
}

impl EvidenceV1 {
    pub fn new(commitments: Vec<Vec<Vec<Digest>>>) -> Self {
        Self { commitments, inputs: Vec::new() }
    }

    pub fn root(&self) -> Digest {
        let mut s = keyed(EVIDENCE_ROOT_DOMAIN_V1);
        s.update(&(self.commitments.len() as u64).to_le_bytes());
        for pos in &self.commitments {
            s.update(&(pos.len() as u64).to_le_bytes());
            for occ in pos {
                s.update(&(occ.len() as u64).to_le_bytes());
                for d in occ {
                    s.update(d);
                }
            }
        }
        // A stage's inputs extend the root; a single-program claim's root is unchanged.
        if !self.inputs.is_empty() {
            s.update(b"inputs").update(&(self.inputs.len() as u64).to_le_bytes());
            for pos in &self.inputs {
                s.update(&(pos.len() as u64).to_le_bytes());
                for d in pos {
                    s.update(d);
                }
            }
        }
        finish(s)
    }

    pub fn input_at(&self, p: u32, k: u16) -> Option<&Digest> {
        self.inputs.get(p as usize)?.get(k as usize)
    }

    pub fn at(&self, p: u32, s: u16, n: u16) -> Option<&Digest> {
        self.commitments.get(p as usize)?.get(s as usize)?.get(n as usize)
    }

    /// The output root the claim states: every position's logits commitment, in order.
    pub fn output_root(&self, program: &TirProgramV1) -> Digest {
        let post = program.schedule.layers.len() + 1;
        let mut s = keyed(OUTPUT_ROOT_DOMAIN_V1);
        s.update(&(self.commitments.len() as u64).to_le_bytes());
        for pos in &self.commitments {
            if let Some(d) = pos.get(post).and_then(|o| o.get(program.logits as usize)) {
                s.update(d);
            }
        }
        finish(s)
    }
}

/// Every node value: `values[position][occurrence][node]`; a pipeline stage's input tensors `inputs[position][k]`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TraceV1 {
    pub values: Vec<Vec<Vec<Tensor>>>,
    pub inputs: Vec<Vec<Tensor>>,
}

impl TraceV1 {
    pub fn evidence(&self) -> EvidenceV1 {
        EvidenceV1 {
            commitments: self.values.iter().map(|p| p.iter().map(|o| o.iter().map(tensor_commitment).collect()).collect()).collect(),
            inputs: self.inputs.iter().map(|p| p.iter().map(tensor_commitment).collect()).collect(),
        }
    }

    pub fn input(&self, p: u32, k: u16) -> Option<&Tensor> {
        self.inputs.get(p as usize)?.get(k as usize)
    }

    pub fn value(&self, p: u32, s: u16, n: u16) -> Option<&Tensor> {
        self.values.get(p as usize)?.get(s as usize)?.get(n as usize)
    }
}

/// Where an input's value comes from.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SourceV1 {
    /// A committed node value.
    Node {
        position: u32,
        occurrence: u16,
        node: u16,
    },
    Param {
        index: u16,
        layer: Option<u16>,
    },
    Const(u16),
    /// The all-zeros initial value of a state of this dtype/shape.
    Zeros {
        dtype: DType,
        shape: Vec<usize>,
    },
    /// A public job input (`idx` scalar).
    Public(u32),
    /// A pipeline stage's committed input tensor `k` at a position.
    Input {
        k: u16,
        position: u32,
    },
}

/// What makes a TIR v2 stage's version-1 view a stage: where its input params start, and which `post` nodes are state writes
/// (the view's committed `Clamp`s) that the next position reads.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct StageBindingV1 {
    /// View params at or past this index are the stage's inputs (`k = index − first_input`).
    pub first_input: u16,
    /// `(state, occurrence, node)`: a `post` write of a global `Fixed` state.
    pub post_writers: Vec<(u16, u16, u16)>,
    /// The number of input tensors.
    pub inputs: u16,
}

/// The program's wiring, precomputed once.
pub struct WiringV1<'p> {
    pub program: &'p TirProgramV1,
    pub info: ProgramInfo,
    pub occurrences: Vec<(u8, Option<u16>)>,
    /// `(state, layer) → (occurrence, node)` of its `StateWrite`.
    writers: BTreeMap<(u16, Option<u16>), (u16, u16)>,
    /// `(state, layer) → (occurrence, node)` of its `HistAppend`.
    appenders: BTreeMap<(u16, Option<u16>), (u16, u16)>,
    /// The stage's inputs start here (`u16::MAX`: none).
    first_input: u16,
    /// `(block, node)` of every derived node.
    derived: BTreeSet<(u8, u16)>,
}

fn malformed(msg: impl Into<String>) -> TirError {
    TirError::new(misaka_palw_tir::TirErrorKind::Malformed, msg)
}

impl<'p> WiringV1<'p> {
    pub fn new(program: &'p TirProgramV1) -> TirResult<Self> {
        let info = misaka_palw_tir::validate::validate(program)?;
        let occurrences = program.occurrences();
        let mut writers = BTreeMap::new();
        let mut appenders = BTreeMap::new();
        for (s, (b, layer)) in occurrences.iter().enumerate() {
            for (ni, node) in program.blocks[*b as usize].nodes.iter().enumerate() {
                match node.prim {
                    Prim::StateWrite { state } => {
                        writers.insert((state, *layer), (s as u16, ni as u16));
                    }
                    Prim::HistAppend { state } => {
                        appenders.insert((state, *layer), (s as u16, ni as u16));
                    }
                    _ => {}
                }
            }
        }
        Ok(Self { program, info, occurrences, writers, appenders, first_input: u16::MAX, derived: derived_nodes_v1(program) })
    }

    /// The wiring of a pipeline stage's version-1 view: its input params resolve to the stage's committed inputs, and its `post`
    /// writes feed the next position's state reads.
    pub fn for_stage(program: &'p TirProgramV1, stage: Option<&StageBindingV1>) -> TirResult<Self> {
        let mut w = Self::new(program)?;
        if let Some(st) = stage {
            w.first_input = st.first_input;
            for (state, occ, node) in &st.post_writers {
                if w.writers.insert((*state, None), (*occ, *node)).is_some() {
                    return Err(malformed("a state written twice"));
                }
            }
        }
        Ok(w)
    }

    /// Is node `n` of occurrence `s` derived (rebuilt from committed rows, never served)?
    pub fn is_derived(&self, s: u16, n: u16) -> bool {
        self.occurrences.get(s as usize).is_some_and(|(b, _)| self.derived.contains(&(*b, n)))
    }

    /// `H` at a position for an occurrence's block.
    pub fn h(&self, occurrence: u16, position: u32) -> usize {
        let b = self.occurrences[occurrence as usize].0 as usize;
        self.info.blocks[b].window.map(|w| (position as usize + 1).min(w as usize)).unwrap_or(1)
    }

    pub fn node(&self, occurrence: u16, node: u16) -> &misaka_palw_tir::program::Node {
        &self.program.blocks[self.occurrences[occurrence as usize].0 as usize].nodes[node as usize]
    }

    /// The source of input `idx` of node `(p, s, n)`.
    pub fn input_source(&self, tokens: &[u32], p: u32, s: u16, n: u16, idx: usize) -> TirResult<SourceV1> {
        let layer = self.occurrences[s as usize].1;
        let node = self.node(s, n);
        let r = node.inputs.get(idx).ok_or_else(|| malformed("no such input"))?;
        Ok(match *r {
            Ref::Node(j) => SourceV1::Node { position: p, occurrence: s, node: j },
            Ref::CarryIn(k) => {
                if s == 0 {
                    return Err(malformed("a carry-in in the first occurrence"));
                }
                let prev = self.occurrences[s as usize - 1].0 as usize;
                let out = *self.program.blocks[prev].carry_out.get(k as usize).ok_or_else(|| malformed("no such carry-out"))?;
                SourceV1::Node { position: p, occurrence: s - 1, node: out }
            }
            Ref::Param(j) if j >= self.first_input => SourceV1::Input { k: j - self.first_input, position: p },
            Ref::Param(j) => {
                let per_layer = self.program.params[j as usize].per_layer;
                SourceV1::Param { index: j, layer: if per_layer { layer } else { None } }
            }
            Ref::Const(j) => SourceV1::Const(j),
            Ref::State(j) => match (p, self.writers.get(&(j, layer))) {
                (p, Some((ws, wn))) if p > 0 => SourceV1::Node { position: p - 1, occurrence: *ws, node: *wn },
                _ => {
                    let st = &self.program.states[j as usize];
                    SourceV1::Zeros { dtype: st.dtype, shape: st.shape.iter().map(|d| *d as usize).collect() }
                }
            },
            Ref::Input(j) => {
                let v = if j == INPUT_TOKEN {
                    let t = *tokens.get(p as usize).ok_or_else(|| malformed("no token for the position"))?;
                    if t >= self.program.token_bound {
                        return Err(malformed(format!("token {t} ≥ token_bound {}", self.program.token_bound)));
                    }
                    t
                } else {
                    p
                };
                SourceV1::Public(v)
            }
        })
    }

    /// The prior rows a `HistAppend` at `(p, s, n)` reads: the appended rows of the previous
    /// `min(p, window − 1)` positions, oldest first.
    pub fn hist_prior_sources(&self, tokens: &[u32], p: u32, s: u16, n: u16) -> TirResult<Vec<SourceV1>> {
        let Prim::HistAppend { state } = self.node(s, n).prim else { return Ok(Vec::new()) };
        let StateKind::Hist { window } = self.program.states[state as usize].kind else {
            return Err(malformed("HistAppend on a Fixed state"));
        };
        let layer = self.occurrences[s as usize].1;
        let (as_, an) = *self.appenders.get(&(state, layer)).ok_or_else(|| malformed("no appender"))?;
        let rows = (p as usize).min(window as usize - 1) as u32;
        (p - rows..p).map(|q| self.input_source(tokens, q, as_, an, 0)).collect()
    }
}

impl WiringV1<'_> {
    /// The commitment a source names: a committed node's from `evidence`, a public value's recomputed. `None` for a param or const
    /// (artifact and program material, which no state boundary reads).
    pub fn source_commitment(&self, evidence: &EvidenceV1, src: &SourceV1) -> Option<Digest> {
        match src {
            SourceV1::Node { position, occurrence, node } => evidence.at(*position, *occurrence, *node).copied(),
            SourceV1::Zeros { dtype, shape } => Some(tensor_commitment(&Tensor::zeros(*dtype, shape))),
            SourceV1::Public(v) => Tensor::scalar(DType::Idx, *v as i128).ok().map(|t| tensor_commitment(&t)),
            SourceV1::Input { k, position } => evidence.input_at(*position, *k).copied(),
            SourceV1::Param { .. } | SourceV1::Const(_) => None,
        }
    }

    /// **The state root entering position `p`** (RFC-0011 §15.2's boundary row): every written `Fixed` state instance's value (the
    /// previous position's committed write, or zeros at 0) and every `Hist` instance's prior rows (the earlier positions' committed
    /// appended rows), in `(state, layer)` order. Derived from the committed trace — a segment's entry state is never a separate claim.
    pub fn state_root_entering(&self, evidence: &EvidenceV1, tokens: &[u32], p: u32) -> TirResult<Digest> {
        let mut s = keyed(STATE_ROOT_DOMAIN_V1);
        s.update(&p.to_le_bytes());
        for ((state, layer), (ws, wn)) in &self.writers {
            s.update(&[0]).update(&state.to_le_bytes()).update(&layer.map(|l| l as u32 + 1).unwrap_or(0).to_le_bytes());
            let src = if p == 0 {
                let st = &self.program.states[*state as usize];
                SourceV1::Zeros { dtype: st.dtype, shape: st.shape.iter().map(|d| *d as usize).collect() }
            } else {
                SourceV1::Node { position: p - 1, occurrence: *ws, node: *wn }
            };
            s.update(&self.source_commitment(evidence, &src).ok_or_else(|| malformed("a state write outside the evidence"))?);
        }
        for ((state, layer), (as_, an)) in &self.appenders {
            s.update(&[1]).update(&state.to_le_bytes()).update(&layer.map(|l| l as u32 + 1).unwrap_or(0).to_le_bytes());
            // The prior rows the appender at `p` would read are exactly the history entering `p`.
            let rows = self.hist_prior_sources(tokens, p, *as_, *an)?;
            s.update(&(rows.len() as u32).to_le_bytes());
            for r in &rows {
                s.update(&self.source_commitment(evidence, r).ok_or_else(|| malformed("a history row outside the evidence"))?);
            }
        }
        Ok(finish(s))
    }
}

/// **The derived nodes of a program**, as `(block, node)`: every `HistAppend`, and every `Transpose` / `Reshape` whose input is a
/// derived node of the same block (in node order, so a view of a view is derived too).
pub fn derived_nodes_v1(program: &TirProgramV1) -> BTreeSet<(u8, u16)> {
    let mut out = BTreeSet::new();
    for (b, block) in program.blocks.iter().enumerate() {
        for (n, node) in block.nodes.iter().enumerate() {
            let derived = match node.prim {
                Prim::HistAppend { .. } => true,
                Prim::Transpose { .. } | Prim::Reshape => {
                    matches!(node.inputs.first(), Some(Ref::Node(j)) if out.contains(&(b as u8, *j)))
                }
                _ => false,
            };
            if derived {
                out.insert((b as u8, n as u16));
            }
        }
    }
    out
}

/// [`derived_nodes_v1`] per occurrence: `mask[occurrence][node]`.
pub fn derived_mask_v1(program: &TirProgramV1) -> Vec<Vec<bool>> {
    let d = derived_nodes_v1(program);
    program
        .occurrences()
        .iter()
        .map(|(b, _)| (0..program.blocks[*b as usize].nodes.len()).map(|n| d.contains(&(*b, n as u16))).collect())
        .collect()
}

/// Resolve a source from the producer's own values (the tracer) — the verifier resolves the same
/// sources from openings instead.
pub(crate) fn const_tensor(program: &TirProgramV1, j: u16) -> TirResult<Tensor> {
    let c = &program.consts[j as usize];
    Tensor::from_le_bytes(c.dtype, &c.shape.iter().map(|d| *d as usize).collect::<Vec<_>>(), &c.data)
}

/// Trace construction has the same typed-operand requirement as Interpreter.
/// Check metadata before walking a provider's values or evaluating a node;
/// accepting a larger tensor would change TopK/Gather/state semantics while
/// retaining the admitted program's smaller declared resource envelope.
fn typed_parameter_tensor(program: &TirProgramV1, index: u16, tensor: Tensor) -> TirResult<Tensor> {
    let d = program.params.get(index as usize).ok_or_else(|| malformed("no declared parameter"))?;
    let shape: Vec<_> = d.shape.iter().map(|n| *n as usize).collect();
    let len = shape.iter().try_fold(1usize, |n, d| n.checked_mul(*d));
    if tensor.dtype != d.dtype || tensor.shape != shape || len != Some(tensor.data.len()) {
        return Err(TirError::new(
            misaka_palw_tir::TirErrorKind::Operand,
            format!("param {index}: tensor metadata differs from declaration"),
        ));
    }
    if tensor.data.iter().any(|v| !d.dtype.contains(*v)) {
        return Err(TirError::new(misaka_palw_tir::TirErrorKind::Operand, format!("param {index}: value outside declared dtype")));
    }
    Ok(tensor)
}

fn parameter_tensor(program: &TirProgramV1, params: &dyn ParamSource, index: u16, layer: Option<u16>) -> TirResult<Tensor> {
    let d = program.params.get(index as usize).ok_or_else(|| malformed("no declared parameter"))?;
    if (d.per_layer && layer.is_none_or(|l| l as usize >= program.schedule.layers.len())) || (!d.per_layer && layer.is_some()) {
        return Err(malformed("parameter instance differs from declared layer namespace"));
    }
    let tensor =
        params.param(index, layer).ok_or_else(|| TirError::new(misaka_palw_tir::TirErrorKind::Missing, format!("param {index}")))?;
    typed_parameter_tensor(program, index, tensor)
}

/// **One node, from its inputs** — the exact semantics every check and court shares.
pub fn eval_node(
    program: &TirProgramV1,
    node: &misaka_palw_tir::program::Node,
    inputs: &[Tensor],
    prior_rows: &[Tensor],
    h: usize,
) -> TirResult<Tensor> {
    let out_shape = node.out.resolve(h);
    match node.prim {
        Prim::StateWrite { state } => {
            let StateKind::Fixed { lo, hi } = program.states[state as usize].kind else {
                return Err(malformed("StateWrite on a Hist state"));
            };
            let x = inputs.first().ok_or_else(|| malformed("StateWrite without its input"))?;
            Tensor::new(node.out.dtype, out_shape, x.data.iter().map(|v| (*v).clamp(lo as i128, hi as i128)).collect())
        }
        Prim::HistAppend { state } => {
            let s = &program.states[state as usize];
            let row = inputs.first().ok_or_else(|| malformed("HistAppend without its row"))?;
            let mut data = Vec::with_capacity((prior_rows.len() + 1) * row.len());
            for r in prior_rows.iter().chain(std::iter::once(row)) {
                if r.dtype != s.dtype || r.shape != s.shape.iter().map(|d| *d as usize).collect::<Vec<_>>() {
                    return Err(malformed("a history row of another type"));
                }
                data.extend_from_slice(&r.data);
            }
            Tensor::new(s.dtype, out_shape, data)
        }
        _ => eval_primitive(&node.prim, inputs, node.out.dtype, &out_shape),
    }
}

/// **An honest producer's trace**: every node value, position by position.
pub fn trace_v1(program: &TirProgramV1, params: &dyn ParamSource, tokens: &[u32]) -> TirResult<TraceV1> {
    trace_stage_v1(program, None, params, tokens, &|_, _| None)
}

/// **An honest producer's trace, streamed** (lane K2S, GAP-31): exactly [`trace_v1`]'s values, handed to `visit` one position at a
/// time and then dropped. Only the previous position is held: every value a position reads is at that position or the one before
/// (a `Fixed` state, a `Hist` window and its views), so a producer commits a long claim — every committed value of every position,
/// derived windows included — without holding the claim (`docs/design/palw/k2-real-scale.md` §1.3). A source older than the previous
/// position is refused, by name.
pub fn trace_streaming_v1(
    program: &TirProgramV1,
    params: &dyn ParamSource,
    tokens: &[u32],
    visit: &mut dyn FnMut(u32, &[Vec<Tensor>]) -> TirResult<()>,
) -> TirResult<()> {
    let w = WiringV1::new(program)?;
    let mut prev: Vec<Vec<Tensor>> = Vec::new();
    // Each window's appended rows, newest last: a `HistAppend` reads the rows its appender appended at the previous
    // `min(p, window − 1)` positions (`WiringV1::hist_prior_sources`), so those rows — not the positions — are what is kept.
    let mut appended: BTreeMap<(u16, u16), std::collections::VecDeque<Tensor>> = BTreeMap::new();
    for p in 0..tokens.len() as u32 {
        let mut pos_vals: Vec<Vec<Tensor>> = Vec::with_capacity(w.occurrences.len());
        for s in 0..w.occurrences.len() as u16 {
            let b = w.occurrences[s as usize].0 as usize;
            let mut occ_vals: Vec<Tensor> = Vec::with_capacity(program.blocks[b].nodes.len());
            for n in 0..program.blocks[b].nodes.len() as u16 {
                let resolve = |src: SourceV1, occ_vals: &Vec<Tensor>, pos_vals: &Vec<Vec<Tensor>>| -> TirResult<Tensor> {
                    match src {
                        SourceV1::Node { position, occurrence, node } if position == p && occurrence == s => {
                            occ_vals.get(node as usize).cloned().ok_or_else(|| malformed("a forward node reference"))
                        }
                        SourceV1::Node { position, occurrence, node } if position == p => {
                            Ok(pos_vals[occurrence as usize][node as usize].clone())
                        }
                        SourceV1::Node { position, occurrence, node } if position + 1 == p => prev
                            .get(occurrence as usize)
                            .and_then(|o| o.get(node as usize))
                            .cloned()
                            .ok_or_else(|| malformed("a previous-position reference")),
                        SourceV1::Node { .. } => {
                            Err(malformed("a source older than the previous position (a streamed trace holds one)"))
                        }
                        SourceV1::Param { index, layer } => parameter_tensor(program, params, index, layer),
                        SourceV1::Const(j) => const_tensor(program, j),
                        SourceV1::Zeros { dtype, shape } => Ok(Tensor::zeros(dtype, &shape)),
                        SourceV1::Public(v) => Tensor::scalar(DType::Idx, v as i128),
                        SourceV1::Input { k, .. } => Err(TirError::new(
                            misaka_palw_tir::TirErrorKind::Missing,
                            format!("input {k} (a streamed trace has no stage inputs)"),
                        )),
                    }
                };
                let node = w.node(s, n);
                let inputs = (0..node.inputs.len())
                    .map(|i| resolve(w.input_source(tokens, p, s, n, i)?, &occ_vals, &pos_vals))
                    .collect::<TirResult<Vec<_>>>()?;
                let window = match node.prim {
                    Prim::HistAppend { state } => {
                        let StateKind::Hist { window } = program.states[state as usize].kind else {
                            return Err(malformed("HistAppend on a Fixed state"));
                        };
                        if w.appenders.get(&(state, w.occurrences[s as usize].1)) != Some(&(s, n)) {
                            return Err(malformed("a window appended by another node (a streamed trace keeps its own rows)"));
                        }
                        Some(window as usize)
                    }
                    _ => None,
                };
                let prior: Vec<Tensor> = match window {
                    Some(window) => {
                        let rows = appended.entry((s, n)).or_default();
                        let keep = (p as usize).min(window - 1);
                        if rows.len() < keep {
                            return Err(malformed("a window's rows were not appended"));
                        }
                        rows.iter().skip(rows.len() - keep).cloned().collect()
                    }
                    None => Vec::new(),
                };
                let value = eval_node(program, node, &inputs, &prior, w.h(s, p))?;
                if let Some(window) = window {
                    let rows = appended.entry((s, n)).or_default();
                    rows.push_back(inputs.first().cloned().ok_or_else(|| malformed("HistAppend without its row"))?);
                    while rows.len() > window.saturating_sub(1) {
                        rows.pop_front();
                    }
                }
                occ_vals.push(value);
            }
            pos_vals.push(occ_vals);
        }
        visit(p, &pos_vals)?;
        prev = pos_vals;
    }
    Ok(())
}

/// A pipeline stage's trace: `inputs(k, position)` is input `k`'s value at the position (recorded in the trace).
pub fn trace_stage_v1(
    program: &TirProgramV1,
    stage: Option<&StageBindingV1>,
    params: &dyn ParamSource,
    tokens: &[u32],
    inputs: &dyn Fn(u16, u32) -> Option<Tensor>,
) -> TirResult<TraceV1> {
    let w = WiringV1::for_stage(program, stage)?;
    let n_inputs = stage.map(|s| s.inputs).unwrap_or(0);
    let mut stage_inputs: Vec<Vec<Tensor>> = Vec::with_capacity(if n_inputs > 0 { tokens.len() } else { 0 });
    for p in 0..tokens.len() as u32 {
        if n_inputs > 0 {
            stage_inputs.push(
                (0..n_inputs)
                    .map(|k| {
                        let index = w.first_input.checked_add(k).ok_or_else(|| malformed("stage input parameter overflow"))?;
                        let tensor =
                            inputs(k, p).ok_or_else(|| TirError::new(misaka_palw_tir::TirErrorKind::Missing, format!("input {k}")))?;
                        typed_parameter_tensor(program, index, tensor)
                    })
                    .collect::<TirResult<_>>()?,
            );
        }
    }
    let mut values: Vec<Vec<Vec<Tensor>>> = Vec::with_capacity(tokens.len());
    for p in 0..tokens.len() as u32 {
        let mut pos_vals: Vec<Vec<Tensor>> = Vec::with_capacity(w.occurrences.len());
        for s in 0..w.occurrences.len() as u16 {
            let b = w.occurrences[s as usize].0 as usize;
            let mut occ_vals: Vec<Tensor> = Vec::with_capacity(program.blocks[b].nodes.len());
            for n in 0..program.blocks[b].nodes.len() as u16 {
                let resolve = |src: SourceV1, occ_vals: &Vec<Tensor>, pos_vals: &Vec<Vec<Tensor>>| -> TirResult<Tensor> {
                    match src {
                        SourceV1::Node { position, occurrence, node } if position == p && occurrence == s => {
                            occ_vals.get(node as usize).cloned().ok_or_else(|| malformed("a forward node reference"))
                        }
                        SourceV1::Node { position, occurrence, node } if position == p => {
                            Ok(pos_vals[occurrence as usize][node as usize].clone())
                        }
                        SourceV1::Node { position, occurrence, node } => {
                            Ok(values[position as usize][occurrence as usize][node as usize].clone())
                        }
                        SourceV1::Param { index, layer } => parameter_tensor(program, params, index, layer),
                        SourceV1::Const(j) => const_tensor(program, j),
                        SourceV1::Zeros { dtype, shape } => Ok(Tensor::zeros(dtype, &shape)),
                        SourceV1::Public(v) => Tensor::scalar(DType::Idx, v as i128),
                        SourceV1::Input { k, position } => stage_inputs
                            .get(position as usize)
                            .and_then(|r| r.get(k as usize))
                            .cloned()
                            .ok_or_else(|| TirError::new(misaka_palw_tir::TirErrorKind::Missing, format!("input {k}"))),
                    }
                };
                let node = w.node(s, n);
                let inputs = (0..node.inputs.len())
                    .map(|i| resolve(w.input_source(tokens, p, s, n, i)?, &occ_vals, &pos_vals))
                    .collect::<TirResult<Vec<_>>>()?;
                let prior = w
                    .hist_prior_sources(tokens, p, s, n)?
                    .into_iter()
                    .map(|src| resolve(src, &occ_vals, &pos_vals))
                    .collect::<TirResult<Vec<_>>>()?;
                occ_vals.push(eval_node(program, node, &inputs, &prior, w.h(s, p))?);
            }
            pos_vals.push(occ_vals);
        }
        values.push(pos_vals);
    }
    Ok(TraceV1 { values, inputs: stage_inputs })
}
