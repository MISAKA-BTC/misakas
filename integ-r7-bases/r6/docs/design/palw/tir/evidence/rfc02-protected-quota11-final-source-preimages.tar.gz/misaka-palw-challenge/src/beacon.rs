//! **`PalwWorkBeaconV1`** (RFC-0007 §§VI.3–VI.4): `k` distinct future qualifying useful works, in canonical order, mixed into
//! one accumulator — derived by every node from its own canonical PALW history, never issued or locked by a committee.
//!
//! * **Eligibility** ([`eligibility_v1`]): REAL useful work only — heartbeat, BASE-0 fallback, EXEC_TX, EXEC work slices,
//!   receipt-only material, provisional attempts and bare Panel receipts are refused by kind. The source profile must be in the
//!   set frozen from the subject's commitment state as Active **and** G14-complete (the consumer derives both from
//!   authenticated state and the code-derived gate; never a registrant flag), must not be the candidate under test or depend on
//!   its semantics, and the work must be Final, DA-satisfied and valid independently of the challenge consuming it.
//! * **Freshness**: the work's commitment is accepted at or after `S = commitment position + anchor delay`; reaching Final
//!   after `S` is not enough. Its settlement falls in `[S, S + window)`.
//! * **Order**: `(settlement_position, occurrence_index, canonical_work_id)`; the first occurrence of a work identity counts,
//!   re-inclusions/reattachments never enlarge the set. Arrival order, RPC order and producer-selected lists are irrelevant:
//!   [`collect_work_beacon_v1`] sorts what it is given.
//! * **Lock**: `k` sources and the `k`-th settled at depth `D` on this branch — a branch-relative state, not finality and not a
//!   reorg veto. A reorg is a recomputation over the new branch's events; dependents of a lost lock roll back with it.
//! * **Unavailable**: the window closed with fewer than `k`. That is `BEACON_UNAVAILABLE` — never fraud, never a pass, and
//!   never a fallback to heartbeat/BASE-0/EXEC/block hashes, signatures or local randomness.
//!
//! Mixing more works is not, by itself, a proof of unbiased randomness: an adaptive last contributor, withholding, reordering
//! and reorgs can bias a simple accumulator. Bounding that bias is an external review gate (RFC-0007 §VI.8 item 2).

use std::collections::BTreeSet;

use borsh::{BorshDeserialize, BorshSerialize};

use crate::hash::{DOMAIN_CHALLENGE_ANCHOR, DOMAIN_WORK_BEACON, DOMAIN_WORK_BEACON_ITEM, DOMAIN_WORK_BEACON_MIX, Digest, object_id};
use crate::policy::{PolicyRefusalV1, PostCommitChallengePolicyV1, SourceRuleV1};
use crate::subject::{RootV1, SubjectKindV1};

/// What a Final event on the chain is. Only `RealUsefulWork` can be a source.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, BorshSerialize, BorshDeserialize)]
#[borsh(use_discriminant = true)]
#[repr(u8)]
pub enum WorkSourceKindV1 {
    RealUsefulWork = 0,
    Heartbeat = 1,
    Base0Fallback = 2,
    ExecTx = 3,
    ExecWorkSlice = 4,
    ReceiptOnly = 5,
    ProvisionalAttempt = 6,
    PanelReceipt = 7,
}

/// One settlement event of the canonical history, with the facts the consumer derived for it from authenticated state.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord, BorshSerialize, BorshDeserialize)]
pub struct WorkFinalEventV1 {
    pub kind: WorkSourceKindV1,
    pub source_profile_id: Digest,
    /// Stable under header/carrier reattachment (never a block hash, signature or rewrappable claim id).
    pub canonical_work_id: Digest,
    pub execution_commitment: Digest,
    /// The EARLIEST chain position at which this canonical work identity's commitment was accepted on this branch, through any
    /// carrier: a work committed before `S` and reattached later is still not fresh.
    pub accepted_position: u64,
    /// The chain position of its claim Final / PALW-native settlement.
    pub settlement_position: u64,
    pub occurrence_index: u32,
    pub claim_final: bool,
    pub da_satisfied: bool,
    /// Its validity does not depend on any challenge consuming this beacon.
    pub validity_independent: bool,
    /// Profiles whose semantics this work depends on (pipeline stages, adapters): a candidate here makes it ineligible.
    pub depends_on_profiles: Vec<Digest>,
    /// How the work reached Final: through a Panel licence (and which Panel draw), or with no Panel in its path.
    pub final_path: FinalPathV1,
}

/// **Who stands behind a source work** — facts the consumer derives from authenticated state (never a field the producer writes
/// into its own claim): the producer (the bond that committed and stands liable for the work) and the consumer (whoever posted and
/// paid for the job), `Absent` where the consumer's state does not record one. The distinct source rules
/// ([`crate::policy::SourceRuleV1`]) read them so one party cannot fill every source position with its own bonds or its own jobs.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, BorshSerialize, BorshDeserialize)]
pub struct SourceAttributionV1 {
    pub producer_id: Digest,
    pub consumer_id: RootV1,
}

/// A Final event with its attribution — what the attributed collector reads, and what a node serves for each Final it can state.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord, BorshSerialize, BorshDeserialize)]
pub struct AttributedWorkV1 {
    pub event: WorkFinalEventV1,
    pub attribution: SourceAttributionV1,
}

/// **How a source work reached Final** — the fact that decides whether it may seed a Panel draw.
///
/// A Panel-licensed Final is a function of a Panel assignment (its seats can include, delay or void the work), so feeding it into
/// the entropy of a Panel assignment closes the loop `work validity → Panel assignment → Final → beacon → Panel assignment`.
/// [`SubjectKindV1::PanelAssignment`] therefore accepts only [`FinalPathV1::PanelIndependent`] sources; until a Panel-independent
/// Final exists (RFC-0014 public window lapse / RFC-0015), a Panel-assignment beacon stays `BEACON_UNAVAILABLE` and RFC-0010 stays
/// dormant. Other subjects may use Panel-licensed sources; the veto/delay bias a captured Panel has over them is part of the
/// reviewed bias budget (RFC-0007 §VI.8 item 2), not a property this code proves.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, BorshSerialize, BorshDeserialize)]
pub enum FinalPathV1 {
    /// Licensed by a Panel quorum or by parts; the licensing Panel was drawn from `panel_seed_id` at `panel_epoch`.
    PanelLicensed { panel_seed_id: Digest, panel_epoch: u64 },
    /// Final with no Panel licence anywhere in its path.
    PanelIndependent,
}

/// The subject side of a beacon: fixed when the subject's commitment is accepted.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct BeaconContextV1 {
    pub chain_genesis: Digest,
    pub ruleset_id: Digest,
    pub policy: PostCommitChallengePolicyV1,
    pub subject_kind: SubjectKindV1,
    pub commitment_root: Digest,
    /// The accepted chain position of the subject's commitment.
    pub commitment_position: u64,
    pub challenge_epoch: u64,
    /// Source profiles that were Active AND G14-complete in the subject's commitment state (frozen then).
    pub eligible_profiles: BTreeSet<Digest>,
    /// The candidate under test and every profile depending on its proposed semantics.
    pub excluded_profiles: BTreeSet<Digest>,
    /// The candidate under test itself, refused as a source by construction (whatever `excluded_profiles` says). Required
    /// (`Present`) for model and kernel conformance.
    pub candidate_profile_id: RootV1,
}

impl BeaconContextV1 {
    /// The context's identity: a verified beacon carries it, so a seed is never minted from a beacon of another context.
    pub fn id(&self) -> Digest {
        object_id(crate::hash::DOMAIN_BEACON_CONTEXT, self)
    }

    /// `S`: the first position a source's commitment may be accepted at.
    pub fn start(&self) -> u64 {
        self.commitment_position.saturating_add(self.policy.anchor_delay_slots)
    }

    /// The end (exclusive) of the settlement window.
    pub fn window_end(&self) -> u64 {
        self.start().saturating_add(self.policy.beacon_window_slots)
    }
}

/// Why an event is not a source.
#[derive(Clone, Copy, Debug, PartialEq, Eq, thiserror::Error)]
pub enum IneligibleV1 {
    #[error("not REAL useful work ({0:?})")]
    NotUsefulWork(WorkSourceKindV1),
    #[error("the source profile was not Active and G14-complete at the subject's commitment")]
    ProfileNotEligible,
    #[error("the candidate under test, or work depending on its semantics (no self-beacon)")]
    SelfOrDependent,
    #[error("the work's commitment was accepted before the start S (not fresh)")]
    NotFresh,
    #[error("settled outside the beacon window")]
    OutsideWindow,
    #[error("not Final")]
    NotFinal,
    #[error("its public DA obligation is not satisfied")]
    DaUnsatisfied,
    #[error("its validity depends on the challenge consuming it")]
    NotIndependent,
    #[error("a Panel-licensed Final cannot seed a Panel assignment (circular: Panel → Final → beacon → Panel)")]
    PanelDependentFinal,
}

pub fn eligibility_v1(ctx: &BeaconContextV1, ev: &WorkFinalEventV1) -> Result<(), IneligibleV1> {
    use IneligibleV1 as I;
    if ev.kind != WorkSourceKindV1::RealUsefulWork {
        return Err(I::NotUsefulWork(ev.kind));
    }
    let is_candidate = |p: &Digest| ctx.candidate_profile_id == RootV1::Present(*p);
    if ctx.excluded_profiles.contains(&ev.source_profile_id)
        || is_candidate(&ev.source_profile_id)
        || ev.depends_on_profiles.iter().any(|p| ctx.excluded_profiles.contains(p) || is_candidate(p))
    {
        return Err(I::SelfOrDependent);
    }
    if !ctx.eligible_profiles.contains(&ev.source_profile_id) {
        return Err(I::ProfileNotEligible);
    }
    if ev.accepted_position < ctx.start() {
        return Err(I::NotFresh);
    }
    if ev.settlement_position < ctx.start() || ev.settlement_position >= ctx.window_end() {
        return Err(I::OutsideWindow);
    }
    if !ev.claim_final {
        return Err(I::NotFinal);
    }
    if !ev.da_satisfied {
        return Err(I::DaUnsatisfied);
    }
    if !ev.validity_independent {
        return Err(I::NotIndependent);
    }
    if ctx.subject_kind == SubjectKindV1::PanelAssignment && ev.final_path != FinalPathV1::PanelIndependent {
        return Err(I::PanelDependentFinal);
    }
    Ok(())
}

/// One mixed source, as the public evidence records it.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct BeaconSourceV1 {
    pub source_profile_id: Digest,
    pub canonical_work_id: Digest,
    pub execution_commitment: Digest,
    pub accepted_position: u64,
    pub settlement_position: u64,
    pub occurrence_index: u32,
}

/// A locked beacon: its sources in canonical order, every accumulator and the output.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct WorkBeaconV1 {
    pub sources: Vec<BeaconSourceV1>,
    /// `acc_0 … acc_k`.
    pub accumulators: Vec<Digest>,
    pub output: Digest,
    /// The normalized window/epoch and ordered work identities (not a block hash).
    pub challenge_anchor: Digest,
    /// The position from which it is locked on this branch (`k`-th settlement + D).
    pub lock_position: u64,
}

/// **A beacon this node derived itself** for one context (from [`collect_work_beacon_v1`] or [`verify_work_beacon_v1`]). It cannot
/// be decoded from bytes or assembled by a caller, so a seed ([`crate::seed::challenge_seed_v1`]) is never minted from a presented,
/// stale or invented beacon, and it names the context it was collected for.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct VerifiedWorkBeaconV1 {
    beacon: WorkBeaconV1,
    context_id: Digest,
}

impl VerifiedWorkBeaconV1 {
    /// A beacon a collector of this crate derived for the context `context_id` (never from presented bytes).
    pub(crate) fn derived(beacon: WorkBeaconV1, context_id: Digest) -> Self {
        Self { beacon, context_id }
    }

    pub fn beacon(&self) -> &WorkBeaconV1 {
        &self.beacon
    }

    pub fn context_id(&self) -> Digest {
        self.context_id
    }
}

impl std::ops::Deref for VerifiedWorkBeaconV1 {
    type Target = WorkBeaconV1;

    fn deref(&self) -> &WorkBeaconV1 {
        &self.beacon
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum WorkBeaconStateV1 {
    /// The window is open and fewer than `k` sources settled.
    Collecting {
        have: u32,
        need: u32,
    },
    /// `k` sources, the `k`-th not yet at depth `D`.
    Candidate {
        have: u32,
        lock_position: u64,
    },
    Locked(VerifiedWorkBeaconV1),
    /// `BEACON_UNAVAILABLE`: the window closed with fewer than `k`. Not fraud, not a pass.
    Unavailable {
        have: u32,
        need: u32,
    },
}

fn item_v1(s: &BeaconSourceV1) -> Digest {
    object_id(DOMAIN_WORK_BEACON_ITEM, &(s.source_profile_id, s.canonical_work_id, s.execution_commitment))
}

/// `acc_0`.
pub fn initial_accumulator_v1(ctx: &BeaconContextV1) -> Digest {
    object_id(DOMAIN_WORK_BEACON, &(ctx.chain_genesis, ctx.ruleset_id, ctx.policy.id(), ctx.commitment_root, ctx.challenge_epoch))
}

/// `acc_i` from `acc_(i-1)`, the 1-based index `i` and source `i`.
pub fn mix_v1(prev: &Digest, i: u32, source: &BeaconSourceV1) -> Digest {
    object_id(DOMAIN_WORK_BEACON_MIX, &(*prev, i, item_v1(source)))
}

/// **The lock evidence root**: what the RFC-0013 §9 evidence binds about the lock predicate — the lock position, every
/// accumulator and the ordered sources (a fresh node recomputes it from its own locked beacon).
pub fn lock_evidence_root_v1(beacon: &WorkBeaconV1) -> Digest {
    object_id(crate::hash::DOMAIN_LOCK_EVIDENCE, &(beacon.lock_position, &beacon.accumulators, &beacon.sources))
}

/// The challenge anchor: policy, epoch, window and the ordered work identities.
pub fn challenge_anchor_v1(ctx: &BeaconContextV1, sources: &[BeaconSourceV1]) -> Digest {
    let ids: Vec<Digest> = sources.iter().map(|s| s.canonical_work_id).collect();
    object_id(DOMAIN_CHALLENGE_ANCHOR, &(ctx.policy.id(), ctx.challenge_epoch, ctx.start(), ctx.policy.beacon_window_slots, ids))
}

/// The canonical, eligible, de-duplicated source list from `events` (any order), under the policy's plain rule.
pub fn canonical_sources_v1(ctx: &BeaconContextV1, events: &[WorkFinalEventV1]) -> Vec<BeaconSourceV1> {
    let works: Vec<AttributedWorkV1> = events.iter().map(unattributed).collect();
    canonical_attributed_sources_v1(ctx, &works, SourceRuleV1::Plain)
}

/// A work whose attribution is unknown (the plain rule never reads it).
fn unattributed(ev: &WorkFinalEventV1) -> AttributedWorkV1 {
    AttributedWorkV1 { event: ev.clone(), attribution: SourceAttributionV1 { producer_id: [0u8; 64], consumer_id: RootV1::Absent } }
}

/// **The canonical source list under `rule`**: sorted by `(settlement_position, occurrence_index, canonical_work_id)` (then the
/// whole record, so ties never fall to arrival order); a work identity counts once, at its first canonical occurrence, eligible or
/// not; an eligible work is then taken only if the rule allows it beside the works already taken (distinct producers; distinct
/// consumers where both are known; the per-profile cap). A work the rule passes over is simply not a source — a later work may take
/// the place — so the list is a prefix-stable function of the branch's events.
pub fn canonical_attributed_sources_v1(ctx: &BeaconContextV1, works: &[AttributedWorkV1], rule: SourceRuleV1) -> Vec<BeaconSourceV1> {
    let mut sorted: Vec<&AttributedWorkV1> = works.iter().collect();
    sorted.sort_by(|a, b| {
        let (x, y) = (&a.event, &b.event);
        (x.settlement_position, x.occurrence_index, x.canonical_work_id)
            .cmp(&(y.settlement_position, y.occurrence_index, y.canonical_work_id))
            .then_with(|| a.cmp(b))
    });
    let cap = rule.per_profile_cap(ctx.policy.work_count_k) as usize;
    let mut seen = BTreeSet::new();
    let (mut producers, mut consumers) = (BTreeSet::new(), BTreeSet::new());
    let mut per_profile: std::collections::BTreeMap<Digest, usize> = std::collections::BTreeMap::new();
    let mut out = Vec::new();
    for w in sorted {
        let ev = &w.event;
        if !seen.insert(ev.canonical_work_id) {
            continue;
        }
        if eligibility_v1(ctx, ev).is_err() {
            continue;
        }
        if rule.needs_attribution() {
            if producers.contains(&w.attribution.producer_id) {
                continue;
            }
            if let RootV1::Present(c) = w.attribution.consumer_id
                && consumers.contains(&c)
            {
                continue;
            }
            if per_profile.get(&ev.source_profile_id).copied().unwrap_or(0) >= cap {
                continue;
            }
            producers.insert(w.attribution.producer_id);
            if let RootV1::Present(c) = w.attribution.consumer_id {
                consumers.insert(c);
            }
            *per_profile.entry(ev.source_profile_id).or_insert(0) += 1;
        }
        out.push(BeaconSourceV1 {
            source_profile_id: ev.source_profile_id,
            canonical_work_id: ev.canonical_work_id,
            execution_commitment: ev.execution_commitment,
            accepted_position: ev.accepted_position,
            settlement_position: ev.settlement_position,
            occurrence_index: ev.occurrence_index,
        });
    }
    out
}

/// **The beacon at `tip_position`** of the branch whose settlement events are `events` — for a policy whose source rule reads no
/// attribution. A rule that does (the distinct rules) is refused here: use [`collect_attributed_work_beacon_v1`]. A complete-check
/// policy has no beacon at all ([`PolicyRefusalV1::NoBeacon`]).
pub fn collect_work_beacon_v1(
    ctx: &BeaconContextV1,
    events: &[WorkFinalEventV1],
    tip_position: u64,
) -> Result<WorkBeaconStateV1, PolicyRefusalV1> {
    if ctx.policy.is_sealed_source() {
        return Err(PolicyRefusalV1::WrongCollector("a sealed-source (v3) policy is collected by collect_sealed_work_beacon_v3"));
    }
    if ctx.policy.source_rule().is_some_and(SourceRuleV1::needs_attribution) {
        return Err(PolicyRefusalV1::Missing(
            "the attribution of each source (this policy's source rule reads producers and consumers)",
        ));
    }
    let works: Vec<AttributedWorkV1> = events.iter().map(unattributed).collect();
    collect_attributed_work_beacon_v1(ctx, &works, tip_position)
}

/// **The beacon at `tip_position`** of the branch whose attributed settlement events are `works`, under the policy's source rule.
pub fn collect_attributed_work_beacon_v1(
    ctx: &BeaconContextV1,
    works: &[AttributedWorkV1],
    tip_position: u64,
) -> Result<WorkBeaconStateV1, PolicyRefusalV1> {
    ctx.policy.validate()?;
    if !ctx.policy.needs_beacon() {
        return Err(PolicyRefusalV1::NoBeacon);
    }
    if ctx.policy.is_sealed_source() {
        return Err(PolicyRefusalV1::WrongCollector("a sealed-source (v3) policy is collected by collect_sealed_work_beacon_v3"));
    }
    let rule = ctx.policy.source_rule().ok_or(PolicyRefusalV1::UnknownId("source_eligibility_policy_id"))?;
    if matches!(ctx.subject_kind, SubjectKindV1::ModelConformance | SubjectKindV1::KernelConformance)
        && ctx.candidate_profile_id == RootV1::Absent
    {
        return Err(PolicyRefusalV1::Missing("candidate_profile_id"));
    }
    let need = ctx.policy.work_count_k;
    // Only what has settled by the tip exists on this branch.
    let settled: Vec<AttributedWorkV1> = works.iter().filter(|w| w.event.settlement_position <= tip_position).cloned().collect();
    let mut sources = canonical_attributed_sources_v1(ctx, &settled, rule);
    sources.truncate(need as usize);
    let have = sources.len() as u32;
    if have < need {
        return Ok(if tip_position >= ctx.window_end() {
            WorkBeaconStateV1::Unavailable { have, need }
        } else {
            WorkBeaconStateV1::Collecting { have, need }
        });
    }
    let lock_position = sources.last().expect("k ≥ 1").settlement_position.saturating_add(ctx.policy.settlement_depth_d);
    if tip_position < lock_position {
        return Ok(WorkBeaconStateV1::Candidate { have, lock_position });
    }
    let mut accumulators = vec![initial_accumulator_v1(ctx)];
    for (i, s) in sources.iter().enumerate() {
        let next = mix_v1(accumulators.last().expect("acc_0"), (i + 1) as u32, s);
        accumulators.push(next);
    }
    let output = *accumulators.last().expect("acc_k");
    let challenge_anchor = challenge_anchor_v1(ctx, &sources);
    Ok(WorkBeaconStateV1::Locked(VerifiedWorkBeaconV1 {
        beacon: WorkBeaconV1 { sources, accumulators, output, challenge_anchor, lock_position },
        context_id: ctx.id(),
    }))
}

/// Why a presented beacon is not the one this node derives.
#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
pub enum BeaconEvidenceRefusalV1 {
    #[error("the policy: {0}")]
    Policy(PolicyRefusalV1),
    #[error("this branch has no locked beacon for the subject ({0:?})")]
    NotLocked(WorkBeaconStateV1),
    #[error("this branch has no locked sealed-source beacon for the subject ({0})")]
    NotLockedV3(String),
    #[error("the presented beacon differs from the one derived from canonical history at source {at}")]
    Mismatch { at: usize },
    #[error("the presented accumulator chain, output or anchor is not the derivation of its sources")]
    Derivation,
}

/// **A fresh node checks a presented beacon** against its own canonical events: reordered, non-canonical, duplicated,
/// ineligible or substituted sources, a forged accumulator or anchor — all refused. The presented object is a claim to
/// recompute, never an input.
pub fn verify_work_beacon_v1(
    ctx: &BeaconContextV1,
    presented: &WorkBeaconV1,
    events: &[WorkFinalEventV1],
    tip_position: u64,
) -> Result<VerifiedWorkBeaconV1, BeaconEvidenceRefusalV1> {
    let derived = collect_work_beacon_v1(ctx, events, tip_position).map_err(BeaconEvidenceRefusalV1::Policy)?;
    compare_presented(derived, presented)
}

/// [`verify_work_beacon_v1`] over attributed works (the distinct source rules).
pub fn verify_attributed_work_beacon_v1(
    ctx: &BeaconContextV1,
    presented: &WorkBeaconV1,
    works: &[AttributedWorkV1],
    tip_position: u64,
) -> Result<VerifiedWorkBeaconV1, BeaconEvidenceRefusalV1> {
    let derived = collect_attributed_work_beacon_v1(ctx, works, tip_position).map_err(BeaconEvidenceRefusalV1::Policy)?;
    compare_presented(derived, presented)
}

fn compare_presented(derived: WorkBeaconStateV1, presented: &WorkBeaconV1) -> Result<VerifiedWorkBeaconV1, BeaconEvidenceRefusalV1> {
    match derived {
        WorkBeaconStateV1::Locked(b) => compare_presented_v1(b, presented),
        other => Err(BeaconEvidenceRefusalV1::NotLocked(other)),
    }
}

/// A presented beacon against the one this node derived: refused at the first differing source, or if anything else differs.
pub(crate) fn compare_presented_v1(
    derived: VerifiedWorkBeaconV1,
    presented: &WorkBeaconV1,
) -> Result<VerifiedWorkBeaconV1, BeaconEvidenceRefusalV1> {
    let n = derived.sources.len().max(presented.sources.len());
    if let Some(at) = (0..n).find(|i| derived.sources.get(*i) != presented.sources.get(*i)) {
        return Err(BeaconEvidenceRefusalV1::Mismatch { at });
    }
    if *derived.beacon() != *presented {
        return Err(BeaconEvidenceRefusalV1::Derivation);
    }
    Ok(derived)
}
