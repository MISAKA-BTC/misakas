use crate::{
    consensus::test_consensus::TestConsensus,
    model::{services::reachability::ReachabilityService, stores::headers::HeaderStoreReader},
};
use kaspa_consensus_core::BlockHash;
use kaspa_consensus_core::{
    BlockHashSet,
    api::ConsensusApi,
    block::{Block, BlockTemplate, MutableBlock, TemplateBuildMode, TemplateTransactionSelector},
    blockhash,
    blockstatus::BlockStatus,
    coinbase::MinerData,
    config::{
        ConfigBuilder,
        params::{DEVNET_PARAMS, MAINNET_PARAMS},
    },
    mldsa87_primitives::p2pkh_mldsa87_spk,
    tx::{Transaction, TransactionOutpoint},
};
use std::{collections::VecDeque, thread::JoinHandle};

mod palw_mergeset_view;

struct OnetimeTxSelector {
    txs: Option<Vec<Transaction>>,
    rejected: bool,
}

impl OnetimeTxSelector {
    fn new(txs: Vec<Transaction>) -> Self {
        Self { txs: Some(txs), rejected: false }
    }
}

impl TemplateTransactionSelector for OnetimeTxSelector {
    fn select_transactions(&mut self) -> Vec<Transaction> {
        // First call returns the fixed set; subsequent calls (the builder's
        // rejection re-selection loop) return empty so the loop terminates
        // instead of unwrapping `None`.
        self.txs.take().unwrap_or_default()
    }

    fn reject_selection(&mut self, _tx_id: kaspa_consensus_core::tx::TransactionId) {
        // Record the rejection so `is_successful` reports failure and
        // `build_block_template` surfaces the per-tx `RuleError` (instead of
        // panicking or silently dropping the tx).
        self.rejected = true;
    }

    fn is_successful(&self) -> bool {
        !self.rejected
    }
}

struct TestContext {
    consensus: TestConsensus,
    join_handles: Vec<JoinHandle<()>>,
    miner_data: MinerData,
    simulated_time: u64,
    current_templates: VecDeque<BlockTemplate>,
    current_tips: BlockHashSet,
}

impl Drop for TestContext {
    fn drop(&mut self) {
        self.consensus.shutdown(std::mem::take(&mut self.join_handles));
    }
}

impl TestContext {
    fn new(consensus: TestConsensus) -> Self {
        let join_handles = consensus.init();
        let genesis_hash = consensus.params().genesis.hash;
        let simulated_time = consensus.params().genesis.timestamp;
        Self {
            consensus,
            join_handles,
            miner_data: new_miner_data(),
            simulated_time,
            current_templates: Default::default(),
            current_tips: BlockHashSet::from_iter([genesis_hash]),
        }
    }

    pub fn build_block_template_row(&mut self, nonces: impl Iterator<Item = usize>) -> &mut Self {
        for nonce in nonces {
            self.simulated_time += self.consensus.params().target_time_per_block();
            self.current_templates.push_back(self.build_block_template(nonce as u64, self.simulated_time));
        }
        self
    }

    pub fn assert_row_parents(&mut self) -> &mut Self {
        for t in self.current_templates.iter() {
            assert_eq!(self.current_tips, BlockHashSet::from_iter(t.block.header.direct_parents().iter().copied()));
        }
        self
    }

    pub async fn validate_and_insert_row(&mut self) -> &mut Self {
        self.current_tips.clear();
        while let Some(t) = self.current_templates.pop_front() {
            self.current_tips.insert(t.block.header.hash);
            self.validate_and_insert_block(t.block.to_immutable()).await;
        }
        self
    }

    pub async fn build_and_insert_disqualified_chain(&mut self, mut parents: Vec<BlockHash>, len: usize) -> BlockHash {
        // The chain will be disqualified since build_block_with_parents builds utxo-invalid blocks
        for _ in 0..len {
            self.simulated_time += self.consensus.params().target_time_per_block();
            let b = self.build_block_with_parents(parents, 0, self.simulated_time);
            parents = vec![b.header.hash];
            self.validate_and_insert_block(b.to_immutable()).await;
        }
        parents[0]
    }

    /// A template with the timestamp the BUILDER chose, which is what a real miner mines.
    ///
    /// `build_block_template` below re-stamps, and on a network whose EVM lane is active that is
    /// silently fatal: `evm_commitment_root` is computed during the build over
    /// `EvmBlockInput { header_timestamp_ms, .. }`, so moving the timestamp afterwards leaves the
    /// header committing a root for a block that no longer exists and every such block is
    /// disqualified at `evm_commitment_root mismatch`. It went unnoticed because the lane is inert
    /// (`u64::MAX`) on every network the harness builds against except the RC's — and because
    /// `kaspa-consensus` had never been compiled with `--features evm`.
    ///
    /// `kaspad`'s own producer reads `template.block.header.timestamp` and never writes it, so
    /// this is the harness diverging from the miner, not the miner from the chain.
    pub fn build_block_template_keeping_time(&self, nonce: u64) -> BlockTemplate {
        let mut t = self
            .consensus
            .build_block_template(
                self.miner_data.clone(),
                Box::new(OnetimeTxSelector::new(Default::default())),
                TemplateBuildMode::Standard,
            )
            .unwrap();
        t.block.header.nonce = nonce;
        if kaspa_consensus_core::pow_layer0::is_palw_attempt_algo_id(t.block.header.pow_algo_id) {
            t.block.header.palw_commitment = self.consensus.palw_v2_test_carriage(&t.block.header);
        }
        t.block.header.finalize();
        t
    }

    pub fn build_block_template(&self, nonce: u64, timestamp: u64) -> BlockTemplate {
        let mut t = self
            .consensus
            .build_block_template(
                self.miner_data.clone(),
                Box::new(OnetimeTxSelector::new(Default::default())),
                TemplateBuildMode::Standard,
            )
            .unwrap();
        // See `build_block_template_keeping_time`: moving the timestamp after the build breaks
        // `evm_commitment_root`, so the re-stamp is only legal while the lane is inert. Asserted
        // rather than assumed — a silently invalid block is the failure this whole method caused.
        assert!(
            !self.consensus.params().is_evm_active(t.block.header.daa_score),
            "re-stamping a template whose EVM lane is active invalidates its evm_commitment_root — use build_block_template_keeping_time"
        );
        t.block.header.timestamp = timestamp;
        t.block.header.nonce = nonce;
        // ADR-0042 Decision 3a: the template DECLARES algo-6 on a `ConsensusV2` network but does
        // not carry an attempt — the carriage is the miner's, and producing one is what the work
        // IS. The harness stands in for that miner, and it must stamp after the timestamp and the
        // nonce because the challenge binds both: an envelope built before them would be an
        // attempt mounted at a different position, which is exactly what the finalizer refuses.
        if kaspa_consensus_core::pow_layer0::is_palw_attempt_algo_id(t.block.header.pow_algo_id) {
            t.block.header.palw_commitment = self.consensus.palw_v2_test_carriage(&t.block.header);
        }
        t.block.header.finalize();
        t
    }

    pub fn build_block_with_parents(&self, parents: Vec<BlockHash>, nonce: u64, timestamp: u64) -> MutableBlock {
        let mut b = self.consensus.build_block_with_parents_and_transactions(blockhash::NONE, parents, Default::default());
        b.header.timestamp = timestamp;
        b.header.nonce = nonce;
        // Same reason as `build_block_template`: the challenge binds the timestamp and the nonce,
        // so the carriage is stamped after they are final.
        if kaspa_consensus_core::pow_layer0::is_palw_attempt_algo_id(b.header.pow_algo_id) {
            b.header.palw_commitment = self.consensus.palw_v2_test_carriage(&b.header);
        }
        b.header.finalize(); // This overrides the NONE hash we passed earlier with the actual hash
        b
    }

    pub async fn validate_and_insert_block(&mut self, block: Block) -> &mut Self {
        let status = self.consensus.validate_and_insert_block(block).virtual_state_task.await.unwrap();
        assert!(status.has_block_body());
        self
    }

    /// kaspa-pq ADR-0018 §G (DAG-2 harness): build ONE block from a template with a
    /// custom `miner_data` (so the coinbase can pay a known, spendable key) and a
    /// custom tx set fed through `OnetimeTxSelector` (so the coinbase is computed
    /// correctly and the block can reach a valid UTXO tip — unlike
    /// `build_block_with_parents_and_transactions`, which builds a utxo-invalid
    /// coinbase). Parents are auto-selected from the current virtual tips, so the
    /// caller just mines a linear chain. Returns the inserted (immutable) block so
    /// the caller can read its coinbase outputs / daa score. NOTE: an invalid tx in
    /// `txs` makes the template builder call `OnetimeTxSelector::reject_selection`,
    /// which panics — i.e. an invalid funded spend fails loudly here.
    pub async fn mine_block(&mut self, miner_data: MinerData, txs: Vec<Transaction>) -> Block {
        self.simulated_time += self.consensus.params().target_time_per_block();
        let mut t = self
            .consensus
            .build_block_template(miner_data, Box::new(OnetimeTxSelector::new(txs)), TemplateBuildMode::Standard)
            .unwrap();
        t.block.header.timestamp = self.simulated_time;
        t.block.header.nonce = self.simulated_time;
        t.block.header.finalize();
        let block = t.block.to_immutable();
        self.validate_and_insert_block(block.clone()).await;
        block
    }

    pub fn assert_tips(&mut self) -> &mut Self {
        assert_eq!(BlockHashSet::from_iter(self.consensus.get_tips().into_iter()), self.current_tips);
        self
    }

    pub fn assert_tips_num(&mut self, expected_num: usize) -> &mut Self {
        assert_eq!(BlockHashSet::from_iter(self.consensus.get_tips().into_iter()).len(), expected_num);
        self
    }

    pub fn assert_virtual_parents_subset(&mut self) -> &mut Self {
        assert!(self.consensus.get_virtual_parents().is_subset(&self.current_tips));
        self
    }

    pub fn assert_valid_utxo_tip(&mut self) -> &mut Self {
        // Assert that at least one body tip was resolved with valid UTXO
        assert!(self.consensus.body_tips().iter().copied().any(|h| self.consensus.block_status(h) == BlockStatus::StatusUTXOValid));
        self
    }
}

#[tokio::test]
async fn template_mining_sanity_test() {
    let config = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    let rounds = 10;
    let width = 3;
    for _ in 0..rounds {
        ctx.build_block_template_row(0..width)
            .assert_row_parents()
            .validate_and_insert_row()
            .await
            .assert_tips()
            .assert_virtual_parents_subset()
            .assert_valid_utxo_tip();
    }
}

/// **ADR-0042 Unit C, through the real pipeline: the PALW V2 state is ABSENT — not idle — on a
/// network with no V2 bundle.**
///
/// The wiring note this closes says the fork-choice and state sites "consume these functions when
/// `PalwConsensusMode::ConsensusV2` exists to demand them — a dead handle in today's blue-work
/// pipeline would be surface without semantics". This is that property, asserted against real
/// block processing rather than against the gate's source: four rows of blocks go through the
/// whole virtual processor on a shipped-shaped network, and the PALW store is untouched at the
/// end — no genesis tip, no delta rows.
///
/// The V2 half is `palw_v2_state_walks_with_the_utxo_diff` below, which the harness can now build
/// because `TestConsensus::build_header_with_parents` stamps a position-bound attempt envelope on
/// a `ConsensusV2` network.
#[tokio::test]
async fn a_network_without_a_v2_bundle_keeps_no_palw_state() {
    let config = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    assert!(
        config.params.palw_consensus_mode.required_algo_id().is_none(),
        "the fixture must be a network with no V2 bundle — that is the property under test"
    );

    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..2).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let store = ctx.consensus.virtual_processor().palw_state_v2_store.read();
    assert!(store.tip_record().unwrap().is_none(), "no V2 bundle, no PALW tip — the walk is absent, not idle");
    assert!(
        store.iter_delta_blocks().next().is_none(),
        "no V2 bundle, no delta rows — real block processing wrote nothing into the PALW store"
    );
}

/// **The other half: on a `ConsensusV2` network the state really walks with the diff.**
///
/// Every chain block writes its delta in its own batch, the tip ends at the walk's own end point,
/// and — the property the whole store shape exists for — folding the deltas from genesis
/// reproduces the materialized tip exactly. A walk that drifted from its own deltas would be a
/// node whose resumed state and whose replayed state disagree, which is P0-4 wearing a different
/// hat.
#[tokio::test]
async fn palw_v2_state_walks_with_the_utxo_diff() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{PalwChainStateV2, apply_delta_v2};

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    // The fixture is a ruleset a node would really boot on, not a shape that merely type-checks.
    config.params.validate_palw_v2().expect("the fixture bundle is a runnable ruleset");
    let state_params = match &config.params.palw_consensus_mode {
        PalwConsensusMode::ConsensusV2(bundle) => bundle.state.clone(),
        _ => unreachable!(),
    };
    let genesis_hash = config.params.genesis.hash;

    let consensus = TestConsensus::new(&config);
    {
        let store = consensus.virtual_processor().palw_state_v2_store.read();
        let tip = store.tip_record().unwrap().expect("a V2 network installs its genesis tip");
        assert_eq!(tip.block, genesis_hash, "the zero point stands at genesis");
    }

    let mut ctx = TestContext::new(consensus);
    for _ in 0..4 {
        ctx.build_block_template_row(0..2).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let store = ctx.consensus.virtual_processor().palw_state_v2_store.read();
    let tip = store.tip_record().unwrap().expect("the walk wrote a tip");
    assert_ne!(tip.block, genesis_hash, "the walk advanced past genesis — the chain really was built");

    // The tip reloads under its OWN committed root: the same refusal a peer-supplied pruning
    // carriage gets, run against what this node just wrote.
    let (block, state) = store.load_tip(&state_params).unwrap().expect("the tip loads");
    assert_eq!(block, tip.block);
    assert_eq!(state.state_root(), tip.state_root, "the stored root is the state's own");
    assert!(store.has_delta(tip.block).unwrap(), "the tip block's own delta is on disk");

    // Fold every delta from genesis and compare. This is the differential the store exists to
    // make checkable — resume and replay must be the same state.
    // Genesis is INCLUDED now: it applies the bundle's registration list, so it has a delta like
    // every other chain block. Stopping the walk above it (the shape this test had before the
    // registrations landed) folds from a state the chain never had, and the second delta refuses
    // to apply — which is `revert/apply_delta_v2` doing its job, not a test detail.
    let chain: Vec<_> = ctx
        .consensus
        .virtual_processor()
        .reachability_service
        .default_backward_chain_iterator(tip.block)
        .take_while(|h| *h != kaspa_consensus_core::blockhash::ORIGIN)
        .collect();
    assert!(chain.len() > 1, "the fixture must produce chain blocks beyond genesis for the fold to mean anything");
    let mut folded = PalwChainStateV2::genesis();
    for block in chain.iter().rev() {
        let (_, delta) = store.delta_of(*block).expect("every chain block on the walk has a delta");
        folded = apply_delta_v2(&folded, &delta, &state_params).expect("the deltas fold");
    }
    assert_eq!(folded.state_root(), state.state_root(), "folding the deltas reproduces the materialized tip");
}

/// **ADR-0060 Decisions 1 + 2, through the real pipeline.** A heartbeat block — bondless,
/// carriage-less, fee-only — is accepted by a ConsensusV2 network, folds through the V2 state
/// walk as `PalwBlockWorkV3::None` (the clock ticking IS the sweep advancing), weighs exactly ε
/// in its child's blue work, and is refused when it violates the slot rule or declares a
/// subsidy. The ramp's fast arm is exercised end-to-end: with every bonded lane silent past six
/// hours, the interval is the full cadence.
#[tokio::test]
async fn palw_heartbeat_blocks_tick_the_clock_and_weigh_epsilon() {
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    // **The lane RUNS here, because ADR-0066 gave it a fence that can be armed.**
    //
    // This test used to skip: the lane was a `const bool` set to false, so the only way to run it
    // was to rebuild the binary — which is also the only way an operator could have turned the
    // lane on, and that was the defect. Arming `Params::palw_heartbeat` is a config change, so
    // the test arms it, and the thing under test is the thing an operator would deploy.
    kaspa_core::log::try_init_logger("info");
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_heartbeat = Some(kaspa_consensus_core::config::params::PalwHeartbeatV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
        })
        .build();
    config.params.validate_palw_v2().expect("the fixture bundle is a runnable ruleset");
    assert!(config.params.palw_heartbeat_lane_open_at(0), "the fence is armed, so the lane is open");
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Two bonded (algo-6) blocks so the chain has real bonded production behind it.
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // 1) Adapt an ordinary template into the lane. The carriage is emptied, the declared subsidy
    //    is zero — and the `bits` are the ones the template already had.
    ctx.simulated_time += 120_000;
    let template = ctx.build_block_template(7, ctx.simulated_time);
    let global_bits = template.block.header.bits;
    let (hb_template, earliest) =
        ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts a template");
    let hb_header = hb_template.block.header.clone();
    assert_eq!(hb_header.pow_algo_id, hb::PALW_HEARTBEAT_ALGO_ID);
    assert!(hb_header.palw_commitment.is_empty(), "a heartbeat carries no attempt — that is the lane");

    // **ADR-0066 Decision 1, as an assertion: the lane's price is NOT in `header.bits`.**
    //
    // This is the fix for the finding that withdrew the first implementation. The old adapter
    // overwrote `bits` with the lane's own 2²⁴-hard retarget, and those rows then sat in the
    // GLOBAL difficulty window — a window that filled with them demanded work 33,554,432, no
    // bonded block could re-enter it, and the chain was heartbeat-only for good. A heartbeat now
    // carries the same `bits` any other block at this position carries, so it is an ordinary
    // difficulty row and the average has nothing to run away from.
    assert_eq!(
        hb_header.bits, global_bits,
        "a heartbeat header carries the GLOBAL expected bits — the lane's own price lives in \
         StateLayer0, where nothing averages it"
    );

    assert!(earliest <= hb_header.timestamp, "the first heartbeat after a full hour has its slot");
    let payload = &hb_template.block.transactions[0].payload;
    assert_eq!(u64::from_le_bytes(payload[8..16].try_into().unwrap()), 0, "Decision 1.4: the declared subsidy is zero");
    assert_ne!(hb_header.palw_state_root, Default::default(), "a heartbeat chain block commits the parent state root");

    // 2) The pipeline accepts it and the V2 walk folds it (work = None) — the sink moves.
    let hb_hash = hb_header.hash;
    ctx.validate_and_insert_block(hb_template.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    // The slot rule pushed the heartbeat a full interval past its parent, so the simulated clock
    // has to follow it or every later template is `TimeTooOld` against its own ancestor.
    ctx.simulated_time = ctx.simulated_time.max(hb_header.timestamp);

    // 3) ε: the bonded child credits the heartbeat exactly one unit of blue work — a bonded
    //    block is ~10⁶ at these bits, so the lane is byte-for-byte "near-weightless".
    ctx.simulated_time += 120_000;
    let child = ctx.build_block_template(8, ctx.simulated_time);
    assert!(child.block.header.direct_parents().contains(&hb_hash), "the child extends the heartbeat");
    assert_eq!(
        child.block.header.blue_work - hb_header.blue_work,
        kaspa_consensus_core::BlueWorkType::from(hb::HEARTBEAT_BLUE_WORK_EPSILON),
        "the heartbeat's whole fork-choice contribution is ε"
    );
    ctx.validate_and_insert_block(child.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let child_ts = child.block.header.timestamp;

    // 4) **The slot rule, one block deep.** The selected parent is now the bonded child, so the
    //    interval is the nominal hour, measured from THAT header — not from a walk over the
    //    window. A heartbeat inside it is refused.
    ctx.simulated_time += 1_000;
    let template = ctx.build_block_template(9, ctx.simulated_time);
    let (early_hb, earliest) =
        ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("adapt reports the slot");
    assert_eq!(earliest, child_ts + hb::HEARTBEAT_NOMINAL_INTERVAL_MS, "a producing chain: one heartbeat per hour");
    let mut too_early = early_hb.block.clone();
    too_early.header.timestamp = child_ts + 1_000;
    too_early.header.finalize();
    match ctx.consensus.validate_and_insert_block(too_early.to_immutable()).virtual_state_task.await {
        Err(kaspa_consensus_core::errors::block::RuleError::HeartbeatTooEarly(_, _, last, interval)) => {
            assert_eq!(last, child_ts, "the boundary is the SELECTED PARENT's timestamp");
            assert_eq!(interval, hb::HEARTBEAT_NOMINAL_INTERVAL_MS);
        }
        other => panic!("a heartbeat inside the slot must be HeartbeatTooEarly, got {other:?}"),
    }

    // 5) Past the interval it is admitted — the clock the doctrine promises a stalled network.
    ctx.simulated_time = child_ts + hb::HEARTBEAT_NOMINAL_INTERVAL_MS + 60_000;
    let template = ctx.build_block_template(10, ctx.simulated_time);
    let (ramped, earliest) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).unwrap();
    assert!(earliest <= ramped.block.header.timestamp, "past the interval the slot is open");
    let ramped_ts = ramped.block.header.timestamp;
    ctx.validate_and_insert_block(ramped.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    ctx.simulated_time = ctx.simulated_time.max(ramped_ts);

    // 6) **And now the recovery cadence, which is what makes a stopped chain recoverable.** The
    //    selected parent is a heartbeat, so the interval drops from an hour to one block time —
    //    asserted as a DIFFERENCE against step 4, where the same call returned the hour.
    ctx.simulated_time = ramped_ts + hb::HEARTBEAT_RECOVERY_INTERVAL_MS;
    let template = ctx.build_block_template(11, ctx.simulated_time);
    let (recovering, earliest) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).unwrap();
    assert_eq!(
        earliest,
        ramped_ts + hb::HEARTBEAT_RECOVERY_INTERVAL_MS,
        "behind a heartbeat the lane runs at cadence, not at the calm-network hour"
    );
    assert!(hb::HEARTBEAT_RECOVERY_INTERVAL_MS < hb::HEARTBEAT_NOMINAL_INTERVAL_MS);
    ctx.validate_and_insert_block(recovering.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let recovering_ts = recovering.block.header.timestamp;
    ctx.simulated_time = ctx.simulated_time.max(recovering_ts);

    // 6b) **With the fence closed the adapter refuses, instead of handing back a block every
    //     peer would reject.** Built as a separate consensus because the fence is a params value:
    //     same bundle, same everything, `palw_heartbeat` unset.
    {
        let closed = ConfigBuilder::new(MAINNET_PARAMS)
            .skip_proof_of_work()
            .edit_consensus_params(|p| {
                p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
                *p = p.clone().with_palw_v2_cadence();
            })
            .build();
        assert!(closed.params.palw_heartbeat.is_none());
        let mut shut = TestContext::new(TestConsensus::new(&closed));
        shut.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
        shut.simulated_time += 120_000;
        let t = shut.build_block_template(20, shut.simulated_time);
        match shut.consensus.virtual_processor().heartbeat_adapt_block_template(t) {
            Err(kaspa_consensus_core::errors::block::RuleError::UnknownPowAlgoId(id)) => {
                assert_eq!(id, hb::PALW_HEARTBEAT_ALGO_ID, "refused with the validator's own answer");
            }
            other => panic!("a closed lane must refuse to build, got {other:?}"),
        }
    }

    // 7) Decision 1.4 is enforced, not advisory: the same heartbeat with its subsidy declared
    //    back at the full figure is refused as WrongSubsidy.
    ctx.simulated_time = recovering_ts + 240_000;
    let donor = ctx.build_block_template(12, ctx.simulated_time); // algo-6: full-subsidy coinbase
    let full_coinbase = donor.block.transactions[0].clone();
    let template = ctx.build_block_template(13, ctx.simulated_time + 1_000);
    let (greedy, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).unwrap();
    let mut greedy = greedy.block.clone();
    greedy.transactions[0] = full_coinbase;
    greedy.header.hash_merkle_root = kaspa_consensus_core::merkle::calc_hash_merkle_root(greedy.transactions.iter());
    greedy.header.finalize();
    match ctx.consensus.validate_and_insert_block(greedy.to_immutable()).virtual_state_task.await {
        Err(kaspa_consensus_core::errors::block::RuleError::WrongSubsidy(expected, _)) => {
            assert_eq!(expected, 0, "the lane's subsidy is zero by rule");
        }
        other => panic!("a heartbeat declaring a subsidy must be WrongSubsidy, got {other:?}"),
    }
}

/// **ADR-0066 Decision 3 (finding F2), closed by ADR-0068 Phase 1: under the fence an attempt
/// block's blue work is the network constant — and without it, `calc_work(bits)` as before.**
///
/// The audit's finding 2: on a V2 preset the class lottery is the throttle, so the ambient bits
/// price a bonded block at ~2 — parity with two ε = 1 sibling heartbeats for ~280 kH/s. Both
/// sides of the fence are asserted as blue-work DIFFERENCES through the real pipeline, so the
/// number a peer actually adds is the number under test.
#[tokio::test]
async fn adr0138_past_the_anchor_clock_the_heartbeat_still_ticks_the_clock() {
    // **ADR-0138: the clock is the lanes whose rate the chain sets — the anchor AND the heartbeat.**
    // The heartbeat is not priced by `bits` (ADR-0066) but it is the chain's liveness tick, one an
    // hour on a constant target: if it did not tick, a chain whose hash lane stopped would keep
    // producing while its DAA score froze. So merging a heartbeat moves the clock, exactly as it
    // did below the fence, and what the fence takes out is the attempt and receipt lanes.
    use crate::model::stores::daa::DaaStoreReader;
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    kaspa_core::log::try_init_logger("info");
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_heartbeat = Some(kaspa_consensus_core::config::params::PalwHeartbeatV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
            p.palw_anchor_clock = Some(kaspa_consensus_core::config::params::ForkActivation::always());
            // ADR-0142: the anchor clock may not be armed without the cursor — past it only a
            // heartbeat advances the score, and without the cursor a busy economic lane starves the
            // one lane that can. `validate_palw_v2` refuses the pair apart, which is what this
            // fixture would otherwise trip on.
            p.palw_clock_cursor = Some(kaspa_consensus_core::config::params::ForkActivation::always());
        })
        .build();
    config.params.validate_palw_v2().expect("the clock and its cursor are a runnable ruleset");
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    ctx.simulated_time += 120_000;
    let template = ctx.build_block_template(7, ctx.simulated_time);
    let (hb_template, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts");
    assert_eq!(hb_template.block.header.pow_algo_id, hb::PALW_HEARTBEAT_ALGO_ID);
    let hb_hash = hb_template.block.header.hash;
    let sink_before = ctx.consensus.get_sink();
    let daa_before = ctx.consensus.virtual_processor().headers_store.get_daa_score(sink_before).unwrap();
    let hb_timestamp = hb_template.block.header.timestamp;
    ctx.validate_and_insert_block(hb_template.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    // The heartbeat sits in its hourly slot, ahead of the simulated clock; the next anchor comes after it.
    ctx.simulated_time = ctx.simulated_time.max(hb_timestamp) + 120_000;
    let next = ctx.build_block_template(8, ctx.simulated_time);
    assert!(next.block.header.direct_parents().contains(&hb_hash), "the next anchor merges the heartbeat");
    let next_hash = next.block.header.hash;
    ctx.validate_and_insert_block(next.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let vp = ctx.consensus.virtual_processor();
    let daa_next = vp.headers_store.get_daa_score(next_hash).unwrap();
    let daa_hb = vp.headers_store.get_daa_score(hb_hash).unwrap();
    // Two blocks were added on top of `sink_before` — the heartbeat and the anchor that merged it —
    // and the clock moved by exactly one: the anchor's.
    assert_eq!(daa_hb, daa_before + 1, "the heartbeat's own score counts the anchor it built on");
    // The mergeset of `next` carries the heartbeat and the anchor `next` builds on. Something in it
    // is priced, so the beat adds nothing: one anchor, one tick. (Where NOTHING priced is merged —
    // a chain whose hash lane has stopped — one beat ticks in the anchor's place, which is what
    // keeps the clock from freezing; `daa_exempt_count` is where that lives.)
    // **ADR-0142 changed this answer, and the change is the rule working.** `next` merges ONLY the
    // heartbeat — nothing priced is in its mergeset — so whether it ticks is the beat's slot to
    // decide. The beat's own score came from the anchor IT merged, which makes the beat the block
    // that advanced to this score and therefore the reference the slot is measured from. A beat
    // cannot both cause an advance and then consume the slot that advance opened, so it does not
    // tick twice. Before the cursor it did, unconditionally, which is the clock running free.
    assert_eq!(daa_next, daa_hb, "the beat caused this score and cannot also consume the slot it opened: one advance, not two");
    let ghostdag = vp.ghostdag_store.get_data(next_hash).unwrap();
    assert!(
        ghostdag.mergeset_blues.contains(&hb_hash) || ghostdag.selected_parent == hb_hash,
        "the heartbeat is merged (blue, ε work) — outside the clock is not outside the DAG"
    );
    let non_daa = vp.daa_excluded_store.get_mergeset_non_daa(next_hash).unwrap_or_default();
    assert!(!non_daa.contains(&hb_hash), "and it is NOT in `mergeset_non_daa`: it is paid and folded like any blue");
}

/// **ADR-0142 §6, at the pipeline: the lane can no longer be starved, and the clock still cannot run
/// fast.** The two halves of the invariant, on a running consensus rather than on the pure rule.
///
/// The bug this pins: the slot rule measured a beat against its SELECTED PARENT, which every new
/// chain block replaces, so a chain producing faster than the interval moved the next opportunity
/// out of reach for ever. The drill froze at DAA 20 with the miner running and nothing minted.
///
/// Past the cursor a beat is admissible whenever its producer can pay for it — two in a row, in the
/// same slot, both accepted as BLOCKS — and exactly one of them moves the clock.
#[tokio::test]
async fn adr0142_past_the_cursor_a_beat_is_never_starved_and_the_clock_still_ticks_once_a_slot() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    kaspa_core::log::try_init_logger("info");
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_heartbeat = Some(kaspa_consensus_core::config::params::PalwHeartbeatV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
            p.palw_anchor_clock = Some(kaspa_consensus_core::config::params::ForkActivation::always());
            p.palw_clock_cursor = Some(kaspa_consensus_core::config::params::ForkActivation::always());
        })
        .build();
    config.params.validate_palw_v2().expect("the clock and its cursor are a runnable ruleset");
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // Three beats in a row, each building on the last — the shape a chain with no priced lane
    // actually has. The first still merges a priced anchor, so it is the SECOND that first merges
    // nothing but a beat, and the second is therefore where the cursor opens.
    let before = ctx.consensus.virtual_processor().headers_store.get_daa_score(ctx.consensus.get_sink()).unwrap();
    let mut beats = Vec::new();
    let mut scores = Vec::new();
    for (i, step_ms) in [120_000u64, 120_000, 1_000].into_iter().enumerate() {
        ctx.simulated_time += step_ms;
        let t = ctx.build_block_template(21 + i as u64, ctx.simulated_time);
        let (t, earliest) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(t).expect("the lane adapts");
        // **The starvation is gone**: past the cursor the earliest admissible time is now, for every
        // one of them. Under the retired slot rule the second and third were refused outright, and
        // on a chain that produces faster than the interval that refusal repeated for ever.
        assert_eq!(earliest, ctx.simulated_time, "beat {i}: past the cursor there is no slot to wait for");
        assert_eq!(t.block.header.timestamp, ctx.simulated_time, "beat {i}: and the template is not stamped forward");
        let hash = t.block.header.hash;
        ctx.validate_and_insert_block(t.block.clone().to_immutable()).await.assert_valid_utxo_tip();
        scores.push(ctx.consensus.virtual_processor().headers_store.get_daa_score(hash).unwrap());
        beats.push(hash);
    }

    // **The clock ticks once a slot, and the slot is measured from the last ADVANCE — whoever made
    // it.** Three beats 120 s, 120 s and 1 s apart produce two ticks over 240 s, which is the
    // cadence. Which of them ticks is worth spelling out, because it is one merge later than the
    // naive reading:
    //
    //   beat 0  merges the anchor, which is priced, so the ANCHOR ticks and beat 0 adds nothing.
    //           Beat 0 is now the block at the new score, so it is the reference.
    //   beat 1  merges beat 0. Nothing priced, so the stand-in applies — but beat 0's timestamp is
    //           the reference itself, so the slot it would consume is the one just opened. No tick.
    //   beat 2  merges beat 1, whose timestamp is a full interval past the reference. The slot is
    //           open, and the clock ticks.
    //
    // A beat is counted where it is MERGED, not where it is minted, so the slot is judged on the
    // merged beat's timestamp. That is why the cadence shows as two ticks and not three.
    assert_eq!(scores, vec![before + 1, before + 1, before + 2], "two ticks over two intervals: the cadence, not the block rate");
    assert_eq!(scores[2] - before, 2, "and 240 s of beats bought exactly two slots");

    // **Operator check 2: a competing branch drags nothing.** The reference is derived from the
    // block's OWN window, so a sibling cannot reach a score already decided. Here a fourth beat is
    // minted as a sibling of the third — same parents, different block — and every score already
    // written stays as it was.
    let before_scores = scores.clone();
    ctx.simulated_time += 1_000;
    let sibling = ctx.build_block_template(99, ctx.simulated_time);
    let (sibling, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(sibling).expect("the lane adapts");
    let sibling_hash = sibling.block.header.hash;
    assert_ne!(sibling_hash, beats[2], "the sibling is a different block");
    ctx.validate_and_insert_block(sibling.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let vp = ctx.consensus.virtual_processor();
    for (h, was) in beats.iter().zip(before_scores) {
        assert_eq!(vp.headers_store.get_daa_score(*h).unwrap(), was, "the sibling changed a score already written for {h}");
    }
    assert_eq!(
        vp.headers_store.get_daa_score(sibling_hash).unwrap(),
        scores[2],
        "and the sibling finds the same slot taken that its sibling did"
    );
}

/// The ADR-0142 fixture the cursor tests share: a V2 bundle with the heartbeat lane, the anchor
/// clock and the cursor armed from genesis — and, when `floor` is set, the clock floor (H3/H5).
fn clock_cursor_config(floor: bool) -> kaspa_consensus_core::config::Config {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_heartbeat = Some(kaspa_consensus_core::config::params::PalwHeartbeatV1 {
                activation: ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
            p.palw_anchor_clock = Some(ForkActivation::always());
            p.palw_clock_cursor = Some(ForkActivation::always());
            p.palw_clock_floor = floor.then(ForkActivation::always);
        })
        .build();
    config.params.validate_palw_v2().expect("the clock and its cursor are a runnable ruleset");
    config
}

/// Adapt a template built at `at` into a heartbeat, insert it, and return it with the `earliest`
/// the adapter reported. The simulated clock follows the stamp, as a miner's would.
async fn insert_beat_at(ctx: &mut TestContext, nonce: u64, at: u64) -> (kaspa_consensus_core::block::Block, u64) {
    ctx.simulated_time = ctx.simulated_time.max(at);
    let t = ctx.build_block_template(nonce, at);
    let (t, earliest) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(t).expect("the lane adapts");
    let block = t.block.to_immutable();
    ctx.simulated_time = ctx.simulated_time.max(block.header.timestamp);
    ctx.validate_and_insert_block(block.clone()).await.assert_valid_utxo_tip();
    (block, earliest)
}

/// **H1 (the 2026-09-24 heartbeat audit): past the cursor the adapter's `earliest` IS the slot, and
/// the hint says when a slot is taken.**
///
/// Measured on testnet-12: a tick took `120 s + a + b + c` (163–261 s per DAA), heartbeats were 74%
/// of blocks and 11% of beats got a tick. The miner never waited, because the adapter answered
/// `earliest = now` past the cursor — so it ground beats into a slot the clock had already advanced
/// through, each one a blue score and a relay for nothing, and the beat that could have been granted
/// started late. Both answers now come from the decision the DAA score itself is computed from.
#[tokio::test]
async fn h1_past_the_cursor_the_adapter_waits_for_the_slot_and_the_hint_names_it() {
    use kaspa_consensus_core::palw_heartbeat_v1::{HEARTBEAT_RECOVERY_INTERVAL_MS as I, HeartbeatYieldHintV1};
    kaspa_core::log::try_init_logger("info");
    let config = clock_cursor_config(false);
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let daa = |ctx: &TestContext, h| ctx.consensus.virtual_processor().headers_store.get_daa_score(h).unwrap();

    // Beat 0 merges the priced anchor, so the anchor ticks and beat 0 is the block at the new score:
    // the reference. The next slot opens one interval after it.
    let t0 = ctx.simulated_time + I;
    let (beat0, _) = insert_beat_at(&mut ctx, 31, t0).await;
    let slot = beat0.header.timestamp + I;

    // **Ten seconds later the slot is taken.** The adapter used to answer "now" here.
    let (early, earliest) = {
        let t = ctx.build_block_template(32, beat0.header.timestamp + 10_000);
        ctx.consensus.virtual_processor().heartbeat_adapt_block_template(t).expect("the lane adapts")
    };
    assert_eq!(earliest, slot, "past the cursor `earliest` is the next slot, not the template's own time");
    assert_eq!(early.block.header.timestamp, slot, "and a template adapted early is stamped for the slot, never before it");
    let vp = ctx.consensus.virtual_processor().clone();
    assert_eq!(vp.heartbeat_yield_hint_at(beat0.header.timestamp + 10_000), HeartbeatYieldHintV1::SlotTaken(slot));
    assert_eq!(vp.heartbeat_yield_hint_at(slot - 1), HeartbeatYieldHintV1::SlotTaken(slot), "until the last millisecond");
    assert_ne!(vp.heartbeat_yield_hint_at(slot), HeartbeatYieldHintV1::SlotTaken(slot), "and open at the boundary");

    // At the slot the beat is minted and holds it; a block that merges it steps. Between the two
    // the hint does NOT say "taken" — the step is the next block, and this lane may be the only one
    // that builds it.
    let (beat1, earliest1) = insert_beat_at(&mut ctx, 33, slot).await;
    assert_eq!(earliest1, slot);
    assert_eq!(daa(&ctx, beat1.header.hash), daa(&ctx, beat0.header.hash), "a beat holding the slot has not stepped yet");
    assert!(
        !matches!(vp.heartbeat_yield_hint_at(slot + 1), HeartbeatYieldHintV1::SlotTaken(_)),
        "a granted beat waiting in the virtual is not a taken slot: the next block steps the clock"
    );
    let (beat2, earliest2) = insert_beat_at(&mut ctx, 34, slot + 1_000).await;
    assert_eq!(earliest2, slot + 1_000, "the step's slot is already open: its own time");
    assert_eq!(daa(&ctx, beat2.header.hash), daa(&ctx, beat1.header.hash) + 1, "the step advanced the clock");

    // …and now the slot IS taken, until one interval after the step: the step is the reference.
    let next = beat2.header.timestamp + I;
    assert_eq!(vp.heartbeat_yield_hint_at(beat2.header.timestamp + 1), HeartbeatYieldHintV1::SlotTaken(next));
}

/// The cursor fixture with the attempt-work constant (so an attempt block outweighs any heartbeat
/// line) and, when `floor` is set, the clock floor.
fn clock_floor_config(floor: bool) -> kaspa_consensus_core::config::Config {
    let mut config = clock_cursor_config(floor);
    let mut params = config.params.clone();
    params.palw_attempt_work = Some(kaspa_consensus_core::config::params::PalwAttemptWorkV1 {
        activation: kaspa_consensus_core::config::params::ForkActivation::always(),
        work_log2: kaspa_consensus_core::pow_layer0::PALW_ATTEMPT_BLUE_WORK_LOG2,
        ticket_bucket_log2: kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2,
    });
    config = ConfigBuilder::new(params).skip_proof_of_work().build();
    config.params.validate_palw_v2().expect("the fixture is a runnable ruleset");
    config
}

/// A heartbeat on explicit parents: the harness block, re-declared into the lane (algo 8, no
/// carriage, a zero-subsidy coinbase — Decision 1.4) and stamped `timestamp`.
fn heartbeat_on(ctx: &TestContext, parents: Vec<BlockHash>, nonce: u64, timestamp: u64) -> MutableBlock {
    let mut b = ctx.build_block_with_parents(parents, nonce, timestamp);
    b.header.pow_algo_id = kaspa_consensus_core::palw_heartbeat_v1::PALW_HEARTBEAT_ALGO_ID;
    b.header.palw_commitment = Vec::new();
    b.transactions[0].payload[8..16].copy_from_slice(&0u64.to_le_bytes());
    b.transactions[0].finalize();
    b.header.hash_merkle_root = kaspa_consensus_core::merkle::calc_hash_merkle_root(b.transactions.iter());
    b.header.finalize();
    b
}

/// **H3: past the floor F5's chain exemption is paced — a burst chain is refused, the outage chain
/// F5 exists for still merges.**
///
/// The burst: eight attempt blocks a second apart (each outweighs any heartbeat line, and here each
/// advances the score), and a heartbeat hung off each, merging the beat before it. Every beat is
/// stamped at its own slot, so each is valid alone; together they are ONE chain of beats a second
/// apart that no slot paid for, and every one lands in the next beat's mergeset. Without the floor
/// the whole chain is admitted; with it, the first block whose mergeset holds more beats than their
/// timestamps pay for is refused.
#[tokio::test]
async fn h3_past_the_floor_a_burst_heartbeat_chain_is_refused_and_an_outage_chain_merges() {
    use kaspa_consensus_core::palw_heartbeat_v1::HEARTBEAT_RECOVERY_INTERVAL_MS as I;
    kaspa_core::log::try_init_logger("info");
    for floor in [true, false] {
        let config = clock_floor_config(floor);
        let mut ctx = TestContext::new(TestConsensus::new(&config));
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
        ctx.simulated_time += 120_000;
        let base = ctx.build_block_template(1, ctx.simulated_time);
        ctx.validate_and_insert_block(base.block.clone().to_immutable()).await.assert_valid_utxo_tip();
        let t = ctx.simulated_time;
        let mut line = vec![base.block.header.hash];
        for i in 1..=8u64 {
            let y = ctx.build_block_with_parents(vec![line[i as usize - 1]], 100 + i, t + i * 1_000);
            line.push(y.header.hash);
            ctx.consensus.validate_and_insert_block(y.to_immutable()).virtual_state_task.await.expect("an attempt on the line");
        }
        let mut previous: Option<BlockHash> = None;
        let mut refused = None;
        for i in 1..=8u64 {
            let mut parents = vec![line[i as usize - 1]];
            parents.extend(previous);
            let stamp = t + (i - 1) * 1_000 + I;
            if floor {
                let slot = ctx.consensus.virtual_processor().palw_clock_step_for_parents(&parents).unwrap().next_slot_ms();
                assert_eq!(slot, Some(stamp), "beat {i} is stamped exactly at its own slot");
            }
            let beat = heartbeat_on(&ctx, parents, 200 + i, stamp);
            let hash = beat.header.hash;
            match ctx.consensus.validate_and_insert_block(beat.to_immutable()).virtual_state_task.await {
                Ok(_) => previous = Some(hash),
                Err(e) => {
                    refused = Some((i, e));
                    break;
                }
            }
        }
        use kaspa_consensus_core::errors::block::RuleError::MergeSetHeartbeatChainUnpaced as Unpaced;
        match (floor, refused) {
            (true, Some((i, Unpaced(count, span, capacity)))) => {
                assert_eq!(i, 8, "the first beat whose mergeset holds more beats than they paid for");
                assert_eq!((count, span, capacity), (7, 6_000, 6), "seven beats over six seconds: the flat bound and one slot's two");
            }
            (false, None) => {}
            (floor, other) => panic!("floor={floor}: the burst answered {other:?}"),
        }
    }

    // **F5's own shape still merges past the floor.** Six outage beats in one chain, minted by the
    // lane's adapter a slot at a time, stranded behind a heavier bonded fork and merged whole.
    let config = clock_floor_config(true);
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    ctx.simulated_time += 120_000;
    let base = ctx.build_block_template(1, ctx.simulated_time);
    let base_hash = base.block.header.hash;
    ctx.validate_and_insert_block(base.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let mut chain = Vec::new();
    for nonce in 0..6u64 {
        ctx.simulated_time += I;
        let template = ctx.build_block_template(2 + nonce, ctx.simulated_time);
        let (hb_template, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts");
        ctx.simulated_time = ctx.simulated_time.max(hb_template.block.header.timestamp);
        chain.push(hb_template.block.header.hash);
        ctx.validate_and_insert_block(hb_template.block.clone().to_immutable()).await;
    }
    let fork = ctx.build_block_with_parents(vec![base_hash], 77, ctx.simulated_time + 1_000);
    let fork_hash = fork.header.hash;
    ctx.consensus.validate_and_insert_block(fork.to_immutable()).virtual_state_task.await.expect("the bonded fork is valid");
    let fork_ext = ctx.build_block_with_parents(vec![fork_hash], 78, ctx.simulated_time + 1_500);
    let fork_ext_hash = fork_ext.header.hash;
    ctx.consensus.validate_and_insert_block(fork_ext.to_immutable()).virtual_state_task.await.expect("the extension is valid");
    let merger = ctx.build_block_with_parents(vec![fork_ext_hash, chain[5]], 79, ctx.simulated_time + 2_000);
    {
        let gd = ctx.consensus.services.ghostdag_manager.ghostdag(merger.header.direct_parents());
        assert_eq!(gd.selected_parent, fork_ext_hash);
        let merged = gd.mergeset_blues.iter().chain(gd.mergeset_reds.iter()).filter(|h| chain.contains(h)).count() as u64;
        assert_eq!(merged, 6, "all six outage beats in one mergeset");
        assert!(merged > kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET);
    }
    ctx.consensus
        .validate_and_insert_block(merger.to_immutable())
        .virtual_state_task
        .await
        .expect("a chain paced a slot at a time is what F5's exemption is for, and the floor admits it");
}

/// **H5: a block of ANY lane that steps the clock on a beat's grant is stamped at or past the slot it
/// consumed — and without the floor one stamped two seconds after the reference stepped anyway.**
///
/// The block that steps becomes the next slot's reference. A heartbeat step already meets H3 (it is
/// a beat, over the same cursor); this is the step from another lane — here an attempt block whose
/// mergeset holds nothing priced but the beat that holds the slot, so the beat's grant is its tick.
#[tokio::test]
async fn h5_a_step_from_another_lane_is_stamped_at_or_past_its_slot() {
    use kaspa_consensus_core::palw_heartbeat_v1::HEARTBEAT_RECOVERY_INTERVAL_MS as I;
    kaspa_core::log::try_init_logger("info");
    for floor in [true, false] {
        let config = clock_cursor_config(floor);
        let mut ctx = TestContext::new(TestConsensus::new(&config));
        for _ in 0..2 {
            ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
        }
        let first = ctx.simulated_time + I;
        let (beat0, _) = insert_beat_at(&mut ctx, 41, first).await;
        let reference = beat0.header.timestamp;
        let slot = reference + I;
        let (holder, _) = insert_beat_at(&mut ctx, 42, slot).await;
        let holder_daa = ctx.consensus.virtual_processor().headers_store.get_daa_score(holder.header.hash).unwrap();
        // The next template steps the clock on the holder's grant; stamped "now" — two seconds after
        // the reference, long before the slot it consumes.
        let early = ctx.build_block_template(43, reference + 2_000);
        assert!(kaspa_consensus_core::pow_layer0::is_palw_attempt_algo_id(early.block.header.pow_algo_id), "another lane");
        assert_eq!(early.block.header.daa_score, holder_daa + 1, "it steps the clock");
        let hash = early.block.header.hash;
        match (floor, ctx.consensus.validate_and_insert_block(early.block.to_immutable()).virtual_state_task.await) {
            (true, Err(kaspa_consensus_core::errors::block::RuleError::ClockStepBeforeItsSlot(h, stamped, opens))) => {
                assert_eq!((h, stamped, opens), (hash, reference + 2_000, slot), "refused with the slot it consumed");
            }
            (false, Ok(_)) => {
                let parents: Vec<BlockHash> = ctx.consensus.get_virtual_parents().into_iter().collect();
                assert_eq!(
                    ctx.consensus.virtual_processor().palw_clock_step_for_parents(&parents).unwrap().next_slot_ms(),
                    Some(reference + 2_000 + I),
                    "without the floor it ticked, and the next slot opened two seconds after the last"
                );
            }
            (floor, other) => panic!("floor={floor}: a step two seconds after the reference answered {other:?}"),
        }
    }
}

#[tokio::test]
async fn palw_attempt_blocks_weigh_the_constant_under_the_fence() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    kaspa_core::log::try_init_logger("info");
    let catalog = palw_v2_test_catalog();

    // Fence ON: two bonded blocks, the second merging exactly the first — its blue-work delta is
    // the first block's whole contribution, and the rule says that is the constant.
    let armed = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_attempt_work = Some(kaspa_consensus_core::config::params::PalwAttemptWorkV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_ATTEMPT_BLUE_WORK_LOG2,
                ticket_bucket_log2: kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2,
            });
        })
        .build();
    armed.params.validate_palw_v2().expect("the fixture bundle plus the attempt-work fence is a runnable ruleset");
    assert!(armed.params.palw_attempt_work_open_at(0), "the fence is armed, so the constant is in force");
    let mut ctx = TestContext::new(TestConsensus::new(&armed));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    ctx.simulated_time += 120_000;
    let a = ctx.build_block_template(1, ctx.simulated_time);
    ctx.validate_and_insert_block(a.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    ctx.simulated_time += 120_000;
    let b = ctx.build_block_template(2, ctx.simulated_time);
    assert_eq!(b.block.header.direct_parents(), &[a.block.header.hash], "b merges exactly a");
    let constant = kaspa_consensus_core::BlueWorkType::from(1u64 << kaspa_consensus_core::pow_layer0::PALW_ATTEMPT_BLUE_WORK_LOG2);
    assert_eq!(
        b.block.header.blue_work - a.block.header.blue_work,
        constant,
        "under the fence a bonded block's whole fork-choice contribution is the constant — \
         2^20, a million heartbeats, not the ambient 2"
    );
    ctx.validate_and_insert_block(b.block.clone().to_immutable()).await.assert_valid_utxo_tip();

    // Fence OFF: the same two-block shape prices the bonded block from its bits — whatever that
    // figure is at these params, it is NOT the constant, or the fence gates nothing.
    let unfenced = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    assert!(unfenced.params.palw_attempt_work.is_none());
    let mut off = TestContext::new(TestConsensus::new(&unfenced));
    off.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    off.simulated_time += 120_000;
    let a = off.build_block_template(1, off.simulated_time);
    off.validate_and_insert_block(a.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    off.simulated_time += 120_000;
    let b = off.build_block_template(2, off.simulated_time);
    assert_ne!(
        b.block.header.blue_work - a.block.header.blue_work,
        constant,
        "without the fence the old pricing stands — the constant only enters by activation"
    );
}

/// **The Phase 1 drill (ADR-0068 / ADR-0064): the heartbeat clock sweeps a stopped chain back
/// to life, unattended.** This is the block-600 wedge — the exposure deadlock ADR-0060 §1 names
/// first — re-run WITH the clock, as the regression it should have been from the start:
///
/// 1. The only bond fills its exposure ceiling: four claims open, the fifth block exists in the
///    DAG but cannot become the sink. Releasing a claim requires DAA to advance; before the
///    lane, only this bond could advance it. Held forever, by arithmetic.
/// 2. The heartbeat lane ticks — one block an hour behind a producing chain, the full cadence
///    behind itself — and every tick advances the DAA the timeout sweep runs on. No bond, no
///    claim, no operator.
/// 3. The sweep voids the stuck claims on the clock's time, exposure releases, and the SAME
///    bonded producer's next block becomes the sink again. Nobody restarted anything.
#[tokio::test]
async fn the_heartbeat_clock_sweeps_a_stopped_chain_back_to_life() {
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    kaspa_core::log::try_init_logger("info");
    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_at_min_collateral(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            // The whole Phase 1 configuration: the clock, its width bound, and the attempt-work
            // constant — armed together, the way a deployment would.
            p.palw_heartbeat = Some(kaspa_consensus_core::config::params::PalwHeartbeatV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
            p.palw_attempt_work = Some(kaspa_consensus_core::config::params::PalwAttemptWorkV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_ATTEMPT_BLUE_WORK_LOG2,
                ticket_bucket_log2: kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2,
            });
        })
        .build();
    config.params.validate_palw_v2().expect("the Phase 1 configuration is a runnable ruleset");
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // 1) Fill the ceiling: as many claims as it admits fit, the next block cannot become the
    //    sink. This is the wedge — the one party that could advance the clock is the one party
    //    that is stuck. The count is derived so the wedge, not an arithmetic coincidence, is
    //    what this reproduces.
    let fits = palw_v2_claims_that_fit(&bundle);
    assert!(fits >= 2, "the fixture must admit more than one claim for the wedge to be the thing under test");
    for _ in 0..fits {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    {
        let store = ctx.consensus.virtual_processor().palw_state_v2_store.read();
        let (_, state) = store.load_tip(&bundle.state).unwrap().unwrap();
        assert_eq!(state.claims_iter().count() as u64, fits, "the bond is at its ceiling");
    }
    let wedged_sink = ctx.consensus.get_sink();
    ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    assert_eq!(ctx.consensus.get_sink(), wedged_sink, "one claim past the ceiling: the chain is wedged");

    // 2) The clock, and nothing else. First tick an hour out (the chain was producing a block
    //    ago), then the recovery cadence — each tick one DAA unit, sweeping the lifecycle
    //    windows a stuck bond never could. Claims void along the way; the loop watches for the
    //    release rather than assuming the horizon, and the ceiling on iterations IS the
    //    documented sweep horizon plus rebind slack.
    let mut released_at = None;
    for tick in 0u64..9_000 {
        let sink_ts = {
            let h = ctx.consensus.headers_store.get_header(ctx.consensus.get_sink()).unwrap();
            h.timestamp
        };
        let interval = if tick == 0 { hb::HEARTBEAT_NOMINAL_INTERVAL_MS } else { hb::HEARTBEAT_RECOVERY_INTERVAL_MS };
        ctx.simulated_time = ctx.simulated_time.max(sink_ts) + interval;
        let template = ctx.build_block_template(1_000 + tick, ctx.simulated_time);
        let (hb_template, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts");
        ctx.validate_and_insert_block(hb_template.block.clone().to_immutable()).await;
        if tick % 100 == 99 {
            let store = ctx.consensus.virtual_processor().palw_state_v2_store.read();
            let (_, state) = store.load_tip(&bundle.state).unwrap().unwrap();
            if state.claims_iter().count() == 0 {
                released_at = Some(tick + 1);
                break;
            }
        }
    }
    let ticks = released_at.expect("the sweep must void every stuck claim within the lifecycle horizon — that is the doctrine");

    // 3) Unattended recovery: the SAME bond's next block binds a fresh claim and becomes the
    //    sink. Nothing was restarted, re-registered or forced — the clock did all of it.
    ctx.simulated_time += 120_000;
    let sink_before = ctx.consensus.get_sink();
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    assert_ne!(ctx.consensus.get_sink(), sink_before, "with exposure released the bonded lane re-enters by itself");
    {
        let store = ctx.consensus.virtual_processor().palw_state_v2_store.read();
        let (_, state) = store.load_tip(&bundle.state).unwrap().unwrap();
        assert_eq!(state.claims_iter().count(), 1, "one fresh claim — the ceiling has room again");
    }
    kaspa_core::info!("heartbeat sweep released the wedge after {ticks} clock ticks");
}

/// **F3a, closed (ADR-0068 Phase 1): a mergeset holds at most `PALW_HEARTBEAT_MAX_PER_MERGESET`
/// heartbeats — refused by consensus, and never built by a template.**
///
/// Sibling heartbeats share one selected parent, one admissible timestamp and one fixed price,
/// so nothing bounded how many the DAG accepts. The bound is a mergeset property beside
/// `mergeset_size_limit`: five siblings exist, a block merging all five is refused, a block
/// merging four is valid, and the template builder chunks — four this block, the fifth against
/// the next block's fresh budget — so a flood is absorbed at a bounded rate rather than refused
/// forever or accepted wholesale.
#[tokio::test]
async fn a_mergeset_holds_at_most_four_heartbeats_and_templates_chunk_the_rest() {
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    kaspa_core::log::try_init_logger("info");
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_heartbeat = Some(kaspa_consensus_core::config::params::PalwHeartbeatV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
        })
        .build();
    config.params.validate_palw_v2().expect("the fixture bundle is a runnable ruleset");
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // A bonded base, then FIVE sibling heartbeats behind it — each valid alone (they share the
    // one admissible slot, which is exactly the width the slot rule cannot see).
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    ctx.simulated_time += 120_000;
    let base = ctx.build_block_template(1, ctx.simulated_time);
    let base_hash = base.block.header.hash;
    ctx.validate_and_insert_block(base.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    ctx.simulated_time += hb::HEARTBEAT_NOMINAL_INTERVAL_MS + 60_000;
    let template = ctx.build_block_template(2, ctx.simulated_time);
    let (hb_template, _) =
        ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts a template");
    assert_eq!(hb_template.block.header.direct_parents(), &[base_hash], "the siblings all sit behind the bonded base");
    let mut siblings = Vec::new();
    for nonce in 0..5u64 {
        let mut sib = hb_template.block.clone();
        sib.header.nonce = nonce;
        sib.header.finalize();
        siblings.push(sib.header.hash);
        ctx.validate_and_insert_block(sib.to_immutable()).await;
    }
    ctx.simulated_time = ctx.simulated_time.max(hb_template.block.header.timestamp);

    // Consensus: merging all five is one heartbeat too many; merging four is a valid block.
    ctx.simulated_time += 120_000;
    let over = ctx.build_block_with_parents(siblings.clone(), 77, ctx.simulated_time);
    match ctx.consensus.validate_and_insert_block(over.to_immutable()).virtual_state_task.await {
        Err(kaspa_consensus_core::errors::block::RuleError::MergeSetTooManyHeartbeats(count, bound)) => {
            assert_eq!(bound, kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET);
            assert!(count > bound, "refused at the first heartbeat past the bound");
        }
        other => panic!("five heartbeats in one mergeset must be MergeSetTooManyHeartbeats, got {other:?}"),
    }
    let four = ctx.build_block_with_parents(siblings[..4].to_vec(), 78, ctx.simulated_time + 1);
    ctx.consensus.validate_and_insert_block(four.to_immutable()).virtual_state_task.await.expect("four heartbeats fit the bound");

    // Template: pointed at the five-sibling DAG (before the manual merger reshaped it, the
    // template path saw the same five tips) the builder never over-merges — count the heartbeat
    // parents of the four-merger's OWN template-built successor: the fifth sibling rides a later
    // block's fresh budget instead of being merged here.
    ctx.simulated_time += 120_000;
    let next = ctx.build_block_template(3, ctx.simulated_time);
    let hb_parents = next.block.header.direct_parents().iter().filter(|p| siblings.contains(p)).count() as u64;
    let mergeset_hbs = {
        // The template's parents are not the whole story — the bound is on the MERGESET. Count
        // heartbeats the way the rule does.
        let gd = ctx.consensus.services.ghostdag_manager.ghostdag(next.block.header.direct_parents());
        gd.mergeset_blues.iter().chain(gd.mergeset_reds.iter()).filter(|h| siblings.contains(h)).count() as u64
    };
    assert!(
        mergeset_hbs <= kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
        "a template never builds what consensus refuses: {mergeset_hbs} heartbeats in its mergeset"
    );
    ctx.validate_and_insert_block(next.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let _ = hb_parents;

    // And the fifth is absorbed, not orphaned: within a couple of template rounds every sibling
    // is in the selected chain's past — the flood was chunked, which is the whole design.
    ctx.simulated_time += 120_000;
    let after = ctx.build_block_template(4, ctx.simulated_time);
    ctx.validate_and_insert_block(after.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let sink = ctx.consensus.get_sink();
    for sib in &siblings {
        assert!(
            ctx.consensus.services.reachability_service.is_dag_ancestor_of(*sib, sink),
            "every sibling heartbeat ends up merged — the bound chunks, it does not strand"
        );
    }
}

/// **F5, closed: a heartbeat CHAIN of any depth merges in one mergeset — a heartbeat TREE does
/// not** (ADR-0068 Phase 1, the drill's fifth finding).
///
/// The live drill manufactured the strand: a heavier bonded fork put five outage heartbeats in
/// its anticone, merging the tip meant dragging all five ancestors into one mergeset, the flat
/// bound refused, and — because the intermediates are not tips — no chunking path existed. 400+
/// templates excluded the branch forever, and whatever rode it would have unwound. But a CHAIN
/// is the lane doing its job through a long outage, already rate-priced by the slot ladder;
/// what F3a is about is WIDTH. So the rule is "flat bound, or one chain", and this test pins
/// both edges: the drill's exact shape now merges, and a tree — one root, many children, the
/// shape that would fool a chain-HEAD count — still refuses.
#[tokio::test]
async fn a_heartbeat_chain_of_any_depth_merges_but_a_tree_does_not() {
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    kaspa_core::log::try_init_logger("info");
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_heartbeat = Some(kaspa_consensus_core::config::params::PalwHeartbeatV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
            p.palw_attempt_work = Some(kaspa_consensus_core::config::params::PalwAttemptWorkV1 {
                activation: kaspa_consensus_core::config::params::ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_ATTEMPT_BLUE_WORK_LOG2,
                ticket_bucket_log2: kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2,
            });
        })
        .build();
    config.params.validate_palw_v2().expect("the fixture bundle is a runnable ruleset");
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // A bonded base, then the drill's outage: SIX heartbeats in one chain, each the next's
    // selected parent — they become the sink chain, one ε at a time.
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    ctx.simulated_time += 120_000;
    let base = ctx.build_block_template(1, ctx.simulated_time);
    let base_hash = base.block.header.hash;
    ctx.validate_and_insert_block(base.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let mut chain = Vec::new();
    for nonce in 0..6u64 {
        ctx.simulated_time += if nonce == 0 { hb::HEARTBEAT_NOMINAL_INTERVAL_MS + 60_000 } else { hb::HEARTBEAT_RECOVERY_INTERVAL_MS };
        let template = ctx.build_block_template(2 + nonce, ctx.simulated_time);
        let (hb_template, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts");
        ctx.simulated_time = ctx.simulated_time.max(hb_template.block.header.timestamp);
        chain.push(hb_template.block.header.hash);
        ctx.validate_and_insert_block(hb_template.block.clone().to_immutable()).await;
    }

    // The heavier bonded fork from BASE: a tip is compared by the work of its PAST, so the
    // fork's own 2^20 counts once a child stands on it — one extension block, and the bonded
    // branch (W + 2^20) dwarfs the heartbeat chain's W + 5ε. The six become a deep side
    // branch: the drill's stranded shape, exactly.
    let fork = ctx.build_block_with_parents(vec![base_hash], 77, ctx.simulated_time + 1_000);
    let fork_hash = fork.header.hash;
    ctx.consensus.validate_and_insert_block(fork.to_immutable()).virtual_state_task.await.expect("the bonded fork is valid");
    let fork_ext = ctx.build_block_with_parents(vec![fork_hash], 78, ctx.simulated_time + 1_500);
    let fork_ext_hash = fork_ext.header.hash;
    ctx.consensus.validate_and_insert_block(fork_ext.to_immutable()).virtual_state_task.await.expect("the extension is valid");

    // THE F5 EDGE: a block merging the chain's tip drags all six into one mergeset — over the
    // flat bound, admissible because they are one chain. Before the exemption this was the
    // permanent strand. The shape is asserted, not assumed: the merger's selected parent is the
    // bonded branch (F2's constant makes its past the heaviest), so the whole heartbeat chain
    // is its mergeset.
    let merger = ctx.build_block_with_parents(vec![fork_ext_hash, chain[5]], 79, ctx.simulated_time + 2_000);
    {
        let gd = ctx.consensus.services.ghostdag_manager.ghostdag(merger.header.direct_parents());
        assert_eq!(gd.selected_parent, fork_ext_hash, "the bonded branch's past outweighs six ε — F2's constant at work");
        let hbs_in_mergeset = gd.mergeset_blues.iter().chain(gd.mergeset_reds.iter()).filter(|h| chain.contains(h)).count() as u64;
        assert_eq!(hbs_in_mergeset, 6, "all six outage heartbeats land in ONE mergeset — the drill's exact strand shape");
        assert!(hbs_in_mergeset > kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET);
    }
    ctx.consensus
        .validate_and_insert_block(merger.to_immutable())
        .virtual_state_task
        .await
        .expect("six heartbeats in ONE chain merge in one mergeset — the drill's strand is absorbed");

    // And the TREE: two chained heartbeats, then four siblings on the second — six members, one
    // head, NOT one chain. A chain-head count would admit it; the pairwise order refuses it.
    // A FRESH consensus, deliberately: the chain half left a heavy disqualified branch behind,
    // and a template would merge its tips as extra parents — the sibling POV then out-weighs
    // the fork and the six split across past and mergeset, which is a different diagram than
    // the one under test (measured: hbs-in-mergeset dropped to three).
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    ctx.simulated_time += 120_000;
    let base2 = ctx.build_block_template(20, ctx.simulated_time);
    let base2_hash = base2.block.header.hash;
    ctx.validate_and_insert_block(base2.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let mut tree = Vec::new();
    for nonce in 0..2u64 {
        ctx.simulated_time += if nonce == 0 { hb::HEARTBEAT_NOMINAL_INTERVAL_MS + 60_000 } else { hb::HEARTBEAT_RECOVERY_INTERVAL_MS };
        let template = ctx.build_block_template(21 + nonce, ctx.simulated_time);
        let (hb_template, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts");
        ctx.simulated_time = ctx.simulated_time.max(hb_template.block.header.timestamp);
        tree.push(hb_template.block.header.hash);
        ctx.validate_and_insert_block(hb_template.block.clone().to_immutable()).await;
    }
    ctx.simulated_time += hb::HEARTBEAT_RECOVERY_INTERVAL_MS;
    let template = ctx.build_block_template(23, ctx.simulated_time);
    let (sib_template, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts");
    assert_eq!(sib_template.block.header.direct_parents(), &[tree[1]], "the siblings all ride the chain's tip");
    for nonce in 0..4u64 {
        let mut sib = sib_template.block.clone();
        sib.header.nonce = 100 + nonce;
        sib.header.finalize();
        tree.push(sib.header.hash);
        ctx.validate_and_insert_block(sib.to_immutable()).await;
    }
    ctx.simulated_time = ctx.simulated_time.max(sib_template.block.header.timestamp);
    let fork2 = ctx.build_block_with_parents(vec![base2_hash], 81, ctx.simulated_time + 1_000);
    let fork2_hash = fork2.header.hash;
    ctx.consensus.validate_and_insert_block(fork2.to_immutable()).virtual_state_task.await.expect("the second fork is valid");
    let fork2_ext = ctx.build_block_with_parents(vec![fork2_hash], 82, ctx.simulated_time + 1_500);
    let fork2_ext_hash = fork2_ext.header.hash;
    ctx.consensus.validate_and_insert_block(fork2_ext.to_immutable()).virtual_state_task.await.expect("the second extension is valid");
    let tree_merger =
        ctx.build_block_with_parents(vec![fork2_ext_hash, tree[2], tree[3], tree[4], tree[5]], 83, ctx.simulated_time + 2_000);
    {
        let gd = ctx.consensus.services.ghostdag_manager.ghostdag(tree_merger.header.direct_parents());
        assert_eq!(gd.selected_parent, fork2_ext_hash, "the bonded branch's past is the heaviest here too");
        let hbs_in_mergeset = gd.mergeset_blues.iter().chain(gd.mergeset_reds.iter()).filter(|h| tree.contains(h)).count() as u64;
        assert_eq!(hbs_in_mergeset, 6, "the whole tree — two chained, four siblings — lands in one mergeset");
    }
    match ctx.consensus.validate_and_insert_block(tree_merger.to_immutable()).virtual_state_task.await {
        Err(kaspa_consensus_core::errors::block::RuleError::MergeSetTooManyHeartbeats(count, bound)) => {
            assert_eq!(count, 6, "two chained plus four siblings — six members, not one chain");
            assert_eq!(bound, kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET);
        }
        other => panic!("a heartbeat TREE over the bound must be MergeSetTooManyHeartbeats, got {other:?}"),
    }
}

/// The ruleset the slow-producer trap was measured on, in miniature: a V2 network at 120 s
/// (`ghostdag_k = 1`), the heartbeat lane and the attempt-work constant armed from genesis (as on
/// testnet-11 since Relaunch 5), and a bond funded for more concurrent claims than the scenario
/// makes. `transparent` arms ADR-0105's coloring fence from genesis on top.
fn heartbeat_trap_config(transparent: bool) -> kaspa_consensus_core::config::Config {
    use kaspa_consensus_core::config::params::{ForkActivation, PalwAttemptWorkV1, PalwHeartbeatV1};
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle_funded_for(&catalog, 16));
            *p = p.clone().with_palw_v2_cadence();
            p.palw_heartbeat = Some(PalwHeartbeatV1 {
                activation: ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_WORK_LOG2,
                max_per_mergeset: kaspa_consensus_core::pow_layer0::PALW_HEARTBEAT_MAX_PER_MERGESET,
            });
            p.palw_attempt_work = Some(PalwAttemptWorkV1 {
                activation: ForkActivation::always(),
                work_log2: kaspa_consensus_core::pow_layer0::PALW_ATTEMPT_BLUE_WORK_LOG2,
                ticket_bucket_log2: kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2,
            });
            if transparent {
                p.palw_heartbeat_transparent = Some(ForkActivation::always());
            }
        })
        .build();
    config.params.validate_palw_v2().expect("the trap's ruleset is a runnable one");
    assert_eq!(config.params.ghostdag_k(), 1, "the 120 s preset — the k the trap needs");
    assert_eq!(config.params.palw_heartbeat_transparent_fence().is_some(), transparent);
    config
}

/// One recovery-cadence slot as the fleet produced it on 2026-09-10: the heartbeat a template
/// adapts to, plus `siblings` more at the same slot (four miners put 2-4 heartbeats in every slot).
/// Returns the template's heartbeat, whose parents are the tips — including any bonded block that
/// has landed.
async fn mine_heartbeat_slot(ctx: &mut TestContext, nonce: u64, siblings: u64) -> BlockHash {
    let template = ctx.build_block_template(nonce, ctx.simulated_time);
    let (heartbeat, _) = ctx.consensus.virtual_processor().heartbeat_adapt_block_template(template).expect("the lane adapts");
    ctx.simulated_time = ctx.simulated_time.max(heartbeat.block.header.timestamp);
    let hash = heartbeat.block.header.hash;
    ctx.validate_and_insert_block(heartbeat.block.clone().to_immutable()).await;
    for sibling in 0..siblings {
        let mut block = heartbeat.block.clone();
        block.header.nonce = nonce ^ (0x5151_0000 + sibling);
        block.header.finalize();
        ctx.validate_and_insert_block(block.to_immutable()).await;
    }
    hash
}

/// What one run of the slow-producer scenario measured.
struct HeartbeatTrapRun {
    /// Per landed draw: was it colored blue by the heartbeat that merged it, and how much work that
    /// heartbeat added to its selected parent's.
    draws: Vec<(bool, kaspa_consensus_core::BlueWorkType)>,
    /// `blue_work(sink) - blue_work(first heartbeat of the episode)`: the most any DNS anchor inside
    /// the episode could be buried by — `getDnsConfirmation`'s `workDepth` is this quantity.
    work_depth: kaspa_consensus_core::BlueWorkType,
    sink_is_heartbeat: bool,
    /// The interval the slot rule sets for the next heartbeat at the end of the run.
    next_heartbeat_interval: u64,
    /// Did any landed draw ever become a selected-chain block?
    a_draw_was_selected: bool,
}

/// **The scenario, measured on testnet-11 on 2026-09-10 (11:41Z-13:20Z), in the pipeline.**
///
/// A producing chain; a bonded outage past the nominal hour (the fleet's node restarts), so a
/// heartbeat takes the chain; then a producer whose every draw takes ~17 minutes: its template is
/// built on the heartbeat tip, eight recovery-cadence slots of heartbeats (two per slot) land while
/// it draws, and the draw lands carrying its template's timestamp. The next heartbeat merges it.
async fn run_the_slow_producer_trap(transparent: bool, draws: usize) -> HeartbeatTrapRun {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    kaspa_core::log::try_init_logger("info");
    let config = heartbeat_trap_config(transparent);
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let producing = ctx.consensus.get_sink();
    ctx.simulated_time =
        ctx.consensus.headers_store.get_header(producing).unwrap().timestamp + hb::HEARTBEAT_NOMINAL_INTERVAL_MS + 60_000;
    let episode_start = mine_heartbeat_slot(&mut ctx, 100, 1).await;

    // The producer's first draw, on the heartbeat tip.
    ctx.simulated_time += 1_000;
    let mut pending = ctx.build_block_template(200, ctx.simulated_time);
    let mut nonce = 300u64;
    let mut landed = Vec::new();
    let mut out = Vec::new();
    for _ in 0..draws {
        for _ in 0..8 {
            ctx.simulated_time += hb::HEARTBEAT_RECOVERY_INTERVAL_MS;
            mine_heartbeat_slot(&mut ctx, nonce, 1).await;
            nonce += 16;
        }
        let draw = pending.block.header.hash;
        let drawn_at = pending.block.header.timestamp;
        ctx.simulated_time += 60_000;
        assert!(ctx.simulated_time - drawn_at >= 17 * 60_000, "the draw lands ~17 minutes after its template");
        ctx.validate_and_insert_block(pending.block.clone().to_immutable()).await;
        landed.push(draw);
        assert!(
            ctx.consensus.get_sink() != draw,
            "a block carrying its template's parents is eight ε behind the heartbeat tip on landing — never the sink"
        );
        // The producer starts its next draw on what it sees now; the next slot's heartbeat merges this one.
        pending = ctx.build_block_template(nonce, ctx.simulated_time);
        nonce += 16;
        ctx.simulated_time += hb::HEARTBEAT_RECOVERY_INTERVAL_MS;
        let merger = mine_heartbeat_slot(&mut ctx, nonce, 1).await;
        nonce += 16;
        let merged = ctx.consensus.ghostdag_store().get_data(merger).unwrap();
        let blue = merged.mergeset_blues.contains(&draw);
        assert!(blue || merged.mergeset_reds.contains(&draw), "the heartbeat after the draw merges it");
        let added = merged.blue_work - ctx.consensus.ghostdag_store().get_blue_work(merged.selected_parent).unwrap();
        out.push((blue, added));
    }

    let sink = ctx.consensus.get_sink();
    let sink_header = ctx.consensus.headers_store.get_header(sink).unwrap();
    let work_depth = ctx.consensus.ghostdag_store().get_blue_work(sink).unwrap()
        - ctx.consensus.ghostdag_store().get_blue_work(episode_start).unwrap();
    let a_draw_was_selected = landed.iter().any(|draw| ctx.consensus.services.reachability_service.is_chain_ancestor_of(*draw, sink));
    HeartbeatTrapRun {
        draws: out,
        work_depth,
        sink_is_heartbeat: sink_header.pow_algo_id == hb::PALW_HEARTBEAT_ALGO_ID,
        // The v2 form with the pre-fence answers, which is byte-identical to v1 — the fixture is
        // below `palw_anchor_clock`. Spelled this way because the v1 entry points have exactly one
        // module allowed to ask them (`only_this_module_may_ask_the_pre_fence_slot_rule`).
        next_heartbeat_interval: hb::heartbeat_interval_ms_v2(sink_header.pow_algo_id, false, true),
        a_draw_was_selected,
    }
}

/// **ADR-0105: the slow-producer trap, reproduced on the rule testnet-11 runs — and closed by the
/// fence.**
///
/// Without the fence it is the 2026-09-10 incident exactly: every draw lands RED (eight heartbeats
/// in its anticone at `k = 1`), the heartbeat that merges it gains two ε and not one unit of the
/// draw's 2²⁰, no draw is ever a chain block, the chain stays on the recovery cadence — and the
/// work piled on anything inside the episode stays under testnet-11's `required_work_depth` (100)
/// however long it runs, which is `pow_confirmed = false` and a paused bridge.
///
/// With the fence the same DAG colors every draw BLUE: the merging heartbeat carries its 2²⁰, and
/// the work depth passes the requirement at the first draw. What the fence deliberately does NOT
/// do is make the draw a chain block — the heartbeats that merge it carry its work, so the chain
/// stays heartbeat-led at the recovery cadence while heartbeat miners run. Handing the chain back
/// is Decision 2's (the miner's yield); see the test below.
#[tokio::test]
async fn a_slow_bonded_draw_is_red_behind_heartbeats_until_the_fence_keeps_its_work() {
    use kaspa_consensus_core::BlueWorkType;
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    let bonded = BlueWorkType::from(1u64 << kaspa_consensus_core::pow_layer0::PALW_ATTEMPT_BLUE_WORK_LOG2);
    let required = kaspa_consensus_core::config::params::TESTNET_DNS_PARAMS.required_work_depth;
    assert_eq!(required, BlueWorkType::from(100u64), "testnet-11's requiredWorkDepth, as getDnsConfirmation printed it");

    // ---- The rule testnet-11 runs today: the lock-out. ----
    let trapped = run_the_slow_producer_trap(false, 2).await;
    kaspa_core::info!(
        "ADR-0105 trap, fence dormant: draws (blue, added work) = {:?}; work depth over the episode = {}",
        trapped.draws,
        trapped.work_depth
    );
    for (i, (blue, added)) in trapped.draws.iter().enumerate() {
        assert!(!blue, "draw {i}: eight heartbeats in its anticone at k = 1 color it RED — the incident's 59563aa3 / 1b9225e1");
        assert!(*added < bonded, "draw {i}: its 2^20 is in no block's blue work (the merger added {added})");
    }
    assert!(!trapped.a_draw_was_selected, "no draw ever becomes a chain block");
    assert!(trapped.sink_is_heartbeat, "the chain is still on heartbeats");
    assert_eq!(
        trapped.next_heartbeat_interval,
        hb::HEARTBEAT_RECOVERY_INTERVAL_MS,
        "…at the recovery cadence: the mode sustains itself"
    );
    assert!(
        trapped.work_depth < required,
        "~40 minutes of heartbeats and two bonded draws bury nothing to testnet-11's required work depth: {} < {required} — \
         pow_confirmed stays false, dns_confirmed stays false, the bridge stays paused",
        trapped.work_depth
    );

    // ---- The same DAG with ADR-0105's fence armed. ----
    let fenced = run_the_slow_producer_trap(true, 2).await;
    kaspa_core::info!(
        "ADR-0105 trap, fence armed: draws (blue, added work) = {:?}; work depth over the episode = {}",
        fenced.draws,
        fenced.work_depth
    );
    for (i, (blue, added)) in fenced.draws.iter().enumerate() {
        assert!(*blue, "draw {i}: heartbeats no longer count against it, so the merge colors it BLUE");
        assert!(*added > bonded, "draw {i}: the merging heartbeat carries the draw's whole 2^20 (added {added})");
    }
    assert!(
        fenced.work_depth >= bonded * BlueWorkType::from(2u64),
        "every draw's work is in the chain's blue work ({})",
        fenced.work_depth
    );
    assert!(fenced.work_depth > required, "the DNS work depth passes testnet-11's requirement at the first draw");
    // Stated rather than hidden: the fence keeps the work, it does not hand the chain back.
    assert!(!fenced.a_draw_was_selected, "the heartbeats that merge a draw carry its work, so they stay the chain");
    assert!(fenced.sink_is_heartbeat);
}

/// How the heartbeat after a slow draw would color it, when the draw lands after `slots`
/// recovery-cadence slots (two heartbeats each). Computed with the GHOSTDAG manager over the tips —
/// the merger's parents — WITHOUT inserting a merger, because a draw colored red beyond the
/// merge-depth window cannot be merged at all (`ViolatingBoundedMergeDepth`), which is today's
/// behaviour for such a block and not what is being measured here. Also returns the walk's floor
/// and the blue score of the draw's selected-chain ancestor, so the boundary is checked against
/// the formula rather than against a number typed into the test.
async fn color_of_a_slow_draw(transparent: bool, slots: u64) -> (bool, u64, u64) {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::palw_heartbeat_v1 as hb;
    let config = heartbeat_trap_config(transparent);
    let merge_depth = config.params.merge_depth();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let producing = ctx.consensus.get_sink();
    ctx.simulated_time =
        ctx.consensus.headers_store.get_header(producing).unwrap().timestamp + hb::HEARTBEAT_NOMINAL_INTERVAL_MS + 60_000;
    mine_heartbeat_slot(&mut ctx, 100, 1).await;
    ctx.simulated_time += 1_000;
    let draw = ctx.build_block_template(200, ctx.simulated_time);
    let draw_hash = draw.block.header.hash;
    let mut nonce = 300u64;
    for _ in 0..slots {
        ctx.simulated_time += hb::HEARTBEAT_RECOVERY_INTERVAL_MS;
        mine_heartbeat_slot(&mut ctx, nonce, 1).await;
        nonce += 16;
    }
    ctx.validate_and_insert_block(draw.block.clone().to_immutable()).await;
    let tips: Vec<BlockHash> = ctx.consensus.get_tips().into_iter().collect();
    assert_eq!(tips.len(), 3, "the slot's two heartbeats and the draw");
    let merger = ctx.consensus.services.ghostdag_manager.ghostdag(&tips);
    assert_eq!(merger.mergeset_size(), 3, "the merger's mergeset is its selected parent, the sibling and the draw");
    let store = ctx.consensus.ghostdag_store();
    // The draw sorts first (its blue work is its template's), so when it is colored the mergeset
    // holds one blue (the selected parent) and two candidates remain — `most_blues` = 1 + 2.
    let floor = (store.get_blue_score(merger.selected_parent).unwrap() + 3).saturating_sub(merge_depth);
    let ancestor = store.get_blue_score(store.get_selected_parent(draw_hash).unwrap()).unwrap();
    (merger.mergeset_blues.contains(&draw_hash), floor, ancestor)
}

/// **ADR-0105's exemption stops at the merge-depth window — the boundary, pinned on both sides.**
///
/// A classic blue is inside the window by construction, and `check_bounded_merge_depth` relies on
/// that: it checks reds against the merge-depth root and never blues. A candidate that ignores
/// heartbeats would otherwise have no depth bound at all — a bonded block withheld through a long
/// heartbeat-only stretch would be colored blue arbitrarily deep, and its coloring walk would run
/// back through every heartbeat to its parent, past a pruned node's pruning point if it were old
/// enough. So the walk has a floor, and the draw is blue exactly while its selected-chain ancestor
/// sits at or above it. Measured at the incident's eight slots, at the last slot count inside the
/// window and the first outside it, and with the fence dormant (red at every depth, as today).
#[tokio::test]
async fn the_fence_keeps_a_slow_draw_blue_only_inside_the_merge_depth_window() {
    kaspa_core::log::try_init_logger("info");
    for slots in [8u64, 13, 14] {
        let (blue, floor, ancestor) = color_of_a_slow_draw(true, slots).await;
        kaspa_core::info!("ADR-0105 window: {slots} slots -> blue={blue}, ancestor blue score {ancestor}, floor {floor}");
        assert_eq!(blue, ancestor >= floor, "{slots} slots: blue exactly when the draw's chain ancestor is at or above the floor");
    }
    let (inside, _, _) = color_of_a_slow_draw(true, 13).await;
    let (outside, _, _) = color_of_a_slow_draw(true, 14).await;
    assert!(inside && !outside, "at two heartbeats a slot the window is 13 slots (26 minutes): the boundary sits between 13 and 14");
    let (classic, _, _) = color_of_a_slow_draw(false, 8).await;
    assert!(!classic, "with the fence dormant the incident's eight slots already make it red");
}

/// **ADR-0105 Decision 2: a heartbeat miner that stands aside ends the mode — on the rule testnet-11
/// runs today, fence or no fence.**
///
/// The escape the operator used on 2026-09-10 was "stop every heartbeat miner for one draw". This
/// is that, done by the miner and bounded: when the chain runs on heartbeats and a bonded block is
/// waiting in the virtual's mergeset, the hint says so and a yielding miner does not mine. The
/// producer's next draw then lands on a tip nobody stacked ε on, becomes the sink, and the slot
/// rule's nominal hour holds the lane off again. Measured in both positions of the fence: without
/// it the first draw's work is still lost (red) but the chain comes back; with it the first draw is
/// kept too.
#[tokio::test]
async fn a_yielding_heartbeat_miner_hands_the_chain_back_to_the_next_draw() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::palw_heartbeat_v1::{self as hb, HeartbeatYieldHintV1};
    kaspa_core::log::try_init_logger("info");
    for transparent in [false, true] {
        let config = heartbeat_trap_config(transparent);
        let mut ctx = TestContext::new(TestConsensus::new(&config));
        for _ in 0..2 {
            ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
        }
        assert_eq!(
            ctx.consensus.virtual_processor().heartbeat_yield_hint(),
            HeartbeatYieldHintV1::BondedSelectedParent,
            "a producing chain: nothing to yield to, and the miner's budget is full"
        );
        let producing = ctx.consensus.get_sink();
        ctx.simulated_time =
            ctx.consensus.headers_store.get_header(producing).unwrap().timestamp + hb::HEARTBEAT_NOMINAL_INTERVAL_MS + 60_000;
        mine_heartbeat_slot(&mut ctx, 100, 1).await;
        assert_eq!(
            ctx.consensus.virtual_processor().heartbeat_yield_hint(),
            HeartbeatYieldHintV1::NothingToYieldTo,
            "on heartbeats with no bonded block waiting: the regime the lane exists for — tick"
        );

        // A slow draw, landing 17 minutes after its template, eight slots behind the tip.
        ctx.simulated_time += 1_000;
        let first = ctx.build_block_template(200, ctx.simulated_time);
        let mut nonce = 300u64;
        for _ in 0..8 {
            ctx.simulated_time += hb::HEARTBEAT_RECOVERY_INTERVAL_MS;
            mine_heartbeat_slot(&mut ctx, nonce, 1).await;
            nonce += 16;
        }
        ctx.simulated_time += 60_000;
        ctx.validate_and_insert_block(first.block.clone().to_immutable()).await;
        let first_hash = first.block.header.hash;
        assert_ne!(ctx.consensus.get_sink(), first_hash, "it lands behind the heartbeat tip");
        assert_eq!(
            ctx.consensus.virtual_processor().heartbeat_yield_hint(),
            HeartbeatYieldHintV1::YieldUntil(first.block.header.timestamp + hb::HEARTBEAT_NOMINAL_INTERVAL_MS),
            "a bonded block is waiting in the virtual's mergeset: yield until its hour is up"
        );

        // The producer's next draw starts now; the miners yield, so nothing lands for its 17 minutes.
        let second = ctx.build_block_template(nonce, ctx.simulated_time);
        assert!(second.block.header.direct_parents().contains(&first_hash), "it merges the draw that just landed");
        ctx.simulated_time += 17 * 60_000;
        ctx.validate_and_insert_block(second.block.clone().to_immutable()).await.assert_valid_utxo_tip();
        let second_hash = second.block.header.hash;
        assert_eq!(ctx.consensus.get_sink(), second_hash, "fence {transparent}: with nobody stacking ε, the next draw IS the sink");
        assert_eq!(ctx.consensus.virtual_processor().heartbeat_yield_hint(), HeartbeatYieldHintV1::BondedSelectedParent);
        let (_, earliest) = ctx
            .consensus
            .virtual_processor()
            .heartbeat_adapt_block_template(ctx.build_block_template(nonce + 1, ctx.simulated_time))
            .expect("the lane adapts");
        assert_eq!(
            earliest,
            second.block.header.timestamp + hb::HEARTBEAT_NOMINAL_INTERVAL_MS,
            "the mode is over: the slot rule holds the lane off for the nominal hour again"
        );

        // What happened to the FIRST draw's work depends on the fence, and only on the fence.
        let merged = ctx.consensus.ghostdag_store().get_data(second_hash).unwrap();
        assert_eq!(
            merged.mergeset_blues.contains(&first_hash),
            transparent,
            "fence {transparent}: the first draw is blue exactly when heartbeats stop counting against it"
        );
        assert_eq!(merged.mergeset_reds.contains(&first_hash), !transparent);
    }
}

/// **Unit C step 5: the header's committed state root is CHECKED, in both of the two ways a
/// wrong one can be wrong.**
///
/// A commitment nothing verifies is a field, not a commitment. Two refusals, and the first is the
/// stronger one:
///
/// 1. **Moving the root alone is refused at the door.** The root is in the PRE-PoW preimage, so
///    moving it moves `pre_pow_hash`, so the carried attempt's challenge is no longer the one its
///    header position derives. A block cannot claim a wrong root and keep a valid ticket.
/// 2. **Re-mining the ticket for the new position gets a valid block with a lying root**, and
///    that is what the chain-level check is for: it never becomes the sink. Asserted the way this
/// **One solve, unbounded blocks: the receipt lane inherited the attempt lane's shape without its fix.**
///
/// The proof-of-work pre-image EXCLUDES `palw_commitment` (`PalwCommitmentDigestRule::Exclude`,
/// hashing/header.rs) while the block identity includes it. `validate_stateless_v3` checks the
/// signature's LENGTH and recomputes the challenge — and the challenge commits to `pre_pow_hash`,
/// `timestamp` and `nonce`, not to the signature. So on a node that never verifies the bytes, any
/// solved receipt block can be re-signed with garbage, re-hashed, and re-announced as a different
/// block, for free, without redoing the work. Every peer accepts, stores and relays each one.
///
/// The attempt lane (algo 6) documents this attack verbatim ten lines above the receipt arm and
/// verifies `validate_signature_v2` against it. The receipt arm was written without the second
/// half. This test is the receipt lane's copy of that gate; deleting the `validate_signature_v3`
/// call in `check_palw_carriage_stateless` makes it pass a junk signature again.
#[tokio::test]
async fn palw_v3_a_receipt_carriage_with_a_junk_signature_is_refused_at_the_header() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();

    let honest = ctx.build_block_template(7, ctx.simulated_time + 1);

    // A receipt-lane header whose spend binds THIS position correctly and carries a signature of
    // the right length and no authority — exactly what the stateless list accepts.
    let mut forged = honest.block.clone();
    forged.header.pow_algo_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
    forged.header.palw_commitment = ctx.consensus.palw_v3_test_receipt_carriage(&forged.header, false);
    forged.header.finalize();

    match ctx.consensus.validate_and_insert_block(forged.to_immutable()).virtual_state_task.await {
        Err(kaspa_consensus_core::errors::block::RuleError::BadPalwCarriageAdmission { algo_id: 7, reason }) => {
            assert!(
                reason.to_lowercase().contains("signature"),
                "the refusal must NAME the signature — a receipt block refused for some other reason \
                 would let this test pass while the gate stayed unwired. got: {reason}"
            );
        }
        other => panic!("a receipt carriage with a junk signature must be refused at the header stage, got {other:?}"),
    }

    // **And the gate refuses the SIGNATURE, not the lane.** The same header with a real ML-DSA-87
    // signature over the same spend must get past this stage — it is refused later, on the stateful
    // facts (there is no such claim on this chain), and that is a different complaint. Without this
    // half, a test that merely rejected every algo-7 block would look identical to a working gate.
    let mut signed = honest.block.clone();
    signed.header.pow_algo_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
    signed.header.palw_commitment = ctx.consensus.palw_v3_test_receipt_carriage(&signed.header, true);
    signed.header.finalize();
    // Anything other than a signature complaint is out of this gate's scope and deliberately not
    // asserted. Measured while writing this: a correctly signed spend naming a claim this chain
    // does not hold is ACCEPTED as a block — the stateful admission (`palw_v2_check_receipt_spend`)
    // runs on the chain candidate, not on every insertion, so a receipt block that never becomes
    // chain is never asked about its claim. That is a separate question and must not be smuggled
    // into this test's assertions.
    if let Err(kaspa_consensus_core::errors::block::RuleError::BadPalwCarriageAdmission { algo_id: 7, reason }) =
        ctx.consensus.validate_and_insert_block(signed.to_immutable()).virtual_state_task.await
    {
        assert!(
            !reason.to_lowercase().contains("signature"),
            "a correctly signed spend must not be refused for its signature; got: {reason}"
        );
    }
}

/// **RFC-0009: a `PFS4` receipt header is a block only past `palw_receipt_spend_v4`, and past it both ML-DSA-87 signatures are checked at
/// the header stage.** Below the fence (every shipped preset) the carriage is refused BY NAME — the set of valid blocks is exactly what it was.
/// Past it a junk signature is refused for the signature (one solve, unbounded distinct blocks otherwise), and the same header with real
/// signatures gets past this stage.
#[tokio::test]
async fn rfc9_a_pfs4_receipt_header_is_refused_below_the_fence_and_signature_checked_past_it() {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::errors::block::RuleError;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    for armed in [false, true] {
        let config = ConfigBuilder::new(MAINNET_PARAMS)
            .skip_proof_of_work()
            .edit_consensus_params(|p| {
                p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
                *p = p.clone().with_palw_v2_cadence();
                if armed {
                    // The fence's prerequisites (`validate_palw_v2` refuses it without them), then the fence.
                    p.palw_audit_2026_09_11 = Some(ForkActivation::always());
                    p.palw_audit_2026_09_23 = Some(ForkActivation::always());
                    p.sync_palw_escrow_backed_exposure();
                    p.palw_receipt_spend_v4 = Some(ForkActivation::always());
                }
            })
            .build();
        let mut ctx = TestContext::new(TestConsensus::new(&config));
        // The audit fences the armed ruleset needs change what the fixture's first block must carry, and this test is about the HEADER stage
        // alone — so the armed run builds its candidates straight on genesis rather than mining a row first.
        if !armed {
            ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
        }
        let honest = ctx.build_block_template(7, ctx.simulated_time + 1);

        let mut signed = honest.block.clone();
        signed.header.pow_algo_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
        signed.header.palw_commitment = ctx.consensus.palw_v4_test_receipt_carriage(&signed.header, true);
        signed.header.finalize();
        let mut junk = honest.block.clone();
        junk.header.pow_algo_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
        junk.header.palw_commitment = ctx.consensus.palw_v4_test_receipt_carriage(&junk.header, false);
        junk.header.finalize();

        let verdict = |r: Result<_, RuleError>| match r {
            Err(RuleError::BadPalwCarriageAdmission { algo_id: 7, reason }) => Some(reason.to_lowercase()),
            _ => None,
        };
        let signed_verdict = verdict(ctx.consensus.validate_and_insert_block(signed.to_immutable()).virtual_state_task.await.map(|_| ()));
        let junk_verdict = verdict(ctx.consensus.validate_and_insert_block(junk.to_immutable()).virtual_state_task.await.map(|_| ()));
        if !armed {
            // Both refused, and for the fence — not for a signature and not for a size.
            for reason in [signed_verdict, junk_verdict] {
                let reason = reason.expect("a PFS4 header below the fence is refused");
                assert!(reason.contains("below") && reason.contains("palw_receipt_spend_v4"), "refused for the fence by name, got: {reason}");
            }
        } else {
            let reason = junk_verdict.expect("a junk-signed PFS4 header is refused past the fence");
            assert!(reason.contains("signature"), "refused for its signature, got: {reason}");
            if let Some(reason) = signed_verdict {
                assert!(!reason.contains("signature") && !reason.contains("below"), "real signatures get past this stage; got: {reason}");
            }
        }
    }
}

///    file's existing disqualification tests assert it — the sink does not move — because "did
///    not become the selected chain" is the property, and a status code is only its shadow.
#[tokio::test]
async fn a_block_committing_to_the_wrong_palw_state_root_is_disqualified() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let sink_before = ctx.consensus.get_sink();

    // The honest template commits to the parent's root — the state this chain really is at.
    let honest = ctx.build_block_template(7, ctx.simulated_time + 1);
    assert_ne!(honest.block.header.palw_state_root, kaspa_hashes::ZERO_HASH64, "a V2 template commits to a real root");

    // (1) Moving the commitment alone breaks the position binding.
    let mut liar = honest.block.clone();
    liar.header.palw_state_root = kaspa_hashes::Hash64::from_u64_word(0xBAD);
    liar.header.finalize();
    assert_ne!(liar.header.hash, honest.block.header.hash, "moving the commitment moves the identity");
    match ctx.consensus.validate_and_insert_block(liar.to_immutable()).virtual_state_task.await {
        Err(kaspa_consensus_core::errors::block::RuleError::BadPalwCarriageAdmission { algo_id: 6, .. }) => {}
        other => panic!("a moved state root must break the position binding, got {other:?}"),
    }

    // (2) A block that re-mines its ticket for the new position: valid carriage, lying root. It is
    //     a well-formed block, and it must never become the chain.
    let mut forger = honest.block.clone();
    forger.header.palw_state_root = kaspa_hashes::Hash64::from_u64_word(0xBAD);
    forger.header.palw_commitment = ctx.consensus.palw_v2_test_carriage(&forger.header);
    forger.header.finalize();
    let forger_hash = forger.header.hash;
    ctx.validate_and_insert_block(forger.to_immutable()).await;
    assert_ne!(forger_hash, sink_before);
    assert_eq!(ctx.consensus.get_sink(), sink_before, "a block whose committed root is not this chain's cannot become the sink");

    // …and the honest sibling, built the same way and differing only in the root, DOES advance the
    // chain — so the refusal is about the commitment and not about V2 blocks in general.
    let honest_hash = honest.block.header.hash;
    ctx.validate_and_insert_block(honest.block.to_immutable()).await;
    assert_eq!(ctx.consensus.get_sink(), honest_hash, "the honest commitment advances the chain");
}

/// **A template commits the selected parent's PALW root, not the store tip's** (testnet-11 2026-09-21).
///
/// `df80394b` was UTXO-valid and then disqualified from virtual: the producer stamped
/// `load_tip_cached().state_root()` while the validator compared the state reconstructed at the
/// candidate's selected parent. The two are the same block between rounds; they are not the same
/// block after an unclean shutdown, and the existing repair for that window only covered the
/// validating walk (`palw_v2_a_tip_that_does_not_stand_at_the_sink_is_re_derived`). That test had
/// to BUILD the template before moving the tip, "or it would corrupt the template's own state
/// root" — which is this bug, named as a test fixture constraint instead of a property.
#[tokio::test]
async fn palw_v2_a_template_commits_the_selected_parent_root_even_when_the_tip_does_not_stand_there() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor().clone();
    let (sink, sink_state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let expected_root = sink_state.state_root();
    let parent = vp.ghostdag_store.get_selected_parent(sink).expect("the sink has a selected parent");
    let parent_state = {
        let store = vp.palw_state_v2_store.read();
        let (_, delta) = store.delta_of(sink).expect("the sink has a delta");
        kaspa_consensus_core::palw_state_v2::revert_delta_v2(&sink_state, &delta, &bundle.state)
            .expect("reverting the sink's own delta yields its parent's state")
    };
    let parent_root = parent_state.state_root();
    assert_ne!(parent_root, expected_root, "the fixture is vacuous unless parent and sink hash to different roots");

    // The crash window: PALW tip stands one block BEHIND the sink, which is the next template's
    // selected parent. Stamping the store tip would write `parent_root`; the validator will
    // compare `expected_root`.
    vp.palw_state_v2_store.write().set_tip_for_tests(parent, &parent_state).unwrap();
    assert_eq!(vp.palw_state_v2_store.read().tip_record().unwrap().unwrap().block, parent);

    let template = ctx.build_block_template(7, ctx.simulated_time + 1);
    assert_eq!(
        template.block.header.palw_state_root, expected_root,
        "the template must commit the selected parent's state, which is the sink, not the store tip"
    );
    assert_ne!(template.block.header.palw_state_root, parent_root, "stamping the store tip is the df80394b producer/validator split");
}

/// **Unit C step 4: the beacon is derived from the candidate's chain, and a block cannot name
/// its own.**
///
/// This is the property the wiring note calls out by name — "a fact taken from the spending
/// block's own bytes would be the producer asserting its own randomness". The receipt lane's right
/// to spend a quantum is a DRAW, so whoever picks the beacon picks the winner.
///
/// Asserted at the derivation, which is where the property lives: the same slot walked from two
/// different starting points on ONE chain yields the same fact, and the fact names a block the
/// walk found rather than one anybody supplied. The end-to-end spend path additionally needs a
/// certified free-prompt claim on chain, which needs the FP worker's legs capture (see
/// `docs/palw-fp-wiring-atomicity.md`) — until then the pipeline's arm is exercised by the
/// derivation it calls, and by every V2 block going through it with no receipt lane in play.
#[tokio::test]
async fn the_beacon_fact_comes_from_the_chain_not_from_the_block() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            // Six chain blocks is six concurrent claims; the default bond backs four. Funded for
            // the chain it mines — see `palw_v2_test_bundle_funded_for`.
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle_funded_for(&catalog, 16));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..6 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();
    let sink_header = vp.headers_store.get_header(sink).unwrap();
    let sink_daa = sink_header.daa_score;

    // Every block this harness mines is attempt-class (algo 6), so every DAA at or below the sink
    // has a beacon and the fact's own witness must sit strictly below the slot.
    for slot in 0..=sink_daa {
        let fact = vp.palw_beacon_fact_of_candidate(sink, slot).expect("a chain of attempt blocks has a beacon for every slot");
        assert!(fact.beacon_daa >= slot, "the beacon is at or after the slot it draws for");
        assert!(
            fact.prev_attempt_daa < slot || (slot == 0 && fact.prev_attempt_daa == 0),
            "the witness is the last attempt block strictly below the slot: slot {slot}, witness {}",
            fact.prev_attempt_daa
        );
        // The named block is one this chain really contains, at the DAA the fact claims.
        let header = vp.headers_store.get_header(fact.beacon_block).expect("the beacon names a block on this chain");
        assert_eq!(header.daa_score, fact.beacon_daa);
    }

    // The derivation is a function of the CHAIN, not of the walker's position: walking from the
    // sink and from the sink's own parent agree wherever both can see the answer. Two nodes with
    // different sinks on one candidate therefore draw the same beacon, which is the whole point.
    let parent = vp.headers_store.get_header(sink).unwrap().direct_parents()[0];
    let parent_daa = vp.headers_store.get_header(parent).unwrap().daa_score;
    for slot in 0..=parent_daa {
        assert_eq!(
            vp.palw_beacon_fact_of_candidate(sink, slot).unwrap(),
            vp.palw_beacon_fact_of_candidate(parent, slot).unwrap(),
            "slot {slot}: the fact is the chain's, not the walker's"
        );
    }

    // A slot past the tip has no beacon yet, and that is a REFUSAL rather than a zero. A
    // derivation that invented one would be a draw nobody made.
    let err = vp.palw_beacon_fact_of_candidate(sink, sink_daa + 1).unwrap_err();
    assert!(matches!(err, kaspa_consensus_core::palw_fp_beacon_v3::PalwBeaconDeriveV3Error::NoBeaconYet { .. }), "got {err:?}");
}

/// **ADR-0073 SA-1: the armed fence reaches the derivation, and the beacon becomes a FOLD.**
///
/// The pure derivation is pinned in `palw_fp_beacon_v3`'s own tests; what only the pipeline can
/// say is that the fence is actually resolved here — a rule whose value never reaches the walk is
/// a rule nobody runs. So the expectation below is rebuilt from the HEADER STORE rather than from
/// the derivation being tested: the first `k` attempt blocks at or after each slot, folded in
/// ascending chain order.
#[tokio::test]
async fn the_armed_beacon_fence_folds_the_first_k_attempt_blocks() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::config::params::{ForkActivation, PalwBeaconFoldV1};
    use kaspa_consensus_core::palw_fp_beacon_v3::{PALW_BEACON_FOLD_MIN_K_V1, PalwBeaconDeriveV3Error};
    use kaspa_consensus_core::palw_freeprompt_v3::fp_beacon_fold_v3;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let k = PALW_BEACON_FOLD_MIN_K_V1;
    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle_funded_for(&catalog, 16));
            // Armed from genesis, which no shipped preset does — that is the whole point of the
            // fence, and `the_beacon_fact_comes_from_the_chain_not_from_the_block` beside this one
            // is the fence-off half of the pair.
            p.palw_beacon_fold = Some(PalwBeaconFoldV1 { activation: ForkActivation::always(), k });
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..8 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();
    let sink_daa = vp.headers_store.get_header(sink).unwrap().daa_score;
    let attempt_algo = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_COMMITTED_V2;

    // The chain's attempt blocks, ASCENDING — read straight from the store, so the expectation
    // owes nothing to the code under test.
    let mut attempts: Vec<(u64, kaspa_hashes::Hash64)> = vp
        .reachability_service
        .default_backward_chain_iterator(sink)
        .filter_map(|block| {
            let header = vp.headers_store.get_header(block).ok()?;
            (header.pow_algo_id == attempt_algo).then_some((header.daa_score, block))
        })
        .collect();
    attempts.reverse();
    assert!(attempts.len() > k as usize, "the fixture must mine more attempt blocks than the fold is wide");

    let mut folded = 0usize;
    let mut refused = 0usize;
    for slot in 0..=sink_daa + 1 {
        let window: Vec<(u64, kaspa_hashes::Hash64)> =
            attempts.iter().copied().filter(|(daa, _)| *daa >= slot).take(k as usize).collect();
        match vp.palw_beacon_fact_of_candidate(sink, slot) {
            Ok(fact) => {
                assert_eq!(window.len(), k as usize, "slot {slot} drew with only {} attempt blocks above it", window.len());
                let hashes: Vec<kaspa_hashes::Hash64> = window.iter().map(|(_, block)| *block).collect();
                assert_eq!(fact.beacon_block, fp_beacon_fold_v3(&hashes), "slot {slot}: the fold is not over the first {k}");
                assert_eq!(fact.beacon_daa, window[k as usize - 1].0, "slot {slot}: the fact must date from the k-th block");
                // The witness still pins where the fold starts, so the pair of inequalities a
                // non-walker checks is unchanged.
                assert!(fact.prev_attempt_daa < slot || slot == 0, "slot {slot}: witness {}", fact.prev_attempt_daa);
                // …and the beacon is no longer any single block of this chain: it is a digest.
                assert!(
                    !attempts.iter().any(|(_, block)| *block == fact.beacon_block),
                    "slot {slot}: a folded beacon must not name one block"
                );
                folded += 1;
            }
            Err(e) => {
                assert!(
                    matches!(e, PalwBeaconDeriveV3Error::NoBeaconYet { needed, found, .. } if needed == k && (found as usize) == window.len()),
                    "slot {slot}: a slot short of the fold is NOT-YET-DRAWN and says how short: {e:?}"
                );
                assert!(window.len() < k as usize, "slot {slot} refused with a full window");
                refused += 1;
            }
        }
    }
    assert!(folded > 0 && refused >= k as usize, "the sweep must exercise both arms: {folded} folded, {refused} refused");

    // The fact is the CHAIN's, not the walker's, under the fold too: two starting points on one
    // candidate agree wherever both can see the answer.
    let parent = vp.headers_store.get_header(sink).unwrap().direct_parents()[0];
    let parent_daa = vp.headers_store.get_header(parent).unwrap().daa_score;
    for slot in 0..=parent_daa {
        if let Ok(from_parent) = vp.palw_beacon_fact_of_candidate(parent, slot) {
            assert_eq!(
                vp.palw_beacon_fact_of_candidate(sink, slot).unwrap(),
                from_parent,
                "slot {slot}: a complete fold must not move when the chain grows past it"
            );
        }
    }
}

/// **Unit D: one authority, and it is the candidate's — not the sink's.**
///
/// The order is what the IBD commit, the pruning ceiling and the deep-reorg gate all compare, so
/// the property that matters is that it is a function of the CANDIDATE. An order that answered
/// the same thing for every candidate would be a constant, and a constant authority is no
/// authority — every contest would fall through to whatever ran next.
#[tokio::test]
async fn the_palw_candidate_order_is_the_candidates_own() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();
    let parent = vp.headers_store.get_header(sink).unwrap().direct_parents()[0];

    let sink_order = vp.palw_candidate_order_v2(sink).expect("a V2 network orders its own sink");
    let parent_order = vp.palw_candidate_order_v2(parent).expect("and any candidate on its chain");
    // Each order names the candidate it is about. Without this key the comparator would not be
    // total, and two candidates equal in every weight would compare `Equal` — each node keeping
    // whichever it happened to hold.
    assert_eq!(sink_order.candidate, sink);
    assert_eq!(parent_order.candidate, parent);
    assert_ne!(sink_order, parent_order, "the order is the candidate's, not a constant");
    // `live_total >= safe_weight` is a type-level invariant of the constructor, asserted here on
    // real chain data rather than on a fixture.
    assert!(sink_order.live_total >= sink_order.safe_weight);

    // A network with no V2 bundle has no order at all — the three consumers fall through to what
    // they did before, which is what keeps every shipped preset unchanged.
    let plain = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let plain_consensus = TestConsensus::new(&plain);
    let _lt = plain_consensus.init();
    let plain_sink = plain_consensus.get_sink();
    assert!(
        plain_consensus.virtual_processor().palw_candidate_order_v2(plain_sink).is_none(),
        "no bundle, no order — the authority is absent rather than defaulted"
    );
    // …and its pruning ceiling is trivially satisfied, so pruning is unchanged there.
    assert!(plain_consensus.virtual_processor().palw_pruning_point_allowed_v2(plain_sink));
}

/// **Unit D, site 1: the tip order is the PALW authority, and the DAG agrees with it.**
///
/// Wiring tip selection is the site that fought back twice, and both fights were the same fact:
/// GHOSTDAG's `find_selected_parent` is `max by blue_work`, and `pick_virtual_parents` ASSERTS
/// that the sink the search chose is that maximum. A sink ordered by PALW weight and a DAG whose
/// selected parent is ordered by blue work are two canonical chains inside one node — the P0-5
/// this unit exists to close, arriving through the floor.
///
/// The repair is to keep that assumption TRUE rather than to weaken the assert: under the PALW
/// order, virtual parent candidates heavier than the sink are filtered out. It costs liveness
/// (virtual merges fewer tips this round; the excluded ones stay in the DAG) and not safety.
///
/// This pins the invariant on a real V2 chain, and pins the scoping too: applying the filter
/// unconditionally broke two blue-work tests, because there the sink IS the maximum and `<` also
/// drops the equal-work siblings virtual is supposed to merge.
#[tokio::test]
async fn palw_v2_sink_is_the_blue_work_maximum_of_its_virtual_parents() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use crate::model::stores::virtual_state::VirtualStateStoreReader;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::sortable_block::SortableBlock;

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            // Five wide rows is five chain blocks, so five concurrent claims — one more than the
            // bundle's default bond can back. Funded for the chain it mines; see the fixture.
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle_funded_for(&catalog, 16));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    assert!(config.params.palw_fork_choice.is_none(), "a V2 network sets no V1 fork-choice fence");

    // Wide rows, so virtual really has competing parents to choose among — a single-tip chain
    // would satisfy the invariant vacuously.
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..5 {
        ctx.build_block_template_row(0..3).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();
    let virtual_parents = vp.virtual_stores.read().state.get().unwrap().parents.clone();
    assert!(virtual_parents.contains(&sink), "the sink is one of virtual's parents");
    // **The invariant is GHOSTDAG's OWN key, which is `SortableBlock` — `(blue_work, hash)`.**
    //
    // This asserted strictly-lower blue work, which is stronger than the rule and therefore wrong
    // in the merge-narrowing direction: `find_selected_parent` is `max()` over `SortableBlock`, so
    // an equal-work parent whose hash sorts BELOW the sink's cannot be selected over it and is a
    // perfectly legal virtual parent. Demanding strict `<` forced the filter that dropped exactly
    // those siblings on every block of the only lineage that ships V2 (launch blockers §7).
    let sink_sortable = SortableBlock { hash: sink, blue_work: vp.ghostdag_store.get_blue_work(sink).unwrap() };
    for parent in &virtual_parents {
        if *parent == sink {
            continue;
        }
        let parent_sortable = SortableBlock { hash: *parent, blue_work: vp.ghostdag_store.get_blue_work(*parent).unwrap() };
        assert!(
            parent_sortable < sink_sortable,
            "virtual parent {parent} out-ranks the sink under GHOSTDAG's own key — it would be selected, not the sink"
        );
    }
    // And the consequence stated directly, so the invariant is pinned by the rule it protects
    // rather than by a proxy for it.
    assert_eq!(
        vp.ghostdag_manager.find_selected_parent(virtual_parents.iter().copied()),
        sink,
        "GHOSTDAG selects the sink out of virtual's parent set"
    );
}

/// **Two submitters racing the same claim must not kill the block that carries both** (testnet-12,
/// 2026-08-22).
///
/// One funded submitter per network suffices, so several MAY be funded — and when they are, two
/// nodes independently assemble the same quorum and both submit. Both objects are valid against
/// the parent state, so a filter that judges each one there lets both through; the transition then
/// applies them in order and refuses the second as `wrong phase for ReceiptLicensed`, taking the
/// honest block with it. Measured: 175 blocks produced, 23 accepted, 74 disqualified, DAA frozen
/// while three hosts submitted correctly.
///
/// The filter must ask the question the transition will ask, which means folding each accepted
/// object in before judging the next.
#[tokio::test]
async fn a_duplicate_lifecycle_object_is_dropped_and_the_block_stands() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_panel_v2::{
        PALW_RECEIPT_V2_MLDSA87_CONTEXT, PalwReceiptVerdictV2, PalwSeatReceiptV2, palw_receipt_message_v2,
    };
    use kaspa_consensus_core::palw_state_v2::{PalwClaimPhaseV2, PalwConsensusObjectV2};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..26 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let (claim_id, _) =
        state.claims_iter().find(|(_, c)| matches!(c.phase, PalwClaimPhaseV2::PanelBound { .. })).expect("a bound claim");
    let claim_id = *claim_id;
    let panel = state.panel(&claim_id).expect("a bound claim has a panel");
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );
    let signed_daa = ctx.consensus.get_virtual_daa_score();

    let receipts: Vec<PalwSeatReceiptV2> = panel
        .seats
        .iter()
        .take(3)
        .map(|seat| {
            let bond = state.bond(&seat.bond).expect("registered");
            let kp = (0..16u64)
                .map(TestConsensus::palw_v2_registry_keypair)
                .find(|kp| kp.verification_key.as_ref() == bond.pubkey.as_slice())
                .expect("a registry key");
            let message = palw_receipt_message_v2(network_domain, claim_id, PalwReceiptVerdictV2::Valid, signed_daa);
            let signature =
                libcrux_ml_dsa::ml_dsa_87::sign(&kp.signing_key, message.as_byte_slice(), PALW_RECEIPT_V2_MLDSA87_CONTEXT, [0u8; 32])
                    .expect("sign")
                    .as_ref()
                    .to_vec();
            PalwSeatReceiptV2 { claim: claim_id, verdict: PalwReceiptVerdictV2::Valid, seat_bond: seat.bond, signed_daa, signature }
        })
        .collect();

    let object = PalwConsensusObjectV2::ReceiptLicensed { claim: claim_id, receipts };
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: signed_daa,
        blue_score: 27,
        subsidy: 0,
    };

    // What two racing submitters put in one block: the same valid object, twice.
    let accepted = vp.palw_v2_accepted_objects_for_tests(
        &state,
        &bundle.state,
        &point,
        vec![object.clone(), object.clone()],
        ctx.consensus.get_sink(),
    );
    assert_eq!(accepted.len(), 1, "the duplicate is dropped as an OBJECT — the block must not die for carrying it");

    // And the one that survived is applicable, which is the property the filter exists to give the
    // transition: what it returns, the fold takes.
    kaspa_consensus_core::palw_state_v2::apply_palw_transition_v2(&state, &bundle.state, &point, &accepted, None)
        .expect("what the filter accepts, the transition applies");

    // **And the fold must not eat the objects that are NOT duplicates.** The first version of this
    // filter re-applied at the block's own chain point, which the transition accepts exactly once
    // (it demands a strictly increasing blue score) — so every object after the first was dropped
    // with `blue_score must strictly increase`, whatever claim it named. The chain then produced
    // blocks, accepted submissions and licensed nothing: 356 blocks, 72 submissions, weight zero.
    let mut many: Vec<PalwConsensusObjectV2> = Vec::new();
    for (id, claim) in state.claims_iter() {
        if !matches!(claim.phase, PalwClaimPhaseV2::PanelBound { .. }) {
            continue;
        }
        let Some(p) = state.panel(id) else { continue };
        let rs: Vec<PalwSeatReceiptV2> = p
            .seats
            .iter()
            .take(3)
            .map(|seat| {
                let bond = state.bond(&seat.bond).expect("registered");
                let kp = (0..16u64)
                    .map(TestConsensus::palw_v2_registry_keypair)
                    .find(|kp| kp.verification_key.as_ref() == bond.pubkey.as_slice())
                    .expect("a registry key");
                let message = palw_receipt_message_v2(network_domain, *id, PalwReceiptVerdictV2::Valid, signed_daa);
                let signature = libcrux_ml_dsa::ml_dsa_87::sign(
                    &kp.signing_key,
                    message.as_byte_slice(),
                    PALW_RECEIPT_V2_MLDSA87_CONTEXT,
                    [0u8; 32],
                )
                .expect("sign")
                .as_ref()
                .to_vec();
                PalwSeatReceiptV2 { claim: *id, verdict: PalwReceiptVerdictV2::Valid, seat_bond: seat.bond, signed_daa, signature }
            })
            .collect();
        many.push(PalwConsensusObjectV2::ReceiptLicensed { claim: *id, receipts: rs });
        if many.len() == 3 {
            break;
        }
    }
    assert!(many.len() >= 2, "the fixture must offer at least two distinct bound claims, got {}", many.len());
    let all = vp.palw_v2_accepted_objects_for_tests(&state, &bundle.state, &point, many.clone(), ctx.consensus.get_sink());
    assert_eq!(all.len(), many.len(), "distinct claims must all survive the fold — only duplicates are dropped");
    kaspa_consensus_core::palw_state_v2::apply_palw_transition_v2(&state, &bundle.state, &point, &all, None)
        .expect("and the whole accepted set applies in one block");
}

/// **ADR-0064 — the bootstrap registry is the one the transition will have, not the one the
/// object list looks like.**
///
/// The rule lets a chain block's own attempt name a bond that this block's ACCEPTED objects
/// register — the registration riding a transaction in the selected parent's body or a merged
/// block's, never in this block's own body, which is why it buys a joining producer one chain
/// block and does not restart a stopped chain (ADR-0064's correction). The bond it resolves
/// against therefore has to be the registry the transition will hold after it folds those
/// objects — and the cheap way to write that lookup, scanning the object list for the first
/// matching `BondRegistered`, is a DIFFERENT question with a different answer.
///
/// It differs exactly when the block touches the bond again. A mergeset carrying a registration
/// and then a retirement for the same bond leaves it `Retiring`; the first-object reading says
/// `Active`, and admission item 1 refuses `Retiring`. One reading admits the block, the other
/// refuses it, and the whole of ADR-0064 is the removal of a disagreement of precisely that shape.
///
/// Both readings are exercised: the registration alone (where they agree, so a broken lookup still
/// passes) and the registration followed by a retirement (where they cannot).
#[tokio::test]
async fn palw_v2_the_bootstrap_registry_is_the_state_the_transition_will_hold() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_BOND_REGISTRATION_V2_MLDSA87_CONTEXT, PALW_BOND_RETIREMENT_V2_MLDSA87_CONTEXT, PalwBondKeyV2, PalwBondStatusV2,
        PalwConsensusObjectV2, palw_bond_registration_message_v2, palw_bond_retirement_message_v2,
    };
    use kaspa_consensus_core::tx::{TransactionId, TransactionOutpoint};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );

    // A newcomer: an ML-DSA-87 identity past the genesis registry's rows, and a registration
    // outpoint the chain has never accepted. This is the party ADR-0064 exists for.
    let kp = TestConsensus::palw_v2_registry_keypair(40);
    let pubkey = kp.verification_key.as_ref().to_vec();
    let operator_pubkey = vec![0x64u8; 8];
    let bond = PalwBondKeyV2(TransactionOutpoint::new(TransactionId::default(), 640));
    let collateral = bundle.bond.min_collateral_sompi();
    let payout_payload = kaspa_hashes::Hash64::from_u64_word(0x9A11);
    let sign = |message: kaspa_hashes::Hash64, context: &[u8]| {
        libcrux_ml_dsa::ml_dsa_87::sign(&kp.signing_key, message.as_byte_slice(), context, [0u8; 32]).expect("sign").as_ref().to_vec()
    };
    let registered = PalwConsensusObjectV2::BondRegistered {
        bond,
        pubkey: pubkey.clone(),
        operator_pubkey: operator_pubkey.clone(),
        collateral,
        payout_payload,
        capable_classes: Default::default(),
        signature: sign(
            palw_bond_registration_message_v2(
                network_domain,
                &bond,
                &pubkey,
                &operator_pubkey,
                collateral,
                &payout_payload,
                &Default::default(),
            ),
            PALW_BOND_REGISTRATION_V2_MLDSA87_CONTEXT,
        ),
    };

    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 5,
        subsidy: 0,
    };
    assert!(state.bond(&bond).is_none(), "the parent chain has never seen this bond — that IS the deadlock");

    // The registration alone. Both readings agree here, which is why this case cannot be the whole
    // test: it is the one a first-object lookup also passes.
    let (accepted, folded) = vp.palw_v2_accepted_objects_and_state_for_tests(
        &state,
        &bundle.state,
        &point,
        vec![registered.clone()],
        ctx.consensus.get_sink(),
    );
    assert_eq!(accepted.len(), 1, "an honest registration is accepted: {accepted:?}");
    let fresh = folded.bond(&bond).expect("ADR-0064's whole point: the block's own mergeset registers it");
    assert_eq!(fresh.status, PalwBondStatusV2::Active);
    assert_eq!(fresh.pubkey, pubkey, "and it is the newcomer's key, so item 2 still has something to compare");
    assert_eq!(fresh.registered_daa, point.daa_score, "registered AT this block, which is what a maturity rule would measure from");

    // Registration then retirement, one mergeset. The transition leaves the bond `Retiring`; the
    // reading this test exists to forbid would have answered `Active`.
    let retired = PalwConsensusObjectV2::BondRetireRequested {
        bond,
        signature: sign(palw_bond_retirement_message_v2(network_domain, &bond), PALW_BOND_RETIREMENT_V2_MLDSA87_CONTEXT),
    };
    let (accepted, folded) = vp.palw_v2_accepted_objects_and_state_for_tests(
        &state,
        &bundle.state,
        &point,
        vec![registered, retired],
        ctx.consensus.get_sink(),
    );
    assert_eq!(accepted.len(), 2, "both objects are valid in sequence — neither is dropped: {accepted:?}");
    let after = folded.bond(&bond).expect("still registered, just on its way out");
    assert!(
        matches!(after.status, PalwBondStatusV2::Retiring { .. }),
        "the registry the transition will hold says Retiring; reading the first BondRegistered off the \
         list would have said Active, and admission treats those two answers oppositely: {:?}",
        after.status
    );

    // And that difference is load-bearing: item 1 refuses a retiring bond, so the two readings
    // disagree about whether this block may produce at all.
    let attempt = kaspa_consensus_core::palw_attempt_v2::PalwAttemptUnsignedV2 {
        version: 1,
        network_domain,
        challenge: kaspa_hashes::Hash64::from_u64_word(0),
        class_id: kaspa_hashes::Hash64::from_u64_word(0),
        executor_bond: bond.0,
        executor_pubkey: pubkey,
        operator_id: kaspa_consensus_core::palw_state_v2::palw_operator_id_v2(&operator_pubkey),
        artifact_root: kaspa_hashes::Hash64::from_u64_word(0),
        trace_root: kaspa_hashes::Hash64::from_u64_word(0),
        output_root: kaspa_hashes::Hash64::from_u64_word(0),
        pwu: 1,
        trace_manifest_root: kaspa_hashes::Hash64::from_u64_word(0),
        trace_chunk_count: 1,
        trace_retention_daa: 0,
        execution_root: kaspa_hashes::Hash64::from_u64_word(0),
    };
    let err = kaspa_consensus_core::palw_admission_v2::check_palw_producer_entitlement_v2_with_bootstrap(
        &state,
        &attempt,
        folded.bond(&bond),
    )
    .expect_err("a bond this block itself put into retirement may not also produce under it");
    assert!(
        matches!(err, kaspa_consensus_core::palw_admission_v2::PalwAdmissionV2Error::BondRetiring(k) if k == bond),
        "refused for the retirement, which is the fact the folded registry carries and the object list does not: {err:?}"
    );
}

/// **A merged blue is paid only if this chain can show its producer is bonded** (launch blockers
/// §8, first bullet).
///
/// The subsidy pays for PALW work, but the stateful half of admission runs only on the selected
/// chain — so every other merged blue in the DAA window was paid its full worker share without the
/// chain ever asking whether the key that signed it belongs to a live bond. A miner with no bond
/// at all collected on a solved hash.
///
/// Both directions, because a filter that refuses everything would also make the first assertion
/// pass: the honest chain's blues are all entitled and all paid, and the predicate that decides it
/// really does refuse an attempt whose bond this chain does not hold.
#[tokio::test]
async fn palw_v2_an_unbonded_merged_blue_is_not_paid() {
    use crate::model::stores::daa::DaaStoreReader;
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 16);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..2).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor().clone();
    let sink = ctx.consensus.get_sink();
    let ghostdag_data = vp.ghostdag_store.get_data(sink).unwrap();
    assert!(ghostdag_data.mergeset_blues.len() > 1, "the fixture must merge a blue besides the selected parent");
    let non_daa = vp.daa_excluded_store.get_mergeset_non_daa(sink).unwrap();

    // The state AT the sink's selected parent — the one the coinbase is computed against.
    let (tip_block, tip_state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert_eq!(tip_block, sink, "the walk left the tip at the sink");
    let parent_state = {
        let store = vp.palw_state_v2_store.read();
        let (_, delta) = store.delta_of(sink).expect("the sink has a delta");
        kaspa_consensus_core::palw_state_v2::revert_delta_v2(&tip_state, &delta, &bundle.state).expect("the sink's delta reverts")
    };

    // The sink's own evaluation point — the one its transition ran at, and therefore the one the
    // payment gate must ask the admission at (audit3 S-04).
    let sink_header = vp.headers_store.get_header(sink).expect("the sink's header");
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: sink,
        daa_score: sink_header.daa_score,
        blue_score: sink_header.blue_score,
        subsidy: vp.coinbase_manager.calc_block_subsidy(sink_header.daa_score),
    };

    // Honest chain: nothing is withheld. A filter that dropped an honest miner's subsidy would be
    // a worse bug than the one it closes.
    let unentitled = vp.palw_v2_unentitled_blues(&parent_state, &ghostdag_data, &non_daa, &point);
    assert!(unentitled.is_empty(), "every blue of an honest V2 chain is bonded and paid, got {unentitled:?}");

    // And the predicate really separates: the same attempt, naming a bond this chain does not hold.
    let blue = *ghostdag_data
        .mergeset_blues
        .iter()
        .find(|h| **h != ghostdag_data.selected_parent && !non_daa.contains(h))
        .expect("a merged blue that is not the selected parent");
    let header = vp.headers_store.get_header(blue).expect("the blue's header");
    let envelope = PalwAttemptEnvelopeV2::decode_wire(&header.palw_commitment).expect("a V2 block carries an attempt");
    kaspa_consensus_core::palw_admission_v2::check_palw_producer_entitlement_v2(&parent_state, &envelope.attempt)
        .expect("the real attempt is entitled");
    let mut forged = envelope.attempt.clone();
    forged.executor_bond = kaspa_consensus_core::tx::TransactionOutpoint {
        transaction_id: kaspa_consensus_core::tx::TransactionId::from_u64_word(0xDEAD),
        index: 7,
    };
    assert!(
        kaspa_consensus_core::palw_admission_v2::check_palw_producer_entitlement_v2(&parent_state, &forged).is_err(),
        "an attempt naming a bond this chain does not hold is not entitled to the subsidy"
    );
}

/// **An unclean shutdown between the PALW tip batch and the virtual-state commit is repaired, not
/// fatal** (launch blockers §7, fourth bullet).
///
/// The tip row carries the whole registry as a carriage, so it is written once at the end of the
/// UTXO walk rather than in each block's batch — which means there is a window where the tip has
/// landed and the sink has not. The walk used to take the tip's state verbatim as the state at its
/// own starting point; in that window the two are different blocks, `revert_delta_v2` rejected the
/// value it was asked to replace, and the `.expect` around it panicked on every start from then on.
///
/// Both legs are exercised: the pipeline recovers when the tip trails the sink, and the revert leg
/// — the shape the crash window actually produces — is walked directly.
#[tokio::test]
async fn palw_v2_a_tip_that_does_not_stand_at_the_sink_is_re_derived() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor().clone();
    let (tip_block, tip_state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let parent = vp.ghostdag_store.get_selected_parent(tip_block).expect("the tip has a selected parent");
    let parent_state = {
        let store = vp.palw_state_v2_store.read();
        let (_, delta) = store.delta_of(tip_block).expect("the tip has a delta");
        kaspa_consensus_core::palw_state_v2::revert_delta_v2(&tip_state, &delta, &bundle.state)
            .expect("reverting the tip's own delta yields its parent's state")
    };

    // The revert leg, walked directly: this is the shape the crash window leaves — the tip standing
    // one block AHEAD of where the next walk starts.
    {
        let store = vp.palw_state_v2_store.read();
        let rederived =
            crate::processes::palw_state_walk::walk_chain_path(&store, &bundle.state, tip_state.clone(), &[tip_block], &[])
                .expect("the path from the tip back to the sink walks");
        assert_eq!(rederived.state_root(), parent_state.state_root(), "the re-derived state is the state at the sink");
    }

    // The apply leg, through the real pipeline. The template is built BEFORE the tip is moved,
    // which is what the crash window really looks like for VALIDATION: the block on the wire is
    // honest and commits the right root — it is this node's own tip row that no longer stands
    // where the walk starts. (The producer-side twin — a template built AFTER the tip moved —
    // is `palw_v2_a_template_commits_the_selected_parent_root_even_when_the_tip_does_not_stand_there`.)
    ctx.build_block_template_row(0..1);
    vp.palw_state_v2_store.write().set_tip_for_tests(parent, &parent_state).unwrap();
    assert_eq!(vp.palw_state_v2_store.read().tip_record().unwrap().unwrap().block, parent, "the tip really moved");

    // Before the repair this panicked inside `calculate_utxo_state_relatively` on this insert.
    ctx.validate_and_insert_row().await.assert_valid_utxo_tip();

    let (recovered_block, recovered_state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert_eq!(recovered_block, ctx.consensus.get_sink(), "the tip is back at the sink");
    assert_ne!(recovered_block, parent, "and the chain advanced rather than stalling");
    let expected = {
        let store = vp.palw_state_v2_store.read();
        let (_, delta) = store.delta_of(recovered_block).expect("the new tip has a delta");
        let (_, prev_delta) = store.delta_of(tip_block).expect("the old tip has a delta");
        let at_old = kaspa_consensus_core::palw_state_v2::apply_delta_v2(&parent_state, &prev_delta, &bundle.state).unwrap();
        kaspa_consensus_core::palw_state_v2::apply_delta_v2(&at_old, &delta, &bundle.state).unwrap()
    };
    assert_eq!(recovered_state.state_root(), expected.state_root(), "and it is the state the deltas fold to");
}

/// **The V2 sink-search heap carries no PALW key, and the deep-reorg gate carries all of it**
/// (launch blockers §7, first bullet).
///
/// The wedge this pins: `palw_candidate_order_v2` derives a candidate's standing by walking stored
/// deltas, and `commit_utxo_state` writes a delta only for a block already committed to the
/// selected chain. Feeding that into `order_tips_v1` — which ranks `Some` above `None` — makes
/// "weighable" mean "already mine", so the incumbent outranks every challenger by construction. A
/// node whose own branch stalls then never reorgs again, and one privately-delivered block puts a
/// chosen victim in that state.
///
/// Two halves, and the test is only worth something with both: the heap key is gone, AND the
/// authority still exists at the site that can evaluate it.
#[tokio::test]
async fn palw_v2_tip_heap_has_no_weight_key_but_the_gate_does() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle_funded_for(&catalog, 16));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();

    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..2).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();
    // Half one is structural: the sink search's heap holds `SortableBlock`s, GHOSTDAG's own key,
    // so there is no PALW rank the incumbent could be preferred by.

    // Half two: the authority did not evaporate with it. The sink IS weighable — the gate runs
    // after UTXO validation, which is the first moment both sides of a reorg comparison are.
    assert!(vp.palw_candidate_order_v2(sink).is_some(), "the deep-reorg gate must still be able to weigh a validated chain");
}

/// **ADR-0042 Decision 6: attempt admission runs on the live path, and every clause bites.**
///
/// The pure function was tested; what this asserts is that the PIPELINE calls it — and it is
/// worth a test of its own because wiring it is what proved the harness had been mining blocks no
/// chain would admit. Before this the fixture carried a hand-written operator id, a chosen `pwu`,
/// a losing class ticket and a bond with a tenth of the collateral its own claim reserves. Each
/// of those is a real rule, and each refused every block until the harness was made to do what a
/// miner does.
#[tokio::test]
async fn palw_v2_attempt_admission_runs_on_the_live_path() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    // The genesis list is the only place a V2 network gets a class and a bond. Without it every
    // attempt names a bond the chain does not have and the network cannot make its first block —
    // which is what the harness measured the moment admission was wired.
    // One class and a REGISTRY of bonds: a panel seats one bond per operator and never the
    // claim's own executor, so `seat_count + 1` of them is the smallest registry that can license
    // anything — `verify_palw_genesis_v2` refuses a shorter one.
    assert_eq!(
        bundle.genesis_objects.len(),
        1 + kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1(),
        "the bundle registers its class and a seatable bond registry"
    );
    assert!(bundle.genesis_objects.iter().any(|o| matches!(o, PalwConsensusObjectV2::ClassRegistered { .. })));
    assert!(bundle.genesis_objects.iter().any(|o| matches!(o, PalwConsensusObjectV2::BondRegistered { .. })));

    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let genesis_hash = config.params.genesis.hash;
    let consensus = TestConsensus::new(&config);

    // Genesis APPLIED the registrations — the class and the bond exist before block 1.
    {
        let vp = consensus.virtual_processor();
        let store = vp.palw_state_v2_store.read();
        let (_, state) = store.load_tip(&bundle.state).unwrap().expect("the genesis tip loads");
        assert!(state.class(&bundle.base_class_id).is_some(), "the liveness floor is registered at genesis");
        assert_eq!(state.class_share_permille(&bundle.base_class_id), Some(1000), "and holds the whole table");
        assert!(store.has_delta(genesis_hash).unwrap(), "genesis carries a delta like any chain block");
    }

    let mut ctx = TestContext::new(consensus);
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    // Blocks whose attempts pass every admission clause DO advance the chain — the wiring is a
    // gate, not a wall.
    assert_ne!(ctx.consensus.get_sink(), genesis_hash, "admissible attempts build a chain");

    // …and one that does not is refused. The pwu is the sharpest clause: ADR-0045 Decision 1
    // makes item 6 an EQUALITY against a value derived from chain state, so a miner that picks a
    // number is a miner refused.
    let sink_before = ctx.consensus.get_sink();
    let template = ctx.build_block_template(11, ctx.simulated_time + 1);
    let mut liar = template.block.clone();
    let mut envelope =
        kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(&liar.header.palw_commitment).unwrap();
    envelope.attempt.pwu += 1;
    liar.header.palw_commitment = envelope.encode_wire();
    liar.header.finalize();
    let liar_hash = liar.header.hash;
    // `pwu` is inside `attempt_id_v2`, so moving it also breaks the signature — and since launch
    // blockers §5 the relay path verifies that, so this lie is now refused at the DOOR rather than
    // surviving to the chain walk. Both refusals are the point: the door one is what stops a
    // forgery from costing every peer storage, and the pwu equality below is what stops it from
    // ever being chain.
    let outcome = ctx.consensus.validate_and_insert_block(liar.to_immutable()).virtual_state_task.await;
    assert!(outcome.is_err(), "an attempt whose carriage was edited after signing does not enter the DAG");
    assert_eq!(ctx.consensus.get_sink(), sink_before, "an attempt claiming a pwu it did not derive cannot become the sink");
    assert_ne!(liar_hash, sink_before);

    // And a lie that keeps its signature honest — re-signed by the real bond holder — still loses
    // on the pwu clause itself, which is the equality this test is named for.
    let mut resigned = template.block.clone();
    let mut env2 =
        kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(&resigned.header.palw_commitment).unwrap();
    env2.attempt.pwu += 1;
    env2.signature = libcrux_ml_dsa::ml_dsa_87::sign(
        &crate::consensus::test_consensus::TestConsensus::palw_v2_harness_keypair().signing_key,
        kaspa_consensus_core::palw_attempt_v2::attempt_id_v2(&env2.attempt).as_byte_slice(),
        kaspa_consensus_core::palw_attempt_v2::PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
        [0x5Au8; 32],
    )
    .expect("sign")
    .as_ref()
    .to_vec();
    resigned.header.palw_commitment = env2.encode_wire();
    resigned.header.finalize();
    let resigned_hash = resigned.header.hash;
    ctx.validate_and_insert_block(resigned.to_immutable()).await;
    assert_eq!(ctx.consensus.get_sink(), sink_before, "a correctly-signed pwu lie is still refused by the equality");
    assert_ne!(resigned_hash, sink_before);
}

/// **ADR-0072 SA-4, end to end: a network ARMED AT GENESIS produces a chain.**
///
/// Every other proof this lane has is a unit test, and that is what let a third gate keep the old
/// spelling. `consensus/pow/src/palw_admission.rs` called the un-parameterised shape entry point —
/// which hardcodes `PalwAttemptLaneV1::Unfenced` = algo-6 — and its live caller is
/// `utxo_validation`, which runs for EVERY chain candidate; an `Err` there is
/// `StatusDisqualifiedFromChain`. So on this exact configuration every block entered the DAG,
/// relayed normally, and was then disqualified with
/// `PalwAttemptLaneClosed { algo_id: 9, open: 6 }`; the virtual chain never left genesis and the
/// log said "disqualified from virtual chain" without naming the fence. No unit test of a
/// predicate can see that, because the defect is *which* predicate the pipeline calls.
///
/// This test is the answer to "nothing exercises an armed network end to end". It is not the whole
/// answer — `skip_proof_of_work` means the algo-9 finalizer arm is not priced here, and arming
/// ABOVE genesis is a different question (`LegacyArm` needs the deleted pre-ADR-0072 lottery
/// arithmetic back) — but the chain-building path is real: template → carriage → relay gate →
/// GHOSTDAG → UTXO admission → sink.
#[tokio::test]
async fn palw_v2_a_genesis_armed_attempt_lane_builds_a_chain() {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::pow_layer0::{POW_ALGO_ID_PALW_EXEC_V3, PalwAttemptLaneV1};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            // The arming this whole lane is about, in the one position its own remediation
            // recommended: `ForkActivation::always()` on a re-minted network.
            p.palw_attempt_activation = Some(ForkActivation::always());
        })
        .build();
    assert_eq!(
        config.params.palw_attempt_lane_at(0),
        PalwAttemptLaneV1::ExecutionArm,
        "armed at genesis, algo-9 is the open attempt lane at every height"
    );
    let genesis_hash = config.params.genesis.hash;
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // The producer's side: the template declares the OPEN lane and carries an attempt.
    let template = ctx.build_block_template(1, ctx.simulated_time + 1);
    assert_eq!(
        template.block.header.pow_algo_id, POW_ALGO_ID_PALW_EXEC_V3,
        "past the fence every template on every node declares algo-9"
    );
    assert!(!template.block.header.palw_commitment.is_empty(), "and the harness stamps its carriage on that id");

    // The chain's side: those blocks become the chain. This is the assertion the admission defect
    // failed — the blocks entered the DAG either way.
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let sink = ctx.consensus.get_sink();
    assert_ne!(sink, genesis_hash, "an armed network must leave genesis — a disqualified candidate never becomes the sink");
    let sink_header = ctx.consensus.virtual_processor().headers_store.get_header(sink).expect("the sink's header");
    assert_eq!(sink_header.pow_algo_id, POW_ALGO_ID_PALW_EXEC_V3, "and the chain block itself is on the armed lane");

    // The harness's OTHER block-building path (`TestConsensus::build_header_with_parents`) stamps
    // the id from the mode cascade instead of from a template, and the cascade cannot see a
    // top-level fence either. Un-widened it built algo-6 headers while the template builder built
    // algo-9 ones, so an armed test would have driven the CLOSED lane and could only go green for
    // the wrong reason.
    let by_parents = ctx.build_block_with_parents(vec![sink], 7, ctx.simulated_time + 1);
    assert_eq!(
        by_parents.header.pow_algo_id, POW_ALGO_ID_PALW_EXEC_V3,
        "the parent-built harness path must declare the same lane the template builder does"
    );
    assert!(!by_parents.header.palw_commitment.is_empty(), "and stamp a carriage on it");
}

/// **Unit C step 4's missing half: the block's own work reaches the state machine.**
///
/// `palw_v2_check_attempt_admission` validated the carried envelope and then the caller passed
/// `None` to the transition. Everything downstream of a claim therefore had nothing to act on:
/// no `PanelBound` could be derived (there was no `Provisional` claim to bind), nothing could be
/// licensed or challenged, no escrow was ever funded, the safe frontier never moved off the zero
/// point, and `bounded_immature` — the quantity the per-bond exposure ceiling is measured in —
/// stayed at zero on a chain of admissible attempts. PALW weight, which is this network's entire
/// fork choice, was structurally unreachable.
///
/// What this asserts is the seam, not the arithmetic: one attempt-lane chain block, one claim,
/// attributed to that block, in `Provisional`, with real reserved exposure behind it.
#[tokio::test]
async fn palw_v2_an_attempt_block_creates_its_claim() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{PalwClaimPhaseV2, PalwClaimSourceV2};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let genesis_hash = config.params.genesis.hash;
    let consensus = TestConsensus::new(&config);

    // The zero point: genesis registers a class and a bond and creates no claim.
    {
        let store = consensus.virtual_processor().palw_state_v2_store.read();
        let (_, state) = store.load_tip(&bundle.state).unwrap().expect("the genesis tip loads");
        assert_eq!(state.claims_iter().count(), 0, "genesis registers; it does not work");
        assert_eq!(state.bounded_immature(), 0);
    }

    let mut ctx = TestContext::new(consensus);
    const BLOCKS: usize = 3;
    for _ in 0..BLOCKS {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let store = vp.palw_state_v2_store.read();
    let tip = store.tip_record().unwrap().expect("the walk wrote a tip");
    assert_ne!(tip.block, genesis_hash, "the chain really advanced");
    let (_, state) = store.load_tip(&bundle.state).unwrap().expect("the tip loads");

    // One chain block, one claim — the claim IS the block's work.
    let claims: Vec<_> = state.claims_iter().collect();
    assert_eq!(claims.len(), BLOCKS, "every attempt-lane chain block created exactly one claim");
    let chain: Vec<_> = vp
        .reachability_service
        .default_backward_chain_iterator(tip.block)
        .take_while(|h| *h != kaspa_consensus_core::blockhash::ORIGIN)
        .collect();
    for (id, claim) in &claims {
        assert_eq!(claim.source, PalwClaimSourceV2::Attempt, "an algo-6 block's work is an attempt");
        assert!(matches!(claim.phase, PalwClaimPhaseV2::Provisional), "a fresh claim starts unbound");
        assert!(chain.contains(&claim.accepted_block), "claim {id} names a block on this chain");
        assert!(claim.reserved > 0, "and it reserves real collateral against its bond");
    }

    // The exposure the ceiling is measured in is no longer decorative.
    assert!(state.bounded_immature() > 0, "immature weight accumulated — it could not before");
    let bond = claims[0].1.bond;
    assert_eq!(
        state.reserved_exposure(&bond),
        claims.iter().map(|(_, c)| c.reserved).sum::<u128>(),
        "the bond carries exactly the sum of what its claims reserved"
    );
}

/// **ADR-0042 Decision 10: the PALW reward is a CARVE, and now it is actually carved.**
///
/// The Decision is explicit — "PALW reward is a **carve of the fixed subsidy** ..., never an
/// addition to it — the schedule is never exceeded (I6/I15)" — and only the release half was
/// built. Escrows were appended to `validator_reward_outputs` and nothing anywhere was taken out
/// to fund them: the accepting block's miner was paid its whole worker share, the same sompi were
/// escrowed against the claim, and every finalized claim minted its carve a second time, above the
/// emission schedule. `coinbase.rs` contained no PALW arithmetic at all, which is why reading it
/// could not settle the question either way.
///
/// This pins the funding side, which is the half that is observable on a three-block chain: the
/// coinbase that pays an attempt-lane block pays its worker share MINUS the escrow that block's
/// own claim took. The release side is the queue the same state carries, and the two are the same
/// number by construction — `palw_v2_escrow_withheld_at` sums the very field
/// `palw_v2_payout_outputs` later renders.
#[tokio::test]
async fn palw_v2_the_escrow_is_carved_out_of_the_block_that_earned_it() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::dns_finality::split_block_subsidy;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let fee_split = config.params.dns_params.as_ref().expect("the fixture network carves").reward_params.fee_split.clone();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let tip = ctx.consensus.get_sink();
    let selected_parent = vp.headers_store.get_header(tip).unwrap().direct_parents()[0];
    let sp_daa = vp.headers_store.get_header(selected_parent).unwrap().daa_score;

    // What the emission schedule allots the selected parent, and what its own claim escrowed.
    let sp_subsidy = vp.coinbase_manager.calc_block_subsidy(sp_daa);
    let sp_worker_share = split_block_subsidy(sp_subsidy, &fee_split).worker_base_sompi;
    let (_, sp_state) =
        vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().filter(|(b, _)| *b == tip).expect("the walk's tip is the sink");
    let escrow = vp.palw_v2_escrow_withheld_at(&sp_state, selected_parent, vp.headers_store.get_daa_score(selected_parent).unwrap());
    assert!(escrow > 0, "an attempt-lane block escrows its worker carve — otherwise this proves nothing");
    // Measured: 370,468,345 subsidy → 229,690,375 worker share → 229,690,373 escrow. The carve
    // permille (620) and `subsidy_worker_base_bps` (6200) are the same number expressed twice, so
    // an attempt-lane block's ENTIRE worker reward is escrowed and the miner keeps only the
    // rounding difference — which is exactly Decision 10's "block accepted → reward escrow →
    // Final → spendable". `validate_palw_v2` refuses a bundle where the carve is the larger of the
    // two, because then the escrow could not be funded from the block it is carved from.
    assert!(escrow <= sp_worker_share, "the carve must fit inside the share it is carved from");

    // The coinbase that pays the selected parent pays exactly the difference. Not `<=`: an
    // inequality would also hold if the escrow were withheld twice, or from the wrong block.
    let coinbase = &ctx.consensus.get_block(tip).unwrap().transactions[0];
    let paid: u64 = coinbase.outputs.iter().map(|o| o.value).sum();
    assert_eq!(
        paid,
        sp_worker_share - escrow,
        "the tip's coinbase must pay its selected parent's worker share LESS the escrow that block's claim took"
    );

    // And the whole coinbase stays inside what the schedule allows the block to mint. This is the
    // I6/I15 statement, in one line, on a real chain.
    assert!(paid <= sp_subsidy, "a block may never mint more than the subsidy of what it merges");
}

/// **B-1 (mainnet audit 2026-09-11 deep fence): a MERGED block's carve is withheld from the
/// coinbase and escrowed into its own claim — symmetric to own work — and build agrees with
/// validate byte-for-byte.**
///
/// Below the fence ADR-0058 Decision 5 paid a merged block its worker share in full at acceptance
/// and escrowed nothing, so a merged claim that later voided forfeited nothing (the escrow-until-
/// Final invariant, bypassed for the merged lane). Past the fence the accepting block's coinbase
/// withholds each merged block's worker carve (`palw_v2_merged_escrow_withheld`) and the transition
/// escrows the same carve into that block's own claim — one value, one function
/// (`PalwStateParamsV2::worker_carve`), on both the build and the validate path.
///
/// **That every block inserts is the proof of the coinbase-hash rule.** A template whose merged
/// withhold disagreed with the validator's expected coinbase would be mined into a block its own
/// node rejects; `validate_and_insert_row` with the fence ARMED exercises both paths against the
/// same block. The final assertion closes the loop: the carve withheld from the coinbase is the
/// carve the folded claim carries — a deferral of one number, never a second mint.
#[tokio::test]
async fn palw_v2_a_merged_blocks_carve_is_withheld_and_escrowed_past_the_deep_fence() {
    use crate::model::stores::daa::DaaStoreReader;
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_attempt_v2::{PalwAttemptEnvelopeV2, attempt_id_v2};
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 16);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            // B-1 rides the deep fence; arm it at genesis so this short chain runs entirely past it,
            // and so `validate_and_insert_row` checks the coinbase-hash rule with the withhold live.
            p.palw_audit_2026_09_11_deep = Some(ForkActivation::always());
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    // Rows of two parallel blocks merge a blue besides the selected parent. Every row inserting is
    // the build==validate check for the merged withhold, block by block.
    for _ in 0..4 {
        ctx.build_block_template_row(0..2).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor().clone();
    let sink = ctx.consensus.get_sink();
    let ghostdag_data = vp.ghostdag_store.get_data(sink).unwrap();
    assert!(ghostdag_data.mergeset_blues.len() > 1, "the fixture must merge a blue besides the selected parent");
    let non_daa = vp.daa_excluded_store.get_mergeset_non_daa(sink).unwrap();

    // The sink's folded state, and the selected-parent state its coinbase and withhold were against.
    let (tip_block, tip_state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert_eq!(tip_block, sink, "the walk left the tip at the sink");
    let parent_state = {
        let store = vp.palw_state_v2_store.read();
        let (_, delta) = store.delta_of(sink).expect("the sink has a delta");
        kaspa_consensus_core::palw_state_v2::revert_delta_v2(&tip_state, &delta, &bundle.state).expect("the sink's delta reverts")
    };
    let sink_header = vp.headers_store.get_header(sink).expect("the sink's header");
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: sink,
        daa_score: sink_header.daa_score,
        blue_score: sink_header.blue_score,
        subsidy: vp.coinbase_manager.calc_block_subsidy(sink_header.daa_score),
    };

    // The withhold map the sink's coinbase used, recomputed from the same selected-parent state.
    let withheld = vp.palw_v2_merged_escrow_withheld(&parent_state, &ghostdag_data, &non_daa, &point);
    assert!(!withheld.is_empty(), "past the fence, a merged attempt's carve is withheld — otherwise this proves nothing");
    for (blue, carve) in &withheld {
        assert!(*carve > 0, "the withheld carve is the merged block's worker share, non-zero");
        // The matched pair: the claim the transition created for that merged blue escrowed EXACTLY
        // what the coinbase withheld — a deferral of one number, not a second mint.
        let header = vp.headers_store.get_header(*blue).expect("the merged blue's header");
        let envelope = PalwAttemptEnvelopeV2::decode_wire(&header.palw_commitment).expect("a V2 block carries an attempt");
        let claim_id = attempt_id_v2(&envelope.attempt);
        let claim = tip_state.claim(&claim_id).expect("the merged claim was folded into the sink's state");
        assert_eq!(claim.escrowed_reward, *carve, "the carve withheld from the coinbase is the carve escrowed into the claim");
    }
}

/// **Audit C-08's lock, resolved from a real chain's registry.**
///
/// A `PalwBondKeyV2` is the outpoint holding the bond's collateral, and nothing kept the money
/// there: the owner could spend that output in block 1 and every exposure ceiling, every slash and
/// Decision 7's Sybil bound would have been denominated in a balance the bond no longer had.
///
/// This pins the resolver — the seam between the V2 registry and the UTXO spend filter — against a
/// state a real chain produced, at the two DAA scores that matter. What it does NOT do is spend
/// the output: the fixture's genesis bond names an outpoint no test key can open (a genesis
/// premine output needs its vault's ML-DSA key, and no harness holds one), so the last link is
/// covered where it can be — `BondSpendFilter`'s own unit test, over the set this function returns.
#[tokio::test]
async fn palw_v2_a_live_bonds_collateral_outpoint_is_locked() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let registered: Vec<_> = state.bonds_iter().map(|(key, _)| key.0).collect();
    assert_eq!(
        registered.len(),
        kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1(),
        "the fixture registers a seatable bond registry at genesis"
    );

    // EVERY Active bond's collateral is locked at every score — the panel's seats included, since
    // a seat that could spend its stake out from under a claim is a seat with nothing at risk.
    for daa in [0, 1, 1_000_000, u64::MAX] {
        let locked = vp.palw_v2_locked_bond_outpoints(&state, daa);
        for outpoint in &registered {
            assert!(locked.contains(outpoint), "an Active bond's collateral must be locked at daa {daa}");
        }
        assert_eq!(locked.len(), registered.len(), "and nothing else is");
    }

    // A network with no V2 bundle locks nothing here — the filter stays inert where it always was.
    let plain = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let plain_consensus = TestConsensus::new(&plain);
    let _lt = plain_consensus.init();
    assert!(
        plain_consensus.virtual_processor().palw_v2_locked_bond_outpoints(&state, 0).is_empty(),
        "no bundle, no bond policy, nothing locked — every shipped preset is unchanged"
    );
}

/// **The measurement that proves the reservations are real: the ceiling can now be hit.**
///
/// The bundle's default bond funds four concurrent claims (`MIN_COLLATERAL_SOMPI`, whose own
/// doc comment does the arithmetic). While the transition never saw a block's work, `reserved`
/// stayed at zero forever and a single bond could have backed an unbounded chain — the P0-10
/// check was wired, ran on every block, and could not fail. The fifth chain block is refused now,
/// which is the ceiling doing what it exists to do.
///
/// Deliberately uses the DEFAULT fixture, so `palw_v2_test_bundle_funded_for` raising a bond
/// elsewhere cannot quietly retire this.
/// **A block produced the way the RC will produce blocks, accepted by consensus.**
///
/// Everything else about `ConsensusV2` was tested against `palw_v2_test_carriage`, a harness that
/// reads its class facts out of the genesis bundle and invents its roots. This runs the REAL path
/// end to end on the REAL ruleset: `palw_rc_params_from_artifacts` builds the network,
/// `palw_producer_facts_v2` supplies the six chain facts, `base0_execute_for_attempt_v1` runs an
/// actual BASE-0 inference over the job the template anchors, and the attempt is signed with an
/// ML-DSA-87 key the genesis bond registered. If it lands, testnet-12 can make blocks.
///
/// Before this, nothing could: `misaminer` and `pq-miner` both branch on algo 4 and 5 only, and the
/// one algo-6 carriage builder in the tree was a `pub(crate)` test helper. The network had a
/// genesis and no second block, and no test said so.
#[tokio::test]
async fn palw_rc_a_real_execution_produces_a_block_the_chain_accepts() {
    use kaspa_consensus_core::api::ConsensusApi;
    use kaspa_consensus_core::palw_attempt_v2::{
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT, PALW_ATTEMPT_V2_VERSION, PalwAttemptEnvelopeV2, PalwAttemptUnsignedV2, attempt_id_v2,
        challenge_v2, class_ticket_v3, palw_network_domain_v2_for,
    };
    use kaspa_consensus_core::palw_base0_profile::{PALW_RC_BASE0_CANONICAL, PALW_RC_BASE0_GEOMETRY, base0_profile_v1};
    use misaka_palw_base0::produce::{base0_execute_for_attempt_v1, base0_rc_job_anchor_v1, base0_rc_job_v1};

    // The operator half of the genesis card, generated here the way an operator generates it.
    let keypair = libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xB0u8; 32]);
    let bond_key = kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(0));
    let artifact_root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("the floor's artifact derives");
    // The registry, not a bond: row 0 is the producer's, and the rest are the panel's. A registry
    // that cannot seat a panel — or that cannot carry a claim through the bind window — is refused
    // by `verify_palw_genesis_v2`, which is what stops a network from shipping in a state where it
    // makes two blocks and stops.
    let registry: Vec<_> = (0..kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1() as u32)
        .map(|i| kaspa_consensus_core::palw_fp_devnet_v3::PalwGenesisBondSpecV1 {
            bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(i)),
            pubkey: if i == 0 { keypair.verification_key.as_ref().to_vec() } else { vec![7u8.wrapping_add(i as u8); 32] },
            operator_pubkey: vec![21u8, i as u8, 0, 0, 0, 0, 0, 0],
            payout_payload: kaspa_hashes::Hash64::from_u64_word(0x9A11 + i as u64),
        })
        .collect();
    let params = kaspa_consensus_core::config::params::palw_rc_params_from_artifacts(artifact_root, registry)
        .expect("the RC genesis card assembles");
    let bundle = match &params.palw_consensus_mode {
        kaspa_consensus_core::palw_mode_v2::PalwConsensusMode::ConsensusV2(b) => b.clone(),
        _ => panic!("palw_rc_params_from_artifacts must yield a ConsensusV2 network"),
    };
    // The shipped RC activates the EVM lane at DAA 0 (inherited from `TESTNET_PARAMS` and kept
    // deliberately — testnet-11 carries it and the RC is the network t11's traffic moves onto). A
    // template cannot be built for an active lane by a binary without the feature, so a non-evm
    // test build disables it HERE and asserts what it disabled. The lane is orthogonal to what
    // this test measures — a real execution producing an accepted block — and stating the
    // divergence is better than a test that silently runs on a different ruleset.
    assert_eq!(params.evm_activation_daa_score, 0, "the shipped RC carries the EVM lane");
    let config = ConfigBuilder::new(params)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            if !cfg!(feature = "evm") {
                p.evm_activation_daa_score = u64::MAX;
                // ADR-0089 Decision 9: the market's EVM face may not be armed on a lane this build
                // makes inert. Turning the lane off is one decision, not two —
                // `validate_palw_v2` refuses the pair and the node would panic at startup.
                p.palw_model_evm = None;
            }
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let facts = ctx
        .consensus
        .palw_producer_facts_v2(bundle.base_class_id, Some(bond_key.0))
        .expect("the RC network answers for its own floor");
    assert_eq!(
        facts.ready_to_produce(keypair.verification_key.as_ref()),
        Ok(()),
        "the genesis bond, this key, and an untouched epoch budget"
    );
    assert_eq!(facts.artifact_root, artifact_root, "the class registered the artifact the producer will name");

    // The template. Its pre-pow hash anchors the job, so one template is one inference.
    // The builder's own timestamp, not one stamped over it: the RC's EVM lane is active at DAA 0
    // and `evm_commitment_root` is computed during the build against the header's timestamp.
    let mut block = ctx.build_block_template_keeping_time(0).block;
    let timestamp = block.header.timestamp;
    assert_eq!(
        block.header.pow_algo_id,
        kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_COMMITTED_V2,
        "a ConsensusV2 network declares the attempt lane"
    );
    let network_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);
    let profile = base0_profile_v1(PALW_RC_BASE0_GEOMETRY).expect("the floor's graph is expressible");
    let artifact = misaka_palw_base0::rc::palw_rc_base0_artifact_v1().expect("derives");

    // The work, and the draw (ADR-0072): a real inference over the job this template and bucket
    // name, whose execution IS the ticket. A lost draw is not re-rolled by moving the nonce —
    // every nonce in the bucket derives the same anchor and the same ticket — but by the next
    // bucket, which is a different job and a second real inference.
    let mut won = None;
    for bucket in 0u64..4096 {
        let nonce = bucket << kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2;
        let anchor = base0_rc_job_anchor_v1(network_domain, pre_pow, facts.class_id, &bond_key.0, bucket);
        let (job, prompt) = base0_rc_job_v1(
            &profile,
            anchor,
            artifact.shape.vocab,
            PALW_RC_BASE0_CANONICAL.0,
            PALW_RC_BASE0_CANONICAL.1,
            kaspa_consensus_core::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
        );
        let run = base0_execute_for_attempt_v1(&artifact, &profile, &job, &prompt).expect("the floor runs its own job");
        let attempt = PalwAttemptUnsignedV2 {
            version: PALW_ATTEMPT_V2_VERSION,
            network_domain,
            challenge: challenge_v2(network_domain, pre_pow, timestamp, nonce, facts.class_id, &bond_key.0),
            class_id: facts.class_id,
            executor_bond: bond_key.0,
            executor_pubkey: keypair.verification_key.as_ref().to_vec(),
            operator_id: facts.bond.as_ref().unwrap().operator_id,
            artifact_root: facts.artifact_root,
            trace_root: run.trace_root,
            output_root: run.output_root,
            execution_root: run.execution_root,
            pwu: facts.pwu,
            trace_manifest_root: run.trace_manifest_root,
            trace_chunk_count: run.trace_chunk_count,
            trace_retention_daa: block.header.daa_score.saturating_add(facts.min_trace_retention_daa),
        };
        if class_ticket_v3(&attempt, anchor) <= facts.class_target {
            won = Some((nonce, attempt));
            break;
        }
    }
    let (nonce, attempt) = won.expect("the floor's genesis target is winnable");

    // Signed ONCE, after the search, over the attempt id — the signature is outside the commitment
    // root, so signing per nonce would be an ML-DSA-87 operation thrown away every try.
    let signature = libcrux_ml_dsa::ml_dsa_87::sign(
        &keypair.signing_key,
        attempt_id_v2(&attempt).as_byte_slice(),
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
        [0x5Au8; 32],
    )
    .expect("ML-DSA-87 sign")
    .as_ref()
    .to_vec();
    block.header.nonce = nonce;
    block.header.palw_commitment = PalwAttemptEnvelopeV2 { attempt, signature }.encode_wire();
    block.header.finalize();
    let hash = block.header.hash;

    ctx.validate_and_insert_block(block.to_immutable()).await.assert_valid_utxo_tip();
    assert_eq!(ctx.consensus.get_sink(), hash, "the block a real execution produced is the chain");

    // And the chain moved because of it: the floor's epoch counter is the producer's own receipt.
    let after = ctx.consensus.palw_producer_facts_v2(bundle.base_class_id, Some(bond_key.0)).expect("still a V2 network");
    assert_eq!(after.epoch_produced_blocks, 1, "one block of this class, counted");
    assert!(after.bond.as_ref().unwrap().reserved_exposure > 0, "the claim it created reserves against the bond");
}

/// **A block produced by the REAL Qwen2.5-1.5B A16 model, accepted by consensus.**
///
/// The dense tier's own goal sentence. This is not a shaped fixture: it maps the converted
/// `.palwart` of `Qwen/Qwen2.5-1.5B-Instruct` (1.7 GiB, 28 layers, vocabulary 151,936 — the
/// checkpoint that answers "The capital of France is Paris." on this engine), registers it beside
/// the floor and the hybrid in a three-class genesis, runs the anchored canonical job through
/// `A16Engine`, commits under the TILED logits trace, wins the class's lottery, signs under a
/// genesis bond, and lands in the UTXO tip.
///
/// Ignored in CI only because of the 1.7 GiB artifact; everything it exercises is the shipped path.
///
/// ```text
/// MISAKA_QWEN25_A16_ARTIFACT=/path/to/qwen25-1.5b-a16.palwart \
///   cargo test --release -p kaspa-consensus real_qwen25_a16 -- --ignored --nocapture
/// ```
#[tokio::test]
#[ignore = "maps the real 1.7 GiB Qwen2.5 A16 artifact; set MISAKA_QWEN25_A16_ARTIFACT and --ignored"]
async fn palw_rc_the_real_qwen25_a16_model_produces_a_block() {
    use kaspa_consensus_core::api::ConsensusApi;
    use kaspa_consensus_core::palw_attempt_v2::{
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT, PALW_ATTEMPT_V2_VERSION, PalwAttemptEnvelopeV2, PalwAttemptUnsignedV2, attempt_id_v2,
        challenge_v2, class_ticket_v3, palw_network_domain_v2_for,
    };
    use kaspa_consensus_core::palw_backend::PalwExecutionBackendV1;
    use kaspa_consensus_core::palw_qwen25_profile::{QWEN25_A16_CANONICAL, qwen25_a16_graph_v5_profile_v1};
    use misaka_palw_base0::produce::base0_rc_job_anchor_v1;
    use misaka_palw_base0::qwen25_a16_backend::Qwen25A16Backend;

    let path = std::env::var("MISAKA_QWEN25_A16_ARTIFACT").expect("MISAKA_QWEN25_A16_ARTIFACT=/path/to/qwen25-1.5b-a16.palwart");
    let opened = std::time::Instant::now();
    let bytes = std::fs::read(&path).expect("the artifact reads");
    let artifact = misaka_palw_base0::artifact::decode_artifact_file_v1(&bytes).expect("the artifact decodes");
    // The registered dense row is the graph-v5 512 row (ADR-0082), and a court-capable row
    // registers the A16 INVENTORY root, not the container digest — `CanonicalClassV1::artifact_root`
    // is the one spelling (the genesis constant is measured equal to it for the shipped file).
    let artifact_root = misaka_palw_base0::classes::a16_graph_v5_row_v1()
        .expect("the graph-v5 dense row")
        .artifact_root(&artifact)
        .expect("the inventory root derives");
    eprintln!(
        "dense drill: {} layers / vocab {} / root {artifact_root} in {:?}",
        artifact.shape.n_layers,
        artifact.shape.vocab,
        opened.elapsed()
    );

    let keypair = libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xB0u8; 32]);
    let bond_key = kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(0));
    let base_root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("the floor's artifact derives");
    let registry: Vec<_> = (0..kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1() as u32)
        .map(|i| kaspa_consensus_core::palw_fp_devnet_v3::PalwGenesisBondSpecV1 {
            bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(i)),
            pubkey: if i == 0 { keypair.verification_key.as_ref().to_vec() } else { vec![7u8.wrapping_add(i as u8); 32] },
            operator_pubkey: vec![21u8, i as u8, 0, 0, 0, 0, 0, 0],
            payout_payload: kaspa_hashes::Hash64::from_u64_word(0x9A11 + i as u64),
        })
        .collect();

    // THREE classes: the floor, the hybrid (its dev fixture's root — this drill is about the dense
    // one), and the dense model whose weights are on disk.
    let hybrid_root = misaka_palw_base0::qwen36::qwen36_dev_fixture(1, 8).artifact_root();
    let params =
        kaspa_consensus_core::config::params::palw_rc_params_with_classes(base_root, hybrid_root, Some(artifact_root), registry)
            .expect("the three-class RC genesis card assembles");
    let bundle = match &params.palw_consensus_mode {
        kaspa_consensus_core::palw_mode_v2::PalwConsensusMode::ConsensusV2(b) => b.clone(),
        _ => panic!("the RC ships a ConsensusV2 bundle"),
    };
    // The REGISTERED dense class is the corrected `graph-v2` one (ADR-0069): the v1 declaration
    // announces a one-byte state map against an i32 cache, so its backend is not court-capable and
    // a class on it cannot hold weight.
    let dense_class_id = qwen25_a16_graph_v5_profile_v1().expect("the graph-v5 dense profile").shape_profile_id();
    assert_ne!(dense_class_id, bundle.base_class_id, "the dense class is not the floor");

    let config = ConfigBuilder::new(params)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            if !cfg!(feature = "evm") {
                p.evm_activation_daa_score = u64::MAX;
                // ADR-0089 Decision 9: the market's EVM face may not be armed on a lane this build
                // makes inert. Turning the lane off is one decision, not two —
                // `validate_palw_v2` refuses the pair and the node would panic at startup.
                p.palw_model_evm = None;
            }
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let facts = ctx
        .consensus
        .palw_producer_facts_v2(dense_class_id, Some(bond_key.0))
        .expect("the three-class network answers for its dense entrant");
    assert_eq!(facts.artifact_root, artifact_root, "the chain names the artifact this node holds");
    assert_eq!(facts.ready_to_produce(keypair.verification_key.as_ref()), Ok(()), "bond, key and an epoch budget");

    let mut block = ctx.build_block_template_keeping_time(0).block;
    let timestamp = block.header.timestamp;
    let network_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);
    let backend = Qwen25A16Backend::new(
        std::sync::Arc::new(artifact),
        config.params.net.to_string().into_bytes(),
        // The class's graph, not only its id — the backend needs it for the step space and the
        // state map, and `shape_profile_id()` of this profile IS `dense_class_id`.
        kaspa_consensus_core::palw_qwen25_profile::qwen25_a16_profile_v1(
            kaspa_consensus_core::palw_qwen25_profile::qwen25_canonical_geometry_v1("Qwen/Qwen2.5-1.5B-Instruct")
                .expect("the canonical A16 geometry"),
        )
        .expect("a valid A16 profile"),
        QWEN25_A16_CANONICAL,
    )
    // Fallible since ADR-0082 audit E's H-1: the constructor compiles the class's declaration into
    // the program it executes, so a declaration this artifact cannot serve is a named refusal here
    // instead of a forward pass under arithmetic nobody declared.
    .expect("the dense drill's declaration is the program this artifact runs");
    // The work, and the draw (ADR-0072): the execution IS the ticket, so a lost draw is re-rolled
    // by the next bucket — a different job, a second real inference — never by moving the nonce.
    let mut won = None;
    for bucket in 0u64..4096 {
        let nonce = bucket << kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2;
        let anchor = base0_rc_job_anchor_v1(network_domain, pre_pow, dense_class_id, &bond_key.0, bucket);
        let (job, prompt) = backend.job_for_anchor(anchor).expect("the anchor implies a job inside the artifact's table");
        let ran = std::time::Instant::now();
        let run = backend.execute(&job, &prompt).expect("a real Qwen2.5-1.5B forward pass over the anchored job");
        eprintln!(
            "dense drill: executed ({} prefill + {} decode) in {:?}; material {} bytes [bucket {}]",
            job.declared_prefill_tokens,
            job.exact_decode_tokens,
            ran.elapsed(),
            run.material.len(),
            bucket
        );
        let attempt = PalwAttemptUnsignedV2 {
            version: PALW_ATTEMPT_V2_VERSION,
            network_domain,
            challenge: challenge_v2(network_domain, pre_pow, timestamp, nonce, dense_class_id, &bond_key.0),
            class_id: dense_class_id,
            executor_bond: bond_key.0,
            executor_pubkey: keypair.verification_key.as_ref().to_vec(),
            operator_id: facts.bond.as_ref().expect("the pre-flight held a bond").operator_id,
            artifact_root: facts.artifact_root,
            trace_root: run.trace_root,
            output_root: run.output_root,
            execution_root: run.execution_root,
            pwu: facts.pwu,
            trace_manifest_root: run.trace_manifest_root,
            trace_chunk_count: run.trace_chunk_count,
            trace_retention_daa: block.header.daa_score.saturating_add(facts.min_trace_retention_daa),
        };
        if class_ticket_v3(&attempt, anchor) <= facts.class_target {
            won = Some((nonce, attempt));
            break;
        }
    }
    let (nonce, attempt) = won.expect("the entrant's genesis target is winnable");
    let signature = libcrux_ml_dsa::ml_dsa_87::sign(
        &keypair.signing_key,
        attempt_id_v2(&attempt).as_byte_slice(),
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
        [0x5Au8; 32],
    )
    .expect("ML-DSA-87 sign")
    .as_ref()
    .to_vec();
    block.header.nonce = nonce;
    block.header.palw_commitment = PalwAttemptEnvelopeV2 { attempt, signature }.encode_wire();
    block.header.finalize();
    let hash = block.header.hash;

    ctx.validate_and_insert_block(block.to_immutable()).await.assert_valid_utxo_tip();
    assert_eq!(ctx.consensus.get_sink(), hash, "the block a real Qwen2.5-1.5B execution produced is the chain");
    eprintln!("dense drill: block {hash} accepted");
}

/// **A block produced by a REAL Qwen3.6-shaped execution, accepted by consensus** — the goal
/// gate's own sentence, "実用的にブロック生成に使用できる", as a test.
///
/// The floor's twin (`palw_rc_a_real_execution_produces_a_block_the_chain_accepts`) proved the RC
/// path for the class every node derives. This proves the SECOND class — registered from genesis
/// beside the floor by `palw_rc_params_with_qwen36`, answered for by `palw_producer_facts_v2`,
/// executed by the real `Qwen36Engine` (a hybrid GDN + gated-attention + MoE forward pass, not a
/// stub), committed under the TILED logits trace, won at the class's own lottery, signed under a
/// genesis bond, and accepted into the UTXO tip.
///
/// # What stands in, and what does not
///
/// The artifact is `qwen36_dev_fixture` — the Qwen3.6-shaped toy, because a CI test cannot mmap
/// 33 GiB. The stand-in is the WEIGHTS, not the path: the engine, the ops, the commitment scheme
/// and every consensus check are the production ones. The registered class's geometry is the real
/// `QWEN36_35B_A3B` (that is what `qwen36_registration_v1` derives), so the chain-side facts —
/// class id, pwu, target — are the real class's; the drill binary swaps the fixture for the real
/// artifact and nothing else. The profile's court constants are marked PRE-DERIVATION: the
/// admission cost work (per-node tiles, head-slice GDN openings, small registered context) tunes
/// them before any real network mints this genesis, and none of it changes this path.
#[tokio::test]
async fn palw_rc_a_qwen36_execution_produces_a_block_the_chain_accepts() {
    qwen36_block_e2e(misaka_palw_base0::qwen36::qwen36_dev_fixture(4, 8), "Qwen3.6-dev-fixture").await;
}

/// **The same path over the REAL 33 GiB artifact** — the drill the goal names.
///
/// `MISAKA_QWEN36_ARTIFACT=/path/to/q36-40L.palwq36 cargo test --release -p kaspa-consensus ///  real_qwen36_artifact -- --ignored --nocapture`
///
/// Ignored in CI because it memory-maps 33 GiB and runs ten true 35B forward passes (about a
/// minute of inference on the reference M4 Pro, plus one pass over the file for the artifact
/// root). Everything else — the two-class genesis, the facts, the lottery, the signature, the
/// acceptance — is byte-for-byte the fixture test's path, which is the point: the drill swaps the
/// weights and nothing else.
#[tokio::test]
#[ignore = "runs the real 33 GiB Qwen3.6 artifact; set MISAKA_QWEN36_ARTIFACT and --ignored"]
async fn palw_rc_the_real_qwen36_artifact_produces_a_block() {
    let path = std::env::var("MISAKA_QWEN36_ARTIFACT").expect("MISAKA_QWEN36_ARTIFACT=/path/to/q36-40L.palwq36");
    let opened = std::time::Instant::now();
    let artifact = misaka_palw_base0::qwen36::open_artifact(std::path::Path::new(&path)).expect("the artifact opens");
    // **The drill's artifact must be the PUBLIC NETWORK's artifact.** Otherwise this passes for a
    // file nobody on testnet-11 can use, which is the one thing the drill exists to rule out.
    assert_eq!(
        artifact.artifact_root(),
        kaspa_consensus_core::config::params::PALW_RC_GENESIS_QWEN36_ARTIFACT_ROOT,
        "MISAKA_QWEN36_ARTIFACT is not the artifact testnet-11 registers"
    );
    eprintln!(
        "drill: mapped {} layers / {:.2} GiB in {:?}",
        artifact.shape.n_layers(),
        artifact.weight_bytes() as f64 / (1u64 << 30) as f64,
        opened.elapsed()
    );
    qwen36_block_e2e(artifact, "Qwen3.6-35B-A3B").await;
}

async fn qwen36_block_e2e(artifact: misaka_palw_base0::qwen36::Qwen36ArtifactV1, model_id: &str) {
    use kaspa_consensus_core::api::ConsensusApi;
    use kaspa_consensus_core::palw_attempt_v2::{
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT, PALW_ATTEMPT_V2_VERSION, PalwAttemptEnvelopeV2, PalwAttemptUnsignedV2, attempt_id_v2,
        challenge_v2, class_ticket_v3, palw_network_domain_v2_for,
    };
    use kaspa_consensus_core::palw_backend::PalwExecutionBackendV1;
    use kaspa_consensus_core::palw_qwen36_profile::QWEN36_RC_CANONICAL;
    use misaka_palw_base0::produce::base0_rc_job_anchor_v1;
    use misaka_palw_base0::qwen36_backend::Qwen36Backend;

    // The operator half, exactly as the floor test builds it: row 0's key is ours.
    let keypair = libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xB0u8; 32]);
    let bond_key = kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(0));
    let base_root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("the floor's artifact derives");
    let registry: Vec<_> = (0..kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1() as u32)
        .map(|i| kaspa_consensus_core::palw_fp_devnet_v3::PalwGenesisBondSpecV1 {
            bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(i)),
            pubkey: if i == 0 { keypair.verification_key.as_ref().to_vec() } else { vec![7u8.wrapping_add(i as u8); 32] },
            operator_pubkey: vec![21u8, i as u8, 0, 0, 0, 0, 0, 0],
            payout_payload: kaspa_hashes::Hash64::from_u64_word(0x9A11 + i as u64),
        })
        .collect();

    // The Qwen3.6 side: whichever weights the caller supplied, the real class's identity.
    let rooted = std::time::Instant::now();
    let artifact_root = artifact.artifact_root();
    eprintln!("drill: artifact root {artifact_root} in {:?}", rooted.elapsed());
    // The two-class genesis, assembled by the same function the shipped network uses. It once
    // failed here at the boot cost gate (the class's derived close was 1.24x the carrier ceiling)
    // and this call was wrapped in a match that asserted the refusal and returned — which was
    // honest while it lasted and became a FAIL-OPEN the moment the cost fit: a future regression
    // past the ceiling would have made this test pass while producing no block. Unconditional now.
    let params = kaspa_consensus_core::config::params::palw_rc_params_with_qwen36(base_root, artifact_root, registry)
        .expect("the two-class RC genesis card assembles");
    let bundle = match &params.palw_consensus_mode {
        kaspa_consensus_core::palw_mode_v2::PalwConsensusMode::ConsensusV2(b) => b.clone(),
        _ => panic!("a ConsensusV2 network"),
    };
    // The REGISTERED hybrid class is `graph-v3` (ADR-0069) — the v2 projection over the
    // eps-corrected geometry. v1 names a GDN node no backend can serve, so a class on it has no
    // court; asked through the accessor rather than projected here, so this test cannot drift away
    // from what the genesis card actually registers.
    let qwen36_class_id = kaspa_consensus_core::palw_qwen36_profile::qwen36_class_id_v3();
    assert_ne!(qwen36_class_id, bundle.base_class_id, "two classes, and the floor is not the entrant");

    let config = ConfigBuilder::new(params)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            if !cfg!(feature = "evm") {
                p.evm_activation_daa_score = u64::MAX;
                // ADR-0089 Decision 9: the market's EVM face may not be armed on a lane this build
                // makes inert. Turning the lane off is one decision, not two —
                // `validate_palw_v2` refuses the pair and the node would panic at startup.
                p.palw_model_evm = None;
            }
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // The chain answers for the entrant: registered at genesis, active, budgeted.
    let facts = ctx
        .consensus
        .palw_producer_facts_v2(qwen36_class_id, Some(bond_key.0))
        .expect("the two-class network answers for its entrant");
    assert_eq!(facts.artifact_root, artifact_root, "the chain names the artifact this node holds");
    assert_eq!(facts.ready_to_produce(keypair.verification_key.as_ref()), Ok(()), "bond, key, and an epoch budget for 1‰");

    // The template anchors the job; the REAL engine runs it.
    let mut block = ctx.build_block_template_keeping_time(0).block;
    let timestamp = block.header.timestamp;
    let network_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);

    let backend = Qwen36Backend::new(
        std::sync::Arc::new(artifact),
        model_id,
        QWEN36_RC_CANONICAL,
        qwen36_class_id,
        config.params.net.to_string().into_bytes(),
    );
    // The work, and the draw (ADR-0072): the execution IS the ticket, so a lost draw is re-rolled
    // by the next bucket — a different job, a second real inference — never by moving the nonce.
    let mut won = None;
    for bucket in 0u64..4096 {
        let nonce = bucket << kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2;
        let anchor = base0_rc_job_anchor_v1(network_domain, pre_pow, qwen36_class_id, &bond_key.0, bucket);
        let (job, prompt) = backend.job_for_anchor(anchor).expect("the anchor implies a job inside the artifact's table");
        let ran = std::time::Instant::now();
        let run = backend.execute(&job, &prompt).expect("a real hybrid forward pass over the anchored job");
        eprintln!(
            "drill: executed the canonical job ({} prefill + {} decode) in {:?}; material {} bytes [bucket {}]",
            job.declared_prefill_tokens,
            job.exact_decode_tokens,
            ran.elapsed(),
            run.material.len(),
            bucket
        );
        let attempt = PalwAttemptUnsignedV2 {
            version: PALW_ATTEMPT_V2_VERSION,
            network_domain,
            challenge: challenge_v2(network_domain, pre_pow, timestamp, nonce, qwen36_class_id, &bond_key.0),
            class_id: qwen36_class_id,
            executor_bond: bond_key.0,
            executor_pubkey: keypair.verification_key.as_ref().to_vec(),
            operator_id: facts.bond.as_ref().expect("the pre-flight held a bond").operator_id,
            artifact_root: facts.artifact_root,
            trace_root: run.trace_root,
            output_root: run.output_root,
            execution_root: run.execution_root,
            pwu: facts.pwu,
            trace_manifest_root: run.trace_manifest_root,
            trace_chunk_count: run.trace_chunk_count,
            trace_retention_daa: block.header.daa_score.saturating_add(facts.min_trace_retention_daa),
        };
        if class_ticket_v3(&attempt, anchor) <= facts.class_target {
            won = Some((nonce, attempt));
            break;
        }
    }
    let (nonce, attempt) = won.expect("the entrant's genesis target is winnable");
    let signature = libcrux_ml_dsa::ml_dsa_87::sign(
        &keypair.signing_key,
        attempt_id_v2(&attempt).as_byte_slice(),
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
        [0x5Au8; 32],
    )
    .expect("ML-DSA-87 sign")
    .as_ref()
    .to_vec();
    block.header.nonce = nonce;
    block.header.palw_commitment = PalwAttemptEnvelopeV2 { attempt, signature }.encode_wire();
    block.header.finalize();
    let hash = block.header.hash;

    ctx.validate_and_insert_block(block.to_immutable()).await.assert_valid_utxo_tip();
    assert_eq!(ctx.consensus.get_sink(), hash, "the block a Qwen3.6 execution produced is the chain");

    // Counted under the ENTRANT's class, and reserving against the bond — a Qwen3.6 block, not a
    // floor block wearing its id.
    let after = ctx.consensus.palw_producer_facts_v2(qwen36_class_id, Some(bond_key.0)).expect("still a V2 network");
    assert_eq!(after.epoch_produced_blocks, 1, "one block of THIS class, counted");
    assert!(after.bond.as_ref().expect("bonded").reserved_exposure > 0, "its claim reserves against the bond");
}

/// **A stranger can create their own bond, and the chain accepts the form they can build.**
///
/// This is the seam that decides whether a network is open. Producing needs a bond
/// (`ready_to_produce`: "the named bond is not registered on this chain"), and the only bonds any
/// chain had were the ones its genesis registry named — so mining was closed to everyone else. The
/// rules were not what closed it: `palw_lifecycle_object_may_ride_v2` has always let a
/// `BondRegistered` ride. What closed it was the carrier-binding rule demanding an outpoint that
/// named its own carrying transaction by id, which is a hash fixed point (see
/// `naming_the_carrier_by_id_is_a_fixed_point_no_registrant_can_solve`): the object rides in the
/// payload, and the payload is in the id.
///
/// So the registrant names the output by INDEX with a zero id, the extractor substitutes the id it
/// observes, and the signature is made over the zero form. Two parties have to agree about which
/// bytes were signed, and this drives BOTH of them — the real extractor and the real validator —
/// because a correspondence like that only shows up in a round trip. Signing the substituted form
/// instead is refused below, which is what makes the passing half meaningful.
#[tokio::test]
async fn palw_v2_a_stranger_can_register_their_own_bond() {
    use kaspa_consensus_core::palw_lifecycle_objects_v2::{
        PALW_LIFECYCLE_TX_VERSION_V2, PalwLifecycleTxPayloadV2, palw_bond_registration_signed_key_v2,
        palw_lifecycle_objects_from_accepted_txs_v2,
    };
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_BOND_REGISTRATION_V2_MLDSA87_CONTEXT, PalwBondKeyV2, PalwConsensusObjectV2 as Obj, palw_bond_registration_message_v2,
    };
    use kaspa_consensus_core::subnets::SUBNETWORK_ID_PALW_LIFECYCLE;
    use kaspa_consensus_core::tx::{Transaction, TransactionId, TransactionOutpoint, TransactionOutput};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    let vp = ctx.consensus.virtual_processor();
    let (tip, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: tip,
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 2,
        subsidy: 0,
    };

    // A stranger: a key this chain has never seen, on no registry.
    let keypair = libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xC1u8; 32]);
    let pubkey = keypair.verification_key.as_ref().to_vec();
    let payout_payload = kaspa_hashes::Hash64::from_bytes([0x5Au8; 64]);
    let collateral = bundle.state.min_collateral_sompi();
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );

    // What a registrant can compute at signing time: "the output at index 0 of whatever carries me".
    let declared = PalwBondKeyV2(TransactionOutpoint::new(TransactionId::default(), 0));
    let sign_over = |key: &PalwBondKeyV2| {
        let message =
            palw_bond_registration_message_v2(network_domain, key, &pubkey, &pubkey, collateral, &payout_payload, &Default::default());
        libcrux_ml_dsa::ml_dsa_87::sign(
            &keypair.signing_key,
            message.as_byte_slice(),
            PALW_BOND_REGISTRATION_V2_MLDSA87_CONTEXT,
            [9u8; 32],
        )
        .expect("sign")
        .as_ref()
        .to_vec()
    };

    let carry = |signature: Vec<u8>| {
        let object = Obj::BondRegistered {
            bond: declared,
            pubkey: pubkey.clone(),
            operator_pubkey: pubkey.clone(),
            collateral,
            payout_payload,
            capable_classes: Default::default(),
            signature,
        };
        let payload = borsh::to_vec(&PalwLifecycleTxPayloadV2 { version: PALW_LIFECYCLE_TX_VERSION_V2, object })
            .expect("the lifecycle payload serializes");
        Transaction::new(
            0,
            vec![],
            // The collateral, in an output of this very transaction, paying the declared payee.
            vec![TransactionOutput::new(
                collateral,
                kaspa_consensus_core::mldsa87_primitives::p2pkh_mldsa87_spk(payout_payload.as_byte_slice()),
            )],
            0,
            SUBNETWORK_ID_PALW_LIFECYCLE.clone(),
            0,
            payload,
        )
    };

    // **The honest trip.** Signed over the zero form, carried, extracted, validated.
    let tx = carry(sign_over(&declared));
    let extracted = palw_lifecycle_objects_from_accepted_txs_v2(std::slice::from_ref(&tx));
    assert!(extracted.skipped.is_empty(), "the carrier binds: {:?}", extracted.skipped);
    let [carried] = &extracted.objects[..] else { panic!("exactly one object rides") };
    let Obj::BondRegistered { bond, .. } = &carried.object else { panic!("and it is the registration") };
    assert_eq!(bond.0, TransactionOutpoint::new(tx.id(), 0), "the chain keyed the bond to its carrier");
    assert_eq!(palw_bond_registration_signed_key_v2(bond), declared, "and a verifier recovers what was signed");

    vp.palw_v2_validate_objects(&state, &bundle.state, &point, std::slice::from_ref(&carried.object))
        .expect("a stranger's own signed, collateral-locking bond registration must be accepted");

    // **Signing the substituted form instead is refused.** Without this the assertion above would
    // also pass if the verifier had simply stopped checking, and the two halves of the
    // correspondence would be free to drift apart.
    let substituted = PalwBondKeyV2(TransactionOutpoint::new(tx.id(), 0));
    let wrong = carry(sign_over(&substituted));
    let extracted = palw_lifecycle_objects_from_accepted_txs_v2(std::slice::from_ref(&wrong));
    let [carried_wrong] = &extracted.objects[..] else { panic!("it still rides — the lock is about money, not signatures") };
    let err = vp
        .palw_v2_validate_objects(&state, &bundle.state, &point, std::slice::from_ref(&carried_wrong.object))
        .expect_err("a signature over the key the chain substituted is not the one the registrant makes");
    assert!(err.contains("not signed by the key it declares"), "got {err}");
}

/// **Nobody can register a class without a bond that signed for it** (launch blockers §3).
///
/// ADR-0049 Decision H made post-genesis registration a live path and nothing signed it. A
/// registration takes a permille from EVERY incumbent through largest-remainder donation, and the
/// share field's own doc says "whoever may register a class may fund it, and nobody else may move a
/// permille" — there was no `whoever`. Any stranger could move the cadence table for a transaction
/// fee.
#[tokio::test]
async fn palw_v2_a_class_registration_needs_a_bond_that_signed_for_it() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_CLASS_REGISTRATION_V2_MLDSA87_CONTEXT, PalwBondKeyV2, PalwClassAdmissionCarriageV2, PalwConsensusObjectV2 as Obj,
        PalwPwuRuleV2, palw_class_registration_message_v2,
    };

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();

    let vp = ctx.consensus.virtual_processor();
    let (tip, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: tip,
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 2,
        subsidy: 0,
    };

    // A Qwen-shaped entrant, admissible on its own merits — so what decides this test is the
    // authority and nothing else.
    let profile = kaspa_consensus_core::palw_qwen25_profile::qwen25_profile_v1(
        kaspa_consensus_core::palw_qwen25_profile::PalwQwen25GeometryV1 {
            tile_len: 16_384,
            ..kaspa_consensus_core::palw_qwen25_profile::QWEN25_1_5B
        },
    )
    .expect("expressible");
    let class_id = profile.shape_profile_id();
    let share = bundle.state.min_grantable_share_permille();
    let registrant = PalwBondKeyV2(kaspa_consensus_core::tx::TransactionOutpoint::new(
        kaspa_consensus_core::tx::TransactionId::from_u64_word(0xB0),
        0,
    ));
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );
    // The signed preimage is the whole object (audit M2-6), so the fixture states the same values
    // the `make` closure below builds it with — a mismatch here is the attack the fix closes.
    let signed_artifact_root = kaspa_hashes::Hash64::from_u64_word(0xA7);
    let signed_rule = PalwPwuRuleV2::DerivedV1 { pwu_per_inference: 1 };
    let signed_canonical = kaspa_consensus_core::palw_base0_profile::rc_job_context(&profile, 8, 4);
    let message = palw_class_registration_message_v2(
        network_domain,
        class_id,
        share,
        0,
        &registrant,
        signed_artifact_root,
        1,
        u128::MAX / 2,
        &signed_rule,
        &signed_canonical,
    );
    let sign = |kp: &libcrux_ml_dsa::ml_dsa_87::MLDSA87KeyPair| {
        libcrux_ml_dsa::ml_dsa_87::sign(
            &kp.signing_key,
            message.as_byte_slice(),
            PALW_CLASS_REGISTRATION_V2_MLDSA87_CONTEXT,
            [7u8; 32],
        )
        .expect("sign")
        .as_ref()
        .to_vec()
    };
    let make = |bond: PalwBondKeyV2, signature: Vec<u8>| Obj::ClassRegistered {
        class_id,
        artifact_root: kaspa_hashes::Hash64::from_u64_word(0xA7),
        slash_value_per_pwu: 1,
        pwu_rule: PalwPwuRuleV2::DerivedV1 { pwu_per_inference: 1 },
        initial_target: u128::MAX / 2,
        share_permille: share,
        activation_daa: 0,
        admission: Some(Box::new(PalwClassAdmissionCarriageV2 {
            profile: profile.clone(),
            canonical: kaspa_consensus_core::palw_base0_profile::rc_job_context(&profile, 8, 4),
            registrant_bond: bond,
            signature,
        })),
    };

    // **Unsigned: refused.** This is the attack — a stranger moving the cadence table.
    let err = vp
        .palw_v2_validate_objects(&state, &bundle.state, &point, &[make(registrant, Vec::new())])
        .expect_err("an unsigned registration must not move a permille");
    assert!(err.contains("not signed by the bond it names"), "got {err}");

    // Signed by the WRONG key under a real bond: also refused. Holding a bond is not enough.
    let wrong = crate::consensus::test_consensus::TestConsensus::palw_v2_registry_keypair(3);
    let err = vp
        .palw_v2_validate_objects(&state, &bundle.state, &point, &[make(registrant, sign(wrong))])
        .expect_err("a signature from another key is not this bond's authority");
    assert!(err.contains("not signed by the bond it names"), "got {err}");

    // Naming a bond the chain does not have: refused before any signature is looked at.
    let stranger = PalwBondKeyV2(kaspa_consensus_core::tx::TransactionOutpoint::new(
        kaspa_consensus_core::tx::TransactionId::from_u64_word(0xDEAD),
        0,
    ));
    let err = vp
        .palw_v2_validate_objects(&state, &bundle.state, &point, &[make(stranger, Vec::new())])
        .expect_err("a bond this chain does not have is nobody");
    assert!(err.contains("does not have"), "got {err}");

    // And the real holder's signature passes the authority check — whatever the graph gates then
    // say is a different question, and it is not "who".
    let kp = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_keypair();
    let outcome = vp.palw_v2_validate_objects(&state, &bundle.state, &point, &[make(registrant, sign(kp))]);
    if let Err(e) = &outcome {
        assert!(!e.contains("not signed by the bond it names") && !e.contains("does not have"), "authority must pass: {e}");
    }
}

/// **A panel really binds, and a signed quorum really licenses the claim** (launch blockers §2)./// **A panel really binds, and a signed quorum really licenses the claim** (launch blockers §2).
///
/// Nothing in the tree ever filed a `ReceiptLicensed`, so no claim could reach `Final`: every panel
/// voided at `ReceiptTimeout` with all its seats slashed, `safe_weight` stayed zero forever, and
/// the escrowed worker carve of every block — its entire 620-permille worker base share — was
/// burned. The lattice had no configuration in which it turned over.
///
/// This drives the real edges: the chain derives the panel, `palw_seat_duties_v2` reports what the
/// seats owe, real ML-DSA-87 receipts are signed over `palw_receipt_message_v2`, and the acceptance
/// layer's quorum check licenses the claim.
#[tokio::test]
async fn palw_v2_a_signed_quorum_licenses_a_claim() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_panel_v2::{PalwReceiptVerdictV2, PalwSeatReceiptV2, palw_receipt_message_v2};
    use kaspa_consensus_core::palw_state_v2::{PalwClaimPhaseV2, PalwConsensusObjectV2 as Obj};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Past the anchor delay, so the chain can derive a panel for the first claims.
    for _ in 0..(bundle.panel.anchor_delay() + 4) {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let (tip, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");

    // **A panel really bound.** Before the registry gates this was impossible with one bond.
    let (claim_id, claim) = state
        .claims_iter()
        .find(|(id, c)| matches!(c.phase, PalwClaimPhaseV2::PanelBound { .. }) && state.panel(id).is_some())
        .map(|(id, c)| (*id, c.clone()))
        .expect("the chain derives a panel once the anchor exists");
    let panel = state.panel(&claim_id).expect("bound").clone();
    assert_eq!(panel.seats.len(), bundle.panel.seat_count() as usize, "a full jury, not a short one");

    // **The seats see their duty.** A seat cannot act on something it cannot see.
    let mine: Vec<_> = panel.seats.iter().map(|s| s.bond).collect();
    let duties = kaspa_consensus_core::palw_producer_v2::palw_seat_duties_v2(&state, &bundle.state, &mine);
    let for_this_claim: Vec<_> = duties.iter().filter(|d| d.claim_id == claim_id).collect();
    assert_eq!(for_this_claim.len(), mine.len(), "every seat of this panel is a duty this node holds");
    assert!(duties.len() >= for_this_claim.len(), "and duties across every bound claim are reported, not just one");
    let duty = for_this_claim[0];
    assert_eq!(duty.execution_root, claim.execution_root, "and it carries what the seat must decide against");
    assert_ne!(duty.executor_bond, duty.seat_bond, "a seat never judges its own claim");
    assert!(!duty.free_prompt, "an attempt claim's duty names the anchor-derived lane — the seat re-hashes, never replays");

    // **ADR-0122 §6.5: the operator's read of the same claim** (`getPalwClaims`). The executor's
    // list holds it with its panel, the date its receipt window closes and its escrow; each seat's
    // list holds it as a claim the seat judges; the rows come newest first, and a limit says what
    // it left out.
    {
        use kaspa_consensus_core::palw_producer_v2::{PalwClaimRoleV1, palw_claim_rows_v1};
        let (rows, truncated) = palw_claim_rows_v1(&state, &bundle.state, &claim.bond, PalwClaimRoleV1::Executor, false, 0);
        assert!(!truncated);
        let row = rows.iter().find(|r| r.claim_id == claim_id).expect("the executor's list holds its claim");
        assert_eq!(row.seats, mine, "the panel's seats, in seat order");
        let PalwClaimPhaseV2::PanelBound { bound_daa } = claim.phase else { unreachable!("found as panel-bound") };
        assert_eq!(row.bound_daa, Some(bound_daa));
        assert_eq!(row.deadline_daa, Some(bound_daa + bundle.state.window_receipt()), "the receipt window's close");
        assert_eq!((row.escrowed_reward, row.reserved), (claim.escrowed_reward, claim.reserved));
        assert!(rows.windows(2).all(|w| w[0].accepted_daa >= w[1].accepted_daa), "newest first");
        let (seated, _) = palw_claim_rows_v1(&state, &bundle.state, &mine[0], PalwClaimRoleV1::Seat, false, 0);
        assert!(seated.iter().any(|r| r.claim_id == claim_id && r.executor_bond == claim.bond), "a seat lists what it judges");
        let (all, _) = palw_claim_rows_v1(&state, &bundle.state, &claim.bond, PalwClaimRoleV1::Executor, true, 0);
        let (one, cut) = palw_claim_rows_v1(&state, &bundle.state, &claim.bond, PalwClaimRoleV1::Executor, true, 1);
        assert_eq!(one.len(), 1);
        assert_eq!(cut, all.len() > 1, "a limit says whether it left rows out");
        // The bond beside its claims: the registry's own record, including the classes it judges —
        // the one fact no other read reported (a seat is drawn only for a class it declared).
        use kaspa_consensus_core::palw_producer_v2::palw_bond_summary_v1;
        let seat = palw_bond_summary_v1(&state, &mine[0]).expect("a seat is a registered bond");
        let record = state.bond(&mine[0]).expect("registered");
        assert_eq!(
            (seat.collateral, seat.pubkey.as_slice(), seat.retiring_since_daa),
            (record.collateral, record.pubkey.as_slice(), None)
        );
        assert!(seat.capable_classes.contains(&claim.class_id), "it was seated for this class, so it declared it");
        let nobody = kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::tx::TransactionOutpoint::new(
            kaspa_consensus_core::tx::TransactionId::from_u64_word(0xDEAD),
            7,
        ));
        assert!(palw_bond_summary_v1(&state, &nobody).is_none(), "no bond there is None, not an empty record");
    }

    // Real signatures, from the harness identity every genesis bond registers.
    // Each seat signs under ITS OWN registered key — the quorum check resolves the seat bond to its
    // registry pubkey, so one shared key would (correctly) fail to verify for the others.
    // `palw_devnet_bond_registry_v1` keys row `n` at txid `0xB0 + n`, so the row index is the
    // outpoint's own offset — and row 0 is the harness identity the executor bond registers.
    let seat_key = |bond: &kaspa_consensus_core::palw_state_v2::PalwBondKeyV2| {
        let index = (0..16u64)
            .find(|i| bond.0.transaction_id == kaspa_consensus_core::tx::TransactionId::from_u64_word(0xB0 + i) && bond.0.index == 0)
            .expect("a registry row");
        if index == 0 {
            crate::consensus::test_consensus::TestConsensus::palw_v2_harness_keypair()
        } else {
            crate::consensus::test_consensus::TestConsensus::palw_v2_registry_keypair(index)
        }
    };
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );
    let signed_daa = ctx.consensus.get_virtual_daa_score();
    let receipts: Vec<PalwSeatReceiptV2> = panel
        .seats
        .iter()
        .take(bundle.panel.quorum() as usize)
        .map(|seat| {
            let message = palw_receipt_message_v2(network_domain, claim_id, PalwReceiptVerdictV2::Valid, signed_daa);
            let signature = libcrux_ml_dsa::ml_dsa_87::sign(
                &seat_key(&seat.bond).signing_key,
                message.as_byte_slice(),
                kaspa_consensus_core::palw_panel_v2::PALW_RECEIPT_V2_MLDSA87_CONTEXT,
                [0x11u8; 32],
            )
            .expect("sign")
            .as_ref()
            .to_vec();
            PalwSeatReceiptV2 { claim: claim_id, verdict: PalwReceiptVerdictV2::Valid, seat_bond: seat.bond, signed_daa, signature }
        })
        .collect();

    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: tip,
        daa_score: signed_daa,
        blue_score: signed_daa,
        subsidy: 0,
    };
    let object = Obj::ReceiptLicensed { claim: claim_id, receipts: receipts.clone() };
    vp.palw_v2_validate_objects(&state, &bundle.state, &point, std::slice::from_ref(&object))
        .expect("a signed quorum licenses the claim");

    // And one seat short of quorum does not — the quorum is a bound, not a formality.
    let short = Obj::ReceiptLicensed { claim: claim_id, receipts: receipts[..receipts.len() - 1].to_vec() };
    assert!(
        vp.palw_v2_validate_objects(&state, &bundle.state, &point, std::slice::from_ref(&short)).is_err(),
        "below quorum is refused"
    );

    // Folding it moves the claim out of PanelBound — the edge that did not exist.
    // The transition demands a strictly-increasing chain point; acceptance above does not, so the
    // fold gets its own point one step past the tip's.
    let next_point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: kaspa_consensus_core::BlockHash::from_u64_word(0xF01D),
        daa_score: signed_daa + 1,
        blue_score: state.last_point().map(|p| p.blue_score).unwrap_or(0) + 1,
        subsidy: 0,
    };
    let (licensed, _) = kaspa_consensus_core::palw_state_v2::apply_palw_transition_v2(
        &state,
        &bundle.state,
        &next_point,
        std::slice::from_ref(&object),
        None,
    )
    .expect("the transition takes it");
    assert!(
        matches!(licensed.claim(&claim_id).unwrap().phase, PalwClaimPhaseV2::ReceiptLicensed { .. }),
        "the claim is licensed, and its path to Final is open"
    );
}

/// **The pruning-point PALW import installs a real state and REFUSES a forged one**/// **The pruning-point PALW import installs a real state and REFUSES a forged one** (launch
/// blockers §1, the import half).
///
/// `PalwChainStateV2` was written only by `process_genesis`, so a node joining by pruned IBD had
/// none. The startup guard now stops such a node from running; this is what lets it exist at all.
///
/// The gate is the ROOT, and it runs before the write: `into_state` rebuilds the carriage and
/// demands back the root the pruning point's own header commits. A peer that forges one byte of
/// bonds, shares or claims produces a different root and is refused HERE — not detected after a
/// durable write, which would be no defence at all, since forged bonds are block-production rights
/// and forged claims are `safe_weight`.
#[tokio::test]
async fn palw_v2_the_pruning_point_import_verifies_the_root_before_it_writes() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    // The import verifies against the CHILD header — `palw_state_root` commits the state as-of the
    // block's selected parent — so the point being imported has to be one with a child on the
    // chain. The store's tip has none yet, so walk back one: the tip's selected parent is a chain
    // block whose child (the tip) commits its state.
    let (tip, _) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let point = {
        use crate::model::stores::ghostdag::GhostdagStoreReader;
        vp.ghostdag_store.get_selected_parent(tip).expect("the tip has a selected parent")
    };
    let state = {
        // The state AT `point`, rebuilt the way the chain walk rebuilds it.
        let store = vp.palw_state_v2_store.read();
        let (_, delta) = store.delta_of(tip).expect("the tip has a delta");
        let (_, tip_state) = store.load_tip(&bundle.state).unwrap().unwrap();
        kaspa_consensus_core::palw_state_v2::revert_delta_v2(&tip_state, &delta, &bundle.state)
            .expect("reverting the tip's own delta yields its parent's state")
    };
    let honest = PalwStateCarriageV2::from_state(&state);

    // **What a peer would serve, through the production path — which is the SNAPSHOT, not the tip.**
    //
    // This assertion used to read the tip, and passed for that reason alone: on a running node the
    // tip is rewritten to the sink on every virtual walk, so the server's "is the tip the pruning
    // point?" test was permanently false and every pruned IBD aborted. The test could not see it
    // because it served the same row it had just written. Now it captures first, as
    // `advance_pruning_point_if_possible` does, and asks for what the capture put there.
    assert!(vp.pruning_point_palw_state(tip).is_none(), "nothing is servable before a snapshot is captured");
    vp.capture_pruning_point_palw_state(tip);
    let served = vp.pruning_point_palw_state(tip).expect("the captured snapshot is servable");
    assert_eq!(served, PalwStateCarriageV2::from_state(&vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().unwrap().1));
    assert!(vp.pruning_point_palw_state(kaspa_consensus_core::BlockHash::from_u64_word(0xBAD)).is_none(), "and nothing else");

    // Empty the store the way a pruned join leaves it, then import what the peer served.
    {
        let mut store = vp.palw_state_v2_store.write();
        store.delete_tip_for_tests().expect("empty the store");
    }
    assert!(vp.palw_state_v2_store.read().tip_record().unwrap().is_none());

    // **A forged carriage is refused, and the store stays empty.** One extra bond is all it takes:
    // bonds are block-production rights, so this is the exact lie the gate exists to stop.
    let mut forged = honest.clone();
    forged.class_shares.insert(kaspa_hashes::Hash64::from_u64_word(0x5EED), 1);
    let err = vp.import_pruning_point_palw_state(point, forged).expect_err("a forged carriage must not install");
    assert!(format!("{err}").contains("does not rebuild to the root"), "and the refusal names the reason: {err}");
    assert!(
        vp.palw_state_v2_store.read().tip_record().unwrap().is_none(),
        "the refusal happens BEFORE the write — detection afterwards would be no defence"
    );

    // **A frontier above the point itself is refused before the root is even rebuilt** (mainnet
    // audit, 2026-09-05). The root check cannot catch this one when the peer also authored the
    // witness header; the pruning point's own blue score can, and does.
    let mut pinned = honest.clone();
    pinned.safe_frontier_blue_score = u64::MAX;
    let err = vp.import_pruning_point_palw_state(point, pinned).expect_err("a frontier above the point must not install");
    assert!(format!("{err}").contains("safe frontier"), "and the refusal names the frontier: {err}");
    assert!(vp.palw_state_v2_store.read().tip_record().unwrap().is_none(), "…and nothing was written");

    // The honest one installs, and what lands is the state the chain had.
    vp.import_pruning_point_palw_state(point, honest).expect("the honest carriage installs");
    let (imported_block, imported) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("installed");
    assert_eq!(imported_block, point);
    assert_eq!(imported.state_root(), state.state_root(), "and it is the same state, root for root");
}

/// **The pruning-point witness is the selected-chain child — a side block can neither poison the
/// import nor choose the examiner.** (audit M1-2, re-audit R-3)
///
/// The acceptance test both audits asked for and neither had. `import_pruning_point_palw_state` and
/// `import_pruning_point_overlay_snapshot` are the two places a joining node writes peer-supplied
/// state — bonds, which are block-production rights, and a reserve balance, which is mintable coin —
/// and both verify the payload against a header committed by a CHILD of the pruning point. Which
/// child is therefore the whole security of the gate, and it went wrong twice:
///
/// * requiring **every** child to agree (before M1-2) let one cheap side block with a garbage root
///   veto the pruning point permanently: the disagreement is a fact of the DAG, so no retry and no
///   other peer could clear it;
/// * taking the **heaviest** child (M1-2's repair) still let the peer choose, because blue-work ties
///   between siblings are the normal case and the tiebreak was the block hash — which is grindable.
///
/// The witness is now the child on the selected chain to the header DAG's selected tip, of which
/// there is at most one by construction. The shape below is what separates the three rules: one
/// pruning point, one honest chain child, and three siblings committing garbage roots.
///
/// **The discrimination is pinned, not sampled.** All four children of the pruning point carry the
/// same blue work, so the heaviest-child rule turns entirely on its hash tiebreak — and the block
/// hashes here are not stable between runs. Written the obvious way this test caught a revert to
/// that rule only about three runs in four: flaky, not red, which pins nothing. Each sibling is
/// therefore ground until it out-ranks the chain child under exactly the comparison the discarded
/// rule used, and the test asserts that precondition before it asserts anything else. Under the
/// unanimity rule assertion (1) fails; under the heaviest-child rule assertion (1) fails too, and
/// on EVERY run, because the examiner the gate reaches for is then always one of the liars.
#[tokio::test]
async fn the_pruning_point_witness_is_the_selected_chain_child_not_a_side_block() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use crate::model::stores::headers::HeaderStoreReader;
    use crate::model::stores::relations::RelationsStoreReader;
    use kaspa_consensus_core::errors::pruning::PruningImportError;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // `point` is the block whose state a joining node will import. It is about to acquire one
    // honest chain child and three lying siblings.
    let point = ctx.consensus.get_sink();

    // ---- The attacker's block TEMPLATES, built NOW so their only parent is `point`. They are held
    //      back and finalized further down, once the honest chain child is known: the garbage root
    //      each one commits is chosen so that the DISCARDED rule would deterministically pick it.
    //      An attacker can always publish such a block, which is the premise of the whole gate.
    let mut siblings = Vec::new();
    for i in 0..3u64 {
        let side = ctx.build_block_template(0x51D0 + i, ctx.simulated_time + 1).block;
        assert_eq!(side.header.direct_parents(), &[point], "the sibling hangs off the point being imported");
        siblings.push(side);
    }

    // ---- The honest chain continues from `point` and outruns them. Three blocks is enough that no
    //      sibling can win a blue-work tie at the header selected tip: to move the selected chain
    //      off `point`'s honest child an attacker would have to out-work the chain from the pruning
    //      point forward, which is the security level this gate is supposed to have.
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let tip = ctx.consensus.get_sink();

    // The child of `point` on the selected chain to `tip` — the one witness the repaired gate may
    // use. Read BEFORE the siblings arrive, so it is the chain's answer and not a race with them.
    let chain_child = {
        let vp = ctx.consensus.virtual_processor();
        let mut c = vp.ghostdag_store.get_selected_parent(tip).expect("the tip has a selected parent");
        let mut prev = tip;
        while c != point {
            prev = c;
            c = vp.ghostdag_store.get_selected_parent(c).expect("selected parent");
        }
        prev
    };

    // ---- **Pin the discrimination instead of hoping for it.** All four children of `point` carry
    //      the SAME blue work — one block each, one shared parent — so M1-2's "heaviest child" rule
    //      decides on its hash tiebreak alone, and with three siblings against one honest child the
    //      honest child holds the maximum about one run in four. Block hashes here are not stable
    //      across runs (the templates carry a wall-clock timestamp), so left to chance this test
    //      catches a revert to that rule only ~75% of the time — it was flaky, not red, and a flaky
    //      test does not pin a consensus rule. So each sibling is ground until it OUT-RANKS the
    //      chain child under exactly the comparison the discarded rule used. The grind is free:
    //      `palw_state_root` is garbage by construction, so any value in the 0xBAD* family serves.
    let mut side_roots = Vec::new();
    for (i, side) in siblings.iter_mut().enumerate() {
        let mut attempt = 0u64;
        let garbage = loop {
            let garbage = kaspa_hashes::Hash64::from_u64_word(0xBAD0 + i as u64 + (attempt << 16));
            side.header.palw_state_root = garbage;
            side.header.palw_commitment = ctx.consensus.palw_v2_test_carriage(&side.header);
            side.header.finalize();
            if side.header.hash > chain_child {
                break garbage;
            }
            attempt += 1;
            assert!(attempt < 4096, "could not out-rank the chain child in 4096 grinds — the tiebreak is not what this test assumes");
        };
        side_roots.push(garbage);
    }
    assert!(
        siblings.iter().all(|s| s.header.hash > chain_child),
        "precondition of the discrimination: every sibling out-ranks the chain child, so the heaviest-child rule picks a LIAR on every run"
    );

    // ---- Now the siblings arrive, as they would from any peer.
    for side in siblings {
        let hash = side.header.hash;
        ctx.validate_and_insert_block(side.to_immutable()).await;
        assert_eq!(
            ctx.consensus.virtual_processor().ghostdag_store.get_selected_parent(hash).expect("the sibling is in the DAG"),
            point,
            "the sibling is a child of the point being imported — that is the whole premise"
        );
    }
    assert_eq!(ctx.consensus.get_sink(), tip, "and no sibling became the chain");
    assert_eq!(
        {
            let vp = ctx.consensus.virtual_processor();
            let mut c = vp.ghostdag_store.get_selected_parent(tip).expect("the tip has a selected parent");
            let mut prev = tip;
            while c != point {
                prev = c;
                c = vp.ghostdag_store.get_selected_parent(c).expect("selected parent");
            }
            prev
        },
        chain_child,
        "and the arriving siblings did not move the selected chain off the honest child"
    );

    let vp = ctx.consensus.virtual_processor();
    let honest_root = vp.headers_store.get_header(chain_child).expect("the chain child's header").palw_state_root;
    assert_ne!(honest_root, kaspa_hashes::ZERO_HASH64, "the chain child commits a real root");

    // The point really does have four children, and only one of them is the chain's.
    let children: Vec<_> = RelationsStoreReader::get_children(&vp.relations_service, point)
        .map(|c| c.read().iter().copied().collect())
        .unwrap_or_default();
    assert_eq!(children.len(), 4, "one honest chain child and three siblings");

    // The state AT `point`, rebuilt the way the chain walk rebuilds it: revert the selected chain's
    // deltas from the tip back down.
    let state = {
        let store = vp.palw_state_v2_store.read();
        let (_, mut st) = store.load_tip(&bundle.state).unwrap().expect("the tip loads");
        let mut cur = tip;
        while cur != point {
            let (_, delta) = store.delta_of(cur).expect("every chain block has a delta");
            st = kaspa_consensus_core::palw_state_v2::revert_delta_v2(&st, &delta, &bundle.state)
                .expect("reverting walks back one block");
            cur = vp.ghostdag_store.get_selected_parent(cur).expect("selected parent");
        }
        st
    };
    let honest = PalwStateCarriageV2::from_state(&state);

    // Empty the store the way a pruned join leaves it, then import.
    {
        let mut store = vp.palw_state_v2_store.write();
        store.delete_tip_for_tests().expect("empty the store");
    }

    // **(1) The siblings did not poison the pruning point.** Under the pre-M1-2 unanimity rule this
    // is the assertion that failed, and no retry against any peer could have cleared it.
    vp.import_pruning_point_palw_state(point, honest.clone()).expect("the honest carriage installs despite three lying siblings");
    let (imported_block, imported) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("installed");
    assert_eq!(imported_block, point);
    assert_eq!(imported.state_root(), state.state_root(), "and it is the state the chain had, root for root");

    // **(2) The examiner was the chain child, not a sibling.** A forged carriage is refused and the
    // error names the root the gate demanded, which must be the chain child's. This is what
    // separates "heaviest child" from "selected-chain child": under the old rule the demanded root
    // would be one of the planted `0xBAD*` values whenever that sibling won the blue-work tiebreak,
    // and the carriage the attacker also supplied would then be the one that installs.
    {
        let mut store = vp.palw_state_v2_store.write();
        store.delete_tip_for_tests().expect("empty the store again");
    }
    let mut forged = honest.clone();
    forged.class_shares.insert(kaspa_hashes::Hash64::from_u64_word(0x5EED), 1);
    let err = vp.import_pruning_point_palw_state(point, forged).expect_err("a forged carriage must not install");
    let demanded = match &err {
        PruningImportError::ImportedPalwStateInvalid(_, root, _) => *root,
        other => panic!("expected the root-mismatch refusal, got {other:?}"),
    };
    assert_eq!(demanded, honest_root, "the gate examined the selected-chain child");
    for garbage in &side_roots {
        assert_ne!(demanded, *garbage, "and never a sibling's planted root");
    }
    assert!(
        vp.palw_state_v2_store.read().tip_record().unwrap().is_none(),
        "the refusal happens BEFORE the write — detection afterwards would be no defence"
    );
}

/// **A ConsensusV2 node with no PALW state refuses to run** (launch blockers §1)./// **A ConsensusV2 node with no PALW state refuses to run** (launch blockers §1).
///
/// Absent state was read as "no policy", and every PALW authority then failed OPEN: the state root
/// unchecked, no transition applied, tips ordered by blue work alone, any pruning point allowed,
/// the deep-reorg comparator skipped. It does not FORK — it is strictly more permissive — so a node
/// in that state follows the blue-work-heaviest chain that frontier-first ordering exists to refuse,
/// and nothing anywhere reports it.
///
/// Four ways in: pruned IBD, a datadir predating the bundle (bundle-free and bundled testnet-12
/// share a genesis, so the re-genesis guard cannot see the difference), a schema bump that
/// `reindex_if_stale` answers by deleting the tip, and the staging consensus.
///
/// This drives the same construction path a node takes, with the store emptied — the state a
/// pruned join lands in. Deleting the guard makes it build happily, which is the point.
#[tokio::test]
async fn palw_v2_a_node_with_no_palw_state_refuses_to_run() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();

    // A healthy node installs the tip at genesis and runs.
    let tc = TestConsensus::new(&config);
    let _lt = tc.init();
    assert!(
        tc.virtual_processor().palw_state_v2_store.read().tip_record().unwrap().is_some(),
        "a genesis-processed ConsensusV2 node holds a PALW tip"
    );

    // Now the state a pruned join lands in: the store emptied under a live bundle. Every PALW leg
    // reads `None` and becomes a no-op — the silent-downgrade the guard exists to make impossible.
    let vp = tc.virtual_processor();
    {
        let mut store = vp.palw_state_v2_store.write();
        store.delete_tip_for_tests().expect("the fixture can empty its own store");
    }
    assert!(
        vp.palw_state_v2_store.read().tip_record().unwrap().is_none(),
        "and with the tip gone every PALW authority would silently fail open"
    );

    // Every PALW leg is now a no-op on this node, which is the silent downgrade itself: the
    // pruning ceiling allows anything, and the candidate order has no authority to express.
    assert!(
        vp.palw_pruning_point_allowed_v2(tc.get_sink()),
        "with no state the pruning ceiling permits any point — the fail-open the guard exists to stop"
    );
}

/// **A staging consensus is not a node, and refusing it closed the network to newcomers.**
///
/// `IbdType::DownloadHeadersProof` — the path every fresh join takes onto a chain with history —
/// creates a staging consensus to replay the proof into. Staging holds no PALW state by
/// construction: it is a scratch database that is promoted or discarded, and the guard above says
/// so in its own words ("the one legitimate stateless case").
///
/// It could not recognise it. `db_has_history` was read AFTER `virtual_processor.init()`, and
/// `init` writes `past_pruning_points[0]` on any database that lacks a pruning point — so the row
/// that was supposed to mean "this database carries a chain" was written by the same constructor,
/// three lines earlier, for every consensus that has ever existed. Staging looked like a resuming
/// node, the guard fired, and the node died one second into its first IBD.
///
/// Measured on testnet-11 on 2026-08-26: three fresh hosts, three identical panics, no way to join
/// the network except to restart until the datadir had enough state to pass — which is not a join
/// path, it is a coin flip an operator has to know about.
///
/// This is the staging case; `palw_v2_constructing_a_bundled_consensus_over_an_empty_store_panics`
/// is the resuming one, and both must hold: a guard that cannot tell them apart is either a network
/// with no newcomers or a node whose PALW authority silently fails open.
#[test]
fn palw_v2_a_staging_consensus_without_palw_state_is_allowed() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    // Exactly what `ConsensusFactory::new_staging_consensus` builds: the network's own config with
    // genesis skipped, over a database nothing has written to.
    let staging = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .skip_adding_genesis()
        .build();

    let (_lifetime, db) = kaspa_database::create_temp_db!(kaspa_database::prelude::ConnBuilder::default().with_files_limit(10));
    let (sender, _r) = async_channel::unbounded();
    // Constructing it is the whole assertion — the defect was a panic in `Consensus::new`.
    let consensus = crate::consensus::test_consensus::TestConsensus::with_db(db, &staging, sender);
    assert!(
        consensus.virtual_processor().palw_state_v2_store.read().tip_record().unwrap().is_none(),
        "and it is still stateless afterwards — the point is that staging is ALLOWED to be, not that \
         something quietly installed a tip to get past the guard"
    );
}

/// **And the guard actually refuses** — a ConsensusV2 consensus cannot be constructed over an empty
/// PALW store.
///
/// The test above proves the DEGRADED STATE is real; this proves the startup assertion fires in it.
/// Both halves are needed: a guard whose precondition is unreachable is decoration, and a
/// precondition with no guard is the bug.
#[test]
#[should_panic(expected = "PALW state store holds no tip")]
fn palw_v2_constructing_a_bundled_consensus_over_an_empty_store_panics() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();

    // One database, opened twice. The first build installs genesis AND the PALW tip; the store is
    // then emptied the way a pruned join or a `reindex_if_stale` leaves it. The second open is a
    // RESTART — `process_genesis` is off, but the database carries `past_pruning_points[0]`, so
    // this is a node resuming its own chain with its PALW state missing. It must refuse.
    let (_lifetime, db) = kaspa_database::create_temp_db!(kaspa_database::prelude::ConnBuilder::default().with_files_limit(10));
    let (sender, _r) = async_channel::unbounded();
    let first = crate::consensus::test_consensus::TestConsensus::with_db(db.clone(), &config, sender.clone());
    let _lt = first.init();
    {
        let mut store = first.virtual_processor().palw_state_v2_store.write();
        store.delete_tip_for_tests().expect("empty the store the way a pruned join leaves it");
    }
    drop(first);

    let resumed = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .skip_adding_genesis()
        .build();
    let _reopened = crate::consensus::test_consensus::TestConsensus::with_db(db, &resumed, sender);
}

/// **Audit M-01: one unauthenticated transaction used to slash a producer and every panel seat.**/// **Audit M-01: one unauthenticated transaction used to slash a producer and every panel seat.**
///
/// `ProducerDefaulted { claim, receipts: [] }` carried no signature of any kind, the acceptance
/// match had no arm for it (`_ => {}`), and the transition folded it — charging every seat
/// `claim.reserved` through `slash_silent_seats` and debiting the producer's bond through
/// `void_and_slash`. `validate_receipt_quorum_v2` — which checks seat membership, the ML-DSA-87
/// signature, dedup, the window AND the quorum — was written, tested, and had no caller anywhere.
///
/// This drives the acceptance layer directly, because that is the layer that was empty. Deleting
/// either half of the fix makes it pass again: the arm, or the exhaustive match that stops a new
/// object kind from slipping past without a decision.
#[tokio::test]
async fn palw_v2_an_unsigned_receipt_set_cannot_slash_anyone() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2 as Obj;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let (tip, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let claim = *state.claims_iter().next().expect("two blocks made two claims").0;
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: tip,
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 3,
        subsidy: 0,
    };

    // The attack, verbatim: name a real claim, carry nothing.
    for object in [Obj::ProducerDefaulted { claim, receipts: Vec::new() }, Obj::ReceiptLicensed { claim, receipts: Vec::new() }] {
        let err = vp
            .palw_v2_validate_objects(&state, &bundle.state, &point, std::slice::from_ref(&object))
            .expect_err("an unsigned receipt set must not be able to move a claim");
        assert!(err.contains("quorum"), "and the refusal must name the missing quorum: got {err}");
    }

    // **A retirement is authorised by the bond's own key.** It used to be refused outright, which
    // shut the door and locked every genesis bond's collateral in behind it. Now the check is the
    // one the refusal described, so the two ways of getting it wrong must both still fail: a bond
    // this chain does not have, and a real bond whose owner did not sign.
    let stranger = kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::tx::TransactionOutpoint::new(
        kaspa_consensus_core::tx::TransactionId::from_u64_word(0xB0),
        0,
    ));
    let err = vp
        .palw_v2_validate_objects(
            &state,
            &bundle.state,
            &point,
            &[Obj::BondRetireRequested { bond: stranger, signature: vec![0xEE; 8] }],
        )
        .expect_err("a retirement nobody signed must not release anyone's collateral");
    assert!(err.contains("not signed by the key it registered"), "got {err}");

    // And an EMPTY signature is refused a layer earlier, on the ride list, so the two locks are
    // still two — removing either does not open the door on its own.
    assert!(
        kaspa_consensus_core::palw_lifecycle_objects_v2::palw_lifecycle_object_may_ride_v2(&Obj::BondRetireRequested {
            bond: stranger,
            signature: Vec::new(),
        })
        .is_err(),
        "an unsigned retirement must not even ride"
    );
}

/// **A gossiped receipt pool assembles into exactly the object a block accepts** (launch
/// blockers: "what is still missing" — the submitter's consensus half, end to end).
///
/// The correspondence that must hold: `palw_v2_receipt_quorum_assemble` is what the panel service
/// submits, `palw_v2_validate_objects` is what the chain runs on the carried object, and both are
/// fed here from the same state — receipts signed with the REAL registry keys, polluted the way a
/// real gossip pool is (garbage signature, duplicate seat), against a claim whose panel the chain
/// derived itself. If the assembled object were ever one acceptance refuses, the submitter would
/// burn fees on transactions the chain drops; this is the test that says it cannot.
#[tokio::test]
async fn palw_v2_a_gossiped_receipt_pool_assembles_the_object_a_block_accepts() {
    use kaspa_consensus_core::palw_lifecycle_objects_v2::{
        PALW_LIFECYCLE_TX_VERSION_V2, PalwLifecycleTxPayloadV2, validate_palw_lifecycle_tx,
    };
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_panel_v2::{
        PALW_RECEIPT_V2_MLDSA87_CONTEXT, PalwReceiptVerdictV2, PalwSeatReceiptV2, palw_receipt_message_v2,
    };
    use kaspa_consensus_core::palw_state_v2::{PalwClaimPhaseV2, PalwConsensusObjectV2};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    // One claim, then enough chain for its anchor (accepted + 20) to pass and the DERIVED panel
    // binding to fire — the same automatic binding a real network runs.
    for _ in 0..26 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let (claim_id, _) = state
        .claims_iter()
        .find(|(_, c)| matches!(c.phase, PalwClaimPhaseV2::PanelBound { .. }))
        .expect("an early claim's panel has bound by now");
    let claim_id = *claim_id;
    let panel = state.panel(&claim_id).expect("a bound claim has a panel");
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );
    let signed_daa = ctx.consensus.get_virtual_daa_score();

    // Sign with the registry keys, resolved the way a seat resolves its own: by matching the
    // bond's REGISTERED key — never by assuming seat order.
    let sign_seat = |seat: &kaspa_consensus_core::palw_state_v2::PalwPanelSeatV2, verdict: PalwReceiptVerdictV2| {
        let bond = state.bond(&seat.bond).expect("a seat's bond is registered");
        let kp = (0..16u64)
            .map(TestConsensus::palw_v2_registry_keypair)
            .find(|kp| kp.verification_key.as_ref() == bond.pubkey.as_slice())
            .expect("a registry seat signs with a registry key");
        let message = palw_receipt_message_v2(network_domain, claim_id, verdict, signed_daa);
        let signature =
            libcrux_ml_dsa::ml_dsa_87::sign(&kp.signing_key, message.as_byte_slice(), PALW_RECEIPT_V2_MLDSA87_CONTEXT, [0u8; 32])
                .expect("ML-DSA-87 sign")
                .as_ref()
                .to_vec();
        PalwSeatReceiptV2 { claim: claim_id, verdict, seat_bond: seat.bond, signed_daa, signature }
    };
    let honest: Vec<PalwSeatReceiptV2> = panel.seats.iter().take(3).map(|s| sign_seat(s, PalwReceiptVerdictV2::Valid)).collect();

    // The pool as gossip delivers it: a forged receipt first (so a naive assembler chokes on it),
    // a duplicate of an honest seat, then the three honest ones.
    let mut forged = honest[0].clone();
    forged.signature = vec![0u8; forged.signature.len()];
    let pool = vec![forged, honest[0].clone(), honest[0].clone(), honest[1].clone(), honest[2].clone()];

    let object = vp.palw_v2_receipt_quorum_assemble_impl(claim_id, &pool).expect("three honest receipts are a quorum");
    let PalwConsensusObjectV2::ReceiptLicensed { claim, receipts } = &object else {
        panic!("a Valid quorum licenses; got {object:?}");
    };
    assert_eq!(*claim, claim_id);
    assert_eq!(receipts.len(), 3, "the forged receipt and the duplicate were dropped, the quorum kept");

    // The carrier the submitter builds is admissible at the transaction gate…
    let payload = borsh::to_vec(&PalwLifecycleTxPayloadV2 { version: PALW_LIFECYCLE_TX_VERSION_V2, object: object.clone() }).unwrap();
    validate_palw_lifecycle_tx(&payload, true).expect("the assembled object may ride a 0x4b transaction");

    // …and the OBJECT passes the acceptance validator at the same state — the correspondence.
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: signed_daa,
        blue_score: 27,
        subsidy: 0,
    };
    vp.palw_v2_validate_objects(&state, &bundle.state, &point, std::slice::from_ref(&object))
        .expect("what the assembler builds is what acceptance takes");

    // Below quorum: two honest receipts assemble nothing, however clean.
    assert!(
        vp.palw_v2_receipt_quorum_assemble_impl(claim_id, &honest[..2]).is_none(),
        "two receipts are not a quorum and must not become an object"
    );
}

/// **The producer contract reads the LIVE chain, not the genesis bundle** (ADR-0042).
///
/// The harness's own carriage builder reads the class target out of the bundle, which is correct
/// exactly once — at genesis, before anything has been produced. A real producer cannot: the
/// per-class retarget moves the target, the epoch counter moves under every block it lands, and a
/// producer that read either from a file would build attempts the chain refuses and be told only
/// "ticket above target". So the facts come from the state store at virtual's selected parent,
/// and this asserts they MOVE — four blocks in, the epoch counter says four.
///
/// It also asserts the two halves agree on `pwu`, which is the equality admission item 6 turns
/// into a refusal. Nothing else in the tree compares them; they were written a month apart.
#[tokio::test]
async fn palw_v2_producer_facts_track_the_chain_the_blocks_actually_built() {
    use kaspa_consensus_core::api::ConsensusApi;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    let bond = kaspa_consensus_core::tx::TransactionOutpoint::new(kaspa_consensus_core::tx::TransactionId::from_u64_word(0xB0), 0);

    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let facts = ctx
        .consensus
        .palw_producer_facts_v2(bundle.base_class_id, Some(bond))
        .expect("a ConsensusV2 network answers for its own base class");
    assert_eq!(facts.chain_point, ctx.consensus.get_sink(), "the facts are read where a template would build");
    assert_eq!(facts.epoch_produced_blocks, 4, "the epoch counter moved with the blocks, which a bundle cannot do");
    assert!(facts.has_epoch_room(), "the floor's budget is not spent by four blocks");

    let bond_facts = facts.bond.as_ref().expect("the genesis bond is registered");
    assert_eq!(
        bond_facts.registered_pubkey,
        crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey(),
        "the key a producer must sign with is the one the chain registered"
    );
    assert_eq!(facts.ready_to_produce(&bond_facts.registered_pubkey.clone()), Ok(()), "a fifth block is producible");
    assert!(bond_facts.reserved_exposure > 0, "four open claims reserve exposure — the ceiling is a live number");

    // The two halves, on the same number. The harness computes `pwu` from the bundle; the contract
    // computes it from the state at the tip. On a chain that has not retargeted they must be
    // equal, and the equality is what admission item 6 enforces on every block.
    let carriage_pwu = {
        let header = ctx.build_block_template(0, 0).block.header.clone();
        let wire = ctx.consensus.palw_v2_test_carriage(&header);
        kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(&wire)
            .expect("the harness emits a carriage")
            .attempt
            .pwu
    };
    assert_eq!(facts.pwu, carriage_pwu, "the producer contract and the carriage builder derive one pwu");
}

#[tokio::test]
async fn palw_v2_the_exposure_ceiling_bites_when_reservations_are_real() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_at_min_collateral(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // As many as the ceiling admits — derived, not typed.
    let fits = palw_v2_claims_that_fit(&bundle);
    assert!(fits >= 2, "the fixture must admit more than one claim for the ceiling to be the thing under test");
    for _ in 0..fits {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let sink_at_ceiling = ctx.consensus.get_sink();
    {
        let store = ctx.consensus.virtual_processor().palw_state_v2_store.read();
        let (_, state) = store.load_tip(&bundle.state).unwrap().unwrap();
        assert_eq!(
            state.claims_iter().count() as u64,
            fits,
            "every admitted claim is still open — nothing has matured to release one"
        );
    }

    // The next does not: its claim would push the bond past `collateral × 500‰`, and no claim
    // has resolved to give the room back. The block exists in the DAG; it is not the chain.
    ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    assert_eq!(
        ctx.consensus.get_sink(),
        sink_at_ceiling,
        "one claim past the ceiling exceeds the bond's exposure, so its block cannot become the sink"
    );
}

/// **ADR-0042 Decision 3c, re-decided: what P0 changed, and what it did not** (audit item).
///
/// The audit reads 3c's deferral as resting on "only the bond holder can mint valid-signature
/// siblings", and concludes that verifying the signature removed the reason. Reading §A2, the
/// load-bearing reason is a different one and it **survives**: with identity = `attempt_id`
/// (signature excluded), any third party flips one signature bit and relays a copy with the SAME
/// block id and an invalid witness. The first-seen copy fails admission and the id lands in
/// known-invalid caches, after which the honest block — same id, arriving second — is refused
/// unseen. One bit censors one block, network-wide, at zero cost.
///
/// Verifying the signature does not remove that primitive; it is what ARMS it. An unverified
/// witness could not fail admission, so the poisoning needed the check to exist. **3c's identity
/// half therefore stays deferred, and its precondition is unchanged: a pipeline path that rejects
/// a witness-mutated carrier WITHOUT marking the block id invalid.**
///
/// What P0 did change is the residual on the identity the tree actually keeps — raw carrier bytes.
/// Before it, ANY third party could mint valid siblings of one solved PoW. Now only the bond
/// holder can, because only it can sign; ML-DSA-87 signing here is hedged with caller-supplied
/// randomness, so it can mint as many as it likes at one signature each. §A2 asserts the bound on
/// that — "self-malleation buys DAG spam ..., never a second paid claim" — and nothing measured
/// it. This does.
#[tokio::test]
async fn palw_v2_a_bond_holders_own_resignature_buys_a_block_but_never_a_second_claim() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // One honest block, and the SAME attempt signed a second time by the same bonded key. The
    // attempt is untouched, so both carry one `attempt_id` and one solved ticket.
    let template = ctx.build_block_template(11, ctx.simulated_time + 1);
    let honest = template.block.clone();
    let mut sibling = template.block.clone();
    let mut envelope =
        kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(&sibling.header.palw_commitment).unwrap();
    let attempt_id = kaspa_consensus_core::palw_attempt_v2::attempt_id_v2(&envelope.attempt);
    envelope.signature = libcrux_ml_dsa::ml_dsa_87::sign(
        &TestConsensus::palw_v2_harness_keypair().signing_key,
        attempt_id.as_byte_slice(),
        kaspa_consensus_core::palw_attempt_v2::PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
        // Different hedging randomness — a DIFFERENT signature over the SAME message, and every
        // bit of it verifies.
        [0xA5u8; 32],
    )
    .expect("the bond holder can always sign again")
    .as_ref()
    .to_vec();
    let honest_signature =
        kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(&honest.header.palw_commitment).unwrap().signature;
    assert_ne!(envelope.signature, honest_signature, "ML-DSA-87 signing here is hedged — the fixture must actually differ");
    sibling.header.palw_commitment = envelope.encode_wire();
    sibling.header.finalize();

    // Raw-carrier-bytes identity: the sibling is a DIFFERENT block, which is the property §A2
    // chose. (Under 3c's identity half it would share the honest block's id, which is the
    // censorship shape.)
    assert_ne!(sibling.header.hash, honest.header.hash, "the signature is inside block identity, by design");
    let (honest_hash, sibling_hash) = (honest.header.hash, sibling.header.hash);

    ctx.validate_and_insert_block(honest.to_immutable()).await;
    ctx.validate_and_insert_block(sibling.to_immutable()).await;

    // **The bound, measured.** Two blocks exist; one claim does. The second is refused by
    // `DuplicateAttempt` / `DuplicateClaim` — the claim is keyed on `attempt_id`, which the
    // signature is deliberately outside of, so re-signing buys a DAG block and nothing else.
    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert!(state.claim(&attempt_id).is_some(), "the attempt did produce its one claim");
    let for_this_attempt = state.claims_iter().filter(|(id, _)| **id == attempt_id).count();
    assert_eq!(for_this_attempt, 1, "one attempt, one claim, however many signatures were spent on it");

    // And only one of the two can be the sink, because only one of them carries the claim.
    let sink = ctx.consensus.get_sink();
    assert!(sink == honest_hash || sink == sibling_hash);
}

/// **The attempt's signature is checked on the live path — and one solved PoW is one block.**
///
/// The pipeline called `check_palw_attempt_admission_v2`, which takes no verifier and cannot take
/// one: its item 2 compares the carried `executor_pubkey` against the bond record's key, and both
/// are public. So an attempt was admitted on the strength of naming an Active bond, and the
/// `signature` field was bytes nobody read. Two consequences, both asserted here:
///
/// * **anyone could mine under anyone's stake** — the bond outpoint and the key are on chain, so
///   an attacker copies both, writes any bytes into `signature`, and solves the PoW;
/// * **one PoW minted unlimited blocks** — the signature is deliberately outside `attempt_id_v2`
///   and therefore outside the PoW digest (ADR-0042 Decision 3c), while block identity hashes the
///   raw carrier bytes. Unverified, flipping one signature bit yields a different, equally valid
///   block at zero marginal cost.
///
/// The fixture that could not see this was the harness itself: it carried `vec![7u8; 32]` as an
/// ML-DSA-87 public key and `vec![0x5A; ..]` as an ML-DSA-87 signature, and every V2 test passed.
/// It now holds a real key pair, the genesis bond registers that key, and it signs the attempt id
/// after the ticket search — so this test's forgery is a forgery of something real.
#[tokio::test]
async fn palw_v2_a_forged_attempt_signature_cannot_become_the_sink() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let consensus = TestConsensus::new(&config);
    let mut ctx = TestContext::new(consensus);
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let sink_before = ctx.consensus.get_sink();

    // Everything an honest miner produces — the right bond, the registered key, a derived pwu, a
    // winning class ticket — and ONE flipped signature byte. Nothing else moves, so nothing else
    // can be the reason it is refused.
    let template = ctx.build_block_template(11, ctx.simulated_time + 1);
    let mut forger = template.block.clone();
    let mut envelope =
        kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(&forger.header.palw_commitment).unwrap();
    let honest_id = kaspa_consensus_core::palw_attempt_v2::attempt_id_v2(&envelope.attempt);
    envelope.signature[0] ^= 0x01;
    forger.header.palw_commitment = envelope.encode_wire();
    forger.header.finalize();
    let forged_hash = forger.header.hash;

    // The attempt itself is untouched: the id the PoW commits to is the honest one, which is
    // exactly why an unverified signature was free to vary.
    let reread = kaspa_consensus_core::palw_attempt_v2::PalwAttemptEnvelopeV2::decode_wire(&forger.header.palw_commitment).unwrap();
    assert_eq!(
        kaspa_consensus_core::palw_attempt_v2::attempt_id_v2(&reread.attempt),
        honest_id,
        "the forgery moves no priced field — only the signature, which is what makes it free"
    );

    // **It is refused at the DOOR now, not at the chain walk** (launch blockers §5).
    //
    // The chain-walk check kept a forgery from becoming the sink, and that was thought sufficient.
    // It was not: the block was still valid to relay, so every peer accepted, stored and forwarded
    // it — and since the signature sits outside `commitment_root_v2` while the block-identity
    // digest hashes the raw carrier bytes, ONE solved proof of work minted an unbounded number of
    // distinct such blocks, a byte flip apiece. Never chain, and never free for anybody else.
    let outcome = ctx.consensus.validate_and_insert_block(forger.to_immutable()).virtual_state_task.await;
    let err = outcome.expect_err("a forged signature must not even enter the DAG");
    assert!(format!("{err}").contains("signature"), "and the refusal must name the signature rather than a digest mismatch: {err}");
    assert_eq!(ctx.consensus.get_sink(), sink_before, "the sink is untouched");
    assert_ne!(forged_hash, sink_before);
}

/// BASE-0's own reachable set, so the fixture cannot certify itself (see
/// `base0_reaches_only_kernels_this_build_adjudicates`).
fn palw_v2_test_catalog() -> kaspa_consensus_core::palw_mode_v2::PalwClassCatalogV2 {
    use kaspa_consensus_core::palw_mode_v2::{PalwClassCatalogEntryV2, PalwClassCatalogV2};
    PalwClassCatalogV2::new(vec![PalwClassCatalogEntryV2 {
        class_id: kaspa_hashes::Hash64::from_u64_word(1),
        artifact_root: kaspa_hashes::Hash64::from_u64_word(0xA7),
        max_step_leaf_count: 1 << 16,
        canonical_step_leaf_count: 4_096,
        // The derived close price the boot gate compares against the ruleset's ceilings. A nominal
        // one here: this fixture exists to exercise the acceptance path, not the cost bound, and a
        // catalog whose entry claimed a real class's cost would be asserting something this
        // fixture's `class_id` does not stand behind.
        court_cost: kaspa_consensus_core::palw_class_admission_v2::PalwCourtCostV1 {
            max_close_bytes: 1,
            max_terminal_macs: 1,
            max_operand_count: 1,
        },
        reachable_kernels: kaspa_consensus_core::palw_step_refute::KDESC_BASE0_ALL
            .iter()
            .map(|d| kaspa_consensus_core::palw_step::kernel_semantics_id_v1(d))
            .collect(),
    }])
    .expect("a well-formed catalog")
}

fn palw_v2_test_bundle(
    catalog: &kaspa_consensus_core::palw_mode_v2::PalwClassCatalogV2,
) -> kaspa_consensus_core::palw_mode_v2::PalwConsensusParamsV2 {
    // The bond and the class the harness's own attempt carriage names
    // (`TestConsensus::palw_v2_test_carriage`). They must agree: admission refuses an attempt
    // whose bond the chain does not have, and the genesis registration list is the only place a
    // V2 network gets one.
    let mut b = kaspa_consensus_core::palw_fp_devnet_v3::palw_fp_devnet_bundle_v3(
        kaspa_hashes::Hash64::from_u64_word(1),
        catalog.root(),
        kaspa_hashes::Hash64::from_u64_word(0xC0757),
        4_096,
        kaspa_hashes::Hash64::from_u64_word(0xA7),
        {
            // Row 0 is the harness's own bond, carrying its REAL verification key: admission item 2
            // compares the attempt's carried key against this registration's, and the signature
            // check behind it is only meaningful if the key it authorises is the one the chain
            // registered. The rest are the panel's — a registry that cannot seat one is refused by
            // `verify_palw_genesis_v2`, and with one bond no claim could ever be licensed.
            let mut registry = kaspa_consensus_core::palw_fp_devnet_v3::palw_devnet_bond_registry_v1(
                kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1(),
            );
            registry[0].pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey();
            registry[0].operator_pubkey = vec![21u8; 8];
            // Every OTHER row gets a real ML-DSA-87 identity too. They carried four-byte
            // placeholders, so no fixture could sign a panel receipt — which is part of why the
            // missing `ReceiptLicensed` edge went unnoticed for so long.
            for (i, row) in registry.iter_mut().enumerate().skip(1) {
                row.pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_registry_pubkey(i as u64);
            }
            registry
        },
    )
    .expect("the devnet bundle validates");
    b.class_catalog_root = catalog.root();
    b
}

/// The same fixture with a bond sized for a LONGER chain.
///
/// The bundle's own `MIN_COLLATERAL_SOMPI` funds four concurrent claims, which is the ruleset's
/// deliberate rate limit and not a number to edit. It only became visible once the pipeline
/// started folding each block's attempt into the state: until then no claim was ever created, so
/// nothing was ever reserved, so the per-bond exposure ceiling could not be reached however long
/// a fixture mined. The first test to mine five chain blocks found it immediately.
///
/// A test that wants a chain longer than four blocks therefore has to fund it, exactly as an
/// operator would. `palw_v2_the_exposure_ceiling_bites_when_reservations_are_real` keeps the
/// default and asserts the refusal, so raising it here hides nothing.
/// The fixture with every bond at the POLICY FLOOR rather than the derived bind-window figure.
///
/// `palw_fp_devnet_bundle_v3` now sizes a genesis bond to carry a claim through `window_bind`,
/// because a bond that cannot is a chain that stops — but a test that wants to WATCH the exposure
/// ceiling refuse a block needs a deliberately thin one. The floor is a legal declaration (it is
/// `PalwBondParamsV2`'s own minimum), so this is a thin network rather than an invalid one.
fn palw_v2_test_bundle_at_min_collateral(
    catalog: &kaspa_consensus_core::palw_mode_v2::PalwClassCatalogV2,
) -> kaspa_consensus_core::palw_mode_v2::PalwConsensusParamsV2 {
    use kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2;
    let mut b = palw_v2_test_bundle(catalog);
    let floor = b.bond.min_collateral_sompi();
    for object in b.genesis_objects.iter_mut() {
        if let PalwConsensusObjectV2::BondRegistered { collateral, .. } = object {
            *collateral = floor;
        }
    }
    b
}

/// How many concurrent claims this fixture's bond can hold before the exposure ceiling refuses
/// one. Derived, because the answer is a function of the pricing and the two tests that asserted a
/// literal "four" both broke the moment the pricing was corrected — which is the fixture asserting
/// an arithmetic accident rather than the rule it is named for.
fn palw_v2_claims_that_fit(bundle: &kaspa_consensus_core::palw_mode_v2::PalwConsensusParamsV2) -> u64 {
    use kaspa_consensus_core::palw_state_v2::{PalwConsensusObjectV2, PalwPwuRuleV2};
    let reserve = bundle
        .genesis_objects
        .iter()
        .find_map(|o| match o {
            PalwConsensusObjectV2::ClassRegistered {
                pwu_rule: PalwPwuRuleV2::DerivedV1 { pwu_per_inference },
                slash_value_per_pwu,
                ..
            } => Some(*pwu_per_inference as u128 * *slash_value_per_pwu as u128),
            _ => None,
        })
        .expect("the fixture bundle registers its class with a derived pwu rule");
    let collateral = bundle
        .genesis_objects
        .iter()
        .find_map(|o| match o {
            PalwConsensusObjectV2::BondRegistered { collateral, .. } => Some(*collateral as u128),
            _ => None,
        })
        .expect("the fixture bundle registers a bond");
    let ceiling = collateral * bundle.admission.max_exposure_ratio_permille() as u128 / 1000;
    (ceiling / reserve) as u64
}

fn palw_v2_test_bundle_funded_for(
    catalog: &kaspa_consensus_core::palw_mode_v2::PalwClassCatalogV2,
    concurrent_claims: u64,
) -> kaspa_consensus_core::palw_mode_v2::PalwConsensusParamsV2 {
    use kaspa_consensus_core::palw_state_v2::{PalwConsensusObjectV2, PalwPwuRuleV2};
    let mut b = palw_v2_test_bundle(catalog);
    // Read off the bundle's OWN class registration rather than typed, so a ruleset change moves
    // the fixture with it instead of silently under-funding it. A claim reserves
    // `pwu_per_inference × slash_value_per_pwu` — one inference's worth, NOT the derived `pwu`,
    // which carries an `expected_attempts(target)` factor the ceiling must not depend on
    // (`palw_state_v2::palw_exposure_pwu_v1`).
    let reserve_per_claim = b
        .genesis_objects
        .iter()
        .find_map(|o| match o {
            PalwConsensusObjectV2::ClassRegistered {
                pwu_rule: PalwPwuRuleV2::DerivedV1 { pwu_per_inference },
                slash_value_per_pwu,
                ..
            } => Some(pwu_per_inference * slash_value_per_pwu),
            _ => None,
        })
        .expect("the fixture bundle registers its class with a derived pwu rule");
    // The ceiling is `collateral × 500‰`, so N concurrent claims need `2 × N × reserve` — but never
    // less than the bundle's own bond floor, which `CollateralBelowMinimum` refuses at genesis. The
    // clamp is not cosmetic: correcting the exposure pricing halved this figure and put the funded
    // fixtures under the floor, so a helper named "funded for N" was producing registries the chain
    // will not accept at all.
    let floor = b.bond.min_collateral_sompi();
    for object in b.genesis_objects.iter_mut() {
        if let PalwConsensusObjectV2::BondRegistered { collateral, .. } = object {
            *collateral = (2 * concurrent_claims * reserve_per_claim).max(floor);
        }
    }
    b
}

#[tokio::test]
async fn antichain_merge_test() {
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
        })
        .build();

    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Build a large 32-wide antichain
    ctx.build_block_template_row(0..32)
        .validate_and_insert_row()
        .await
        .assert_tips()
        .assert_virtual_parents_subset()
        .assert_valid_utxo_tip();

    // Mine a long enough chain s.t. the antichain is fully merged
    for _ in 0..32 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    ctx.assert_tips_num(1);
}

/// kaspa-pq Phase 10/11 (ADR-0009/0013): first overlay-ACTIVE integration
/// test. With `dns_params = Some` and `dns_activation_daa_score = 0`, the
/// validator-reward code paths that are dormant on every shipping network —
/// the per-block `ActiveBondView` walk, the §B.4 eligibility check, the
/// coinbase reward fan-out (construction + validation), the cross-block
/// uniqueness walk over the rewarded-keys store, and the template
/// ineligible-shard pre-filter — all RUN here (with empty data, since this
/// chain carries no bonds or attestations). The chain must still mine and
/// validate to a valid UTXO tip, proving that activating the overlay does not
/// break block production or validation and that the empty-reward coinbase is
/// reproduced byte-for-byte by the validation path.
///
/// (A full reward-bearing e2e — a real bond tx, an ML-DSA-signed attestation,
/// and a non-empty reward coinbase — needs funded UTXO-valid overlay txs and
/// is a separate harness effort; the reward/eligibility/uniqueness logic is
/// already unit-tested.)
#[tokio::test]
async fn dns_overlay_active_chain_validates() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            // Activate the DNS overlay from genesis (reuse the self-consistent
            // devnet DNS parameters, with activation pulled down to 0).
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            p.dns_params = Some(dns);
        })
        .build();

    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Mine + validate a chain with the overlay active end-to-end.
    for _ in 0..10 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    ctx.assert_tips_num(1);
}

/// kaspa-pq ADR-0018 "本格版" (PoS-v2, Phase 2): overlay **and** v2-economics ACTIVE integration
/// test. With `dns_activation_daa_score = 0` AND `pos_v2_activation_daa_score = 0` (plus shrunk
/// windows so epochs actually bury within a short chain), the full v2 machinery RUNS on every
/// block: the fence-gated 70/30 participation/quality split, the per-block quality-pool
/// persistence (`block_quality_pool_store`, written non-empty here since the §F carve funds a
/// validator pool even with no attestations), the per-epoch accumulator recompute + finalization
/// (`update_epoch_accumulator`), and the deferred quality-bonus payout
/// (`deferred_quality_bonus_outputs` — incl. the finalization-crossing detection and the φS gate).
///
/// This chain carries no bonds/attestations, so every *reward* set is empty — but the code paths
/// execute, write the stores, and the chain must still mine and validate to a valid UTXO tip.
/// Because the validation path rebuilds the coinbase and rejects any mismatch, reaching a valid
/// UTXO tip proves the v2 economics neither break block production nor desynchronise coinbase
/// construction vs validation. (A reward-bearing e2e — real bonds + attestations paid a non-empty
/// bonus — needs the funded-bond DAG harness, DAG-2.)
#[tokio::test]
async fn pos_v2_active_empty_chain_validates() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            // Activate the v2 economics from genesis and shrink the finalization window
            // (= reward_uniqueness_window + max_reorg_horizon = 4) so epochs bury and the
            // deferred-bonus crossing fires within a short chain.
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 2;
            dns.max_reorg_horizon_blocks = 2;
            p.dns_params = Some(dns);
        })
        .build();

    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // threshold(E) = (E+1)·2 + 4, so by ~daa 12 several epochs have finalized and the deferred
    // quality-bonus path has fired (with empty included sets — exercised, not paid).
    for _ in 0..12 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    ctx.assert_tips_num(1);
}

/// kaspa-pq ADR-0018 §G DAG-2 (funded-bond milestone — retires the "fund a bond
/// from a coinbase UTXO" wall). With the overlay + v2 economics ACTIVE, a real
/// ML-DSA-87 keypair mines a coinbase; after maturity its output is SPENT into a
/// funded stake-bond tx (output-0 = locked stake, input-0 signed over the v2 tx
/// sighash under `MLDSA87_TX_CONTEXT`). The block carrying the bond must reach a
/// valid UTXO tip — proving the script engine (`OpCheckSigMlDsa87`) accepts the
/// real ML-DSA-87 P2PKH spend through full consensus validation, the precondition
/// for the reward-bearing / slashing DAG e2e (DAG-2..6).
#[tokio::test]
async fn pos_v2_funded_bond_chain_validates() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            // Shrink coinbase maturity so the funding coinbase is spendable within a short chain.
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 2;
            dns.max_reorg_horizon_blocks = 2;
            p.dns_params = Some(dns);
        })
        .build();

    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // A known validator/funding key; its coinbase P2PKH spk.
    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    // 1) Mine a run of blocks whose coinbase pays K. In Kaspa a block's coinbase
    //    rewards the blocks it MERGES (each merged block's reported miner script),
    //    not its own miner — so K's reward for the funding block b1 (which merges
    //    only genesis → 0 reward) appears in the coinbase of the block that merges
    //    b1 (the harvest block b2).
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let harvest = ctx.mine_block(k_miner.clone(), vec![]).await;
    let coinbase = &harvest.transactions[0];
    let coinbase_id = coinbase.id();
    let coinbase_daa = harvest.header.daa_score;
    let (idx, out) = coinbase
        .outputs
        .iter()
        .enumerate()
        .find(|(_, o)| o.script_public_key == k_spk)
        .expect("the harvest coinbase must pay the known key");
    let coinbase_outpoint = TransactionOutpoint::new(coinbase_id, idx as u32);
    let coinbase_value = out.value;
    assert!(coinbase_value > 200_000, "coinbase value must cover the bond + fee");

    // 2) Mine filler blocks so the harvested coinbase matures (coinbase_maturity = 2).
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    // 3) Spend the matured coinbase into a funded, ML-DSA-87-signed stake-bond tx.
    let amount = coinbase_value - 100_000; // small fee; bond almost the whole coinbase
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _validator_id, _reward_payload) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_outpoint, coinbase_value, coinbase_daa, amount, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();

    // 4) Mine the block carrying the bond tx; it must reach a valid UTXO tip.
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert!(bond_block.transactions.iter().any(|t| t.id() == bond_tx_id), "the funded stake-bond tx must be included in the block");
    assert_eq!(
        ctx.consensus.block_status(bond_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the block carrying the funded ML-DSA-87 stake-bond spend must be UTXO-valid (construction == validation)"
    );
    ctx.assert_valid_utxo_tip();
}

/// ADR-0018 §F bridge wiring — one scenario of the finality-fee e2e: fund a key,
/// spend its matured coinbase into a deposit-lock tx (fee 100_000), mine it, then
/// harvest the next block's coinbase. Returns `(worker_output_value,
/// lock_block_subsidy)` — the worker payout for the block that carried the bridge tx,
/// and that block's subsidy (parsed from its coinbase payload: blue_score u64 LE ‖
/// subsidy u64 LE ‖ …).
///
/// `evm_active` toggles `evm_activation_daa_score` (0 vs u64::MAX). evm-active
/// templates COMMIT to the header timestamp (the EVM execution env derives from it),
/// so in that mode blocks are inserted exactly as templated — no
/// `TestContext::mine_block` timestamp/nonce mutation (the same insertion pattern the
/// EVM lane e2e tests use); the inert mode exercises the ordinary v1 mine path.
async fn finality_fee_bridge_scenario(finality_fence: u64, evm_active: bool) -> (u64, u64) {
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            // Shrink coinbase maturity so the funding coinbase is spendable quickly.
            p.coinbase_maturity = 2;
            // The classification is doubly gated: the §F fence AND EVM-lane activation
            // (the bridge only exists on an EVM-active net). MAINNET_PARAMS is EVM-inert
            // (u64::MAX) by default.
            p.evm_activation_daa_score = if evm_active { 0 } else { u64::MAX };
            let mut dns = p.dns_params.clone().unwrap();
            dns.finality_fee_activation_daa_score = finality_fence;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Insert one block: template-as-is when evm-active (timestamp is commitment-bound),
    // else the ordinary simulated-time mine path.
    async fn mine(ctx: &mut TestContext, evm_active: bool, miner: MinerData, txs: Vec<Transaction>) -> Block {
        if evm_active {
            let t =
                ctx.consensus.build_block_template(miner, Box::new(OnetimeTxSelector::new(txs)), TemplateBuildMode::Standard).unwrap();
            let block = t.block.to_immutable();
            ctx.validate_and_insert_block(block.clone()).await;
            block
        } else {
            ctx.mine_block(miner, txs).await
        }
    }

    // Fund: harvest a coinbase paying the known key K (a block's coinbase rewards
    // the blocks it MERGES, so K's reward for b1 appears in the harvest block).
    let seed = [0x5Au8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = mine(&mut ctx, evm_active, k_miner.clone(), vec![]).await;
    let harvest = mine(&mut ctx, evm_active, k_miner.clone(), vec![]).await;
    let coinbase = &harvest.transactions[0];
    let (idx, out) = coinbase
        .outputs
        .iter()
        .enumerate()
        .find(|(_, o)| o.script_public_key == k_spk)
        .expect("the harvest coinbase must pay the known key");
    let coinbase_outpoint = TransactionOutpoint::new(coinbase.id(), idx as u32);
    let (coinbase_value, coinbase_daa) = (out.value, harvest.header.daa_score);
    assert!(coinbase_value > 200_000, "coinbase must cover the lock + fee");

    // Mature the coinbase (coinbase_maturity = 2).
    for _ in 0..5 {
        mine(&mut ctx, evm_active, new_miner_data(), vec![]).await;
    }

    // The bridge tx: matured coinbase → one EVM_DEPOSIT_LOCK output, fee 100_000.
    let lock_tx = dns_harness::funded_signed_deposit_lock_tx(
        seed,
        coinbase_outpoint,
        coinbase_value,
        coinbase_daa,
        ctx.consensus.params().storage_mass_parameter,
    );
    let lock_tx_id = lock_tx.id();

    // Mine it under a distinct miner spk so its worker payout is findable.
    let lock_miner_spk = p2pkh_mldsa87_spk(&[0x33u8; 64]);
    let lock_block = mine(&mut ctx, evm_active, MinerData::new(lock_miner_spk.clone(), vec![]), vec![lock_tx]).await;
    assert!(lock_block.transactions.iter().any(|t| t.id() == lock_tx_id), "the bridge tx must be included");
    assert_eq!(
        ctx.consensus.block_status(lock_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the block carrying the deposit-lock tx must be UTXO-valid (construction == validation)"
    );
    // The lock block's subsidy, from its coinbase payload (blue_score ‖ subsidy ‖ …).
    let payload = &lock_block.transactions[0].payload;
    let subsidy = u64::from_le_bytes(payload[8..16].try_into().unwrap());

    // Harvest: the next block's coinbase pays the lock block's worker share.
    let harvest2 = mine(&mut ctx, evm_active, new_miner_data(), vec![]).await;
    ctx.assert_valid_utxo_tip();
    let worker_out = harvest2.transactions[0]
        .outputs
        .iter()
        .find(|o| o.script_public_key == lock_miner_spk)
        .expect("the next coinbase must pay the lock block's miner")
        .value;
    (worker_out, subsidy)
}

/// kaspa-pq ADR-0018 §F bridge wiring e2e (EVM-active net): an accepted L1 tx that
/// CREATES an `EVM_DEPOSIT_LOCK` output (ADR-0020 §9.2 bridge deposit) is
/// **finality-class** — its fee is split at the validator-primary finality ratios
/// (Worker 25%) instead of the normal-tx ratios (Worker 90%) — through the REAL
/// template→validate coinbase path over a chain (classification at
/// `calculate_utxo_state`, payout via `expected_coinbase_transaction`; every mined
/// block reaching `StatusUTXOValid` proves construction == validation). The fenced
/// twin (`finality_fee_activation_daa_score = u64::MAX`) runs the identical chain
/// shape and pays the Worker the normal 90% — the exact pre-wiring math — proving the
/// §F fence isolates the change. evm-feature-gated: an evm-active template requires
/// the executor (a non-evm build refuses evm-active blocks by design).
#[tokio::test]
#[cfg(feature = "evm")]
async fn finality_fee_bridge_tx_pays_validator_primary_split() {
    use kaspa_consensus_core::dns_finality::{split_block_subsidy, split_finality_fees, split_normal_tx_fees};
    kaspa_core::log::try_init_logger("info");

    // Active fence (0, the PRODUCTION preset value): the 100_000 bridge fee splits at
    // the finality ratios — the Worker gets 25%, the Validator share (75%) funds the
    // §E pool (don't-mint burned here: no bonded validators).
    let (worker_active, subsidy_a) = finality_fee_bridge_scenario(0, true).await;
    // Inert §F fence: the same chain shape pays the normal-tx 90% — the pre-wiring math.
    let (worker_inert, subsidy_b) = finality_fee_bridge_scenario(u64::MAX, true).await;
    assert_eq!(subsidy_a, subsidy_b, "identical chain shape ⇒ identical lock-block subsidy");

    let dns = MAINNET_PARAMS.dns_params.clone().unwrap();
    let fs = &dns.reward_params.fee_split.clone();
    let worker_base = split_block_subsidy(subsidy_a, fs).worker_base_sompi;
    assert_eq!(
        worker_active,
        worker_base + split_finality_fees(100_000, fs).worker_sompi,
        "bridge-tx fee pays the Worker the FINALITY share (25%)"
    );
    assert_eq!(
        worker_inert,
        worker_base + split_normal_tx_fees(100_000, fs).worker_sompi,
        "below the §F fence the same fee pays the Worker the NORMAL share (90%) — byte-identical to pre-wiring"
    );
    assert_eq!(
        worker_inert - worker_active,
        split_normal_tx_fees(100_000, fs).worker_sompi - split_finality_fees(100_000, fs).worker_sompi,
        "the Worker delta is exactly the normal→finality reclassification (the Validator gains it)"
    );
}

/// kaspa-pq ADR-0018 §F bridge wiring — the EVM-activation gate: deposit-lock OUTPUTS
/// are consensus-legal on every net (the output-class exemption is unconditional),
/// but on an EVM-INERT net (`evm_activation_daa_score = u64::MAX` — mainnet today)
/// the classification must NOT fire even with the §F fence at 0: the lock-bearing
/// tx's fee stays normal-class (Worker 90%), byte-identical to the pre-wiring math.
/// Without this gate a miner on an EVM-inert net could self-include a never-claimable
/// lock tx and reroute fees into the §E pool. Runs on the default (non-evm) build —
/// inert nets produce ordinary v1 blocks.
#[tokio::test]
async fn finality_fee_inert_on_evm_inert_net() {
    use kaspa_consensus_core::dns_finality::{split_block_subsidy, split_normal_tx_fees};
    kaspa_core::log::try_init_logger("info");

    // §F fence ACTIVE (0, the production value) but the EVM lane INERT.
    let (worker_out, subsidy) = finality_fee_bridge_scenario(0, false).await;
    let dns = MAINNET_PARAMS.dns_params.clone().unwrap();
    let fs = &dns.reward_params.fee_split.clone();
    assert_eq!(
        worker_out,
        split_block_subsidy(subsidy, fs).worker_base_sompi + split_normal_tx_fees(100_000, fs).worker_sompi,
        "on an EVM-inert net a lock-bearing tx's fee stays NORMAL-class (Worker 90%) — the EVM gate holds"
    );
}

/// kaspa-pq ADR-0018 §G DAG-2 (reward-bearing e2e): the full overlay + v2 reward
/// path over a real BlockDAG. A funded ML-DSA-87 bond is created (as in the funding
/// milestone), then the validator ML-DSA-signs a recent attestation; the block that
/// includes the attestation shard must pay the validator a non-empty §E
/// participation reward in its coinbase AND validate to a UTXO-valid tip — proving
/// the reward fan-out (eligibility → distribution → coinbase) is
/// construction == validation with real bonds + attestations, not just by unit test.
#[tokio::test]
async fn pos_v2_reward_bearing_attestation_validates() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::{Hash64, dns_finality::ready_epoch_from_tip_blue_score};
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            // Reward recency must comfortably cover the canonical anchor, which is buried by
            // attestation_lag + backoff below the tip (blue_score ~ DAA on this linear chain).
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            // DNS v3 blue_score epochs: small so an epoch buries within this short chain.
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // A known validator/funding key.
    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    // Fund: b1 funds, then two harvest blocks — h_a pays K for b1, h_b pays K for h_a.
    // coinbase_a funds the bond; coinbase_b funds the attestation shard tx (a 0-input
    // shard tx is rejected by the isolation `NoTxInputs` check, so production funds it).
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _vid, reward_payload) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid, "the bond block must be UTXO-valid");
    assert_eq!(reward_payload, k_payload, "rewards pay back to K");

    // Bury several blue_score epochs past the bond so a ready, bond-active canonical anchor
    // exists — DNS v3 pays the §E reward only to an attestation naming the canonical anchor.
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let lr = ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(lr, sink, &dns).expect("canonical anchor for the ready epoch")
    };

    // The validator ML-DSA-signs the CANONICAL anchor for a ready epoch (DNS v3). net_id =
    // genesis hash (Addendum A.3); VSC is a domain-separation field only (P-1D zero).
    let att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_tx = dns_harness::funded_signed_shard_tx(seed, coinbase_b, value_b, daa_b, att, storage_mass_parameter);

    // The block that includes the attestation shard pays the validator the §E
    // participation reward (to owner_reward_spk_payload == k_spk) and must validate.
    let reward_block = ctx.mine_block(new_miner_data(), vec![shard_tx]).await;
    assert_eq!(
        ctx.consensus.block_status(reward_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the attestation-including block must be UTXO-valid with a non-empty reward coinbase"
    );
    let reward_value = reward_block.transactions[0].outputs.iter().find(|o| o.script_public_key == k_spk).map(|o| o.value);
    assert!(
        reward_value.unwrap_or(0) > 0,
        "the coinbase must pay the validator a non-empty §E participation reward (got {reward_value:?})"
    );
}

/// kaspa-pq ADR-0018 §G (DAG-6): full-consensus equivocation-slashing e2e. A funded,
/// ML-DSA-87-signed bond goes active; the validator then EQUIVOCATES — two signed
/// attestations for the same `(bond, validator, epoch)` but DIFFERENT anchors — and a
/// `SlashingEvidence` tx carries both. The block including it must validate
/// (construction == validation), and as a consensus side-effect must REMOVE the locked
/// stake UTXO (the bond's output-0 leaves the supply) and MINT the reporter reward
/// (`slashing_reporter_reward_bps` = 10%) at `(slashing_tx, 0)`. This proves the slashing
/// economics end-to-end through `mine_block`/validate-and-insert, not just at the
/// `UtxoDiff` unit level (closes the audit's DAG-6 test gap).
#[tokio::test]
async fn pos_v2_slashing_evidence_removes_bond_and_pays_reporter() {
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload},
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // One validator/funding/reporter key suffices to exercise the slashing mechanism.
    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    // Fund: h_a pays K (funds the bond), h_b pays K (funds the evidence tx).
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    // Fund + mine the bond — active from activation_daa_score = 0.
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let bond_amount = value_a - 100_000;
    let (bond_tx, _vid, _reward_payload) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, bond_amount, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid, "the bond block must be UTXO-valid");
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    assert!(
        ctx.consensus.get_virtual_utxos(None, 100_000, false).iter().any(|(o, _)| *o == bond_outpoint),
        "the bond's locked-stake UTXO must exist before slashing"
    );
    // Bury the bond so its record is committed into the active bond view the slashing
    // verifier reads (mirrors the burial the reward-bearing e2e does before attesting).
    let mut buried = Vec::new();
    for _ in 0..5 {
        buried.push(ctx.mine_block(new_miner_data(), vec![]).await);
    }

    // Equivocation: two ML-DSA-87-signed attestations, same (bond, validator, epoch),
    // DIFFERENT target_hash (approving two conflicting anchors) — the punishable act.
    let net_id = ctx.consensus.params().genesis.hash;
    let epoch = 1u64;
    // A buried block's DAA: past the bond's (inclusion-set) activation so the bond is
    // Active at the target, and well within `evidence_window_blocks` of the including block.
    let target_daa = buried[1].header.daa_score;
    let att_a = dns_harness::build_signed_attestation(
        &v,
        net_id.as_byte_slice(),
        bond_outpoint,
        epoch,
        Hash64::from_bytes([0xa1u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_b = dns_harness::build_signed_attestation(
        &v,
        net_id.as_byte_slice(),
        bond_outpoint,
        epoch,
        Hash64::from_bytes([0xb2u8; 64]),
        target_daa,
        Hash64::default(),
    );
    // Sanity (localizes a signature/net_id mismatch vs a freshness/status rejection): both
    // attestations must verify under the net_id (genesis hash) the consensus slashing
    // verifier reconstructs the digest with.
    for att in [&att_a, &att_b] {
        let msg = kaspa_consensus_core::dns_finality::stake_attestation_message(
            net_id.as_byte_slice(),
            att.epoch,
            att.target_hash,
            att.target_daa_score,
            att.validator_set_commitment,
            att.bond_outpoint,
        );
        assert!(
            kaspa_txscript::verify_mldsa87_with_context(
                &v.pubkey,
                &msg.as_bytes()[..],
                &att.signature,
                kaspa_consensus_core::dns_finality::ATTESTATION_MLDSA87_CONTEXT
            )
            .unwrap(),
            "attestation must self-verify under the consensus net_id"
        );
    }
    let evidence = SlashingEvidencePayload {
        version: DNS_PAYLOAD_VERSION_V1,
        bond_outpoint,
        attestation_a: att_a,
        attestation_b: att_b,
        reporter_reward_spk_payload: k_payload,
    };
    let slash_tx = dns_harness::funded_signed_slashing_evidence_tx(seed, coinbase_b, value_b, daa_b, evidence, storage_mass_parameter);
    let slash_tx_id = slash_tx.id();

    // The block including the slashing evidence must validate AND apply the side-effects.
    let slash_block = ctx.mine_block(new_miner_data(), vec![slash_tx]).await;
    assert_eq!(
        ctx.consensus.block_status(slash_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the slashing-evidence block must be UTXO-valid (construction == validation of the slashing side-effects)"
    );

    // Consensus side-effects: the locked stake is REMOVED and the reporter reward is minted.
    let utxos: std::collections::HashMap<_, _> = ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect();
    assert!(!utxos.contains_key(&bond_outpoint), "the slashed bond's locked stake must be removed from the UTXO set");
    let reporter_mint = TransactionOutpoint::new(slash_tx_id, 0);
    let reporter_bps = ctx.consensus.params().dns_params.clone().unwrap().reward_params.slashing_reporter_reward_bps as u128;
    let expected_reporter = (bond_amount as u128 * reporter_bps / 10_000) as u64;
    let r = utxos.get(&reporter_mint).expect("the reporter reward must be minted at (slashing_tx, 0)");
    assert_eq!(r.amount, expected_reporter, "reporter reward = bond_amount * reporter_bps / 10000");
    assert_eq!(r.script_public_key, k_spk, "the reporter reward pays the declared reporter P2PKH");

    // ── Supply invariant (audit M-01) ──────────────────────────────────────────────────────
    // The 4-way slashing split is value-conserving: reporter + reserve + victim + burn equals the
    // slashed amount EXACTLY (no coins are created or destroyed by slashing), and only the reporter
    // is re-minted into the UTXO set. With a single (self-)validator there is no honest epoch peer,
    // so no victim-compensation output is emitted at (slash_tx, 2); the reserve share is pool-accrued
    // (not a UTXO) and the victim/burn shares leave the supply with the removed locked stake. Hence
    // minted (reporter) ≤ slashed ⇒ slashing cannot inflate supply.
    let rp = ctx.consensus.params().dns_params.clone().unwrap().reward_params;
    let dist = kaspa_consensus_core::dns_finality::compute_slashing_distribution(
        bond_amount,
        rp.slashing_reporter_reward_bps,
        rp.security_reserve_bps,
        rp.victim_epoch_pool_bps,
    );
    assert_eq!(
        dist.reporter_reward_sompi + dist.security_reserve_sompi + dist.victim_epoch_pool_sompi + dist.burned_sompi,
        bond_amount,
        "slashing split conserves value: reporter + reserve + victim + burn == slashed amount"
    );
    assert_eq!(dist.reporter_reward_sompi, expected_reporter, "minted reporter reward == the split's reporter share");
    assert!(dist.reporter_reward_sompi <= bond_amount, "the minted reporter reward never exceeds the slashed amount (no inflation)");
    assert!(
        !utxos.contains_key(&TransactionOutpoint::new(slash_tx_id, 2)),
        "no victim-compensation output is minted with a single (self-)validator"
    );
}

/// kaspa-pq ADR-0018 "本格版" (PoS-v2) — victim compensation (audit M-01). TWO validators: A
/// (equivocator) and B (honest). B attests the canonical anchor for a ready epoch E and is rewarded
/// (so it joins epoch E's accumulator `included` set); A then EQUIVOCATES the SAME epoch E (two
/// conflicting attestations) and is slashed. The slashing routes the victim-epoch share of A's
/// slashed stake to epoch E's honest peers = {B} (A is dropped by its `owner_reward_spk_payload`),
/// minting a victim-compensation output to B's reward P2PKH at `(slash_tx, 2)`. Proves the
/// multi-validator victim-compensation economics end-to-end through `mine_block`.
#[tokio::test]
async fn pos_v2_slashing_victim_compensates_honest_peer() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{
            DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload, compute_slashing_distribution, ready_epoch_from_tip_blue_score,
        },
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            // Ensure a non-zero victim pool (the 4-way split): reporter 10% / reserve 40% /
            // victim 40% / burn 10%.
            dns.reward_params.slashing_reporter_reward_bps = 1000;
            dns.reward_params.security_reserve_bps = 4000;
            dns.reward_params.victim_epoch_pool_bps = 4000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let (va, vb) = (dns_harness::harness_validator([0x42u8; 32]), dns_harness::harness_validator([0x43u8; 32]));
    let payload_a: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&va.pubkey).as_bytes();
    let payload_b: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&vb.pubkey).as_bytes();
    let (spk_a, spk_b) = (p2pkh_mldsa87_spk(&payload_a), p2pkh_mldsa87_spk(&payload_b));

    // Fund: A needs two coinbases (bond + slashing-evidence tx), B two (bond + attestation shard).
    // A block's coinbase pays its MERGESET (the previous block's miner), not its own, so mine a
    // batch per miner and SCAN all coinbases for ones paying each validator.
    let (miner_a, miner_b) = (MinerData::new(spk_a.clone(), vec![]), MinerData::new(spk_b.clone(), vec![]));
    let mut blocks = Vec::new();
    for _ in 0..4 {
        blocks.push(ctx.mine_block(miner_a.clone(), vec![]).await);
    }
    for _ in 0..4 {
        blocks.push(ctx.mine_block(miner_b.clone(), vec![]).await);
    }
    for _ in 0..5 {
        blocks.push(ctx.mine_block(new_miner_data(), vec![]).await); // mature the coinbases
    }
    let (mut a_funds, mut b_funds) = (Vec::new(), Vec::new());
    for blk in &blocks {
        let cb = &blk.transactions[0];
        for (i, o) in cb.outputs.iter().enumerate() {
            let f = (TransactionOutpoint::new(cb.id(), i as u32), o.value, blk.header.daa_score);
            if o.script_public_key == spk_a {
                a_funds.push(f);
            } else if o.script_public_key == spk_b {
                b_funds.push(f);
            }
        }
    }
    assert!(a_funds.len() >= 2 && b_funds.len() >= 2, "need ≥2 funding coinbases each (a={}, b={})", a_funds.len(), b_funds.len());
    let ((cb_a1, va1, da1), (cb_a2, va2, da2)) = (a_funds[0], a_funds[1]);
    let ((cb_b1, vb1, db1), (cb_b2, vb2, db2)) = (b_funds[0], b_funds[1]);

    // Bond A and B (active from activation_daa_score = 0).
    let storage = ctx.consensus.params().storage_mass_parameter;
    let bond_a_amount = va1 - 100_000;
    let (bond_a_tx, _, _) = dns_harness::funded_signed_bond_tx([0x42u8; 32], cb_a1, va1, da1, bond_a_amount, 0, storage);
    let (bond_b_tx, _, _) = dns_harness::funded_signed_bond_tx([0x43u8; 32], cb_b1, vb1, db1, vb1 - 100_000, 0, storage);
    let (bond_a_id, bond_b_id) = (bond_a_tx.id(), bond_b_tx.id());
    ctx.mine_block(new_miner_data(), vec![bond_a_tx]).await;
    ctx.mine_block(new_miner_data(), vec![bond_b_tx]).await;
    let (bond_a_outpoint, bond_b_outpoint) = (TransactionOutpoint::new(bond_a_id, 0), TransactionOutpoint::new(bond_b_id, 0));

    // Bury so a ready, bond-active canonical anchor exists for a real epoch E.
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let lr = ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(lr, sink, &dns).expect("canonical anchor for the ready epoch")
    };
    let epoch_e = anchor.epoch;

    // B HONESTLY attests the canonical anchor for epoch E → B is rewarded ⇒ joins epoch E's
    // accumulator `included` set (keyed by the attestation epoch).
    let att_b = dns_harness::build_signed_attestation(
        &vb,
        genesis_hash.as_byte_slice(),
        bond_b_outpoint,
        epoch_e,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_b = dns_harness::funded_signed_shard_tx([0x43u8; 32], cb_b2, vb2, db2, att_b, storage);
    let reward_block = ctx.mine_block(new_miner_data(), vec![shard_b]).await;
    assert!(
        reward_block.transactions[0].outputs.iter().any(|o| o.script_public_key == spk_b),
        "B must be rewarded for attesting epoch E (so it joins the epoch's included set)"
    );

    // Bury so A's bond is committed into the active bond view the slashing verifier reads.
    let mut buried = Vec::new();
    for _ in 0..5 {
        buried.push(ctx.mine_block(new_miner_data(), vec![]).await);
    }

    // A EQUIVOCATES the SAME epoch E: two conflicting attestations (different anchors).
    let target_daa = buried[1].header.daa_score;
    let att_a1 = dns_harness::build_signed_attestation(
        &va,
        genesis_hash.as_byte_slice(),
        bond_a_outpoint,
        epoch_e,
        Hash64::from_bytes([0xa1u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_a2 = dns_harness::build_signed_attestation(
        &va,
        genesis_hash.as_byte_slice(),
        bond_a_outpoint,
        epoch_e,
        Hash64::from_bytes([0xb2u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let evidence = SlashingEvidencePayload {
        version: DNS_PAYLOAD_VERSION_V1,
        bond_outpoint: bond_a_outpoint,
        attestation_a: att_a1,
        attestation_b: att_a2,
        reporter_reward_spk_payload: payload_a, // reporter paid to A's address (payout is independent of who is slashed)
    };
    let slash_tx = dns_harness::funded_signed_slashing_evidence_tx([0x42u8; 32], cb_a2, va2, da2, evidence, storage);
    let slash_tx_id = slash_tx.id();
    let slash_block = ctx.mine_block(new_miner_data(), vec![slash_tx]).await;
    assert_eq!(
        ctx.consensus.block_status(slash_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the slashing block must validate AND mint the victim-compensation outputs (construction == validation)"
    );

    let utxos: std::collections::HashMap<_, _> = ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect();
    assert!(!utxos.contains_key(&bond_a_outpoint), "A's slashed locked stake is removed");
    let dist = compute_slashing_distribution(
        bond_a_amount,
        dns.reward_params.slashing_reporter_reward_bps,
        dns.reward_params.security_reserve_bps,
        dns.reward_params.victim_epoch_pool_bps,
    );
    let reporter = utxos.get(&TransactionOutpoint::new(slash_tx_id, 0)).expect("reporter reward minted at (slash_tx, 0)");
    assert_eq!(reporter.amount, dist.reporter_reward_sompi, "reporter = reporter_bps share");
    // VICTIM COMPENSATION: the single honest peer B receives the whole victim pool at (slash_tx, 2).
    let victim = utxos.get(&TransactionOutpoint::new(slash_tx_id, 2)).expect("victim-compensation output minted at (slash_tx, 2)");
    assert_eq!(victim.script_public_key, spk_b, "victim compensation pays the honest peer B");
    assert_eq!(victim.amount, dist.victim_epoch_pool_sompi, "the lone honest peer receives the entire victim pool");
}

/// kaspa-pq ADR-0018 "本格版" (PoS-v2) — multiple slashings in ONE block (audit M-01). TWO
/// independently-bonded validators A and B BOTH equivocate and are slashed by SEPARATE evidence
/// transactions carried in the SAME block. Proves the slashing pipeline applies N>1 side-effects
/// atomically and independently: both locked stakes are removed, each reporter reward is minted at
/// its own `(slash_tx, 0)`, each bond's 4-way split conserves value, and — the multi-slash-specific
/// invariant — the block's committed security-reserve accrual is the SUM of both bonds' reserve
/// shares (`apply_slashing_side_effects`'s fold over the resolved effects, persisted by the
/// `parent_balance + reserve_accrual − drip` recurrence). With no honest epoch peer, no
/// victim-compensation output is minted for either.
#[tokio::test]
async fn pos_v2_multi_slashing_in_one_block() {
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload, compute_slashing_distribution},
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            // 4-way split with non-zero reserve + victim shares (so the summed reserve accrual is observable).
            dns.reward_params.slashing_reporter_reward_bps = 1000;
            dns.reward_params.security_reserve_bps = 4000;
            dns.reward_params.victim_epoch_pool_bps = 4000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let (va, vb) = (dns_harness::harness_validator([0x42u8; 32]), dns_harness::harness_validator([0x43u8; 32]));
    let payload_a: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&va.pubkey).as_bytes();
    let payload_b: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&vb.pubkey).as_bytes();
    let (spk_a, spk_b) = (p2pkh_mldsa87_spk(&payload_a), p2pkh_mldsa87_spk(&payload_b));

    // Fund: each validator needs two coinbases (bond + slashing-evidence tx). A block's coinbase pays
    // its MERGESET (the previous block's) miner, so mine a batch per miner and SCAN all coinbases.
    let (miner_a, miner_b) = (MinerData::new(spk_a.clone(), vec![]), MinerData::new(spk_b.clone(), vec![]));
    let mut blocks = Vec::new();
    for _ in 0..4 {
        blocks.push(ctx.mine_block(miner_a.clone(), vec![]).await);
    }
    for _ in 0..4 {
        blocks.push(ctx.mine_block(miner_b.clone(), vec![]).await);
    }
    for _ in 0..5 {
        blocks.push(ctx.mine_block(new_miner_data(), vec![]).await); // mature the coinbases
    }
    let (mut a_funds, mut b_funds) = (Vec::new(), Vec::new());
    for blk in &blocks {
        let cb = &blk.transactions[0];
        for (i, o) in cb.outputs.iter().enumerate() {
            let f = (TransactionOutpoint::new(cb.id(), i as u32), o.value, blk.header.daa_score);
            if o.script_public_key == spk_a {
                a_funds.push(f);
            } else if o.script_public_key == spk_b {
                b_funds.push(f);
            }
        }
    }
    assert!(a_funds.len() >= 2 && b_funds.len() >= 2, "need ≥2 funding coinbases each (a={}, b={})", a_funds.len(), b_funds.len());
    let ((cb_a1, va1, da1), (cb_a2, va2, da2)) = (a_funds[0], a_funds[1]);
    let ((cb_b1, vb1, db1), (cb_b2, vb2, db2)) = (b_funds[0], b_funds[1]);

    // Bond A and B (active from activation_daa_score = 0).
    let storage = ctx.consensus.params().storage_mass_parameter;
    let (bond_a_amount, bond_b_amount) = (va1 - 100_000, vb1 - 100_000);
    let (bond_a_tx, _, _) = dns_harness::funded_signed_bond_tx([0x42u8; 32], cb_a1, va1, da1, bond_a_amount, 0, storage);
    let (bond_b_tx, _, _) = dns_harness::funded_signed_bond_tx([0x43u8; 32], cb_b1, vb1, db1, bond_b_amount, 0, storage);
    let (bond_a_id, bond_b_id) = (bond_a_tx.id(), bond_b_tx.id());
    ctx.mine_block(new_miner_data(), vec![bond_a_tx]).await;
    ctx.mine_block(new_miner_data(), vec![bond_b_tx]).await;
    let (bond_a_outpoint, bond_b_outpoint) = (TransactionOutpoint::new(bond_a_id, 0), TransactionOutpoint::new(bond_b_id, 0));

    // Bury so BOTH bonds are committed into the active bond view the slashing verifier reads.
    let mut buried = Vec::new();
    for _ in 0..6 {
        buried.push(ctx.mine_block(new_miner_data(), vec![]).await);
    }

    // Both A and B equivocate: each emits two conflicting attestations for the same epoch (different
    // anchors). With no honest peer the epoch only has to be shared by each validator's own pair.
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let epoch = 1u64;
    let target_daa = buried[1].header.daa_score; // past each bond's activation, within evidence_window of the slash block
    let att_a1 = dns_harness::build_signed_attestation(
        &va,
        genesis_hash.as_byte_slice(),
        bond_a_outpoint,
        epoch,
        Hash64::from_bytes([0xa1u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_a2 = dns_harness::build_signed_attestation(
        &va,
        genesis_hash.as_byte_slice(),
        bond_a_outpoint,
        epoch,
        Hash64::from_bytes([0xb2u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_b1 = dns_harness::build_signed_attestation(
        &vb,
        genesis_hash.as_byte_slice(),
        bond_b_outpoint,
        epoch,
        Hash64::from_bytes([0xc3u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_b2 = dns_harness::build_signed_attestation(
        &vb,
        genesis_hash.as_byte_slice(),
        bond_b_outpoint,
        epoch,
        Hash64::from_bytes([0xd4u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let ev_a = SlashingEvidencePayload {
        version: DNS_PAYLOAD_VERSION_V1,
        bond_outpoint: bond_a_outpoint,
        attestation_a: att_a1,
        attestation_b: att_a2,
        reporter_reward_spk_payload: payload_a,
    };
    let ev_b = SlashingEvidencePayload {
        version: DNS_PAYLOAD_VERSION_V1,
        bond_outpoint: bond_b_outpoint,
        attestation_a: att_b1,
        attestation_b: att_b2,
        reporter_reward_spk_payload: payload_b,
    };
    let slash_a = dns_harness::funded_signed_slashing_evidence_tx([0x42u8; 32], cb_a2, va2, da2, ev_a, storage);
    let slash_b = dns_harness::funded_signed_slashing_evidence_tx([0x43u8; 32], cb_b2, vb2, db2, ev_b, storage);
    let (slash_a_id, slash_b_id) = (slash_a.id(), slash_b.id());

    // BOTH slashing-evidence txs in ONE block.
    let slash_block = ctx.mine_block(new_miner_data(), vec![slash_a, slash_b]).await;
    assert_eq!(
        ctx.consensus.block_status(slash_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the block carrying TWO slashing-evidence txs must validate (both side-effects apply atomically)"
    );
    // A block's own transactions (and thus their slashing side-effects + the reserve accrual they
    // commit) are applied to the persisted UTXO state only once the block becomes a SELECTED PARENT.
    // Mine one empty block on top so `slash_block`'s effects settle into a committed chain block
    // (`settle`), whose `reserve_balance_store` row we read below.
    let settle = ctx.mine_block(new_miner_data(), vec![]).await;

    let utxos: std::collections::HashMap<_, _> = ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect();
    // Both locked stakes removed.
    assert!(!utxos.contains_key(&bond_a_outpoint), "A's slashed locked stake is removed");
    assert!(!utxos.contains_key(&bond_b_outpoint), "B's slashed locked stake is removed");

    let rp = ctx.consensus.params().dns_params.clone().unwrap().reward_params;
    let dist_a = compute_slashing_distribution(
        bond_a_amount,
        rp.slashing_reporter_reward_bps,
        rp.security_reserve_bps,
        rp.victim_epoch_pool_bps,
    );
    let dist_b = compute_slashing_distribution(
        bond_b_amount,
        rp.slashing_reporter_reward_bps,
        rp.security_reserve_bps,
        rp.victim_epoch_pool_bps,
    );
    // Each reporter reward minted independently at its own (slash_tx, 0).
    let ra = utxos.get(&TransactionOutpoint::new(slash_a_id, 0)).expect("A's reporter reward minted at (slash_a, 0)");
    let rb = utxos.get(&TransactionOutpoint::new(slash_b_id, 0)).expect("B's reporter reward minted at (slash_b, 0)");
    assert_eq!((ra.amount, &ra.script_public_key), (dist_a.reporter_reward_sompi, &spk_a), "A's reporter share pays A");
    assert_eq!((rb.amount, &rb.script_public_key), (dist_b.reporter_reward_sompi, &spk_b), "B's reporter share pays B");
    // No honest epoch peer ⇒ no victim-compensation output for either bond.
    assert!(!utxos.contains_key(&TransactionOutpoint::new(slash_a_id, 2)), "no victim output without an honest peer (A)");
    assert!(!utxos.contains_key(&TransactionOutpoint::new(slash_b_id, 2)), "no victim output without an honest peer (B)");

    // Per-bond value conservation: each 4-way split sums back to the slashed amount.
    assert_eq!(
        dist_a.reporter_reward_sompi + dist_a.security_reserve_sompi + dist_a.victim_epoch_pool_sompi + dist_a.burned_sompi,
        bond_a_amount,
        "A's slash split conserves value"
    );
    assert_eq!(
        dist_b.reporter_reward_sompi + dist_b.security_reserve_sompi + dist_b.victim_epoch_pool_sompi + dist_b.burned_sompi,
        bond_b_amount,
        "B's slash split conserves value"
    );

    // MULTI-SLASH INVARIANT: the committed security-reserve accrual is the SUM of both bonds' reserve
    // shares (the fold in `apply_slashing_side_effects`). It commits under `settle` (the block whose
    // selected parent is `slash_block`, so its mergeset carries the two slash txs). `settle`'s parent
    // (`slash_block`) accrued no reserve (balance 0 ⇒ no drip), so the recurrence reduces to
    // `0 + (reserve_a + reserve_b) − 0`.
    let committed_reserve = ctx.consensus.virtual_processor().reserve_balance_store.get(settle.header.hash).unwrap_or(0);
    assert_eq!(
        committed_reserve,
        dist_a.security_reserve_sompi + dist_b.security_reserve_sompi,
        "the block's reserve accrual is the SUM of both slashed bonds' reserve shares"
    );
}

/// kaspa-pq ADR-0018 "本格版" (PoS-v2, Phase 4) — security-reserve DRIP (audit M-01). Closes the
/// reserve loop end-to-end: a slashing accrues its reserve share to the pool, and when an epoch the
/// pool can pay finalizes, the reserve DRIPS back out into that block's coinbase, stake-proportionally
/// to the epoch's honest included validators. TWO validators: A is slashed for equivocation (its
/// `security_reserve_bps` share accrues to the reserve pool); B honestly attests the canonical anchor
/// for a ready epoch E and joins `included[E]`. Once epoch E finalizes (its `(E+1)·L + finalization_depth`
/// DAA threshold is crossed), the finalizing block's coinbase pays B the whole reserve (cap set high,
/// B the sole included validator). Proves accrued-in == dripped-out (value conservation).
///
/// NOTE the config sets `epoch_length_blocks == attestation_epoch_length_blue_score`: the drip pays
/// the FINALIZING epoch's `included` set, which `recompute_epoch_tallies` keys by the ATTESTATION
/// epoch, while `epochs_finalized_at` selects epochs by the DAA epoch (`daa_score / epoch_length_blocks`).
/// The two numberings coincide (on a linear chain blue_score ≈ daa_score) only when those two lengths
/// are equal — which is exactly the production reality (both = 100 in GENESIS_ACTIVE/PRODUCTION_DNS_PARAMS).
/// That equality is a configuration this fixture AVOIDS the two-clock gap with, not a fact about the
/// chain: the gap itself is pinned by `dns_finality::tests::the_accumulator_keys_one_map_from_two_epoch_numberings`
/// (mainnet audit, 2026-09-06, H-2), which goes red both if it widens and if it closes.
///
/// It also cannot see M-1: `reserve_drip_per_epoch_cap_sompi` is `u64::MAX` here and this chain
/// crosses one threshold a block, so the per-crossing spend has nothing to multiply. The rate limit
/// is stated over a multi-epoch crossing by
/// `dns_finality::tests::the_reserve_drip_rate_limit_is_spent_per_block_not_per_crossing`.
#[tokio::test]
async fn pos_v2_reserve_drip_pays_finalized_epoch() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{
            DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload, compute_slashing_distribution, ready_epoch_from_tip_blue_score,
        },
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            // epoch_length_blocks == attestation_epoch_length_blue_score (production reality) so the
            // attestation epoch B signs and the DAA epoch the drip finalizes are the same number.
            dns.epoch_length_blocks = 3;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            // Reward recency must comfortably cover the canonical anchor (buried by lag + backoff
            // below the tip); finalization_depth = window + max_reorg_horizon = 52.
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.stake_score_window_blue_score = 10_000;
            // Isolate the drip: participation takes the full validator pool (quality-bonus pool = 0), so
            // the only post-attestation coinbase output to B is the reserve drip.
            dns.reward_params.validator_participation_bps = 10_000;
            dns.reward_params.slashing_reporter_reward_bps = 1000;
            dns.reward_params.security_reserve_bps = 4000; // 40% of the slashed bond accrues to the reserve
            dns.reward_params.victim_epoch_pool_bps = 4000;
            dns.reward_params.reserve_drip_per_epoch_cap_sompi = u64::MAX; // the whole reserve drips in one epoch
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let (va, vb) = (dns_harness::harness_validator([0x42u8; 32]), dns_harness::harness_validator([0x43u8; 32]));
    let payload_a: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&va.pubkey).as_bytes();
    let payload_b: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&vb.pubkey).as_bytes();
    let (spk_a, spk_b) = (p2pkh_mldsa87_spk(&payload_a), p2pkh_mldsa87_spk(&payload_b));

    // Fund: A needs two coinbases (bond + slashing-evidence tx), B two (bond + attestation shard).
    // A block's coinbase pays its MERGESET miner, so mine a batch per miner and SCAN all coinbases.
    let (miner_a, miner_b) = (MinerData::new(spk_a.clone(), vec![]), MinerData::new(spk_b.clone(), vec![]));
    let mut blocks = Vec::new();
    for _ in 0..4 {
        blocks.push(ctx.mine_block(miner_a.clone(), vec![]).await);
    }
    for _ in 0..4 {
        blocks.push(ctx.mine_block(miner_b.clone(), vec![]).await);
    }
    for _ in 0..5 {
        blocks.push(ctx.mine_block(new_miner_data(), vec![]).await);
    }
    let (mut a_funds, mut b_funds) = (Vec::new(), Vec::new());
    for blk in &blocks {
        let cb = &blk.transactions[0];
        for (i, o) in cb.outputs.iter().enumerate() {
            let f = (TransactionOutpoint::new(cb.id(), i as u32), o.value, blk.header.daa_score);
            if o.script_public_key == spk_a {
                a_funds.push(f);
            } else if o.script_public_key == spk_b {
                b_funds.push(f);
            }
        }
    }
    assert!(a_funds.len() >= 2 && b_funds.len() >= 2, "need ≥2 funding coinbases each (a={}, b={})", a_funds.len(), b_funds.len());
    let ((cb_a1, va1, da1), (cb_a2, va2, da2)) = (a_funds[0], a_funds[1]);
    let ((cb_b1, vb1, db1), (cb_b2, vb2, db2)) = (b_funds[0], b_funds[1]);

    let storage = ctx.consensus.params().storage_mass_parameter;
    let genesis_hash = ctx.consensus.params().genesis.hash;

    // ── B bonds and HONESTLY attests the ready canonical epoch E ────────────────────────────────
    // B bonds and attests FIRST: A is bonded only later (below), strictly after E's anchor, so A is
    // not part of E's expected-stake denominator — leaving B the sole included validator at E, which
    // makes the drip pay B the WHOLE reserve (a crisp value-conservation assertion). The stake-
    // proportional split when a slashed peer co-existed at the anchor is exercised separately.
    let (bond_b_tx, _, _) = dns_harness::funded_signed_bond_tx([0x43u8; 32], cb_b1, vb1, db1, vb1 - 100_000, 0, storage);
    let bond_b_id = bond_b_tx.id();
    ctx.mine_block(new_miner_data(), vec![bond_b_tx]).await;
    let bond_b_outpoint = TransactionOutpoint::new(bond_b_id, 0);
    // Bury so a ready, bond-active canonical anchor exists for B's epoch E.
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let lr = ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(lr, sink, &dns).expect("canonical anchor for the ready epoch")
    };
    let epoch_e = anchor.epoch;
    let att_b = dns_harness::build_signed_attestation(
        &vb,
        genesis_hash.as_byte_slice(),
        bond_b_outpoint,
        epoch_e,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_b = dns_harness::funded_signed_shard_tx([0x43u8; 32], cb_b2, vb2, db2, att_b, storage);
    let reward_block = ctx.mine_block(new_miner_data(), vec![shard_b]).await;
    assert!(
        reward_block.transactions[0].outputs.iter().any(|o| o.script_public_key == spk_b),
        "B must be rewarded for attesting epoch E (so it joins included[E])"
    );

    // ── Accrue the reserve: bond A (AFTER E's anchor) and slash it for equivocation ─────────────
    let bond_a_amount = va1 - 100_000;
    let (bond_a_tx, _, _) = dns_harness::funded_signed_bond_tx([0x42u8; 32], cb_a1, va1, da1, bond_a_amount, 0, storage);
    let bond_a_id = bond_a_tx.id();
    ctx.mine_block(new_miner_data(), vec![bond_a_tx]).await;
    let bond_a_outpoint = TransactionOutpoint::new(bond_a_id, 0);
    // Bury so A's bond is committed into the active bond view the slashing verifier reads.
    let mut buried = Vec::new();
    for _ in 0..6 {
        buried.push(ctx.mine_block(new_miner_data(), vec![]).await);
    }
    // A equivocates an arbitrary epoch (1) DISJOINT from B's epoch E, so A's slash mints no victim
    // output (epoch 1 has no honest included peer) — only the reserve accrues.
    let target_daa = buried[1].header.daa_score;
    let att_a1 = dns_harness::build_signed_attestation(
        &va,
        genesis_hash.as_byte_slice(),
        bond_a_outpoint,
        1,
        Hash64::from_bytes([0xa1u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_a2 = dns_harness::build_signed_attestation(
        &va,
        genesis_hash.as_byte_slice(),
        bond_a_outpoint,
        1,
        Hash64::from_bytes([0xb2u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let evidence = SlashingEvidencePayload {
        version: DNS_PAYLOAD_VERSION_V1,
        bond_outpoint: bond_a_outpoint,
        attestation_a: att_a1,
        attestation_b: att_a2,
        reporter_reward_spk_payload: payload_a,
    };
    let slash_tx = dns_harness::funded_signed_slashing_evidence_tx([0x42u8; 32], cb_a2, va2, da2, evidence, storage);
    let slash_block = ctx.mine_block(new_miner_data(), vec![slash_tx]).await;
    assert_eq!(ctx.consensus.block_status(slash_block.header.hash), BlockStatus::StatusUTXOValid, "the slashing block must validate");
    // Settle so the reserve accrual commits (a block's own txs apply once it becomes a selected parent).
    let reserve_settle = ctx.mine_block(new_miner_data(), vec![]).await;
    let dist = compute_slashing_distribution(
        bond_a_amount,
        dns.reward_params.slashing_reporter_reward_bps,
        dns.reward_params.security_reserve_bps,
        dns.reward_params.victim_epoch_pool_bps,
    );
    let reserve_accrued = ctx.consensus.virtual_processor().reserve_balance_store.get(reserve_settle.header.hash).unwrap_or(0);
    assert_eq!(reserve_accrued, dist.security_reserve_sompi, "A's slash accrues its reserve share to the pool");
    assert!(reserve_accrued > 0, "the reserve must be non-zero to drip");

    // ── Mine until epoch E's DAA-finalization; the drip pays B in that block's coinbase ─────────
    let target_final_daa =
        (epoch_e + 1) * dns.epoch_length_blocks + dns.reward_uniqueness_window_blocks + dns.max_reorg_horizon_blocks;
    let mut drip_block = None;
    for _ in 0..80 {
        let blk = ctx.mine_block(new_miner_data(), vec![]).await;
        // The reserve drip is appended to the coinbase of the block that finalizes epoch E. B got its
        // one-time participation reward at `reward_block` (cross-block dedup blocks re-payment), and the
        // §D worker bounty pays the includer — so the only later coinbase output to B is the drip.
        if blk.transactions[0].outputs.iter().any(|o| o.script_public_key == spk_b) {
            drip_block = Some(blk);
            break;
        }
        if blk.header.daa_score > target_final_daa + 5 {
            break;
        }
    }
    let drip_block = drip_block.expect("a block after the reward must drip the reserve to B at epoch E's finalization");
    let drip_out = drip_block.transactions[0].outputs.iter().find(|o| o.script_public_key == spk_b).expect("drip pays B");
    // The sole included validator B receives the WHOLE reserve (cap is u64::MAX): accrued-in == dripped-out.
    assert_eq!(drip_out.value, reserve_accrued, "the entire accrued reserve drips to the lone included validator B");
}

/// kaspa-pq ADR-0016 §D.2 — the bond-UTXO spend-gate races the slashing side-effect (audit M-01). A
/// validator's locked stake (the bond's output-0) is NOT releasable while the bond is Active, so a
/// block that SPENDS it must be rejected — even when the SAME block also carries a slashing-evidence
/// tx for that bond (which would otherwise remove output-0). The spend-gate wins the race: the block
/// is disqualified (`NonReleasableBondSpendInBlock`), so NEITHER the spend NOR the slash takes effect
/// — the locked stake survives intact and no reporter reward is minted. Proves a validator cannot
/// reclaim locked capital by smuggling a self-spend into a block, and that the spend-gate takes
/// precedence over the slashing side-effect.
#[tokio::test]
async fn pos_v2_spend_gate_rejects_locked_bond_racing_slash() {
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload},
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // One validator/funding/reporter key.
    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    // Fund: h_a pays K (funds the bond), h_b pays K (funds the slashing-evidence tx).
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    // Bond: output-0 is the locked stake (a P2PKH to K), Active from activation 0.
    let storage = ctx.consensus.params().storage_mass_parameter;
    let bond_amount = value_a - 100_000;
    let (bond_tx, _vid, _payload) = dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, bond_amount, 0, storage);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid, "the bond block must be UTXO-valid");
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    let bond_daa = bond_block.header.daa_score;

    // Bury so the bond is committed into the active bond view the slashing verifier reads.
    let mut buried = Vec::new();
    for _ in 0..6 {
        buried.push(ctx.mine_block(new_miner_data(), vec![]).await);
    }

    // Equivocation evidence (two conflicting attestations for the same (bond, epoch)).
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let target_daa = buried[1].header.daa_score;
    let att_a = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        1,
        Hash64::from_bytes([0xa1u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_b = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        1,
        Hash64::from_bytes([0xb2u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let evidence = SlashingEvidencePayload {
        version: DNS_PAYLOAD_VERSION_V1,
        bond_outpoint,
        attestation_a: att_a,
        attestation_b: att_b,
        reporter_reward_spk_payload: k_payload,
    };
    let slash_tx = dns_harness::funded_signed_slashing_evidence_tx(seed, coinbase_b, value_b, daa_b, evidence, storage);
    let slash_tx_id = slash_tx.id();
    // A self-spend of the still-locked bond output-0 (the spend-gate violation).
    let spend_tx = dns_harness::funded_signed_p2pkh_spend(seed, bond_outpoint, bond_amount, bond_daa, storage);

    // ONE block carries BOTH: the slash (which would remove output-0) AND the self-spend of output-0.
    //
    // Since the 2026-08-11 audit P0 the devnet preset activates the MERGESET spend gate at
    // genesis, which replaces the own-body REJECT with an acceptance-time SKIP: the block stays
    // valid and the spend simply is not accepted. That is the deliberate trade — an own-body
    // reject makes an honest miner self-reject for merely MERGING someone else's forbidden
    // spend, while the skip protects the collateral in both cases. What must remain true either
    // way is the property this test exists for: the locked output is NOT spendable while the
    // bond is unreleasable.
    let race_block = ctx.mine_block(new_miner_data(), vec![slash_tx, spend_tx]).await;
    assert_eq!(
        ctx.consensus.block_status(race_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the mergeset skip keeps the block valid — an honest miner must not self-reject over a merged spend"
    );
    // What the SKIP changes, and what it does not. The spend is not accepted — that is the whole
    // point, the collateral cannot leave while the bond is unreleasable — but the block is valid,
    // so everything ELSE in it applies, including the slash. The locked output therefore does
    // leave the UTXO set: removed by the slashing side-effect, not spent by its owner, and the
    // reporter reward that proves which of the two happened IS minted.
    //
    // Under the old own-body REJECT the block was disqualified and neither happened. Both
    // outcomes protect the collateral; only this one lets an honest miner merge the spend without
    // self-rejecting.
    let utxos: std::collections::HashMap<_, _> = ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect();
    assert!(!utxos.contains_key(&bond_outpoint), "the locked output must not survive as spendable stake");
    assert!(
        utxos.contains_key(&TransactionOutpoint::new(slash_tx_id, 0)),
        "the slash applied and paid its reporter — so the output left by SLASHING, not by the refused spend"
    );
}

/// kaspa-pq ADR-0018 "本格版" (PoS-v2) — slashing is REORG-RESISTANT and reorg-SAFE (audit M-01). An
/// equivocator cannot escape its slash by getting the network to reorg onto a heavier branch that
/// omits the evidence. A bond X is buried in a shared prefix; one branch (A) slashes X — committing
/// the side-effect (output-0 removed, reporter minted at `(slash_tx, 0)`) — while a HEAVIER competing
/// branch (B), built by a second consensus instance over the SAME prefix, omits the slash. When B's
/// blocks arrive the node reorgs onto B (the reorg gate is held dormant — Bootstrap stage, since
/// `min_active_validators` is raised so a lone bond never activates it — so selection is pure
/// blue_work). The slash block leaves the SELECTED chain, but branch A is still a DAG tip and is
/// MERGED into the virtual, so the slash side-effect is RECOMPUTED and re-applies deterministically:
/// X stays slashed and the reporter stays minted, exactly once (no double-removal, no panic, supply
/// conserved). This is the economically correct, reorg-safe outcome — the equivocation evidence is
/// permanent in the DAG, so the punishment survives the reorg rather than being stranded or replayed.
#[tokio::test]
async fn pos_v2_slashing_survives_reorg_via_evidence_merge() {
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload},
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            // A large reorg horizon so the fork is within range (the gate is dormant anyway).
            dns.max_reorg_horizon_blocks = 1000;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            // Keep the rollout stage in Bootstrap (one bond can never reach Active), so the reorg gate
            // stays GateInactive and selection is pure blue_work — the heaviest branch wins.
            dns.min_active_validators = 100;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    // ── Shared prefix on the honest node: fund + bond X + bury (collected for delivery to the 2nd
    //    instance, so both branches share an identical bond-creation history) ────────────────────
    let mut prefix = Vec::new();
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    prefix.push(ctx.mine_block(k_miner.clone(), vec![]).await);
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    prefix.push(h_a.clone());
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    prefix.push(h_b.clone());
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        prefix.push(ctx.mine_block(new_miner_data(), vec![]).await);
    }
    let storage = ctx.consensus.params().storage_mass_parameter;
    let bond_amount = value_a - 100_000;
    let (bond_tx, _vid, _rp) = dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, bond_amount, 0, storage);
    let bond_tx_id = bond_tx.id();
    prefix.push(ctx.mine_block(new_miner_data(), vec![bond_tx]).await);
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    let mut buried = Vec::new();
    for _ in 0..6 {
        let b = ctx.mine_block(new_miner_data(), vec![]).await;
        buried.push(b.clone());
        prefix.push(b);
    }

    // ── Second instance: replay the SAME prefix, then build a HEAVIER no-slash branch B ─────────
    let mut atk = TestContext::new(TestConsensus::new(&config));
    for b in &prefix {
        atk.validate_and_insert_block(b.clone()).await;
    }
    atk.simulated_time = ctx.simulated_time; // so branch B's timestamps stay ahead of the prefix
    let mut branch_b = Vec::new();
    for _ in 0..12 {
        branch_b.push(atk.mine_block(new_miner_data(), vec![]).await);
    }
    let branch_b_tip = branch_b.last().unwrap().header.hash;

    // ── Honest branch A: slash X (equivocation) and settle so the side-effect is COMMITTED ──────
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let target_daa = buried[1].header.daa_score;
    let att_a = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        1,
        Hash64::from_bytes([0xa1u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let att_b = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        1,
        Hash64::from_bytes([0xb2u8; 64]),
        target_daa,
        Hash64::default(),
    );
    let evidence = SlashingEvidencePayload {
        version: DNS_PAYLOAD_VERSION_V1,
        bond_outpoint,
        attestation_a: att_a,
        attestation_b: att_b,
        reporter_reward_spk_payload: k_payload,
    };
    let slash_tx = dns_harness::funded_signed_slashing_evidence_tx(seed, coinbase_b, value_b, daa_b, evidence, storage);
    let slash_tx_id = slash_tx.id();
    let slash_block = ctx.mine_block(new_miner_data(), vec![slash_tx]).await;
    assert_eq!(ctx.consensus.block_status(slash_block.header.hash), BlockStatus::StatusUTXOValid, "branch A's slash block validates");
    ctx.mine_block(new_miner_data(), vec![]).await; // settle so the slash side-effect commits

    // Slash applied on branch A: X's locked stake is gone and the reporter reward is minted.
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let expected_reporter = kaspa_consensus_core::dns_finality::compute_slashing_distribution(
        bond_amount,
        dns.reward_params.slashing_reporter_reward_bps,
        dns.reward_params.security_reserve_bps,
        dns.reward_params.victim_epoch_pool_bps,
    )
    .reporter_reward_sompi;
    let reporter_outpoint = TransactionOutpoint::new(slash_tx_id, 0);
    let pre: std::collections::HashMap<_, _> = ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect();
    assert!(!pre.contains_key(&bond_outpoint), "branch A: the slashed bond's locked stake is removed");
    assert_eq!(pre.get(&reporter_outpoint).map(|u| u.amount), Some(expected_reporter), "branch A: the reporter reward is minted");

    // ── Deliver branch B → the node reorgs onto the heavier no-slash branch ─────────────────────
    for b in &branch_b {
        ctx.validate_and_insert_block(b.clone()).await;
    }
    assert_eq!(ctx.consensus.get_sink(), branch_b_tip, "the node reorged onto the heavier branch B (gate dormant ⇒ pure blue_work)");

    // ── The slash SURVIVES the reorg: branch A leaves the selected chain but is merged back into the
    //    virtual, so the side-effect re-applies deterministically — X stays slashed, reporter stays
    //    minted EXACTLY ONCE (no double-removal, no double-mint, no panic). ──────────────────────
    let post: std::collections::HashMap<_, _> = ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect();
    assert!(
        !post.contains_key(&bond_outpoint),
        "after reorg: the equivocator is STILL slashed — its locked stake stays removed (evidence merged back)"
    );
    assert_eq!(
        post.get(&reporter_outpoint).map(|u| u.amount),
        Some(expected_reporter),
        "after reorg: the reporter reward is still minted, exactly once (recomputed over the new selected chain + merge set)"
    );
}

/// kaspa-pq ADR-0018 §F (DAG-3) — STAGED reward-split rollout across the `full_reward_split_daa_score`
/// boundary. The §F carve selects the fee/subsidy split deterministically from the block's DAA score:
/// below `full_reward_split_daa_score` the BOOTSTRAP split (smaller validator carve — worker base
/// 8200bps), at/above it the FULL split (worker base 6200bps; validator 30% — re-genesis raised it
/// from 25%). This mines a constant-miner chain straight across the boundary and asserts (a) EVERY
/// block stays UTXO-valid — the coinbase carve the template builds equals the one validation
/// recomputes, on BOTH sides AND at the crossing block (construction == validation across a staged
/// consensus parameter), and (b) the miner's per-block subsidy share visibly DROPS at the boundary
/// (bootstrap 82% → full 62% of subsidy), proving the split actually changed rather than the stage
/// being inert.
#[tokio::test]
async fn pos_v2_staged_full_reward_split_across_boundary() {
    kaspa_core::log::try_init_logger("info");
    const H: u64 = 20; // full_reward_split_daa_score
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0; // overlay active ⇒ the §F carve applies (Some(split))
            dns.full_reward_split_daa_score = H; // Stage 2 (bootstrap) below H, Stage 3 (full) at/above
            // pos_v2 stays fenced (preset u64::MAX) — §F fee-split staging is independent of the v2 economics.
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // A single, constant miner so every coinbase pays the same spk (the reward is the prev block's
    // carved subsidy — the coinbase pays its mergeset miner).
    let v = dns_harness::harness_validator([0x42u8; 32]);
    let k_spk = p2pkh_mldsa87_spk(&kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes());
    let miner = MinerData::new(k_spk.clone(), vec![]);

    let mut rewards: Vec<(u64, u64)> = Vec::new(); // (block daa_score, miner's coinbase reward)
    for _ in 0..(H + 15) {
        let b = ctx.mine_block(miner.clone(), vec![]).await;
        assert_eq!(
            ctx.consensus.block_status(b.header.hash),
            BlockStatus::StatusUTXOValid,
            "every block stays UTXO-valid across the staged-split boundary (construction == validation)"
        );
        let r: u64 = b.transactions[0].outputs.iter().filter(|o| o.script_public_key == k_spk).map(|o| o.value).sum();
        rewards.push((b.header.daa_score, r));
    }

    // The coinbase of a block at DAA d carves the mergeset (prev block's) subsidy by the split
    // SELECTED FROM d. Sample a block clearly in Stage 2 (bootstrap) and one clearly in Stage 3
    // (full); both adjacent enough that subsidy decay is negligible, so the ratio isolates the carve.
    let stage2 = rewards.iter().rev().find(|(d, r)| *d < H && *r > 0).map(|(_, r)| *r).expect("a Stage-2 reward");
    let stage3 = rewards.iter().find(|(d, r)| *d >= H && *r > 0).map(|(_, r)| *r).expect("a Stage-3 reward");
    // Worker base share drops 8200bps → 6200bps ⇒ ratio ≈ 0.7561. Tolerance absorbs the tiny per-block decay.
    let ratio = stage3 as f64 / stage2 as f64;
    assert!(
        (0.74..=0.77).contains(&ratio),
        "the miner's subsidy share drops at the boundary by the bootstrap→full worker-base carve (8200→6200bps ≈ 0.756); got stage2={stage2} stage3={stage3} ratio={ratio:.4}"
    );
}

/// kaspa-pq ADR-0018 §G (DAG-7) — MULTI-NODE mesh convergence with the DNS overlay ACTIVE. Three
/// independent consensus instances (same overlay-active config) each mine a DIVERGENT chain from
/// genesis; then every block is gossiped to every node. All three must converge on the SAME sink —
/// i.e. the overlay's per-block machinery (epoch accumulator / reserve / rewarded-keys stores) and
/// the reorg gate (dormant here: no attestations ⇒ no confirmed anchor) do NOT break GHOSTDAG's
/// deterministic multi-node convergence. Complements the single-instance wide-DAG anchor-agreement
/// test (which proves divergent VIEWS pick one anchor) with real cross-instance block exchange.
#[tokio::test]
async fn dag7_multi_node_mesh_converges_with_overlay_active() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 8; // enough to merge the divergent tips
            p.mergeset_size_limit = 16;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0; // overlay ACTIVE on every node
            p.dns_params = Some(dns);
        })
        .build();

    // Three nodes, each mining a chain of a DIFFERENT length from genesis (genuinely divergent tips).
    let mut nodes: Vec<TestContext> = (0..3).map(|_| TestContext::new(TestConsensus::new(&config))).collect();
    let lengths = [5usize, 8, 6];
    let mut chains: Vec<Vec<Block>> = Vec::new();
    for i in 0..nodes.len() {
        let mut blocks = Vec::new();
        for _ in 0..lengths[i] {
            blocks.push(nodes[i].mine_block(new_miner_data(), vec![]).await);
        }
        chains.push(blocks);
    }

    // Before gossip the nodes disagree (each sees only its own chain's tip).
    let pre: Vec<_> = nodes.iter().map(|n| n.consensus.get_sink()).collect();
    assert!(pre[0] != pre[1] || pre[1] != pre[2], "pre-gossip the nodes' sinks diverge");

    // Gossip: deliver every OTHER node's chain (parents-first) to each node.
    // Index-based: the inner `i == j` skip needs both indices, and `nodes[i]` is
    // borrowed mutably while `chains[j]` is borrowed immutably in the same body.
    #[allow(clippy::needless_range_loop)]
    for i in 0..nodes.len() {
        for j in 0..chains.len() {
            if i == j {
                continue;
            }
            for b in &chains[j] {
                nodes[i].validate_and_insert_block(b.clone()).await;
            }
        }
    }

    // After gossip every node holds the identical union DAG ⇒ all converge on ONE sink.
    let sinks: Vec<_> = nodes.iter().map(|n| n.consensus.get_sink()).collect();
    assert_eq!(sinks[0], sinks[1], "node 0 and node 1 converge on the same sink ({} vs {})", sinks[0], sinks[1]);
    assert_eq!(sinks[1], sinks[2], "node 1 and node 2 converge on the same sink ({} vs {})", sinks[1], sinks[2]);
    // The converged sink is the heaviest divergent chain's tip (node 1's 8-block chain), and every
    // node's chosen sink is one of the gossiped tips (a real block, not genesis).
    let tips: std::collections::HashSet<_> = chains.iter().map(|c| c.last().unwrap().header.hash).collect();
    assert!(tips.contains(&sinks[0]), "the converged sink is one of the mined chain tips");
}

/// kaspa-pq H-06 (unbond lifecycle): full-consensus unbond-REQUEST e2e + the client-side
/// funded builder (`funded_signed_unbond_tx`). A funded, ML-DSA-87-signed bond goes
/// Active; the owner then submits a funded, signed `StakeUnbondRequest` — the shape an
/// operator's exit tool produces. The including block must validate, exercising the live
/// unbond-authorization rule (`unbond_request_authorized`: bond present, Pending/Active,
/// owner-key binding `validator_id_from_pubkey(owner) == bond.owner_pubkey_hash`, and the
/// ML-DSA-87 signature over the bond-bound `unbond_request_message` under
/// `UNBOND_REQUEST_CONTEXT`). The release-after-`unbonding_period_blocks` spend is covered
/// by the apply-path unit tests (`allows_spend_of_releasable_bond`).
#[tokio::test]
async fn pos_v2_funded_unbond_request_validates() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let bond_amount = value_a - 100_000;
    let (bond_tx, _vid, _rp) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, bond_amount, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid, "the bond block must be UTXO-valid");
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    // Bury the bond so its record is committed into the active bond view the unbond rule reads.
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    // The owner submits a funded, ML-DSA-87-signed unbond request; the block must validate.
    // audit M-04: the authorization binds the network id (genesis hash), as the consensus rule reconstructs it.
    let net_id = ctx.consensus.params().genesis.hash;
    let unbond_tx = dns_harness::funded_signed_unbond_tx(
        seed,
        net_id.as_byte_slice(),
        coinbase_b,
        value_b,
        daa_b,
        bond_outpoint,
        storage_mass_parameter,
    );
    let unbond_block = ctx.mine_block(new_miner_data(), vec![unbond_tx]).await;
    assert_eq!(
        ctx.consensus.block_status(unbond_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the owner-authorized funded unbond request must validate through full consensus"
    );
}

/// kaspa-pq DNS v3 (PR2b): the processor's blue_score canonical-anchor walk
/// (`canonical_anchor_by_blue_score`) feeds the pure core the *real* selected-chain
/// `(hash, blue_score, daa_score)` ancestors, so the anchor it returns is a genuine
/// selected-chain block, most-recent-at-or-below the epoch cutoff, and stable as the tip
/// advances (the v3 position-invariance property). The hot path does not call it yet (PR4
/// wires it into the verifier), so this white-box test is the only thing exercising the
/// store walk until then. A future / unburied epoch must return `None`, never the tip.
#[tokio::test]
async fn dns_v3_canonical_anchor_walk_matches_chain() {
    use std::collections::HashMap;
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            // Tiny blue_score epochs so several bury within a short linear chain.
            // L=3, backoff=1 -> cutoff(E) = (E+1)*3 - 1 - 1 = 3E+1; lag=2.
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();

    let mut ctx = TestContext::new(TestConsensus::new(&config));
    // A linear chain (one block per row); each block's only parent is the prior tip, so
    // mergeset_blues = {selected_parent} and blue_score increments by exactly 1 (genesis = 0).
    let miner = new_miner_data();
    let mut by_blue: HashMap<u64, BlockHash> = HashMap::new();
    for _ in 0..20 {
        let b = ctx.mine_block(miner.clone(), vec![]).await;
        by_blue.insert(b.header.blue_score, b.header.hash);
    }

    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let tip = ctx.consensus.get_sink();
    let vp = ctx.consensus.virtual_processor();

    // cutoff(E) = 3E+1 on this dense chain, and every integer blue_score 0..=20 is present
    // exactly once, so the most-recent-at-or-below is the block whose blue_score == cutoff(E).
    let a0 = vp.canonical_anchor_by_blue_score(0, tip, &dns).expect("epoch 0 buried");
    assert_eq!(a0.epoch, 0);
    assert_eq!(a0.cutoff_blue_score, 1);
    assert_eq!(a0.anchor_blue_score, 1);
    assert_eq!(a0.anchor_hash, by_blue[&1], "epoch 0 anchors the real bs=1 block");
    assert!(!a0.duplicate_of_previous_anchor);

    let a1 = vp.canonical_anchor_by_blue_score(1, tip, &dns).expect("epoch 1 buried");
    assert_eq!(a1.cutoff_blue_score, 4);
    assert_eq!(a1.anchor_blue_score, 4);
    assert_eq!(a1.anchor_hash, by_blue[&4], "epoch 1 anchors the real bs=4 block");
    assert!(!a1.duplicate_of_previous_anchor); // distinct anchors on a dense chain

    // Position-invariance: anchor(0) is the SAME block no matter how far the tip advanced
    // (the walk reads blue_score, not the store index) — the core v3 property.
    let mid = by_blue[&10];
    let a0_mid = vp.canonical_anchor_by_blue_score(0, mid, &dns).expect("epoch 0 buried at mid-chain tip");
    assert_eq!(a0_mid.anchor_hash, a0.anchor_hash, "the anchor is independent of the observing tip");

    // A future / unburied epoch has no canonical anchor on this chain (cutoff > tip.blue_score)
    // and must NOT degenerate to returning the tip.
    assert!(vp.canonical_anchor_by_blue_score(1_000_000, tip, &dns).is_none());
}

/// kaspa-pq DNS v3 (PR4) — POSITIVE: an attestation that names THIS chain's canonical
/// lagged anchor for a ready blue_score epoch IS credited by the v3 verifier
/// (`collect_stake_contributions_v2`) with the bond's full stake, the per-epoch
/// denominator is keyed by the CANONICAL anchor DAA, and a ready epoch the validator did
/// NOT attest still appears in the denominator (so a participation gap is visible to φS
/// instead of vanishing — the v1 weakness). Reuses the funded-bond + funded-shard DAG-2
/// harness; the attestation is signed over the canonical `(epoch, anchor_hash,
/// anchor_daa_score)` rather than a free-floating self-reported target.
#[tokio::test]
async fn dns_v3_canonical_attestation_credited() {
    use crate::model::stores::{headers::HeaderStoreReader, stake_bonds::StakeBondsStoreReader};
    use kaspa_consensus_core::{Hash64, dns_finality::ready_epoch_from_tip_blue_score};
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 2;
            dns.max_reorg_horizon_blocks = 2;
            // Small blue_score epochs so several bury within this chain: L=3, backoff=1 ->
            // cutoff(E)=3E+1; lag=2 -> epoch E ready once tip_blue >= 3E+4.
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    // Fund a bond (coinbase_a) + a shard-funding coinbase (coinbase_b), same as the e2e.
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _vid, _reward_payload) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid, "the bond block is UTXO-valid");
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);

    // Bury several blue_score epochs past the bond so a ready, bond-active anchor exists.
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    // THIS chain's canonical anchor for the latest ready epoch at the current sink.
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let latest_ready =
            ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
                .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(latest_ready, sink, &dns).expect("canonical anchor for the ready epoch")
    };

    // Sign an attestation that names the canonical anchor exactly, fund + include it.
    let att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_tx = dns_harness::funded_signed_shard_tx(seed, coinbase_b, value_b, daa_b, att, storage_mass_parameter);
    let reward_block = ctx.mine_block(new_miner_data(), vec![shard_tx]).await;
    assert_eq!(
        ctx.consensus.block_status(reward_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the canonical-attestation block validates"
    );
    // Mine 2 fillers so the shard is MERGED -> accepted by a chain block in past(sink), the
    // view the StakeScore verifier walks (accepted txs, not a block's own body).
    ctx.mine_block(new_miner_data(), vec![]).await;
    ctx.mine_block(new_miner_data(), vec![]).await;

    let new_sink = ctx.consensus.get_sink();
    let (contributions, denom, bond_amount) = {
        let vp = ctx.consensus.virtual_processor();
        let bonds: Vec<_> = vp.stake_bonds_store.read().iterator().filter_map(|r| r.ok().map(|(_, rec)| (*rec).clone())).collect();
        let bond_amount = bonds.iter().find(|b| b.bond_outpoint == bond_outpoint).expect("the funded bond is persisted").amount;
        let (c, d) = vp.collect_stake_contributions_v2(new_sink, None, &bonds, genesis_hash.as_byte_slice(), &dns);
        (c, d, bond_amount)
    };

    // The canonical attestation is credited with the bond's full stake at its epoch.
    let credited = contributions.iter().find(|c| c.bond_outpoint == bond_outpoint).expect("the canonical attestation is credited");
    assert_eq!(credited.epoch, anchor.epoch, "credited at the canonical epoch");
    assert_eq!(credited.signed_weight, bond_amount as u128, "credited with the bond's full stake");
    // The denominator is keyed by the CANONICAL anchor DAA for that epoch.
    assert_eq!(denom.get(&anchor.epoch).copied(), Some(anchor.anchor_daa_score), "denominator keyed by the canonical anchor DAA");
    // A ready epoch with no attestation still appears in the denominator (visible gap).
    assert!(
        denom.keys().any(|&e| !contributions.iter().any(|c| c.epoch == e)),
        "a ready, un-attested epoch is still in the denominator (got epochs {:?})",
        denom.keys().collect::<Vec<_>>()
    );
}

/// kaspa-pq DNS v3 (PR4) — NEGATIVE: a validly-signed, bonded, reward-eligible attestation
/// for a ready epoch whose `target_hash` is NOT this chain's canonical anchor is NOT
/// credited by the v3 verifier. The including block still validates (the reward path is
/// migrated to the canonical rule in PR5; until then a non-canonical attestation can still
/// earn the v1 reward), which is exactly the divergence PR5 closes — here we prove the
/// StakeScore verifier already refuses the non-canonical target.
#[tokio::test]
async fn dns_v3_noncanonical_attestation_rejected() {
    use crate::model::stores::{headers::HeaderStoreReader, stake_bonds::StakeBondsStoreReader};
    use kaspa_consensus_core::{Hash64, dns_finality::ready_epoch_from_tip_blue_score};
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            // Wide reward recency so the canonical anchor is comfortably in-window: the only
            // reason the bogus-target attestation earns nothing is the v3 canonical gate.
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _vid, _reward_payload) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid);
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let latest_ready =
            ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
                .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(latest_ready, sink, &dns).expect("canonical anchor for the ready epoch")
    };

    // Same ready epoch + canonical DAA, but a BOGUS target_hash (not this chain's anchor).
    let bogus_target = Hash64::from_bytes([0xdeu8; 64]);
    assert_ne!(bogus_target, anchor.anchor_hash);
    let att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        bogus_target,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_tx = dns_harness::funded_signed_shard_tx(seed, coinbase_b, value_b, daa_b, att, storage_mass_parameter);
    let reward_block = ctx.mine_block(new_miner_data(), vec![shard_tx]).await;
    assert_eq!(
        ctx.consensus.block_status(reward_block.header.hash),
        BlockStatus::StatusUTXOValid,
        "the block still validates — the canonical-gated reward fan-out simply pays nothing for the non-canonical attestation (same in construction + validation)"
    );
    // PR5: the §E reward fan-out is canonical-gated, so the non-canonical attestation earns
    // NO coinbase reward (only output to K would be the §E reward; the miner is a different spk).
    let reward_to_validator = reward_block.transactions[0].outputs.iter().find(|o| o.script_public_key == k_spk).map(|o| o.value);
    assert_eq!(reward_to_validator, None, "a non-canonical attestation earns no §E reward (PR5)");

    ctx.mine_block(new_miner_data(), vec![]).await;
    ctx.mine_block(new_miner_data(), vec![]).await;

    let new_sink = ctx.consensus.get_sink();
    let (contributions, denom) = {
        let vp = ctx.consensus.virtual_processor();
        let bonds: Vec<_> = vp.stake_bonds_store.read().iterator().filter_map(|r| r.ok().map(|(_, rec)| (*rec).clone())).collect();
        vp.collect_stake_contributions_v2(new_sink, None, &bonds, genesis_hash.as_byte_slice(), &dns)
    };

    // The non-canonical attestation also earns NO StakeScore credit (PR4)...
    assert!(contributions.iter().all(|c| c.bond_outpoint != bond_outpoint), "a non-canonical-target attestation must not be credited");
    // ...even though its epoch IS a ready, creditable epoch (present in the denominator).
    assert!(denom.contains_key(&anchor.epoch), "the epoch is ready/creditable; only the non-canonical target is rejected");
}

/// kaspa-pq DNS v3 (PR3) — the signer hands the validator the canonical lagged anchor, NOT
/// the live sink. The singular `get_validator_attestation_target` returns the oldest READY
/// canonical anchor for which the requested bond is Active (matching the hard-inclusion gate's
/// oldest-first backlog order), and the batch `get_validator_attestation_targets` returns every
/// ready, non-duplicate, bond-active epoch ascending up to the latest — so a fallen-behind
/// validator can catch up. Both feed the exact target the PR4 verifier credits.
#[tokio::test]
async fn dns_v3_signer_produces_canonical_ready_targets() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::{Hash64, dns_finality::ready_epoch_from_tip_blue_score};
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _, _) = dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid);
    let outpoint = TransactionOutpoint::new(bond_tx_id, 0);

    let miner = new_miner_data();
    for _ in 0..20 {
        ctx.mine_block(miner.clone(), vec![]).await;
    }

    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let sink = ctx.consensus.get_sink();

    // The singular target == the first batch target: the oldest ready epoch for which this bond is
    // active at the canonical anchor.
    let target = ctx.consensus.get_validator_attestation_target(outpoint).expect("a ready canonical target");
    let (latest_ready, anchor) = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let lr = ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("an epoch is ready");
        (lr, vp.canonical_anchor_by_blue_score(target.epoch, sink, &dns).expect("canonical anchor for the singular target"))
    };
    assert!(target.epoch <= latest_ready, "the singular target is no later than the latest ready epoch");
    assert_eq!(target.target_hash, anchor.anchor_hash, "target is the canonical anchor hash");
    assert_eq!(target.target_daa_score, anchor.anchor_daa_score, "target daa is the canonical anchor daa");
    assert_eq!(target.validator_set_commitment, Hash64::default(), "VSC is a fixed zero (P-1D)");

    // The batch returns every ready, non-duplicate, bond-active epoch ascending up to the latest.
    let targets = ctx.consensus.get_validator_attestation_targets(outpoint, 0, 100);
    assert!(!targets.is_empty());
    assert!(targets.windows(2).all(|w| w[0].epoch < w[1].epoch), "ascending, unique epochs");
    assert_eq!(target.epoch, targets[0].epoch, "singular target follows oldest-first backlog order");
    assert_eq!(targets.last().unwrap().epoch, latest_ready, "the batch reaches the latest ready epoch");
    {
        let vp = ctx.consensus.virtual_processor();
        for t in &targets {
            let a = vp.canonical_anchor_by_blue_score(t.epoch, sink, &dns).expect("each batched epoch has a canonical anchor");
            assert!(!a.duplicate_of_previous_anchor, "duplicate epochs are excluded from the batch");
            assert_eq!(t.target_hash, a.anchor_hash);
            assert_eq!(t.target_daa_score, a.anchor_daa_score);
        }
    }

    // A `from_epoch` past the latest ready epoch yields nothing (no future epochs to sign).
    assert!(ctx.consensus.get_validator_attestation_targets(outpoint, latest_ready + 1, 100).is_empty());
}

/// kaspa-pq DNS v3 (PR6) — high-parallel no-hole: on a WIDE DAG the selected chain's
/// blue_score jumps by the merged-set size, skipping whole epoch [start, end] ranges. Every
/// buried epoch must still resolve to a canonical anchor (the most-recent selected-chain block
/// at-or-below its cutoff — which, for a skipped epoch, is a block below the jump → a
/// correctly-flagged duplicate), NEVER a hole (None / panic). This is the DAG-level analogue of
/// PR2a's pure `no-hole-on-jump` test, exercising the real store walk over a jumpy chain.
#[tokio::test]
async fn dns_v3_high_parallel_blue_score_jump_no_hole() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::dns_finality::ready_epoch_from_tip_blue_score;
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 16;
            p.mergeset_size_limit = 16;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            // Small epochs vs. wide merges (up to 16) so a single merge jumps past whole epochs.
            dns.attestation_epoch_length_blue_score = 5;
            dns.attestation_lag_blue_score = 3;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 100_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Warm up, then alternate WIDE antichains + single merge blocks so the selected chain's
    // blue_score jumps by the merged set size (skipping whole epoch ranges), then settle.
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    }
    for _ in 0..4 {
        ctx.build_block_template_row(0..14).validate_and_insert_row().await; // wide antichain
        ctx.build_block_template_row(0..1).validate_and_insert_row().await; // merge -> blue_score jump
    }
    for _ in 0..6 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    }
    ctx.assert_tips_num(1);

    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let sink = ctx.consensus.get_sink();
    let vp = ctx.consensus.virtual_processor();
    let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
    let latest_ready =
        ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("epochs are ready on a chain this long");
    assert!(latest_ready >= 2, "the chain spans several epochs (latest_ready = {latest_ready})");

    // NO HOLE + monotonic: every buried epoch resolves to a canonical anchor whose blue_score is
    // non-decreasing across epochs, even across the blue_score jumps.
    let mut prev_blue = 0u64;
    let mut distinct = std::collections::HashSet::new();
    for e in 0..=latest_ready {
        let a = vp.canonical_anchor_by_blue_score(e, sink, &dns).unwrap_or_else(|| panic!("epoch {e} has no canonical anchor (hole)"));
        assert!(a.anchor_blue_score >= prev_blue, "anchor blue_score is monotonic across epochs");
        prev_blue = a.anchor_blue_score;
        distinct.insert(a.anchor_hash);
    }
    // The wide merges actually skipped >=1 epoch range: fewer distinct anchors than epochs (some
    // epochs share an anchor) — proving the test exercised real blue_score jumps, not a dense chain.
    assert!(
        distinct.len() <= latest_ready as usize,
        "a blue_score jump made >=1 epoch reuse a prior anchor ({} distinct anchors over {} epochs)",
        distinct.len(),
        latest_ready + 1
    );
}

/// kaspa-pq DNS v3 — the validator FUNCTIONS end-to-end: a bonded validator's canonical
/// attestation drives the StakeScore over `required_stake_depth`, so `update_dns_state`
/// promotes the overlay to the `Active` stage AND records a DNS-confirmed anchor — the
/// precondition the §H reorg gate needs to protect finality. Shrunk params: a single
/// validator is the whole active stake, so one fully-attested ready epoch earns exactly
/// `1·SCALE`, clearing `required_stake_depth = SCALE/2`. (Foundation for the 51%-attack test.)
#[tokio::test]
async fn dns_v3_validator_drives_confirmed_anchor() {
    use crate::model::stores::{dns_state::DnsStateStoreReader, headers::HeaderStoreReader};
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{DnsRolloutStage, STAKE_SCORE_SCALE, StakeScore, ready_epoch_from_tip_blue_score},
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap(); // GENESIS_ACTIVE: TwoDimensionalDominance
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            // Confirm on a short chain: work threshold trivial, one fully-attested epoch suffices.
            dns.required_work_depth = kaspa_consensus_core::BlueWorkType::ZERO;
            dns.required_stake_depth = StakeScore(STAKE_SCORE_SCALE / 2);
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);

    // Fund a bond + a shard-funding coinbase.
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _vid, _reward_payload) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid);
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);

    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let lr = ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(lr, sink, &dns).expect("canonical anchor")
    };
    let att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_tx = dns_harness::funded_signed_shard_tx(seed, coinbase_b, value_b, daa_b, att, storage_mass_parameter);
    let reward_block = ctx.mine_block(new_miner_data(), vec![shard_tx]).await;
    assert_eq!(ctx.consensus.block_status(reward_block.header.hash), BlockStatus::StatusUTXOValid);

    // Mine generously so the shard merges (accepted on the selected chain), the attested epoch
    // buries, and update_dns_state recomputes (it throttles to once per blue_score epoch) with
    // the attestation credited -> stake_depth >= required -> the anchor confirms.
    for _ in 0..15 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    let state = {
        let vp = ctx.consensus.virtual_processor();
        vp.dns_state_store.read().get().expect("DnsState is written once the overlay is active")
    };
    assert_eq!(state.rollout_stage, DnsRolloutStage::Active, "one active validator -> Active stage");
    assert!(
        state.stake_depth >= StakeScore(STAKE_SCORE_SCALE / 2),
        "the validator's canonical attestation drove StakeScore over the threshold (got {:?})",
        state.stake_depth
    );
    assert_ne!(
        state.last_dns_confirmed_anchor,
        Hash64::default(),
        "a DNS-confirmed anchor is recorded (the reorg gate now protects it)"
    );
}

/// kaspa-pq DNS-finality (E3/§6.2 template integration) — a refill-capable selector for the
/// template-adoption tests: returns its candidate batches in order (one per
/// `select_transactions` call) and never reports failure on rejection, so a classifier-driven
/// `reject_selection` (an ineligible-shard drop) triggers the builder's refill loop pulling the
/// next batch — exactly the production frontier-selector refill semantics, without a mempool.
struct RefillTxSelector {
    batches: VecDeque<Vec<Transaction>>,
    rejected: Vec<kaspa_consensus_core::tx::TransactionId>,
}

impl RefillTxSelector {
    fn new(batches: Vec<Vec<Transaction>>) -> Self {
        Self { batches: batches.into(), rejected: vec![] }
    }
}

impl TemplateTransactionSelector for RefillTxSelector {
    fn select_transactions(&mut self) -> Vec<Transaction> {
        self.batches.pop_front().unwrap_or_default()
    }
    fn reject_selection(&mut self, tx_id: kaspa_consensus_core::tx::TransactionId) {
        self.rejected.push(tx_id);
    }
    // Infallible from the selector's POV: rejections are refills, not failures. The
    // tests build with `TemplateBuildMode::Infallible` so the rejection never aborts.
    fn is_successful(&self) -> bool {
        true
    }
}

/// Shared setup for the template-adoption tests (E3/§6.2): bond one validator, bury several
/// blue_score epochs so a ready bond-active anchor exists, and return the context plus the
/// validator, the canonical anchor, and TWO matured shard-funding coinbase outpoints (so two
/// distinct funded shards can be built in one test). Mirrors the `dns_v3_*` preamble.
#[cfg(test)]
async fn template_adoption_setup() -> (
    TestContext,
    dns_harness::HarnessValidator,
    TransactionOutpoint,                                            // bond outpoint
    kaspa_consensus_core::dns_finality::CanonicalLaggedEpochAnchor, // canonical anchor for latest ready epoch
    (TransactionOutpoint, u64, u64),                                // shard-funding coinbase #1 (outpoint, value, daa)
    (TransactionOutpoint, u64, u64),                                // shard-funding coinbase #2 (outpoint, value, daa)
    kaspa_consensus_core::dns_finality::DnsParams,
    BlockHash, // genesis hash (net id)
    u64,       // storage_mass_parameter
) {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::dns_finality::ready_epoch_from_tip_blue_score;
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);
    let k_miner = MinerData::new(k_spk.clone(), vec![]);

    // coinbase_a funds the bond; coinbase_b + coinbase_c fund two shards.
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_c = ctx.mine_block(k_miner.clone(), vec![]).await;
    let pick = |h: &Block| {
        let cb = &h.transactions[0];
        let (i, o) = cb.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("pays K");
        (TransactionOutpoint::new(cb.id(), i as u32), o.value, h.header.daa_score)
    };
    let (coinbase_a, value_a, daa_a) = pick(&h_a);
    let cb_b = pick(&h_b);
    let cb_c = pick(&h_c);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _vid, _rp) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid);
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let lr = ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(lr, sink, &dns).expect("canonical anchor")
    };
    (ctx, v, bond_outpoint, anchor, cb_b, cb_c, dns, genesis_hash, storage_mass_parameter)
}

/// kaspa-pq DNS-finality (E3/§6.2, test T3): a mempool-submitted ELIGIBLE attestation shard
/// appears as a non-coinbase tx in `build_block_template` output (the construction path now
/// classifies + keeps eligible shards at selection time instead of dropping them late).
#[tokio::test]
async fn t3_eligible_shard_in_block_template() {
    use kaspa_consensus_core::Hash64;
    let (ctx, v, bond_outpoint, anchor, cb_b, _cb_c, dns, genesis_hash, smp) = template_adoption_setup().await;
    let att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_tx = dns_harness::funded_signed_shard_tx(v.seed, cb_b.0, cb_b.1, cb_b.2, att, smp);
    let shard_id = shard_tx.id();

    let template = ctx
        .consensus
        .build_block_template(new_miner_data(), Box::new(OnetimeTxSelector::new(vec![shard_tx])), TemplateBuildMode::Standard)
        .expect("template builds with the eligible shard");
    // The eligible shard is included as a non-coinbase tx.
    assert!(
        template.block.transactions.iter().skip(1).any(|t| t.id() == shard_id),
        "the eligible attestation shard must appear in the template"
    );
    // T5 (fee alignment): calculated_fees stays 1:1 with the non-coinbase txs.
    assert_eq!(
        template.calculated_fees.len(),
        template.block.transactions.len() - 1,
        "calculated_fees must be 1:1 with the non-coinbase txs"
    );
    let _ = dns; // params used by setup; silence unused on some builds
}

/// kaspa-pq DNS-finality (E3/§6.2, test T4): an INELIGIBLE shard selected first is rejected
/// (refilled) and an ELIGIBLE shard from the next batch is included instead. Uses the
/// refill-capable selector + `Infallible` build so the classifier drop triggers a refill, not
/// a build failure.
#[tokio::test]
async fn t4_ineligible_shard_refilled_with_eligible() {
    use kaspa_consensus_core::Hash64;
    let (ctx, v, bond_outpoint, anchor, cb_b, cb_c, _dns, genesis_hash, smp) = template_adoption_setup().await;

    // Ineligible: correct bond + signature but a WRONG self-declared validator_id (P-1A
    // mismatch) ⇒ classifier `Drop(ValidatorIdMismatch)`. Still a structurally valid funded tx
    // (so it passes block-template tx validation and reaches the classifier).
    let mut bad_att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    bad_att.validator_id = Hash64::from_bytes([0xff; 64]); // ≠ bond.validator_pubkey_hash
    let bad_shard = dns_harness::funded_signed_shard_tx(v.seed, cb_b.0, cb_b.1, cb_b.2, bad_att, smp);
    let bad_id = bad_shard.id();

    // Eligible: correct id + signature + canonical anchor.
    let good_att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let good_shard = dns_harness::funded_signed_shard_tx(v.seed, cb_c.0, cb_c.1, cb_c.2, good_att, smp);
    let good_id = good_shard.id();

    // Batch 1 = the ineligible shard (dropped+refilled); batch 2 = the eligible shard (kept).
    let selector = RefillTxSelector::new(vec![vec![bad_shard], vec![good_shard]]);
    let template = ctx
        .consensus
        .build_block_template(new_miner_data(), Box::new(selector), TemplateBuildMode::Infallible)
        .expect("template builds (infallible)");

    let ids: Vec<_> = template.block.transactions.iter().skip(1).map(|t| t.id()).collect();
    assert!(!ids.contains(&bad_id), "the ineligible shard must be dropped from the template");
    assert!(ids.contains(&good_id), "the eligible refill shard must be included instead");
    // T5 (fee alignment) after a drop+refill: still 1:1.
    assert_eq!(
        template.calculated_fees.len(),
        template.block.transactions.len() - 1,
        "calculated_fees must stay 1:1 with the non-coinbase txs after a drop+refill"
    );
}

/// kaspa-pq DNS-finality (P1, duplicate-epoch credit regression): the SAME (bond, epoch)
/// attestation accepted TWICE on the selected chain is credited to StakeScore only ONCE
/// (`collect_stake_contributions_v2` dedups by the canonical-anchor gate + the
/// `aggregate_epoch_tallies` per-(bond,epoch) collapse). This pins the existing — and, as the
/// investigation found, already-correct — behavior so a future change cannot start double-crediting.
#[tokio::test]
async fn duplicate_epoch_attestation_credited_once() {
    use crate::model::stores::stake_bonds::StakeBondsStoreReader;
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{aggregate_epoch_tallies, total_active_stake_by_epoch},
    };
    let (mut ctx, v, bond_outpoint, anchor, cb_b, cb_c, dns, genesis_hash, smp) = template_adoption_setup().await;

    // Two shards naming the SAME canonical (epoch, anchor) for the SAME bond, funded from two
    // distinct coinbases so both are structurally valid + can both be mined/accepted.
    let mk = |cb: (TransactionOutpoint, u64, u64)| {
        let att = dns_harness::build_signed_attestation(
            &v,
            genesis_hash.as_byte_slice(),
            bond_outpoint,
            anchor.epoch,
            anchor.anchor_hash,
            anchor.anchor_daa_score,
            Hash64::default(),
        );
        dns_harness::funded_signed_shard_tx(v.seed, cb.0, cb.1, cb.2, att, smp)
    };
    let shard1 = mk(cb_b);
    let shard2 = mk(cb_c);
    let b1 = ctx.mine_block(new_miner_data(), vec![shard1]).await;
    assert_eq!(ctx.consensus.block_status(b1.header.hash), BlockStatus::StatusUTXOValid);
    let b2 = ctx.mine_block(new_miner_data(), vec![shard2]).await;
    assert_eq!(ctx.consensus.block_status(b2.header.hash), BlockStatus::StatusUTXOValid);
    // Bury so both merge onto the selected chain.
    for _ in 0..4 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    let new_sink = ctx.consensus.get_sink();
    let vp = ctx.consensus.virtual_processor();
    let bonds: Vec<_> = vp.stake_bonds_store.read().iterator().filter_map(|r| r.ok().map(|(_, rec)| (*rec).clone())).collect();
    let (contributions, denom) = vp.collect_stake_contributions_v2(new_sink, None, &bonds, genesis_hash.as_byte_slice(), &dns);

    // The (bond, epoch) pair is credited at most once even though two shards carry it.
    let credited_for_epoch = contributions.iter().filter(|c| c.bond_outpoint == bond_outpoint && c.epoch == anchor.epoch).count();
    assert!(credited_for_epoch >= 1, "the canonical attestation is credited at least once");
    // After the per-(bond,epoch) aggregation, the signed stake for this epoch equals the bond's
    // stake exactly ONCE (no double-count from the duplicate shard).
    let totals = total_active_stake_by_epoch(&bonds, &denom);
    let per_epoch = aggregate_epoch_tallies(&contributions, &totals);
    let bond_amount = bonds.iter().find(|b| b.bond_outpoint == bond_outpoint).expect("bond persisted").amount;
    let tally = per_epoch.iter().find(|t| t.epoch == anchor.epoch).expect("the epoch is tallied");
    assert_eq!(
        tally.signed_weight, bond_amount as u128,
        "the duplicate (bond, epoch) is credited exactly once (signed stake == one bond's stake, got {})",
        tally.signed_weight
    );
}

/// kaspa-pq DNS v3 (§H finality) — **51%-PoW attack is stopped**: a stake-less attacker that
/// out-mines the honest chain (strictly higher blue_work — a PoW majority) CANNOT rewrite a
/// DNS-confirmed anchor. The honest node bonds a validator and reaches a confirmed anchor;
/// a second consensus instance (the attacker, same genesis) mines a longer STAKE-LESS chain;
/// its heavier blocks are delivered to the honest node, whose sink-search runs the
/// `TwoDimensionalDominance` gate (`dns_reorg_allows`): the candidate exits the confirmed
/// prefix and out-Works but does NOT out-Stake (zero attestations) → `DominanceViolation` →
/// soft-reject. The honest sink therefore STILL contains the confirmed anchor, never the
/// heavier attacker tip — PoW surplus does not substitute for a PoS deficit (the
/// non-substitutability finality property). Completes the PR6-deferred 51%-finality-stop sim.
#[tokio::test]
async fn dns_v3_pow_majority_cannot_rewrite_confirmed_anchor() {
    use crate::model::stores::{dns_state::DnsStateStoreReader, ghostdag::GhostdagStoreReader, headers::HeaderStoreReader};
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{DnsRolloutStage, STAKE_SCORE_SCALE, StakeScore, ready_epoch_from_tip_blue_score},
    };
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap(); // GENESIS_ACTIVE: TwoDimensionalDominance
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            // Large reorg horizon so a from-genesis fork is GATE-ELIGIBLE (the dominance test
            // runs) instead of being auto-rejected as deeper than the horizon.
            dns.max_reorg_horizon_blocks = 1000;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            dns.required_work_depth = kaspa_consensus_core::BlueWorkType::ZERO;
            dns.required_stake_depth = StakeScore(STAKE_SCORE_SCALE / 2);
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // ---- Honest node: bond a validator, attest, reach a DNS-confirmed anchor. ----
    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
    let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
    let cb_a = &h_a.transactions[0];
    let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
    let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
    let cb_b = &h_b.transactions[0];
    let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
    let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _vid, _rp) =
        dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage_mass_parameter);
    let bond_tx_id = bond_tx.id();
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid);
    let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let sink = ctx.consensus.get_sink();
    let anchor = {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let lr = ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
            .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(lr, sink, &dns).expect("canonical anchor")
    };
    let att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        anchor.epoch,
        anchor.anchor_hash,
        anchor.anchor_daa_score,
        Hash64::default(),
    );
    let shard_tx = dns_harness::funded_signed_shard_tx(seed, coinbase_b, value_b, daa_b, att, storage_mass_parameter);
    ctx.mine_block(new_miner_data(), vec![shard_tx]).await;
    for _ in 0..15 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    let honest_sink = ctx.consensus.get_sink();
    let (confirmed_anchor, honest_work) = {
        let vp = ctx.consensus.virtual_processor();
        let st = vp.dns_state_store.read().get().expect("DnsState");
        assert_eq!(st.rollout_stage, DnsRolloutStage::Active, "honest node is Active");
        assert_ne!(st.last_dns_confirmed_anchor, Hash64::default(), "honest node has a confirmed anchor");
        (st.last_dns_confirmed_anchor, vp.ghostdag_store.get_blue_work(honest_sink).unwrap())
    };

    // ---- Attacker: a SEPARATE instance (same genesis) mines a longer STAKE-LESS chain. ----
    let mut atk = TestContext::new(TestConsensus::new(&config));
    let mut attacker_blocks = Vec::new();
    for _ in 0..60 {
        attacker_blocks.push(atk.mine_block(new_miner_data(), vec![]).await);
    }
    let attacker_tip = attacker_blocks.last().unwrap().header.hash;
    let attacker_work = { atk.consensus.virtual_processor().ghostdag_store.get_blue_work(attacker_tip).unwrap() };
    assert!(
        attacker_work > honest_work,
        "the attacker is a genuine PoW majority (heavier blue_work): attacker {attacker_work} vs honest {honest_work}"
    );

    // ---- Deliver the attacker's heavier branch to the honest node. ----
    for b in &attacker_blocks {
        ctx.validate_and_insert_block(b.clone()).await;
    }

    // ---- Finality held: the honest sink STILL contains the confirmed anchor, NOT the heavier
    //      attacker tip. PoW surplus could not substitute for the attacker's zero stake. ----
    let new_sink = ctx.consensus.get_sink();
    assert_ne!(new_sink, attacker_tip, "the honest node did NOT reorg onto the heavier stake-less attacker chain");
    {
        let vp = ctx.consensus.virtual_processor();
        assert!(
            vp.reachability_service.is_chain_ancestor_of(confirmed_anchor, new_sink),
            "the DNS-confirmed anchor is still on the selected chain (the reorg gate stopped the 51% attack)"
        );
        // The confirmed anchor is unchanged — finality was not rewritten.
        let st = vp.dns_state_store.read().get().expect("DnsState");
        assert_eq!(st.last_dns_confirmed_anchor, confirmed_anchor, "the confirmed anchor was not rewritten by the attack");
    }
}

/// kaspa-pq DNS v3 — **many validators converge on ONE anchor at the epoch boundary**, the
/// core reason v3 replaces v1 current-sink signing. Under fast mining / a wide DAG, validators
/// transiently observe DIFFERENT sinks (the multi-tip frontier + propagation lag) — v1 had each
/// sign its own differing sink, splitting honest stake below φS. Here we build a wide DAG, take
/// many divergent validator VIEWS (the multiple frontier tips a fast network produces + lagging
/// ancestors at different heights), and show that although their views differ (≥2 distinct
/// blocks → ≥2 distinct v1 sink-targets), every one of them computes the SAME v3 canonical
/// lagged anchor for a buried epoch (exactly 1) — unanimous, so honest stake never splits.
#[tokio::test]
async fn dns_v3_many_validators_agree_on_anchor_under_fast_wide_dag() {
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::dns_finality::ready_epoch_from_tip_blue_score;
    use std::collections::HashSet;
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 16;
            p.mergeset_size_limit = 16;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
            dns.dns_activation_daa_score = 0;
            // Moderate epoch + a generous lag so the latest ready epoch's anchor is buried well
            // below the churning multi-tip frontier (where the views diverge) into shared history.
            dns.attestation_epoch_length_blue_score = 5;
            dns.attestation_lag_blue_score = 20;
            dns.attestation_anchor_backoff_blue_score = 2;
            dns.stake_score_window_blue_score = 100_000;
            p.dns_params = Some(dns);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Fast mining / wide DAG: wide antichains merged repeatedly, ENDING on a wide antichain so the
    // frontier is genuinely multi-tip (the different sinks a fast network's validators observe).
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    }
    for _ in 0..6 {
        ctx.build_block_template_row(0..12).validate_and_insert_row().await; // wide antichain
        ctx.build_block_template_row(0..1).validate_and_insert_row().await; // merge -> blue_score jump
    }
    ctx.build_block_template_row(0..12).validate_and_insert_row().await; // leave a multi-tip frontier

    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let sink = ctx.consensus.get_sink();

    // Collect many divergent VALIDATOR VIEWS: every frontier tip (a fast network's competing
    // sinks) + several RECENT lagging ancestors at different heights (validators a little behind
    // on propagation — but still past the readiness threshold, like real honest nodes).
    let mut views: Vec<BlockHash> = ctx.consensus.get_tips().into_iter().collect();
    {
        let vp = ctx.consensus.virtual_processor();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        for anc in vp.reachability_service.default_backward_chain_iterator(sink) {
            let b = vp.headers_store.get_blue_score(anc).unwrap();
            // Only "slightly behind" validators (recent ancestors); stop once we'd reach nodes too
            // far back to have a ready epoch (a genesis-deep view is not a realistic poll state).
            if sink_blue.saturating_sub(b) > 40
                || ready_epoch_from_tip_blue_score(b, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
                    .is_none()
            {
                break;
            }
            views.push(anc);
            if views.len() >= 24 {
                break;
            }
        }
    }
    views.sort();
    views.dedup();

    let (anchors, blue_scores, buried_epoch) = {
        let vp = ctx.consensus.virtual_processor();
        // A buried epoch every view agrees is ready: the min over views of each view's latest
        // ready epoch (so canonical_anchor_by_blue_score returns Some for every view).
        let buried_epoch = views
            .iter()
            .map(|t| {
                let b = vp.headers_store.get_blue_score(*t).unwrap();
                ready_epoch_from_tip_blue_score(b, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
                    .expect("each view has at least one ready epoch")
            })
            .min()
            .unwrap();
        let anchors: HashSet<BlockHash> = views
            .iter()
            .map(|t| {
                vp.canonical_anchor_by_blue_score(buried_epoch, *t, &dns).expect("every view resolves the buried epoch").anchor_hash
            })
            .collect();
        let blue_scores: HashSet<u64> = views.iter().map(|t| vp.headers_store.get_blue_score(*t).unwrap()).collect();
        (anchors, blue_scores, buried_epoch)
    };

    // The views are genuinely divergent (a fast network: many distinct tips at several heights) —
    // under v1 these would be ≥2 different current-sink targets, splitting honest stake.
    assert!(views.len() >= 5, "many validator views ({})", views.len());
    assert!(blue_scores.len() >= 2, "the views sit at genuinely different positions (would be different v1 sinks)");
    // ...yet under v3 every view computes the SAME canonical anchor for the buried epoch.
    assert_eq!(
        anchors.len(),
        1,
        "all {} validator views must agree on ONE canonical anchor for epoch {} (got {} distinct)",
        views.len(),
        buried_epoch,
        anchors.len()
    );
}

/// kaspa-pq Layer-0 (audit M-3, updated for ADR-0007 Phase 3): a header whose
/// `pow_algo_id` is not the algo the network mandates at its DAA score is
/// rejected by header-in-isolation validation. On the BLAKE2b-SHA3-active mainnet
/// params the mandated id is `3`, so both the wrong-but-known Phase-1 id (`1` —
/// a miner trying the cheap kHeavyHash on a BLAKE2b-SHA3 network) and a garbage id
/// (`99`) must be rejected, before the PoW seed — which consumes algo_id — is
/// even derived.
#[tokio::test]
async fn header_with_unknown_pow_algo_id_is_rejected() {
    use kaspa_consensus_core::errors::block::RuleError;
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    // Establish a virtual chain with one valid (template-built ⇒ correct algo id) block.
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();

    // Corrupt the algo id to the wrong-but-known Phase-1 id and re-finalize.
    let mut t = ctx.build_block_template(0, ctx.simulated_time + 1_000);
    t.block.header.pow_algo_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_KHEAVYHASH;
    t.block.header.finalize();
    let res = ctx.consensus.validate_and_insert_block(t.block.to_immutable()).block_task.await;
    assert!(matches!(res, Err(RuleError::UnknownPowAlgoId(1))), "expected UnknownPowAlgoId(1), got {res:?}");

    // A garbage id is rejected the same way.
    let mut t = ctx.build_block_template(0, ctx.simulated_time + 2_000);
    t.block.header.pow_algo_id = 99;
    t.block.header.finalize();
    let res = ctx.consensus.validate_and_insert_block(t.block.to_immutable()).block_task.await;
    assert!(matches!(res, Err(RuleError::UnknownPowAlgoId(99))), "expected UnknownPowAlgoId(99), got {res:?}");
}

// ============================================================================
// kaspa-pq ADR-0018 §G — DNS-overlay DAG integration harness (foundation).
//
// Retires the "ML-DSA-87 signing unavailable in the consensus test crate"
// blocker for the reward-bearing / reorg / slashing DAG tests (DAG-2..7): these
// helpers let a consensus test build stake-bond + attestation-shard txs and
// produce an attestation signature the §B.4 verifier
// (`kaspa_txscript::verify_mldsa87_with_context` under
// `ATTESTATION_MLDSA87_CONTEXT`) accepts. Funding a bond tx from a coinbase UTXO
// (so a full reward-bearing chain validates) is the next harness step (DAG-2).
// ============================================================================
#[cfg(test)]
mod dns_harness {
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{
            ATTESTATION_MLDSA87_CONTEXT, DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload, StakeAttestation, StakeBondPayload,
            StakeUnbondRequestPayload, UNBOND_REQUEST_CONTEXT, attestations_from_accepted_txs, p2pkh_mldsa87_spk,
            single_attestation_shard, stake_attestation_message, stake_attestation_shard_tx, unbond_request_message,
            validator_id_from_pubkey,
        },
        hashing::sighash::{Mldsa87SigHashReusedValuesUnsync, calc_mldsa87_signature_hash},
        hashing::sighash_type::SIG_HASH_ALL,
        mass::MassCalculator,
        subnets::{
            SUBNETWORK_ID_NATIVE, SUBNETWORK_ID_SLASHING_EVIDENCE, SUBNETWORK_ID_STAKE_ATTESTATION_SHARD, SUBNETWORK_ID_STAKE_BOND,
            SUBNETWORK_ID_STAKE_UNBOND,
        },
        tx::{PopulatedTransaction, Transaction, TransactionInput, TransactionOutpoint, TransactionOutput, UtxoEntry},
    };
    use kaspa_txscript::{MLDSA87_TX_CONTEXT, script_builder::ScriptBuilder};
    use libcrux_ml_dsa::ml_dsa_87 as mldsa;

    /// A test validator: an ML-DSA-87 key (re-derived deterministically from
    /// `seed`) plus its 2592-byte pubkey and overlay `validator_id`.
    pub(super) struct HarnessValidator {
        pub seed: [u8; 32],
        pub pubkey: Vec<u8>,
        pub validator_id: Hash64,
    }

    pub(super) fn harness_validator(seed: [u8; 32]) -> HarnessValidator {
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let validator_id = validator_id_from_pubkey(&pubkey);
        HarnessValidator { seed, pubkey, validator_id }
    }

    /// Build a stake-bond tx (subnetwork `SUBNETWORK_ID_STAKE_BOND`, payload =
    /// borsh `StakeBondPayload`). The funded variant (output-0 = `amount` locked
    /// stake spent from a coinbase UTXO) is the next step; here the tx is
    /// payload-first for shape / borsh checks.
    pub(super) fn build_stake_bond_tx(
        v: &HarnessValidator,
        amount: u64,
        activation_daa_score: u64,
        reward_payload: [u8; 64],
    ) -> Transaction {
        let payload = StakeBondPayload {
            version: DNS_PAYLOAD_VERSION_V1,
            owner_pubkey_hash: v.validator_id,
            validator_pubkey_hash: v.validator_id,
            validator_pubkey: v.pubkey.clone(),
            amount,
            activation_daa_score,
            unbonding_period_blocks: 700,
            owner_reward_spk_payload: reward_payload,
        };
        Transaction::new(
            crate::constants::TX_VERSION,
            vec![],
            vec![],
            0,
            SUBNETWORK_ID_STAKE_BOND,
            0,
            borsh::to_vec(&payload).unwrap(),
        )
    }

    /// kaspa-pq ADR-0018 §G (DAG-2): build a FUNDED, ML-DSA-87-signed stake-bond tx.
    /// Spends the matured coinbase UTXO `coinbase_outpoint` (value `coinbase_value`,
    /// paid to this validator's own P2PKH) into output-0 = `amount` locked stake
    /// (P2PKH to the same key), carrying the `StakeBondPayload`. Input-0 is signed
    /// over `calc_mldsa87_signature_hash(.., SIG_HASH_ALL)` under `MLDSA87_TX_CONTEXT`
    /// — the exact 64-byte digest `OpCheckSigMlDsa87` recomputes — so the block
    /// validates through the full script engine (construction == validation).
    /// Returns `(signed tx, validator_id, owner_reward_spk_payload)`.
    pub(super) fn funded_signed_bond_tx(
        seed: [u8; 32],
        coinbase_outpoint: TransactionOutpoint,
        coinbase_value: u64,
        coinbase_daa_score: u64,
        amount: u64,
        activation_daa_score: u64,
        storage_mass_parameter: u64,
    ) -> (Transaction, Hash64, [u8; 64]) {
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let validator_id = validator_id_from_pubkey(&pubkey);
        // Keyed BLAKE2b-512 address payload (the same digest the spk's OP_BLAKE2B_512
        // recomputes); rewards + the locked-stake output both pay this P2PKH.
        let reward_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&reward_payload);

        let payload = StakeBondPayload {
            version: DNS_PAYLOAD_VERSION_V1,
            owner_pubkey_hash: validator_id,
            validator_pubkey_hash: validator_id,
            validator_pubkey: pubkey.clone(),
            amount,
            activation_daa_score,
            unbonding_period_blocks: 700,
            owner_reward_spk_payload: reward_payload,
        };
        // input-0 spends the coinbase; output-0 = the locked stake; fee = coinbase_value - amount.
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(coinbase_outpoint, vec![], 0, 1)],
            vec![TransactionOutput::new(amount, spk.clone())],
            0,
            SUBNETWORK_ID_STAKE_BOND,
            0,
            borsh::to_vec(&payload).unwrap(),
        );

        // KIP-9 storage-mass commitment: value-based, so independent of the (still
        // empty) signature_script — committing it now matches the validator's
        // `calc_contextual_masses(..).storage_mass` recheck (else WrongMass).
        let utxo = UtxoEntry::new(coinbase_value, spk, coinbase_daa_score, true);
        let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the funded bond tx")
            .storage_mass;
        tx.set_mass(storage_mass);

        // Sign input-0 over the SIG_HASH_ALL digest of the (mass-committed) tx.
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0x77u8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        let sig_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("ML-DSA-87 signature push fits MAX_SCRIPT_ELEMENT_SIZE")
            .add_data(&pubkey)
            .expect("ML-DSA-87 public-key push fits MAX_SCRIPT_ELEMENT_SIZE")
            .drain();
        tx.inputs[0].signature_script = sig_script;
        (tx, validator_id, reward_payload)
    }

    /// kaspa-pq ADR-0018 §G (DAG-2): build a FUNDED, ML-DSA-87-signed attestation
    /// shard tx — the production shape (`build_funded_shard_tx`). A canonical 0-input
    /// shard tx is rejected by the isolation `NoTxInputs` check, so the shard must
    /// spend a (matured) coinbase like any other tx: one P2PKH change output back to
    /// the same key, with the attestation carried verbatim in the payload on
    /// `SUBNETWORK_ID_STAKE_ATTESTATION_SHARD`. Input-0 is ML-DSA-signed over the v2
    /// tx sighash; the storage mass is committed.
    pub(super) fn funded_signed_shard_tx(
        seed: [u8; 32],
        coinbase_outpoint: TransactionOutpoint,
        coinbase_value: u64,
        coinbase_daa_score: u64,
        attestation: StakeAttestation,
        storage_mass_parameter: u64,
    ) -> Transaction {
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let reward_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&reward_payload);
        // The payload is exactly what the canonical zero-input shard builder emits.
        let payload = stake_attestation_shard_tx(&single_attestation_shard(attestation)).payload;
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(coinbase_outpoint, vec![], 0, 1)],
            vec![TransactionOutput::new(coinbase_value - 100_000, spk.clone())],
            0,
            SUBNETWORK_ID_STAKE_ATTESTATION_SHARD,
            0,
            payload,
        );
        let utxo = UtxoEntry::new(coinbase_value, spk, coinbase_daa_score, true);
        let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the funded shard tx")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0x88u8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        let sig_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("ML-DSA-87 signature push fits MAX_SCRIPT_ELEMENT_SIZE")
            .add_data(&pubkey)
            .expect("ML-DSA-87 public-key push fits MAX_SCRIPT_ELEMENT_SIZE")
            .drain();
        tx.inputs[0].signature_script = sig_script;
        tx
    }

    /// kaspa-pq ADR-0018 §G (DAG-6): build a FUNDED, ML-DSA-87-signed slashing-evidence
    /// tx. Spends the matured coinbase `coinbase_outpoint` (paid to this key's P2PKH) with
    /// **no outputs** — the reporter reward is minted by consensus as a side-effect at
    /// `(tx, 0)` (ADR-0013 Addendum C.2), so any declared output would collide with the
    /// mint — carrying the `SlashingEvidencePayload` on `SUBNETWORK_ID_SLASHING_EVIDENCE`.
    /// Input-0 is ML-DSA-87-signed over the v2 sighash and the storage mass is committed,
    /// so the block validates through the full script engine (construction == validation).
    pub(super) fn funded_signed_slashing_evidence_tx(
        seed: [u8; 32],
        coinbase_outpoint: TransactionOutpoint,
        coinbase_value: u64,
        coinbase_daa_score: u64,
        evidence: SlashingEvidencePayload,
        storage_mass_parameter: u64,
    ) -> Transaction {
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let reward_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&reward_payload);
        // Evidence tx: input-0 funds it (the entire value becomes fee), NO outputs.
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(coinbase_outpoint, vec![], 0, 1)],
            vec![],
            0,
            SUBNETWORK_ID_SLASHING_EVIDENCE,
            0,
            borsh::to_vec(&evidence).unwrap(),
        );
        let utxo = UtxoEntry::new(coinbase_value, spk, coinbase_daa_score, true);
        let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the funded slashing-evidence tx")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0x99u8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        let sig_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("ML-DSA-87 signature push fits MAX_SCRIPT_ELEMENT_SIZE")
            .add_data(&pubkey)
            .expect("ML-DSA-87 public-key push fits MAX_SCRIPT_ELEMENT_SIZE")
            .drain();
        tx.inputs[0].signature_script = sig_script;
        tx
    }

    /// kaspa-pq H-06 (unbond lifecycle): build a FUNDED, ML-DSA-87-signed stake-unbond
    /// request tx — the client-side shape an operator submits to exit a bond. Spends the
    /// matured coinbase into one P2PKH change output (subnet `SUBNETWORK_ID_STAKE_UNBOND`),
    /// carrying a `StakeUnbondRequestPayload` whose `signature` is the owner's ML-DSA-87
    /// signature over `unbond_request_message(bond)` under `UNBOND_REQUEST_CONTEXT`
    /// (the digest the stateful `unbond_request_authorized` rule reconstructs). Input-0 is
    /// signed over the v2 tx sighash so the block validates through the script engine.
    pub(super) fn funded_signed_unbond_tx(
        seed: [u8; 32],
        net_id: &[u8],
        coinbase_outpoint: TransactionOutpoint,
        coinbase_value: u64,
        coinbase_daa_score: u64,
        bond_outpoint: TransactionOutpoint,
        storage_mass_parameter: u64,
    ) -> Transaction {
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let reward_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&reward_payload);
        // Owner authorization: ML-DSA-87 signature over the network- and bond-bound unbond message (M-04).
        let auth_digest = unbond_request_message(net_id, bond_outpoint);
        let auth_sig = mldsa::sign(&kp.signing_key, &auth_digest.as_bytes()[..], UNBOND_REQUEST_CONTEXT, [0xaau8; 32])
            .expect("ML-DSA-87 unbond authorization sign");
        let payload = borsh::to_vec(&StakeUnbondRequestPayload {
            version: DNS_PAYLOAD_VERSION_V1,
            bond_outpoint,
            owner_pubkey: pubkey.clone(),
            signature: auth_sig.as_ref().to_vec(),
        })
        .unwrap();
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(coinbase_outpoint, vec![], 0, 1)],
            vec![TransactionOutput::new(coinbase_value - 100_000, spk.clone())],
            0,
            SUBNETWORK_ID_STAKE_UNBOND,
            0,
            payload,
        );
        let utxo = UtxoEntry::new(coinbase_value, spk, coinbase_daa_score, true);
        let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the funded unbond tx")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0xabu8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        let sig_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("ML-DSA-87 signature push fits MAX_SCRIPT_ELEMENT_SIZE")
            .add_data(&pubkey)
            .expect("ML-DSA-87 public-key push fits MAX_SCRIPT_ELEMENT_SIZE")
            .drain();
        tx.inputs[0].signature_script = sig_script;
        tx
    }

    /// Build a FUNDED, ML-DSA-87-signed NATIVE spend of a P2PKH UTXO (e.g. a bond's locked
    /// output-0) back to the same key. Exercises the ADR-0016 §D.2 bond-UTXO spend-gate: consensus
    /// must reject a block that spends a still-locked (non-releasable) bond output. The spent output
    /// is a regular (non-coinbase) tx output; the sighash commits its value + spk (both supplied),
    /// so the signature verifies through the full script engine.
    pub(super) fn funded_signed_p2pkh_spend(
        seed: [u8; 32],
        outpoint: TransactionOutpoint,
        value: u64,
        daa_score: u64,
        storage_mass_parameter: u64,
    ) -> Transaction {
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let reward_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&reward_payload);
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(outpoint, vec![], 0, 1)],
            vec![TransactionOutput::new(value - 100_000, spk.clone())],
            0,
            SUBNETWORK_ID_NATIVE,
            0,
            vec![],
        );
        let utxo = UtxoEntry::new(value, spk, daa_score, false);
        let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the bond-output spend")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0xacu8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        let sig_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("ML-DSA-87 signature push fits MAX_SCRIPT_ELEMENT_SIZE")
            .add_data(&pubkey)
            .expect("ML-DSA-87 public-key push fits MAX_SCRIPT_ELEMENT_SIZE")
            .drain();
        tx.inputs[0].signature_script = sig_script;
        tx
    }

    /// ADR-0018 §F bridge wiring: a fully ML-DSA-87-signed BRIDGE tx — spends `seed`'s
    /// P2PKH `outpoint` into a single `EVM_DEPOSIT_LOCK` output (`value − 100_000`; fee
    /// 100_000), whose refund path is the same key's P2PKH. Mirrors
    /// [`funded_signed_p2pkh_spend`]; the lock output makes the tx **finality-class**
    /// past `finality_fee_activation_daa_score`.
    pub(super) fn funded_signed_deposit_lock_tx(
        seed: [u8; 32],
        outpoint: TransactionOutpoint,
        value: u64,
        daa_score: u64,
        storage_mass_parameter: u64,
    ) -> Transaction {
        use kaspa_txscript::script_class::evm_deposit_lock_script;
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let reward_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&reward_payload);
        // The deposit lock: 20-byte EVM address, far-future timeout (refund path never taken
        // here), small claim tip; refund = the spender's own ML-DSA P2PKH.
        let lock_spk = evm_deposit_lock_script([0xABu8; 20], 100_000_000, 7, spk.script());
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(outpoint, vec![], 0, 1)],
            vec![TransactionOutput::new(value - 100_000, lock_spk)],
            0,
            SUBNETWORK_ID_NATIVE,
            0,
            vec![],
        );
        let utxo = UtxoEntry::new(value, spk, daa_score, false);
        let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the deposit-lock spend")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0xadu8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        let sig_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("ML-DSA-87 signature push fits MAX_SCRIPT_ELEMENT_SIZE")
            .add_data(&pubkey)
            .expect("ML-DSA-87 public-key push fits MAX_SCRIPT_ELEMENT_SIZE")
            .drain();
        tx.inputs[0].signature_script = sig_script;
        tx
    }

    /// Build a fully ML-DSA-87-signed attestation for `bond_outpoint`, signing
    /// exactly the digest the §B.4 verifier reconstructs.
    pub(super) fn build_signed_attestation(
        v: &HarnessValidator,
        network_id: &[u8],
        bond_outpoint: TransactionOutpoint,
        epoch: u64,
        target_hash: Hash64,
        target_daa_score: u64,
        validator_set_commitment: Hash64,
    ) -> StakeAttestation {
        let msg = stake_attestation_message(network_id, epoch, target_hash, target_daa_score, validator_set_commitment, bond_outpoint);
        let mb = msg.as_bytes();
        let kp = mldsa::generate_key_pair(v.seed);
        let sig = mldsa::sign(&kp.signing_key, &mb[..], ATTESTATION_MLDSA87_CONTEXT, [0x55u8; 32]).expect("ml-dsa-87 sign");
        StakeAttestation {
            version: DNS_PAYLOAD_VERSION_V1,
            validator_id: v.validator_id,
            bond_outpoint,
            epoch,
            target_hash,
            target_daa_score,
            validator_set_commitment,
            signature: sig.as_ref().to_vec(),
        }
    }

    /// ADR-0128: a fully ML-DSA-87-signed round-two precommit for `bond_outpoint`, signing exactly
    /// the digest the processor's walk reconstructs (`stake_precommit_message` under
    /// `PRECOMMIT_MLDSA87_CONTEXT`), with the lock and the snapshot commitment inside it.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn build_signed_precommit(
        v: &HarnessValidator,
        network_id: &[u8],
        bond_outpoint: TransactionOutpoint,
        epoch: u64,
        target_hash: Hash64,
        target_daa_score: u64,
        lock: kaspa_consensus_core::dns_finality::PrecommitLock,
        snapshot_commitment: Hash64,
    ) -> kaspa_consensus_core::dns_finality::StakePrecommitPayload {
        use kaspa_consensus_core::dns_finality::{PRECOMMIT_MLDSA87_CONTEXT, StakePrecommitPayload, stake_precommit_message};
        let msg = stake_precommit_message(
            network_id,
            epoch,
            target_hash,
            target_daa_score,
            lock.epoch,
            lock.anchor,
            snapshot_commitment,
            bond_outpoint,
        );
        let mb = msg.as_bytes();
        let kp = mldsa::generate_key_pair(v.seed);
        let sig = mldsa::sign(&kp.signing_key, &mb[..], PRECOMMIT_MLDSA87_CONTEXT, [0x56u8; 32]).expect("ml-dsa-87 sign");
        StakePrecommitPayload {
            version: DNS_PAYLOAD_VERSION_V1,
            validator_id: v.validator_id,
            bond_outpoint,
            epoch,
            target_hash,
            target_daa_score,
            locked_epoch: lock.epoch,
            locked_hash: lock.anchor,
            snapshot_commitment,
            signature: sig.as_ref().to_vec(),
        }
    }

    /// ADR-0128: a FUNDED, ML-DSA-87-signed precommit tx — the shard tx's shape on
    /// `SUBNETWORK_ID_STAKE_PRECOMMIT`: input-0 spends a matured coinbase paid to this key, one
    /// P2PKH change output, the precommit borsh-encoded in the payload, the storage mass committed.
    pub(super) fn funded_signed_precommit_tx(
        seed: [u8; 32],
        coinbase_outpoint: TransactionOutpoint,
        coinbase_value: u64,
        coinbase_daa_score: u64,
        precommit: &kaspa_consensus_core::dns_finality::StakePrecommitPayload,
        storage_mass_parameter: u64,
    ) -> Transaction {
        let kp = mldsa::generate_key_pair(seed);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let reward_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&reward_payload);
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(coinbase_outpoint, vec![], 0, 1)],
            vec![TransactionOutput::new(coinbase_value - 100_000, spk.clone())],
            0,
            kaspa_consensus_core::subnets::SUBNETWORK_ID_STAKE_PRECOMMIT,
            0,
            borsh::to_vec(precommit).unwrap(),
        );
        let utxo = UtxoEntry::new(coinbase_value, spk, coinbase_daa_score, true);
        let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the funded precommit tx")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0x89u8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        let sig_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("ML-DSA-87 signature push fits MAX_SCRIPT_ELEMENT_SIZE")
            .add_data(&pubkey)
            .expect("ML-DSA-87 public-key push fits MAX_SCRIPT_ELEMENT_SIZE")
            .drain();
        tx.inputs[0].signature_script = sig_script;
        tx
    }

    /// DAG-harness foundation (ADR-0018 §G): a consensus test can build overlay
    /// txs and produce an attestation signature the §B.4 verifier accepts.
    #[test]
    fn dns_harness_signs_attestations_the_verifier_accepts() {
        let v = harness_validator([0x11u8; 32]);
        assert_eq!(v.pubkey.len(), 2592);
        assert_eq!(v.validator_id, validator_id_from_pubkey(&v.pubkey));

        // Stake-bond tx shape + payload round-trip; validator_pubkey_hash binds the pubkey.
        let bond_tx = build_stake_bond_tx(&v, 10_000_000_000, 0, [0x33u8; 64]);
        assert_eq!(bond_tx.subnetwork_id, SUBNETWORK_ID_STAKE_BOND);
        let bond_outpoint = TransactionOutpoint::new(bond_tx.id(), 0);
        let decoded: StakeBondPayload = borsh::from_slice(&bond_tx.payload).unwrap();
        assert_eq!(decoded.amount, 10_000_000_000);
        assert_eq!(decoded.validator_pubkey_hash, validator_id_from_pubkey(&decoded.validator_pubkey));

        // Signed attestation: the §B.4 verifier (txscript) must accept it.
        let net_id = [0xabu8; 32];
        let target_hash = Hash64::from_bytes([0x44u8; 64]);
        let vsc = Hash64::from_bytes([0x22u8; 64]);
        let att = build_signed_attestation(&v, &net_id, bond_outpoint, 7, target_hash, 700, vsc);
        let msg = stake_attestation_message(
            &net_id,
            att.epoch,
            att.target_hash,
            att.target_daa_score,
            att.validator_set_commitment,
            att.bond_outpoint,
        );
        let mb = msg.as_bytes();
        assert!(
            kaspa_txscript::verify_mldsa87_with_context(&v.pubkey, &mb[..], &att.signature, ATTESTATION_MLDSA87_CONTEXT).unwrap(),
            "the §B.4 verifier must accept the harness-signed attestation"
        );
        // A different key must NOT verify (sanity).
        let v2 = harness_validator([0x99u8; 32]);
        assert!(
            !kaspa_txscript::verify_mldsa87_with_context(&v2.pubkey, &mb[..], &att.signature, ATTESTATION_MLDSA87_CONTEXT).unwrap()
        );

        // Shard tx wraps exactly one extractable attestation.
        let shard_tx = stake_attestation_shard_tx(&single_attestation_shard(att));
        assert_eq!(shard_tx.subnetwork_id, SUBNETWORK_ID_STAKE_ATTESTATION_SHARD);
        assert_eq!(attestations_from_accepted_txs(std::slice::from_ref(&shard_tx)).len(), 1);
    }
}

#[tokio::test]
async fn basic_utxo_disqualified_test() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
        })
        .build();

    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Mine a valid chain
    for _ in 0..10 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // Get current sink
    let sink = ctx.consensus.get_sink();

    // Mine a longer disqualified chain
    let disqualified_tip = ctx.build_and_insert_disqualified_chain(vec![config.genesis.hash], 20).await;

    assert_ne!(sink, disqualified_tip);
    assert_eq!(sink, ctx.consensus.get_sink());
    assert_eq!(BlockHashSet::from_iter([sink, disqualified_tip]), BlockHashSet::from_iter(ctx.consensus.get_tips().into_iter()));
    assert!(!ctx.consensus.get_virtual_parents().contains(&disqualified_tip));
}

#[tokio::test]
async fn double_search_disqualified_test() {
    // TODO: add non-coinbase transactions and concurrency in order to complicate the test

    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.min_difficulty_window_size = p.difficulty_window_size;
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // Mine 3 valid blocks over genesis
    ctx.build_block_template_row(0..3)
        .validate_and_insert_row()
        .await
        .assert_tips()
        .assert_virtual_parents_subset()
        .assert_valid_utxo_tip();

    // Mark the one expected to remain on virtual chain
    let original_sink = ctx.consensus.get_sink();

    // Find the roots to be used for the disqualified chains
    let mut virtual_parents = ctx.consensus.get_virtual_parents();
    assert!(virtual_parents.remove(&original_sink));
    let mut iter = virtual_parents.into_iter();
    let root_1 = iter.next().unwrap();
    let root_2 = iter.next().unwrap();
    assert_eq!(iter.next(), None);

    // Mine a valid chain
    for _ in 0..10 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // Get current sink
    let sink = ctx.consensus.get_sink();

    assert!(ctx.consensus.reachability_service().is_chain_ancestor_of(original_sink, sink));

    // Mine a long disqualified chain
    let disqualified_tip_1 = ctx.build_and_insert_disqualified_chain(vec![root_1], 30).await;

    // And another shorter disqualified chain
    let disqualified_tip_2 = ctx.build_and_insert_disqualified_chain(vec![root_2], 20).await;

    assert_eq!(ctx.consensus.get_block_status(root_1), Some(BlockStatus::StatusUTXOValid));
    assert_eq!(ctx.consensus.get_block_status(root_2), Some(BlockStatus::StatusUTXOValid));

    assert_ne!(sink, disqualified_tip_1);
    assert_ne!(sink, disqualified_tip_2);
    assert_eq!(sink, ctx.consensus.get_sink());
    assert_eq!(
        BlockHashSet::from_iter([sink, disqualified_tip_1, disqualified_tip_2]),
        BlockHashSet::from_iter(ctx.consensus.get_tips().into_iter())
    );
    assert!(!ctx.consensus.get_virtual_parents().contains(&disqualified_tip_1));
    assert!(!ctx.consensus.get_virtual_parents().contains(&disqualified_tip_2));

    // Mine a long enough valid chain s.t. both disqualified chains are fully merged
    for _ in 0..30 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    ctx.assert_tips_num(1);
}

fn new_miner_data() -> MinerData {
    // kaspa-pq PQ-only: coinbase outputs must be the standard ML-DSA-87 P2PKH class
    // (enforced with no exemption — see `check_transaction_pq_output_classes`). Use a
    // random 64-byte hash payload: the script is class-valid but unspendable (no
    // preimage), which is all this helper needs, and stays distinct per call.
    let mut payload = [0u8; 64];
    for b in payload.iter_mut() {
        *b = rand::random();
    }
    MinerData::new(p2pkh_mldsa87_spk(&payload), vec![])
}

#[cfg(feature = "evm")]
fn set_fresh_dns_finality(consensus: &TestConsensus) {
    use crate::model::stores::dns_state::DnsStateStore;
    use kaspa_consensus_core::BlueWorkType;
    use kaspa_consensus_core::dns_finality::{DnsHealth, DnsRolloutStage, DnsState, STAKE_SCORE_SCALE, StakeScore};

    // The anchor must be a block with a header: since 2026-09-10 the bridge's freshness is measured
    // in blue score from the anchor's header (`dns_finality_fresh_for_bridge`), and an anchor the
    // headers store cannot resolve reads as stale. Genesis sits 0 blue below a genesis sink.
    let anchor = consensus.params().genesis.hash;
    consensus
        .virtual_processor()
        .dns_state_store
        .write()
        .set(DnsState {
            selected_chain_anchor: anchor,
            anchor_daa_score: 0,
            work_depth: BlueWorkType::from_u64(2_000_000),
            stake_depth: StakeScore(20 * STAKE_SCORE_SCALE),
            last_dns_confirmed_anchor: anchor,
            last_dns_confirmed_anchor_daa_score: 0,
            rollout_stage: DnsRolloutStage::Active,
            validator_set_commitment: BlockHash::from(88u64),
            health: DnsHealth::Active,
        })
        .unwrap();
}

/// kaspa-pq EVM Lane v0.4 (ADR-0020) — first EVM-ACTIVE pipeline integration
/// test: with `evm_activation_daa_score = 0`, real blocks inserted through the
/// full pipeline (header → body → virtual) drive the lazy chain-context step:
/// each chain block's mergeset acceptance executes ONCE, its result + state
/// snapshot persist atomically with its UTXO diff, the canonical EVM heads
/// move with the sink, a commitment fault disqualifies the block from the
/// chain (the block stays in the DAG — no poison), and the chain recovers
/// past the disqualified block without re-executing prior EVM results.
#[tokio::test]
#[cfg(feature = "evm")]
async fn evm_active_chain_executes_persists_and_moves_heads() {
    use crate::model::stores::evm::{EvmCanonicalHeadsStoreReader, EvmHeaderStoreReader, EvmPayloadStoreReader, EvmRawTxStoreReader};
    use kaspa_consensus_core::constants::EVM_HEADER_VERSION;
    use kaspa_consensus_core::evm::{EvmAddress, EvmExecutionPayload, EvmStateSnapshot};
    use kaspa_evm::EvmBlockInput;
    use kaspa_hashes::Hash64;

    kaspa_core::log::try_init_logger("info");
    let config =
        ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().edit_consensus_params(|p| p.evm_activation_daa_score = 0).build();
    let consensus = TestConsensus::new(&config);
    let wait_handles = consensus.init();
    let storage = consensus.consensus_clone().storage.clone();
    set_fresh_dns_finality(&consensus);

    let genesis = consensus.params().genesis.hash;
    let miner_data = MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]);

    // ---- b1: empty payload. The §4.3 version rule demands v2 post-activation;
    // the producer (this test) computes the mergeset-acceptance commitment the
    // same way the verifier will (mergeset = [genesis], no payloads ⇒ no
    // accepted txs; EVM parent = none ⇒ genesis state).
    let payload1 = EvmExecutionPayload::default();
    let mut b1 = consensus.build_utxo_valid_block_with_parents(1.into(), vec![genesis], miner_data.clone(), vec![]);
    b1.header.version = EVM_HEADER_VERSION;
    b1.header.evm_payload_hash = payload1.payload_hash();
    let input1 = EvmBlockInput {
        market: Default::default(),
        parent: None,
        header_timestamp_ms: b1.header.timestamp,
        selected_parent_hash: genesis.as_bytes(),
        blue_work_be: b1.header.blue_work.to_be_bytes().to_vec(),
        daa_score: b1.header.daa_score,
        payload: &payload1,
        accepted_txs: &[],
        gas_pool_v2_activation_daa_score: u64::MAX,
        f002_withdraw_cap_activation_daa_score: u64::MAX,
        bridge_ledger_activation_daa_score: u64::MAX,
        f003_mldsa_verify_activation_daa_score: u64::MAX,
        typed_receipt_root_activation_daa_score: u64::MAX,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let (exp1, snap1) = kaspa_evm::snapshot::execute_block_from_snapshot(&EvmStateSnapshot::default(), &input1).unwrap();
    b1.header.evm_commitment_root = exp1.header.commitment_root();
    b1.evm_payload = payload1;
    consensus.validate_and_insert_block(b1.to_immutable()).virtual_state_task.await.unwrap();

    assert_eq!(storage.evm_header_store.get(1.into()).unwrap(), exp1.header, "b1's EVM result persisted by the pipeline");
    assert_eq!(exp1.header.evm_number, 1);
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(1u64), "heads moved to the sink");

    // ---- b2: carries its OWN non-empty payload (a declared coinbase + extra
    // data) — proving payload persistence at body commit and EVM state chaining
    // b1 → b2 through the real pipeline. (A real DepositClaim needs a funded
    // EVM_DEPOSIT_LOCK UTXO — P4 claim validation rejects a dangling one; the
    // claim/bridge paths are unit-tested in processes::evm.)
    let payload2 = EvmExecutionPayload {
        evm_coinbase: EvmAddress::from_bytes([0xFE; 20]),
        extra_data: vec![0x4D, 0x53, 0x4B],
        ..Default::default()
    };
    let mut b2 = consensus.build_utxo_valid_block_with_parents(2.into(), vec![1.into()], miner_data.clone(), vec![]);
    b2.header.version = EVM_HEADER_VERSION;
    b2.header.evm_payload_hash = payload2.payload_hash();
    let input2 = EvmBlockInput {
        market: Default::default(),
        parent: Some(&exp1.header),
        header_timestamp_ms: b2.header.timestamp,
        selected_parent_hash: BlockHash::from(1u64).as_bytes(),
        blue_work_be: b2.header.blue_work.to_be_bytes().to_vec(),
        daa_score: b2.header.daa_score,
        payload: &payload2,
        accepted_txs: &[], // b1's payload was empty ⇒ nothing to accept
        gas_pool_v2_activation_daa_score: u64::MAX,
        f002_withdraw_cap_activation_daa_score: u64::MAX,
        bridge_ledger_activation_daa_score: u64::MAX,
        f003_mldsa_verify_activation_daa_score: u64::MAX,
        typed_receipt_root_activation_daa_score: u64::MAX,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let (exp2, _snap2) = kaspa_evm::snapshot::execute_block_from_snapshot(&snap1, &input2).unwrap();
    b2.header.evm_commitment_root = exp2.header.commitment_root();
    b2.evm_payload = payload2.clone();
    consensus.validate_and_insert_block(b2.to_immutable()).virtual_state_task.await.unwrap();

    let stored2 = storage.evm_header_store.get(2.into()).unwrap();
    assert_eq!(stored2, exp2.header);
    assert_eq!(stored2.evm_number, 2);
    assert_eq!(stored2.parent_state_root, exp1.header.state_root, "EVM state chains selected-parent-wise");
    assert_eq!(storage.evm_payload_store.get(2.into()).unwrap(), payload2, "own payload persisted at body commit");
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(2u64));

    // ADR-0109 Decision 4 (I-4): `safe` is the DNS-confirmed anchor when it is a chain ancestor of the
    // sink that carries an EVM result — b1 here — and the sink when the anchor carries none.
    {
        use crate::model::stores::dns_state::{DnsStateStore, DnsStateStoreReader};
        let vp = consensus.virtual_processor().clone();
        let point_anchor_at = |anchor: BlockHash| {
            let mut state = vp.dns_state_store.read().get().unwrap();
            state.last_dns_confirmed_anchor = anchor;
            vp.dns_state_store.write().set(state).unwrap();
            let mut batch = rocksdb::WriteBatch::default();
            vp.update_evm_canonical_heads(&mut batch, 2.into());
            vp.db.write(batch).unwrap();
            storage.evm_heads_store.read().get().unwrap()
        };
        let heads = point_anchor_at(1.into());
        assert_eq!((heads.latest, heads.safe), (BlockHash::from(2u64), BlockHash::from(1u64)), "safe = the DNS-confirmed anchor b1");
        let heads = point_anchor_at(BlockHash::from(0xDEADu64));
        assert_eq!(heads.safe, BlockHash::from(2u64), "an anchor with no EVM result leaves safe at the sink, as before");
    }

    // ---- b3: a commitment FAULT (producer lied about the acceptance result).
    // The block enters the DAG but is disqualified from the chain — exactly the
    // UTXO-fault shape — and no EVM rows are written for it.
    let payload3 = EvmExecutionPayload::default();
    let mut b3 = consensus.build_utxo_valid_block_with_parents(3.into(), vec![2.into()], miner_data.clone(), vec![]);
    b3.header.version = EVM_HEADER_VERSION;
    b3.header.evm_payload_hash = payload3.payload_hash();
    b3.header.evm_commitment_root = Hash64::from_bytes([0xEE; 64]);
    b3.evm_payload = payload3.clone();
    let _ = consensus.validate_and_insert_block(b3.to_immutable()).virtual_state_task.await;
    assert_eq!(consensus.block_status(3.into()), BlockStatus::StatusDisqualifiedFromChain, "commitment mismatch ⇒ chain-disqualified");
    assert!(!storage.evm_header_store.has(3.into()).unwrap(), "no EVM rows for a disqualified block");
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(2u64), "heads did NOT follow the faulty block");

    // ---- b4: a valid sibling continuation on b2 — the chain recovers past the
    // disqualified b3 (b3 ∉ past(b4), so b3's payload is NOT accepted by b4)
    // and the heads advance. b1/b2 results are reused (their diffs exist ⇒ the
    // KeyNotFound execution arm is never re-entered: no re-execution on reorg).
    let payload4 = EvmExecutionPayload::default();
    let mut b4 = consensus.build_utxo_valid_block_with_parents(4.into(), vec![2.into()], miner_data, vec![]);
    b4.header.version = EVM_HEADER_VERSION;
    b4.header.evm_payload_hash = payload4.payload_hash();
    let input4 = EvmBlockInput {
        market: Default::default(),
        parent: Some(&exp2.header),
        header_timestamp_ms: b4.header.timestamp,
        selected_parent_hash: BlockHash::from(2u64).as_bytes(),
        blue_work_be: b4.header.blue_work.to_be_bytes().to_vec(),
        daa_score: b4.header.daa_score,
        payload: &payload4,
        accepted_txs: &[], // b2's payload txs are empty (system ops are not delayed-accepted)
        gas_pool_v2_activation_daa_score: u64::MAX,
        f002_withdraw_cap_activation_daa_score: u64::MAX,
        bridge_ledger_activation_daa_score: u64::MAX,
        f003_mldsa_verify_activation_daa_score: u64::MAX,
        typed_receipt_root_activation_daa_score: u64::MAX,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let snap2 = {
        // Recompute b2's child snapshot the same way the node stored it.
        let (_, s) = kaspa_evm::snapshot::execute_block_from_snapshot(&snap1, &input2).unwrap();
        s
    };
    let (exp4, _) = kaspa_evm::snapshot::execute_block_from_snapshot(&snap2, &input4).unwrap();
    b4.header.evm_commitment_root = exp4.header.commitment_root();
    b4.evm_payload = payload4;
    consensus.validate_and_insert_block(b4.to_immutable()).virtual_state_task.await.unwrap();

    assert_eq!(storage.evm_header_store.get(4.into()).unwrap().evm_number, 3, "b4 is EVM block 3 on the selected chain");
    assert_eq!(
        storage.evm_heads_store.read().get().unwrap().latest,
        BlockHash::from(4u64),
        "heads recovered past the disqualified block"
    );

    // ---- b5: the node's OWN template (§15 producer path) — the builder must
    // declare v2, commit the (empty) payload hash and the REAL acceptance
    // commitment, and the resulting block must validate through the full
    // pipeline. (Template used as-is: on an evm-active net a miner must not
    // mutate the template timestamp — the commitment derives from it.)
    let template = consensus
        .build_block_template(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
        )
        .unwrap();
    assert_eq!(template.block.header.version, EVM_HEADER_VERSION, "evm-active template declares v2");
    assert_eq!(template.block.header.evm_payload_hash, EvmExecutionPayload::default().payload_hash());
    assert_ne!(template.block.header.evm_commitment_root, Hash64::default(), "the template committed a real acceptance result");
    let mut b5 = template.block;
    b5.header.hash = 5u64.into(); // test identity (PoW skipped)
    consensus.validate_and_insert_block(b5.to_immutable()).virtual_state_task.await.unwrap();
    assert!(storage.evm_header_store.has(5.into()).unwrap(), "the self-mined block executed + persisted");
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(5u64));

    // ---- b6 (§16-1): a template with an EVM-mempool candidate — the §15
    // step-6 own-payload path. The fixture is a signed EIP-1559 transfer on
    // EVM_CHAIN_ID (regenerate: `cargo test -p kaspa-evm fixture_generator --
    // --ignored --nocapture`); its sender is UNFUNDED, which is irrelevant for
    // inclusion (data-only) and makes acceptance a deterministic class-2 skip.
    const FIXTURE_TX_NONCE0: &str = "02f86b834d534b8080843b9aca008252089400000000000000000000000000000000000000228201f480c001a03244f5d74a96a52bd1c42fa1b9c336f4d3ae5509190ed9a526f17971c7fd743ca07f58e09399b50636b84f0ae4a7634c60a11c6f32427b613ebf6f4a638d6c68c1";
    let mut raw_n0 = vec![0u8; FIXTURE_TX_NONCE0.len() / 2];
    faster_hex::hex_decode(FIXTURE_TX_NONCE0.as_bytes(), &mut raw_n0).unwrap();

    let template = consensus
        .build_block_template_with_evm(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
            kaspa_consensus_core::evm::EvmTemplateData {
                evm_coinbase: kaspa_consensus_core::evm::EvmAddress::from_bytes([0xCB; 20]),
                transactions: vec![raw_n0.clone()],
                system_ops: vec![],
            },
        )
        .unwrap();
    assert_eq!(template.block.evm_payload.transactions, vec![raw_n0.clone()], "the candidate landed in the own payload");
    assert_eq!(
        template.block.evm_payload.evm_coinbase,
        kaspa_consensus_core::evm::EvmAddress::from_bytes([0xCB; 20]),
        "the declared fee recipient landed as the payload coinbase (§8.2)"
    );
    assert_eq!(
        template.block.header.evm_payload_hash,
        template.block.evm_payload.payload_hash(),
        "the header commits the NON-empty payload"
    );
    let mut b6 = template.block;
    b6.header.hash = 6u64.into();
    consensus.validate_and_insert_block(b6.to_immutable()).virtual_state_task.await.unwrap();
    assert!(storage.evm_payload_store.has(6.into()).unwrap(), "the non-empty own payload persisted at commit_body");

    // ---- b7: the NEXT template accepts b6's payload (mergeset delayed
    // acceptance): the unfunded sender makes the tx a deterministic class-2
    // skip — counted, no receipt, block valid. This closes the full §16-1
    // loop: pool candidate → template inclusion → wire/body validation →
    // acceptance processing by the selected child.
    let template = consensus
        .build_block_template(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
        )
        .unwrap();
    let mut b7 = template.block;
    b7.header.hash = 7u64.into();
    consensus.validate_and_insert_block(b7.to_immutable()).virtual_state_task.await.unwrap();
    let h7 = storage.evm_header_store.get(7.into()).unwrap();
    assert_eq!(h7.skipped_tx_count, 1, "b6's unfunded payload tx was class-2 skipped at acceptance");
    assert_eq!(h7.accepted_tx_count, 0);
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(7u64));

    // §16-3: the tx-lookup index recorded the journey — included in b6 (DA
    // visibility), never accepted, last skip = class 2 (unfunded sender). The
    // exact data misaka_getTxInclusionStatus serves.
    let fixture_hash = kaspa_evm::tx::tx_hash(&{
        let mut raw = vec![0u8; FIXTURE_TX_NONCE0.len() / 2];
        faster_hex::hex_decode(FIXTURE_TX_NONCE0.as_bytes(), &mut raw).unwrap();
        raw
    });
    let row = storage.evm_tx_index_store.get_or_default(fixture_hash).unwrap();
    assert_eq!(row.included_in, vec![BlockHash::from(6u64)], "DA visibility: the payload block carrying the tx");
    assert!(row.accepted_in.is_empty(), "never executed (unfunded)");
    assert_eq!(row.last_skip_class, Some(2));

    // audit R-2: the raw tx is resolvable DIRECTLY by hash (no included_in scan),
    // recorded at body commit of its carrying payload block (b6) — the path the
    // eth_getTransactionByHash/receipt adapter now uses.
    let stored = storage.evm_raw_tx_store.get(fixture_hash).unwrap().expect("raw tx indexed by hash");
    assert_eq!(stored.raw, raw_n0, "raw EIP-2718 bytes round-trip by hash");
    assert_eq!(stored.payload_block, BlockHash::from(6u64), "carrying payload block recorded");
    assert_eq!(
        consensus.consensus_clone().get_evm_raw_tx(fixture_hash).unwrap(),
        Some(raw_n0.clone()),
        "get_evm_raw_tx resolves the tx without the bounded included_in scan"
    );

    consensus.shutdown(wait_handles);
}

/// kaspa-pq EVM Lane v0.4 (§16 RPC / canonical-index fix, R-1): the
/// `evm_number → L1 hash` map is driven by the SELECTED chain at virtual commit,
/// NOT per-block result-commit. A reorg must detach the old canonical block's
/// number and attach the new chain's block at that number; the detached block
/// stays queryable by L1 hash (immutable rows are kept). This exercises
/// `update_evm_canonical_number_map` end-to-end. The conditional-release branch
/// is unit-tested in `model::stores::evm` (`evm_number_store_canonical_*`). The
/// precise sink-search-loser shadow that motivated the fix needs the DNS
/// reorg-gate (overlay-Active); the structural fix prevents it by construction —
/// a non-selected block never writes the map.
#[tokio::test]
#[cfg(feature = "evm")]
async fn evm_active_canonical_number_map_follows_reorg() {
    use crate::model::stores::evm::{EvmCanonicalHeadsStoreReader, EvmHeaderStoreReader, EvmNumberStoreReader};
    use kaspa_consensus_core::constants::EVM_HEADER_VERSION;
    use kaspa_consensus_core::evm::{EvmExecutionPayload, EvmStateSnapshot};
    use kaspa_evm::EvmBlockInput;

    kaspa_core::log::try_init_logger("info");
    let config =
        ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().edit_consensus_params(|p| p.evm_activation_daa_score = 0).build();
    let consensus = TestConsensus::new(&config);
    let wait_handles = consensus.init();
    let storage = consensus.consensus_clone().storage.clone();

    let genesis = consensus.params().genesis.hash;
    let miner_data = MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]);
    let inert = u64::MAX;

    // ---- b1 (#1): empty payload on genesis (mirrors the EVM-active test).
    let payload1 = EvmExecutionPayload::default();
    let mut b1 = consensus.build_utxo_valid_block_with_parents(1.into(), vec![genesis], miner_data.clone(), vec![]);
    b1.header.version = EVM_HEADER_VERSION;
    b1.header.evm_payload_hash = payload1.payload_hash();
    let input1 = EvmBlockInput {
        market: Default::default(),
        parent: None,
        header_timestamp_ms: b1.header.timestamp,
        selected_parent_hash: genesis.as_bytes(),
        blue_work_be: b1.header.blue_work.to_be_bytes().to_vec(),
        daa_score: b1.header.daa_score,
        payload: &payload1,
        accepted_txs: &[],
        gas_pool_v2_activation_daa_score: inert,
        f002_withdraw_cap_activation_daa_score: inert,
        bridge_ledger_activation_daa_score: inert,
        f003_mldsa_verify_activation_daa_score: inert,
        typed_receipt_root_activation_daa_score: inert,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let (exp1, snap1) = kaspa_evm::snapshot::execute_block_from_snapshot(&EvmStateSnapshot::default(), &input1).unwrap();
    b1.header.evm_commitment_root = exp1.header.commitment_root();
    b1.evm_payload = payload1;
    consensus.validate_and_insert_block(b1.to_immutable()).virtual_state_task.await.unwrap();

    // ---- b2 (#2): on b1.
    let payload2 = EvmExecutionPayload::default();
    let mut b2 = consensus.build_utxo_valid_block_with_parents(2.into(), vec![1.into()], miner_data.clone(), vec![]);
    b2.header.version = EVM_HEADER_VERSION;
    b2.header.evm_payload_hash = payload2.payload_hash();
    let input2 = EvmBlockInput {
        market: Default::default(),
        parent: Some(&exp1.header),
        header_timestamp_ms: b2.header.timestamp,
        selected_parent_hash: BlockHash::from(1u64).as_bytes(),
        blue_work_be: b2.header.blue_work.to_be_bytes().to_vec(),
        daa_score: b2.header.daa_score,
        payload: &payload2,
        accepted_txs: &[],
        gas_pool_v2_activation_daa_score: inert,
        f002_withdraw_cap_activation_daa_score: inert,
        bridge_ledger_activation_daa_score: inert,
        f003_mldsa_verify_activation_daa_score: inert,
        typed_receipt_root_activation_daa_score: inert,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let (exp2, snap2) = kaspa_evm::snapshot::execute_block_from_snapshot(&snap1, &input2).unwrap();
    b2.header.evm_commitment_root = exp2.header.commitment_root();
    b2.evm_payload = payload2;
    consensus.validate_and_insert_block(b2.to_immutable()).virtual_state_task.await.unwrap();
    assert_eq!(storage.evm_number_store.get(2).unwrap(), Some(BlockHash::from(2u64)), "b2 claims #2");

    // ---- x3 (#3) on b2 — the initial sink. Hash 9 wins the equal-blue-work
    // tiebreak vs y3 (hash 5), so x3 stays canonical at #3 until y4 reorgs.
    let payloadx = EvmExecutionPayload::default();
    let mut x3 = consensus.build_utxo_valid_block_with_parents(9.into(), vec![2.into()], miner_data.clone(), vec![]);
    x3.header.version = EVM_HEADER_VERSION;
    x3.header.evm_payload_hash = payloadx.payload_hash();
    let inputx = EvmBlockInput {
        market: Default::default(),
        parent: Some(&exp2.header),
        header_timestamp_ms: x3.header.timestamp,
        selected_parent_hash: BlockHash::from(2u64).as_bytes(),
        blue_work_be: x3.header.blue_work.to_be_bytes().to_vec(),
        daa_score: x3.header.daa_score,
        payload: &payloadx,
        accepted_txs: &[],
        gas_pool_v2_activation_daa_score: inert,
        f002_withdraw_cap_activation_daa_score: inert,
        bridge_ledger_activation_daa_score: inert,
        f003_mldsa_verify_activation_daa_score: inert,
        typed_receipt_root_activation_daa_score: inert,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let (expx, _snapx) = kaspa_evm::snapshot::execute_block_from_snapshot(&snap2, &inputx).unwrap();
    assert_eq!(expx.header.evm_number, 3);
    x3.header.evm_commitment_root = expx.header.commitment_root();
    x3.evm_payload = payloadx;
    consensus.validate_and_insert_block(x3.to_immutable()).virtual_state_task.await.unwrap();
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(9u64), "x3 is the sink");
    assert_eq!(storage.evm_number_store.get(3).unwrap(), Some(BlockHash::from(9u64)), "x3 canonical at #3 before the reorg");

    // ---- y3 (#3) on b2 — a sibling of x3. Equal blue work, lower hash (5 < 9)
    // ⇒ x3 keeps the sink; y3 is inserted but not yet selected/validated.
    let payloady3 = EvmExecutionPayload::default();
    let mut y3 = consensus.build_utxo_valid_block_with_parents(5.into(), vec![2.into()], miner_data.clone(), vec![]);
    y3.header.version = EVM_HEADER_VERSION;
    y3.header.evm_payload_hash = payloady3.payload_hash();
    let inputy3 = EvmBlockInput {
        market: Default::default(),
        parent: Some(&exp2.header),
        header_timestamp_ms: y3.header.timestamp,
        selected_parent_hash: BlockHash::from(2u64).as_bytes(),
        blue_work_be: y3.header.blue_work.to_be_bytes().to_vec(),
        daa_score: y3.header.daa_score,
        payload: &payloady3,
        accepted_txs: &[],
        gas_pool_v2_activation_daa_score: inert,
        f002_withdraw_cap_activation_daa_score: inert,
        bridge_ledger_activation_daa_score: inert,
        f003_mldsa_verify_activation_daa_score: inert,
        typed_receipt_root_activation_daa_score: inert,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let (expy3, snapy3) = kaspa_evm::snapshot::execute_block_from_snapshot(&snap2, &inputy3).unwrap();
    y3.header.evm_commitment_root = expy3.header.commitment_root();
    y3.evm_payload = payloady3;
    consensus.validate_and_insert_block(y3.to_immutable()).virtual_state_task.await.unwrap();
    assert_eq!(storage.evm_number_store.get(3).unwrap(), Some(BlockHash::from(9u64)), "x3 still canonical at #3 (y3 not selected)");

    // ---- y4 (#4) on y3 — the heavier branch (2 blocks past b2) reorgs the sink
    // from x3 to y4. The selected chain is now ...b2, y3(#3), y4(#4).
    let payloady4 = EvmExecutionPayload::default();
    let mut y4 = consensus.build_utxo_valid_block_with_parents(6.into(), vec![5.into()], miner_data, vec![]);
    y4.header.version = EVM_HEADER_VERSION;
    y4.header.evm_payload_hash = payloady4.payload_hash();
    let inputy4 = EvmBlockInput {
        market: Default::default(),
        parent: Some(&expy3.header),
        header_timestamp_ms: y4.header.timestamp,
        selected_parent_hash: BlockHash::from(5u64).as_bytes(),
        blue_work_be: y4.header.blue_work.to_be_bytes().to_vec(),
        daa_score: y4.header.daa_score,
        payload: &payloady4,
        accepted_txs: &[],
        gas_pool_v2_activation_daa_score: inert,
        f002_withdraw_cap_activation_daa_score: inert,
        bridge_ledger_activation_daa_score: inert,
        f003_mldsa_verify_activation_daa_score: inert,
        typed_receipt_root_activation_daa_score: inert,
        user_gas_cap: kaspa_consensus_core::evm::MAX_EVM_ACCEPTED_GAS_PER_CHAIN_BLOCK,
    };
    let (expy4, _snapy4) = kaspa_evm::snapshot::execute_block_from_snapshot(&snapy3, &inputy4).unwrap();
    assert_eq!(expy4.header.evm_number, 4);
    y4.header.evm_commitment_root = expy4.header.commitment_root();
    y4.evm_payload = payloady4;
    consensus.validate_and_insert_block(y4.to_immutable()).virtual_state_task.await.unwrap();

    // The reorg detached x3 and attached y3(#3) + y4(#4):
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(6u64), "sink reorged to y4");
    assert_eq!(
        storage.evm_number_store.get(3).unwrap(),
        Some(BlockHash::from(5u64)),
        "#3 now resolves to y3 (canonical), not the detached x3"
    );
    assert_eq!(storage.evm_number_store.get(4).unwrap(), Some(BlockHash::from(6u64)), "y4 claimed #4");
    assert_eq!(storage.evm_number_store.get(2).unwrap(), Some(BlockHash::from(2u64)), "#2 (below the fork) is unchanged");
    assert_ne!(storage.evm_number_store.get(3).unwrap(), Some(BlockHash::from(9u64)), "the detached x3 no longer owns #3");
    // The detached x3 stays queryable by L1 hash (immutable rows survive).
    assert!(storage.evm_header_store.has(9.into()).unwrap(), "x3's immutable EVM rows survive the reorg (hash-queryable)");

    consensus.shutdown(wait_handles);
}

/// kaspa-pq EVM Lane v0.4 §9.2 — producer-side deposit-claim path: a queued
/// `DepositClaim` (resolved from a real EVM_DEPOSIT_LOCK UTXO, the work the
/// `submitEvmDepositClaim` RPC does) lands in the node's OWN template
/// `system_ops` after the template path re-validates it against the live claim
/// view; a claim for a non-existent/stale lock is dropped — so a queued claim
/// can never make the producer's own block invalid. This closes the production
/// half of the bridge: deposits are now both validatable (P4) AND producible.
#[tokio::test]
#[cfg(feature = "evm")]
async fn evm_producer_deposit_claim_fills_and_filters_template_system_ops() {
    use kaspa_consensus_core::evm::{DepositClaim, EvmAddress, EvmSystemOp, EvmTemplateData};
    use kaspa_consensus_core::header::Header;
    use kaspa_consensus_core::muhash::MuHashExtensions;
    use kaspa_consensus_core::tx::UtxoEntry;
    use kaspa_muhash::MuHash;
    use kaspa_txscript::script_class::evm_deposit_lock_script;

    kaspa_core::log::try_init_logger("info");

    // A real EVM_DEPOSIT_LOCK output: 1000 sompi locked to an EVM address, claim
    // tip 7, timeout far in the future; refund = a standard ML-DSA P2PKH.
    let evm_addr = [0xAB; 20];
    let refund_spk = p2pkh_mldsa87_spk(&[0x42; 64]);
    let lock_spk = evm_deposit_lock_script(evm_addr, 1_000_000, 7, refund_spk.script());
    let lock_outpoint = TransactionOutpoint::new(99u64.into(), 0);
    let initial_utxos =
        [(lock_outpoint, UtxoEntry { amount: 1000, script_public_key: lock_spk, block_daa_score: 0, is_coinbase: false })];

    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| p.evm_activation_daa_score = 0)
        .apply_args(|cfg| {
            // ADR-0109: this test is about the QUEUE path under the pre-ADR gate; the index path and
            // the `Label` default have their own tests below.
            cfg.evm_bridge_finality = kaspa_consensus_core::evm::EvmBridgeFinalityPolicy::Pause;
            let mut ms = MuHash::new();
            initial_utxos.iter().for_each(|(op, u)| ms.add_utxo(op, u));
            cfg.params.genesis.utxo_commitment = ms.finalize();
            let genesis_header: Header = (&cfg.params.genesis).into();
            cfg.params.genesis.hash = genesis_header.hash;
        })
        .build();
    let consensus = TestConsensus::new(&config);
    let wait_handles = consensus.init();
    let mut genesis_ms = MuHash::new();
    consensus.append_imported_pruning_point_utxos(&initial_utxos, &mut genesis_ms);
    consensus.import_pruning_point_utxo_set(config.genesis.hash, genesis_ms).unwrap();

    // (1) the valid claim for the real lock; (2) a claim for a non-existent
    // outpoint that re-validation must drop.
    let good_claim = DepositClaim {
        deposit_outpoint: lock_outpoint,
        evm_address: EvmAddress::from_bytes(evm_addr),
        amount_sompi: 1000,
        claim_tip_sompi: 7,
    };
    let bogus_claim = DepositClaim {
        deposit_outpoint: TransactionOutpoint::new(123u64.into(), 0),
        evm_address: EvmAddress::from_bytes([0xCD; 20]),
        amount_sompi: 500,
        claim_tip_sompi: 0,
    };

    let stale_template = consensus
        .build_block_template_with_evm(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
            EvmTemplateData {
                evm_coinbase: EvmAddress::from_bytes([0xCB; 20]),
                transactions: vec![],
                system_ops: vec![good_claim.clone(), bogus_claim.clone()],
            },
        )
        .unwrap();
    assert!(
        stale_template.block.evm_payload.is_empty(),
        "without a fresh DNS-confirmed anchor, bridge deposit claims stay out of the template"
    );

    set_fresh_dns_finality(&consensus);

    let template = consensus
        .build_block_template_with_evm(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
            EvmTemplateData {
                evm_coinbase: EvmAddress::from_bytes([0xCB; 20]),
                transactions: vec![],
                system_ops: vec![good_claim.clone(), bogus_claim],
            },
        )
        .unwrap();

    assert_eq!(template.block.evm_payload.system_ops.len(), 1, "only the valid claim survives template re-validation");
    assert_eq!(
        template.block.evm_payload.system_ops[0],
        EvmSystemOp::DepositClaim(good_claim),
        "the resolved lock's claim is in the own payload"
    );
    assert_eq!(
        template.block.evm_payload.evm_coinbase,
        EvmAddress::from_bytes([0xCB; 20]),
        "a claim-bearing payload declares the coinbase (the tip routes to it)"
    );
    assert_eq!(template.block.header.evm_payload_hash, template.block.evm_payload.payload_hash(), "header commits the claim payload");

    consensus.shutdown(wait_handles);
}

/// kaspa-pq EVM Lane v0.4 §14.1/§14.3 — Y9 budget independence, pipeline e2e:
/// a template assembled from an OVERSUPPLIED candidate list fills the payload
/// to the byte cap (and no further), the resulting full-cap block keeps its
/// normal UTXO content and passes the complete pipeline (mass rules included),
/// and the next chain block processes the entire payload at acceptance without
/// invalidating or stalling the UTXO lane. Complements the in-isolation mass
/// equality test (`evm_y9_payload_byte_budget_independent_of_utxo_mass_budget`);
/// the λ·D propagation re-validation with measured payload-laden D is Y10 —
/// testnet work and an activation precondition (§14.3), not a unit concern.
#[tokio::test]
#[cfg(feature = "evm")]
async fn evm_y9_full_cap_payload_block_validates_and_executes() {
    use crate::model::stores::evm::{EvmCanonicalHeadsStoreReader, EvmHeaderStoreReader, EvmPayloadStoreReader};
    use kaspa_consensus_core::evm::{EvmAddress, EvmExecutionPayload, EvmTemplateData, MAX_EVM_PAYLOAD_BYTES_PER_DAG_BLOCK};

    kaspa_core::log::try_init_logger("info");
    let config =
        ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().edit_consensus_params(|p| p.evm_activation_daa_score = 0).build();
    let consensus = TestConsensus::new(&config);
    let wait_handles = consensus.init();
    let storage = consensus.consensus_clone().storage.clone();
    set_fresh_dns_finality(&consensus);

    // The class-1-valid §16 fixture, oversupplied: duplication is legal at the
    // body (admission is per-tx) and a deterministic skip at acceptance.
    const FIXTURE_TX_NONCE0: &str = "02f86b834d534b8080843b9aca008252089400000000000000000000000000000000000000228201f480c001a03244f5d74a96a52bd1c42fa1b9c336f4d3ae5509190ed9a526f17971c7fd743ca07f58e09399b50636b84f0ae4a7634c60a11c6f32427b613ebf6f4a638d6c68c1";
    let mut raw = vec![0u8; FIXTURE_TX_NONCE0.len() / 2];
    faster_hex::hex_decode(FIXTURE_TX_NONCE0.as_bytes(), &mut raw).unwrap();
    let base = EvmExecutionPayload::default().payload_bytes().len();
    let per_tx = 4 + raw.len();
    let n = (MAX_EVM_PAYLOAD_BYTES_PER_DAG_BLOCK - base) / per_tx;

    let template = consensus
        .build_block_template_with_evm(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
            EvmTemplateData {
                evm_coinbase: EvmAddress::from_bytes([0xCB; 20]),
                transactions: vec![raw.clone(); n + 32], // 32 candidates beyond the cap
                system_ops: vec![],
            },
        )
        .unwrap();
    assert_eq!(template.block.evm_payload.transactions.len(), n, "template fills to the byte cap and not one tx further");
    let assembled = template.block.evm_payload.payload_bytes().len();
    assert!(assembled <= MAX_EVM_PAYLOAD_BYTES_PER_DAG_BLOCK, "assembled payload within the cap");
    assert!(assembled > MAX_EVM_PAYLOAD_BYTES_PER_DAG_BLOCK - per_tx, "assembled payload NEAR the cap");

    let mut b1 = template.block;
    b1.header.hash = 1u64.into();
    consensus.validate_and_insert_block(b1.to_immutable()).virtual_state_task.await.unwrap();
    assert!(storage.evm_payload_store.has(1.into()).unwrap(), "full-cap payload persisted at commit_body");

    // The next chain block accepts b1's payload: every copy is a deterministic
    // skip (unfunded sender), the block stays valid, the heads advance — a
    // payload-maxed DAG block never blocks the UTXO lane (§14.2).
    let template = consensus
        .build_block_template(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
        )
        .unwrap();
    let mut b2 = template.block;
    b2.header.hash = 2u64.into();
    consensus.validate_and_insert_block(b2.to_immutable()).virtual_state_task.await.unwrap();
    let h2 = storage.evm_header_store.get(2.into()).unwrap();
    assert_eq!(h2.skipped_tx_count, n as u32, "the full-cap payload was processed: every copy skipped, none accepted");
    assert_eq!(h2.accepted_tx_count, 0);
    assert_eq!(storage.evm_heads_store.read().get().unwrap().latest, BlockHash::from(2u64));

    consensus.shutdown(wait_handles);
}

/// The DNS reorg gate's common-ancestor search: the O(log horizon) index binary search must agree
/// with the linear walk **block for block and boundary for boundary**, and the horizon both apply
/// must be the CANONICAL-side rewind depth.
///
/// The metric matters as much as the answer. Bounding the *candidate* side (what the walk did
/// before) measures how far the other branch ran, so an attacker who mines a long secret branch
/// while canonical advances a little would be classified "deeper than the horizon" and the gate
/// would ABSTAIN — handing a deep-reorg attacker the pass the veto exists to deny. Bounding the
/// canonical side asks the question the horizon is named for: how many of MY blocks would this
/// candidate rewind. Here the side branch (8 blocks) is deliberately SHORTER than the canonical
/// rewind it would cause (15), so the two metrics give different verdicts and the test pins the
/// right one.
#[tokio::test]
async fn dns_gate_common_ancestor_search_matches_walk_on_canonical_rewind_depth() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..40 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    }

    const REWIND: usize = 15; // canonical blocks the side branch would rewind
    const SIDE_LEN: usize = 8; // side-branch length — deliberately < REWIND
    let sink = ctx.consensus.get_sink();
    let fork_point = {
        let vp = ctx.consensus.virtual_processor();
        // The iterator yields `sink` itself first, so `nth(REWIND)` is REWIND blocks back.
        vp.reachability_service.default_backward_chain_iterator(sink).nth(REWIND).expect("the chain is longer than REWIND")
    };
    let side_tip = ctx.build_and_insert_disqualified_chain(vec![fork_point], SIDE_LEN).await;

    let vp = ctx.consensus.virtual_processor();
    // At or above the rewind depth both paths find the same fork point.
    for horizon in [REWIND as u64, REWIND as u64 + 1, 40, 10_000] {
        assert_eq!(
            vp.chain_common_ancestor_within(side_tip, sink, horizon),
            Some(fork_point),
            "binary search finds the fork point at horizon {horizon}"
        );
        assert_eq!(vp.chain_common_ancestor_walk(side_tip, sink, horizon), Some(fork_point), "the walk agrees at horizon {horizon}");
    }
    // Below it both abstain — including at exactly one short of the boundary.
    for horizon in [0, 1, REWIND as u64 - 1] {
        assert_eq!(vp.chain_common_ancestor_within(side_tip, sink, horizon), None, "binary search abstains at {horizon}");
        assert_eq!(vp.chain_common_ancestor_walk(side_tip, sink, horizon), None, "the walk agrees at {horizon}");
    }
    // The boundary is the canonical rewind (15), NOT the side-branch length (8): a horizon that
    // covers the side branch but not the rewind must still abstain.
    assert!(SIDE_LEN < REWIND);
    assert_eq!(vp.chain_common_ancestor_within(side_tip, sink, SIDE_LEN as u64), None);
    assert_eq!(vp.chain_common_ancestor_walk(side_tip, sink, SIDE_LEN as u64), None);
    // Degenerate inputs: canonical vs itself, and canonical vs one of its own chain ancestors.
    assert_eq!(vp.chain_common_ancestor_within(sink, sink, 10), Some(sink));
    assert_eq!(vp.chain_common_ancestor_walk(sink, sink, 10), Some(sink));
    assert_eq!(vp.chain_common_ancestor_within(fork_point, sink, 100), Some(fork_point));
    assert_eq!(vp.chain_common_ancestor_walk(fork_point, sink, 100), Some(fork_point));
}

/// Critical-1 regression: **a long secret branch must not buy an abstain.**
///
/// The gate's horizon is a bound on the search, and turning "I stopped looking" into a consensus
/// decision is what made the old candidate-side walk exploitable. Shape of the attack it allowed:
///
/// ```text
///   fork F
///     canonical:  F → C1 … C15          (15 blocks — all this candidate would rewind)
///     secret:     F → A1 … A60          (60 blocks — mined in private, arbitrarily long)
/// ```
///
/// Walking back from the CANDIDATE, a horizon of 20 runs out 40 blocks short of `F`, reports "no
/// common ancestor", and the gate abstains — so an attacker bought a pass out of DNS adjudication
/// purely by making the secret branch longer, which costs nothing to do. Walking back from
/// CANONICAL asks the question the horizon is actually named for — how many of MY blocks does this
/// rewind — and 15 is well inside 20, so the ancestor is found and the gate adjudicates.
///
/// This is the mirror of `dns_gate_common_ancestor_search_matches_walk_on_canonical_rewind_depth`,
/// which pins the same metric from the other side (side branch SHORTER than the rewind). Both
/// asymmetries are needed: one proves a short branch cannot dodge the horizon, this one proves a
/// long branch cannot dodge the gate.
#[tokio::test]
async fn dns_gate_long_secret_branch_cannot_buy_an_abstain() {
    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..40 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    }

    const REWIND: usize = 15; // canonical blocks the secret branch would rewind
    const SECRET_LEN: usize = 60; // secret branch — deliberately MUCH longer than the rewind
    const HORIZON: u64 = 20; // covers the rewind, nowhere near the secret branch
    assert!(REWIND < HORIZON as usize && (HORIZON as usize) < SECRET_LEN, "the horizon must separate the two metrics");

    let sink = ctx.consensus.get_sink();
    let fork_point = {
        let vp = ctx.consensus.virtual_processor();
        vp.reachability_service.default_backward_chain_iterator(sink).nth(REWIND).expect("the chain is longer than REWIND")
    };
    let secret_tip = ctx.build_and_insert_disqualified_chain(vec![fork_point], SECRET_LEN).await;
    // Built up front: extending the branch needs `&mut ctx`, which cannot overlap the `vp` borrow.
    let longer_tip = ctx.build_and_insert_disqualified_chain(vec![secret_tip], SECRET_LEN).await;

    let vp = ctx.consensus.virtual_processor();
    // The ancestor is found: the horizon bounds the canonical rewind (15), not the secret branch (60).
    assert_eq!(
        vp.chain_common_ancestor_within(secret_tip, sink, HORIZON),
        Some(fork_point),
        "a {SECRET_LEN}-block secret branch must not push a {REWIND}-block rewind out of a {HORIZON} horizon"
    );
    assert_eq!(vp.chain_common_ancestor_walk(secret_tip, sink, HORIZON), Some(fork_point), "the reference walk agrees");

    // Lengthening the secret branch further changes nothing — the metric is not on that side.
    assert_eq!(
        vp.chain_common_ancestor_within(longer_tip, sink, HORIZON),
        Some(fork_point),
        "doubling the secret branch must not change the verdict"
    );
    assert_eq!(vp.chain_common_ancestor_walk(longer_tip, sink, HORIZON), Some(fork_point));

    // And the horizon still bites where it should: one short of the canonical rewind, both abstain.
    assert_eq!(vp.chain_common_ancestor_within(secret_tip, sink, REWIND as u64 - 1), None);
    assert_eq!(vp.chain_common_ancestor_walk(secret_tip, sink, REWIND as u64 - 1), None);

    // The bug this pins, stated executably. Swapping the arguments makes the walk measure the
    // SECRET side — exactly what the pre-fix code did — and at the same horizon it reports "no
    // common ancestor", which the gate turns into an abstain. Same DAG, same horizon, opposite
    // verdict: the metric alone is the difference between adjudicating and standing aside.
    assert_eq!(
        vp.chain_common_ancestor_walk(sink, secret_tip, HORIZON),
        None,
        "measuring the secret side abstains — this is the hole, kept here so it cannot come back unnoticed"
    );
}

/// **The boundary of the DNS liveness work, stated executably.** Releasing the DNS veto —
/// horizon, TTL, work override, all of it — cannot converge a fork whose branches disagree about
/// whether each other's blocks are *valid*.
///
/// Every DNS release path acts at sink selection, on candidates that have already passed UTXO
/// validation. When a node judges the other branch UTXO-invalid, those blocks are disqualified
/// **before** the gate is ever consulted, so no amount of gate permissiveness reaches them. That
/// is why the incident reports separate the two layers: testnet-21's split was verdict divergence
/// (layer 1) wearing a relay/IBD closure (layer 2), and testnet-22 still lists overlay-commitment
/// verdict divergence among its unresolved candidate causes.
///
/// Construction is deliberately blunt: a side branch heavier than canonical, built UTXO-invalid,
/// with the DNS gate provably dormant (no bond ⇒ never `Active`) so it cannot be blamed for the
/// non-convergence. The heavier branch is refused anyway.
///
/// Kept so nobody reads the partition-liveness commits as "chain splits are fixed". They are not:
/// what is fixed is DNS turning a split into a permanent one.
#[tokio::test]
async fn verdict_divergent_branch_does_not_converge_even_with_the_dns_gate_dormant() {
    use crate::model::stores::{dns_state::DnsStateStoreReader, ghostdag::GhostdagStoreReader};
    use kaspa_consensus_core::dns_finality::DnsRolloutStage;

    kaspa_core::log::try_init_logger("info");
    let config = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..20 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await;
    }

    const REWIND: usize = 5; // canonical blocks the side branch forks below
    const SIDE_LEN: usize = 40; // long enough to out-work the canonical tail by a wide margin
    let sink_before = ctx.consensus.get_sink();
    let fork_point = {
        let vp = ctx.consensus.virtual_processor();
        vp.reachability_service.default_backward_chain_iterator(sink_before).nth(REWIND).expect("chain longer than REWIND")
    };
    let side_tip = ctx.build_and_insert_disqualified_chain(vec![fork_point], SIDE_LEN).await;

    // The side branch really is heavier — this is not a work-starved branch being ignored.
    {
        let vp = ctx.consensus.virtual_processor();
        let side_work = vp.ghostdag_store.get_blue_work(side_tip).unwrap();
        let canon_work = vp.ghostdag_store.get_blue_work(sink_before).unwrap();
        assert!(side_work > canon_work, "the side branch must out-work canonical ({side_work} vs {canon_work})");

        // And the DNS gate is dormant: no bond was ever created, so the rollout never reached
        // `Active` and `dns_reorg_outcome` short-circuits to `GateInactive` before any horizon,
        // TTL or override logic runs. Whatever refuses this branch, it is not the DNS veto.
        let stage = vp.dns_state_store.read().get().map(|s| s.rollout_stage).unwrap_or(DnsRolloutStage::Launch);
        assert_ne!(stage, DnsRolloutStage::Active, "the gate must be provably out of the picture for this test to mean anything");
    }

    // Refused anyway: the blocks never became sink candidates, because this node judged them
    // UTXO-invalid. Sink selection — where every DNS release path lives — is downstream of that.
    assert_eq!(ctx.consensus.block_status(side_tip), BlockStatus::StatusDisqualifiedFromChain, "the branch is verdict-rejected");
    assert_eq!(ctx.consensus.get_sink(), sink_before, "a heavier but verdict-rejected branch does not move the sink");

    // The honest reading: DNS bounded ⇒ a split cannot be made permanent BY DNS. A split caused by
    // divergent validation still needs the divergence itself fixed.
    assert!(
        ctx.consensus.virtual_processor().reachability_service.is_chain_ancestor_of(fork_point, ctx.consensus.get_sink()),
        "both branches still share the fork point; nothing converged them"
    );
}

/// Confirmed-anchor TTL (`dns_veto_ttl_daa_score`) end to end on a real DAG — the release path for
/// a node defending an anchor its own branch no longer supports.
///
/// Shape (the testnet-20 dead-branch wedge, and what an isolated node lands in): a validator bonds
/// and attests once, the node confirms an anchor, then attestation stops while the node keeps
/// mining. `advance_dns_confirmation` carries that same anchor forward forever, so before the TTL
/// existed the veto stayed armed on a branch nothing was supporting, and only a >4x work override
/// or a fork deeper than the horizon could ever release it.
///
/// Both directions are asserted from the identical block script, so the TTL is provably the cause:
///   * TTL disabled (`u64::MAX`) → the heavier stake-less branch is REFUSED (this is also the
///     51%-attack property `dns_v3_pow_majority_cannot_rewrite_confirmed_anchor` pins).
///   * TTL exceeded            → the veto releases and the node follows the work-dominant chain.
///
/// The attacker is deliberately kept under the 4x override ratio, so in the control case the
/// refusal comes from the stake dimension and nothing else.
#[tokio::test]
async fn dns_stale_anchor_ttl_releases_a_dead_branch_wedge() {
    use crate::model::stores::{dns_state::DnsStateStoreReader, ghostdag::GhostdagStoreReader, headers::HeaderStoreReader};
    use kaspa_consensus_core::{
        Hash64,
        dns_finality::{DnsRolloutStage, STAKE_SCORE_SCALE, StakeScore, ready_epoch_from_tip_blue_score},
    };
    kaspa_core::log::try_init_logger("info");

    /// Runs the same script under one TTL and reports whether the confirmed anchor survived on the
    /// honest node's selected chain after the heavier stake-less branch arrived.
    async fn anchor_survives_with_ttl(ttl: u64) -> bool {
        let config = ConfigBuilder::new(MAINNET_PARAMS)
            .skip_proof_of_work()
            .edit_consensus_params(|p| {
                p.max_block_parents = 4;
                p.mergeset_size_limit = 10;
                p.coinbase_maturity = 2;
                let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap(); // TwoDimensionalDominance
                dns.dns_activation_daa_score = 0;
                dns.pos_v2_activation_daa_score = 0;
                dns.epoch_length_blocks = 2;
                dns.reward_uniqueness_window_blocks = 50;
                // A generous gate horizon so the fork stays gate-eligible: the release under test
                // must be the TTL, never the horizon abstain.
                dns.max_reorg_horizon_blocks = 1000;
                dns.dns_gate_horizon_blocks = 5000;
                dns.dns_veto_ttl_daa_score = ttl;
                dns.attestation_epoch_length_blue_score = 3;
                dns.attestation_lag_blue_score = 2;
                dns.attestation_anchor_backoff_blue_score = 1;
                dns.stake_score_window_blue_score = 10_000;
                dns.required_work_depth = kaspa_consensus_core::BlueWorkType::ZERO;
                dns.required_stake_depth = StakeScore(STAKE_SCORE_SCALE / 2);
                p.dns_params = Some(dns);
            })
            .build();
        let mut ctx = TestContext::new(TestConsensus::new(&config));

        // ---- Honest node: bond a validator, attest once, reach a DNS-confirmed anchor. ----
        let seed = [0x42u8; 32];
        let v = dns_harness::harness_validator(seed);
        let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
        let k_spk = p2pkh_mldsa87_spk(&k_payload);
        let k_miner = MinerData::new(k_spk.clone(), vec![]);
        let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
        let h_a = ctx.mine_block(k_miner.clone(), vec![]).await;
        let h_b = ctx.mine_block(k_miner.clone(), vec![]).await;
        let cb_a = &h_a.transactions[0];
        let (ia, oa) = cb_a.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_a pays K");
        let (coinbase_a, value_a, daa_a) = (TransactionOutpoint::new(cb_a.id(), ia as u32), oa.value, h_a.header.daa_score);
        let cb_b = &h_b.transactions[0];
        let (ib, ob) = cb_b.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("h_b pays K");
        let (coinbase_b, value_b, daa_b) = (TransactionOutpoint::new(cb_b.id(), ib as u32), ob.value, h_b.header.daa_score);
        for _ in 0..5 {
            ctx.mine_block(new_miner_data(), vec![]).await;
        }
        let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
        let (bond_tx, _vid, _rp) =
            dns_harness::funded_signed_bond_tx(seed, coinbase_a, value_a, daa_a, value_a - 100_000, 0, storage_mass_parameter);
        let bond_tx_id = bond_tx.id();
        ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
        let bond_outpoint = TransactionOutpoint::new(bond_tx_id, 0);
        for _ in 0..8 {
            ctx.mine_block(new_miner_data(), vec![]).await;
        }
        let dns = ctx.consensus.params().dns_params.clone().unwrap();
        let genesis_hash = ctx.consensus.params().genesis.hash;
        let sink = ctx.consensus.get_sink();
        let anchor = {
            let vp = ctx.consensus.virtual_processor();
            let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
            let lr =
                ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
                    .expect("an epoch is ready");
            vp.canonical_anchor_by_blue_score(lr, sink, &dns).expect("canonical anchor")
        };
        let att = dns_harness::build_signed_attestation(
            &v,
            genesis_hash.as_byte_slice(),
            bond_outpoint,
            anchor.epoch,
            anchor.anchor_hash,
            anchor.anchor_daa_score,
            Hash64::default(),
        );
        let shard_tx = dns_harness::funded_signed_shard_tx(seed, coinbase_b, value_b, daa_b, att, storage_mass_parameter);
        ctx.mine_block(new_miner_data(), vec![shard_tx]).await;
        for _ in 0..15 {
            ctx.mine_block(new_miner_data(), vec![]).await;
        }
        let confirmed_anchor = {
            let vp = ctx.consensus.virtual_processor();
            let st = vp.dns_state_store.read().get().expect("DnsState");
            assert_eq!(st.rollout_stage, DnsRolloutStage::Active, "honest node is Active");
            assert_ne!(st.last_dns_confirmed_anchor, Hash64::default(), "honest node has a confirmed anchor");
            st.last_dns_confirmed_anchor
        };

        // ---- Attestation STOPS while the node keeps mining: the anchor freezes, the tip runs on. ----
        for _ in 0..40 {
            ctx.mine_block(new_miner_data(), vec![]).await;
        }
        let (honest_work, anchor_age) = {
            let vp = ctx.consensus.virtual_processor();
            let st = vp.dns_state_store.read().get().expect("DnsState");
            assert_eq!(st.last_dns_confirmed_anchor, confirmed_anchor, "no new confirmation: the same anchor is carried forward");
            let sink = ctx.consensus.get_sink();
            let sink_daa = vp.headers_store.get_daa_score(sink).unwrap();
            (vp.ghostdag_store.get_blue_work(sink).unwrap(), sink_daa.saturating_sub(st.last_dns_confirmed_anchor_daa_score))
        };
        assert!(anchor_age > 20, "the anchor must have aged measurably on the node's own chain (got {anchor_age})");

        // ---- A heavier, stake-less branch arrives — heavier, but under the 4x override ratio. ----
        let mut atk = TestContext::new(TestConsensus::new(&config));
        let mut attacker_blocks = Vec::new();
        for _ in 0..110 {
            attacker_blocks.push(atk.mine_block(new_miner_data(), vec![]).await);
        }
        let attacker_tip = attacker_blocks.last().unwrap().header.hash;
        let attacker_work = { atk.consensus.virtual_processor().ghostdag_store.get_blue_work(attacker_tip).unwrap() };
        assert!(attacker_work > honest_work, "the branch is genuinely heavier ({attacker_work} vs {honest_work})");
        let (four_x, overflowed) = honest_work.overflowing_mul_u64(4);
        assert!(!overflowed && attacker_work < four_x, "and stays UNDER the 4x work override, so only the TTL can explain a release");
        for b in &attacker_blocks {
            ctx.validate_and_insert_block(b.clone()).await;
        }

        let new_sink = ctx.consensus.get_sink();
        let vp = ctx.consensus.virtual_processor();
        let survived = vp.reachability_service.is_chain_ancestor_of(confirmed_anchor, new_sink);
        assert_eq!(
            survived,
            new_sink != attacker_tip,
            "the two ways of asking (anchor still on the chain / sink moved to the branch) must agree"
        );
        survived
    }

    assert!(
        anchor_survives_with_ttl(u64::MAX).await,
        "control: with the TTL disabled the veto never expires, so the heavier stake-less branch is refused"
    );
    assert!(
        !anchor_survives_with_ttl(20).await,
        "with the anchor aged past the TTL the veto releases and the node follows the work-dominant chain"
    );
}

/// What one run of the ADR-0128 pipeline script saw — see [`run_the_bft_gate`].
struct BftGateRun {
    /// The epoch the validator attested, and its anchor on the honest chain.
    attested: kaspa_consensus_core::dns_finality::CanonicalLaggedEpochAnchor,
    /// The duty the chain answered once round one was in, and once the precommit was.
    duty_after_attesting: kaspa_consensus_core::dns_finality::PrecommitDuty,
    duty_after_precommitting: Option<kaspa_consensus_core::dns_finality::PrecommitDuty>,
    /// The overlay state just before the heavier branch arrived.
    state_before_attack: kaspa_consensus_core::dns_finality::DnsState,
    /// Whether the StakeScore depth rule's own threshold was cleared at that point — what it would
    /// have confirmed on without the fence.
    depth_rule_clears: bool,
    /// Whether this node's own BFT evaluation at the sink could cover its walk, and whether the gate
    /// was abstaining when the heavier branch arrived.
    evaluation_covered: bool,
    gate_abstaining: bool,
    /// After the heavier stake-less branch arrived: the sink moved onto it, and the attested anchor
    /// is (not) still on the selected chain.
    sink_is_attacker: bool,
    anchor_survived: bool,
}

/// The shape of one run.
#[derive(Clone, Copy)]
struct BftGateScript {
    /// `Params::dns_bft_gate`'s height, or no fence at all.
    fence: Option<kaspa_consensus_core::config::params::ForkActivation>,
    /// Whether the validator signs round two.
    precommit: bool,
    /// `dns_veto_ttl_daa_score`.
    ttl: u64,
    /// Blocks mined with no further votes before the heavier branch arrives.
    age_blocks: usize,
    /// Delete the bond block's acceptance data after the votes, so the next evaluation cannot cover
    /// its walk.
    punch_a_hole: bool,
}

/// **The ADR-0128 pipeline script.** A single validator (one bonded validator is a whole counted
/// set: the floor holds, nothing leaks, its bond is `W(E)`) bonds, attests the latest ready epoch in
/// a funded shard, and — when the script says so — signs round two from the precommit duty the chain
/// answers, in a funded precommit tx. The honest node then mines on (ageing its anchor when asked),
/// and a separate node mines a longer, stake-less branch from genesis, which is delivered to it.
///
/// The depth rule's own gate is given a two-block reach, so it ABSTAINS on a branch forked at
/// genesis: whatever refuses the heavier branch in these runs is the BFT gate, and whatever lets it
/// through is the depth rule's gate standing aside or the BFT gate releasing.
async fn run_the_bft_gate(script: BftGateScript) -> BftGateRun {
    use crate::model::stores::{acceptance_data::AcceptanceDataStore, dns_state::DnsStateStoreReader, ghostdag::GhostdagStoreReader};
    use kaspa_consensus_core::{
        Hash64,
        config::params::{DnsBftGateV1, ForkActivation},
        dns_finality::{PrecommitLock, STAKE_SCORE_SCALE, StakeScore, ready_epoch_from_tip_blue_score},
    };
    let gate_numbers =
        |activation| DnsBftGateV1 { activation, t_leak_daa: 5_040, reentry_final_depth_daa: 200, min_retained_validators: 4 };
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.max_block_parents = 4;
            p.mergeset_size_limit = 10;
            p.coinbase_maturity = 2;
            let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap(); // TwoDimensionalDominance
            dns.dns_activation_daa_score = 0;
            dns.pos_v2_activation_daa_score = 0;
            dns.epoch_length_blocks = 2;
            dns.reward_uniqueness_window_blocks = 50;
            dns.max_reorg_horizon_blocks = 2;
            dns.dns_gate_horizon_blocks = 2;
            dns.dns_veto_ttl_daa_score = script.ttl;
            dns.attestation_epoch_length_blue_score = 3;
            dns.attestation_lag_blue_score = 2;
            dns.attestation_anchor_backoff_blue_score = 1;
            dns.stake_score_window_blue_score = 10_000;
            dns.required_work_depth = kaspa_consensus_core::BlueWorkType::ZERO;
            dns.required_stake_depth = StakeScore(STAKE_SCORE_SCALE / 2);
            p.dns_params = Some(dns);
            p.dns_bft_gate = script.fence.map(gate_numbers);
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // ---- A validator bonds, and keeps three matured coinbases to fund its votes with. ----
    let seed = [0x42u8; 32];
    let v = dns_harness::harness_validator(seed);
    let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&v.pubkey).as_bytes();
    let k_spk = p2pkh_mldsa87_spk(&k_payload);
    let k_miner = MinerData::new(k_spk.clone(), vec![]);
    let _b1 = ctx.mine_block(k_miner.clone(), vec![]).await;
    let mut funding = Vec::new();
    for _ in 0..3 {
        let block = ctx.mine_block(k_miner.clone(), vec![]).await;
        let cb = &block.transactions[0];
        let (i, o) = cb.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == k_spk).expect("the coinbase pays K");
        funding.push((TransactionOutpoint::new(cb.id(), i as u32), o.value, block.header.daa_score));
    }
    for _ in 0..5 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
    let (bond_tx, _vid, _rp) = dns_harness::funded_signed_bond_tx(
        seed,
        funding[0].0,
        funding[0].1,
        funding[0].2,
        funding[0].1 - 100_000,
        0,
        storage_mass_parameter,
    );
    let bond_outpoint = TransactionOutpoint::new(bond_tx.id(), 0);
    let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
    assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid);
    for _ in 0..8 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }

    // ---- Round one: attest the latest ready epoch. ----
    let dns = ctx.consensus.params().dns_params.clone().unwrap();
    let genesis_hash = ctx.consensus.params().genesis.hash;
    let attested = {
        let vp = ctx.consensus.virtual_processor();
        let sink = ctx.consensus.get_sink();
        let sink_blue = vp.headers_store.get_blue_score(sink).unwrap();
        let ready =
            ready_epoch_from_tip_blue_score(sink_blue, dns.attestation_epoch_length_blue_score, dns.attestation_lag_blue_score)
                .expect("an epoch is ready");
        vp.canonical_anchor_by_blue_score(ready, sink, &dns).expect("canonical anchor")
    };
    let att = dns_harness::build_signed_attestation(
        &v,
        genesis_hash.as_byte_slice(),
        bond_outpoint,
        attested.epoch,
        attested.anchor_hash,
        attested.anchor_daa_score,
        Hash64::default(),
    );
    let shard_tx = dns_harness::funded_signed_shard_tx(seed, funding[1].0, funding[1].1, funding[1].2, att, storage_mass_parameter);
    ctx.mine_block(new_miner_data(), vec![shard_tx]).await;
    for _ in 0..4 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let duty_after_attesting = ctx.consensus.get_precommit_duty(v.validator_id, bond_outpoint).expect("the network runs an overlay");

    // ---- Round two, from the duty — or, below the fence, from the commitment the rules would ask
    //      for, so every run that precommits carries the same transactions. ----
    let mut duty_after_precommitting = None;
    if script.precommit {
        let commitment = match duty_after_attesting.due.iter().find(|due| due.0 == attested.epoch) {
            Some(due) => due.3,
            None => {
                use crate::model::stores::stake_bonds::StakeBondsStoreReader;
                let vp = ctx.consensus.virtual_processor();
                let bonds: Vec<_> =
                    vp.stake_bonds_store.read().iterator().filter_map(|r| r.ok().map(|(_, rec)| (*rec).clone())).collect();
                let evaluation = vp
                    .dns_bft_evaluate(ctx.consensus.get_sink(), &bonds, &dns, &gate_numbers(ForkActivation::always()))
                    .expect("the walk covers a chain shorter than its bound");
                evaluation
                    .verdicts
                    .iter()
                    .find(|verdict| verdict.epoch.epoch == attested.epoch)
                    .expect("the epoch is evaluated")
                    .snapshot_commitment
            }
        };
        let precommit = dns_harness::build_signed_precommit(
            &v,
            genesis_hash.as_byte_slice(),
            bond_outpoint,
            attested.epoch,
            attested.anchor_hash,
            attested.anchor_daa_score,
            PrecommitLock::default(),
            commitment,
        );
        let precommit_tx = dns_harness::funded_signed_precommit_tx(
            seed,
            funding[2].0,
            funding[2].1,
            funding[2].2,
            &precommit,
            storage_mass_parameter,
        );
        let precommit_block = ctx.mine_block(new_miner_data(), vec![precommit_tx]).await;
        assert_eq!(ctx.consensus.block_status(precommit_block.header.hash), BlockStatus::StatusUTXOValid);
    }
    for _ in 0..15 {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    if script.precommit {
        duty_after_precommitting = Some(ctx.consensus.get_precommit_duty(v.validator_id, bond_outpoint).expect("overlay"));
    }
    if script.punch_a_hole {
        ctx.consensus.virtual_processor().acceptance_data_store.delete(bond_block.header.hash).unwrap();
        // A node that comes up with the hole: nothing an earlier walk read is in its memory either.
        ctx.consensus.virtual_processor().dns_bft_runtime.forget_accepted_votes();
    }
    for _ in 0..script.age_blocks {
        ctx.mine_block(new_miner_data(), vec![]).await;
    }
    let (state_before_attack, honest_work, honest_blue, evaluation_covered) = {
        use crate::model::stores::stake_bonds::StakeBondsStoreReader;
        let vp = ctx.consensus.virtual_processor();
        let sink = ctx.consensus.get_sink();
        let bonds: Vec<_> = vp.stake_bonds_store.read().iterator().filter_map(|r| r.ok().map(|(_, rec)| (*rec).clone())).collect();
        let evaluate = || vp.dns_bft_evaluate(sink, &bonds, &dns, &gate_numbers(ForkActivation::always()));
        let covered = match evaluate() {
            Ok(first) => {
                // The walk's memo: a second walk over the same chain reads no block from the stores, and
                // what it decides is what a walk reading every block from the stores decides.
                let from_memo = evaluate().expect("covered once, covered again");
                assert_eq!(
                    (from_memo.read, from_memo.walked),
                    (0, first.walked),
                    "a second walk over one chain reads every block from the memo"
                );
                vp.dns_bft_runtime.forget_accepted_votes();
                let from_stores = evaluate().expect("the stores still cover the walk");
                assert!(
                    from_stores.read > 0 && from_stores.read <= from_stores.walked,
                    "with the memo gone the walk reads the stores again"
                );
                for evaluation in [&from_memo, &from_stores] {
                    assert_eq!((&evaluation.verdicts, &evaluation.precommits), (&first.verdicts, &first.precommits));
                }
                true
            }
            Err(_) => false,
        };
        (
            vp.dns_state_store.read().get().expect("DnsState"),
            vp.ghostdag_store.get_blue_work(sink).unwrap(),
            vp.headers_store.get_blue_score(sink).unwrap(),
            covered,
        )
    };
    let depth_rule_clears = state_before_attack.stake_depth >= dns.required_stake_depth;
    let gate_abstaining = ctx.consensus.virtual_processor().dns_bft_runtime.gate_abstains();

    // ---- A longer, stake-less branch from genesis arrives. ----
    let mut atk = TestContext::new(TestConsensus::new(&config));
    let mut attacker_blocks = Vec::new();
    for _ in 0..(honest_blue as usize + 30) {
        attacker_blocks.push(atk.mine_block(new_miner_data(), vec![]).await);
    }
    let attacker_tip = attacker_blocks.last().unwrap().header.hash;
    let attacker_work = atk.consensus.virtual_processor().ghostdag_store.get_blue_work(attacker_tip).unwrap();
    assert!(attacker_work > honest_work, "the branch is genuinely heavier ({attacker_work} vs {honest_work})");
    for b in &attacker_blocks {
        ctx.validate_and_insert_block(b.clone()).await;
    }
    let new_sink = ctx.consensus.get_sink();
    let anchor_survived = ctx.consensus.virtual_processor().reachability_service.is_chain_ancestor_of(attested.anchor_hash, new_sink);
    BftGateRun {
        attested,
        duty_after_attesting,
        duty_after_precommitting,
        state_before_attack,
        depth_rule_clears,
        evaluation_covered,
        gate_abstaining,
        sink_is_attacker: new_sink == attacker_tip,
        anchor_survived,
    }
}

/// **ADR-0128 §6, in the pipeline: past the fence a reorg abandoning a DNS-final anchor is refused,
/// and below it the same reorg follows the depth rule.**
///
/// One block script, two heights for the fence. Past it (genesis) the validator's attestation and
/// its precommit — signed from the duty the chain answers, with the commitment the duty names —
/// make the attested anchor DNS-final and the confirmed anchor; the duty then shows the lock and
/// owes nothing; and the heavier stake-less branch is refused, though the depth rule's own gate
/// abstains at its two-block reach. Below it (a height the chain never reaches) the depth rule
/// confirms as it always has, its gate stands aside for the deep fork, and the node follows the
/// heavier branch.
#[tokio::test]
async fn adr0128_a_reorg_abandoning_a_dns_final_anchor_is_refused_past_the_fence_and_follows_the_old_rule_below_it() {
    use kaspa_consensus_core::{config::params::ForkActivation, dns_finality::PrecommitLock};
    kaspa_core::log::try_init_logger("info");
    let script =
        BftGateScript { fence: Some(ForkActivation::always()), precommit: true, ttl: u64::MAX, age_blocks: 0, punch_a_hole: false };

    let past = run_the_bft_gate(script).await;
    let epoch = past.attested.epoch;
    let duty = &past.duty_after_attesting;
    assert!(duty.round_active, "past the fence the round is live at the sink");
    assert_eq!(duty.held, PrecommitLock::default(), "no precommit yet, so no lock");
    let due = duty.due.iter().find(|d| d.0 == epoch).expect("round one reached quorum, so the attested epoch is due");
    assert_eq!((due.1, due.2), (past.attested.anchor_hash, past.attested.anchor_daa_score), "the duty names the anchor");
    let after = past.duty_after_precommitting.as_ref().expect("precommitted");
    assert_eq!(after.held, PrecommitLock { epoch, anchor: past.attested.anchor_hash }, "the chain shows the lock it took");
    assert!(after.due.iter().all(|d| d.0 > epoch), "the precommitted epoch, and every one below the lock, is no longer due");
    assert_eq!(past.state_before_attack.last_dns_confirmed_anchor, past.attested.anchor_hash, "the DNS-final anchor is confirmed");
    assert_eq!(past.state_before_attack.last_dns_confirmed_anchor_daa_score, past.attested.anchor_daa_score);
    assert!(!past.gate_abstaining && past.evaluation_covered);
    assert!(past.anchor_survived && !past.sink_is_attacker, "past the fence the heavier branch that abandons the anchor is refused");

    let below = run_the_bft_gate(BftGateScript { fence: Some(ForkActivation::new(10_000_000)), ..script }).await;
    assert!(!below.duty_after_attesting.round_active, "below the fence round two is not live");
    assert!(below.duty_after_attesting.due.is_empty());
    assert!(below.depth_rule_clears, "the depth rule's threshold is cleared");
    assert_ne!(
        below.state_before_attack.last_dns_confirmed_anchor,
        kaspa_consensus_core::Hash64::default(),
        "and it confirms as before"
    );
    assert!(
        below.sink_is_attacker && !below.anchor_survived,
        "below the fence the depth rule's gate abstains on a fork beyond its reach and the heavier branch wins"
    );
}

/// **ADR-0128 §6: a stale DNS-final anchor releases.** The past-the-fence run above, with the
/// validator going silent after its precommit and the node mining on past `dns_veto_ttl_daa_score`:
/// the anchor is carried forward (nothing newer is final), goes stale on this node's own chain, and
/// the heavier branch is let through to the comparator that would otherwise have been shielded.
#[tokio::test]
async fn adr0128_a_stale_dns_final_anchor_releases_the_veto() {
    use kaspa_consensus_core::config::params::ForkActivation;
    kaspa_core::log::try_init_logger("info");
    let run = run_the_bft_gate(BftGateScript {
        fence: Some(ForkActivation::always()),
        precommit: true,
        ttl: 20,
        age_blocks: 40,
        punch_a_hole: false,
    })
    .await;
    assert_eq!(
        run.state_before_attack.last_dns_confirmed_anchor, run.attested.anchor_hash,
        "carried forward while nothing newer is final"
    );
    let age = run.state_before_attack.anchor_daa_score.saturating_sub(run.state_before_attack.last_dns_confirmed_anchor_daa_score);
    assert!(age > 20, "the anchor aged past the TTL on the node's own chain (age {age})");
    assert!(run.sink_is_attacker && !run.anchor_survived, "a stale anchor is no veto");
}

/// **ADR-0128 §6: validators who never reach precommit quorum advance no anchor, and the gate
/// behaves as without the fence.** Past the fence the validator attests (round one is met, and the
/// duty says so) but never precommits: the confirmed anchor never advances although the depth rule's
/// threshold is cleared, and the heavier branch goes through exactly as it does in the same script
/// with no fence at all.
#[tokio::test]
async fn adr0128_validators_that_never_reach_precommit_quorum_advance_no_anchor() {
    use kaspa_consensus_core::{Hash64, config::params::ForkActivation};
    kaspa_core::log::try_init_logger("info");
    let script =
        BftGateScript { fence: Some(ForkActivation::always()), precommit: false, ttl: u64::MAX, age_blocks: 0, punch_a_hole: false };
    let silent = run_the_bft_gate(script).await;
    assert!(silent.duty_after_attesting.round_active);
    assert!(silent.duty_after_attesting.due.iter().any(|d| d.0 == silent.attested.epoch), "round one is met and round two is owed");
    assert!(silent.depth_rule_clears, "the depth rule alone would have confirmed");
    assert_eq!(silent.state_before_attack.last_dns_confirmed_anchor, Hash64::default(), "round one alone confirms nothing");
    assert!(silent.sink_is_attacker, "nothing is vetoed");

    let unfenced = run_the_bft_gate(BftGateScript { fence: None, ..script }).await;
    assert!(!unfenced.duty_after_attesting.round_active, "without the fence there is no round two");
    assert_eq!(silent.sink_is_attacker, unfenced.sink_is_attacker, "the same reorg outcome as without the fence");
    assert_eq!(silent.anchor_survived, unfenced.anchor_survived);
}

/// **ADR-0128 Decision 3: a node whose walk cannot cover its bound abstains.** The past-the-fence run
/// with one chain block's acceptance data deleted after the votes: the next evaluation cannot read
/// the walk (the log names the block), the confirmed anchor does not advance — the DNS-final anchor
/// is carried, not re-derived — and the gate that would have refused the heavier branch stands aside
/// instead of judging on evidence this node does not hold.
#[tokio::test]
async fn adr0128_an_evaluation_that_cannot_cover_its_walk_does_not_advance_and_the_gate_abstains() {
    use kaspa_consensus_core::{Hash64, config::params::ForkActivation};
    kaspa_core::log::try_init_logger("info");
    let run = run_the_bft_gate(BftGateScript {
        fence: Some(ForkActivation::always()),
        precommit: true,
        ttl: u64::MAX,
        age_blocks: 6,
        punch_a_hole: true,
    })
    .await;
    assert!(!run.evaluation_covered, "the hole is inside the walk");
    assert!(run.gate_abstaining, "the evaluation after the hole says so");
    assert_eq!(
        run.state_before_attack.last_dns_confirmed_anchor, run.attested.anchor_hash,
        "the confirmation is carried, not advanced"
    );
    assert!(run.sink_is_attacker, "the gate abstains");
    assert_ne!(run.attested.anchor_hash, Hash64::default());
}

/// **ADR-0128 Decision 5 on a ConsensusV2 network: the BFT gate is asked before the PALW comparator,
/// and only refuses.**
///
/// On a V2 chain `dns_reorg_outcome` used to answer a reorg candidate with the PALW comparator and
/// return before the DNS half ran. Built over a real V2 chain with the overlay state written by hand
/// (no validator economy is needed to ask the gate a question): a candidate that abandons a DNS-final
/// anchor the BFT rule confirmed is refused before the comparator is consulted; the incumbent itself
/// passes; and wherever the gate does not refuse — the anchor stale on this node's own chain, the
/// state written before the fence, an incumbent below the fence — the outcome is exactly the
/// comparator's.
#[tokio::test]
async fn adr0128_on_a_v2_network_the_bft_gate_refuses_before_the_palw_comparator_runs() {
    use crate::model::stores::dns_state::DnsStateStore;
    use kaspa_consensus_core::{
        Hash64,
        config::params::{DnsBftGateV1, ForkActivation},
        dns_finality::{ActiveBondView, DnsHealth, DnsReorgOutcome, DnsRolloutStage, DnsState, StakeScore},
        palw_mode_v2::PalwConsensusMode,
    };
    const FENCE: u64 = 5;
    // A V2 network runs the overlay's two-minute windows exactly (`validate_palw_v2`), so the TTL is
    // the cadence's own 120 and the chain is mined past it.
    const TTL: u64 = 120;
    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            p.dns_params = DEVNET_PARAMS.dns_params.clone();
            *p = p.clone().with_palw_v2_cadence();
            assert_eq!(p.dns_params.as_ref().unwrap().dns_veto_ttl_daa_score, TTL);
            p.dns_bft_gate = Some(DnsBftGateV1 {
                activation: ForkActivation::new(FENCE),
                t_leak_daa: 50,
                reentry_final_depth_daa: 10,
                min_retained_validators: 4,
            });
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..(TTL + 16) {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();
    let chain: Vec<(BlockHash, u64)> = vp
        .reachability_service
        .default_backward_chain_iterator(sink)
        .map(|block| (block, vp.headers_store.get_daa_score(block).unwrap()))
        .collect();
    let sink_daa = chain[0].1;
    assert!(sink_daa >= FENCE + TTL + 4, "the chain crosses the fence with room for a stale anchor (sink DAA {sink_daa})");
    // The newest chain block at or below each DAA the cases need.
    let at_or_below = |daa: u64| chain.iter().copied().find(|(_, d)| *d <= daa).expect("the chain reaches genesis");
    let fresh_anchor = at_or_below(sink_daa - 2);
    let stale_anchor = at_or_below(sink_daa - TTL - 4);
    // A chain ancestor of both anchors: it abandons each of them.
    let candidate = at_or_below(stale_anchor.1 - 2).0;
    let below_the_fence = at_or_below(FENCE - 1);
    assert!(below_the_fence.1 < FENCE && stale_anchor.1 > FENCE, "the cases sit on the sides of the fence they claim");
    let bonds = ActiveBondView::default();
    let write_state = |anchor: (BlockHash, u64), written_at_daa: u64| {
        vp.dns_state_store
            .write()
            .set(DnsState {
                selected_chain_anchor: sink,
                anchor_daa_score: written_at_daa,
                work_depth: Default::default(),
                stake_depth: StakeScore(0),
                last_dns_confirmed_anchor: anchor.0,
                last_dns_confirmed_anchor_daa_score: anchor.1,
                rollout_stage: DnsRolloutStage::Active,
                validator_set_commitment: Hash64::default(),
                health: DnsHealth::Active,
            })
            .unwrap();
    };

    // The comparator's own answer, with nothing confirmed.
    write_state((Hash64::default(), 0), sink_daa);
    let comparator = vp.dns_reorg_outcome(candidate, sink, &bonds);
    assert_ne!(comparator, DnsReorgOutcome::HardCheckpointReject, "the PALW comparator never answers with the stake gate's refusal");

    // A DNS-final anchor the BFT rule confirmed: the abandoning candidate is refused first.
    write_state(fresh_anchor, sink_daa);
    assert_eq!(vp.dns_bft_gate_refusal(candidate, sink), Some(DnsReorgOutcome::HardCheckpointReject));
    assert_eq!(vp.dns_reorg_outcome(candidate, sink, &bonds), DnsReorgOutcome::HardCheckpointReject, "refused before the comparator");
    assert!(vp.dns_reorg_outcome(sink, sink, &bonds).is_accept(), "a candidate that contains the anchor goes on as before");
    assert_eq!(vp.dns_bft_gate_refusal(sink, sink), None);

    // Stale on this node's own chain: released, and the comparator decides.
    write_state(stale_anchor, sink_daa);
    assert_eq!(vp.dns_bft_gate_refusal(candidate, sink), None, "a stale anchor is no veto");
    assert_eq!(vp.dns_reorg_outcome(candidate, sink, &bonds), comparator, "released to exactly the comparator's answer");

    // The same anchor in a state the depth rule wrote below the fence: not the vote's to protect.
    write_state(fresh_anchor, FENCE - 1);
    assert_eq!(vp.dns_bft_gate_refusal(candidate, sink), None);
    assert_eq!(vp.dns_reorg_outcome(candidate, sink, &bonds), comparator);

    // An incumbent below the fence: the gate is not in force.
    write_state(fresh_anchor, sink_daa);
    assert_eq!(vp.dns_bft_gate_refusal(candidate, below_the_fence.0), None, "resolved at the incumbent sink's DAA");
}

/// **Qwen3.6's own three series, per epoch, on a two-class chain: expected, observed, target.**
///
/// The live testnet cannot answer this — testnet-11 registered no second class (its 2026-08-24
/// registration carrier was never mined), so its only class holds the whole table and the
/// retarget is an exact no-op by construction. This runs the same question against the same
/// consensus code on the two-class RC genesis, where the entrant is the REAL `PALW-QWEN36` class:
/// its own `shape_profile_id`, its own counted `pwu_per_inference`, its own registered target.
///
/// Every block here is a real block: template, attempt, class lottery, ML-DSA-87 signature, and
/// `validate_and_insert_block` through the virtual processor. What is reused rather than recomputed
/// is the EXECUTION behind one class's roots — one forward pass per class, then the nonce moves the
/// challenge. Acceptance never re-runs an execution (that is the panel's and the court's), so this
/// changes nothing the difficulty loop reads.
///
/// Run: `cargo test --release -p kaspa-consensus qwen36_per_epoch -- --ignored --nocapture`
#[tokio::test]
#[ignore = "produces thousands of real blocks; run explicitly with --ignored --nocapture"]
async fn palw_rc_qwen36_per_epoch_expected_observed_target() {
    use kaspa_consensus_core::api::ConsensusApi;
    use kaspa_consensus_core::palw_attempt_v2::{
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT, PALW_ATTEMPT_V2_VERSION, PalwAttemptEnvelopeV2, PalwAttemptUnsignedV2, attempt_id_v2,
        challenge_v2, class_ticket_v3, execution_anchor_v3, palw_network_domain_v2_for,
    };
    use kaspa_consensus_core::palw_backend::PalwExecutionBackendV1;
    use kaspa_consensus_core::palw_base0_profile::{PALW_RC_BASE0_CANONICAL, PALW_RC_BASE0_GEOMETRY, base0_profile_v1};
    use kaspa_consensus_core::palw_qwen36_profile::{QWEN36_35B_A3B, QWEN36_RC_CANONICAL, qwen36_profile_v1};
    use misaka_palw_base0::produce::{base0_execute_for_attempt_v1, base0_rc_job_anchor_v1, base0_rc_job_v1};
    use misaka_palw_base0::qwen36_backend::Qwen36Backend;

    let epochs: u64 = std::env::var("MISAKA_EPOCHS").ok().and_then(|v| v.parse().ok()).unwrap_or(3);

    // Every registry row gets a REAL key, so claims can be spread over more than one bond: a
    // 1000-block epoch holds ~`window_bind` claims open at once, and one bond is sized for one
    // class's span.
    let keys: Vec<_> = (0..kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1() as u32)
        .map(|i| libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xB0u8.wrapping_add(i as u8); 32]))
        .collect();
    let registry: Vec<_> = keys
        .iter()
        .enumerate()
        .map(|(i, kp)| kaspa_consensus_core::palw_fp_devnet_v3::PalwGenesisBondSpecV1 {
            bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(
                i as u32,
            )),
            pubkey: kp.verification_key.as_ref().to_vec(),
            operator_pubkey: vec![21u8, i as u8, 0, 0, 0, 0, 0, 0],
            payout_payload: kaspa_hashes::Hash64::from_u64_word(0x9A11 + i as u64),
        })
        .collect();

    let base_root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("the floor's artifact derives");
    let qwen_artifact = misaka_palw_base0::qwen36::qwen36_dev_fixture(4, 8);
    let qwen_root = qwen_artifact.artifact_root();
    let params = kaspa_consensus_core::config::params::palw_rc_params_with_qwen36(base_root, qwen_root, registry)
        .expect("the two-class genesis assembles");
    let bundle = match &params.palw_consensus_mode {
        kaspa_consensus_core::palw_mode_v2::PalwConsensusMode::ConsensusV2(b) => b.clone(),
        _ => panic!("a ConsensusV2 network"),
    };
    let epoch_length = bundle.state.epoch_length();
    let qwen_class_id = qwen36_profile_v1(QWEN36_35B_A3B).expect("projects").shape_profile_id();
    let base_class_id = bundle.base_class_id;

    let config = ConfigBuilder::new(params)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            if !cfg!(feature = "evm") {
                p.evm_activation_daa_score = u64::MAX;
                // ADR-0089 Decision 9: the market's EVM face may not be armed on a lane this build
                // makes inert. Turning the lane off is one decision, not two —
                // `validate_palw_v2` refuses the pair and the node would panic at startup.
                p.palw_model_evm = None;
            }
        })
        .build();
    let network_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let ctx = TestContext::new(TestConsensus::new(&config));

    // One execution per class; the nonce does the rest.
    let base_profile = base0_profile_v1(PALW_RC_BASE0_GEOMETRY).expect("expressible");
    let base_artifact = misaka_palw_base0::rc::palw_rc_base0_artifact_v1().expect("derives");
    let seed_anchor = base0_rc_job_anchor_v1(
        network_domain,
        kaspa_hashes::Hash64::from_u64_word(1),
        base_class_id,
        &kaspa_consensus_core::config::premine::premine_outpoint(0),
        0,
    );
    let (base_job, base_prompt) = base0_rc_job_v1(
        &base_profile,
        seed_anchor,
        base_artifact.shape.vocab,
        PALW_RC_BASE0_CANONICAL.0,
        PALW_RC_BASE0_CANONICAL.1,
        kaspa_consensus_core::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
    );
    let base_run = base0_execute_for_attempt_v1(&base_artifact, &base_profile, &base_job, &base_prompt).expect("the floor runs");
    let qwen_backend = Qwen36Backend::new(
        std::sync::Arc::new(qwen_artifact),
        "Qwen3.6-dev-fixture",
        QWEN36_RC_CANONICAL,
        qwen_class_id,
        config.params.net.to_string().into_bytes(),
    );
    let qwen_anchor = base0_rc_job_anchor_v1(
        network_domain,
        kaspa_hashes::Hash64::from_u64_word(2),
        qwen_class_id,
        &kaspa_consensus_core::config::premine::premine_outpoint(1),
        0,
    );
    let (qwen_job, qwen_prompt) = qwen_backend.job_for_anchor(qwen_anchor).expect("the anchor implies a job");
    let qwen_run = qwen_backend.execute(&qwen_job, &qwen_prompt).expect("a real hybrid forward pass");
    // The four roots and the chunk count are all an attempt carries out of an execution, and the
    // two engines return different types — so the commitment material, not the run, is what the
    // loop below selects between.
    let base_roots =
        (base_run.trace_root, base_run.output_root, base_run.execution_root, base_run.trace_manifest_root, base_run.trace_chunk_count);
    let qwen_roots =
        (qwen_run.trace_root, qwen_run.output_root, qwen_run.execution_root, qwen_run.trace_manifest_root, qwen_run.trace_chunk_count);

    println!();
    println!("=== two-class RC chain: BASE-0 {} + QWEN36 {} ===", &base_class_id.to_string()[..16], &qwen_class_id.to_string()[..16]);
    println!("epoch_length {epoch_length}, entrant share {}‰", bundle.state.min_grantable_share_permille());
    println!(
        "{:>5} {:>7} {:>6} {:>9} {:>9} {:>7} {:>12} {:>16} {:>16}",
        "epoch", "class", "share", "expected", "observed", "budget", "pwu", "target before", "target after"
    );

    // Per epoch: how many blocks the entrant tries to produce.
    let qwen_quota = |epoch: u64| -> u64 { if epoch == 0 { 0 } else { 1 } };
    let mut refused_over_budget = 0u64;
    // The counters roll the moment the boundary block lands, so the closed epoch's numbers have to
    // be taken from inside it — the last read before the crossing is the epoch's final state.
    let mut last_in_epoch: Vec<(&'static str, u16, u64, u64, u64, u128, u64)> = Vec::new();

    for epoch in 0..epochs {
        loop {
            let daa = ctx.consensus.get_virtual_daa_score();
            if daa / epoch_length != epoch {
                break;
            }
            let produced_qwen = ctx
                .consensus
                .palw_producer_facts_v2(qwen_class_id, None)
                .map(|f| if f.epoch_index == epoch { f.epoch_produced_blocks } else { 0 })
                .unwrap_or(0);
            let want_qwen = produced_qwen < qwen_quota(epoch);
            let (class_id, bond_index) = if want_qwen { (qwen_class_id, 1u32) } else { (base_class_id, 0u32) };
            let bond = kaspa_consensus_core::config::premine::premine_outpoint(bond_index);
            let facts = ctx.consensus.palw_producer_facts_v2(class_id, Some(bond)).expect("a V2 network answers");
            let run = if want_qwen { qwen_roots } else { base_roots };
            let mut block = ctx.build_block_template_keeping_time(0).block;
            let timestamp = block.header.timestamp;
            let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);
            let mut attempt = PalwAttemptUnsignedV2 {
                version: PALW_ATTEMPT_V2_VERSION,
                network_domain,
                challenge: kaspa_hashes::Hash64::default(),
                class_id,
                executor_bond: bond,
                executor_pubkey: keys[bond_index as usize].verification_key.as_ref().to_vec(),
                operator_id: facts.bond.as_ref().expect("a genesis bond").operator_id,
                artifact_root: facts.artifact_root,
                trace_root: run.0,
                output_root: run.1,
                execution_root: run.2,
                pwu: facts.pwu,
                trace_manifest_root: run.3,
                trace_chunk_count: run.4,
                trace_retention_daa: block.header.daa_score.saturating_add(facts.min_trace_retention_daa),
            };
            // The draw walks the bucket (ADR-0072): the ticket is the execution's under the anchor the
            // header derives, so a nonce inside a bucket moves nothing and the next bucket is the next draw.
            let mut won = None;
            for bucket in 0u64..4096 {
                let nonce = bucket << kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2;
                let anchor = execution_anchor_v3(network_domain, pre_pow, class_id, &bond, nonce);
                if class_ticket_v3(&attempt, anchor) <= facts.class_target {
                    attempt.challenge = challenge_v2(network_domain, pre_pow, timestamp, nonce, class_id, &bond);
                    won = Some(nonce);
                    break;
                }
            }
            let nonce = won.expect("the class target is winnable");
            let signature = libcrux_ml_dsa::ml_dsa_87::sign(
                &keys[bond_index as usize].signing_key,
                attempt_id_v2(&attempt).as_byte_slice(),
                PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
                [0x5Au8; 32],
            )
            .expect("sign")
            .as_ref()
            .to_vec();
            block.header.nonce = nonce;
            block.header.palw_commitment = PalwAttemptEnvelopeV2 { attempt, signature }.encode_wire();
            block.header.finalize();
            let inserted = block.to_immutable();
            let status = ctx.consensus.validate_and_insert_block(inserted).virtual_state_task.await;
            match status {
                Ok(_) => {}
                Err(e) => {
                    let text = format!("{e:?}");
                    assert!(
                        text.contains("budget") || text.contains("exposure"),
                        "a block may only be refused for the budget or the bond, got: {text}"
                    );
                    refused_over_budget += 1;
                    if refused_over_budget > 4 {
                        panic!("the chain refused five blocks running: {text}");
                    }
                    break;
                }
            }
            // `palw_producer_facts_v2` answers for the CANDIDATE, so the last read inside an epoch
            // already describes the next one — keep only the reads that still describe this epoch.
            let captured: Vec<_> = [("BASE-0", base_class_id, 0u32), ("QWEN36", qwen_class_id, 1u32)]
                .into_iter()
                .map(|(name, class_id, bond_index)| {
                    let f = ctx
                        .consensus
                        .palw_producer_facts_v2(class_id, Some(kaspa_consensus_core::config::premine::premine_outpoint(bond_index)))
                        .expect("answers");
                    let share = ctx
                        .consensus
                        .palw_v2_class_table()
                        .into_iter()
                        .find(|r| r.class_id == class_id)
                        .and_then(|r| r.share_permille)
                        .unwrap_or(0);
                    (name, share, f.epoch_produced_blocks, f.epoch_budget_blocks, f.pwu, f.class_target, f.epoch_index)
                })
                .collect();
            if captured.iter().all(|row| row.6 == epoch) {
                last_in_epoch = captured;
            }
        }
        // The closed epoch's own numbers, captured inside it.
        let rows = std::mem::take(&mut last_in_epoch);
        let realized: u64 = rows.iter().map(|r| r.2).sum();
        for (name, share, observed, budget, pwu, target, seen_epoch) in rows {
            let expected = (realized * share as u64 + 500) / 1000;
            let class_id = if name == "BASE-0" { base_class_id } else { qwen_class_id };
            let after = ctx.consensus.palw_producer_facts_v2(class_id, None).map(|f| f.class_target).unwrap_or(target);
            println!(
                "{:>5} {:>7} {:>5}‰ {:>9} {:>9} {:>7} {:>12} {:>16.9} {:>16.9}",
                seen_epoch,
                name,
                share,
                expected,
                observed,
                budget,
                pwu,
                (target as f64 + 1.0) / (u128::MAX as f64 + 1.0),
                (after as f64 + 1.0) / (u128::MAX as f64 + 1.0)
            );
        }
    }
    println!("blocks refused for budget/exposure during the run: {refused_over_budget}");
}

/// **ADR-0054 under real block validation: the entrant's share moves at the boundary.**
///
/// `the_real_qwen36_class_earns_share_by_producing` drives the transition directly, which is where
/// the rule lives; this drives the BLOCKS — every one of them templated, ticketed, signed and
/// accepted — so the share the chain reports afterwards is one that survived the whole pipeline,
/// and it is read back through the same `palw_v2_class_table` an operator sees.
///
/// One epoch is 1,000 DAA and one block is one DAA, so this is a thousand real blocks; ignored in
/// CI for that reason.
#[tokio::test]
#[ignore = "produces a full 1000-block epoch; run with --ignored --nocapture"]
async fn palw_rc_qwen36_earns_share_through_real_blocks() {
    use kaspa_consensus_core::api::ConsensusApi;
    use kaspa_consensus_core::palw_attempt_v2::{
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT, PALW_ATTEMPT_V2_VERSION, PalwAttemptEnvelopeV2, PalwAttemptUnsignedV2, attempt_id_v2,
        challenge_v2, class_ticket_v3, execution_anchor_v3, palw_network_domain_v2_for,
    };
    use kaspa_consensus_core::palw_backend::PalwExecutionBackendV1;
    use kaspa_consensus_core::palw_base0_profile::{PALW_RC_BASE0_CANONICAL, PALW_RC_BASE0_GEOMETRY, base0_profile_v1};
    use kaspa_consensus_core::palw_qwen36_profile::{QWEN36_35B_A3B, QWEN36_RC_CANONICAL, qwen36_profile_v1};
    use misaka_palw_base0::produce::{base0_execute_for_attempt_v1, base0_rc_job_anchor_v1, base0_rc_job_v1};
    use misaka_palw_base0::qwen36_backend::Qwen36Backend;

    let keys: Vec<_> = (0..kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1() as u32)
        .map(|i| libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xB0u8.wrapping_add(i as u8); 32]))
        .collect();
    let registry: Vec<_> = keys
        .iter()
        .enumerate()
        .map(|(i, kp)| kaspa_consensus_core::palw_fp_devnet_v3::PalwGenesisBondSpecV1 {
            bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(
                i as u32,
            )),
            pubkey: kp.verification_key.as_ref().to_vec(),
            operator_pubkey: vec![21u8, i as u8, 0, 0, 0, 0, 0, 0],
            payout_payload: kaspa_hashes::Hash64::from_u64_word(0x9A11 + i as u64),
        })
        .collect();
    let base_root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("derives");
    let qwen_artifact = misaka_palw_base0::qwen36::qwen36_dev_fixture(4, 8);
    let qwen_root = qwen_artifact.artifact_root();
    let params = kaspa_consensus_core::config::params::palw_rc_params_with_qwen36(base_root, qwen_root, registry)
        .expect("the two-class genesis assembles");
    let bundle = match &params.palw_consensus_mode {
        kaspa_consensus_core::palw_mode_v2::PalwConsensusMode::ConsensusV2(b) => b.clone(),
        _ => panic!("a ConsensusV2 network"),
    };
    assert!(bundle.state.class_growth_permille() > 0, "the RC bundle carries ADR-0054");
    let epoch_length = bundle.state.epoch_length();
    let base_class_id = bundle.base_class_id;
    let qwen_class_id = qwen36_profile_v1(QWEN36_35B_A3B).expect("projects").shape_profile_id();

    let config = ConfigBuilder::new(params)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            if !cfg!(feature = "evm") {
                p.evm_activation_daa_score = u64::MAX;
                // ADR-0089 Decision 9: the market's EVM face may not be armed on a lane this build
                // makes inert. Turning the lane off is one decision, not two —
                // `validate_palw_v2` refuses the pair and the node would panic at startup.
                p.palw_model_evm = None;
            }
        })
        .build();
    let network_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let ctx = TestContext::new(TestConsensus::new(&config));

    // One execution per class; the nonce moves the challenge, which is what the ticket reads.
    let base_profile = base0_profile_v1(PALW_RC_BASE0_GEOMETRY).expect("expressible");
    let base_artifact = misaka_palw_base0::rc::palw_rc_base0_artifact_v1().expect("derives");
    let seed = base0_rc_job_anchor_v1(
        network_domain,
        kaspa_hashes::Hash64::from_u64_word(1),
        base_class_id,
        &kaspa_consensus_core::config::premine::premine_outpoint(0),
        0,
    );
    let (base_job, base_prompt) = base0_rc_job_v1(
        &base_profile,
        seed,
        base_artifact.shape.vocab,
        PALW_RC_BASE0_CANONICAL.0,
        PALW_RC_BASE0_CANONICAL.1,
        kaspa_consensus_core::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
    );
    let base_run = base0_execute_for_attempt_v1(&base_artifact, &base_profile, &base_job, &base_prompt).expect("the floor runs");
    let backend = Qwen36Backend::new(
        std::sync::Arc::new(qwen_artifact),
        "Qwen3.6-dev-fixture",
        QWEN36_RC_CANONICAL,
        qwen_class_id,
        config.params.net.to_string().into_bytes(),
    );
    let qwen_anchor = base0_rc_job_anchor_v1(
        network_domain,
        kaspa_hashes::Hash64::from_u64_word(2),
        qwen_class_id,
        &kaspa_consensus_core::config::premine::premine_outpoint(1),
        0,
    );
    let (qwen_job, qwen_prompt) = backend.job_for_anchor(qwen_anchor).expect("the anchor implies a job");
    let qwen_run = backend.execute(&qwen_job, &qwen_prompt).expect("a real hybrid forward pass");
    let base_roots =
        (base_run.trace_root, base_run.output_root, base_run.execution_root, base_run.trace_manifest_root, base_run.trace_chunk_count);
    let qwen_roots =
        (qwen_run.trace_root, qwen_run.output_root, qwen_run.execution_root, qwen_run.trace_manifest_root, qwen_run.trace_chunk_count);

    let share_of = |ctx: &TestContext, class_id| {
        ctx.consensus.palw_v2_class_table().into_iter().find(|r| r.class_id == class_id).and_then(|r| r.share_permille)
    };
    let opening_share = share_of(&ctx, qwen_class_id).expect("the entrant is in the table");
    assert_eq!(
        opening_share,
        kaspa_consensus_core::config::params::PALW_RC_GENESIS_QWEN36_SHARE_PERMILLE,
        "the card funds the hybrid tier at genesis"
    );
    // The budget IS the share, so filling it is the only signal a class has — and the only way to
    // produce that signal is to make every block it is allowed to.
    let quota = ctx.consensus.palw_producer_facts_v2(qwen_class_id, None).expect("answers").epoch_budget_blocks;
    assert!(quota > 1, "a funded tier's allowance is more than one block");

    let mut qwen_made = 0u64;
    // One epoch, plus the block that crosses the boundary — the crossing is what pays.
    while ctx.consensus.get_virtual_daa_score() <= epoch_length {
        let want_qwen = qwen_made < quota;
        let (class_id, bond_index) = if want_qwen { (qwen_class_id, 1u32) } else { (base_class_id, 0u32) };
        let bond = kaspa_consensus_core::config::premine::premine_outpoint(bond_index);
        let facts = ctx.consensus.palw_producer_facts_v2(class_id, Some(bond)).expect("a V2 network answers");
        let run = if want_qwen { qwen_roots } else { base_roots };
        let mut block = ctx.build_block_template_keeping_time(0).block;
        let timestamp = block.header.timestamp;
        let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);
        let mut attempt = PalwAttemptUnsignedV2 {
            version: PALW_ATTEMPT_V2_VERSION,
            network_domain,
            challenge: kaspa_hashes::Hash64::default(),
            class_id,
            executor_bond: bond,
            executor_pubkey: keys[bond_index as usize].verification_key.as_ref().to_vec(),
            operator_id: facts.bond.as_ref().expect("a genesis bond").operator_id,
            artifact_root: facts.artifact_root,
            trace_root: run.0,
            output_root: run.1,
            execution_root: run.2,
            pwu: facts.pwu,
            trace_manifest_root: run.3,
            trace_chunk_count: run.4,
            trace_retention_daa: block.header.daa_score.saturating_add(facts.min_trace_retention_daa),
        };
        // The draw walks the bucket (ADR-0072): the ticket is the execution's under the anchor the
        // header derives, so a nonce inside a bucket moves nothing and the next bucket is the next draw.
        let mut won = None;
        for bucket in 0u64..4096 {
            let nonce = bucket << kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2;
            let anchor = execution_anchor_v3(network_domain, pre_pow, class_id, &bond, nonce);
            if class_ticket_v3(&attempt, anchor) <= facts.class_target {
                attempt.challenge = challenge_v2(network_domain, pre_pow, timestamp, nonce, class_id, &bond);
                won = Some(nonce);
                break;
            }
        }
        let signature = libcrux_ml_dsa::ml_dsa_87::sign(
            &keys[bond_index as usize].signing_key,
            attempt_id_v2(&attempt).as_byte_slice(),
            PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
            [0x5Au8; 32],
        )
        .expect("sign")
        .as_ref()
        .to_vec();
        block.header.nonce = won.expect("the class target is winnable");
        block.header.palw_commitment = PalwAttemptEnvelopeV2 { attempt, signature }.encode_wire();
        block.header.finalize();
        ctx.consensus.validate_and_insert_block(block.to_immutable()).virtual_state_task.await.expect("the chain accepts it");
        if want_qwen {
            qwen_made += 1;
        }
    }

    {
        // The closed epoch as the rule read it. Kept because the first version of this test passed
        // its own loop counter and failed its assertion: 200 blocks built, 15 accepted, and only
        // the store could say which of those two numbers the chain believed.
        let vp = ctx.consensus.virtual_processor();
        let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
        let counted = state.epoch_counter(&qwen_class_id).map(|c| (c.epoch_index, c.produced_blocks));
        eprintln!("at the crossing: counter {counted:?}");
        assert_eq!(counted, Some((0, quota)), "every block the loop built was accepted and counted");
    }
    let qwen_share = share_of(&ctx, qwen_class_id).expect("the entrant is in the table");
    let base_share = share_of(&ctx, base_class_id).expect("the floor is in the table");
    eprintln!(
        "after one epoch of real blocks: QWEN36 {qwen_share} permille (from {opening_share}, having made {qwen_made} of {quota}), BASE-0 {base_share} permille"
    );
    assert_eq!(qwen_made, quota, "it made every block its allowance permitted");
    let step = (u32::from(opening_share) * 250 / 1000).max(1) as u16;
    assert_eq!(qwen_share, opening_share + step, "it filled its budget, so it took a step from the floor");
    assert_eq!(qwen_share + base_share, 1000, "and the denominator is conserved through the block path");
    let facts = ctx.consensus.palw_producer_facts_v2(qwen_class_id, None).expect("answers");
    assert_eq!(facts.epoch_budget_blocks as u16, qwen_share, "the new epoch's budget follows the new share");
}

/// **ADR-0058 under real block validation: a class that never wins a chain slot still counts.**
///
/// The sibling test above hands the entrant every chain slot its budget allows. This one hands it
/// NONE — every Qwen block is built on a parent four chain blocks stale, so it always loses tip
/// selection by blue work and is only ever MERGED — which is testnet-11 as measured (12 of 12
/// real-inference blocks merged, zero on the selected chain, share frozen at genesis forever).
/// The assertions are the mechanism ADR-0058 restores: the epoch counter fills from the mergeset,
/// the budget cap holds against over-production (three extra blocks are skipped, not counted),
/// the share steps up at the boundary exactly as if the blocks had been chain blocks, and every
/// merged claim names its CARRYING block and escrows nothing.
///
/// One epoch is 1,000 DAA and one block is one DAA; ignored in CI for the same reason as above.
#[tokio::test]
#[ignore = "produces a full 1000-block epoch; run with --ignored --nocapture"]
async fn palw_rc_qwen36_counts_merged_work() {
    kaspa_core::log::try_init_logger("info");
    use kaspa_consensus_core::api::ConsensusApi;
    use kaspa_consensus_core::palw_attempt_v2::{
        PALW_ATTEMPT_V2_MLDSA87_CONTEXT, PALW_ATTEMPT_V2_VERSION, PalwAttemptEnvelopeV2, PalwAttemptUnsignedV2, attempt_id_v2,
        challenge_v2, class_ticket_v3, execution_anchor_v3, palw_network_domain_v2_for,
    };
    use kaspa_consensus_core::palw_backend::PalwExecutionBackendV1;
    use kaspa_consensus_core::palw_base0_profile::{PALW_RC_BASE0_CANONICAL, PALW_RC_BASE0_GEOMETRY, base0_profile_v1};
    use kaspa_consensus_core::palw_qwen36_profile::{QWEN36_35B_A3B, QWEN36_RC_CANONICAL, qwen36_profile_v1};
    use misaka_palw_base0::produce::{base0_execute_for_attempt_v1, base0_rc_job_anchor_v1, base0_rc_job_v1};
    use misaka_palw_base0::qwen36_backend::Qwen36Backend;
    use std::collections::HashSet;

    let keys: Vec<_> = (0..kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1() as u32)
        .map(|i| libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xB0u8.wrapping_add(i as u8); 32]))
        .collect();
    let registry: Vec<_> = keys
        .iter()
        .enumerate()
        .map(|(i, kp)| kaspa_consensus_core::palw_fp_devnet_v3::PalwGenesisBondSpecV1 {
            bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(kaspa_consensus_core::config::premine::premine_outpoint(
                i as u32,
            )),
            pubkey: kp.verification_key.as_ref().to_vec(),
            operator_pubkey: vec![21u8, i as u8, 0, 0, 0, 0, 0, 0],
            payout_payload: kaspa_hashes::Hash64::from_u64_word(0x9A11 + i as u64),
        })
        .collect();
    let base_root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("derives");
    let qwen_artifact = misaka_palw_base0::qwen36::qwen36_dev_fixture(4, 8);
    let qwen_root = qwen_artifact.artifact_root();
    let params = kaspa_consensus_core::config::params::palw_rc_params_with_qwen36(base_root, qwen_root, registry)
        .expect("the two-class genesis assembles");
    let bundle = match &params.palw_consensus_mode {
        kaspa_consensus_core::palw_mode_v2::PalwConsensusMode::ConsensusV2(b) => b.clone(),
        _ => panic!("a ConsensusV2 network"),
    };
    let epoch_length = bundle.state.epoch_length();
    let base_class_id = bundle.base_class_id;
    let qwen_class_id = qwen36_profile_v1(QWEN36_35B_A3B).expect("projects").shape_profile_id();

    let config = ConfigBuilder::new(params)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            if !cfg!(feature = "evm") {
                p.evm_activation_daa_score = u64::MAX;
                // ADR-0089 Decision 9: the market's EVM face may not be armed on a lane this build
                // makes inert. Turning the lane off is one decision, not two —
                // `validate_palw_v2` refuses the pair and the node would panic at startup.
                p.palw_model_evm = None;
            }
        })
        .build();
    let network_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let ctx = TestContext::new(TestConsensus::new(&config));

    let base_profile = base0_profile_v1(PALW_RC_BASE0_GEOMETRY).expect("expressible");
    let base_artifact = misaka_palw_base0::rc::palw_rc_base0_artifact_v1().expect("derives");
    let seed = base0_rc_job_anchor_v1(
        network_domain,
        kaspa_hashes::Hash64::from_u64_word(1),
        base_class_id,
        &kaspa_consensus_core::config::premine::premine_outpoint(0),
        0,
    );
    let (base_job, base_prompt) = base0_rc_job_v1(
        &base_profile,
        seed,
        base_artifact.shape.vocab,
        PALW_RC_BASE0_CANONICAL.0,
        PALW_RC_BASE0_CANONICAL.1,
        kaspa_consensus_core::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
    );
    let base_run = base0_execute_for_attempt_v1(&base_artifact, &base_profile, &base_job, &base_prompt).expect("the floor runs");
    let backend = Qwen36Backend::new(
        std::sync::Arc::new(qwen_artifact),
        "Qwen3.6-dev-fixture",
        QWEN36_RC_CANONICAL,
        qwen_class_id,
        config.params.net.to_string().into_bytes(),
    );
    let qwen_anchor = base0_rc_job_anchor_v1(
        network_domain,
        kaspa_hashes::Hash64::from_u64_word(2),
        qwen_class_id,
        &kaspa_consensus_core::config::premine::premine_outpoint(1),
        0,
    );
    let (qwen_job, qwen_prompt) = backend.job_for_anchor(qwen_anchor).expect("the anchor implies a job");
    let qwen_run = backend.execute(&qwen_job, &qwen_prompt).expect("a real hybrid forward pass");
    let base_roots =
        (base_run.trace_root, base_run.output_root, base_run.execution_root, base_run.trace_manifest_root, base_run.trace_chunk_count);
    let qwen_roots =
        (qwen_run.trace_root, qwen_run.output_root, qwen_run.execution_root, qwen_run.trace_manifest_root, qwen_run.trace_chunk_count);

    let share_of = |ctx: &TestContext, class_id| {
        ctx.consensus.palw_v2_class_table().into_iter().find(|r| r.class_id == class_id).and_then(|r| r.share_permille)
    };
    let opening_share = share_of(&ctx, qwen_class_id).expect("the entrant is in the table");
    let quota = ctx.consensus.palw_producer_facts_v2(qwen_class_id, None).expect("answers").epoch_budget_blocks;
    assert!(quota > 1, "a funded tier's allowance is more than one block");

    // How stale a Qwen block's parent is, in chain blocks. Four floor blocks of blue work is the
    // margin the real network showed (2M–14M ≈ 2–10 blocks), and it guarantees the side block
    // loses tip selection here for the same reason it loses it there.
    const STALE_DEPTH: usize = 4;
    // Three blocks past the budget: the cap must SKIP them (deterministically, every node),
    // not count them — over-production is the attack the budget exists for.
    let overproduce = quota + 3;

    let mut chain_tips: Vec<BlockHash> = vec![config.genesis.hash];
    let mut qwen_blocks: HashSet<BlockHash> = HashSet::new();
    let mut qwen_made = 0u64;
    let sign = |keys: &[libcrux_ml_dsa::ml_dsa_87::MLDSA87KeyPair], bond_index: u32, attempt: &PalwAttemptUnsignedV2| {
        libcrux_ml_dsa::ml_dsa_87::sign(
            &keys[bond_index as usize].signing_key,
            attempt_id_v2(attempt).as_byte_slice(),
            PALW_ATTEMPT_V2_MLDSA87_CONTEXT,
            [0x5Au8; 32],
        )
        .expect("sign")
        .as_ref()
        .to_vec()
    };

    while ctx.consensus.get_virtual_daa_score() <= epoch_length {
        // A Qwen SIDE block first, whenever allowance (plus the deliberate excess) remains and
        // the chain is deep enough to have a stale parent for it.
        if qwen_made < overproduce && chain_tips.len() > STALE_DEPTH {
            let stale = chain_tips[chain_tips.len() - 1 - STALE_DEPTH];
            let bond = kaspa_consensus_core::config::premine::premine_outpoint(1);
            let facts = ctx.consensus.palw_producer_facts_v2(qwen_class_id, Some(bond)).expect("a V2 network answers");
            // NOT the UTXO-valid template builder: its pov sink search runs the deep-reorg
            // gate, which correctly refuses to re-anchor virtual on a stale parent (and then
            // walks past genesis into ORIGIN). A side blue needs no UTXO validity — only a
            // chain-block candidate is ever UTXO-validated, and this block must never be one.
            let mut block = ctx.consensus.build_block_with_parents_and_transactions(blockhash::NONE, vec![stale], vec![]);
            let timestamp = block.header.timestamp;
            let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);
            let mut attempt = PalwAttemptUnsignedV2 {
                version: PALW_ATTEMPT_V2_VERSION,
                network_domain,
                challenge: kaspa_hashes::Hash64::default(),
                class_id: qwen_class_id,
                executor_bond: bond,
                executor_pubkey: keys[1].verification_key.as_ref().to_vec(),
                operator_id: facts.bond.as_ref().expect("a genesis bond").operator_id,
                artifact_root: facts.artifact_root,
                trace_root: qwen_roots.0,
                output_root: qwen_roots.1,
                execution_root: qwen_roots.2,
                pwu: facts.pwu,
                trace_manifest_root: qwen_roots.3,
                trace_chunk_count: qwen_roots.4,
                trace_retention_daa: block.header.daa_score.saturating_add(facts.min_trace_retention_daa),
            };
            // The draw walks the bucket (ADR-0072): the ticket is the execution's under the anchor the
            // header derives, so a nonce inside a bucket moves nothing and the next bucket is the next draw.
            let mut won = None;
            for bucket in 0u64..4096 {
                let nonce = bucket << kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2;
                let anchor = execution_anchor_v3(network_domain, pre_pow, qwen_class_id, &bond, nonce);
                if class_ticket_v3(&attempt, anchor) <= facts.class_target {
                    attempt.challenge = challenge_v2(network_domain, pre_pow, timestamp, nonce, qwen_class_id, &bond);
                    won = Some(nonce);
                    break;
                }
            }
            let signature = sign(&keys, 1, &attempt);
            block.header.nonce = won.expect("the class target is winnable");
            block.header.palw_commitment = PalwAttemptEnvelopeV2 { attempt, signature }.encode_wire();
            block.header.finalize();
            let qwen_hash = block.header.hash;
            ctx.consensus.validate_and_insert_block(block.to_immutable()).virtual_state_task.await.expect("the DAG accepts it");
            qwen_blocks.insert(qwen_hash);
            qwen_made += 1;
        }

        // Then the floor's chain block, which merges whatever the anticone holds.
        {
            let bond = kaspa_consensus_core::config::premine::premine_outpoint(0);
            let facts = ctx.consensus.palw_producer_facts_v2(base_class_id, Some(bond)).expect("a V2 network answers");
            let mut block = ctx.build_block_template_keeping_time(0).block;
            let timestamp = block.header.timestamp;
            let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);
            let mut attempt = PalwAttemptUnsignedV2 {
                version: PALW_ATTEMPT_V2_VERSION,
                network_domain,
                challenge: kaspa_hashes::Hash64::default(),
                class_id: base_class_id,
                executor_bond: bond,
                executor_pubkey: keys[0].verification_key.as_ref().to_vec(),
                operator_id: facts.bond.as_ref().expect("a genesis bond").operator_id,
                artifact_root: facts.artifact_root,
                trace_root: base_roots.0,
                output_root: base_roots.1,
                execution_root: base_roots.2,
                pwu: facts.pwu,
                trace_manifest_root: base_roots.3,
                trace_chunk_count: base_roots.4,
                trace_retention_daa: block.header.daa_score.saturating_add(facts.min_trace_retention_daa),
            };
            // The draw walks the bucket (ADR-0072): the ticket is the execution's under the anchor the
            // header derives, so a nonce inside a bucket moves nothing and the next bucket is the next draw.
            let mut won = None;
            for bucket in 0u64..4096 {
                let nonce = bucket << kaspa_consensus_core::palw_attempt_v2::PALW_TICKET_NONCE_BUCKET_LOG2;
                let anchor = execution_anchor_v3(network_domain, pre_pow, base_class_id, &bond, nonce);
                if class_ticket_v3(&attempt, anchor) <= facts.class_target {
                    attempt.challenge = challenge_v2(network_domain, pre_pow, timestamp, nonce, base_class_id, &bond);
                    won = Some(nonce);
                    break;
                }
            }
            let signature = sign(&keys, 0, &attempt);
            block.header.nonce = won.expect("the class target is winnable");
            block.header.palw_commitment = PalwAttemptEnvelopeV2 { attempt, signature }.encode_wire();
            block.header.finalize();
            ctx.consensus.validate_and_insert_block(block.to_immutable()).virtual_state_task.await.expect("the chain accepts it");
            chain_tips.push(ctx.consensus.get_sink());
        }
    }

    // 1. Not one Qwen block won a chain slot — the starvation is real, not assumed.
    let chain: HashSet<BlockHash> = ctx
        .consensus
        .get_virtual_chain_from_block(config.genesis.hash, None)
        .expect("the chain walks")
        .added
        .iter()
        .copied()
        .collect();
    assert!(qwen_blocks.iter().all(|q| !chain.contains(q)), "every Qwen block stayed off the selected chain");

    // 1b. And not because they were quietly blue: at ghostdag_k = 1 a four-deep side block's
    // anticone makes it a RED by construction, so this test only proves ADR-0058 if the works
    // it counted rode the red half of the mergeset — which is where every slower-than-the-floor
    // class lives at the frozen cadence.
    {
        use crate::model::stores::ghostdag::GhostdagStoreReader;
        let vp_diag = ctx.consensus.virtual_processor();
        let mut in_blues = 0usize;
        let mut in_reds = 0usize;
        for cb in &chain {
            if let Ok(gd) = vp_diag.ghostdag_store.get_data(*cb) {
                in_blues += gd.mergeset_blues.iter().filter(|b| qwen_blocks.contains(*b)).count();
                in_reds += gd.mergeset_reds.iter().filter(|b| qwen_blocks.contains(*b)).count();
            }
        }
        eprintln!("side blocks: {} total, {in_blues} merged as blues, {in_reds} as reds", qwen_blocks.len());
        assert_eq!(in_blues + in_reds, qwen_blocks.len(), "every side block was merged exactly once");
        assert!(in_reds > 0, "at k = 1 the side blocks land in the red set — the set the old rule never read");
    }

    // 2. The counter filled from the MERGESET, and the budget cap held against the excess.
    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let counted = state.epoch_counter(&qwen_class_id).map(|c| (c.epoch_index, c.produced_blocks));
    let base_counted = state.epoch_counter(&base_class_id).map(|c| (c.epoch_index, c.produced_blocks));
    let qwen_claims_total = state.claims_iter().filter(|(_, c)| c.class_id == qwen_class_id).count();
    let all_claims_total = state.claims_iter().count();
    eprintln!(
        "at the crossing: qwen counter {counted:?}, base counter {base_counted:?}, qwen claims in state {qwen_claims_total}, all claims {all_claims_total}, side blocks built {qwen_made} (budget {quota})"
    );
    assert_eq!(counted, Some((0, quota)), "merged production filled the budget exactly; the three excess blocks were skipped");

    // 3. Every merged claim names its CARRYING block and escrows nothing (ADR-0058 D4/D5).
    let mut merged_claims = 0usize;
    for (_, claim) in state.claims_iter().filter(|(_, c)| c.class_id == qwen_class_id) {
        assert!(qwen_blocks.contains(&claim.accepted_block), "a merged claim names the blue that carried it");
        assert_eq!(claim.escrowed_reward, 0, "a merged claim escrows nothing — its blue was paid by the coinbase in full");
        merged_claims += 1;
    }
    assert!(merged_claims > 0, "the tip state still holds merged claims");

    // 4. The boundary paid: the share stepped up off merged production alone.
    let qwen_share = share_of(&ctx, qwen_class_id).expect("the entrant is in the table");
    let base_share = share_of(&ctx, base_class_id).expect("the floor is in the table");
    eprintln!(
        "after one epoch of MERGED-ONLY production: QWEN36 {qwen_share} permille (from {opening_share}), BASE-0 {base_share} permille"
    );
    let step = (u32::from(opening_share) * 250 / 1000).max(1) as u16;
    assert_eq!(qwen_share, opening_share + step, "it filled its budget from the anticone, so it took a step from the floor");
    assert_eq!(qwen_share + base_share, 1000, "and the denominator is conserved");
}

/// **A caller's prompt, run on a registered class, opens a claim at the SHIPPED quantum.**
///
/// This test used to assert the opposite — that no registered class could earn a single draw —
/// because the shipped quantum was 1,000 and the widest job a class could hold (BASE-0's n_ctx 12
/// → 705 CU) floored to zero. Lowering the quantum to 100, with `pwu_per_quantum` lowered in step
/// so a given CU total keeps the exact chain weight it had, is what changed: the floor's own
/// maximum job now earns real quanta, and its commitment is taken by the same extraction the
/// virtual processor runs on every accepted block — the shipped parameters, not a rebuilt set.
///
/// The comment above `QUANTUM_CU` records the arithmetic; this is its consequence on the chain
/// path: a person's prompt, executed on the class the chain registered, becomes a claim the chain
/// opens.
#[tokio::test]
async fn a_callers_prompt_on_a_registered_class_opens_a_claim_at_the_shipped_quantum() {
    use kaspa_consensus_core::palw_backend::PalwExecutionBackendV1;
    use kaspa_consensus_core::palw_fp_execution_v3::{PalwFpClassFactsV3, palw_fp_commitment_v3};
    use kaspa_consensus_core::palw_freeprompt_v3::{
        PALW_FP_PRIVACY_PUBLIC_DA, PALW_FP_V3_MLDSA87_COMMITMENT_CONTEXT, PALW_FP_V3_VERSION, PalwFpCommitmentTxPayloadV3,
        PalwFreePromptJobV3, fp_claim_id_v3,
    };
    use kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2 as Obj;
    use kaspa_consensus_core::subnets::SUBNETWORK_ID_PALW_FP_COMMITMENT;
    use kaspa_consensus_core::tx::{Transaction, TransactionId, TransactionOutpoint};
    use kaspa_hashes::Hash64;
    use misaka_palw_base0::backend::Base0Backend;
    use misaka_palw_base0::classes::{canonical_class_by_model_id_v1, resolve_class_v1};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);

    // The floor, resolved the way a node resolves it: from nothing but its registered root.
    let court = bundle.court;
    let entry = canonical_class_by_model_id_v1(&court, "PALW-BASE-0/rc").expect("the floor is a canonical class");
    let root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("the floor's pinned root");
    let backend = Base0Backend::new(resolve_class_v1(&court, entry.class_id(), root, &[]).expect("the floor resolves"));

    // **The caller's tokens.** Not derived from an anchor — that is the attempt lane's rule, and
    // the whole point of this lane is that a person chooses the input.
    // The largest job this class can hold: one prefill token and the rest decode, which is what
    // maximises `cu` under these weights. It is still short of a quantum, and the assertions below
    // are about that rather than about this particular prompt.
    let ctx_max = backend.profile().n_ctx as usize;
    let prompt: Vec<usize> = vec![11];
    let decode = (ctx_max - prompt.len()) as u32;
    let bond = TransactionOutpoint::new(TransactionId::from_u64_word(0xB0), 0);
    let keypair = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_keypair();
    let job = PalwFreePromptJobV3 {
        version: PALW_FP_V3_VERSION,
        network_domain: kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
            MAINNET_PARAMS.net.to_string().as_bytes(),
            Some(MAINNET_PARAMS.genesis.hash),
        ),
        class_id: entry.class_id(),
        executor_bond: bond,
        executor_pubkey: crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey(),
        operator_id: Hash64::from_u64_word(0x0B),
        anchor_block: MAINNET_PARAMS.genesis.hash,
        anchor_daa: 1,
        job_nonce: [0x5A; 32],
        tokenizer_id: Hash64::default(),
        prompt_token_ids_hash: kaspa_consensus_core::palw_v2::prompt_token_ids_hash_v2(
            &prompt.iter().map(|t| *t as u32).collect::<Vec<_>>(),
        ),
        prompt_tokens: prompt.len() as u32,
        decode_token_limit: decode,
        max_context_tokens: backend.profile().n_ctx,
        privacy_mode: PALW_FP_PRIVACY_PUBLIC_DA,
        prompt_mode: kaspa_consensus_core::palw_freeprompt_v3::PALW_FP_PROMPT_MODE_USER,
        sampling_seed: kaspa_consensus_core::palw_decode_select_v2::PALW_DECODE_SEED_GREEDY,
        temperature_q: kaspa_consensus_core::palw_decode_select_v2::PALW_DECODE_TEMPERATURE_GREEDY,
        decode: None,
        tail: None,
    };

    let run = backend.execute_free_prompt(&job, &prompt).expect("the floor runs a caller's prompt");
    let class = PalwFpClassFactsV3 {
        model_profile_id: Hash64::default(),
        runtime_manifest_hash: Hash64::default(),
        runtime_class_id: Hash64::default(),
        shape_profile_id: backend.profile().shape_profile_id(),
        cu_ruleset_id: Hash64::default(),
    };
    let commitment =
        palw_fp_commitment_v3(&job, &class, &run, b"misaka-palw-rc", 4_096).expect("a finished run assembles a commitment");

    // Signed over the claim id, which is what the extraction verifies — the bond answering for the
    // work, not a fixture asserting that somebody would have.
    let claim_id_signed = fp_claim_id_v3(&commitment);
    let signature = libcrux_ml_dsa::ml_dsa_87::sign(
        &keypair.signing_key,
        claim_id_signed.as_byte_slice(),
        PALW_FP_V3_MLDSA87_COMMITMENT_CONTEXT,
        [0u8; 32],
    )
    .expect("the harness signs")
    .as_ref()
    .to_vec();

    let committed_leaves = commitment.work_leaves;
    let payload = borsh::to_vec(&PalwFpCommitmentTxPayloadV3 {
        version: PALW_FP_V3_VERSION,
        commitment,
        prompt_token_ids: prompt.iter().map(|t| *t as u32).collect(),
        signature,
    })
    .expect("the commitment payload serializes");
    let tx = Transaction::new(0, vec![], vec![], 0, SUBNETWORK_ID_PALW_FP_COMMITMENT.clone(), 0, payload);

    // **The shipped extraction, on the shipped bundle.** No parameters rebuilt: this is the
    // function the virtual processor calls, with the quantum the network actually ships.
    let extraction = kaspa_consensus_core::palw_fp_objects_v3::palw_fp_objects_from_accepted_txs_v3(
        std::slice::from_ref(&tx),
        job.network_domain,
        &bundle.freeprompt,
        kaspa_consensus_core::BlockHash::default(),
        kaspa_consensus_core::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
        |pubkey: &[u8], message: &[u8], context: &[u8], signature: &[u8]| {
            kaspa_txscript::verify_mldsa87_with_context(pubkey, message, context, signature).unwrap_or(false)
        },
    );

    // The floor's widest job clears the quantum now, so its commitment opens a claim.
    // The floor's quantum is an eighth of its canonical job (ADR-0074 Decision 5); this job of a
    // few tokens must earn at least one, or the lane is unreachable on the class it ships with.
    let (canonical_ctx, _) = backend.job_for_anchor(Hash64::from_u64_word(0xF1)).expect("the floor implies a canonical job");
    let canonical_leaves = kaspa_consensus_core::palw_step::step_leaf_count(backend.profile(), &canonical_ctx).expect("counts");
    let quantum = kaspa_consensus_core::palw_freeprompt_v3::fp_class_quantum_leaves_v1(
        canonical_leaves,
        bundle.freeprompt.quanta_per_canonical_job(),
    );
    assert!(
        committed_leaves >= quantum,
        "this job ({committed_leaves} leaves) must reach the floor's {quantum}-leaf quantum (canonical job {canonical_leaves} leaves)"
    );
    assert!(extraction.skipped.is_empty(), "a job that earns a draw is not skipped: {:?}", extraction.skipped);
    let [carried] = &extraction.objects[..] else { panic!("exactly one object rides a commitment") };
    let Obj::FreePromptCommitted { claim, class_id, .. } = &carried.object else {
        panic!("and it commits a free-prompt claim: {:?}", carried.object)
    };
    assert_eq!(*claim, claim_id_signed, "the claim the chain opened is the one the executor signed");
    assert_eq!(*class_id, entry.class_id(), "under the class that ran it");
}

/// **A receipt block carrying a real certified claim passes the header admission gate.**
///
/// The end-to-end admission — a real execution's claim, certified, its quantum spend accepted by
/// `check_palw_receipt_spend_admission_full_v3` — is proven in
/// `misaka_palw_base0::backend::end_to_end_tests`. This adds the piece that lives in the pipeline:
/// the receipt carriage a producer builds, on a real header, gets past the HEADER stage's
/// signature gate — the check `validate_and_insert_block` runs before a block is a block at all.
///
/// It stops there deliberately. Whether the block then becomes the SINK is a stateful question the
/// virtual processor answers on the chain candidate, and reaching it honestly needs the claim
/// certified ON the mined chain — windows of DAA (bind 600, challenge 1,200) the frozen cadence
/// makes into hours and this harness cannot cheaply advance without tripping the epoch-budget and
/// DAA-progress rules that govern a real chain. The admission logic is proven where it is pure;
/// this proves the header gate accepts the producer's carriage, and names what it does not cover.
#[tokio::test]
async fn a_receipt_carriage_passes_the_header_signature_gate() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::tx::{TransactionId, TransactionOutpoint};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();

    // A claim id and bond a producer would name — the harness bond is genesis row 0, whose REAL
    // key the signature verifies against. The claim need not be on chain for the HEADER gate: that
    // gate checks the signature over the header position, and the stateful "is this claim Final"
    // question is asked later, on the candidate (measured in the receipt-gate test above).
    let bond = TransactionOutpoint::new(TransactionId::from_u64_word(0xB0), 0);
    let claim_id = kaspa_hashes::Hash64::from_u64_word(0xFEED);
    let beacon_block = kaspa_hashes::Hash64::from_u64_word(0xBEAC);

    let honest = ctx.build_block_template(9, ctx.simulated_time + 1);

    // Junk signature — the stateless gate must refuse it, naming the signature.
    let mut forged = honest.block.clone();
    forged.header.pow_algo_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
    forged.header.palw_commitment =
        ctx.consensus.palw_v3_test_receipt_carriage_for(&forged.header, false, claim_id, 0, bond, beacon_block);
    forged.header.finalize();
    match ctx.consensus.validate_and_insert_block(forged.to_immutable()).virtual_state_task.await {
        Err(kaspa_consensus_core::errors::block::RuleError::BadPalwCarriageAdmission { algo_id: 7, reason }) => {
            assert!(reason.to_lowercase().contains("signature"), "the refusal names the signature: {reason}");
        }
        other => panic!("a junk-signature receipt carriage must be refused at the header stage, got {other:?}"),
    }

    // Real signature over the same spend — the producer's carriage — must get PAST the signature
    // gate. It is refused later on the stateful facts (no such Final claim on this chain), which is
    // a different complaint and deliberately not asserted here.
    let mut signed = honest.block.clone();
    signed.header.pow_algo_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
    signed.header.palw_commitment =
        ctx.consensus.palw_v3_test_receipt_carriage_for(&signed.header, true, claim_id, 0, bond, beacon_block);
    signed.header.finalize();
    if let Err(kaspa_consensus_core::errors::block::RuleError::BadPalwCarriageAdmission { algo_id: 7, reason }) =
        ctx.consensus.validate_and_insert_block(signed.to_immutable()).virtual_state_task.await
    {
        assert!(
            !reason.to_lowercase().contains("signature"),
            "a correctly signed spend must not be refused for its signature: {reason}"
        );
    }
}

/// **ADR-0075 Decision 9 on a mainnet-based ruleset: a block grades two family drills and drops
/// the third, and a class binds to what the block recorded.** The evidence is real — the floor's
/// attempt and free-prompt drills and the A16 fixture's attempt drill — graded by the acceptance
/// walk on `MAINNET_PARAMS` with the V2 bundle, which is what a carded mainnet is.
#[tokio::test]
async fn palw_v2_a_block_grades_at_most_two_family_drills_and_a_class_binds_to_them() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_CERTIFICATION_MAX_PER_BLOCK, PalwCertificationEvidenceV1, PalwCertifiedLaneV1, PalwClassStatusV2, PalwConsensusObjectV2,
    };
    use misaka_palw_base0::e2e_drill::{PalwRcFamilyV1, rc_attempt_evidence_v1, rc_free_prompt_evidence_v1};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 5,
        subsidy: 0,
    };

    let floor_attempt = rc_attempt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its attempt lane");
    let floor_fp = rc_free_prompt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its free-prompt lane");
    let a16_attempt = rc_attempt_evidence_v1(PalwRcFamilyV1::Qwen25A16).expect("the A16 fixture drills its attempt lane");
    let objects = vec![
        PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(floor_attempt)) },
        PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::FreePrompt(floor_fp)) },
        PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(a16_attempt.clone())) },
    ];
    let (accepted, folded) =
        vp.palw_v2_accepted_objects_and_state_for_tests(&state, &bundle.state, &point, objects, ctx.consensus.get_sink());
    assert_eq!(accepted.len(), PALW_CERTIFICATION_MAX_PER_BLOCK, "two drills are graded, the third is dropped and the block stands");
    assert_eq!(folded.chain_certified_families(PalwCertifiedLaneV1::Attempt).len(), 1, "the floor's attempt family");
    assert_eq!(folded.chain_certified_families(PalwCertifiedLaneV1::FreePrompt).len(), 1, "the floor's free-prompt family");

    // The next block carries what the cap dropped.
    let a16_object = PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(a16_attempt)) };
    let point2 = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: kaspa_hashes::Hash64::from_u64_word(0xB102),
        daa_score: point.daa_score + 1,
        blue_score: point.blue_score + 8,
        subsidy: 0,
    };
    let (accepted, folded) =
        vp.palw_v2_accepted_objects_and_state_for_tests(&folded, &bundle.state, &point2, vec![a16_object], point2.block);
    assert_eq!(accepted.len(), 1);
    assert_eq!(folded.chain_certified_families(PalwCertifiedLaneV1::Attempt).len(), 2, "the A16 family joins in the next block");

    // A class the recorded free-prompt family covers binds to it: the base class, whose profile
    // is the floor's, if it is Active on this chain.
    let base = bundle.base_class_id;
    if matches!(folded.class(&base).map(|c| &c.status), Some(PalwClassStatusV2::Active)) {
        let profile = kaspa_consensus_core::palw_base0_profile::base0_profile_v1(
            kaspa_consensus_core::palw_base0_profile::PALW_RC_BASE0_GEOMETRY,
        )
        .expect("the floor's profile");
        if profile.shape_profile_id() == base {
            let bind = PalwConsensusObjectV2::ClassLaneCertified {
                class_id: base,
                lane: PalwCertifiedLaneV1::FreePrompt,
                profile: Box::new(profile),
            };
            let point3 = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
                block: kaspa_hashes::Hash64::from_u64_word(0xB103),
                daa_score: point2.daa_score + 1,
                blue_score: point2.blue_score + 8,
                subsidy: 0,
            };
            let (accepted, folded) =
                vp.palw_v2_accepted_objects_and_state_for_tests(&folded, &bundle.state, &point3, vec![bind], point3.block);
            assert_eq!(accepted.len(), 1, "the binding is accepted");
            assert!(folded.fp_lane_certification(&base).is_some(), "and recorded");
        }
    }
}

/// **ADR-0078 Decision 4, on the shipped acceptance path.** A derivation of a free-prompt claim
/// rides when it is signed by the claim's executor over its own message under its own context,
/// on this chain; it is dropped — and the block stands — when the signature is not the declared
/// key's, when it names another network's domain, when the declared key is a real key that is
/// not the claim's bond key, and when it repeats a `(claim, transformer)` the chain already holds.
/// The claim it derives from is a REAL floor execution committed through the shipped extractor.
#[tokio::test]
async fn palw_v2_a_derivation_rides_signed_by_the_claims_executor_and_is_dropped_otherwise() {
    use kaspa_consensus_core::palw_backend::PalwExecutionBackendV1;
    use kaspa_consensus_core::palw_derived_v1::{
        PALW_DERIVED_V1_MLDSA87_CONTEXT, PALW_DERIVED_V1_VERSION, PalwDerivedArtifactV1, kind, palw_derived_message_v1,
    };
    use kaspa_consensus_core::palw_fp_execution_v3::{PalwFpClassFactsV3, palw_fp_commitment_v3};
    use kaspa_consensus_core::palw_freeprompt_v3::{
        PALW_FP_PRIVACY_PUBLIC_DA, PALW_FP_V3_MLDSA87_COMMITMENT_CONTEXT, PALW_FP_V3_VERSION, PalwFpCommitmentTxPayloadV3,
        PalwFreePromptJobV3, fp_claim_id_v3,
    };
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2 as Obj;
    use kaspa_consensus_core::subnets::SUBNETWORK_ID_PALW_FP_COMMITMENT;
    use kaspa_consensus_core::tx::{Transaction, TransactionId, TransactionOutpoint};
    use kaspa_hashes::Hash64;
    use misaka_palw_base0::backend::Base0Backend;
    use misaka_palw_base0::classes::{canonical_class_by_model_id_v1, resolve_class_v1};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let court = bundle.court;
    let entry = canonical_class_by_model_id_v1(&court, "PALW-BASE-0/rc").expect("the floor is a canonical class");
    // The fixture bundle registers the floor under its OWN base class id (`palw_v2_test_bundle`
    // names `Hash64::from_u64_word(1)`, the id the harness's attempt carriage also names), so the
    // claim commits under that id; the floor's backend runs the job whatever id the job names.
    let floor_class = bundle.base_class_id;
    // The floor's free-prompt lane certified at genesis, so the commitment below opens a claim.
    let params = bundle.state.clone().with_fp_certified_classes([floor_class].into_iter().collect());
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        MAINNET_PARAMS.net.to_string().as_bytes(),
        Some(MAINNET_PARAMS.genesis.hash),
    );

    // A real floor execution of a caller's prompt, committed by the harness bond (registry row 0,
    // whose REAL key the chain registered), extracted by the shipped extractor.
    let root = misaka_palw_base0::rc::palw_rc_base0_artifact_root_v1().expect("the floor's pinned root");
    let backend = Base0Backend::new(resolve_class_v1(&court, entry.class_id(), root, &[]).expect("the floor resolves"));
    let prompt: Vec<usize> = vec![11];
    let decode = (backend.profile().n_ctx as usize - prompt.len()) as u32;
    let bond = TransactionOutpoint::new(TransactionId::from_u64_word(0xB0), 0);
    let keypair = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_keypair();
    let executor_pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey();
    let job = PalwFreePromptJobV3 {
        version: PALW_FP_V3_VERSION,
        network_domain,
        class_id: floor_class,
        executor_bond: bond,
        executor_pubkey: executor_pubkey.clone(),
        operator_id: Hash64::from_u64_word(0x0B),
        anchor_block: MAINNET_PARAMS.genesis.hash,
        anchor_daa: 1,
        job_nonce: [0x5B; 32],
        tokenizer_id: Hash64::default(),
        prompt_token_ids_hash: kaspa_consensus_core::palw_v2::prompt_token_ids_hash_v2(
            &prompt.iter().map(|t| *t as u32).collect::<Vec<_>>(),
        ),
        prompt_tokens: prompt.len() as u32,
        decode_token_limit: decode,
        max_context_tokens: backend.profile().n_ctx,
        privacy_mode: PALW_FP_PRIVACY_PUBLIC_DA,
        prompt_mode: kaspa_consensus_core::palw_freeprompt_v3::PALW_FP_PROMPT_MODE_USER,
        sampling_seed: kaspa_consensus_core::palw_decode_select_v2::PALW_DECODE_SEED_GREEDY,
        temperature_q: kaspa_consensus_core::palw_decode_select_v2::PALW_DECODE_TEMPERATURE_GREEDY,
        decode: None,
        tail: None,
    };
    let run = backend.execute_free_prompt(&job, &prompt).expect("the floor runs a caller's prompt");
    let class = PalwFpClassFactsV3 {
        model_profile_id: Hash64::default(),
        runtime_manifest_hash: Hash64::default(),
        runtime_class_id: Hash64::default(),
        shape_profile_id: backend.profile().shape_profile_id(),
        cu_ruleset_id: Hash64::default(),
    };
    let commitment =
        palw_fp_commitment_v3(&job, &class, &run, b"misaka-palw-rc", 4_096).expect("a finished run assembles a commitment");
    let claim_id = fp_claim_id_v3(&commitment);
    let output_root = commitment.output_root;
    let sign = |message: &[u8], context: &[u8]| {
        libcrux_ml_dsa::ml_dsa_87::sign(&keypair.signing_key, message, context, [0u8; 32]).expect("sign").as_ref().to_vec()
    };
    let payload = borsh::to_vec(&PalwFpCommitmentTxPayloadV3 {
        version: PALW_FP_V3_VERSION,
        commitment,
        prompt_token_ids: prompt.iter().map(|t| *t as u32).collect(),
        signature: sign(claim_id.as_byte_slice(), PALW_FP_V3_MLDSA87_COMMITMENT_CONTEXT),
    })
    .unwrap();
    let tx = Transaction::new(0, vec![], vec![], 0, SUBNETWORK_ID_PALW_FP_COMMITMENT.clone(), 0, payload);
    let extraction = kaspa_consensus_core::palw_fp_objects_v3::palw_fp_objects_from_accepted_txs_v3(
        std::slice::from_ref(&tx),
        network_domain,
        &bundle.freeprompt,
        kaspa_consensus_core::BlockHash::default(),
        kaspa_consensus_core::palw_prompt_ids_v1::PalwPromptIdsFormV1::Flat,
        |pubkey: &[u8], message: &[u8], context: &[u8], signature: &[u8]| {
            kaspa_txscript::verify_mldsa87_with_context(pubkey, message, context, signature).unwrap_or(false)
        },
    );
    assert!(extraction.skipped.is_empty(), "{:?}", extraction.skipped);
    let committed = extraction.objects[0].object.clone();
    assert!(matches!(committed, Obj::FreePromptCommitted { .. }));

    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 5,
        subsidy: 0,
    };
    // The transition's own answer first, so a refusal is named rather than counted.
    kaspa_consensus_core::palw_state_v2::apply_palw_transition_v2(&state, &params, &point, std::slice::from_ref(&committed), None)
        .unwrap_or_else(|e| panic!("the floor's commitment must open a claim on this state: {e}"));
    let (accepted, with_claim) =
        vp.palw_v2_accepted_objects_and_state_for_tests(&state, &params, &point, vec![committed], ctx.consensus.get_sink());
    assert_eq!(accepted.len(), 1, "the floor's commitment opens a claim");
    assert_eq!(with_claim.claim(&claim_id).expect("the claim is on chain").output_root, output_root);

    let transformer = Hash64::from_u64_word(0x7A);
    let object = PalwDerivedArtifactV1 {
        version: PALW_DERIVED_V1_VERSION,
        network_domain,
        claim_id,
        output_root,
        grammar_id: Hash64::from_u64_word(0x6A),
        transformer_id: transformer,
        kind: kind::SCENE,
        dsl_hash: Hash64::from_u64_word(0xD5),
        artifact_hash: Hash64::from_u64_word(0xA7),
        artifact_bytes: 4_096,
        executor_pubkey: executor_pubkey.clone(),
    };
    let signed = |o: &PalwDerivedArtifactV1, key: &libcrux_ml_dsa::ml_dsa_87::MLDSA87KeyPair| Obj::DerivedArtifactV1 {
        object: Box::new(o.clone()),
        signature: libcrux_ml_dsa::ml_dsa_87::sign(
            &key.signing_key,
            palw_derived_message_v1(o).as_byte_slice(),
            PALW_DERIVED_V1_MLDSA87_CONTEXT,
            [0u8; 32],
        )
        .expect("sign")
        .as_ref()
        .to_vec(),
    };
    let point2 = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: Hash64::from_u64_word(0xB201),
        daa_score: point.daa_score + 1,
        blue_score: point.blue_score + 8,
        subsidy: 0,
    };

    // Signed by the executor, on this chain: accepted and recorded beside the claim.
    let good = signed(&object, keypair);
    let (accepted, folded) =
        vp.palw_v2_accepted_objects_and_state_for_tests(&with_claim, &params, &point2, vec![good.clone()], point2.block);
    assert_eq!(accepted.len(), 1, "the executor's derivation rides");
    let row = folded.derived_artifact(&claim_id, &transformer).expect("recorded beside the claim");
    assert_eq!(row.kind, kind::SCENE);
    assert_eq!(row.accepted_daa, point2.daa_score);

    // A signature that is not the declared key's over this message: dropped at acceptance.
    let mut bad_sig = good.clone();
    if let Obj::DerivedArtifactV1 { signature, .. } = &mut bad_sig {
        signature[0] ^= 1;
    }
    // Another network's domain, properly signed: dropped at acceptance before any state is read.
    let mut foreign = object.clone();
    foreign.network_domain = Hash64::from_u64_word(0xF0);
    let foreign = signed(&foreign, keypair);
    // A real key that is not the claim's bond key: the signature verifies, the transition refuses.
    let stranger_key = crate::consensus::test_consensus::TestConsensus::palw_v2_registry_keypair(1);
    let mut stranger = object.clone();
    stranger.executor_pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_registry_pubkey(1);
    let stranger = signed(&stranger, stranger_key);
    for (name, refused) in
        [("a mismatching signature", bad_sig), ("another network's domain", foreign), ("a stranger's key", stranger)]
    {
        let (accepted, unchanged) =
            vp.palw_v2_accepted_objects_and_state_for_tests(&with_claim, &params, &point2, vec![refused], point2.block);
        assert_eq!(accepted.len(), 0, "{name} is dropped");
        assert!(unchanged.derived_artifact(&claim_id, &transformer).is_none(), "{name} records nothing");
    }
    // The same (claim, transformer) again: refused by the transition, the block stands.
    let (accepted, still) = vp.palw_v2_accepted_objects_and_state_for_tests(&folded, &params, &point2, vec![good], point2.block);
    assert_eq!(accepted.len(), 0, "a duplicate derivation is dropped");
    assert_eq!(still.derived_artifacts_of(claim_id).count(), 1);

    // **ADR-0078 Decision 5: the read half of the same object.** Accepting a derivation puts it in
    // the state root, which is not the same as making it CHECKABLE — "verification belongs to the
    // consumer" is a promise about ids a stranger can fetch, and until this read existed the
    // `derived_artifacts` table had no reader outside the transition that wrote it. This is the
    // function `getPalwDerivedArtifacts` calls once it has loaded the tip, put to the state the
    // acceptance just produced: the same state, the same object, no second path to disagree on.
    let (read_claim, read_key, read_rows) =
        crate::consensus::palw_derived_claim_view_v1(&folded, claim_id).expect("the chain holds the claim it just accepted");
    assert_eq!(read_claim.output_root, output_root, "X6 recomputes against the CLAIM's root, which the row does not carry");
    assert_eq!(read_key, executor_pubkey, "the executor's registered key — whose name the provenance is on");
    assert_eq!(read_rows.len(), 1, "one derivation was accepted, so one is readable");
    let (read_row_key, read_row) = &read_rows[0];
    assert_eq!(read_row_key.claim, claim_id);
    assert_eq!(read_row_key.transformer, transformer, "transformer_id lives in the KEY and the row never repeats it");
    assert_eq!(read_row.derived_id, kaspa_consensus_core::palw_derived_v1::derived_id_v1(&object), "total over every field");
    assert_eq!(read_row.grammar_id, object.grammar_id);
    assert_eq!(read_row.kind, object.kind);
    assert_eq!(read_row.dsl_hash, object.dsl_hash);
    assert_eq!(read_row.artifact_hash, object.artifact_hash);
    assert_eq!(read_row.artifact_bytes, object.artifact_bytes);
    assert_eq!(read_row.accepted_daa, point2.daa_score);
    // A claim the chain does not hold reads as `None`, never as an empty list: "this claim carries
    // no derivation" and "this is not my chain's claim" are different answers, and a verifier that
    // could not tell them apart would report a clean bill of health about somebody else's chain.
    assert!(crate::consensus::palw_derived_claim_view_v1(&folded, Hash64::from_u64_word(0xDEAD)).is_none());
    // And a claim with none reads as an empty list rather than as absence: the pre-derivation
    // state has the claim and no rows.
    let (_, _, none_yet) = crate::consensus::palw_derived_claim_view_v1(&with_claim, claim_id).expect("the claim exists there too");
    assert!(none_yet.is_empty(), "before the derivation the claim is readable and carries nothing");
}

/// **ADR-0075 security amendment SA-1 and SA-2: the permissionless lane pays rent, and pays it
/// before the work is done.**
///
/// Decision 1 rested certification's whole unsigned, permissionless design on "the transaction fee
/// is the rent", and nothing on the accepting path had ever read a fee — so both prices were the
/// mempool's flat floor. Past `palw_certification_rent`:
///
/// * **SA-2** — a `FamilyCertified` whose carrier paid less than its vector count's price is
///   dropped BEFORE the court grades it and, the part that matters, before it consumes one of the
///   block's two grading slots. Charging a refused object a slot would let a griefer starve honest
///   drills for the price of a floor fee, which is the denial `PALW_CERTIFICATION_MAX_PER_BLOCK`
///   exists to stop.
/// * **SA-1** — a chunk that OPENS a group is charged the carriage of the room it reserves. A
///   one-part-sized chunk declaring eight parts held one of eight state-root slots for ~5.5 days at
///   the flat floor; now it pays what eight hundred kilobytes of carriage costs.
///
/// The evidence is real (the floor's own drills), the ruleset is the mainnet one with a V2 bundle,
/// and the honest path is asserted with the fence ARMED — a paid drill is graded and recorded
/// exactly as it is without the fence.
#[tokio::test]
async fn palw_v2_certification_and_chunk_carriage_pay_rent_past_the_fence() {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_CERTIFICATION_MAX_PER_BLOCK, PALW_OBJECT_CHUNK_MAX_BYTES, PALW_OBJECT_CHUNK_MAX_COUNT, PalwCertificationEvidenceV1,
        PalwCertifiedLaneV1, PalwConsensusObjectV2, palw_certification_min_fee_v1, palw_object_chunk_group_rent_v1,
        palw_object_chunks_with_cap_v1,
    };
    use misaka_palw_base0::e2e_drill::{PalwRcFamilyV1, rc_attempt_evidence_v1, rc_free_prompt_evidence_v1};

    // The flat mempool floor a carrier used to be able to pay for any of this.
    const FLOOR: u64 = 250_000;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let armed = |rent: Option<ForkActivation>| {
        let bundle = bundle.clone();
        ConfigBuilder::new(MAINNET_PARAMS)
            .skip_proof_of_work()
            .edit_consensus_params(move |p| {
                p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
                p.palw_certification_rent = rent;
                *p = p.clone().with_palw_v2_cadence();
            })
            .build()
    };

    let floor_attempt = rc_attempt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its attempt lane");
    let floor_fp = rc_free_prompt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its free-prompt lane");
    let a16_attempt = rc_attempt_evidence_v1(PalwRcFamilyV1::Qwen25A16).expect("the A16 fixture drills its attempt lane");
    let attempt_object = |e: kaspa_consensus_core::palw_e2e_adjudicability::PalwE2eDrillEvidenceV1| {
        PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(e)) }
    };
    let fp_object = PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::FreePrompt(floor_fp)) };
    let floor_object = attempt_object(floor_attempt);
    let a16_object = attempt_object(a16_attempt);
    let price = |object: &PalwConsensusObjectV2| match object {
        PalwConsensusObjectV2::FamilyCertified { evidence } => palw_certification_min_fee_v1(evidence.vector_count()),
        other => panic!("{other:?} is not a certification"),
    };
    // The family each drill grades to — the name under which it is recorded. Asserted by NAME and
    // not by count, because the count cannot tell the two apart: the block's grading cap is two, so
    // "one attempt family landed" is true whether it is the underpaid floor's or the paid A16's,
    // and a rule that drops the wrong one of them would read as green.
    let digest_of = |object: &PalwConsensusObjectV2| match object {
        PalwConsensusObjectV2::FamilyCertified { evidence } => evidence.grade().expect("this build grades its own drill").digest(),
        other => panic!("{other:?} is not a certification"),
    };
    let floor_family = digest_of(&floor_object);
    let a16_family = digest_of(&a16_object);
    assert_ne!(floor_family, a16_family, "the two attempt drills are two families");
    let attempt_families = |folded: &kaspa_consensus_core::palw_state_v2::PalwChainStateV2| {
        folded.chain_certified_families(PalwCertifiedLaneV1::Attempt).iter().map(|f| f.digest()).collect::<Vec<_>>()
    };
    assert!(price(&floor_object) > FLOOR, "a real drill's grading costs more than the flat floor it used to pay");

    // A context at some chain height, with the state and evaluation point the walk would use.
    async fn walked(config: kaspa_consensus_core::config::Config) -> TestContext {
        let mut ctx = TestContext::new(TestConsensus::new(&config));
        for _ in 0..2 {
            ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
        }
        ctx
    }
    let point_of = |ctx: &TestContext| kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 5,
        subsidy: 0,
    };

    // ── SA-2, armed ──────────────────────────────────────────────────────────────────────────
    let ctx = walked(armed(Some(ForkActivation::always()))).await;
    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let point = point_of(&ctx);
    let (accepted, folded) = vp.palw_v2_accepted_priced_objects_for_tests(
        &state,
        &bundle.state,
        &point,
        vec![
            // Underpaid: the flat floor a griefer used to buy 32 court re-executions with.
            (floor_object.clone(), FLOOR),
            (fp_object.clone(), price(&fp_object)),
            (a16_object.clone(), price(&a16_object)),
        ],
        point.block,
    );
    assert_eq!(
        accepted.len(),
        PALW_CERTIFICATION_MAX_PER_BLOCK,
        "the underpaid drill is dropped ungraded and spends no grading slot, so BOTH paid ones land"
    );
    assert_eq!(folded.chain_certified_families(PalwCertifiedLaneV1::FreePrompt).len(), 1, "the paid free-prompt family is recorded");
    assert_eq!(
        attempt_families(&folded),
        vec![a16_family],
        "the attempt family the block recorded is the PAID one — the underpaid floor drill was never graded, and the slot it \
         would have burned went to the A16 carrier behind it"
    );

    // The honest path, with the fence armed: pay the rent and the same drill is graded.
    let (accepted, folded) = vp.palw_v2_accepted_priced_objects_for_tests(
        &state,
        &bundle.state,
        &point,
        vec![(floor_object.clone(), price(&floor_object))],
        point.block,
    );
    assert_eq!(accepted.len(), 1, "a drill that paid its rent is graded");
    assert_eq!(attempt_families(&folded), vec![floor_family], "and recorded: the rent buys the grading, it does not forbid it");

    // ── SA-1, armed: opening a chunk group ───────────────────────────────────────────────────
    // Cut at the carriage the lane actually rides at. This was `bytes.len().div_ceil(4)` — "a
    // four-part group" — written when the floor's drill evidence was under 400 KB. The evidence is
    // 754,377 B today, so a quarter of it is 188,595 B, the transition refused every part as
    // `ChunkTooLarge` (cap 100,000), the rehearsal dropped the opener, and the assertion below read
    // "left 0, right 1" for a reason that had nothing to do with rent. Worse, the underpay
    // assertion above it kept passing: the rent check runs BEFORE the transition, so an opener
    // that could never open was "dropped" for both prices. Asserted here by name so the next
    // growth of the evidence fails as what it is and not as a rent regression.
    let bytes = borsh::to_vec(&floor_object).expect("the object serializes");
    let chunks = palw_object_chunks_with_cap_v1(&floor_object, PALW_OBJECT_CHUNK_MAX_BYTES).expect("it chunks").expect("it needs to");
    let PalwConsensusObjectV2::ObjectChunk { group, count, bytes: part0, .. } = chunks[0].clone() else { panic!("a chunk") };
    assert!(
        part0.len() <= PALW_OBJECT_CHUNK_MAX_BYTES && (count as usize) <= PALW_OBJECT_CHUNK_MAX_COUNT as usize,
        "the floor's {}-byte evidence must ride the lane's carriage as {count} parts of at most {PALW_OBJECT_CHUNK_MAX_BYTES} B",
        bytes.len()
    );
    let room = palw_object_chunk_group_rent_v1();
    assert!(room > FLOOR, "taking a pending-chunk slot costs more than the flat floor");

    let (accepted, unopened) =
        vp.palw_v2_accepted_priced_objects_for_tests(&state, &bundle.state, &point, vec![(chunks[0].clone(), room - 1)], point.block);
    assert!(accepted.is_empty(), "an opener that underpays the room is dropped, and the block stands");
    assert!(unopened.pending_chunk_group(&group).is_none(), "and no slot is held: the junk never reaches the state root");

    let (accepted, opened) =
        vp.palw_v2_accepted_priced_objects_for_tests(&state, &bundle.state, &point, vec![(chunks[0].clone(), room)], point.block);
    assert_eq!(accepted.len(), 1, "the same chunk, having paid the room, opens the group");
    let held = opened.pending_chunk_group(&group).expect("the group is held");
    assert_eq!(held.count, count);
    // Extending it is not charged the room again — that would tax only the carrier that completes.
    // A later chain point, because `opened` already folded one object at `point`: the transition
    // demands a strictly increasing blue score along a chain.
    let next = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: kaspa_hashes::Hash64::from_u64_word(0xB1_0075),
        daa_score: point.daa_score + 1,
        blue_score: point.blue_score + 8,
        subsidy: 0,
    };
    let (accepted, _) =
        vp.palw_v2_accepted_priced_objects_for_tests(&opened, &bundle.state, &next, vec![(chunks[1].clone(), FLOOR)], next.block);
    assert_eq!(accepted.len(), 1, "a chunk that extends an open group reserves nothing new and pays no room rent");

    // ── The fence OFF: byte-identical to before the amendment ────────────────────────────────
    let ctx = walked(armed(None)).await;
    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let point = point_of(&ctx);
    let (accepted, folded) = vp.palw_v2_accepted_priced_objects_for_tests(
        &state,
        &bundle.state,
        &point,
        vec![(floor_object, FLOOR), (fp_object, FLOOR), (a16_object, FLOOR)],
        point.block,
    );
    assert_eq!(accepted.len(), PALW_CERTIFICATION_MAX_PER_BLOCK, "unarmed, the cap is the only limit and the floor fee buys grading");
    assert_eq!(
        attempt_families(&folded),
        vec![floor_family],
        "unarmed, the flat-fee floor drill is graded first and the A16 behind it is what the cap drops — the pre-amendment \
         behaviour, byte for byte"
    );
    assert_eq!(folded.chain_certified_families(PalwCertifiedLaneV1::FreePrompt).len(), 1);
    let (accepted, opened) =
        vp.palw_v2_accepted_priced_objects_for_tests(&state, &bundle.state, &point, vec![(chunks[0].clone(), FLOOR)], point.block);
    assert_eq!(accepted.len(), 1, "unarmed, a one-floor-fee opener holds a slot exactly as it did");
    assert!(opened.pending_chunk_group(&group).is_some());
}

/// **The block's two grading slots are spent on court work and on nothing else** (ADR-0075 SA-2).
///
/// The cap counted "does this chunk complete its group", which is not the question it is named
/// for. `ObjectChunk { group: <fresh>, index: 5, count: 1 }` completes a group by that reading and
/// the transition then refuses it as `ChunkIndexOutOfRange`; so does `{ index: 0, count: 1 }`
/// carrying two bytes no object decodes from. Sixty-odd bytes each, and two per block exhausted
/// `PALW_CERTIFICATION_MAX_PER_BLOCK` and dropped every genuine `FamilyCertified` the block
/// carried — a block-cheap way to keep an honest class weightless, which is the exact denial the
/// cap exists to prevent.
///
/// Both junk chunks here PAY the slot rent, so SA-1 lets them through: what must stop them is that
/// the cap now counts `palw_v2_graded_vector_count`, the same predicate SA-2 prices from, which
/// answers `None` for everything the transition refuses before it grades.
#[tokio::test]
async fn palw_v2_a_chunk_the_transition_refuses_spends_no_grading_slot() {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PalwCertificationEvidenceV1, PalwCertifiedLaneV1, PalwConsensusObjectV2, palw_certification_min_fee_v1,
        palw_object_chunk_group_rent_v1,
    };
    use misaka_palw_base0::e2e_drill::{PalwRcFamilyV1, rc_attempt_evidence_v1};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params({
            let bundle = bundle.clone();
            move |p| {
                p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
                p.palw_certification_rent = Some(ForkActivation::always());
                *p = p.clone().with_palw_v2_cadence();
            }
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 5,
        subsidy: 0,
    };

    let evidence = rc_attempt_evidence_v1(PalwRcFamilyV1::Qwen25A16).expect("the A16 fixture drills its attempt lane");
    let certification = PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(evidence)) };
    let (family, price) = match &certification {
        PalwConsensusObjectV2::FamilyCertified { evidence } => (
            evidence.grade().expect("this build grades its own drill").digest(),
            palw_certification_min_fee_v1(evidence.vector_count()),
        ),
        other => panic!("{other:?}"),
    };

    // Two chunks the transition refuses on their face, each paying the slot rent in full.
    let rent = palw_object_chunk_group_rent_v1();
    let out_of_range = PalwConsensusObjectV2::ObjectChunk {
        group: kaspa_hashes::Hash64::from_u64_word(0x0075_0001),
        index: 5,
        count: 1,
        bytes: vec![0xAA],
    };
    let undecodable = PalwConsensusObjectV2::ObjectChunk {
        group: kaspa_hashes::Hash64::from_u64_word(0x0075_0002),
        index: 0,
        count: 1,
        bytes: vec![0xAA],
    };

    let (accepted, folded) = vp.palw_v2_accepted_priced_objects_for_tests(
        &state,
        &bundle.state,
        &point,
        vec![(out_of_range, rent), (undecodable, rent), (certification, price)],
        point.block,
    );
    assert_eq!(accepted.len(), 1, "both junk chunks are refused as objects, and the block stands carrying the certification");
    assert_eq!(
        folded.chain_certified_families(PalwCertifiedLaneV1::Attempt).iter().map(|f| f.digest()).collect::<Vec<_>>(),
        vec![family],
        "the family is chain-certified: two sixty-byte chunks the transition was always going to refuse did not spend the \
         grading slots it needed"
    );
}

/// **The rent is a fee the chain actually READ, and it is burned rather than paid back.**
///
/// Everything else about ADR-0075's two prices is proven at the acceptance filter, which is handed
/// `(object, fee)` pairs directly. That leaves the half the whole rule rests on untested: that
/// `calculate_utxo_state` — the only frame where a fee exists, since `AcceptanceData` records a
/// transaction id and an index and nothing about value — remembers a fee for every carrier the
/// object walk will price. If it does not, `fee_of` reads `unwrap_or(0)`, every carrier looks
/// unpaid, and no certification and no chunk group can ever be accepted again on that network: a
/// permanent halt with no error a submitter can see, since the object is dropped and the block
/// stands.
///
/// So this drives a REAL 0x4b carrier — funded from a matured coinbase, ML-DSA-87-signed, selected
/// into a template and inserted — through `validate_and_insert_block`, and reads the answer off
/// the state root. One sompi decides it, which is only possible if the number the walk compared is
/// the number the block carried.
///
/// It also reads what the carrier block's own miner was paid, because that is the other half of
/// SA-2's claim: a fee returns to the coinbase of the block that accepts it, so before the burn a
/// miner — the cheapest adversary either rule has — recovered what he had just been charged.
#[tokio::test]
async fn palw_v2_a_funded_carrier_is_priced_by_the_fee_the_utxo_walk_read() {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_state_v2::palw_object_chunk_group_rent_v1;

    let group = kaspa_hashes::Hash64::from_u64_word(0x5107_0075);
    let rent = palw_object_chunk_group_rent_v1();

    /// `(the group is open in the tip state, what the carrier block's miner was paid for it)`.
    async fn run(rent_fence: Option<ForkActivation>, fee: u64, group: kaspa_hashes::Hash64) -> (bool, u64) {
        use crate::model::stores::virtual_state::VirtualStateStoreReader;
        use kaspa_consensus_core::hashing::sighash::{Mldsa87SigHashReusedValuesUnsync, calc_mldsa87_signature_hash};
        use kaspa_consensus_core::hashing::sighash_type::SIG_HASH_ALL;
        use kaspa_consensus_core::mass::MassCalculator;
        use kaspa_consensus_core::palw_lifecycle_objects_v2::{PALW_LIFECYCLE_TX_VERSION_V2, PalwLifecycleTxPayloadV2};
        use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
        use kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2;
        use kaspa_consensus_core::subnets::SUBNETWORK_ID_PALW_LIFECYCLE;
        use kaspa_consensus_core::tx::{PopulatedTransaction, TransactionInput, TransactionOutput, UtxoEntry};
        use kaspa_txscript::{MLDSA87_TX_CONTEXT, script_builder::ScriptBuilder};
        use libcrux_ml_dsa::ml_dsa_87 as mldsa;

        kaspa_core::log::try_init_logger("info");
        let catalog = palw_v2_test_catalog();
        let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
        let config = ConfigBuilder::new(MAINNET_PARAMS)
            .skip_proof_of_work()
            .edit_consensus_params({
                let bundle = bundle.clone();
                move |p| {
                    p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
                    p.palw_certification_rent = rent_fence;
                    // So the funding coinbase is spendable within a short chain.
                    p.coinbase_maturity = 2;
                    *p = p.clone().with_palw_v2_cadence();
                }
            })
            .build();
        let mut ctx = TestContext::new(TestConsensus::new(&config));

        // `TestContext::mine_block` does not stamp the V2 carriage, and on a `ConsensusV2` network
        // the template DECLARES algo-6 and leaves producing the attempt to the miner — so the
        // harness stands in for one, after the timestamp and the nonce the challenge binds.
        async fn mine(ctx: &mut TestContext, miner: MinerData, txs: Vec<Transaction>) -> Block {
            ctx.simulated_time += ctx.consensus.params().target_time_per_block();
            let mut t =
                ctx.consensus.build_block_template(miner, Box::new(OnetimeTxSelector::new(txs)), TemplateBuildMode::Standard).unwrap();
            t.block.header.timestamp = ctx.simulated_time;
            t.block.header.nonce = ctx.simulated_time;
            if t.block.header.pow_algo_id == kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_COMMITTED_V2 {
                t.block.header.palw_commitment = ctx.consensus.palw_v2_test_carriage(&t.block.header);
            }
            t.block.header.finalize();
            let block = t.block.to_immutable();
            ctx.validate_and_insert_block(block.clone()).await;
            block
        }

        // A funding key whose coinbase this test can actually spend.
        let kp = mldsa::generate_key_pair([0x7Bu8; 32]);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let address_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&address_payload);

        // **Funding a key on a `ConsensusV2` network takes a two-wide row.** A linear V2 chain pays
        // nobody a coinbase output: every merging block's only DAA-eligible merged block is its own
        // selected parent, whose reward is ESCROWED rather than paid (ADR-0042 Decision 10). A
        // merged blue that is not the selected parent is paid to its own miner — so two siblings,
        // both mined by K, and the block that merges them carries K's spendable output.
        ctx.miner_data = MinerData::new(spk.clone(), vec![]);
        ctx.build_block_template_row(0..2).validate_and_insert_row().await;
        let harvest = mine(&mut ctx, new_miner_data(), vec![]).await;
        let coinbase = &harvest.transactions[0];
        let (index, out) = coinbase
            .outputs
            .iter()
            .enumerate()
            .find(|(_, o)| o.script_public_key == spk)
            .expect("the block merging the row pays the sibling's miner");
        let funding = TransactionOutpoint::new(coinbase.id(), index as u32);
        let value = out.value;
        let funding_daa = harvest.header.daa_score;
        assert!(value > fee, "the funding coinbase ({value}) must cover the {fee} sompi rent");
        for _ in 0..4 {
            mine(&mut ctx, new_miner_data(), vec![]).await;
        }

        // The carrier: one chunk OPENING a group, on the lifecycle band, paying exactly `fee`.
        let object = PalwConsensusObjectV2::ObjectChunk { group, index: 0, count: 3, bytes: vec![0xC0, 0xDE] };
        let payload = borsh::to_vec(&PalwLifecycleTxPayloadV2 { version: PALW_LIFECYCLE_TX_VERSION_V2, object })
            .expect("the lifecycle payload serializes");
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(funding, vec![], 0, 1)],
            vec![TransactionOutput::new(value - fee, spk.clone())],
            0,
            SUBNETWORK_ID_PALW_LIFECYCLE,
            0,
            payload,
        );
        let utxo = UtxoEntry::new(value, spk.clone(), funding_daa, true);
        let storage_mass = MassCalculator::new(0, 0, 0, ctx.consensus.params().storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the funded carrier")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = {
            let populated = PopulatedTransaction::new(&tx, vec![utxo]);
            calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
        };
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0x7Bu8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        tx.inputs[0].signature_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("the signature push fits")
            .add_data(&pubkey)
            .expect("the public-key push fits")
            .drain();
        let carrier_id = tx.id();

        let carrier_block = mine(&mut ctx, new_miner_data(), vec![tx]).await;
        assert!(carrier_block.transactions.iter().any(|t| t.id() == carrier_id), "the carrier reached the block");
        assert_eq!(
            ctx.consensus.block_status(carrier_block.header.hash),
            BlockStatus::StatusUTXOValid,
            "the block carrying the funded lifecycle spend must be UTXO-valid (construction == validation)"
        );

        let vp = ctx.consensus.virtual_processor();
        // What the chain will MINT for this block — the same `BlockRewardData` its merging block's
        // coinbase is built from and validated against, both of them this function's own output.
        let minted_fees = vp
            .virtual_stores
            .read()
            .state
            .get()
            .unwrap()
            .mergeset_rewards
            .get(&carrier_block.header.hash)
            .expect("virtual merges the carrier block it was just built on")
            .total_fees;
        // One more block, so the carrier block is a settled chain block and the PALW state tip is
        // the one its own object walk wrote. (`vp` is a borrow of `ctx`; its last use is above, so
        // the borrow ends before `mine` takes `ctx` mutably — no `drop` of a reference needed.)
        mine(&mut ctx, new_miner_data(), vec![]).await;
        let vp = ctx.consensus.virtual_processor();
        let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
        (state.pending_chunk_group(&group).is_some(), minted_fees)
    }

    let (opened, minted_armed) = run(Some(ForkActivation::always()), rent, group).await;
    assert!(
        opened,
        "a carrier that paid the slot rent opens its group — which it can only be KNOWN to have paid if calculate_utxo_state \
         remembered the fee and the object walk read it"
    );

    let (opened_short, _) = run(Some(ForkActivation::always()), rent - 1, group).await;
    assert!(
        !opened_short,
        "one sompi short and the opener is dropped and the block stands: the number the walk compares is the number the block \
         actually carried, not a constant"
    );

    let (opened_unarmed, minted_unarmed) = run(None, rent, group).await;
    assert!(opened_unarmed, "dormant, the fence prices nothing and the same carrier opens the same group");
    assert_eq!(minted_unarmed, rent, "dormant, the whole fee is minted back to the block's miner, exactly as it always was");
    assert_eq!(
        minted_armed, 0,
        "past the fence the rent is BURNED rather than minted: a fee returns to the coinbase of the block that accepts it, so a \
         miner — the cheapest adversary either amendment has — was being refunded what he had just been charged"
    );
}

/// **The 2026-09-23 Position route matrix, P-B1: a carrier buy the chain refuses is paid back to the
/// payer, end to end — never kept in the sink.**
///
/// The route matrix measured the defect in-process (P8): the carrier is accepted, its `OP_RETURN`
/// sink holds the MSK, the fold drops the object, and nothing pays anything back. This drives a
/// REAL 0x4b `ModelBuy` carrier — funded from a matured coinbase, ML-DSA-87-signed, change at
/// output 0 and the sink at output 1 exactly as `misaka palw model-buy` builds it — onto a line
/// that has no market, through `validate_and_insert_block`, and follows the money: past
/// `palw_audit_2026_09_23` the object walk names the payer, the filter records the refund, the
/// transition writes the row, and a later coinbase pays the sink's value to the change script the
/// payer signed. Below the fence — testnet-11's shape — the same carrier is folded exactly as
/// before: no row and no payment.
///
/// It also checks the filter's bookkeeping on the order it cares about: a refund is owed by the
/// objects acceptance DROPPED, and never by one it applied.
#[tokio::test]
async fn palw_v2_a_refused_carrier_market_move_is_paid_back_to_its_payer() {
    use kaspa_consensus_core::config::params::ForkActivation;

    /// `(the refund row the tip state holds for the carrier, whether a coinbase paid it to the payer,
    /// the payer's change payload)`.
    async fn run(audit: Option<ForkActivation>) -> (Option<(kaspa_hashes::Hash64, u64)>, bool, kaspa_hashes::Hash64) {
        use kaspa_consensus_core::hashing::sighash::{Mldsa87SigHashReusedValuesUnsync, calc_mldsa87_signature_hash};
        use kaspa_consensus_core::hashing::sighash_type::SIG_HASH_ALL;
        use kaspa_consensus_core::mass::MassCalculator;
        use kaspa_consensus_core::palw_lifecycle_objects_v2::{PALW_LIFECYCLE_TX_VERSION_V2, PalwLifecycleTxPayloadV2};
        use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
        use kaspa_consensus_core::palw_model_market_v1::palw_model_sink_spk_v1;
        use kaspa_consensus_core::palw_state_v2::{PalwCarrierRefundV1, PalwConsensusObjectV2, palw_model_refund_payout_key_v1};
        use kaspa_consensus_core::subnets::SUBNETWORK_ID_PALW_LIFECYCLE;
        use kaspa_consensus_core::tx::{PopulatedTransaction, TransactionInput, TransactionOutput, UtxoEntry};
        use kaspa_txscript::{MLDSA87_TX_CONTEXT, script_builder::ScriptBuilder};
        use libcrux_ml_dsa::ml_dsa_87 as mldsa;

        kaspa_core::log::try_init_logger("info");
        let catalog = palw_v2_test_catalog();
        let mut bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
        // Past the 2026-09-23 audit a claim reserves its ESCROW on its bond (option A), which the
        // `pwu`-priced fixture above does not cover; fund the bonds for the unit the fence prices in,
        // so the harness's own attempt blocks stay admissible on both sides of the comparison.
        for object in bundle.genesis_objects.iter_mut() {
            if let PalwConsensusObjectV2::BondRegistered { collateral, .. } = object {
                *collateral = 10_000_000 * 100_000_000;
            }
        }
        let config = ConfigBuilder::new(MAINNET_PARAMS)
            .skip_proof_of_work()
            .edit_consensus_params({
                let bundle = bundle.clone();
                move |p| {
                    p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
                    p.palw_model_market = Some(ForkActivation::always());
                    p.palw_audit_2026_09_23 = audit;
                    // testnet-12 arms the 2026-09-11 audit from genesis too, and with it the
                    // acceptance rehearsal that folds the real step 3 — the one whose queue count
                    // the P-B1 refund accounting reads exactly. The unarmed run keeps testnet-11's
                    // pre-fence shape.
                    if audit.is_some() {
                        p.palw_audit_2026_09_11 = Some(ForkActivation::always());
                    }
                    p.coinbase_maturity = 2;
                    *p = p.clone().with_palw_v2_cadence();
                    p.sync_palw_escrow_backed_exposure();
                }
            })
            .build();
        let mut ctx = TestContext::new(TestConsensus::new(&config));
        let state_params = match &ctx.consensus.params().palw_consensus_mode {
            PalwConsensusMode::ConsensusV2(bundle) => bundle.state.clone(),
            _ => unreachable!("the fixture is ConsensusV2"),
        };

        // The harness's miner, as in the rent test above: the template declares algo-6 and the
        // harness stands in for the producer.
        async fn mine(ctx: &mut TestContext, miner: MinerData, txs: Vec<Transaction>) -> Block {
            ctx.simulated_time += ctx.consensus.params().target_time_per_block();
            let mut t =
                ctx.consensus.build_block_template(miner, Box::new(OnetimeTxSelector::new(txs)), TemplateBuildMode::Standard).unwrap();
            t.block.header.timestamp = ctx.simulated_time;
            t.block.header.nonce = ctx.simulated_time;
            if t.block.header.pow_algo_id == kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_COMMITTED_V2 {
                t.block.header.palw_commitment = ctx.consensus.palw_v2_test_carriage(&t.block.header);
            }
            t.block.header.finalize();
            let block = t.block.to_immutable();
            ctx.validate_and_insert_block(block.clone()).await;
            block
        }

        // The payer: a key whose coinbase this test can spend, funded by a two-wide row (see the
        // rent test above for why a linear V2 chain pays nobody).
        let kp = mldsa::generate_key_pair([0x8Cu8; 32]);
        let pubkey = kp.verification_key.as_ref().to_vec();
        let address_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
        let spk = p2pkh_mldsa87_spk(&address_payload);
        ctx.miner_data = MinerData::new(spk.clone(), vec![]);
        ctx.build_block_template_row(0..2).validate_and_insert_row().await;
        let harvest = mine(&mut ctx, new_miner_data(), vec![]).await;
        let coinbase = &harvest.transactions[0];
        let (index, out) = coinbase
            .outputs
            .iter()
            .enumerate()
            .find(|(_, o)| o.script_public_key == spk)
            .expect("the block merging the row pays the sibling's miner");
        let funding = TransactionOutpoint::new(coinbase.id(), index as u32);
        let value = out.value;
        let funding_daa = harvest.header.daa_score;
        for _ in 0..4 {
            mine(&mut ctx, new_miner_data(), vec![]).await;
        }

        // A buy of a line nobody has seeded: the fold refuses it on every build (ADR-0090 Decision 2
        // — no market opens by a buy), so its carrier is accepted and its object is not.
        let vp = ctx.consensus.virtual_processor();
        let (_, tip) = vp.palw_state_v2_store.read().load_tip(&state_params).unwrap().expect("the tip loads");
        let line = *tip.classes_iter().map(|(id, _)| id).next().expect("the catalog registers a class");
        assert!(tip.model_market(&line).is_none(), "the fixture's line has no market");
        let paid = value / 4;
        let fee = 1_000_000;
        let storage_mass_parameter = ctx.consensus.params().storage_mass_parameter;
        // A funded, signed 0x4b carrier of a `ModelBuy` paying `paid` into the line's sink, change at
        // output 0 back to the payer's own script — exactly as `misaka palw model-buy` builds it.
        let carrier_of = |funding: TransactionOutpoint, value: u64, funding_daa: u64, from_coinbase: bool, paid: u64| {
            let object = PalwConsensusObjectV2::ModelBuy {
                line_id: line,
                holder: kaspa_hashes::Hash64::from_u64_word(0xB0B),
                msk_in: paid,
                min_units_out: 0,
                sink_index: 1,
            };
            let payload = borsh::to_vec(&PalwLifecycleTxPayloadV2 { version: PALW_LIFECYCLE_TX_VERSION_V2, object })
                .expect("the lifecycle payload serializes");
            let mut tx = Transaction::new(
                crate::constants::TX_VERSION,
                vec![TransactionInput::new(funding, vec![], 0, 1)],
                vec![
                    TransactionOutput::new(value - paid - fee, spk.clone()),
                    TransactionOutput::new(paid, palw_model_sink_spk_v1(&line)),
                ],
                0,
                SUBNETWORK_ID_PALW_LIFECYCLE,
                0,
                payload,
            );
            let utxo = UtxoEntry::new(value, spk.clone(), funding_daa, from_coinbase);
            let storage_mass = MassCalculator::new(0, 0, 0, storage_mass_parameter)
                .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
                .expect("contextual mass is computable for the funded carrier")
                .storage_mass;
            tx.set_mass(storage_mass);
            let reused = Mldsa87SigHashReusedValuesUnsync::new();
            let sig_hash = {
                let populated = PopulatedTransaction::new(&tx, vec![utxo]);
                calc_mldsa87_signature_hash(&populated, 0, SIG_HASH_ALL, &reused)
            };
            let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0x8Cu8; 32])
                .expect("ML-DSA-87 sign on the 64-byte sighash");
            let mut sig_item = sig.as_ref().to_vec();
            sig_item.push(SIG_HASH_ALL.to_u8());
            tx.inputs[0].signature_script = ScriptBuilder::new()
                .add_data(&sig_item)
                .expect("the signature push fits")
                .add_data(&pubkey)
                .expect("the public-key push fits")
                .drain();
            tx
        };
        let tx = carrier_of(funding, value, funding_daa, true, paid);
        let carrier_id = tx.id();

        let carrier_block = mine(&mut ctx, new_miner_data(), vec![tx]).await;
        let carrier_daa = carrier_block.header.daa_score;
        assert!(carrier_block.transactions.iter().any(|t| t.id() == carrier_id), "the carrier reached the block");
        assert_eq!(ctx.consensus.block_status(carrier_block.header.hash), BlockStatus::StatusUTXOValid);
        // One more block, so the carrier block's acceptance is folded into the tip state.
        mine(&mut ctx, new_miner_data(), vec![]).await;
        let vp = ctx.consensus.virtual_processor();
        let (_, tip) = vp.palw_state_v2_store.read().load_tip(&state_params).unwrap().expect("the tip loads");
        let key = palw_model_refund_payout_key_v1(&carrier_id);
        let row = tip.pending_payouts_iter().find(|(k, _)| **k == key).map(|(_, row)| (row.payload, row.amount));

        // The filter's bookkeeping, on the tip: a refund is owed by the objects acceptance dropped
        // — before and after one it applied — and never by the one it applied.
        if audit.is_some() {
            let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
                block: ctx.consensus.get_sink(),
                daa_score: ctx.consensus.get_virtual_daa_score(),
                blue_score: vp.headers_store.get_header(ctx.consensus.get_sink()).unwrap().blue_score + 1,
                subsidy: 0,
            };
            let owed = |carrier: u64, amount: u64| PalwCarrierRefundV1 {
                carrier: kaspa_consensus_core::tx::TransactionId::from_u64_word(carrier),
                line_id: line,
                payee: kaspa_hashes::Hash64::from_u64_word(0xFA),
                amount,
            };
            let buy = |min_units_out: u64| PalwConsensusObjectV2::ModelBuy {
                line_id: line,
                holder: kaspa_hashes::Hash64::from_u64_word(0xB0B),
                msk_in: 1_000_000,
                min_units_out,
                sink_index: 1,
            };
            let seed = PalwConsensusObjectV2::ModelSeed {
                line_id: line,
                seeder: kaspa_hashes::Hash64::from_u64_word(0x5EED),
                msk_seed: kaspa_consensus_core::palw_model_market_v1::PALW_MODEL_SEED_MIN_SOMPI_V1,
                sink_index: 1,
            };
            let vp = ctx.consensus.virtual_processor();
            let (accepted, _, refunds) = vp.palw_v2_accepted_refundable_objects_for_tests(
                &tip,
                &state_params,
                &point,
                vec![
                    (buy(0), Some(owed(1, 1_000_000))),
                    (seed.clone(), Some(owed(2, kaspa_consensus_core::palw_model_market_v1::PALW_MODEL_SEED_MIN_SOMPI_V1))),
                    (buy(u64::MAX), Some(owed(3, 1_000_000))),
                ],
                point.block,
            );
            assert_eq!(accepted, vec![seed.clone()], "the seed opens the pair; both buys are refused");
            assert_eq!(refunds, vec![owed(1, 1_000_000), owed(3, 1_000_000)], "the two refused carriers are owed, the seed is not");
            let folded = vp
                .palw_v2_block_fold_with_refunds_for_tests(&tip, &state_params, &point, &accepted, refunds.clone())
                .expect("what the filter returns, the transition applies");
            for refund in &refunds {
                let key = palw_model_refund_payout_key_v1(&refund.carrier);
                assert!(
                    folded
                        .pending_payouts_iter()
                        .any(|(k, row)| *k == key && row.payload == refund.payee && row.amount == refund.amount)
                );
            }

            // ---- Refunds COUNT against the cap (user decision on the P-B1 review) ----------------
            use kaspa_consensus_core::palw_state_v2::PALW_V2_MAX_PENDING_PAYOUTS as CAP;
            // A queue filled to the cap by refunds alone: the cap holds with refunds, whatever the
            // list handed to the fold.
            let flood = |from: u64, n: usize| (0..n as u64).map(|i| owed(from + i, 1_000)).collect::<Vec<_>>();
            let full = vp
                .palw_v2_block_fold_with_refunds_for_tests(&tip, &state_params, &point, &[], flood(0x40_0000, CAP + 16))
                .expect("a block of refunds folds");
            assert_eq!(full.pending_payouts_iter().count(), CAP, "the cap holds with refunds");

            // **Refused buys cannot starve a valid move in the same block.** The next block drains
            // eight rows first, so it has eight. A cheap refused buy (`min_units_out = u64::MAX`)
            // used to promise its two fee rows and then write none — six of them took twelve phantom
            // rows and the valid buy behind them was dropped. Now a refused buy takes exactly the one
            // row its refund really needs, reserved: six refunds and the valid buy's two legs fit.
            let next = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
                block: kaspa_hashes::Hash64::from_u64_word(0x9E47),
                daa_score: point.daa_score + 1,
                blue_score: point.blue_score + 1,
                subsidy: 0,
            };
            let valid = PalwConsensusObjectV2::ModelBuy {
                line_id: line,
                holder: kaspa_hashes::Hash64::from_u64_word(0xB0B),
                msk_in: 1_000 * 100_000_000,
                min_units_out: 0,
                sink_index: 1,
            };
            let mut carried = vec![(seed.clone(), None)];
            carried.extend((0..6u64).map(|i| (buy(u64::MAX), Some(owed(0x50_0000 + i, 1_000_000)))));
            carried.push((valid.clone(), Some(owed(0x50_0100, 1_000 * 100_000_000))));
            let (accepted, _, refunds) =
                vp.palw_v2_accepted_refundable_objects_for_tests(&full, &state_params, &next, carried, next.block);
            assert_eq!(accepted, vec![seed.clone(), valid], "the valid buy behind six refused ones is not starved");
            assert_eq!(refunds.len(), 6, "each refused buy owes, and reserves, one row");
            let after = vp
                .palw_v2_block_fold_with_refunds_for_tests(&full, &state_params, &next, &accepted, refunds)
                .expect("what the filter returns, the transition applies");
            assert!(after.pending_payouts_iter().count() <= CAP, "and the block's refunds keep the cap");

            // **A full queue refuses a market carrier at the mempool and at the template** — it
            // is neither relayed nor mined, so nothing it pays can burn. The tip is swapped for the
            // full state (test-only), a second real carrier is offered from the first one's change,
            // and the real tip is put back afterwards.
            let sink = ctx.consensus.get_sink();
            let (_, real_tip) = vp.palw_state_v2_store.read().load_tip(&state_params).unwrap().expect("the tip loads");
            let second = carrier_of(TransactionOutpoint::new(carrier_id, 0), value - paid - fee, carrier_daa, false, paid / 2);
            let mempool = |tx: &Transaction| {
                let mut mutable = kaspa_consensus_core::tx::MutableTransaction::from_tx(tx.clone());
                ctx.consensus.validate_mempool_transaction(&mut mutable, &Default::default())
            };
            mempool(&second).expect("with room, the carrier is admitted");
            // **The V01 review's LOW 3: every node's per-block sweep asks the same gate** — nothing
            // while the queue has room, and a spent input is never the sweep's to judge.
            let pooled = std::sync::Arc::new(second.clone());
            assert_eq!(ctx.consensus.palw_market_carrier_refusals_v1(&[pooled.clone()]), vec![None], "room: the sweep keeps it");
            vp.palw_state_v2_store.write().set_tip_for_tests(sink, &full).expect("the full queue becomes the tip");
            match mempool(&second) {
                Err(kaspa_consensus_core::errors::tx::TxRuleError::PalwModelMarketNotEligible(why)) => {
                    assert!(why.contains("payout queue"), "{why}")
                }
                other => panic!("a full queue must refuse the carrier at the mempool, got {other:?}"),
            }
            match ctx.consensus.palw_market_carrier_refusals_v1(&[pooled.clone()]).as_slice() {
                [Some(why)] => assert!(why.contains("payout queue"), "the sweep refuses it as admission does: {why}"),
                other => panic!("a full queue must refuse the pooled carrier at the sweep, got {other:?}"),
            }
            let unfunded = {
                let mut tx = second.clone();
                tx.inputs[0].previous_outpoint = TransactionOutpoint::new(kaspa_consensus_core::tx::TransactionId::from_u64_word(0x51E), 0);
                tx.finalize();
                std::sync::Arc::new(tx)
            };
            assert_eq!(
                ctx.consensus.palw_market_carrier_refusals_v1(&[unfunded]),
                vec![None],
                "an input the virtual does not hold (mined, double-spent, chained): not judged"
            );
            assert_eq!(
                ctx.consensus.palw_h1_carrier_refusals_v1(&[pooled.clone()]),
                vec![None],
                "a market carrier is not the H-1 gate's to judge"
            );
            let template = ctx.consensus.build_block_template(
                new_miner_data(),
                Box::new(OnetimeTxSelector::new(vec![second.clone()])),
                TemplateBuildMode::Standard,
            );
            match template {
                Err(crate::errors::RuleError::InvalidTransactionsInNewBlock(invalid)) => assert!(
                    matches!(
                        invalid.get(&second.id()),
                        Some(kaspa_consensus_core::errors::tx::TxRuleError::PalwModelMarketNotEligible(_))
                    ),
                    "the template refuses the carrier on the queue: {invalid:?}"
                ),
                other => {
                    panic!("a full queue must keep the carrier out of the template, got {:?}", other.map(|t| t.block.header.hash))
                }
            }
            vp.palw_state_v2_store.write().set_tip_for_tests(sink, &real_tip).expect("the real tip is restored");
            mempool(&second).expect("room again: the same carrier is admitted");
        }

        // Follow the row to a coinbase: it drains after the claim and seat rows, which on this
        // short chain are few.
        let mut paid_back = false;
        for _ in 0..12 {
            let block = mine(&mut ctx, new_miner_data(), vec![]).await;
            if block.transactions[0].outputs.iter().any(|o| o.script_public_key == spk && o.value == paid) {
                assert_eq!(
                    ctx.consensus.block_status(block.header.hash),
                    BlockStatus::StatusUTXOValid,
                    "the coinbase that pays the refund is the one validation expects (construction == validation)"
                );
                paid_back = true;
                break;
            }
        }
        (row, paid_back, kaspa_hashes::Hash64::from_bytes(address_payload))
    }

    let (row, paid_back, payer) = run(Some(ForkActivation::always())).await;
    let Some((payee, amount)) = row else { panic!("past the fence the refused carrier is owed a refund row") };
    assert_eq!(payee, payer, "the refund pays the change script the payer signed — a key it can spend");
    assert!(amount > 0);
    assert!(paid_back, "and a coinbase pays it to that script");

    let (row, paid_back, _) = run(None).await;
    assert_eq!(row, None, "below the fence (testnet-11's shape) a refused carrier is folded exactly as before");
    assert!(!paid_back);
}

/// **A candidate this consensus cannot REACH is an absent opinion, not a dead node** (audit
/// 2026-09-02).
///
/// `palw_candidate_state_v2` walked straight into `calculate_chain_path`, which asks
/// `is_chain_ancestor_of`, which `unwrap`s the reachability lookup — a `KeyNotFound` there is a
/// panic, and the release profile turns a panic in virtual processing into `process::exit(1)`.
///
/// The reachable shape is a STAGING consensus. It is built `skip_adding_genesis`, so it holds no
/// virtual state row and `get_sink()` answers the all-zero hash, which is not a block; it DOES hold
/// a PALW tip, because the headers-proof IBD imports the peer's pruning-point carriage immediately
/// before asking this question. So the tip loaded, the candidate was a hash this consensus had
/// never seen, and every node taking that path died — a path a peer chooses for its victim by
/// advertising a chain whose pruning point the victim lacks.
///
/// `None` is the honest answer and the one every consumer already handles: a chain nobody could
/// weigh must not be ordered, and deliberately not as zero (see `palw_candidate_order_v2`).
#[tokio::test]
async fn palw_v2_an_unreachable_candidate_is_no_opinion_rather_than_a_panic() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    // Its own sink IS weighable, which is what makes everything below a statement about
    // reachability rather than about a bundle that is simply absent.
    assert!(vp.palw_candidate_order_v2(ctx.consensus.get_sink()).is_some(), "a V2 network weighs its own sink");

    // The all-zero hash — precisely what a staging consensus's `get_sink()` answers.
    for (name, candidate) in
        [("a staging consensus's empty sink", blockhash::NONE), ("a block we never heard of", BlockHash::from_u64_word(0xDEAD_BEEF))]
    {
        assert!(!vp.reachability_service.has_reachability_data(candidate), "{name}: the fixture must be unreachable");
        assert!(vp.palw_candidate_state_v2(candidate).is_none(), "{name}: no state, and no panic reaching for one");
        assert!(vp.palw_candidate_order_v2(candidate).is_none(), "{name}: and therefore no order");
    }
}

/// **The pruning ceiling fails CLOSED on what it cannot read, and OPEN only on what genuinely is
/// not there yet** (audit 2026-09-02).
///
/// `palw_pruning_point_allowed_v2` was one `.ok().flatten()`, which spells both answers the same
/// way: a `load_tip` that returns `Err` — a snapshot a disk corrupted, or one written by another
/// schema — became `None` became "every pruning point allowed". So the gate deleted the history
/// under trial exactly when it had lost the ability to weigh it, and an unresolved claim's
/// evidence and an open court's committed roots went with it. The deep-reorg gate beside it was
/// already fixed for this shape and records it in its own words.
///
/// Three cases, and the third is the one that keeps the fix from being a halt: `Ok(None)` — a V2
/// chain before its first tip — stays open, or a fresh node could never prune at all.
#[tokio::test]
async fn palw_v2_the_pruning_ceiling_fails_closed_on_a_tip_it_cannot_read() {
    use crate::model::stores::palw_state_v2::PalwStateTipRecordV2;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    // Genesis is the point a healthy V2 node still allows: its blue score is 0 and so is the safe
    // frontier of a chain whose first claims have not resolved. The sink is deliberately NOT used
    // — it is above the frontier, and the ceiling refusing it is the rule working, not a fault.
    let genesis = ctx.consensus.params().genesis.hash;
    assert!(vp.palw_pruning_point_allowed_v2(genesis), "a healthy node allows a point at its own frontier");

    // **(1) A point whose header this node does not hold.** The candidate's blue score is the only
    // thing the ceiling compares, so a missing header is a comparison that cannot be made — and
    // "cannot be made" was answered with "allowed".
    assert!(
        !vp.palw_pruning_point_allowed_v2(BlockHash::from_u64_word(0xDEAD_BEEF)),
        "a pruning point whose header is absent must be refused, not waved through"
    );

    // **(2) A tip row that will not load.** `set_tip_batch` computes the root from the state it is
    // handed, so a caller cannot store a snapshot under a root it does not hash to — the tamper
    // has to be written at the row level, which is exactly the threat: a disk, or a tool, editing
    // the bytes after the fact.
    let record = vp.palw_state_v2_store.read().tip_record().unwrap().expect("the healthy node holds a tip");
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("and it loads");
    let tampered = {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.safe_weight += 1;
        borsh::to_vec(&carriage).unwrap()
    };
    {
        let mut store = vp.palw_state_v2_store.write();
        store
            .set_tip_record_for_tests(PalwStateTipRecordV2 {
                block: record.block,
                state_root: record.state_root,
                carriage_borsh: tampered,
            })
            .expect("the fixture can corrupt its own row");
    }
    assert!(vp.palw_state_v2_store.read().load_tip(&bundle.state).is_err(), "the fixture is the unreadable case");
    assert!(
        !vp.palw_pruning_point_allowed_v2(genesis),
        "a frontier this node cannot compute must not authorise deleting the history it would have weighed"
    );

    // **(3) …and no tip at all is a different fact and stays OPEN.** A V2 chain before its first
    // tip has no frontier to respect; refusing here would mean a fresh node could never prune.
    {
        let mut store = vp.palw_state_v2_store.write();
        store.delete_tip_for_tests().expect("empty the store");
    }
    assert!(vp.palw_pruning_point_allowed_v2(genesis), "no state yet is not the same answer as unreadable state");
}

/// **A chunk the transition will refuse on its face completes nothing, and must not spend the
/// block's certification cap** (ADR-0075 D14, audit 2026-09-02).
///
/// The acceptance rehearsal counts an `ObjectChunk` against `PALW_CERTIFICATION_MAX_PER_BLOCK`
/// when it would complete its group, and it asked only `count == 1` for a group that does not
/// exist yet. So `ObjectChunk { group: anything, index: 5, count: 1 }` — sixty bytes, refused by
/// the transition as `ChunkIndexOutOfRange` — was charged as a grading, and two of them per block
/// exhaust the cap and drop every genuine `FamilyCertified` the block carries, for two ordinary
/// fees. Certification is how a family earns the right to bear weight, so a block-cheap way to
/// starve it is a block-cheap way to keep an honest class weightless.
///
/// **The index rule alone was not a rule.** `index: 0, count: 1` costs the identical sixty bytes,
/// is refused by the transition just as fast (`ChunkGroupHashMismatch`), and starves the identical
/// cap — so a guard that asks only `index < count` deletes a strictly dominated variant and buys
/// zero adversarial delta. What the cap is spent on is the `FamilyCertified` a completing chunk
/// carries, so the predicate has to be the transition's own completion test: parts assembled,
/// hashing to the declared group, decoding to a `FamilyCertified`. All three refusals are
/// exercised below, and each of them is charged with the fence off.
///
/// **Both sides of the fence are asserted.** Dormant — every shipped preset — the rehearsal is
/// byte-identical to the one before the field existed, which is the property that lets this reach
/// a running network by rolling deploy instead of splitting it.
#[tokio::test]
async fn palw_v2_a_malformed_chunk_does_not_spend_the_certification_cap() {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{PALW_CERTIFICATION_MAX_PER_BLOCK, PalwCertificationEvidenceV1, PalwConsensusObjectV2};
    use misaka_palw_base0::e2e_drill::{PalwRcFamilyV1, rc_attempt_evidence_v1, rc_free_prompt_evidence_v1};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let floor_attempt = rc_attempt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its attempt lane");
    let floor_fp = rc_free_prompt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its free-prompt lane");

    // **Every shape of sixty-byte chunk the transition refuses on its face**, each in front of two
    // ordinary graded drills. `index: 5` is out of range; `index: 0` with a mismatched group is
    // the one the index rule alone did nothing about; the third hashes correctly and simply is not
    // a `FamilyCertified`.
    let junk = vec![0u8; 8];
    let honest_group = kaspa_consensus_core::palw_state_v2::palw_object_chunk_group_id_v1(&junk);
    let bogus_chunks = [
        ("an index outside its own count", kaspa_hashes::Hash64::from_u64_word(0xC0FFEE), 5u8),
        ("a group id the bytes do not hash to", kaspa_hashes::Hash64::from_u64_word(0xC0FFEE), 0u8),
        ("bytes that hash right and are not a certification", honest_group, 0u8),
    ];

    let objects = |group: kaspa_hashes::Hash64, index: u8| {
        vec![
            PalwConsensusObjectV2::ObjectChunk { group, index, count: 1, bytes: vec![0u8; 8] },
            PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(floor_attempt.clone())) },
            PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::FreePrompt(floor_fp.clone())) },
        ]
    };

    let graded_with = |fence: Option<ForkActivation>, group: kaspa_hashes::Hash64, index: u8| {
        let bundle = bundle.clone();
        let state_params = bundle.state.clone();
        let objects = objects(group, index);
        async move {
            let config = ConfigBuilder::new(MAINNET_PARAMS)
                .skip_proof_of_work()
                .edit_consensus_params(move |p| {
                    p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
                    p.palw_chunk_cap_charge = fence;
                    *p = p.clone().with_palw_v2_cadence();
                })
                .build();
            let mut ctx = TestContext::new(TestConsensus::new(&config));
            for _ in 0..2 {
                ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
            }
            let vp = ctx.consensus.virtual_processor();
            let (_, state) = vp.palw_state_v2_store.read().load_tip(&state_params).unwrap().expect("the tip loads");
            let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
                block: ctx.consensus.get_sink(),
                daa_score: ctx.consensus.get_virtual_daa_score(),
                blue_score: 5,
                subsidy: 0,
            };
            let accepted = vp.palw_v2_accepted_objects_for_tests(&state, &state_params, &point, objects, ctx.consensus.get_sink());
            accepted.len()
        }
    };

    for (name, group, index) in bogus_chunks {
        // **Armed.** The chunk is refused by the transition and dropped, and both real drills are
        // still graded: the cap belongs to the objects that can spend it.
        assert_eq!(
            graded_with(Some(ForkActivation::always()), group, index).await,
            PALW_CERTIFICATION_MAX_PER_BLOCK,
            "{name}: a chunk the transition refuses on its face must not take a grading slot from a family that earned one"
        );

        // **Dormant — every shipped preset.** The old accounting, verbatim: the bogus chunk spends
        // a slot and one honest drill is dropped. Asserting it is what proves the fence is a fence
        // — and asserting it for all three shapes is what proves the fence buys an adversarial
        // delta rather than deleting a variant an attacker would never have chosen.
        assert_eq!(
            graded_with(None, group, index).await,
            PALW_CERTIFICATION_MAX_PER_BLOCK - 1,
            "{name}: fence-off must be byte-identical to today, or this is a silent rule change wearing an activation's clothes"
        );
    }
    assert!(MAINNET_PARAMS.palw_chunk_cap_charge.is_none(), "and every shipped preset leaves it dormant");
}

/// **A consensus with no virtual sink is a chain that can be WEIGHED, not one with no opinion**
/// (audit 2026-09-02, finding 1).
///
/// The reachability guard beside this stopped the `KeyNotFound` panic and stopped there. But
/// `None` is not "no opinion" at either consumer: `validate_staging_palw_order` answers
/// `(Some(_), None)` with a hard `ProtocolError` and `decide_deep_reorg_v2`'s site answers
/// `(None, _)` with `DominanceViolation`. And a STAGING consensus — every headers-proof IBD —
/// hands `get_palw_candidate_order_v2` the all-zero hash, because it is built
/// `skip_adding_genesis` and has no virtual state row. So the guard converted "every node on a V2
/// network dies mid-IBD" into "every node on a V2 network refuses IBD against every peer,
/// forever", and the pruning-point PALW import placed one line earlier so the challenger would be
/// a real value was dead work.
///
/// The staged chain's weighing point is the block whose PALW state this node actually verified:
/// the pruning point it just imported, which is the block the tip row names.
#[tokio::test]
async fn palw_v2_a_consensus_with_no_virtual_sink_is_weighed_at_its_imported_tip() {
    use crate::model::stores::palw_state_v2::PalwStateTipRecordV2;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();

    // A consensus that HAS a sink is weighed there, and nowhere else. The header download hint is
    // deliberately not consulted — it is a download heuristic and a fork-choice decision reading
    // it is P0-5.
    assert_eq!(vp.palw_weighing_point_v2(sink), Some(sink), "a live consensus is weighed at its own sink");

    // **The staging shape.** `blockhash::NONE` is exactly what `get_sink()` answers on a consensus
    // built `skip_adding_genesis`.
    let staged = vp
        .palw_weighing_point_v2(blockhash::NONE)
        .expect("a consensus with no virtual sink still holds a root-verified PALW tip, and that is its standing");
    let tip = vp.palw_state_v2_store.read().tip_record().unwrap().expect("the tip row").block;
    assert_eq!(staged, tip, "and the point it is weighed at is that tip — the deepest block whose PALW state was checked");
    let order = vp.palw_candidate_order_v2(staged).expect("which produces a real order, not an absent one");
    assert_eq!(order.candidate, staged, "candidate-scoped, so two staged chains cannot compare equal by construction");

    // **A tip row that will not read is NOT a weighing point.** A state fault must not become the
    // one opinion a sinkless consensus has; the IBD then refuses, which is the safe answer.
    let record = vp.palw_state_v2_store.read().tip_record().unwrap().expect("the healthy node holds a tip");
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("and it loads");
    let tampered = {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.safe_weight += 1;
        borsh::to_vec(&carriage).unwrap()
    };
    {
        let mut store = vp.palw_state_v2_store.write();
        store
            .set_tip_record_for_tests(PalwStateTipRecordV2 {
                block: record.block,
                state_root: record.state_root,
                carriage_borsh: tampered,
            })
            .expect("the fixture can corrupt its own row");
    }
    assert_eq!(
        vp.palw_weighing_point_v2(blockhash::NONE),
        None,
        "an unreadable snapshot is a fault, and a fault must not be the standing a chain is committed on"
    );
    // …and the sink path is untouched by the corruption: it is still a block, still weighed there.
    assert_eq!(vp.palw_weighing_point_v2(sink), Some(sink), "the fallback fires only where the sink is not a block at all");
}

/// **An unreadable tip REFUSES a deep reorg; it does not wave it through** (audit 2026-09-02,
/// finding 6).
///
/// `palw_candidate_state_v2` opened with one `.ok().flatten()` over `load_tip`, so a snapshot a
/// disk corrupted and "no V2 tip yet" were the same `None` — the exact conflation the pruning
/// ceiling four lines below was fixed for, left in place in the function the same commit edited.
/// It is not inert: `palw_frontier_provenance_outcome` reads `None` as `GateInactive`, which is
/// ALLOW, so ADR-0065 D2's veto abstained on a deep reorg precisely when it had lost the ability
/// to weigh one. A missing ancestor is a genuine absence and still abstains — that is the
/// permanent-partition escape the horizon paragraph argues for — but a store that will not read is
/// this node's own fault, and the honest answer to "may this reorg proceed" is no.
#[tokio::test]
async fn palw_v2_an_unreadable_tip_refuses_a_deep_reorg_rather_than_abstaining() {
    use crate::model::stores::palw_state_v2::PalwStateTipRecordV2;
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::dns_finality::DnsReorgOutcome;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            p.palw_frontier_provenance = Some(ForkActivation::always());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let candidate = ctx.consensus.get_sink();
    let prev_sink = vp.headers_store.get_header(candidate).unwrap().direct_parents()[0];

    // Healthy: the registry minted nothing across the fork point, so D2 has nothing to veto.
    assert_eq!(
        vp.palw_frontier_provenance_outcome(candidate, prev_sink),
        DnsReorgOutcome::GateInactive,
        "a chain that minted no bonds across the fork point is not what D2 is about"
    );

    // The same tamper the pruning ceiling's test uses: the row is written at the row level,
    // because `set_tip_batch` re-derives the root and a caller cannot store a mismatched one.
    let record = vp.palw_state_v2_store.read().tip_record().unwrap().expect("the healthy node holds a tip");
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("and it loads");
    let tampered = {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.safe_weight += 1;
        borsh::to_vec(&carriage).unwrap()
    };
    {
        let mut store = vp.palw_state_v2_store.write();
        store
            .set_tip_record_for_tests(PalwStateTipRecordV2 {
                block: record.block,
                state_root: record.state_root,
                carriage_borsh: tampered,
            })
            .expect("the fixture can corrupt its own row");
    }
    assert!(vp.palw_state_v2_store.read().load_tip(&bundle.state).is_err(), "the fixture is the unreadable case");
    assert_eq!(
        vp.palw_candidate_state_v2_checked(candidate),
        Err(crate::pipeline::virtual_processor::processor::PalwWeighFaultV2::StoreUnreadable),
        "the two reasons this node can answer nothing are told apart at the source"
    );
    assert_eq!(
        vp.palw_frontier_provenance_outcome(candidate, prev_sink),
        DnsReorgOutcome::FrontierProvenanceViolation,
        "a veto that cannot read its own evidence must refuse the reorg, not abstain into allowing it"
    );

    // …and an honest absence keeps abstaining, which is the half that stops this being a halt.
    {
        let mut store = vp.palw_state_v2_store.write();
        store.delete_tip_for_tests().expect("empty the store");
    }
    assert_eq!(
        vp.palw_candidate_state_v2_checked(candidate),
        Err(crate::pipeline::virtual_processor::processor::PalwWeighFaultV2::NoOpinion),
        "no tip yet is an absence, not a fault"
    );
    assert_eq!(
        vp.palw_frontier_provenance_outcome(candidate, prev_sink),
        DnsReorgOutcome::GateInactive,
        "and an absence still abstains, or a young chain could never reorg at all"
    );
}

/// **A delta row this node wrote and can no longer decode is a FAULT, not an abstention**
/// (audit 2026-09-02 round 3, finding 2).
///
/// The `.ok().flatten()` conflation was removed from `load_tip` and left one line below it:
/// `walk_chain_path(..).map_err(|_| NoOpinion)` collapsed `MissingDelta` — a pruned block, a
/// genuine absence — with `StoreError::DataInconsistency` from `load_delta`, which is a delta row
/// this node wrote and can no longer read. The store's own comment calls that "the same refusal by
/// another name — never absent", and the walk then spelled it as an absence anyway.
///
/// It is the same fail-open, one level down: `palw_frontier_provenance_outcome` reads `NoOpinion`
/// as `GateInactive`, which is ALLOW. So a node whose tip snapshot reads back perfectly and whose
/// delta rows are corrupt permitted the deep reorg it had just lost the ability to weigh.
#[tokio::test]
async fn palw_v2_an_undecodable_delta_refuses_a_deep_reorg_rather_than_abstaining() {
    use crate::model::stores::palw_state_v2::PalwStateDeltaRecordV2;
    use crate::pipeline::virtual_processor::processor::PalwWeighFaultV2;
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::dns_finality::DnsReorgOutcome;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            p.palw_frontier_provenance = Some(ForkActivation::always());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let candidate = ctx.consensus.get_sink();
    let prev_sink = vp.headers_store.get_header(candidate).unwrap().direct_parents()[0];

    // The tip stands AT the sink, so weighing the fork's other side reverts exactly the sink's own
    // delta — which is the row this test corrupts. Asserted rather than assumed: if the tip ever
    // moved off the sink, the walk below would touch a different row and the test would be about
    // nothing.
    let tip = vp.palw_state_v2_store.read().tip_record().unwrap().expect("the healthy node holds a tip").block;
    assert_eq!(tip, candidate, "the fixture's walk from the tip to the fork point reverts the sink's delta");

    // Healthy: both sides of the fork materialize, so D2 has an opinion and (nothing having been
    // minted across the fork) waves the reorg through.
    assert!(vp.palw_candidate_state_v2_checked(prev_sink).is_ok(), "a healthy node can weigh the fork point");
    assert_eq!(
        vp.palw_frontier_provenance_outcome(candidate, prev_sink),
        DnsReorgOutcome::GateInactive,
        "a chain that minted no bonds across the fork point is not what D2 is about"
    );

    // **The fault.** Written at the row level for the reason the tip test gives: every production
    // writer serializes the delta it is handed, so a caller cannot store bytes that do not decode
    // — the corruption has to arrive from underneath, which is exactly the threat.
    let root = vp.palw_state_v2_store.read().state_root_of(candidate).expect("the sink has a delta row");
    {
        let mut store = vp.palw_state_v2_store.write();
        store
            .set_delta_record_for_tests(candidate, PalwStateDeltaRecordV2 { state_root: root, delta_borsh: vec![0xff; 3] })
            .expect("the fixture can corrupt its own row");
    }
    assert!(
        matches!(vp.palw_state_v2_store.read().delta_of(candidate), Err(kaspa_database::prelude::StoreError::DataInconsistency(_))),
        "the fixture is the undecodable-row case, not the absent-row case"
    );
    assert_eq!(
        vp.palw_candidate_state_v2_checked(prev_sink),
        Err(PalwWeighFaultV2::StoreUnreadable),
        "a delta row that will not decode is this node's own fault, and the walk must say so"
    );
    assert_eq!(
        vp.palw_frontier_provenance_outcome(candidate, prev_sink),
        DnsReorgOutcome::FrontierProvenanceViolation,
        "a veto that cannot read its own delta rows must refuse the reorg, not abstain into allowing it"
    );

    // …and the absence half still abstains, which is what stops this being a halt: a pruned delta
    // is a fact this node legitimately does not hold, and refusing on it would be the
    // permanent-partition shape the horizon paragraph argues against.
    {
        let mut store = vp.palw_state_v2_store.write();
        store.delete_delta_for_tests(candidate).expect("empty the row");
    }
    assert!(
        matches!(vp.palw_state_v2_store.read().delta_of(candidate), Err(kaspa_database::prelude::StoreError::KeyNotFound(_))),
        "and now it is the absent-row case"
    );
    assert_eq!(
        vp.palw_candidate_state_v2_checked(prev_sink),
        Err(PalwWeighFaultV2::NoOpinion),
        "a delta this node does not hold is an absence, not a fault"
    );
    assert_eq!(
        vp.palw_frontier_provenance_outcome(candidate, prev_sink),
        DnsReorgOutcome::GateInactive,
        "and an absence still abstains, or a pruned node could never reorg at all"
    );
}

/// **An ungradeable certification must not starve the block's certification cap** (audit
/// 2026-09-02 round 3, findings 1 and 3).
///
/// The chunk rule closed a side door and left the front door open. `palw_v2_accepted_objects`
/// charged `PALW_CERTIFICATION_MAX_PER_BLOCK` to `matches!(object, FamilyCertified{..}) ||
/// completes_a_group` BEFORE `palw_v2_validate_objects` or the transition ever ran — so two
/// ordinary lifecycle transactions carrying a `FamilyCertified` the court refuses at its first
/// line (`NoVectors`, checked before a single fault vector is graded) spent the whole block's cap
/// and every genuine certification in that block was dropped. `FamilyCertified` rides an ordinary
/// transaction with no signature and no deposit, so nothing else stopped it, and the same objects
/// reach the identical outcome wrapped in an `ObjectChunk` whose bytes hash to the declared group
/// — through the new predicate rather than around it.
///
/// **The rule that binds is about WORK, not about turns.** A slot is what a certification the
/// grader ACCEPTED consumes; the CPU a block may demand is fault vectors, which is what the grader
/// actually spends time on, and an object it throws out before touching one costs nothing and must
/// take nothing. Both counters are asserted here, and both sides of the fence are.
#[tokio::test]
async fn palw_v2_an_ungradeable_certification_does_not_starve_the_block_cap() {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_CERTIFICATION_MAX_PER_BLOCK, PalwCertificationEvidenceV1, PalwConsensusObjectV2, palw_object_chunk_group_id_v1,
    };
    use misaka_palw_base0::e2e_drill::{PalwRcFamilyV1, rc_attempt_evidence_v1, rc_free_prompt_evidence_v1};

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 64);
    let floor_attempt = rc_attempt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its attempt lane");
    let floor_fp = rc_free_prompt_evidence_v1(PalwRcFamilyV1::Base0).expect("the floor drills its free-prompt lane");

    // **The attacker's object.** The floor's own drill with its fault vectors removed: the court
    // refuses it as `NoVectors`, before it grades anything, so it is free for every node to reject
    // — and free for a stranger to build, because certification carries no signature and no
    // deposit. Two of them per block was the whole attack.
    let ungradeable = {
        let mut drill = floor_attempt.clone();
        drill.vectors.clear();
        PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(drill)) }
    };
    let ungradeable_bytes = borsh::to_vec(&ungradeable).expect("a lifecycle object serializes");
    let ungradeable_group = palw_object_chunk_group_id_v1(&ungradeable_bytes);

    let honest = || {
        vec![
            PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::Attempt(floor_attempt.clone())) },
            PalwConsensusObjectV2::FamilyCertified { evidence: Box::new(PalwCertificationEvidenceV1::FreePrompt(floor_fp.clone())) },
        ]
    };
    // Both shapes the audit proved, each in front of the two honest drills: the DIRECT object,
    // which no fence covered at all, and the CHUNK carrying the same bytes with the group id they
    // really hash to, which the completion predicate accepts because it IS a certification.
    let direct = {
        let mut objects = vec![ungradeable.clone(), ungradeable.clone()];
        objects.extend(honest());
        objects
    };
    let chunked = {
        let chunk =
            PalwConsensusObjectV2::ObjectChunk { group: ungradeable_group, index: 0, count: 1, bytes: ungradeable_bytes.clone() };
        let mut objects = vec![chunk.clone(), chunk];
        objects.extend(honest());
        objects
    };

    let graded_with = |fence: Option<ForkActivation>, objects: Vec<PalwConsensusObjectV2>| {
        let bundle = bundle.clone();
        let state_params = bundle.state.clone();
        async move {
            let config = ConfigBuilder::new(MAINNET_PARAMS)
                .skip_proof_of_work()
                .edit_consensus_params(move |p| {
                    p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
                    p.palw_chunk_cap_charge = fence;
                    *p = p.clone().with_palw_v2_cadence();
                })
                .build();
            let mut ctx = TestContext::new(TestConsensus::new(&config));
            for _ in 0..2 {
                ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
            }
            let vp = ctx.consensus.virtual_processor();
            let (_, state) = vp.palw_state_v2_store.read().load_tip(&state_params).unwrap().expect("the tip loads");
            let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
                block: ctx.consensus.get_sink(),
                daa_score: ctx.consensus.get_virtual_daa_score(),
                blue_score: 5,
                subsidy: 0,
            };
            vp.palw_v2_accepted_objects_for_tests(&state, &state_params, &point, objects, ctx.consensus.get_sink()).len()
        }
    };

    for (name, objects) in [("a direct FamilyCertified the court refuses", direct), ("the same bytes riding as a chunk", chunked)] {
        // **Armed.** The ungradeable objects are dropped, and both real drills are still graded:
        // a slot belongs to a certification the grader accepted, and this one it never will.
        assert_eq!(
            graded_with(Some(ForkActivation::always()), objects.clone()).await,
            PALW_CERTIFICATION_MAX_PER_BLOCK,
            "{name}: an object the court refuses before grading a single fault vector must not take a slot from a family that earned one"
        );

        // **Dormant — every shipped preset.** The old accounting, verbatim: two ordinary lifecycle
        // transactions spend the whole cap and BOTH honest drills are dropped. Asserting it is
        // what proves the fence is a fence, and what makes the adversarial delta it buys a number
        // rather than a claim.
        assert_eq!(
            graded_with(None, objects).await,
            0,
            "{name}: fence-off must be byte-identical to today, or this is a silent rule change wearing an activation's clothes"
        );
    }
    assert!(MAINNET_PARAMS.palw_chunk_cap_charge.is_none(), "and every shipped preset leaves it dormant");
}

/// **ADR-0135: every genesis class the binary can describe has a work for the registry** — the
/// devnet's shipped ruleset registers its classes with no admission carriage (their profiles are
/// the catalog's), so the works come from the canonical class table, base class included, and a
/// class the table does not carry is absent rather than invented.
#[test]
fn adr0135_the_registry_describes_the_genesis_classes_from_the_canonical_table() {
    use kaspa_consensus_core::config::params::devnet_shipped_params;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2;
    let params = devnet_shipped_params();
    let PalwConsensusMode::ConsensusV2(bundle) = &params.palw_consensus_mode else { panic!("the devnet ruleset is V2") };
    let genesis: Vec<_> = bundle
        .genesis_objects
        .iter()
        .filter_map(|o| match o {
            PalwConsensusObjectV2::ClassRegistered { class_id, admission, .. } => Some((*class_id, admission.is_some())),
            _ => None,
        })
        .collect();
    assert!(!genesis.is_empty(), "the premise: the devnet registers classes at genesis");
    let base = bundle.state.base_class_id();
    assert!(
        genesis.iter().any(|(id, carried)| *id == base && !carried),
        "the premise: the floor is registered without an admission carriage (it is derived, not declared)"
    );
    let config = ConfigBuilder::new(params.clone()).skip_proof_of_work().build();
    let consensus = TestConsensus::new(&config);
    let works = consensus.virtual_processor().palw_known_model_works_v1();
    let floor = works.get(&base).expect("the floor is described: derived, every node has it");
    assert!(floor.ops_supported && floor.verification_ccu > 0 && floor.economic_ccu_per_claim > 0, "{floor:?}");
    for (class_id, _) in &genesis {
        assert!(works.contains_key(class_id), "genesis class {class_id} is described from the canonical table");
    }
    assert_eq!(consensus.virtual_processor().palw_known_model_works_v1(), works, "derived once, answered the same again");
}

/// **The processor's refutation ladder comes from `palw_court_ladder`, and from nothing else**
/// (ADR-0084 §7.5; mainnet audit 2026-09-06, M-15).
///
/// The merge of the DA-court and model-market branches left two ladder fences on `Params` —
/// `palw_context_ladder` (ADR-0077 Phase B) and `palw_court_ladder` (ADR-0084 U-08) — arming the
/// same idea at the same call sites on two branches. Nothing in the tree bound either to the
/// processor that reads one of them, so a carded mainnet armed the wrong one and its court walked
/// at `2^22` while its classes were admitted at `2^26`.
///
/// Three arms, and the middle one is the whole test: arming the OTHER ladder must not move this
/// answer.
#[test]
fn the_processor_resolves_the_refutation_ladder_from_palw_court_ladder_alone() {
    use kaspa_consensus_core::config::params::{ForkActivation, devnet_shipped_params};
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_step_leg::PALW_STEP_LEG_MAX_LEAVES;

    let court_of = |p: &kaspa_consensus_core::config::params::Params| match &p.palw_consensus_mode {
        PalwConsensusMode::ConsensusV2(b) => b.court,
        _ => panic!("the fixture must be V2"),
    };

    let case = |mutate: fn(&mut kaspa_consensus_core::config::params::Params)| {
        let mut params = devnet_shipped_params();
        mutate(&mut params);
        let court = court_of(&params);
        let config = ConfigBuilder::new(params).skip_proof_of_work().build();
        let consensus = TestConsensus::new(&config);
        let answer = consensus.virtual_processor().palw_court_step_ladder_at(0, &court);
        (answer, court.max_step_leaf_count())
    };

    // The premise: the ruleset admits deeper than the walkers' constant.
    let (dormant, ruleset_ladder) = case(|p| {
        p.palw_court_ladder = None;
        p.palw_context_ladder = None;
    });
    assert!(ruleset_ladder > PALW_STEP_LEG_MAX_LEAVES, "the premise: {ruleset_ladder} vs {PALW_STEP_LEG_MAX_LEAVES}");
    assert_eq!(dormant, PALW_STEP_LEG_MAX_LEAVES, "both dormant: the walkers' constant");

    // **ADR-0077 Phase B's fence is a different rule and must not answer this question.**
    let (context_only, _) = case(|p| {
        p.palw_court_ladder = None;
        p.palw_context_ladder = Some(ForkActivation::always());
    });
    assert_eq!(
        context_only, PALW_STEP_LEG_MAX_LEAVES,
        "palw_context_ladder must not move the refutation ladder: it gates class admission (ADR-0077 Phase B), and the \
         fence ADR-0084 §7.5 names for this walk is palw_court_ladder"
    );

    let (armed, ruleset_ladder) = case(|p| p.palw_court_ladder = Some(ForkActivation::always()));
    assert_eq!(armed, ruleset_ladder, "armed: the ruleset's own ladder, which is the value a class was admitted at");
}

/// **A `RequestPruningPointPalwState` costs the serving node one materialization per captured
/// snapshot, and a hash it never captured costs it nothing** (mainnet audit H-1).
///
/// Forty bytes on the wire, reachable by any peer that completed the p2p handshake, with no
/// operator opt-in and no `--profile` to turn it off. The serve used to run `load_pruning_snapshot`
/// — a borsh decode of the whole carriage, two index rebuilds, two consistency walks and a full
/// `state_root()` — and compare the peer's hash afterwards, and then run a SECOND full tip
/// materialization for the class declarations whose result the not-found arm threw away.
///
/// This measures the node's cost in carriage bytes decoded, which is the only form of the claim
/// that a later refactor cannot quietly falsify. The rule: `wrong hash ⇒ zero`, `right hash ⇒ one
/// row's worth however many times it is asked`, and the answer identical to the pre-patch
/// expression each time — because the requester verifies its root against the pruning point's own
/// header, so a serve that is merely equivalent is a serve that fails IBD.
#[tokio::test]
async fn palw_v2_a_pruning_point_state_request_costs_one_materialization_and_a_wrong_hash_costs_none() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let (tip, _) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    vp.capture_pruning_point_palw_state(tip);

    const CALLS: usize = 64;
    let wrong = kaspa_consensus_core::BlockHash::from_u64_word(0xBAD);
    assert_ne!(wrong, tip);

    // **A hash this node did not capture must be answered without touching the state.**
    let tip_before = vp.palw_state_v2_store.read().tip_bytes_decoded();
    let snapshot_before = vp.palw_state_v2_store.read().pruning_snapshot_bytes_decoded();
    for _ in 0..CALLS {
        assert!(vp.pruning_point_palw_state(wrong).is_none(), "a point this node never captured answers not-found");
    }
    assert_eq!(
        vp.palw_state_v2_store.read().pruning_snapshot_bytes_decoded(),
        snapshot_before,
        "{CALLS} forty-byte requests for a hash we do not hold each bought a full snapshot materialization"
    );
    assert_eq!(
        vp.palw_state_v2_store.read().tip_bytes_decoded(),
        tip_before,
        "…and each bought a second one, for class declarations the not-found reply never carries"
    );

    // **The captured point costs one row's worth however often it is asked for, and the bytes are
    // the ones the uncached expression produced.**
    // The pre-patch expression, verbatim, as the reference answer. `load_pruning_snapshot` keeps
    // its own uncached shape and does not touch the serve counter, so this does not perturb the
    // measurement below.
    let expected = {
        let store = vp.palw_state_v2_store.read();
        let (block, state) = store.load_pruning_snapshot(&bundle.state).unwrap().expect("the snapshot is captured");
        assert_eq!(block, tip);
        PalwStateCarriageV2::from_state(&state)
    };
    let one_carriage = vp.palw_state_v2_store.read().pruning_snapshot_record().unwrap().unwrap().carriage_borsh.len() as u64;
    let snapshot_before = vp.palw_state_v2_store.read().pruning_snapshot_bytes_decoded();
    for _ in 0..CALLS {
        let served = vp.pruning_point_palw_state(tip).expect("the captured snapshot is servable");
        assert_eq!(served, expected, "the served carriage is not the one the uncached path produced");
    }
    assert_eq!(
        vp.palw_state_v2_store.read().pruning_snapshot_bytes_decoded() - snapshot_before,
        one_carriage,
        "{CALLS} serves of one captured snapshot decoded more than one carriage"
    );

    // **And the declarations that ride with it are one tip read, not one per request** (ADR-0067
    // Decision 6's serving half, which the same flow calls).
    let tip_before = vp.palw_state_v2_store.read().tip_bytes_decoded();
    let first = vp.palw_class_carriages_for_sync_v1_impl();
    for _ in 1..CALLS {
        assert_eq!(vp.palw_class_carriages_for_sync_v1_impl(), first, "two serves of the declaration set disagreed");
    }
    let tip_grew = vp.palw_state_v2_store.read().tip_bytes_decoded() - tip_before;
    assert!(
        tip_grew <= vp.palw_state_v2_store.read().tip_record().unwrap().unwrap().carriage_borsh.len() as u64,
        "{CALLS} declaration serves materialized the tip more than once ({tip_grew} B)"
    );
}

/// **No read-side `palw_*_impl` takes an uncached tip materialization** (audit M-7, re-opened by
/// mainnet audit H-1).
///
/// These are the answers `ConsensusApi` hands the RPC service and the p2p serve flows, so each
/// uncached read is a borsh decode of the whole carriage, `rebuild_deadline_free_indices`,
/// `rebuild_deadline_index_v2`, two consistency walks and a full `state_root()` against a request
/// of a couple of hundred bytes from a caller that authenticated to nothing.
///
/// Two halves, because neither alone states the rule:
///
/// * the MEASUREMENT drives the read paths and asserts the node decoded one carriage in total, so
///   a loader that stops sharing fails whatever the source looks like;
/// * the ALLOWLIST names every `load_tip` caller left in the production source. `load_tip` is the
///   right read for the fold and restart paths — they materialize in order to WALK or to WRITE and
///   need an owned state — and the wrong one everywhere else, and a seventeenth read path added on
///   it turns this red the day it is added, including the one impl below the measurement cannot
///   call (`palw_court_close_verdict_v2_impl` needs a full `PalwCourtVerdictProofV2`, whose
///   `PalwStepBindingV2` has no cheap constructor outside consensus-core's own `cfg(test)`).
#[tokio::test]
async fn palw_v2_no_read_side_impl_takes_an_uncached_tip_materialization() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let class_id = kaspa_hashes::Hash64::from_u64_word(1);
    let bond_key = {
        let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
        state.bonds_iter().next().map(|(key, _)| *key).expect("the genesis registry seated bonds")
    };
    let mine = [bond_key];

    // The tip has to be materialized once before the baseline, or the first call below pays for
    // the cold cache and the number under test becomes "two carriages" for a reason that is not
    // the finding.
    let _ = vp.palw_state_v2_store.read().load_tip_cached(&bundle.state).unwrap();
    let baseline = vp.palw_state_v2_store.read().tip_bytes_decoded();

    // The fifteen read-side impls that are callable with cheap arguments, in the order the
    // production source declares them. Every one of them reaches its tip read before it looks at
    // its arguments, so the values here only have to be well-formed.
    let _ = vp.palw_disputable_claims_v2_impl(&mine);
    // Lane B (2026-09-26): the operator's non-seat filer's read, once a DAA on every operator node.
    let _ = vp.palw_operator_da_candidates_v1_impl(&mine);
    let _ = vp.palw_operator_da_standing_v1_impl(&mine[0]);
    let _ = vp.palw_court_duties_v2_impl(&mine);
    let _ = vp.palw_da_duties_v2_impl(&mine);
    let _ = vp.palw_claim_readers_v2_impl(kaspa_hashes::Hash64::from_u64_word(0xC1A1));
    let _ = vp.palw_bond_payout_payload_v2_impl(&bond_key);
    let _ = vp.palw_v2_class_table_impl();
    let _ = vp.palw_bond_of_pubkey_v2_impl(&[7u8; 4]);
    let _ = vp.palw_v2_registration_terms_impl();
    let _ = vp.palw_registered_class_carriage_v1_impl(class_id);
    let _ = vp.palw_class_carriages_for_sync_v1_impl();
    let _ = vp.palw_adopt_class_carriage_v1_impl(class_id, &[]);
    let _ = vp.palw_seat_duties_v2_impl(&mine);
    let _ = vp.palw_producer_facts_v2_impl(class_id, Some(bond_key.0));
    let _ = vp.palw_fp_spendable_v3_impl(bond_key.0);
    let _ = vp.palw_locked_bond_outpoints_v2_impl();
    let _ = vp.palw_v2_receipt_quorum_assemble_impl(kaspa_hashes::Hash64::from_u64_word(0xC1A1), &[]);
    // ADR-0152 P2-10: claim row v3 and `getPalwVesting` (op 199) — every query shape, each a read
    // of the one cached tip.
    for with_vesting in [false, true] {
        let _ = vp.palw_claim_rows_v1_impl(
            bond_key,
            kaspa_consensus_core::palw_producer_v2::PalwClaimRoleV1::Executor,
            true,
            0,
            with_vesting,
        );
    }
    {
        use kaspa_consensus_core::palw_vesting_read_v1::{PalwVestingPayeeV1, PalwVestingQueryV1};
        for query in [
            PalwVestingQueryV1::Chain,
            PalwVestingQueryV1::Payee(PalwVestingPayeeV1::Bond(bond_key)),
            PalwVestingQueryV1::Payee(PalwVestingPayeeV1::Payload(kaspa_hashes::Hash64::from_u64_word(0xB0B))),
            PalwVestingQueryV1::Claim(kaspa_hashes::Hash64::from_u64_word(0xC1A1)),
        ] {
            assert!(vp.palw_vesting_v1_impl(query, 0, None).is_some(), "a ConsensusV2 node answers {query:?}");
        }
    }

    let one_carriage = vp.palw_state_v2_store.read().tip_record().unwrap().unwrap().carriage_borsh.len() as u64;
    let grew = vp.palw_state_v2_store.read().tip_bytes_decoded() - baseline;
    assert_eq!(
        grew,
        0,
        "the read-side impls decoded {grew} B of carriage ({} materializations of {one_carriage} B) for one unmoved tip",
        grew / one_carriage.max(1)
    );

    // **The allowlist.** `load_tip` is for the callers that walk or write; every other caller in
    // this file is a read path and must take `load_tip_cached`. Adding a name here is a deliberate
    // act, which is the point — the sixteen sites above were converted one audit at a time exactly
    // because nothing made the boundary visible.
    const OWNED_STATE_CALLERS: &[&str] = &[
        "calculate_utxo_state_relatively",
        "evm_template_fields",
        "calculate_virtual_state",
        "palw_candidate_state_v2_checked",
        "palw_weighing_point_v2",
        "palw_pruning_point_allowed_v2",
        "capture_pruning_point_palw_state",
    ];
    let source = include_str!("processor.rs");
    let mut enclosing = String::new();
    let mut found: Vec<String> = Vec::new();
    for line in source.lines() {
        let trimmed = line.trim_start();
        if let Some(rest) = trimmed
            .strip_prefix("pub(crate) fn ")
            .or_else(|| trimmed.strip_prefix("pub(super) fn "))
            .or_else(|| trimmed.strip_prefix("pub fn "))
            .or_else(|| trimmed.strip_prefix("fn "))
        {
            enclosing = rest.split(['(', '<']).next().unwrap_or_default().to_string();
        }
        if line.contains(".load_tip(") {
            found.push(enclosing.clone());
        }
    }
    found.sort();
    found.dedup();
    let mut allowed: Vec<String> = OWNED_STATE_CALLERS.iter().map(|s| s.to_string()).collect();
    allowed.sort();
    assert_eq!(
        found, allowed,
        "a `load_tip` caller in virtual_processor/processor.rs is not one of the fold/restart paths. A READ path \
         must take `load_tip_cached`; a new walk-or-write path belongs in OWNED_STATE_CALLERS."
    );
}

/// **The 2026-09-23 Position route matrix, P-B3: the template asks the market gate the mempool
/// asks** (the review's MEDIUM point). A carrier admitted to the mempool while its class served can
/// be in the pool when the class regresses (Probation → Held); only a template-time check keeps
/// this node from mining it into a fold that drops it. Pinned on the source: both
/// `validate_mempool_transaction_impl` and `validate_block_template_transaction` call
/// `palw_mempool_market_refusal`, the one function that asks `palw_model_market_carrier_refusal_v1`.
#[test]
fn p_b3_the_template_asks_the_market_gate_the_mempool_asks() {
    let source = include_str!("processor.rs");
    let body_of = |name: &str| -> String {
        let start = source.find(&format!("fn {name}(")).unwrap_or_else(|| panic!("{name} exists"));
        let rest = &source[start..];
        let end = rest[1..].find("\n    fn ").or_else(|| rest[1..].find("\n    pub")).map(|i| i + 1).unwrap_or(rest.len());
        rest[..end].to_string()
    };
    for caller in ["validate_mempool_transaction_impl", "validate_block_template_transaction"] {
        assert!(
            body_of(caller).contains("self.palw_mempool_market_refusal("),
            "{caller} must ask the P-B3 market gate (palw_mempool_market_refusal)"
        );
    }
    assert!(
        body_of("palw_mempool_market_refusal_with").contains("palw_model_market_carrier_refusal_v1("),
        "the gate is the core predicate the fold's refusal is tested against"
    );
    // The V01 review's LOW 3: and every node's mempool sweep at each new block — the gate's own
    // fence and layers, on the one snapshot the H-1 sweep takes.
    let gate = body_of("palw_mempool_market_refusal");
    assert!(gate.contains("self.palw_market_gated_at(") && gate.contains("self.palw_mempool_market_refusal_with("));
    let sweep = body_of("palw_market_carrier_refusals_v1_impl");
    assert!(sweep.contains("self.palw_sweep_snapshot_v1(txs)"), "the H-1 sweep's snapshot");
    assert!(sweep.contains("self.palw_market_gated_at(") && sweep.contains("self.palw_mempool_market_refusal_with("));
    assert!(body_of("palw_h1_carrier_refusals_v1_impl").contains("self.palw_sweep_snapshot_v1(txs)"));
}

/// **ADR-0152 v3.1 H-1 (P2-9 review, finding 5): the template asks the H-1 gate the mempool asks,
/// and the gate asks the fold** — the acceptance layer and the object's own arm, the two halves the
/// block's rehearsal runs. Pinned on the source for P-B3's reason: deleting either call leaves every
/// behavioural test that drives only the other one green.
#[test]
fn h1_the_template_asks_the_carrier_gate_the_mempool_asks() {
    let source = include_str!("processor.rs");
    let body_of = |name: &str| -> String {
        let start = source.find(&format!("fn {name}(")).unwrap_or_else(|| panic!("{name} exists"));
        let rest = &source[start..];
        let end = rest[1..].find("\n    fn ").or_else(|| rest[1..].find("\n    pub")).map(|i| i + 1).unwrap_or(rest.len());
        rest[..end].to_string()
    };
    for caller in ["validate_mempool_transaction_impl", "validate_block_template_transaction"] {
        assert!(
            body_of(caller).contains("self.palw_mempool_h1_carrier_refusal("),
            "{caller} must ask the H-1 carrier gate (palw_mempool_h1_carrier_refusal)"
        );
    }
    // V01 (the 2026-09-25 sweep): and every node's mempool sweep at each new block — the gate's own
    // two steps (its object, then its layers on a tip), on the one snapshot the sweep checked
    // against the virtual (the V01 review, MEDIUM).
    for asker in ["palw_mempool_h1_carrier_refusal", "palw_h1_carrier_refusals_v1_impl"] {
        let body = body_of(asker);
        assert!(body.contains("self.palw_h1_gated_object_at("), "{asker} takes the gate's object");
        assert!(body.contains("self.palw_mempool_h1_carrier_refusal_with("), "{asker} asks the gate's layers");
    }
    assert!(body_of("palw_mempool_h1_carrier_refusal_with").contains("self.palw_h1_carrier_refusal_on("));
    let on = body_of("palw_h1_carrier_refusal_on");
    assert!(on.contains("self.palw_v2_validate_objects("), "the acceptance layer");
    assert!(on.contains("palw_v2_apply_one_object_v1("), "and the fold's own arm");
}

/// **`getPalwProducerFacts` answers from one tip materialization, not two per call** (mainnet
/// audit M-5).
///
/// The RPC ran `palw_locked_bond_outpoints_v2` and then `palw_producer_facts_v2`, both on the
/// uncached loader, both synchronously on an RPC reactor thread, and both above the class-id parse
/// — so a caller who fat-fingered a class id had already bought two full PALW-state
/// materializations before it was told its request was malformed.
///
/// This is the consensus half of that repair and it states the rule rather than the patch: the two
/// answers are unchanged across every call, and the node decodes one carriage in total for an
/// unmoved tip. It fails the moment either impl goes back to an uncached read, in either order.
#[tokio::test]
async fn palw_v2_the_producer_facts_read_paths_materialize_the_tip_once_per_tip() {
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let vp = ctx.consensus.virtual_processor();
    let class_id = kaspa_hashes::Hash64::from_u64_word(1);
    let bond_key = {
        let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
        state.bonds_iter().next().map(|(key, _)| *key).expect("the genesis registry seated bonds")
    };

    const CALLS: usize = 64;
    let _ = vp.palw_state_v2_store.read().load_tip_cached(&bundle.state).unwrap();
    let baseline = vp.palw_state_v2_store.read().tip_bytes_decoded();

    let first_facts = vp.palw_producer_facts_v2_impl(class_id, Some(bond_key.0));
    let first_outpoints = vp.palw_locked_bond_outpoints_v2_impl();
    for _ in 1..CALLS {
        // Interleaved, because the two used to be separate materializations and a cache shared by
        // only one of them would still pass a test that ran them in two blocks.
        assert_eq!(vp.palw_producer_facts_v2_impl(class_id, Some(bond_key.0)), first_facts, "the producer facts changed");
        assert_eq!(vp.palw_locked_bond_outpoints_v2_impl(), first_outpoints, "the locked-bond set changed");
    }

    let one_carriage = vp.palw_state_v2_store.read().tip_record().unwrap().unwrap().carriage_borsh.len() as u64;
    let grew = vp.palw_state_v2_store.read().tip_bytes_decoded() - baseline;
    assert_eq!(
        grew,
        0,
        "{CALLS} interleaved producer-facts reads decoded {grew} B of carriage ({} materializations of {one_carriage} B) \
         for one unmoved tip",
        grew / one_carriage.max(1)
    );
    assert!(!first_outpoints.is_empty(), "the fixture must actually have locked collateral, or the measurement is vacuous");
}

/// **An exhausted sink search HOLDS; it does not kill the node.**
///
/// `sink_search_algorithm` seeds its heap from `tips` and grows it only by parents at or above the
/// finality point, so the heap empties exactly when the walk reached the finality frontier with no
/// UTXO-valid candidate. That used to end in `expect("valid sink must exist")` — the process died
/// and the log named nothing, which is how a 2026-09-07 field report of three identical crashes on
/// `testnet-main-65e6a80e` arrived with no way to tell which wall the search hit.
///
/// The empty-tips call is the smallest instance of that shape: nothing to pop on the first
/// iteration. Virtual must come back sitting on the previous sink, with no candidates and with the
/// diff walked back to it, so the caller's `pick_virtual_parents(prev_sink, [])` and
/// `utxo_multisets_store.get(prev_sink)` still find what they need.
#[tokio::test]
async fn an_exhausted_sink_search_holds_at_the_previous_sink() {
    use crate::model::stores::{
        pruning::PruningStoreReader, utxo_multisets::UtxoMultisetsStoreReader, virtual_state::VirtualStateStoreReader,
    };
    let config = ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..3).validate_and_insert_row().await.assert_valid_utxo_tip();

    let vp = ctx.consensus.virtual_processor();
    let pruning_point = vp.pruning_point_store.read().pruning_point().unwrap();
    let virtual_read = vp.virtual_stores.upgradable_read();
    let prev_state = virtual_read.state.get().unwrap();
    let prev_sink = prev_state.ghostdag_data.selected_parent;
    let finality_point = vp.virtual_finality_point(&prev_state.ghostdag_data, pruning_point);
    let mut diff = prev_state.utxo_diff.clone().to_reversed();
    let mut bond_view = vp.initial_active_bond_view();

    // No tips at all: the heap is empty before the first pop, which is the exhaustion path.
    let (sink, candidates) =
        vp.sink_search_algorithm(&virtual_read, &mut diff, &mut bond_view, prev_sink, vec![], finality_point, pruning_point);

    assert_eq!(sink, prev_sink, "an exhausted search must hold virtual where it was");
    assert!(candidates.is_empty(), "and merge nothing while it holds");
    assert!(vp.utxo_multisets_store.get(sink).is_ok(), "the held sink must still be one the caller can read a multiset for");
}

/// **A gap between the stored PALW tip and the walk's base is this node's problem, and it must not
/// be charged to the chain.**
///
/// `calculate_utxo_state_relatively` needs the V2 state at `from`. When the tip row stands
/// elsewhere it walks the deltas between them — and when one of those deltas is missing it used to
/// return `from`, which is the same answer it gives for "this candidate is UTXO-disqualified".
/// The sink search calls it once per candidate, so a single missing delta disqualified every block
/// the search could reach; virtual walked back to the finality frontier and the search then died on
/// an empty heap. That is the 2026-09-07 field report, and it reproduced on every start because the
/// store stayed in that shape.
///
/// The pruning snapshot is a second base: a state at a block the candidates descend from, with a
/// delta on every chain block above it. This drives exactly the broken shape — tip elsewhere, its
/// delta deleted — and demands the walk still get past `from` on the snapshot and re-apply every
/// delta it holds: to the block below the deleted one, and, asked for that block, exactly to it.
#[tokio::test]
async fn a_missing_delta_under_the_tip_is_recovered_from_the_pruning_snapshot() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;

    let catalog = palw_v2_test_catalog();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(palw_v2_test_bundle(&catalog));
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let state_params = match &config.params.palw_consensus_mode {
        PalwConsensusMode::ConsensusV2(bundle) => bundle.state.clone(),
        _ => unreachable!(),
    };
    let genesis_hash = config.params.genesis.hash;

    let consensus = TestConsensus::new(&config);
    // The snapshot a live node writes at its pruning point is a state IT HELD. Capture the real
    // genesis state before the chain moves, rather than synthesising one: a bare `genesis()` is a
    // different state from the one this bundle installs, and the deltas would not apply to it.
    let genesis_state = {
        let store = consensus.virtual_processor().palw_state_v2_store.read();
        let (block, state) = store.load_tip(&state_params).unwrap().expect("a V2 network installs its genesis tip");
        assert_eq!(block, genesis_hash, "the zero point stands at genesis");
        state
    };

    let mut ctx = TestContext::new(consensus);
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let sink = ctx.consensus.get_sink();
    let vp = ctx.consensus.virtual_processor();
    let tip_block = {
        let store = vp.palw_state_v2_store.read();
        store.tip_record().unwrap().expect("the walk wrote a tip").block
    };
    assert_ne!(tip_block, genesis_hash, "the fixture must have advanced, or the walk has nothing to cross");
    {
        let mut store = vp.palw_state_v2_store.write();
        store.set_pruning_snapshot_for_tests(genesis_hash, &genesis_state).expect("the snapshot is planted");
        // Break the tip's own path: reverting it needs its delta, and the delta is gone.
        store.delete_delta_for_tests(tip_block).expect("the delta is deleted");
    }

    // The walk from genesis to the sink now has no usable tip base. It must still land on `to`.
    let virtual_read = vp.virtual_stores.upgradable_read();
    let mut diff = kaspa_consensus_core::utxo::utxo_diff::UtxoDiff::default();
    let mut bond_view = vp.initial_active_bond_view();
    // Two failures are staged at once and each has its own answer, so the assertions separate them.
    let reached = vp.calculate_utxo_state_relatively(&virtual_read, &mut diff, &mut bond_view, genesis_hash, sink);

    // 1. The BASE. Reverting the tip needs the delta that is gone, so the tip is not a usable base;
    //    the pruning snapshot is, and the walk got past `from` on the strength of it. Without that
    //    recovery this call returns `from` immediately and this assertion is what fails.
    assert_ne!(reached, genesis_hash, "the walk must rebuild its base from the pruning snapshot, not give up at {genesis_hash}");
    assert!(
        ctx.consensus.reachability_service().is_chain_ancestor_of(reached, sink),
        "whatever it reached must be on the chain it was asked to walk"
    );

    // 2. And it walks every row it holds. The recovery is not a partial one: with the base rebuilt,
    //    the forward leg re-applies the chain's stored deltas up to the one this fixture deleted —
    //    the tip's own, which is the sink's — and stops BELOW it, at the last block whose PALW state
    //    it established. It used to return the sink itself here, one block past its PALW state (the
    //    UTXO diff and `diff_point` were advanced before the apply that failed), which is the shape
    //    that panicked the sink search when the block so returned had no other way to its state
    //    (ADR-0152 Phase 2, P2-3 review; `p2_a_damaged_row_the_forward_leg_must_reapply_holds_the_old_sink`).
    //    The process being alive to assert it is the other half — the missing row used to reach an
    //    `expect` on this path.
    assert_eq!(tip_block, sink, "the tip row stands at the sink, so the deleted delta is the sink's own");
    let below = vp.ghostdag_store.get_selected_parent(sink).unwrap();
    assert_eq!(reached, below, "the rebuilt base carries the walk to {below}, the last block before the deleted row");

    // 3. And it arrives: asked for the block below the gap, the walk (from the same broken tip, on
    //    the same snapshot) returns exactly that block.
    let mut diff = kaspa_consensus_core::utxo::utxo_diff::UtxoDiff::default();
    let mut bond_view = vp.initial_active_bond_view();
    let reached = vp.calculate_utxo_state_relatively(&virtual_read, &mut diff, &mut bond_view, genesis_hash, below);
    assert_eq!(reached, below, "the rebuilt base must carry the walk all the way to {below}");
    let _ = state_params;
}

/// ADR-0109 test fixture: a consensus whose imported virtual UTXO set holds the given deposit locks
/// (`(seed, block_daa_score)` each), under `policy`. Returns each lock's outpoint and the claim it is.
#[cfg(feature = "evm")]
fn consensus_with_deposit_locks(
    policy: kaspa_consensus_core::evm::EvmBridgeFinalityPolicy,
    locks: &[(u64, u64)],
) -> (TestConsensus, Vec<JoinHandle<()>>, Vec<(TransactionOutpoint, kaspa_consensus_core::evm::DepositClaim)>) {
    use kaspa_consensus_core::evm::{DepositClaim, EvmAddress};
    use kaspa_consensus_core::header::Header;
    use kaspa_consensus_core::muhash::MuHashExtensions;
    use kaspa_consensus_core::tx::UtxoEntry;
    use kaspa_muhash::MuHash;
    use kaspa_txscript::script_class::evm_deposit_lock_script;

    let refund_spk = p2pkh_mldsa87_spk(&[0x42; 64]);
    let mut initial_utxos = Vec::new();
    let mut claims = Vec::new();
    for (i, (seed, daa)) in locks.iter().enumerate() {
        let evm_addr = [0xA0 + i as u8; 20];
        let amount = 1000 + i as u64;
        let lock_spk = evm_deposit_lock_script(evm_addr, 1_000_000, 7, refund_spk.script());
        let outpoint = TransactionOutpoint::new((*seed).into(), 0);
        initial_utxos.push((outpoint, UtxoEntry { amount, script_public_key: lock_spk, block_daa_score: *daa, is_coinbase: false }));
        claims.push((
            outpoint,
            DepositClaim {
                deposit_outpoint: outpoint,
                evm_address: EvmAddress::from_bytes(evm_addr),
                amount_sompi: amount,
                claim_tip_sompi: 7,
            },
        ));
    }
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| p.evm_activation_daa_score = 0)
        .apply_args(|cfg| {
            cfg.evm_bridge_finality = policy;
            let mut ms = MuHash::new();
            initial_utxos.iter().for_each(|(op, u)| ms.add_utxo(op, u));
            cfg.params.genesis.utxo_commitment = ms.finalize();
            let genesis_header: Header = (&cfg.params.genesis).into();
            cfg.params.genesis.hash = genesis_header.hash;
        })
        .build();
    let consensus = TestConsensus::new(&config);
    let wait_handles = consensus.init();
    let mut genesis_ms = MuHash::new();
    consensus.append_imported_pruning_point_utxos(&initial_utxos, &mut genesis_ms);
    consensus.import_pruning_point_utxo_set(config.genesis.hash, genesis_ms).unwrap();
    (consensus, wait_handles, claims)
}

#[cfg(feature = "evm")]
fn unasked_template(consensus: &TestConsensus, queued: Vec<kaspa_consensus_core::evm::DepositClaim>) -> BlockTemplate {
    use kaspa_consensus_core::evm::{EvmAddress, EvmTemplateData};
    consensus
        .build_block_template_with_evm(
            MinerData::new(p2pkh_mldsa87_spk(&[0u8; 64]), vec![]),
            Box::new(OnetimeTxSelector::new(Default::default())),
            TemplateBuildMode::Standard,
            EvmTemplateData { evm_coinbase: EvmAddress::from_bytes([0xCB; 20]), transactions: vec![], system_ops: queued },
        )
        .unwrap()
}

/// ADR-0109 Decision 1 (I-1): a lock in the virtual UTXO set is claimed by the next template with NO
/// queued claim — the index path, filled by the pruning-point import that put the lock in the set.
/// Under `Label` (the default) no DNS anchor needs to be fresh for it. Under `Pause` the behaviour
/// before ADR-0109 holds: a stale anchor empties the payload.
#[tokio::test]
#[cfg(feature = "evm")]
async fn evm_producer_claims_every_accepted_lock_unasked() {
    use kaspa_consensus_core::evm::{EvmBridgeFinalityPolicy, EvmSystemOp};
    kaspa_core::log::try_init_logger("info");

    let (consensus, wait_handles, claims) = consensus_with_deposit_locks(EvmBridgeFinalityPolicy::Label, &[(99, 0)]);
    let template = unasked_template(&consensus, vec![]);
    assert_eq!(
        template.block.evm_payload.system_ops,
        vec![EvmSystemOp::DepositClaim(claims[0].1.clone())],
        "the lock is claimed unasked, and no anchor had to be fresh for it"
    );
    assert_eq!(template.block.header.evm_payload_hash, template.block.evm_payload.payload_hash(), "header commits the claim payload");
    consensus.shutdown(wait_handles);

    let (consensus, wait_handles, _claims) = consensus_with_deposit_locks(EvmBridgeFinalityPolicy::Pause, &[(99, 0)]);
    let stale = unasked_template(&consensus, vec![]);
    assert!(stale.block.evm_payload.is_empty(), "Pause: a stale anchor keeps the payload empty, as before ADR-0109");
    consensus.shutdown(wait_handles);
}

/// ADR-0109 Decision 1 (I-3): the template's claims are the index's, oldest lock first, and a claim
/// the queue also holds is carried once.
#[tokio::test]
#[cfg(feature = "evm")]
async fn evm_template_claims_oldest_lock_first_and_once() {
    use kaspa_consensus_core::evm::{EvmBridgeFinalityPolicy, EvmSystemOp};
    kaspa_core::log::try_init_logger("info");

    // seed 5 is the NEWER lock (DAA 50), seed 3 the older (DAA 30); the queue holds the newer's claim.
    let (consensus, wait_handles, claims) = consensus_with_deposit_locks(EvmBridgeFinalityPolicy::Label, &[(5, 50), (3, 30)]);
    let template = unasked_template(&consensus, vec![claims[0].1.clone()]);
    assert_eq!(
        template.block.evm_payload.system_ops,
        vec![EvmSystemOp::DepositClaim(claims[1].1.clone()), EvmSystemOp::DepositClaim(claims[0].1.clone())],
        "oldest lock first; the queued claim the index also holds appears once"
    );
    consensus.shutdown(wait_handles);
}

/// ADR-0109 Decision 1 (I-2): the index follows the virtual UTXO diff — an added lock enters, an added
/// plain output does not, a removed lock leaves — and a rebuild makes it equal to the set's locks.
#[tokio::test]
#[cfg(feature = "evm")]
async fn evm_deposit_lock_index_follows_the_virtual_utxo_diff() {
    use crate::model::stores::evm::EvmDepositLockStoreReader;
    use kaspa_consensus_core::tx::UtxoEntry;
    use kaspa_consensus_core::utxo::utxo_diff::UtxoDiff;
    use kaspa_txscript::script_class::evm_deposit_lock_script;
    use rocksdb::WriteBatch;

    let config =
        ConfigBuilder::new(MAINNET_PARAMS).skip_proof_of_work().edit_consensus_params(|p| p.evm_activation_daa_score = 0).build();
    let consensus = TestConsensus::new(&config);
    let wait_handles = consensus.init();
    let vp = consensus.virtual_processor().clone();
    assert!(vp.evm_deposit_lock_store.read().is_built(), "init builds the index once on a database that lacks it");
    assert!(vp.evm_deposit_lock_store.read().all().unwrap().is_empty());

    let refund_spk = p2pkh_mldsa87_spk(&[0x42; 64]);
    let lock_entry = |daa: u64| UtxoEntry {
        amount: 1000,
        script_public_key: evm_deposit_lock_script([0xAB; 20], 1_000_000, 7, refund_spk.script()),
        block_daa_score: daa,
        is_coinbase: false,
    };
    let plain_entry =
        UtxoEntry { amount: 5, script_public_key: p2pkh_mldsa87_spk(&[0x11; 64]), block_daa_score: 5, is_coinbase: false };
    let lock_op = TransactionOutpoint::new(7u64.into(), 0);
    let plain_op = TransactionOutpoint::new(8u64.into(), 1);

    // added: the lock enters, the plain output does not
    let mut diff = UtxoDiff::default();
    diff.add.insert(lock_op, lock_entry(5));
    diff.add.insert(plain_op, plain_entry.clone());
    let mut batch = WriteBatch::default();
    vp.stage_evm_deposit_locks(&mut batch, &diff);
    vp.db.write(batch).unwrap();
    let all = vp.evm_deposit_lock_store.read().all().unwrap();
    assert_eq!(all.len(), 1, "one lock, no plain output");
    assert_eq!(all[0].0, lock_op);
    let record = &all[0].1;
    assert_eq!(
        (record.amount_sompi, record.claim_tip_sompi, record.timeout_daa_score, record.block_daa_score),
        (1000, 7, 1_000_000, 5)
    );
    assert_eq!(record.evm_address, kaspa_consensus_core::evm::EvmAddress::from_bytes([0xAB; 20]));

    // removed: the lock leaves; a removed plain output touches nothing
    let mut diff = UtxoDiff::default();
    diff.remove.insert(lock_op, lock_entry(5));
    diff.remove.insert(plain_op, plain_entry.clone());
    let mut batch = WriteBatch::default();
    vp.stage_evm_deposit_locks(&mut batch, &diff);
    vp.db.write(batch).unwrap();
    assert!(vp.evm_deposit_lock_store.read().all().unwrap().is_empty(), "the removed lock left the index");

    // rebuilt: what the virtual set holds is what the index holds
    {
        let mut virtual_write = vp.virtual_stores.write();
        let mut diff = UtxoDiff::default();
        diff.add.insert(lock_op, lock_entry(9));
        diff.add.insert(plain_op, plain_entry);
        let mut batch = WriteBatch::default();
        virtual_write.utxo_set.write_diff_batch(&mut batch, &diff).unwrap();
        vp.db.write(batch).unwrap();
        vp.rebuild_evm_deposit_lock_index(&virtual_write.utxo_set);
    }
    let all = vp.evm_deposit_lock_store.read().all().unwrap();
    assert_eq!(all.len(), 1);
    assert_eq!((all[0].0, all[0].1.block_daa_score), (lock_op, 9), "the rebuild read the set, not the old index");
    consensus.shutdown(wait_handles);
}

/// ADR-0109 Decision 3 (I-5): the input a mempool transaction is refused for is the one spending a
/// locked PALW bond, and a transaction with free inputs names nothing.
#[test]
fn first_locked_input_names_the_locked_bond_spend() {
    use kaspa_consensus_core::subnets::SUBNETWORK_ID_NATIVE;
    use kaspa_consensus_core::tx::TransactionInput;
    let free = TransactionOutpoint::new(1u64.into(), 0);
    let bond = TransactionOutpoint::new(2u64.into(), 0);
    let tx = |outpoints: &[TransactionOutpoint]| {
        Transaction::new(
            crate::constants::TX_VERSION,
            outpoints.iter().map(|o| TransactionInput::new(*o, vec![], 0, 1)).collect(),
            vec![],
            0,
            SUBNETWORK_ID_NATIVE,
            0,
            vec![],
        )
    };
    let locked: std::collections::HashSet<TransactionOutpoint> = [bond].into_iter().collect();
    assert_eq!(super::processor::first_locked_input(&tx(&[free, bond]), &locked), Some(bond));
    assert_eq!(super::processor::first_locked_input(&tx(&[free]), &locked), None);
    assert_eq!(super::processor::first_locked_input(&tx(&[bond]), &Default::default()), None, "an empty registry locks nothing");
}

/// **A-1 (Critical) — the acceptance rehearsal and the real block fold disagree at a class's
/// activation-crossing block, so one accepted list permanently halts the chain.**
///
/// `palw_v2_accepted_objects` (the acceptance FILTER) rehearses each object by folding it through
/// the WHOLE block transition at a synthetic point — `apply_palw_transition_v2_with_extras`, whose
/// step 3a `activate_due_classes` runs AFTER the objects. So when the block reaches a class X's
/// `activation_daa`, the FIRST accepted object's own rehearsal transition already flipped X to
/// `Active` in the folded state, and a later `ClassLaneCertified{X}` — which the transition admits
/// only for an `Active` class — is validated against that and ACCEPTED.
///
/// The real fold the pipeline runs on the chain candidate (`apply_palw_transition_v7` over the
/// accepted list) applies every object to the PARENT state, where step 3a has not run yet: at the
/// `ClassLaneCertified` X is still `Registered`, the transition returns
/// `CertificationNeedsActiveClass`, and the whole block is `StatusDisqualifiedFromChain` on every
/// node. The filter's one contract — "what it returns, the transition applies" — is broken exactly
/// at the crossing, and the chain cannot advance past the parent.
///
/// The regression asserts the SAFE invariant (the accepted list folds without error), so on the
/// audited commit it FAILS. It also exhibits the concrete effect: the fold's error is
/// `CertificationNeedsActiveClass`, which is what disqualifies the block.
///
/// The two accepted objects are the finding's minimum: a leading object whose rehearsal transition
/// crosses the activation (here a partial `ObjectChunk`, which the real pipeline always has an
/// analogue of — a derived `PanelBound` or a 0x4a `FreePromptCommitted` is ordered ahead of every
/// lifecycle object), then the `ClassLaneCertified`. Drop the leading object and the filter
/// correctly refuses the binding, which is why "an object accepted before it" is load-bearing.
#[tokio::test]
async fn the_acceptance_filter_output_always_folds_at_a_class_activation_crossing() {
    use kaspa_consensus_core::palw_class_admission_v2::reachable_kernels_v1;
    use kaspa_consensus_core::palw_e2e_adjudicability::{PalwE2eCoveringV1, PalwE2eFamilyV1, palw_e2e_family_id_v1};
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{
        PalwBlockContextV2, PalwCertifiedFamilyStateV2, PalwCertifiedLaneV1, PalwChainStateV2, PalwConsensusObjectV2,
        PalwDeltaEntryV2, PalwPwuRuleV2, PalwStateDeltaV2, PalwStateV2Error, apply_delta_v2, apply_palw_transition_v2,
    };
    use kaspa_hashes::Hash64;

    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            // A-1 lives past the audit flag day; arm it so the filter folds the fold's step 3.
            p.palw_audit_2026_09_11 = Some(kaspa_consensus_core::config::params::ForkActivation::always());
        })
        .build();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    let vp = ctx.consensus.virtual_processor();

    // The post-genesis class X the block activates: a real, shippable profile so its id is its
    // graph and a chain-certified family can cover it (the finding's precondition).
    let profile =
        kaspa_consensus_core::palw_base0_profile::base0_profile_v1(kaspa_consensus_core::palw_base0_profile::PALW_RC_BASE0_GEOMETRY)
            .expect("the floor's profile projects");
    let class_x = profile.shape_profile_id();

    let point = |word: u64, daa: u64, blue: u64| PalwBlockContextV2 {
        block: Hash64::from_u64_word(word),
        daa_score: daa,
        blue_score: blue,
        subsidy: 0,
    };

    // S: the parent state at the moment before the crossing. The base class Active, and X
    // Registered with a FUTURE activation (weightless, so its grant is a no-op and cannot fail).
    let genesis = PalwChainStateV2::genesis();
    let base = PalwConsensusObjectV2::ClassRegistered {
        class_id: bundle.base_class_id,
        artifact_root: Hash64::from_u64_word(0xA7),
        slash_value_per_pwu: 5,
        pwu_rule: PalwPwuRuleV2::MaxPerAttempt(160),
        initial_target: u128::MAX / 2,
        share_permille: 1000,
        activation_daa: 0,
        admission: None,
    };
    let (s1, _) = apply_palw_transition_v2(&genesis, &bundle.state, &point(1, 100, 1), &[base], None).expect("the base registers");
    let register_x = PalwConsensusObjectV2::ClassRegistered {
        class_id: class_x,
        artifact_root: Hash64::from_u64_word(0xB0),
        slash_value_per_pwu: 5, // the network's one slash value (the base's), or the transition refuses it
        pwu_rule: PalwPwuRuleV2::MaxPerAttempt(160),
        initial_target: u128::MAX / 2,
        share_permille: 0,   // weightless
        activation_daa: 105, // in the future relative to registration at daa 101
        admission: None,
    };
    let (s2, _) =
        apply_palw_transition_v2(&s1, &bundle.state, &point(2, 101, 2), &[register_x], None).expect("X registers, not yet active");
    assert!(
        matches!(
            s2.class(&class_x).map(|c| &c.status),
            Some(kaspa_consensus_core::palw_state_v2::PalwClassStatusV2::Registered { .. })
        ),
        "X must be Registered (not yet Active) going into the crossing block: {:?}",
        s2.class(&class_x).map(|c| c.status.clone())
    );

    // A chain-certified free-prompt family that covers X's reachable kernels — installed as state
    // (rooted, carried, reverted) exactly as `a_chain_certified_class_takes_fp_commitments...` does,
    // so `ClassLaneCertified`'s coverage check has a family to find.
    let family = PalwE2eFamilyV1 {
        family_id: palw_e2e_family_id_v1("A1-COVER"),
        drilled_class_id: class_x,
        kernel_ids: reachable_kernels_v1(&profile),
        covering: PalwE2eCoveringV1 { convicted_leaves: 6, ..Default::default() },
    };
    let digest = family.digest();
    let delta = PalwStateDeltaV2 {
        point: point(2, 101, 2),
        entries: vec![PalwDeltaEntryV2::CertifiedFamily {
            lane: PalwCertifiedLaneV1::FreePrompt,
            key: digest,
            old: None,
            new: Some(PalwCertifiedFamilyStateV2 { family, certified_daa: 101 }),
        }],
    };
    let s = apply_delta_v2(&s2, &delta, &bundle.state).expect("the covering family installs");

    // The crossing block at daa 105: a leading object (a partial chunk the fold accepts) followed by
    // the binding. In a real block the leading object is a derived `PanelBound` or a 0x4a commitment,
    // ordered ahead of all lifecycle objects; a partial `ObjectChunk` stands in for "any object the
    // fold accepts first", and like them it triggers `activate_due_classes` in its rehearsal step.
    let leading =
        PalwConsensusObjectV2::ObjectChunk { group: Hash64::from_u64_word(0x00C0_00DE), index: 0, count: 2, bytes: vec![0xAB] };
    let bind = PalwConsensusObjectV2::ClassLaneCertified {
        class_id: class_x,
        lane: PalwCertifiedLaneV1::FreePrompt,
        profile: Box::new(profile),
    };
    let crossing = point(3, 105, 3);

    // The FILTER, driven for real: it rehearses each object through the whole transition, so the
    // leading object's step 3a flips X Active before the binding is judged, and both are accepted.
    let (accepted, _folded_sequentially) = vp.palw_v2_accepted_objects_and_state_for_tests(
        &s,
        &bundle.state,
        &crossing,
        vec![leading.clone(), bind.clone()],
        crossing.block,
    );
    // THE INVARIANT (A-1 fix): the filter now predicts the fold's step 3, so the ClassLaneCertified
    // for a class that only becomes `Active` at this block's step 3a is DROPPED here — the leading
    // object is kept, the block stands, and the chain advances.
    assert_eq!(
        accepted.len(),
        1,
        "the filter must drop the ClassLaneCertified at the activation crossing (X is Active only at step 3a, after \
         the objects) and keep the leading object. Got {accepted:?}"
    );
    assert!(
        matches!(accepted[0], PalwConsensusObjectV2::ObjectChunk { .. }),
        "the surviving object is the leading one, not the binding: {accepted:?}"
    );

    // The filter's one contract: what it returns, the REAL one-shot fold applies on the parent
    // without error — so the block is not disqualified and the chain does not halt.
    let folded = vp.palw_v2_block_fold_for_tests(&s, &bundle.state, &crossing, &accepted);
    assert!(
        folded.is_ok(),
        "A-1: the filter's accepted list must fold on the parent without error, or every node disqualifies the block \
         and the chain halts. Fold error: {:?}",
        folded.err(),
    );

    // WHY the binding is dropped, pinned as a positive control: the fold refuses it alone with the
    // activation-ordering error the finding names — X is still Registered when step 3 reaches it.
    let bind_alone = vp.palw_v2_block_fold_for_tests(&s, &bundle.state, &crossing, std::slice::from_ref(&bind));
    assert!(
        matches!(&bind_alone, Err(PalwStateV2Error::CertificationNeedsActiveClass { class }) if *class == class_x),
        "the dropped binding is refused by the fold with CertificationNeedsActiveClass, got {bind_alone:?}"
    );
}

// ===================================================================================
#[tokio::test]
async fn palw_v2_a_quantum_spent_twice_in_one_mergeset_is_paid_once() {
    use crate::model::stores::ghostdag::{GhostdagData, HashKTypeMap};
    use kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for;
    use kaspa_consensus_core::palw_freeprompt_v3::{PALW_FP_V3_VERSION, PalwReceiptSpendUnsignedV3, fp_quantum_ticket_v3};
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_pwu::palw_ticket_admits_v1;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_RECEIPT_TARGET_SEED_V1, PalwBlockContextV2, PalwBlockWorkV3, PalwBondKeyV2, PalwChainStateV2, PalwClaimPhaseV2,
        PalwConsensusObjectV2 as Obj, PalwMergedWorkV1, PalwPanelSeatV2, PalwPwuRuleV2, PalwStateParamsV2, PalwTransitionExtrasV1,
        apply_palw_transition_v2, apply_palw_transition_v7,
    };
    use kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
    use kaspa_consensus_core::tx::{TransactionId, TransactionOutpoint};
    use kaspa_consensus_core::{BlockHashMap, BlockHashSet, blockhash::BlockHashes};
    use kaspa_hashes::Hash64;

    let h64 = Hash64::from_u64_word;

    // ---- 1. A V2+FP chain on DEVNET windows (receipt maturity 20) so the draw beacon
    //         sits at a low DAA and the chain need only be a couple dozen blocks. The
    //         harness registry (row 0 = the harness ML-DSA identity, bond (0xB0,0)) is the
    //         one `palw_v2_test_carriage`/`palw_v3_test_receipt_carriage_for` sign under. ----
    let catalog = palw_v2_test_catalog();
    let bundle = {
        let registry = {
            let mut registry = kaspa_consensus_core::palw_fp_devnet_v3::palw_devnet_bond_registry_v1(
                kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1(),
            );
            registry[0].pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey();
            registry[0].operator_pubkey = vec![21u8; 8];
            for (i, row) in registry.iter_mut().enumerate().skip(1) {
                row.pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_registry_pubkey(i as u64);
            }
            registry
        };
        let mut b = kaspa_consensus_core::palw_fp_devnet_v3::palw_fp_bundle_with_windows_v3(
            h64(1),
            catalog.root(),
            h64(0xC0757),
            4_096,
            h64(0xA7),
            registry,
            &kaspa_consensus_core::palw_fp_devnet_v3::PALW_DEVNET_WINDOWS_V1,
        )
        .expect("the devnet-windowed harness bundle validates");
        b.class_catalog_root = catalog.root();
        // Fund every genesis bond generously — every mined attempt block reserves exposure, and
        // a couple dozen concurrent claims must fit. `verify_palw_genesis_v2` (the UTXO-backing
        // gate) does not run on this construction path, exactly as `palw_v2_test_bundle_funded_for`.
        for object in b.genesis_objects.iter_mut() {
            if let Obj::BondRegistered { collateral, .. } = object {
                *collateral = 1u64 << 60;
            }
        }
        b
    };
    let maturity = bundle.freeprompt.receipt_maturity_daa();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            // B-5's pay-once dedup lives past the audit flag day; arm it.
            p.palw_audit_2026_09_11 = Some(kaspa_consensus_core::config::params::ForkActivation::always());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    let net_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // ---- 2. A standalone certified (Final) free-prompt claim state, built with the SAME harness
    //         bond identity (bond (0xB0,0), harness pubkey) so a spend's signature and the
    //         `bond.pubkey == producer_pubkey` check pass. This is the `state` the coinbase pay-set
    //         predicate is evaluated against — the selected parent's state, where the quantum is
    //         still unspent. Built through the public transition API only; no production change. ----
    let harness_bond = TransactionOutpoint::new(TransactionId::from_u64_word(0xB0), 0);
    let harness_bond_key = PalwBondKeyV2(harness_bond);
    let harness_pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey();
    let base_class = h64(1);
    let inj_params =
        PalwStateParamsV2::new(100, 1, 1, 1, 500, 1_000, base_class, 4, 1_000, 100, 1_000, 0).unwrap().with_fp_quanta(8, 64).unwrap();
    let build_injected = |claim_id: Hash64| -> PalwChainStateV2 {
        let cx = |w: u64, daa: u64, blue: u64| PalwBlockContextV2 { block: h64(w), daa_score: daa, blue_score: blue, subsidy: 0 };
        let reg = vec![
            Obj::ClassRegistered {
                class_id: base_class,
                artifact_root: h64(11),
                slash_value_per_pwu: 5,
                pwu_rule: PalwPwuRuleV2::MaxPerAttempt(160),
                initial_target: u128::MAX / 2,
                share_permille: 1000,
                activation_daa: 0,
                admission: None,
            },
            Obj::BondRegistered {
                bond: harness_bond_key,
                pubkey: harness_pubkey.clone(),
                operator_pubkey: vec![21u8; 8],
                collateral: 1u64 << 40,
                payout_payload: h64(0x9A11),
                capable_classes: Default::default(),
                signature: Vec::new(),
            },
        ];
        let (s1, _) = apply_palw_transition_v2(&PalwChainStateV2::genesis(), &inj_params, &cx(1, 1, 1), &reg, None).unwrap();
        let commit = Obj::FreePromptCommitted {
            job_pin: kaspa_hashes::Hash64::default(),
            eval: None,
            claim: claim_id,
            class_id: base_class,
            bond: harness_bond_key,
            executor_pubkey: harness_pubkey.clone(),
            work_leaves: 60,
            prompt_token_ids_hash: h64(0x7E),
            // ADR-0145 §5's two execution facts, unread below the derived-work fence — which this
            // harness is, since it drives `apply_palw_transition_v2` directly.
            prompt_tokens: 0,
            prompt_token_ids: Vec::new(),
            decode_tokens_executed: 3,
            trace_root: h64(41),
            output_root: h64(42),
            execution_root: h64(43),
            trace_chunk_count: 4,
            trace_retention_daa: 999_999,
            consumed_prefix_state: kaspa_consensus_core::palw_freeprompt_v3::PalwFpPrefixStateV1::genesis(base_class),
        };
        let (s2, _) = apply_palw_transition_v2(&s1, &inj_params, &cx(2, 2, 2), &[commit], None).unwrap();
        let seats = vec![PalwPanelSeatV2 { bond: harness_bond_key, operator_id: h64(90) }];
        let (s3, _) = apply_palw_transition_v2(
            &s2,
            &inj_params,
            &cx(3, 3, 3),
            &[Obj::PanelBound { claim: claim_id, anchor: h64(77), seats }],
            None,
        )
        .unwrap();
        let (s4, _) = apply_palw_transition_v2(
            &s3,
            &inj_params,
            &cx(4, 4, 4),
            &[Obj::ReceiptLicensed { claim: claim_id, receipts: Vec::new() }],
            None,
        )
        .unwrap();
        let (s5, _) = apply_palw_transition_v2(&s4, &inj_params, &cx(5, 6, 5), &[], None).unwrap();
        s5
    };

    // final_daa is deterministic (6) from the walk above; the draw slot is final_daa + maturity.
    let probe = build_injected(h64(0xFC));
    let final_daa = match &probe.claim(&h64(0xFC)).expect("the fixture certifies a claim").phase {
        PalwClaimPhaseV2::Final { final_daa } => *final_daa,
        other => panic!("the fixture must reach Final, got {other:?}"),
    };
    let slot = final_daa + maturity;

    // ---- 3. Mine attempt blocks until the chain reaches the draw slot, so a beacon exists. ----
    while ctx.consensus.get_virtual_daa_score() < slot + 2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let tip = ctx.consensus.get_sink();
    let vp = ctx.consensus.virtual_processor();
    let beacon = vp.palw_beacon_fact_of_candidate(tip, slot).expect("the chain reached the draw slot, so a beacon derives");

    // A claim id whose quantum-0 ticket admits under the receipt-lane seed target (MAX/2).
    let claim_id = (0u64..2_000)
        .map(|i| h64(0xFC00 + i))
        .find(|cid| palw_ticket_admits_v1(fp_quantum_ticket_v3(net_domain, beacon.beacon_block, *cid, 0), PALW_RECEIPT_TARGET_SEED_V1))
        .expect("some claim id wins the receipt lottery under the seed target");
    let injected = build_injected(claim_id);

    // ---- 4. Two receipt-lane (algo-7) siblings on the SAME parent, each a different block
    //         (nonce/timestamp) but both spending the SAME quantum 0 of the SAME claim, each with a
    //         real ML-DSA-87 signature and the correct draw beacon. Cheap to make; the header gate
    //         accepts both. ----
    let mut receipts: Vec<Hash64> = Vec::new();
    for (nonce, ts_bump) in [(0xA1u64, 100u64), (0xA2u64, 200u64)] {
        let mut r = ctx.consensus.build_block_with_parents_and_transactions(blockhash::NONE, vec![tip], vec![]);
        r.header.timestamp = ctx.simulated_time + ts_bump;
        r.header.nonce = nonce;
        r.header.pow_algo_id = POW_ALGO_ID_PALW_RECEIPT_V3;
        r.header.palw_commitment =
            ctx.consensus.palw_v3_test_receipt_carriage_for(&r.header, true, claim_id, 0, harness_bond, beacon.beacon_block);
        r.header.finalize();
        let hash = r.header.hash;
        // The header signature gate accepts a correctly signed spend; the block enters the DAG as a
        // side block (it never becomes the selected chain — receipt blocks carry 0 blue work).
        let _ = ctx.consensus.validate_and_insert_block(r.to_immutable()).virtual_state_task.await;
        receipts.push(hash);
    }
    let (r1, r2) = (receipts[0], receipts[1]);

    let point = PalwBlockContextV2 { block: h64(0xC0DE), daa_score: beacon.beacon_daa, blue_score: 1 << 20, subsidy: 0 };
    let non_daa = BlockHashSet::default();
    let anticone = || HashKTypeMap::new(BlockHashMap::default());

    // ---- Positive control: a SINGLE valid receipt spend is entitled (paid) — so the harness truly
    //      produces a spend the pay set accepts. If this failed, an empty result below would be
    //      "both rejected", not "both paid". ----
    let gd_one = GhostdagData::new(0, Default::default(), tip, BlockHashes::new(vec![tip]), BlockHashes::new(vec![r1]), anticone());
    let unentitled_one = vp.palw_v2_unentitled_blues(&injected, &gd_one, &non_daa, &point);
    assert!(
        unentitled_one.is_empty(),
        "positive control: one valid receipt spend must be entitled (paid), so the fixture really produces a valid spend; \
         got unentitled={unentitled_one:?}"
    );

    // ---- The finding: TWO siblings spending ONE quantum in one mergeset. ----
    let gd = GhostdagData::new(0, Default::default(), tip, BlockHashes::new(vec![tip]), BlockHashes::new(vec![r1, r2]), anticone());
    let unentitled = vp.palw_v2_unentitled_blues(&injected, &gd, &non_daa, &point);

    // Concrete effect: BOTH receipt siblings are paid (neither marked unentitled).
    let both_paid = !unentitled.contains(&r1) && !unentitled.contains(&r2);

    // Contrast — the FOLD does resolve the conflict: it applies one spend and skips the other with
    // QuantumAlreadySpent, so the quantum's weight is added exactly once. The pay set below does
    // NOT share this dedup, which is the whole finding.
    let unsigned = |challenge: u64| PalwReceiptSpendUnsignedV3 {
        version: PALW_FP_V3_VERSION,
        network_domain: net_domain,
        challenge: h64(challenge),
        claim_id,
        quantum_index: 0,
        beacon_block: beacon.beacon_block,
        producer_bond: harness_bond,
        producer_pubkey: harness_pubkey.clone(),
    };
    let (spend_a, spend_b) = (unsigned(0xAAAA), unsigned(0xBBBB));
    let merged = vec![
        PalwMergedWorkV1 {
            carrying_block: r1,
            work: PalwBlockWorkV3::ReceiptSpend(&spend_a),
            execution_key: Default::default(),
            subsidy: 0,
            escrow_carve: None,
            bits: 0,
            job_anchor: kaspa_hashes::Hash64::default(),
        },
        PalwMergedWorkV1 {
            carrying_block: r2,
            work: PalwBlockWorkV3::ReceiptSpend(&spend_b),
            execution_key: Default::default(),
            subsidy: 0,
            escrow_carve: None,
            bits: 0,
            job_anchor: kaspa_hashes::Hash64::default(),
        },
    ];
    let fold_point = PalwBlockContextV2 { block: h64(0xF01D), daa_score: 7, blue_score: 6, subsidy: 0 };
    let (folded, _delta, merged_skips) = apply_palw_transition_v7(
        &injected,
        &inj_params,
        None,
        &fold_point,
        &[],
        PalwBlockWorkV3::None,
        &merged,
        // B-4 own-work key: no own attempt here (block_work None), so default.
        Default::default(),
        false,
        false,
        false,
        false,
        &PalwTransitionExtrasV1::default(),
    )
    .expect("the fold applies");
    assert_eq!(merged_skips.len(), 1, "the FOLD resolves the double spend: one applied, one skipped (QuantumAlreadySpent)");
    assert!(folded.safe_weight() > injected.safe_weight(), "the fold folds exactly one quantum's weight");

    // ---- SAFE invariant (fails on 5bed4405 iff the finding is real): of two merged receipt
    //      siblings spending ONE quantum, exactly one may be paid; the other is the double spend and
    //      must be `unentitled`. On this commit the receipt arm of `palw_v2_unentitled_blues` has no
    //      dedup, so the set is EMPTY and both are paid — one certified quantum minting two full
    //      worker shares. ----
    assert_eq!(
        unentitled.len(),
        1,
        "B-5: two merged receipt siblings spending the SAME quantum must have all-but-one marked unentitled so the coinbase \
         pays at most once; the pay set marks {} of the 2 (both_paid={both_paid}) — the fold applied the quantum once \
         (merged_skips={}) yet the coinbase would pay {} worker shares for it",
        unentitled.len(),
        merged_skips.len(),
        2 - unentitled.len()
    );
}

#[tokio::test]
async fn rfc9_a_v4_receipt_block_is_entitled_split_to_the_executors_payout_and_paid_once() {
    use crate::model::stores::ghostdag::{GhostdagData, HashKTypeMap};
    use kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for;
    use kaspa_consensus_core::palw_freeprompt_v3::{PALW_FP_V3_VERSION, PalwReceiptSpendUnsignedV3, fp_quantum_ticket_v3};
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_pwu::palw_ticket_admits_v1;
    use kaspa_consensus_core::palw_state_v2::{
        PALW_RECEIPT_TARGET_SEED_V1, PalwBlockContextV2, PalwBlockWorkV3, PalwBondKeyV2, PalwChainStateV2, PalwClaimPhaseV2,
        PalwConsensusObjectV2 as Obj, PalwMergedWorkV1, PalwPanelSeatV2, PalwPwuRuleV2, PalwStateParamsV2, PalwTransitionExtrasV1,
        apply_palw_transition_v2, apply_palw_transition_v7,
    };
    use kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_RECEIPT_V3;
    use kaspa_consensus_core::tx::{TransactionId, TransactionOutpoint};
    use kaspa_consensus_core::{BlockHashMap, BlockHashSet, blockhash::BlockHashes};
    use kaspa_hashes::Hash64;

    let h64 = Hash64::from_u64_word;

    // ---- 1. A V2+FP chain on DEVNET windows (receipt maturity 20) so the draw beacon
    //         sits at a low DAA and the chain need only be a couple dozen blocks. The
    //         harness registry (row 0 = the harness ML-DSA identity, bond (0xB0,0)) is the
    //         one `palw_v2_test_carriage`/`palw_v3_test_receipt_carriage_for` sign under. ----
    let catalog = palw_v2_test_catalog();
    let bundle = {
        let registry = {
            let mut registry = kaspa_consensus_core::palw_fp_devnet_v3::palw_devnet_bond_registry_v1(
                kaspa_consensus_core::palw_fp_devnet_v3::palw_v2_min_genesis_bonds_v1(),
            );
            registry[0].pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey();
            registry[0].operator_pubkey = vec![21u8; 8];
            for (i, row) in registry.iter_mut().enumerate().skip(1) {
                row.pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_registry_pubkey(i as u64);
            }
            registry
        };
        let mut b = kaspa_consensus_core::palw_fp_devnet_v3::palw_fp_bundle_with_windows_v3(
            h64(1),
            catalog.root(),
            h64(0xC0757),
            4_096,
            h64(0xA7),
            registry,
            &kaspa_consensus_core::palw_fp_devnet_v3::PALW_DEVNET_WINDOWS_V1,
        )
        .expect("the devnet-windowed harness bundle validates");
        b.class_catalog_root = catalog.root();
        // Fund every genesis bond generously — every mined attempt block reserves exposure, and
        // a couple dozen concurrent claims must fit. `verify_palw_genesis_v2` (the UTXO-backing
        // gate) does not run on this construction path, exactly as `palw_v2_test_bundle_funded_for`.
        for object in b.genesis_objects.iter_mut() {
            if let Obj::BondRegistered { collateral, .. } = object {
                *collateral = 1u64 << 60;
            }
        }
        b
    };
    let maturity = bundle.freeprompt.receipt_maturity_daa();
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            // B-5's pay-once dedup lives past the audit flag day; arm it.
            p.palw_audit_2026_09_11 = Some(kaspa_consensus_core::config::params::ForkActivation::always());
            *p = p.clone().with_palw_v2_cadence();
        })
        .build();
    // RFC-0009: arm the redemption fence on the built (validated, dormant) ruleset — `validate_palw_v2` would ask for the 2026-09-23 audit
    // fence too, which changes what this fixture's attempt blocks must carry; the fence's own prerequisites are held by
    // `palw_receipt_spend_v4_fence.rs`. Everything below reads the fence through the processor, as the node does.
    let mut config = config;
    config.params.palw_receipt_spend_v4 = Some(kaspa_consensus_core::config::params::ForkActivation::always());
    let net_domain = palw_network_domain_v2_for(config.params.net.to_string().as_bytes(), Some(config.params.genesis.hash));
    let mut ctx = TestContext::new(TestConsensus::new(&config));

    // ---- 2. A standalone certified (Final) free-prompt claim state, built with the SAME harness
    //         bond identity (bond (0xB0,0), harness pubkey) so a spend's signature and the
    //         `bond.pubkey == producer_pubkey` check pass. This is the `state` the coinbase pay-set
    //         predicate is evaluated against — the selected parent's state, where the quantum is
    //         still unspent. Built through the public transition API only; no production change. ----
    let harness_bond = TransactionOutpoint::new(TransactionId::from_u64_word(0xB0), 0);
    let harness_bond_key = PalwBondKeyV2(harness_bond);
    let harness_pubkey = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey();
    let base_class = h64(1);
    let inj_params =
        PalwStateParamsV2::new(100, 1, 1, 1, 500, 1_000, base_class, 4, 1_000, 100, 1_000, 0).unwrap().with_fp_quanta(8, 64).unwrap();
    let build_injected = |claim_id: Hash64| -> PalwChainStateV2 {
        let cx = |w: u64, daa: u64, blue: u64| PalwBlockContextV2 { block: h64(w), daa_score: daa, blue_score: blue, subsidy: 0 };
        let reg = vec![
            Obj::ClassRegistered {
                class_id: base_class,
                artifact_root: h64(11),
                slash_value_per_pwu: 5,
                pwu_rule: PalwPwuRuleV2::MaxPerAttempt(160),
                initial_target: u128::MAX / 2,
                share_permille: 1000,
                activation_daa: 0,
                admission: None,
            },
            Obj::BondRegistered {
                bond: harness_bond_key,
                pubkey: harness_pubkey.clone(),
                operator_pubkey: vec![21u8; 8],
                collateral: 1u64 << 40,
                payout_payload: h64(0x9A11),
                capable_classes: Default::default(),
                signature: Vec::new(),
            },
        ];
        let (s1, _) = apply_palw_transition_v2(&PalwChainStateV2::genesis(), &inj_params, &cx(1, 1, 1), &reg, None).unwrap();
        let commit = Obj::FreePromptCommitted {
            job_pin: kaspa_hashes::Hash64::default(),
            eval: None,
            claim: claim_id,
            class_id: base_class,
            bond: harness_bond_key,
            executor_pubkey: harness_pubkey.clone(),
            work_leaves: 60,
            prompt_token_ids_hash: h64(0x7E),
            // ADR-0145 §5's two execution facts, unread below the derived-work fence — which this
            // harness is, since it drives `apply_palw_transition_v2` directly.
            prompt_tokens: 0,
            prompt_token_ids: Vec::new(),
            decode_tokens_executed: 3,
            trace_root: h64(41),
            output_root: h64(42),
            execution_root: h64(43),
            trace_chunk_count: 4,
            trace_retention_daa: 999_999,
            consumed_prefix_state: kaspa_consensus_core::palw_freeprompt_v3::PalwFpPrefixStateV1::genesis(base_class),
        };
        let (s2, _) = apply_palw_transition_v2(&s1, &inj_params, &cx(2, 2, 2), &[commit], None).unwrap();
        let seats = vec![PalwPanelSeatV2 { bond: harness_bond_key, operator_id: h64(90) }];
        let (s3, _) = apply_palw_transition_v2(
            &s2,
            &inj_params,
            &cx(3, 3, 3),
            &[Obj::PanelBound { claim: claim_id, anchor: h64(77), seats }],
            None,
        )
        .unwrap();
        let (s4, _) = apply_palw_transition_v2(
            &s3,
            &inj_params,
            &cx(4, 4, 4),
            &[Obj::ReceiptLicensed { claim: claim_id, receipts: Vec::new() }],
            None,
        )
        .unwrap();
        let (s5, _) = apply_palw_transition_v2(&s4, &inj_params, &cx(5, 6, 5), &[], None).unwrap();
        s5
    };

    // final_daa is deterministic (6) from the walk above; the draw slot is final_daa + maturity.
    let probe = build_injected(h64(0xFC));
    let final_daa = match &probe.claim(&h64(0xFC)).expect("the fixture certifies a claim").phase {
        PalwClaimPhaseV2::Final { final_daa } => *final_daa,
        other => panic!("the fixture must reach Final, got {other:?}"),
    };
    let slot = final_daa + maturity;

    // ---- 3. Mine attempt blocks until the chain reaches the draw slot, so a beacon exists. ----
    while ctx.consensus.get_virtual_daa_score() < slot + 2 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let tip = ctx.consensus.get_sink();
    let vp = ctx.consensus.virtual_processor();
    let beacon = vp.palw_beacon_fact_of_candidate(tip, slot).expect("the chain reached the draw slot, so a beacon derives");

    // A claim id whose quantum-0 ticket admits under the receipt-lane seed target (MAX/2).
    let claim_id = (0u64..2_000)
        .map(|i| h64(0xFC00 + i))
        .find(|cid| palw_ticket_admits_v1(fp_quantum_ticket_v3(net_domain, beacon.beacon_block, *cid, 0), PALW_RECEIPT_TARGET_SEED_V1))
        .expect("some claim id wins the receipt lottery under the seed target");
    let injected = build_injected(claim_id);

    // ---- 4. V4 (public redemption) receipt blocks: the builder is the harness identity here (the only key the harness can sign with), but
    //         everything the chain checks is the V4 path's — both real ML-DSA-87 signatures, the authorization's range and fee, the executor
    //         bond's key and the claim's draw. ----
    let mk_v4 = |nonce: u64, ts_bump: u64, fee_bps: u16| {
        let mut r = ctx.consensus.build_block_with_parents_and_transactions(blockhash::NONE, vec![tip], vec![]);
        r.header.timestamp = ctx.simulated_time + ts_bump;
        r.header.nonce = nonce;
        r.header.pow_algo_id = POW_ALGO_ID_PALW_RECEIPT_V3;
        r.header.palw_commitment =
            ctx.consensus.palw_v4_test_receipt_carriage_for(&r.header, true, claim_id, 0, beacon.beacon_block, fee_bps);
        r.header.finalize();
        r
    };
    let mut ids: Vec<Hash64> = Vec::new();
    for (nonce, ts_bump, fee_bps) in [(0xC1u64, 100u64, 500u16), (0xC2, 200, 750)] {
        let r = mk_v4(nonce, ts_bump, fee_bps);
        ids.push(r.header.hash);
        let verdict = ctx.consensus.validate_and_insert_block(r.to_immutable()).virtual_state_task.await;
        assert!(
            !matches!(&verdict, Err(kaspa_consensus_core::errors::block::RuleError::BadPalwCarriageAdmission { .. })),
            "a correctly signed V4 spend past the fence gets through the header stage: {verdict:?}"
        );
    }
    let (v4_a, v4_b) = (ids[0], ids[1]);
    // A V3 spend of the SAME quantum, for the cross-version case.
    let mut v3 = ctx.consensus.build_block_with_parents_and_transactions(blockhash::NONE, vec![tip], vec![]);
    v3.header.timestamp = ctx.simulated_time + 300;
    v3.header.nonce = 0xC3;
    v3.header.pow_algo_id = POW_ALGO_ID_PALW_RECEIPT_V3;
    v3.header.palw_commitment = ctx.consensus.palw_v3_test_receipt_carriage_for(&v3.header, true, claim_id, 0, harness_bond, beacon.beacon_block);
    v3.header.finalize();
    let v3_hash = v3.header.hash;
    let _ = ctx.consensus.validate_and_insert_block(v3.to_immutable()).virtual_state_task.await;

    let point = PalwBlockContextV2 { block: h64(0xC0DE), daa_score: beacon.beacon_daa, blue_score: 1 << 20, subsidy: 0 };
    let non_daa = BlockHashSet::default();
    let anticone = || HashKTypeMap::new(BlockHashMap::default());

    // Positive control: ONE valid V4 spend, as a merged red, is entitled — and the payout map names the executor bond's registered payout
    // (`0x9A11`, derived to a script) and the authorization's fee, so the coinbase splits it.
    let gd_one = GhostdagData::new(0, Default::default(), tip, BlockHashes::new(vec![tip]), BlockHashes::new(vec![v4_a]), anticone());
    let unentitled_one = vp.palw_v2_unentitled_blues(&injected, &gd_one, &non_daa, &point);
    assert!(unentitled_one.is_empty(), "positive control: a valid V4 spend is entitled; got unentitled={unentitled_one:?}");
    let payouts = vp.palw_v2_receipt_v4_payouts(&injected, &gd_one, &non_daa, &unentitled_one);
    let expected_script = kaspa_consensus_core::palw_receipt_v4::palw_receipt_v4_miner_script(&h64(0x9A11));
    let entry = payouts.get(&v4_a).expect("an entitled V4 block has a payout entry");
    assert_eq!(entry.miner_script, expected_script, "the miner leg goes to the executor bond's registered payout");
    assert_eq!(entry.fee_bps, 500);
    assert_eq!(payouts.len(), 1);

    // Two V4 siblings of ONE quantum: exactly one is entitled, and only that one has a payout entry (B-5's dedup runs on the fold view).
    let gd_two = GhostdagData::new(0, Default::default(), tip, BlockHashes::new(vec![tip]), BlockHashes::new(vec![v4_a, v4_b]), anticone());
    let unentitled_two = vp.palw_v2_unentitled_blues(&injected, &gd_two, &non_daa, &point);
    assert_eq!(unentitled_two.len(), 1, "one quantum, two V4 siblings: paid once");
    assert!(unentitled_two.contains(&v4_b) && !unentitled_two.contains(&v4_a), "the first in acceptance order wins");
    let payouts_two = vp.palw_v2_receipt_v4_payouts(&injected, &gd_two, &non_daa, &unentitled_two);
    assert_eq!(payouts_two.keys().copied().collect::<Vec<_>>(), vec![v4_a], "the refused double spend has no payout entry");

    // A V3 and a V4 spend of the SAME quantum are the same double spend: paid once, whichever is first.
    let gd_mixed = GhostdagData::new(0, Default::default(), tip, BlockHashes::new(vec![tip]), BlockHashes::new(vec![v3_hash, v4_a]), anticone());
    let unentitled_mixed = vp.palw_v2_unentitled_blues(&injected, &gd_mixed, &non_daa, &point);
    assert_eq!(unentitled_mixed.len(), 1, "V3 and V4 share one spent-quantum ledger: paid once");
    assert!(unentitled_mixed.contains(&v4_a));
    let payouts_mixed = vp.palw_v2_receipt_v4_payouts(&injected, &gd_mixed, &non_daa, &unentitled_mixed);
    assert!(payouts_mixed.is_empty(), "the V3 block is paid as V3 always was (no split); the refused V4 one is not paid at all");

    // **The coinbase, through the processor's own manager and fee split** (the template path's expression, fed the entitlement and payout map
    // the walk computed above): the V4 receipt block is paid as two outputs — the miner leg to the executor's payout, the rest to the block's
    // own script — and the pair sums to exactly what the V3 expression pays the same block.
    {
        use kaspa_consensus_core::coinbase::{BlockRewardData, MinerData};
        use kaspa_consensus_core::tx::ScriptPublicKey;
        let a_daa = ctx.consensus.headers_store.get_header(v4_a).unwrap().daa_score;
        let subsidy = vp.coinbase_manager.calc_block_subsidy(a_daa);
        let carve = vp.fee_split_at(a_daa);
        let builder_script = kaspa_txscript::pay_to_script_hash_script(b"rfc9-builder");
        let tip_script = kaspa_txscript::pay_to_script_hash_script(b"rfc9-tip");
        let mut rewards = BlockHashMap::default();
        rewards.insert(tip, BlockRewardData::new(subsidy, 0, 0, tip_script));
        rewards.insert(v4_a, BlockRewardData::new(subsidy, 0, 0, builder_script.clone()));
        let miner = MinerData::new(builder_script.clone(), vec![]);
        let build = |v4: &BlockHashMap<kaspa_consensus_core::palw_receipt_v4::PalwReceiptV4Payout>| {
            vp.coinbase_manager
                .expected_coinbase_transaction(
                    a_daa,
                    subsidy,
                    miner.clone(),
                    &gd_one,
                    &rewards,
                    &non_daa,
                    &[],
                    carve.as_ref(),
                    (0, 0),
                    0,
                    &unentitled_one,
                    true,
                    &Default::default(),
                    &Default::default(),
                    v4,
                )
                .expect("the coinbase builds")
                .tx
        };
        let v3_like = build(&BlockHashMap::default());
        let v4_cb = build(&payouts);
        let total = |tx: &kaspa_consensus_core::tx::Transaction| tx.outputs.iter().map(|o| o.value).sum::<u64>();
        assert_eq!(total(&v4_cb), total(&v3_like), "the split moves value between two payees of one block, never in or out");
        let part = match &carve {
            Some(fs) => kaspa_consensus_core::dns_finality::split_block_subsidy(subsidy, fs).worker_base_sompi,
            None => subsidy,
        };
        let (leg, fee) = kaspa_consensus_core::palw_receipt_v4::palw_receipt_v4_split_v1(part, 500);
        let paid = |tx: &kaspa_consensus_core::tx::Transaction, s: &ScriptPublicKey| {
            tx.outputs.iter().filter(|o| &o.script_public_key == s).map(|o| o.value).sum::<u64>()
        };
        assert_eq!(paid(&v4_cb, &expected_script), leg, "the miner leg reaches the executor bond's registered payout");
        assert!(leg > 0 && fee > 0, "the fixture's reward is large enough for both legs to be non-zero (leg {leg}, fee {fee})");
        assert_eq!(
            paid(&v4_cb, &builder_script) + leg,
            paid(&v3_like, &builder_script),
            "the builder keeps exactly what the V3 expression paid, less the miner leg"
        );
    }

    // The fold takes the winning V4 spend exactly once: weight added once, the second is skipped as QuantumAlreadySpent.
    let spend_view = |bytes: &[u8]| {
        kaspa_consensus_core::palw_receipt_v4::PalwReceiptSpendEnvelopeV4::decode(bytes).expect("decodes").to_fold_envelope()
    };
    let (ea, eb) = (
        spend_view(&ctx.consensus.headers_store.get_header(v4_a).unwrap().palw_commitment),
        spend_view(&ctx.consensus.headers_store.get_header(v4_b).unwrap().palw_commitment),
    );
    let merged = vec![
        PalwMergedWorkV1 {
            carrying_block: v4_a,
            work: PalwBlockWorkV3::ReceiptSpend(&ea.spend),
            execution_key: Default::default(),
            subsidy: 0,
            escrow_carve: None,
            bits: 0,
            job_anchor: Hash64::default(),
        },
        PalwMergedWorkV1 {
            carrying_block: v4_b,
            work: PalwBlockWorkV3::ReceiptSpend(&eb.spend),
            execution_key: Default::default(),
            subsidy: 0,
            escrow_carve: None,
            bits: 0,
            job_anchor: Hash64::default(),
        },
    ];
    let fold_point = PalwBlockContextV2 { block: h64(0xF01D), daa_score: 7, blue_score: 6, subsidy: 0 };
    let (folded, _delta, merged_skips) = apply_palw_transition_v7(
        &injected,
        &inj_params,
        None,
        &fold_point,
        &[],
        PalwBlockWorkV3::None,
        &merged,
        Default::default(),
        false,
        false,
        false,
        false,
        &PalwTransitionExtrasV1::default(),
    )
    .expect("the fold applies");
    assert_eq!(merged_skips.len(), 1, "the FOLD resolves the V4 double spend: one applied, one skipped");
    assert!(folded.safe_weight() > injected.safe_weight(), "exactly one quantum's weight is folded");
}

// =================================================================================================
// AC-SLOT (independent mainnet audit, High): the per-block court slot is spent by an object the
// fold refuses, and the root-claim signature does not cover what the fold refuses it for.
// =================================================================================================

/// Everything the two AC-SLOT tests need: a consensus with the k-ary court armed, and the ADR-0082
/// drill's court sitting at its fused terminal — written by consensus-core's
/// `ac_slot_emit_the_fused_terminal_fixture` to `$AC_SLOT_FIXTURE`, because that drill is
/// `#[cfg(test)]` in the core crate. The claim's bond is given a real ML-DSA-87 key here, and the
/// honest root claim is signed under it, so acceptance runs its real signature check.
struct AcSlotFixture {
    ctx: TestContext,
    state: kaspa_consensus_core::palw_state_v2::PalwChainStateV2,
    params: kaspa_consensus_core::palw_state_v2::PalwStateParamsV2,
    honest: kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2,
    junk: kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2,
    sid: kaspa_hashes::Hash64,
    claim: kaspa_hashes::Hash64,
    daa: u64,
}

fn ac_slot_fixture() -> AcSlotFixture {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{PalwConsensusObjectV2, PalwStateCarriageV2, PalwStateParamsV2};

    // The fixture is committed (`testdata/ac_slot_fixture.bin`, the bytes consensus-core's
    // `ac_slot_emit_the_fused_terminal_fixture` emits — that test pins the file byte for byte), so
    // both tests run in every `cargo test`; `AC_SLOT_FIXTURE` still points them at a fresh one.
    let bytes = match std::env::var("AC_SLOT_FIXTURE") {
        Ok(path) => std::fs::read(&path).expect("the AC-SLOT fixture file exists"),
        Err(_) => include_bytes!("testdata/ac_slot_fixture.bin").to_vec(),
    };
    #[allow(clippy::type_complexity)]
    let (carriage, params, mut honest, sid, daa): (Vec<u8>, PalwStateParamsV2, PalwConsensusObjectV2, kaspa_hashes::Hash64, u64) =
        borsh::from_slice(&bytes).expect("the AC-SLOT fixture decodes");
    let mut carriage: PalwStateCarriageV2 = borsh::from_slice(&carriage).expect("the fixture carriage decodes");
    let claim = carriage.court_sessions.get(&sid).expect("the drill's session").claim;
    let bond = carriage.claims.get(&claim).expect("the drill's claim").bond;
    // The responder: the CLAIM's bond, which is the key a root claim is verified under.
    let keypair = libcrux_ml_dsa::ml_dsa_87::generate_key_pair([0xACu8; 32]);
    carriage.bonds.get_mut(&bond).expect("the claim's bond").pubkey = keypair.verification_key.as_ref().to_vec();
    let state = carriage.into_state(&params, None).expect("the carriage loads");

    let catalog = palw_v2_test_catalog();
    let mut bundle = palw_v2_test_bundle(&catalog);
    // Arming the fence requires the frozen arity to be the derived one (params.rs, audit D H-1).
    bundle.court = kaspa_consensus_core::palw_court_v2::palw_court_params_at_v2(&bundle, true)
        .expect("the test bundle derives a dissection arity");
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params({
            let bundle = bundle.clone();
            move |p| {
                p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
                p.palw_kary_court = Some(ForkActivation::always());
                // AC-SLOT charges the court slot post-apply only past the audit flag day; arm it.
                p.palw_audit_2026_09_11 = Some(ForkActivation::always());
                *p = p.clone().with_palw_v2_cadence();
            }
        })
        .build();
    let ctx = TestContext::new(TestConsensus::new(&config));
    let arity = ctx
        .consensus
        .virtual_processor()
        .palw_court_params_at(daa)
        .expect("a V2 bundle")
        .expect("the armed court derives its params")
        .dissection_arity();

    // The responder's honest filing: the ruleset's arity, signed over (session, root).
    if let PalwConsensusObjectV2::CourtAttnRootClaimed { root, arity: declared, signature, .. } = &mut honest {
        *declared = arity;
        let message = kaspa_consensus_core::palw_court_v2::palw_attn_root_claim_message_v1(&sid, root);
        *signature = libcrux_ml_dsa::ml_dsa_87::sign(
            &keypair.signing_key,
            &message,
            kaspa_consensus_core::palw_court_v2::PALW_COURT_V2_MLDSA87_ATTN_RESPONDER_CONTEXT,
            [0x5Au8; 32],
        )
        .expect("ML-DSA-87 sign")
        .as_ref()
        .to_vec();
    } else {
        panic!("the fixture's honest object is a plain root claim");
    }
    // The attacker's copy: the SAME session, root, arity and signature bytes (copied off the
    // mempool — no key needed), and a foreign binding, which the signature does not cover.
    let mut junk = honest.clone();
    if let PalwConsensusObjectV2::CourtAttnRootClaimed { binding, .. } = &mut junk {
        binding.step_merkle_root = kaspa_hashes::Hash64::from_u64_word(0x00BA_DB1D);
    }
    AcSlotFixture { ctx, state, params, honest, junk, sid, claim, daa }
}

fn ac_slot_point(daa: u64) -> kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
    kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: BlockHash::from_u64_word(0xAC51_0700 + daa),
        daa_score: daa,
        blue_score: daa,
        subsidy: 0,
    }
}

/// **AC-SLOT, one block: an object the fold refuses must not spend the block's only court slot.**
///
/// `palw_v2_accepted_objects` increments `court_closes_completed` as soon as
/// `palw_v2_validate_objects` returns `Ok` — BEFORE the rehearsal transition runs — and the
/// transition's `Err` arm drops the object without giving the slot back. The root claim's
/// acceptance checks only the fence, the arity and an ML-DSA-87 signature over `(session, root)`,
/// so a copy of an honest filing with a foreign binding passes acceptance, spends the slot, is
/// refused by the fold, and the honest filing behind it is dropped for want of a slot.
#[tokio::test]
async fn a_fold_failing_court_move_does_not_spend_the_block_slot() {
    use kaspa_consensus_core::palw_state_v2::{
        PalwConsensusObjectV2 as PalwConsensusObjectV2Alias, palw_court_move_spends_the_slot_v1,
    };
    let f = ac_slot_fixture();
    let vp = f.ctx.consensus.virtual_processor();
    let point = ac_slot_point(f.daa);

    // Control: alone, the honest filing passes acceptance AND the fold, and opens the phase.
    let (accepted, folded) =
        vp.palw_v2_accepted_objects_and_state_for_tests(&f.state, &f.params, &point, vec![f.honest.clone()], point.block);
    assert_eq!(accepted, vec![f.honest.clone()], "control: the honest root claim is carried");
    assert!(folded.court_session(&f.sid).unwrap().dissection.is_some(), "control: the honest root claim opens the phase");

    // The junk copy passes the very acceptance check the processor runs (real ML-DSA-87 verify)
    // and satisfies the slot predicate ...
    let PalwConsensusObjectV2Alias::CourtAttnRootClaimed { root, signature, .. } = &f.junk else { unreachable!() };
    kaspa_consensus_core::palw_court_v2::check_court_attn_root_claim_acceptance_v2(
        &f.state,
        &f.sid,
        root,
        signature,
        |key, message, sig, context| kaspa_txscript::verify_mldsa87_with_context(key, message, sig, context).unwrap_or(false),
    )
    .expect("the replayed signature verifies over the junk copy: it covers only (session, root)");
    assert!(palw_court_move_spends_the_slot_v1(&f.state, &f.junk), "the junk copy spends the slot by the predicate");
    // ... and alone it is dropped (the fold refuses it).
    let alone = vp.palw_v2_accepted_objects_for_tests(&f.state, &f.params, &point, vec![f.junk.clone()], point.block);
    assert!(alone.is_empty(), "the fold refuses the junk copy");

    // The attack: the junk copy first in the accepting block's order, the honest filing behind it.
    let (accepted, folded) = vp.palw_v2_accepted_objects_and_state_for_tests(
        &f.state,
        &f.params,
        &point,
        vec![f.junk.clone(), f.honest.clone()],
        point.block,
    );
    eprintln!(
        "AC-SLOT one block: carried {} object(s); honest carried = {}; phase opened = {}",
        accepted.len(),
        accepted.contains(&f.honest),
        folded.court_session(&f.sid).unwrap().dissection.is_some()
    );
    assert_eq!(
        accepted,
        vec![f.honest.clone()],
        "AC-SLOT: a root claim the fold REFUSED spent the block's only court slot (PALW_COURT_CLOSE_MAX_PER_BLOCK), and the \
         honest root claim behind it was dropped"
    );
}

/// **AC-SLOT, to the rung deadline: a replayed signature cannot crowd the filer into a conviction.**
///
/// The responder files its honest root claim in EVERY block; the attacker puts one replayed copy
/// with a foreign binding ahead of it in every block. Invariant: the filer's move is carried
/// inside its rung and its honest claim is not voided.
#[tokio::test]
async fn a_replayed_root_claim_signature_with_a_foreign_binding_cannot_crowd_out_the_filer() {
    use kaspa_consensus_core::palw_state_v2::{PalwClaimPhaseV2, apply_palw_transition_v2};
    let f = ac_slot_fixture();
    let vp = f.ctx.consensus.virtual_processor();
    let mut state = f.state.clone();
    let mut daa = f.daa;
    let mut filed_at = None;
    let mut blocks = 0u64;
    while state.court_session(&f.sid).is_some() && blocks < 400 {
        let point = ac_slot_point(daa);
        let accepted =
            vp.palw_v2_accepted_objects_for_tests(&state, &f.params, &point, vec![f.junk.clone(), f.honest.clone()], point.block);
        if accepted.contains(&f.honest) {
            filed_at = Some(daa);
        }
        state = apply_palw_transition_v2(&state, &f.params, &point, &accepted, None).expect("the block folds").0;
        blocks += 1;
        daa += 1;
        if filed_at.is_some() {
            break;
        }
    }
    let phase = state.claim(&f.claim).expect("the claim is a record").phase.clone();
    eprintln!(
        "AC-SLOT to the deadline: {blocks} block(s) each carrying [replayed copy, honest filing]; honest filing carried at \
         {filed_at:?}; session alive = {}; claim phase = {phase:?}",
        state.court_session(&f.sid).is_some()
    );
    assert!(
        filed_at.is_some(),
        "AC-SLOT: the responder filed its honest root claim in every one of {blocks} blocks and none was carried"
    );
    assert!(
        !matches!(phase, PalwClaimPhaseV2::Voided { .. }),
        "AC-SLOT: an honest claim was voided because its responder's filing was crowded out: {phase:?}"
    );
}

/// **ADR-0119 Decision 4, pinned where it lives: the acceptance layer bounds a held court move at
/// the claim's CLASS ladder, and judges a fused site's close knowing the held regime.** The fold
/// reads the same ladder off the same state (`every_held_court_arm_of_the_fold_reads_the_claims_class_ladder`);
/// an acceptance arm that read the network's bare would refuse, at `2^26`, a held claim's move the
/// fold would have applied at `2^40` — the two layers disagreeing about one object.
#[test]
fn every_held_court_acceptance_arm_reads_the_claims_class_ladder() {
    let source = include_str!("processor.rs");
    let arm = |name: &str| {
        let at = source.find(&format!("Obj::{name} {{")).unwrap_or_else(|| panic!("{name}'s arm"));
        let end = at + source[at..].find("\n                Obj::").unwrap_or(source.len() - at);
        &source[at..end]
    };
    assert!(arm("ShardCourtAccused").contains("let ladder = state.class_step_ladder_v1(&claim.class_id, ladder);"));
    for name in ["CheckpointAccused", "MaterialDisclosedHeld"] {
        assert!(arm(name).contains("state.class_step_ladder_v1(&claim.class_id, ladder)"), "{name} reads the claim's ladder");
    }
    assert!(!source.contains("adjudicate_court_close_v2("), "every close is judged by v3, which knows the held regime");
    assert_eq!(source.matches("adjudicate_court_close_v3(").count(), 3, "the node's verdict, a close chunk and a close");
    assert!(source.contains("palw_fp_objects_from_accepted_txs_by_class_v1("), "the walk bounds each commitment by its class");
}

/// **t12 (`palw_audit_2026_09_23`): the acceptance layer derives the one-move verdict BOUND to the
/// claim, at the fence the fold reads** — the claim's execution root, class and artifact root, and
/// the fence at the block's DAA. An arm that called the unfenced v1 would admit a fused accusation
/// the fold then refuses (or the reverse below the fence): the two layers disagreeing about one
/// object.
#[test]
fn the_one_move_acceptance_arm_derives_the_bound_verdict_at_the_fence() {
    let source = include_str!("processor.rs");
    let at = source.find("Obj::ShardCourtAccused {").expect("the arm");
    let end = at + source[at..].find("\n                Obj::").expect("the next arm");
    let arm = &source[at..end];
    assert!(arm.contains("palw_shard_court_verdict_at_v2("), "the fenced verdict");
    assert!(arm.contains("self.palw_audit_2026_09_23_at(point.daa_score)"), "at the block's own fence");
    assert!(arm.contains("execution_root: claim.execution_root"), "bound to the claim's committed root");
    assert!(!arm.contains("palw_shard_court_verdict_v1("), "never the unfenced verdict directly");
}

/// **ADR-0152 §4-ter (the shard-court addendum): the acceptance layer refuses a held class's
/// `NeedsDissection` where the fold does** — past `palw_offence_attribution` at the block's own DAA,
/// for a class the bundle's answerability mirror lists (the 2M row), and only there: the arm reads
/// the same mirror and the same fence the fold refuses `ShardCourtHeldSiteUnanswerable` under, so
/// the gate and the fold cannot disagree about which fused accusation opens a session.
#[test]
fn the_one_move_acceptance_arm_refuses_an_unanswerable_held_class_where_the_fold_does() {
    let source = include_str!("processor.rs");
    let at = source.find("Obj::ShardCourtAccused {").expect("the arm");
    let end = at + source[at..].find("\n                Obj::").expect("the next arm");
    let arm = &source[at..end];
    let refusal = arm.find("state_params.held_class_is_unanswerable_v1(&claim.class_id)").expect("the mirror is read");
    let guard = &arm[refusal.saturating_sub(160)..refusal];
    assert!(
        guard.contains("if self.palw_offence_attribution_at(point.daa_score)") && guard.contains("NeedsDissection)"),
        "at the fence"
    );
    assert!(arm[refusal..].contains("return Err("), "and refused");
    let fold = include_str!("../../../core/src/palw_state_v2.rs");
    let fold_at = fold.find("PalwConsensusObjectV2::ShardCourtAccused { accusation } => {").expect("the fold's arm");
    let fold_arm =
        &fold[fold_at..fold_at + fold[fold_at..].find("PalwConsensusObjectV2::CheckpointAccused { accusation } => {").unwrap()];
    assert!(
        fold_arm
            .contains("builder.extras.offence_attribution_active && builder.params.held_class_is_unanswerable_v1(&claim.class_id)"),
        "the fold refuses under the same fence and mirror"
    );
}

/// **ADR-0152 §4-ter: the acceptance layer's half of C2 and C5.** The held root claim (tag 57) is
/// admitted by the same arm as the other two forms of move 1 — the k-ary fence, the declared arity,
/// the responder's signature over the root claim — and exists only past `palw_offence_attribution`
/// at the block's own DAA (the fold refuses it below, `HeldRootClaimRefused`); and a class
/// registration past the fence is asked `palw_held_class_is_attributable_v1` beside the admission
/// gate, at the block's own DAA.
#[test]
fn the_acceptance_layer_takes_the_held_root_claim_past_the_fence_and_refuses_an_unattributable_class() {
    let source = include_str!("processor.rs");
    let at = source.find("Obj::CourtAttnRootClaimed { session_id, root, arity, signature, .. }").expect("the move-1 arm");
    let end = at + source[at..].find("\n                Obj::CourtAttnDissected").expect("the next arm");
    let arm = &source[at..end];
    assert!(arm.contains("| Obj::CourtAttnRootClaimedHeld { session_id, root, arity, signature, .. } =>"), "one arm, three forms");
    let fence =
        arm.find("matches!(object, Obj::CourtAttnRootClaimedHeld { .. }) && !self.palw_offence_attribution_at(point.daa_score)");
    assert!(fence.is_some(), "the held form's fence, at the block's DAA");
    for check in ["palw_attn_move_is_admissible_v2(", "derived.dissection_arity()", "check_court_attn_root_claim_acceptance_v2("] {
        assert!(arm.contains(check), "the held form takes `{check}` like the others");
    }
    let registration = source.find("kaspa_consensus_core::palw_class_admission_v2::verify_class_admission_v9(").expect("the gate");
    let after = &source[registration..registration + 6_000];
    let c5 = after.find("palw_held_class_is_attributable_v1(").expect("C5 beside the gate");
    assert!(after[c5..c5 + 200].contains("self.palw_offence_attribution_at(point.daa_score)"), "at the block's fence");
    assert!(source.contains("O::CourtAttnRootClaimedHeld { .. } => \"CourtAttnRootClaimedHeld\","), "and it has a name");
}

// ---- ADR-0125: the execution lane through the real pipeline ----------------------------------

/// A network with the round lane open from genesis, two permits a round, and one schedule span far
/// longer than the test, so every block is in span 0.
fn adr0125_config() -> (kaspa_consensus_core::config::Config, kaspa_consensus_core::palw_mode_v2::PalwConsensusParamsV2) {
    adr0125_config_funded_for(8)
}

/// [`adr0125_config`] with the harness bond funded for `claims` concurrent claims — one a chain block.
fn adr0125_config_funded_for(
    claims: u64,
) -> (kaspa_consensus_core::config::Config, kaspa_consensus_core::palw_mode_v2::PalwConsensusParamsV2) {
    use kaspa_consensus_core::config::params::{ForkActivation, PalwExecSpanShortV1, PalwExecutionLaneV1};
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, claims);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            p.palw_execution_lane = Some(PalwExecutionLaneV1 {
                activation: ForkActivation::always(),
                permits_per_round: 2,
                widenings: PalwExecutionLaneV1::NO_WIDENINGS,
                max_per_mergeset: 600,
                schedule_span_daa: 1_000,
                short_span: PalwExecSpanShortV1::NONE,
            });
            p.palw_execution_quanta = Some(ForkActivation::always());
        })
        .build();
    config.params.validate_palw_v2().expect("the fixture bundle with the lane is a runnable ruleset");
    (config, bundle)
}

/// The genesis registry's row-0 bond: the harness identity, whose key signs every envelope here.
fn adr0125_harness_bond() -> kaspa_consensus_core::palw_state_v2::PalwBondKeyV2 {
    kaspa_consensus_core::palw_state_v2::PalwBondKeyV2(TransactionOutpoint::new(
        kaspa_consensus_core::tx::TransactionId::from_u64_word(0xB0),
        0,
    ))
}

/// **A schedule a test installs, as ADR-0130 derives one**: the participants its finals earn, seeded
/// by an anchor and a frontier. A unit-test chain cannot finalize an attempt, so these are installed
/// through the carriage; on a live chain the finals are span `s`'s, the snapshot is taken at the first
/// chain block of `s + 1` and this seeding happens at the first chain block of `s + 2`.
fn adr0125_schedule_of(
    span: u64,
    finals: &[kaspa_consensus_core::palw_execution_lane_v1::PalwExecFinalV1],
) -> kaspa_consensus_core::palw_execution_lane_v1::PalwExecScheduleV1 {
    use kaspa_consensus_core::palw_execution_lane_v1::{
        PalwExecSeedAnchorV1, palw_execution_schedule_seeded_v1, palw_execution_schedule_snapshot_v1,
    };
    let anchor = PalwExecSeedAnchorV1 {
        span: span.saturating_sub(1),
        block: kaspa_hashes::Hash64::from_u64_word(0xA0C0),
        execution_key: kaspa_hashes::Hash64::from_u64_word(0xE0E1),
    };
    palw_execution_schedule_seeded_v1(
        &palw_execution_schedule_snapshot_v1(span, finals),
        &anchor,
        7,
        kaspa_hashes::Hash64::from_u64_word(0xF0),
    )
}

/// Solve (the fixture skips PoW, so nonce 0 stands) and sign a round block the way a permit holder
/// does: the envelope names the round, the permit and the bond, and its signature covers the
/// pre-PoW hash, the timestamp and the nonce.
fn adr0125_sign_round_block(
    block: &mut MutableBlock,
    config: &kaspa_consensus_core::config::Config,
    round: u64,
    permit_index: u16,
    nonce: u64,
) {
    use kaspa_consensus_core::palw_execution_lane_v1::{
        PALW_EXEC_ENVELOPE_VERSION_V1, PALW_EXEC_MLDSA87_CONTEXT, PalwExecEnvelopeV1, palw_exec_signing_message_v1,
    };
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );
    let bond = adr0125_harness_bond();
    block.header.nonce = nonce;
    block.header.palw_commitment = Vec::new();
    let pre_pow = kaspa_consensus_core::hashing::header::pre_pow_hash_64(&block.header);
    let message =
        palw_exec_signing_message_v1(network_domain, pre_pow, block.header.timestamp, block.header.nonce, round, permit_index, &bond);
    let kp = TestConsensus::palw_v2_harness_keypair();
    let signature = libcrux_ml_dsa::ml_dsa_87::sign(&kp.signing_key, message.as_byte_slice(), PALW_EXEC_MLDSA87_CONTEXT, [0u8; 32])
        .expect("ML-DSA-87 sign")
        .as_ref()
        .to_vec();
    let envelope = PalwExecEnvelopeV1 {
        version: PALW_EXEC_ENVELOPE_VERSION_V1,
        network_domain,
        round,
        permit_index,
        bond,
        pubkey: TestConsensus::palw_v2_harness_pubkey(),
        signature,
    };
    block.header.palw_commitment = envelope.encode();
    block.header.finalize();
}

/// A round block of `round`, adapted from the current template and signed.
fn adr0125_round_block(
    ctx: &TestContext,
    config: &kaspa_consensus_core::config::Config,
    round: u64,
    permit_index: u16,
    payout: kaspa_consensus_core::tx::ScriptPublicKey,
    nonce: u64,
) -> MutableBlock {
    let template = ctx
        .consensus
        .build_block_template(new_miner_data(), Box::new(OnetimeTxSelector::new(Default::default())), TemplateBuildMode::Standard)
        .unwrap();
    let mut adapted =
        ctx.consensus.virtual_processor().round_adapt_block_template(template, round, payout).expect("the lane adapts a template");
    adr0125_sign_round_block(&mut adapted.block, config, round, permit_index, nonce);
    adapted.block
}

/// **ADR-0125 through the pipeline: round blocks hang beside the chain and never move it.**
///
/// A round block names the sink's selected parent as its anchor; the next chain block merges it as
/// a red, keeps the sink as its selected parent and counts one DAA step, as if the round block were
/// not there. A round block that extends the lane names only the round tip and inherits its anchor.
/// The header stage refuses a chain block that names only round blocks, a mergeset holding one
/// permit twice, and an envelope whose signature does not verify; a template never merges a
/// duplicate permit.
#[tokio::test]
async fn adr0125_round_blocks_hang_beside_the_chain_and_never_move_it() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::errors::block::RuleError;
    let (config, bundle) = adr0125_config();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor().clone();
    let sink0 = ctx.consensus.get_sink();
    let anchor0 = vp.ghostdag_store.get_selected_parent(sink0).unwrap();
    let genesis_ts = config.params.genesis.timestamp;
    let first_round = {
        let r = (vp.headers_store.get_timestamp(sink0).unwrap() - genesis_ts) / 1_000 + 2;
        r + r % 2
    };
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let payout = p2pkh_mldsa87_spk(state.bond(&adr0125_harness_bond()).expect("row 0 is registered").payout_payload.as_byte_slice());
    let view = vp.palw_round_view_v1(first_round).expect("the lane is open");
    assert!(view.permits.is_empty(), "no attempt has reached Final, so no span is scheduled and no permit exists");
    let status = vp.palw_round_lane_status_v1(first_round).expect("the status reads the same state");
    assert_eq!(status.view, view);
    assert!(status.schedule.is_none() && status.accepted_in_span == 0 && status.finals == 0, "an unscheduled lane reports nothing");

    // A round block hangs from the sink's selected parent.
    let e1 = adr0125_round_block(&ctx, &config, first_round, 0, payout.clone(), 0);
    assert_eq!(e1.header.pow_algo_id, kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_ROUND_V1);
    assert_eq!(e1.header.direct_parents(), &[anchor0], "with no round tip, the anchor alone");
    let e1_hash = e1.header.hash;
    ctx.consensus.validate_and_insert_block(e1.to_immutable()).virtual_state_task.await.expect("a signed round block is valid");
    assert_eq!(vp.ghostdag_store.get_selected_parent(e1_hash).unwrap(), anchor0);
    assert_eq!(ctx.consensus.get_sink(), sink0, "a round block never moves the sink");

    // The next chain block merges it as a red and counts one DAA step.
    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + first_round * 1_000) + config.params.target_time_per_block();
    let p1 = ctx.build_block_template(11, ctx.simulated_time);
    assert!(p1.block.header.direct_parents().contains(&e1_hash), "virtual offers the round tip as a parent");
    assert!(p1.block.header.direct_parents().contains(&sink0));
    let p1_hash = p1.block.header.hash;
    ctx.validate_and_insert_block(p1.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    assert_eq!(ctx.consensus.get_sink(), p1_hash);
    let p1_data = vp.ghostdag_store.get_data(p1_hash).unwrap();
    assert_eq!(p1_data.selected_parent, sink0, "the chain block's selected parent is the chain block");
    assert!(p1_data.mergeset_reds.contains(&e1_hash), "the round block is a red");
    assert!(!p1_data.mergeset_blues.contains(&e1_hash));
    assert_eq!(
        vp.headers_store.get_daa_score(p1_hash).unwrap(),
        vp.headers_store.get_daa_score(sink0).unwrap() + 1,
        "the round block is outside the DAA set"
    );

    // A round block anchored at the new sink's selected parent, then one extending it alone.
    let e2 = adr0125_round_block(&ctx, &config, first_round + 2, 0, payout.clone(), 0);
    let e2_hash = e2.header.hash;
    assert_eq!(e2.header.direct_parents(), &[sink0], "the lane moves onto the chain block the next one can merge it beside");
    ctx.consensus.validate_and_insert_block(e2.to_immutable()).virtual_state_task.await.expect("valid");
    let e3 = adr0125_round_block(&ctx, &config, first_round + 4, 0, payout.clone(), 0);
    let e3_hash = e3.header.hash;
    assert_eq!(e3.header.direct_parents(), &[e2_hash], "a round block extending the lane names only the round tip");
    ctx.consensus.validate_and_insert_block(e3.to_immutable()).virtual_state_task.await.expect("valid");
    assert_eq!(vp.ghostdag_store.get_selected_parent(e3_hash).unwrap(), sink0, "and inherits its anchor");
    assert_eq!(ctx.consensus.get_sink(), p1_hash);

    // A chain block may not name only round blocks.
    ctx.simulated_time += 1_000;
    let orphaned = ctx.build_block_with_parents(vec![e3_hash], 91, ctx.simulated_time);
    match ctx.consensus.validate_and_insert_block(orphaned.to_immutable()).virtual_state_task.await {
        Err(RuleError::BadRoundLaneParents(_)) => {}
        other => panic!("a chain block naming only round blocks must be BadRoundLaneParents, got {other:?}"),
    }

    // One permit twice: each alone is valid; a mergeset holding both is refused, and a template
    // never builds one.
    let twin_round = first_round + 6;
    let e4a = adr0125_round_block(&ctx, &config, twin_round, 1, payout.clone(), 1);
    let mut e4b = e4a.clone();
    adr0125_sign_round_block(&mut e4b, &config, twin_round, 1, 2);
    let (e4a_hash, e4b_hash) = (e4a.header.hash, e4b.header.hash);
    assert_ne!(e4a_hash, e4b_hash);
    ctx.consensus.validate_and_insert_block(e4a.to_immutable()).virtual_state_task.await.expect("valid alone");
    ctx.consensus.validate_and_insert_block(e4b.to_immutable()).virtual_state_task.await.expect("valid alone");
    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + twin_round * 1_000) + config.params.target_time_per_block();
    let both = ctx.build_block_with_parents(vec![p1_hash, e4a_hash, e4b_hash], 92, ctx.simulated_time);
    match ctx.consensus.validate_and_insert_block(both.to_immutable()).virtual_state_task.await {
        Err(RuleError::BadRoundLaneMergeset(why)) => assert!(why.contains("permit"), "names the duplicate: {why}"),
        other => panic!("a mergeset holding one permit twice must be BadRoundLaneMergeset, got {other:?}"),
    }
    let template = ctx.build_block_template(93, ctx.simulated_time);
    let parents = template.block.header.direct_parents();
    assert!(!(parents.contains(&e4a_hash) && parents.contains(&e4b_hash)), "a template never merges one permit twice");

    // An envelope whose signature does not verify is refused at the header.
    let mut forged = adr0125_round_block(&ctx, &config, twin_round + 2, 0, payout.clone(), 5);
    let mut envelope =
        kaspa_consensus_core::palw_execution_lane_v1::PalwExecEnvelopeV1::decode(&forged.header.palw_commitment).unwrap();
    envelope.signature[0] ^= 0xFF;
    forged.header.palw_commitment = envelope.encode();
    forged.header.finalize();
    match ctx.consensus.validate_and_insert_block(forged.to_immutable()).virtual_state_task.await {
        Err(RuleError::BadPalwCarriageAdmission { .. }) => {}
        other => panic!("a forged envelope must be refused at the header, got {other:?}"),
    }
}

/// **ADR-0125: a merging block's verdict.** Against a state whose span-0 schedule lists the harness
/// bond (installed through the carriage, as a pruned sync would install a state), the virtual block
/// that merges two round blocks of even rounds grants both their permits; a permit already in the
/// ledger is refused; and a round block naming a payout other than its bond's is refused. Without
/// the schedule — the chain's own state here — nothing is granted.
#[tokio::test]
async fn adr0125_a_merging_block_grants_exactly_the_permits_its_parent_state_schedules() {
    use crate::model::stores::virtual_state::VirtualStateStoreReader;
    use kaspa_consensus_core::palw_execution_lane_v1::PalwExecFinalV1;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;
    let (config, bundle) = adr0125_config();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor().clone();
    let sink0 = ctx.consensus.get_sink();
    let genesis_ts = config.params.genesis.timestamp;
    let first_round = {
        let r = (vp.headers_store.get_timestamp(sink0).unwrap() - genesis_ts) / 1_000 + 2;
        r + r % 2
    };
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let bond = state.bond(&adr0125_harness_bond()).expect("row 0").clone();
    let payout = p2pkh_mldsa87_spk(bond.payout_payload.as_byte_slice());

    let e1 = adr0125_round_block(&ctx, &config, first_round, 0, payout.clone(), 0);
    let e1_hash = e1.header.hash;
    ctx.consensus.validate_and_insert_block(e1.to_immutable()).virtual_state_task.await.expect("valid");
    let e2 = adr0125_round_block(&ctx, &config, first_round + 2, 0, payout.clone(), 0);
    let e2_hash = e2.header.hash;
    ctx.consensus.validate_and_insert_block(e2.to_immutable()).virtual_state_task.await.expect("valid");
    let stranger = new_miner_data().script_public_key;
    let e3 = adr0125_round_block(&ctx, &config, first_round + 4, 0, stranger, 0);
    let e3_hash = e3.header.hash;
    ctx.consensus
        .validate_and_insert_block(e3.to_immutable())
        .virtual_state_task
        .await
        .expect("valid at the header: the payout is state");

    let virtual_state = vp.virtual_stores.read().state.get().unwrap();
    let merged: Vec<_> = virtual_state.ghostdag_data.mergeset_reds.iter().copied().collect();
    for round_block in [e1_hash, e2_hash, e3_hash] {
        assert!(merged.contains(&round_block), "virtual merges every round tip's chain of round blocks");
    }
    let daa = virtual_state.daa_score;
    let none = vp.palw_round_verdicts_v1(&state, &virtual_state.ghostdag_data, daa).expect("the lane is open");
    assert_eq!(none.round_blocks.len(), 3);
    assert!(none.permitted.is_empty(), "no schedule, no permit");
    // Lane SCAN: the verdict's named reasons are the SAME decision as `permitted`, block for block.
    let agrees = |v: &super::utxo_validation::PalwRoundVerdictsV1| {
        assert_eq!(v.judged.len(), v.round_blocks.len(), "every round block is judged once");
        for (block, judged) in &v.judged {
            assert_eq!(judged.is_ok(), v.permitted.contains(block), "a named verdict and the permit set never disagree");
        }
    };
    let reason_of = |v: &super::utxo_validation::PalwRoundVerdictsV1, block| {
        v.judged.iter().find(|(b, _)| *b == block).and_then(|(_, j)| j.as_ref().err().copied())
    };
    agrees(&none);
    assert_eq!(reason_of(&none, e1_hash), Some(kaspa_consensus_core::palw_exec_view_v1::PalwRoundRefusalV1::NoSchedule));

    let schedule = adr0125_schedule_of(
        0,
        &[PalwExecFinalV1 {
            domain: bundle.base_class_id,
            bond: adr0125_harness_bond(),
            operator_id: bond.operator_id,
            claim_id: kaspa_hashes::Hash64::from_u64_word(0xC1A1),
            execution_root: kaspa_hashes::Hash64::from_u64_word(0xE0),
            credit: 1,
            accepted_blue_score: 0,
        }],
    );
    let with_schedule = |used: &[(u64, u64)]| {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.round_schedules.insert(0, schedule.clone());
        for key in used {
            carriage.round_permits_used.insert(*key, 1);
        }
        carriage.into_state(&bundle.state, None).expect("a carriage with a schedule rebuilds")
    };
    let scheduled = with_schedule(&[]);
    let verdicts = vp.palw_round_verdicts_v1(&scheduled, &virtual_state.ghostdag_data, daa).expect("open");
    assert!(verdicts.permitted.contains(&e1_hash) && verdicts.permitted.contains(&e2_hash), "both even-round permits are granted");
    assert!(!verdicts.permitted.contains(&e3_hash), "a round block paying a stranger is not its bond's");
    assert_eq!(verdicts.uses.len(), 2);
    agrees(&verdicts);
    assert_eq!(reason_of(&verdicts, e3_hash), Some(kaspa_consensus_core::palw_exec_view_v1::PalwRoundRefusalV1::PayoutMismatch));
    assert!(verdicts.uses.iter().all(|u| u.span == 0 && u.permit_index == 0));

    let spent = with_schedule(&[(0, first_round)]);
    let verdicts = vp.palw_round_verdicts_v1(&spent, &virtual_state.ghostdag_data, daa).expect("open");
    assert!(!verdicts.permitted.contains(&e1_hash), "a permit in the ledger is not granted again");
    agrees(&verdicts);
    assert_eq!(reason_of(&verdicts, e1_hash), Some(kaspa_consensus_core::palw_exec_view_v1::PalwRoundRefusalV1::PermitAlreadyUsed));
    assert!(verdicts.permitted.contains(&e2_hash));

    // The template's coinbase pays nothing for an unpermitted round block, and the block it becomes
    // is valid — construction and validation agree on the lane.
    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + (first_round + 4) * 1_000) + config.params.target_time_per_block();
    let p1 = ctx.build_block_template(21, ctx.simulated_time);
    assert!(p1.block.transactions[0].outputs.iter().all(|o| o.script_public_key != payout), "no payout without a permit");
    ctx.validate_and_insert_block(p1.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    assert_eq!(ctx.consensus.get_sink(), p1.block.header.hash);
}

/// **ADR-0125 §7.3 through the pipeline: a permit signed twice is evidence the chain accepts once.**
/// Two round blocks for one permit, each valid at the header, become evidence. Against a state whose
/// span-0 schedule grants that permit to the harness bond the acceptance layer admits it; a tampered
/// signature, a span without the grant and a permit already burned are refused; and once burned, the
/// merging block's verdict grants the permit to neither block.
#[tokio::test]
async fn adr0125_a_permit_signed_twice_is_evidence_the_chain_accepts_once() {
    use crate::model::stores::virtual_state::VirtualStateStoreReader;
    use kaspa_consensus_core::palw_execution_lane_v1::{
        PALW_EXEC_EQUIVOCATION_VERSION_V1, PalwExecEnvelopeV1, PalwExecEquivocationV1, PalwExecFinalV1,
    };
    use kaspa_consensus_core::palw_state_v2::{PalwBlockContextV2, PalwConsensusObjectV2, PalwStateCarriageV2};
    let (config, bundle) = adr0125_config();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor().clone();
    let genesis_ts = config.params.genesis.timestamp;
    let round = {
        let r = (vp.headers_store.get_timestamp(ctx.consensus.get_sink()).unwrap() - genesis_ts) / 1_000 + 2;
        r + r % 2
    };
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let bond = state.bond(&adr0125_harness_bond()).expect("row 0").clone();
    let payout = p2pkh_mldsa87_spk(bond.payout_payload.as_byte_slice());

    // Two blocks for one permit: one header, re-solved under another nonce and signed again.
    let first = adr0125_round_block(&ctx, &config, round, 0, payout.clone(), 1);
    let mut second = first.clone();
    adr0125_sign_round_block(&mut second, &config, round, 0, 2);
    let (first_hash, second_hash) = (first.header.hash, second.header.hash);
    ctx.consensus.validate_and_insert_block(first.clone().to_immutable()).virtual_state_task.await.expect("valid alone");
    ctx.consensus.validate_and_insert_block(second.clone().to_immutable()).virtual_state_task.await.expect("valid alone");
    let side = |block: &MutableBlock| {
        let envelope = PalwExecEnvelopeV1::decode(&block.header.palw_commitment).expect("a signed envelope");
        let mut bare = block.header.clone();
        bare.palw_commitment = Vec::new();
        envelope.signed_round_v1(kaspa_consensus_core::hashing::header::pre_pow_hash_64(&bare), bare.timestamp, bare.nonce)
    };
    let evidence = PalwExecEquivocationV1 {
        version: PALW_EXEC_EQUIVOCATION_VERSION_V1,
        span: 0,
        round,
        permit_index: 0,
        bond: adr0125_harness_bond(),
        first: side(&first),
        second: side(&second),
    };
    let object = |evidence: PalwExecEquivocationV1| PalwConsensusObjectV2::RoundPermitEquivocated { evidence: Box::new(evidence) };

    let virtual_state = vp.virtual_stores.read().state.get().unwrap();
    let point = PalwBlockContextV2 {
        block: kaspa_hashes::Hash64::from_u64_word(0xE0E0),
        daa_score: virtual_state.daa_score,
        blue_score: virtual_state.ghostdag_data.blue_score,
        subsidy: 0,
    };
    let schedule = adr0125_schedule_of(
        0,
        &[PalwExecFinalV1 {
            domain: bundle.base_class_id,
            bond: adr0125_harness_bond(),
            operator_id: bond.operator_id,
            claim_id: kaspa_hashes::Hash64::from_u64_word(0xC1A1),
            execution_root: kaspa_hashes::Hash64::from_u64_word(0xE0),
            credit: 1,
            accepted_blue_score: 0,
        }],
    );
    let scheduled = {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.round_schedules.insert(0, schedule);
        carriage.into_state(&bundle.state, None).expect("a carriage with a schedule rebuilds")
    };

    assert!(
        vp.palw_v2_validate_objects(&state, &bundle.state, &point, &[object(evidence.clone())]).is_err(),
        "without the schedule's grant it is two signed blocks for a permit that does not exist"
    );
    vp.palw_v2_validate_objects(&scheduled, &bundle.state, &point, &[object(evidence.clone())])
        .expect("two signed blocks for a granted permit are evidence");
    let mut tampered = evidence.clone();
    tampered.second.signature[7] ^= 0xFF;
    assert!(vp.palw_v2_validate_objects(&scheduled, &bundle.state, &point, &[object(tampered)]).is_err(), "a tampered signature");
    let renamed = PalwExecEquivocationV1 { permit_index: 1, ..evidence.clone() };
    assert!(vp.palw_v2_validate_objects(&scheduled, &bundle.state, &point, &[object(renamed)]).is_err(), "a permit it did not sign");

    // Before the burn the merging block would grant the permit to one of the two; after it, to neither.
    let verdicts = vp.palw_round_verdicts_v1(&scheduled, &virtual_state.ghostdag_data, virtual_state.daa_score).expect("open");
    assert!(verdicts.permitted.contains(&first_hash) || verdicts.permitted.contains(&second_hash), "an unburned permit is granted");
    let (burned, _) = kaspa_consensus_core::palw_state_v2::apply_palw_transition_v2_with_extras(
        &scheduled,
        &bundle.state,
        &point,
        &[object(evidence.clone())],
        None,
        false,
        false,
        false,
        false,
        &kaspa_consensus_core::palw_state_v2::PalwTransitionExtrasV1 {
            round_lane: Some(kaspa_consensus_core::palw_execution_lane_v1::PalwExecLaneFoldV1 {
                schedule_span_daa: 1_000,
                ..Default::default()
            }),
            ..Default::default()
        },
    )
    .expect("the fold burns the permit");
    assert!(burned.round_equivocated(0, round, 0));
    assert!(
        burned.bond(&adr0125_harness_bond()).unwrap().slashed > bond.slashed,
        "the bond paid for signing two blocks for one permit"
    );
    let verdicts = vp.palw_round_verdicts_v1(&burned, &virtual_state.ghostdag_data, virtual_state.daa_score).expect("open");
    assert!(
        !verdicts.permitted.contains(&first_hash) && !verdicts.permitted.contains(&second_hash),
        "a burned permit is granted to neither"
    );
    assert!(vp.palw_v2_validate_objects(&burned, &bundle.state, &point, &[object(evidence)]).is_err(), "and it burns once");
}

/// **ADR-0125 §7.2 through the pipeline: a widening holds for whole spans.** The lane opens one
/// permit a round and widens to two from the first span that opens at or past DAA 8 (spans of 4).
/// Two round blocks of one round each validate alone; a chain block whose mergeset holds both is
/// refused while its span is one permit wide, and a chain block merging two such blocks of a later
/// round is valid once its span is two wide. The template follows the same width.
#[tokio::test]
async fn adr0125_a_widening_holds_for_whole_spans() {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::config::params::{ForkActivation, PalwExecWideningV1, PalwExecutionLaneV1};
    use kaspa_consensus_core::errors::block::RuleError;
    const SPAN: u64 = 4;
    const WIDEN_AT: u64 = 8;
    // Twelve chain blocks, so the harness bond is funded for more concurrent claims than the default.
    let (mut config, bundle) = adr0125_config_funded_for(24);
    {
        let lane = config.params.palw_execution_lane.as_mut().expect("the fixture arms the lane");
        let mut widenings = PalwExecutionLaneV1::NO_WIDENINGS;
        widenings[0] = PalwExecWideningV1 { activation: ForkActivation::new(WIDEN_AT), permits_per_round: 2 };
        *lane = PalwExecutionLaneV1 { permits_per_round: 1, widenings, schedule_span_daa: SPAN, ..*lane };
    }
    config.params.validate_palw_v2().expect("a lane that widens once is runnable");
    let lane = config.params.palw_execution_lane.unwrap();
    assert_eq!((lane.width_at_daa(WIDEN_AT - 1), lane.width_at_daa(WIDEN_AT)), (1, 2));

    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..3 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor().clone();
    let genesis_ts = config.params.genesis.timestamp;
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let payout = p2pkh_mldsa87_spk(state.bond(&adr0125_harness_bond()).expect("row 0").payout_payload.as_byte_slice());
    let next_round = |ctx: &TestContext| (vp.headers_store.get_timestamp(ctx.consensus.get_sink()).unwrap() - genesis_ts) / 1_000 + 2;

    // Span 0/1: two blocks of one round, each valid alone, refused together.
    let round = next_round(&ctx);
    let narrow_a = adr0125_round_block(&ctx, &config, round, 0, payout.clone(), 1);
    let narrow_b = adr0125_round_block(&ctx, &config, round, 1, payout.clone(), 2);
    let (narrow_a_hash, narrow_b_hash) = (narrow_a.header.hash, narrow_b.header.hash);
    ctx.consensus.validate_and_insert_block(narrow_a.to_immutable()).virtual_state_task.await.expect("valid alone");
    ctx.consensus.validate_and_insert_block(narrow_b.to_immutable()).virtual_state_task.await.expect("valid alone");
    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + round * 1_000) + config.params.target_time_per_block();
    let sink = ctx.consensus.get_sink();
    let both = ctx.build_block_with_parents(vec![sink, narrow_a_hash, narrow_b_hash], 31, ctx.simulated_time);
    assert!(both.header.daa_score < WIDEN_AT);
    match ctx.consensus.validate_and_insert_block(both.to_immutable()).virtual_state_task.await {
        Err(RuleError::BadRoundLaneMergeset(_)) => {}
        other => panic!("two round blocks of one round in a one-permit span must be BadRoundLaneMergeset, got {other:?}"),
    }
    let template = ctx.build_block_template(32, ctx.simulated_time);
    let parents = template.block.header.direct_parents();
    assert!(!(parents.contains(&narrow_a_hash) && parents.contains(&narrow_b_hash)), "the template keeps the narrow width");
    ctx.validate_and_insert_block(template.block.clone().to_immutable()).await.assert_valid_utxo_tip();

    // Into the wide span.
    while vp.headers_store.get_daa_score(ctx.consensus.get_sink()).unwrap() < WIDEN_AT + 1 {
        ctx.simulated_time += config.params.target_time_per_block();
        let block = ctx.build_block_template(33, ctx.simulated_time);
        ctx.validate_and_insert_block(block.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    }
    let anchor = vp.ghostdag_store.get_selected_parent(ctx.consensus.get_sink()).unwrap();
    assert!(vp.headers_store.get_daa_score(anchor).unwrap() >= WIDEN_AT, "the next round blocks hang in the wide span");
    let round = next_round(&ctx);
    let wide_a = adr0125_round_block(&ctx, &config, round, 0, payout.clone(), 3);
    let wide_b = adr0125_round_block(&ctx, &config, round, 1, payout.clone(), 4);
    let (wide_a_hash, wide_b_hash) = (wide_a.header.hash, wide_b.header.hash);
    ctx.consensus.validate_and_insert_block(wide_a.to_immutable()).virtual_state_task.await.expect("valid alone");
    ctx.consensus.validate_and_insert_block(wide_b.to_immutable()).virtual_state_task.await.expect("valid alone");
    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + round * 1_000) + config.params.target_time_per_block();
    let template = ctx.build_block_template(34, ctx.simulated_time);
    let parents = template.block.header.direct_parents();
    assert!(parents.contains(&wide_a_hash) && parents.contains(&wide_b_hash), "a two-permit span merges both");
    ctx.validate_and_insert_block(template.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    assert_eq!(ctx.consensus.get_sink(), template.block.header.hash);
}

/// **ADR-0130 through the pipeline: a span's schedule is written at the span's first chain block,
/// from participants fixed a span earlier and the attempt-carrying chain block that anchored them.**
///
/// The lane runs 4-DAA spans. The tip's state is given span `s + 1`'s participants — a snapshot, not
/// a schedule, installed as a pruned sync installs a state, because a unit-test chain cannot take one
/// from finalized attempts — and the chain is built on. Every chain block of this harness carries an
/// attempt, so the last chain block of span `s` is the anchor the fold records; the first chain block
/// of `s + 1` seeds exactly that anchor and the frontier its parent left into the span's schedule,
/// and a round block anchored in the new span holds the permit that schedule grants: the merging
/// block accepts it and records the permit as used.
#[tokio::test]
async fn adr0130_a_span_is_seeded_at_its_first_block_from_the_anchor_of_the_span_before() {
    use kaspa_consensus_core::config::params::PalwExecutionLaneV1;
    use kaspa_consensus_core::palw_execution_lane_v1::{
        PalwExecFinalV1, palw_execution_permits_v1, palw_execution_schedule_seeded_v1, palw_execution_schedule_snapshot_v1,
        palw_execution_span_v1,
    };
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;
    const SPAN: u64 = 4;
    let (mut config, bundle) = adr0125_config_funded_for(24);
    {
        let lane = config.params.palw_execution_lane.as_mut().expect("the fixture arms the lane");
        *lane = PalwExecutionLaneV1 { schedule_span_daa: SPAN, ..*lane };
    }
    config.params.validate_palw_v2().expect("a lane with short spans is runnable");
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor().clone();
    let genesis_ts = config.params.genesis.timestamp;
    let sink0 = ctx.consensus.get_sink();
    let (tip, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert_eq!(tip, sink0);
    let bond = state.bond(&adr0125_harness_bond()).expect("row 0").clone();
    let payout = p2pkh_mldsa87_spk(bond.payout_payload.as_byte_slice());
    let span = palw_execution_span_v1(vp.headers_store.get_daa_score(sink0).unwrap(), SPAN);
    let snapshot = palw_execution_schedule_snapshot_v1(
        span + 1,
        &[PalwExecFinalV1 {
            domain: bundle.base_class_id,
            bond: adr0125_harness_bond(),
            operator_id: bond.operator_id,
            claim_id: kaspa_hashes::Hash64::from_u64_word(0xC1A1),
            execution_root: kaspa_hashes::Hash64::from_u64_word(0xE0),
            credit: 1,
            accepted_blue_score: 0,
        }],
    );
    let planted = {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.round_pending.insert(span + 1, snapshot.clone());
        carriage.into_state(&bundle.state, None).expect("a carriage with a pending snapshot rebuilds")
    };
    vp.palw_state_v2_store.write().set_tip_for_tests(sink0, &planted).unwrap();

    // Chain blocks until one opens the next span. The state each leaves carries that block as the
    // span's anchor, and no schedule until the span turns.
    let (mut last_in_span, mut parent_state) = (sink0, planted);
    let (opening, state_after) = loop {
        ctx.simulated_time += config.params.target_time_per_block();
        let block = ctx.build_block_template(60, ctx.simulated_time);
        ctx.validate_and_insert_block(block.block.clone().to_immutable()).await.assert_valid_utxo_tip();
        let hash = block.block.header.hash;
        let (_, next) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
        if palw_execution_span_v1(vp.headers_store.get_daa_score(hash).unwrap(), SPAN) > span {
            break (hash, next);
        }
        assert!(next.round_schedule(span + 1).is_none(), "the span is not scheduled before its first block");
        assert!(next.round_pending_snapshot().is_some_and(|s| s.target_span == span + 1), "the participants wait");
        (last_in_span, parent_state) = (hash, next);
    };
    let anchor = *parent_state.round_seed_anchor().expect("every chain block here carries an attempt");
    assert_eq!((anchor.span, anchor.block), (span, last_in_span), "the latest attempt-carrying chain block of the span");
    assert_ne!(anchor.execution_key, kaspa_hashes::Hash64::default(), "and its own execution, as the processor derives it");

    let (frontier_blue_score, frontier) = parent_state.safe_frontier();
    let schedule = state_after.round_schedule(span + 1).expect("the span's first block schedules it").clone();
    assert_eq!(schedule, palw_execution_schedule_seeded_v1(&snapshot, &anchor, frontier_blue_score, frontier));
    assert!(state_after.round_pending_snapshot().is_none(), "the snapshot is spent");
    assert_eq!(
        state_after.round_seed_anchor().map(|a| (a.span, a.block)),
        Some((span + 1, opening)),
        "and the opening block, which carries an attempt of its own, anchors the next target"
    );

    // A round block anchored in the new span holds the permit that schedule grants.
    ctx.simulated_time += config.params.target_time_per_block();
    let after = ctx.build_block_template(61, ctx.simulated_time);
    ctx.validate_and_insert_block(after.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let round = {
        let r = (vp.headers_store.get_timestamp(ctx.consensus.get_sink()).unwrap() - genesis_ts) / 1_000 + 2;
        r + r % 2
    };
    assert_eq!(
        palw_execution_permits_v1(&schedule, round, config.params.palw_execution_lane.unwrap().width_of_span(span + 1))
            .iter()
            .map(|p| p.bond)
            .collect::<Vec<_>>(),
        vec![adr0125_harness_bond()],
        "the harness bond holds this round"
    );
    let e1 = adr0125_round_block(&ctx, &config, round, 0, payout.clone(), 0);
    let e1_hash = e1.header.hash;
    ctx.consensus.validate_and_insert_block(e1.to_immutable()).virtual_state_task.await.expect("a signed round block is valid");
    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + round * 1_000) + config.params.target_time_per_block();
    let merging = ctx.build_block_template(62, ctx.simulated_time);
    assert!(merging.block.header.direct_parents().contains(&e1_hash), "virtual offers the round tip");
    ctx.validate_and_insert_block(merging.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let (_, merged) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert!(merged.round_permit_used(span + 1, round, 0), "the merging block granted the permit the seeded schedule wrote");
}

/// **Execution quanta through the pipeline:** a planted Final with 500k CanonicalWork mints five
/// spend-once tickets onto distinct future 1-second rounds. One of those rounds produces an algo-10
/// block; the merging chain block consumes that quantum and leaves the siblings unspent.
#[tokio::test]
async fn execution_quanta_turn_one_final_into_n_algo10_round_permits() {
    use kaspa_consensus_core::config::params::PalwExecutionLaneV1;
    use kaspa_consensus_core::palw_execution_lane_v1::{PalwExecFinalV1, palw_execution_permits_v1, palw_execution_span_v1};
    use kaspa_consensus_core::palw_execution_quanta_v1::PALW_EXECUTION_QUANTUM_V1;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;
    const SPAN: u64 = 4;
    let (mut config, bundle) = adr0125_config_funded_for(24);
    {
        let lane = config.params.palw_execution_lane.as_mut().expect("the fixture arms the lane");
        *lane = PalwExecutionLaneV1 { schedule_span_daa: SPAN, ..*lane };
    }
    config.params.validate_palw_v2().expect("a lane with short spans is runnable");
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor().clone();
    let genesis_ts = config.params.genesis.timestamp;
    let sink0 = ctx.consensus.get_sink();
    let (tip, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert_eq!(tip, sink0);
    let bond = state.bond(&adr0125_harness_bond()).expect("row 0").clone();
    let payout = p2pkh_mldsa87_spk(bond.payout_payload.as_byte_slice());
    let span = palw_execution_span_v1(vp.headers_store.get_daa_score(sink0).unwrap(), SPAN);
    let snapshot = kaspa_consensus_core::palw_execution_lane_v1::palw_execution_schedule_snapshot_v1(
        span + 1,
        &[
            PalwExecFinalV1 {
                domain: bundle.base_class_id,
                bond: adr0125_harness_bond(),
                operator_id: bond.operator_id,
                claim_id: kaspa_hashes::Hash64::from_u64_word(0xC1A1),
                execution_root: kaspa_hashes::Hash64::from_u64_word(0xE0),
                credit: 500_000,
                accepted_blue_score: 0,
            },
            PalwExecFinalV1 {
                domain: bundle.base_class_id,
                bond: adr0125_harness_bond(),
                operator_id: bond.operator_id,
                claim_id: kaspa_hashes::Hash64::from_u64_word(0xC1A2),
                execution_root: kaspa_hashes::Hash64::from_u64_word(0xE0),
                credit: 500_000,
                accepted_blue_score: 0,
            },
        ],
    );
    let planted = {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.round_pending.insert(span + 1, snapshot.clone());
        carriage.into_state(&bundle.state, None).expect("a carriage with a pending snapshot rebuilds")
    };
    vp.palw_state_v2_store.write().set_tip_for_tests(sink0, &planted).unwrap();

    let (opening, state_after) = loop {
        ctx.simulated_time += config.params.target_time_per_block();
        let block = ctx.build_block_template(60, ctx.simulated_time);
        ctx.validate_and_insert_block(block.block.clone().to_immutable()).await.assert_valid_utxo_tip();
        let hash = block.block.header.hash;
        let (_, next) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
        if palw_execution_span_v1(vp.headers_store.get_daa_score(hash).unwrap(), SPAN) > span {
            break (hash, next);
        }
    };
    let _ = opening;
    let schedule = state_after.round_schedule(span + 1).expect("the span's first block schedules it").clone();
    assert_eq!(
        schedule.quanta.len(),
        (500_000 / PALW_EXECUTION_QUANTUM_V1) as usize,
        "copies of one execution_root do not multiply; 500k / 100k is five tickets, got {}",
        schedule.quanta.len()
    );
    assert_eq!(
        schedule.quanta.iter().map(|q| q.scheduled_round).collect::<std::collections::BTreeSet<_>>().len(),
        5,
        "each quantum owns a unique round"
    );
    let first = schedule.quanta[0];
    let round = first.scheduled_round;
    assert_eq!(
        palw_execution_permits_v1(&schedule, round, 1).iter().map(|p| p.bond).collect::<Vec<_>>(),
        vec![adr0125_harness_bond()]
    );
    ctx.simulated_time += config.params.target_time_per_block();
    let after = ctx.build_block_template(61, ctx.simulated_time);
    ctx.validate_and_insert_block(after.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let e1 = adr0125_round_block(&ctx, &config, round, 0, payout.clone(), 0);
    let e1_hash = e1.header.hash;
    ctx.consensus.validate_and_insert_block(e1.to_immutable()).virtual_state_task.await.expect("a signed round block is valid");
    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + round * 1_000) + config.params.target_time_per_block();
    let merging = ctx.build_block_template(62, ctx.simulated_time);
    assert!(merging.block.header.direct_parents().contains(&e1_hash), "virtual offers the quantum's round tip");
    ctx.validate_and_insert_block(merging.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let (_, merged) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert!(merged.round_permit_used(span + 1, round, 0), "consuming the quantum is a tombstone");
    let sibling = schedule.quanta[1].scheduled_round;
    assert!(!merged.round_permit_used(span + 1, sibling, 0), "a sibling quantum is still live");
}

/// **ADR-0130 through the pipeline: an operator does not hold two consecutive rounds, and the round
/// it cannot hold is missed rather than handed back to it.**
///
/// One operator — the harness bond — earned in two security domains, which split the lane and take
/// one parity each. Under ADR-0125's first rule the bond was listed in both and held every round;
/// under this one it is listed only in the domain where it earned more, so the other parity's rounds
/// have no permit at all. Two round blocks, consecutive rounds and one of each parity, are valid at
/// the header; the merging block's verdict grants the one whose parity the operator holds and refuses
/// the other — while the schedule the rule replaced, hand-built here with the bond in both domains,
/// grants both.
#[tokio::test]
async fn adr0130_a_round_block_whose_permit_the_previous_round_held_is_not_granted() {
    use crate::model::stores::virtual_state::VirtualStateStoreReader;
    use kaspa_consensus_core::palw_execution_lane_v1::{PalwExecFinalV1, palw_execution_permits_v1};
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;
    let (config, bundle) = adr0125_config();
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor().clone();
    let sink0 = ctx.consensus.get_sink();
    let genesis_ts = config.params.genesis.timestamp;
    let first_round = {
        let r = (vp.headers_store.get_timestamp(sink0).unwrap() - genesis_ts) / 1_000 + 2;
        r + r % 2
    };
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let bond = state.bond(&adr0125_harness_bond()).expect("row 0").clone();
    let payout = p2pkh_mldsa87_spk(bond.payout_payload.as_byte_slice());

    // One operator, two domains: five credits in the class's own domain and one in another.
    let other_domain = kaspa_hashes::Hash64::from_u64_word(0xD0D0);
    let earned = |domain, claim: u64, credit| PalwExecFinalV1 {
        domain,
        bond: adr0125_harness_bond(),
        operator_id: bond.operator_id,
        claim_id: kaspa_hashes::Hash64::from_u64_word(claim),
        execution_root: kaspa_hashes::Hash64::from_u64_word(0xE0),
        credit,
        accepted_blue_score: 0,
    };
    let schedule = adr0125_schedule_of(0, &[earned(bundle.base_class_id, 0xC1A1, 5), earned(other_domain, 0xC1A2, 1)]);
    assert_eq!(schedule.domains.len(), 2, "two domains");
    assert_ne!(schedule.domains[0].parity, schedule.domains[1].parity, "one parity each");
    let held = schedule.domain(&bundle.base_class_id).expect("the class's own domain");
    assert_eq!(held.bonds.len(), 1, "the operator is listed where it earned more");
    assert!(schedule.domain(&other_domain).expect("listed").bonds.is_empty(), "and nowhere else");
    let (held_round, missed_round) =
        if first_round % 2 == held.parity as u64 { (first_round, first_round + 1) } else { (first_round + 1, first_round + 2) };
    assert!(palw_execution_permits_v1(&schedule, missed_round, 2).is_empty(), "the other parity's round has no permit at all");

    // What the rule replaced: the same schedule with the operator listed in both parities.
    let both_parities = {
        let mut relaxed = schedule.clone();
        let row = held.bonds[0];
        relaxed.domains.iter_mut().for_each(|d| d.bonds = vec![row]);
        relaxed
    };
    assert_eq!(palw_execution_permits_v1(&both_parities, missed_round, 2).len(), 1, "under which the missed round was held");

    let e_held = adr0125_round_block(&ctx, &config, held_round, 0, payout.clone(), 1);
    let e_held_hash = e_held.header.hash;
    ctx.consensus.validate_and_insert_block(e_held.to_immutable()).virtual_state_task.await.expect("valid at the header");
    let e_missed = adr0125_round_block(&ctx, &config, missed_round, 0, payout.clone(), 2);
    let e_missed_hash = e_missed.header.hash;
    ctx.consensus.validate_and_insert_block(e_missed.to_immutable()).virtual_state_task.await.expect("valid at the header");

    let virtual_state = vp.virtual_stores.read().state.get().unwrap();
    let daa = virtual_state.daa_score;
    let with = |schedule: &kaspa_consensus_core::palw_execution_lane_v1::PalwExecScheduleV1| {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.round_schedules.insert(0, schedule.clone());
        carriage.into_state(&bundle.state, None).expect("a carriage with a schedule rebuilds")
    };
    let verdicts = vp.palw_round_verdicts_v1(&with(&schedule), &virtual_state.ghostdag_data, daa).expect("the lane is open");
    assert!(verdicts.permitted.contains(&e_held_hash), "the round its parity holds is granted");
    assert!(
        !verdicts.permitted.contains(&e_missed_hash),
        "and the round before or after it is not — the operator does not hold two in a row"
    );
    let relaxed = vp.palw_round_verdicts_v1(&with(&both_parities), &virtual_state.ghostdag_data, daa).expect("open");
    assert!(
        relaxed.permitted.contains(&e_held_hash) && relaxed.permitted.contains(&e_missed_hash),
        "the schedule the rule replaced grants both"
    );
}

// ---- ADR-0127: conflicting spends in the execution lane, and what a burst of it confirms -------

/// What one [`adr0127_round_burst`] run leaves at the chain block that merged the burst.
struct Adr0127BurstOutcome {
    merging: BlockHash,
    /// `[e1, e2, e3]`: e1 carries `spends[0]`, e2 carries `spends[1]`, e3 carries nothing. Empty
    /// when the run built no round blocks.
    round_blocks: Vec<BlockHash>,
    rounds: [u64; 3],
    spends: [kaspa_consensus_core::tx::TransactionId; 2],
    funding: TransactionOutpoint,
    /// Every transaction id the merging block accepted.
    accepted: Vec<kaspa_consensus_core::tx::TransactionId>,
    /// The merging block's mergeset, without its selected parent, in consensus order.
    mergeset_order: Vec<BlockHash>,
    utxos: std::collections::HashMap<TransactionOutpoint, kaspa_consensus_core::tx::UtxoEntry>,
    /// The span-0 permits the merging block's state records as used, by round.
    permits_used: [bool; 3],
    /// The chain's PALW fork-choice inputs at the merging block: frontier blue score, safe weight,
    /// live total — and its blue work, blue score and DAA score.
    fork_choice: (u64, u128, u128),
    blue_work: kaspa_consensus_core::BlueWorkType,
    blue_score: u64,
    daa_score: u64,
    /// The settlement read at the funding output's DAA score and at the merging block's.
    settlement: [Option<kaspa_consensus_core::palw_settlement_v1::PalwSettlementV1>; 2],
}

/// **One chain, built twice**: a key is funded and matures, the sink's state is given a span-0 schedule
/// that grants the harness bond permit 0 of every even round (installed at the tip, as a pruned sync
/// installs a state — on a live chain the schedule is earned by attempts that reached `Final` two spans
/// earlier, which a unit-test chain cannot finalize), and then the next chain block is built —
/// `with_round_blocks` merging three permitted round blocks, e1 and e2 each carrying a spend of the
/// one funded output and e3 carrying none, and otherwise merging nothing. Every other step, time and
/// nonce is the same in both runs, so the two merging blocks differ by the burst alone.
async fn adr0127_round_burst(with_round_blocks: bool) -> Adr0127BurstOutcome {
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use kaspa_consensus_core::hashing::sighash::{Mldsa87SigHashReusedValuesUnsync, calc_mldsa87_signature_hash};
    use kaspa_consensus_core::hashing::sighash_type::SIG_HASH_ALL;
    use kaspa_consensus_core::mass::MassCalculator;
    use kaspa_consensus_core::palw_execution_lane_v1::PalwExecFinalV1;
    use kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2;
    use kaspa_consensus_core::subnets::SUBNETWORK_ID_NATIVE;
    use kaspa_consensus_core::tx::{PopulatedTransaction, TransactionInput, TransactionOutput, UtxoEntry};
    use kaspa_txscript::{MLDSA87_TX_CONTEXT, script_builder::ScriptBuilder};
    use libcrux_ml_dsa::ml_dsa_87 as mldsa;
    use std::ops::Deref;

    let (mut config, bundle) = adr0125_config_funded_for(32);
    // So the funding coinbase is spendable within a short chain.
    config.params.coinbase_maturity = 2;
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // A key this test can spend from. A linear V2 chain escrows each selected parent's reward, so two
    // siblings are mined to the key and the block merging them pays the one that is not its selected
    // parent (`palw_v2_a_funded_carrier_is_priced_by_the_fee_the_utxo_walk_read` funds its carrier so).
    let kp = mldsa::generate_key_pair([0x27u8; 32]);
    let pubkey = kp.verification_key.as_ref().to_vec();
    let address_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&pubkey).as_bytes();
    let spk = p2pkh_mldsa87_spk(&address_payload);
    ctx.miner_data = MinerData::new(spk.clone(), vec![]);
    ctx.build_block_template_row(0..2).validate_and_insert_row().await;
    ctx.miner_data = new_miner_data();
    ctx.simulated_time += config.params.target_time_per_block();
    let harvest = ctx.build_block_template(40, ctx.simulated_time);
    ctx.validate_and_insert_block(harvest.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    let coinbase = &harvest.block.transactions[0];
    let (index, output) = coinbase
        .outputs
        .iter()
        .enumerate()
        .find(|(_, o)| o.script_public_key == spk)
        .expect("the block merging the row pays the sibling's miner");
    let funding = TransactionOutpoint::new(coinbase.id(), index as u32);
    let (value, funding_daa) = (output.value, harvest.block.header.daa_score);
    for _ in 0..4 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    // Two spends of the one output, differing in their fee.
    let spend = |fee: u64| {
        let mut tx = Transaction::new(
            crate::constants::TX_VERSION,
            vec![TransactionInput::new(funding, vec![], 0, 1)],
            vec![TransactionOutput::new(value - fee, spk.clone())],
            0,
            SUBNETWORK_ID_NATIVE,
            0,
            vec![],
        );
        let utxo = UtxoEntry::new(value, spk.clone(), funding_daa, true);
        let storage_mass = MassCalculator::new(0, 0, 0, config.params.storage_mass_parameter)
            .calc_contextual_masses(&PopulatedTransaction::new(&tx, vec![utxo.clone()]))
            .expect("contextual mass is computable for the spend")
            .storage_mass;
        tx.set_mass(storage_mass);
        let reused = Mldsa87SigHashReusedValuesUnsync::new();
        let sig_hash = calc_mldsa87_signature_hash(&PopulatedTransaction::new(&tx, vec![utxo]), 0, SIG_HASH_ALL, &reused);
        let sig = mldsa::sign(&kp.signing_key, sig_hash.as_bytes().as_slice(), MLDSA87_TX_CONTEXT, [0x27u8; 32])
            .expect("ML-DSA-87 sign on the 64-byte sighash");
        let mut sig_item = sig.as_ref().to_vec();
        sig_item.push(SIG_HASH_ALL.to_u8());
        tx.inputs[0].signature_script = ScriptBuilder::new()
            .add_data(&sig_item)
            .expect("the signature push fits")
            .add_data(&pubkey)
            .expect("the key fits")
            .drain();
        tx
    };
    let spends = [spend(10_000), spend(20_000)];

    // The schedule, at the sink's state.
    let vp = ctx.consensus.virtual_processor().clone();
    let sink0 = ctx.consensus.get_sink();
    let (tip, state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert_eq!(tip, sink0);
    let bond = state.bond(&adr0125_harness_bond()).expect("row 0").clone();
    let payout = p2pkh_mldsa87_spk(bond.payout_payload.as_byte_slice());
    let schedule = adr0125_schedule_of(
        0,
        &[PalwExecFinalV1 {
            domain: bundle.base_class_id,
            bond: adr0125_harness_bond(),
            operator_id: bond.operator_id,
            claim_id: kaspa_hashes::Hash64::from_u64_word(0xC1A1),
            execution_root: kaspa_hashes::Hash64::from_u64_word(0xE0),
            credit: 1,
            accepted_blue_score: 0,
        }],
    );
    let scheduled = {
        let mut carriage = PalwStateCarriageV2::from_state(&state);
        carriage.round_schedules.insert(0, schedule);
        carriage.into_state(&bundle.state, None).expect("a carriage with a schedule rebuilds")
    };
    vp.palw_state_v2_store.write().set_tip_for_tests(sink0, &scheduled).unwrap();

    let genesis_ts = config.params.genesis.timestamp;
    let first_round = {
        let r = (vp.headers_store.get_timestamp(sink0).unwrap() - genesis_ts) / 1_000 + 2;
        r + r % 2
    };
    let rounds = [first_round, first_round + 2, first_round + 4];
    let mut round_blocks = Vec::new();
    if with_round_blocks {
        // Both spends are valid against the virtual UTXO set until one is accepted, so both carriers
        // are built before either is inserted.
        let carrying = |round: u64, nonce: u64, txs: Vec<Transaction>| {
            let template = ctx
                .consensus
                .build_block_template(new_miner_data(), Box::new(OnetimeTxSelector::new(txs)), TemplateBuildMode::Standard)
                .expect("a template carrying one valid spend");
            let mut adapted = vp.round_adapt_block_template(template, round, payout.clone()).expect("the lane adapts a template");
            adr0125_sign_round_block(&mut adapted.block, &config, round, 0, nonce);
            adapted.block
        };
        let e1 = carrying(rounds[0], 1, vec![spends[0].clone()]);
        let e2 = carrying(rounds[1], 2, vec![spends[1].clone()]);
        assert!(
            e1.transactions.iter().any(|tx| tx.id() == spends[0].id()) && e2.transactions.iter().any(|tx| tx.id() == spends[1].id())
        );
        for block in [&e1, &e2] {
            round_blocks.push(block.header.hash);
            ctx.consensus
                .validate_and_insert_block(block.clone().to_immutable())
                .virtual_state_task
                .await
                .expect("valid at the header");
        }
        let e3 = adr0125_round_block(&ctx, &config, rounds[2], 0, payout.clone(), 3);
        round_blocks.push(e3.header.hash);
        ctx.consensus.validate_and_insert_block(e3.to_immutable()).virtual_state_task.await.expect("valid at the header");
        assert_eq!(ctx.consensus.get_sink(), sink0, "round blocks never move the sink");
    }

    ctx.simulated_time = ctx.simulated_time.max(genesis_ts + rounds[2] * 1_000) + config.params.target_time_per_block();
    let merging = ctx.build_block_template(50, ctx.simulated_time);
    let merging_hash = merging.block.header.hash;
    ctx.validate_and_insert_block(merging.block.clone().to_immutable()).await.assert_valid_utxo_tip();
    assert_eq!(ctx.consensus.get_sink(), merging_hash, "the merging block is the sink");
    assert_eq!(ctx.consensus.block_status(merging_hash), BlockStatus::StatusUTXOValid);

    let data = vp.ghostdag_store.get_data(merging_hash).unwrap();
    assert_eq!(data.selected_parent, sink0);
    let mergeset_order: Vec<BlockHash> = data.consensus_ordered_mergeset_without_selected_parent(vp.ghostdag_store.deref()).collect();
    let accepted = ctx
        .consensus
        .get_block_acceptance_data(merging_hash)
        .unwrap()
        .iter()
        .flat_map(|merged| merged.accepted_transactions.iter().map(|entry| entry.transaction_id).collect::<Vec<_>>())
        .collect();
    let utxos = ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect();
    let (_, merged_state) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    let permits_used = rounds.map(|round| merged_state.round_permit_used(0, round, 0));
    let order = vp.palw_candidate_order_v2(merging_hash).expect("a V2 network orders its sink");
    let daa_score = vp.headers_store.get_daa_score(merging_hash).unwrap();
    Adr0127BurstOutcome {
        merging: merging_hash,
        round_blocks,
        rounds,
        spends: [spends[0].id(), spends[1].id()],
        funding,
        accepted,
        mergeset_order,
        utxos,
        permits_used,
        fork_choice: (order.safe_frontier_blue_score, order.safe_weight, order.live_total),
        blue_work: vp.ghostdag_store.get_blue_work(merging_hash).unwrap(),
        blue_score: vp.ghostdag_store.get_blue_score(merging_hash).unwrap(),
        daa_score,
        settlement: [ctx.consensus.palw_settlement_v1(funding_daa), ctx.consensus.palw_settlement_v1(daa_score)],
    }
}

/// **ADR-0127 Decision 4 through the pipeline: conflicting spends are ordered, not raced.** Two
/// round blocks, each holding its permit, carry spends of one output; the chain block that merges
/// them accepts the one its mergeset orders first and skips the other, and the UTXO set holds that
/// spend's output and not the other's — while the merging block stays valid and both permits are
/// recorded as used, so the skipped spend was refused as a double spend, not as an unpermitted block.
#[tokio::test]
async fn adr0127_two_permitted_round_blocks_spending_one_output_are_ordered_by_the_merging_block() {
    let run = adr0127_round_burst(true).await;
    let [e1, e2, e3] = run.round_blocks[..] else { panic!("three round blocks") };
    for block in [e1, e2, e3] {
        assert!(run.mergeset_order.contains(&block), "the merging block merges every round block");
    }
    assert_eq!(run.permits_used, [true; 3], "all three permits were granted and recorded: {:?}", run.rounds);
    let position = |block| run.mergeset_order.iter().position(|b| *b == block).unwrap();
    let (first, second) = if position(e1) < position(e2) { (run.spends[0], run.spends[1]) } else { (run.spends[1], run.spends[0]) };
    assert!(run.accepted.contains(&first), "the spend the mergeset orders first is accepted");
    assert!(!run.accepted.contains(&second), "the conflicting spend ordered after it is not");
    assert!(!run.utxos.contains_key(&run.funding), "the output is spent");
    assert!(run.utxos.contains_key(&TransactionOutpoint::new(first, 0)), "the UTXO set holds the accepted spend's output");
    assert!(!run.utxos.contains_key(&TransactionOutpoint::new(second, 0)), "and not the other's");
    assert_ne!(run.merging, kaspa_hashes::ZERO_HASH64);
}

/// **A burst of execution blocks is zero confirmations** (ADR-0127 §1, the ADR-0129 pin). The same
/// chain block built with three permitted round blocks in its mergeset and without any leaves every
/// PALW fork-choice input where it was — the safe frontier's blue score, the safe weight, the live
/// total — and the selected chain's blue work, blue score and DAA score; and the settlement read
/// answers the same settled, depth and pending anchors for the funding output and for the block.
#[tokio::test]
async fn adr0127_a_burst_of_permitted_round_blocks_moves_no_fork_choice_input() {
    let with = adr0127_round_burst(true).await;
    let without = adr0127_round_burst(false).await;
    assert_eq!(with.round_blocks.len(), 3);
    assert_eq!(with.permits_used, [true; 3], "the burst held its permits");
    assert!(without.round_blocks.is_empty() && without.permits_used == [false; 3]);
    assert_ne!(with.merging, without.merging, "two different merging blocks");
    eprintln!(
        "ADR-0127 burst: with {} permitted round blocks / without — (frontier blue score, safe weight, live total) {:?} / {:?}; \
         blue work {} / {}; blue score {} / {}; DAA {} / {}; settlement at the block {:?} / {:?}",
        with.round_blocks.len(),
        with.fork_choice,
        without.fork_choice,
        with.blue_work,
        without.blue_work,
        with.blue_score,
        without.blue_score,
        with.daa_score,
        without.daa_score,
        with.settlement[1],
        without.settlement[1]
    );
    assert_eq!(with.fork_choice, without.fork_choice, "frontier, safe weight and live total");
    assert_eq!(with.blue_work, without.blue_work, "blue work");
    assert_eq!((with.blue_score, with.daa_score), (without.blue_score, without.daa_score), "blue score and DAA score");
    let reading = |s: Option<kaspa_consensus_core::palw_settlement_v1::PalwSettlementV1>| {
        s.map(|s| (s.settled, s.depth, s.pending, s.depth_is_lower_bound, s.safe_frontier_blue_score, s.sink_daa))
    };
    for (at, (w, wo)) in
        ["the funding output", "the merging block"].into_iter().zip(with.settlement.into_iter().zip(without.settlement))
    {
        assert!(w.is_some(), "a V2 node answers the settlement read at {at}");
        assert_eq!(reading(w), reading(wo), "the settlement read at {at}");
    }
}

// ---- ADR-0126: the validator carve drops to a fifth -------------------------------------------

/// **ADR-0126 through the pipeline.** A `ConsensusV2` chain over mainnet's production overlay —
/// testnet-11's shape: the Stage-3 split from genesis with validators at 30 % and the worker base at
/// 62 %, a bundle escrowing 620 ‰ — with `palw_overlay_carve` at DAA 9 = { 2,000 bps, 720 ‰ } and
/// B-1's merged escrow live from genesis. The chain crosses the height on single blocks, with one
/// two-block row whose merging block lands exactly on the height (so it pays two blocks from below)
/// and one row past it, and every block inserting UTXO-valid is the template and the validator
/// agreeing on its coinbase, on both sides. Then, for every chain block down to the first, against
/// the PALW state it was validated on:
///
/// * the split its coinbase carves with is lowered exactly from its own DAA — the validator pool,
///   read back through the quality sub-pool the node persisted, is 20 % of what it merges from the
///   height and 30 % below;
/// * every attempt block's claim escrows 72 % of its subsidy from the height and 62 % below —
///   resolved at the ATTEMPT block's DAA, for the selected parent (read from the state its own
///   transition wrote) and for a merged block (the withhold the coinbase sized is the escrow the
///   fold recorded);
/// * the coinbase pays each merged block its worker base under the PAYING block's split less that
///   escrow — so a block from below that is paid past the height keeps the tenth.
#[tokio::test]
async fn adr0126_a_palw_chain_crosses_the_overlay_carve() {
    use crate::model::stores::daa::DaaStoreReader;
    use crate::model::stores::ghostdag::GhostdagStoreReader;
    use crate::model::stores::headers::HeaderStoreReader;
    use kaspa_consensus_core::config::params::{ForkActivation, PalwOverlayCarveV1};
    use kaspa_consensus_core::dns_finality::split_block_subsidy;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{PalwBlockContextV2, revert_delta_v2};
    const CARVE_AT: u64 = 9;
    let validator_bps_at = |daa: u64| if daa >= CARVE_AT { 2_000u128 } else { 3_000 };
    let carve_permille_at = |daa: u64| if daa >= CARVE_AT { 720u128 } else { 620 };
    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle_funded_for(&catalog, 16);
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            p.palw_audit_2026_09_11_deep = Some(ForkActivation::always());
            p.palw_overlay_carve = Some(PalwOverlayCarveV1 {
                activation: ForkActivation::new(CARVE_AT),
                subsidy_validator_bps: 2_000,
                worker_carve_permille: 720,
            });
        })
        .build();
    config.params.validate_palw_v2().expect("the carve fits the overlay it lowers");
    let dns = config.params.dns_params.clone().expect("the fixture runs mainnet's overlay");
    assert_eq!(dns.reward_params.fee_split.subsidy_validator_bps, 3_000, "validators take 30 % below the height");
    assert_eq!(bundle.state.worker_carve_permille(), 620, "and a claim escrows 62 %");
    assert_eq!(dns.pos_v2_activation_daa_score, 0, "the quality sub-pool is persisted from genesis, so the pool can be read back");

    let mut ctx = TestContext::new(TestConsensus::new(&config));
    let vp = ctx.consensus.virtual_processor().clone();
    while vp.headers_store.get_daa_score(ctx.consensus.get_sink()).unwrap() + 3 < CARVE_AT {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    ctx.build_block_template_row(0..2).validate_and_insert_row().await.assert_valid_utxo_tip();
    assert!(
        ctx.current_tips.iter().all(|block| vp.headers_store.get_daa_score(*block).unwrap() == CARVE_AT - 2),
        "the pair sits below the height, and the block that merges both lands on it"
    );
    for width in [1, 1, 1, 2, 1, 1] {
        ctx.build_block_template_row(0..width).validate_and_insert_row().await.assert_valid_utxo_tip();
    }

    let genesis = config.params.genesis.hash;
    let sink = ctx.consensus.get_sink();
    let (tip, mut state_after) = vp.palw_state_v2_store.read().load_tip(&bundle.state).unwrap().expect("the tip loads");
    assert_eq!(tip, sink, "the walk left the tip at the sink");
    let (mut below, mut at_height, mut past, mut straddles, mut merged_below, mut merged_past) = (0, 0, 0, 0, 0, 0);
    let mut block = sink;
    loop {
        let header = vp.headers_store.get_header(block).unwrap();
        let ghostdag = vp.ghostdag_store.get_data(block).unwrap();
        // The first block merges genesis, which pays and escrows nothing: the walk ends above it.
        if ghostdag.selected_parent == genesis {
            break;
        }
        let non_daa = vp.daa_excluded_store.get_mergeset_non_daa(block).unwrap();
        let state_before = {
            let (_, delta) = vp.palw_state_v2_store.read().delta_of(block).expect("every chain block has a delta");
            revert_delta_v2(&state_after, &delta, &bundle.state).expect("the delta reverts")
        };
        let point = PalwBlockContextV2 {
            block,
            daa_score: header.daa_score,
            blue_score: header.blue_score,
            subsidy: vp.coinbase_manager.calc_block_subsidy(header.daa_score),
        };
        match header.daa_score.cmp(&CARVE_AT) {
            std::cmp::Ordering::Less => below += 1,
            std::cmp::Ordering::Equal => at_height += 1,
            std::cmp::Ordering::Greater => past += 1,
        }

        // The one split, at this block's own DAA.
        let split = vp.fee_split_at(header.daa_score).expect("Stage 3 from genesis");
        assert_eq!(split.subsidy_validator_bps as u128, validator_bps_at(header.daa_score), "block at DAA {}", header.daa_score);

        // The escrows its coinbase withholds for the merged blocks it did not select, sized from the
        // record its fold escrowed from.
        let merged_withheld = vp.palw_v2_merged_escrow_withheld(&state_before, &ghostdag, &non_daa, &point);
        for (merged, carve) in &merged_withheld {
            let merged_daa = vp.headers_store.get_daa_score(*merged).unwrap();
            let subsidy = vp.coinbase_manager.calc_block_subsidy(merged_daa) as u128;
            assert_eq!(*carve as u128, subsidy * carve_permille_at(merged_daa) / 1_000, "merged block at DAA {merged_daa}");
            assert_eq!(
                vp.palw_v2_escrow_withheld_at(&state_after, *merged, header.daa_score),
                *carve,
                "the carve withheld for the merged block at DAA {merged_daa} is the carve its claim escrowed"
            );
            if merged_daa >= CARVE_AT {
                merged_past += 1;
            } else {
                merged_below += 1;
            }
        }

        // What the coinbase paid each merged block, and what it carved for the validator pool.
        let (mut expected_paid, mut pool) = (0u64, 0u64);
        for merged in ghostdag.mergeset_blues.iter().chain(ghostdag.mergeset_reds.iter()).filter(|m| !non_daa.contains(*m)) {
            let merged_daa = vp.headers_store.get_daa_score(*merged).unwrap();
            let subsidy = vp.coinbase_manager.calc_block_subsidy(merged_daa);
            let parts = split_block_subsidy(subsidy, &split);
            assert_eq!(parts.validator_sompi as u128, subsidy as u128 * validator_bps_at(header.daa_score) / 10_000);
            let escrow = if *merged == ghostdag.selected_parent {
                // The selected parent's claim, from the state its own transition wrote.
                let escrow = vp.palw_v2_escrow_withheld_at(&state_before, *merged, header.daa_score);
                assert_eq!(
                    escrow as u128,
                    subsidy as u128 * carve_permille_at(merged_daa) / 1_000,
                    "the selected parent at DAA {merged_daa} escrowed at its own DAA's carve"
                );
                escrow
            } else {
                merged_withheld.get(merged).copied().unwrap_or(0)
            };
            let kept = parts.worker_base_sompi - escrow;
            if merged_daa < CARVE_AT && header.daa_score >= CARVE_AT {
                straddles += 1;
                assert!(
                    kept.abs_diff(subsidy / 10) <= 3,
                    "a block from DAA {merged_daa} paid at DAA {} keeps the tenth: {kept} of {subsidy}",
                    header.daa_score
                );
            } else {
                assert!(kept <= 3, "a block paid under its own side's split escrows its whole worker base: {kept} kept");
            }
            expected_paid += kept;
            pool += parts.validator_sompi;
        }
        let paid: u64 = ctx.consensus.get_block(block).unwrap().transactions[0].outputs.iter().map(|o| o.value).sum();
        assert_eq!(paid, expected_paid, "the coinbase at DAA {} pays each merged block its base less its escrow", header.daa_score);
        let quality = pool - pool * dns.reward_params.validator_participation_bps as u64 / 10_000;
        assert_eq!(
            vp.block_quality_pool_store.get(block).unwrap_or(0),
            quality,
            "the validator pool the block at DAA {} carved is its split's share of what it merged",
            header.daa_score
        );

        state_after = state_before;
        block = ghostdag.selected_parent;
    }
    assert!(
        below >= 4 && at_height == 1 && past >= 5,
        "the chain ran on both sides of the height ({below} below, {at_height} at, {past} past)"
    );
    assert_eq!(straddles, 2, "the block on the height merged the pair from below, and only it straddles");
    assert!(merged_below >= 1 && merged_past >= 1, "a merged escrow on each side ({merged_below} below, {merged_past} past)");
}

/// The walk's registration fixture (review of the 2026-09-24 DoS audit #12): a TestConsensus with
/// `palw_audit_2026_09_11` (A-1) and — when `armed` — `palw_audit_2026_09_23` on, its genesis state
/// with the harness bond (the registrant, 0xB0) funded for many burns, a second genesis bond whose
/// key the fixture holds (`other`, funded per test by [`Fix12WalkFixture::with_other_at`]), and a
/// builder of signed floor-variant registrations the admission gate admits.
struct Fix12WalkFixture {
    ctx: TestContext,
    state: kaspa_consensus_core::palw_state_v2::PalwChainStateV2,
    params: kaspa_consensus_core::palw_state_v2::PalwStateParamsV2,
    point: kaspa_consensus_core::palw_state_v2::PalwBlockContextV2,
    network_domain: kaspa_hashes::Hash64,
    registrant: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2,
    other: (kaspa_consensus_core::palw_state_v2::PalwBondKeyV2, u64),
    floor: u64,
}

async fn fix12_walk_fixture(armed: bool) -> Fix12WalkFixture {
    use kaspa_consensus_core::config::params::ForkActivation;
    use kaspa_consensus_core::palw_mode_v2::PalwConsensusMode;
    use kaspa_consensus_core::palw_state_v2::{PalwBondKeyV2, PalwStateCarriageV2};
    let catalog = palw_v2_test_catalog();
    let mut bundle = palw_v2_test_bundle_funded_for(&catalog, 8);
    // A `BondRegistered` posts the registration floor (#12 (c): the producer floor); genesis rows too.
    let floor = kaspa_consensus_core::palw_state_v2::palw_bond_registration_floor_v1(bundle.bond.min_collateral_sompi(), true);
    for object in bundle.genesis_objects.iter_mut() {
        if let kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2::BondRegistered { collateral, .. } = object {
            *collateral = (*collateral).max(floor);
        }
    }
    let config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(move |p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            p.palw_audit_2026_09_11 = Some(ForkActivation::always());
            if armed {
                p.palw_audit_2026_09_23 = Some(ForkActivation::always());
                p.sync_palw_escrow_backed_exposure();
            }
        })
        .build();
    // No block is mined: the walk is asked directly, on the genesis state the processor stored at
    // construction, so nothing but the objects handed to it decides what it accepts.
    let ctx = TestContext::new(TestConsensus::new(&config));
    let vp = ctx.consensus.virtual_processor();
    let params = match &config.params.palw_consensus_mode {
        PalwConsensusMode::ConsensusV2(b) => b.state.clone(),
        _ => unreachable!(),
    };
    let (_, state) = vp.palw_state_v2_store.read().load_tip(&params).unwrap().expect("the tip loads");
    let registrant = PalwBondKeyV2(kaspa_consensus_core::tx::TransactionOutpoint::new(
        kaspa_consensus_core::tx::TransactionId::from_u64_word(0xB0),
        0,
    ));
    let harness = crate::consensus::test_consensus::TestConsensus::palw_v2_harness_pubkey();
    assert_eq!(state.bond(&registrant).expect("the harness bond").pubkey, harness, "the premise: 0xB0 is the harness key");
    // A second registrant: a genesis row whose key the fixture holds (`palw_v2_registry_keypair`).
    let (other_key, other_row) = state
        .bonds_iter()
        .find_map(|(key, bond)| {
            (1..16u64)
                .find(|i| bond.pubkey == crate::consensus::test_consensus::TestConsensus::palw_v2_registry_pubkey(*i))
                .map(|i| (*key, i))
        })
        .expect("a registry row with a fixture key");
    let mut carriage = PalwStateCarriageV2::from_state(&state);
    carriage.bonds.get_mut(&registrant).unwrap().collateral = 1_000 * 100_000_000;
    let state = carriage.into_state(&params, None).expect("consistent");
    let point = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: ctx.consensus.get_sink(),
        daa_score: ctx.consensus.get_virtual_daa_score(),
        blue_score: 5,
        subsidy: 0,
    };
    let network_domain = kaspa_consensus_core::palw_attempt_v2::palw_network_domain_v2_for(
        config.params.net.to_string().as_bytes(),
        Some(config.params.genesis.hash),
    );
    Fix12WalkFixture { ctx, state, params, point, network_domain, registrant, other: (other_key, other_row), floor }
}

impl Fix12WalkFixture {
    /// Floor variant `n` (a distinct class id) asking `share` permille, registered by `bond` and
    /// signed with `key` (`None` leaves it unsigned — a stranger's carrier). The gate admits it at
    /// the minimum grantable share; at zero it refuses it (a certified family covers the floor's
    /// kernels, so the entrant is not weightless) while the fold takes it — the one knob the tests
    /// use for "passes everything but the gate".
    fn registration(
        &self,
        n: u32,
        share: u16,
        bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2,
        key: Option<&libcrux_ml_dsa::ml_dsa_87::MLDSA87KeyPair>,
    ) -> kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2 {
        let base = self.params.base_class_id();
        let target = self.state.class_target(&base).expect("the base target").target;
        self.registration_at(n, share, bond, key, target)
    }

    /// [`Self::registration`] signed at `target` rather than the chain's.
    fn registration_at(
        &self,
        n: u32,
        share: u16,
        bond: kaspa_consensus_core::palw_state_v2::PalwBondKeyV2,
        key: Option<&libcrux_ml_dsa::ml_dsa_87::MLDSA87KeyPair>,
        target: u128,
    ) -> kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2 {
        use kaspa_consensus_core::palw_state_v2::{
            PALW_CLASS_REGISTRATION_V2_MLDSA87_CONTEXT, PalwClassAdmissionCarriageV2, PalwConsensusObjectV2, PalwPwuRuleV2,
            palw_class_registration_message_v2,
        };
        let floor = kaspa_consensus_core::palw_base0_profile::base0_profile_v1(
            kaspa_consensus_core::palw_base0_profile::PALW_RC_BASE0_GEOMETRY,
        )
        .expect("the floor's profile projects");
        let mut profile = floor.clone();
        profile.n_threads = n;
        let canonical = kaspa_consensus_core::palw_base0_profile::rc_job_context(
            &profile,
            kaspa_consensus_core::palw_base0_profile::PALW_RC_BASE0_CANONICAL.0,
            kaspa_consensus_core::palw_base0_profile::PALW_RC_BASE0_CANONICAL.1,
        );
        let base = self.params.base_class_id();
        let slash = self.state.class(&base).expect("the base class").slash_value_per_pwu;
        let leaves = kaspa_consensus_core::palw_step::step_leaf_count_capped_v1(&profile, &canonical, u64::MAX).unwrap_or(1);
        let class_id = profile.shape_profile_id();
        let artifact_root = kaspa_hashes::Hash64::from_u64_word(0xF12_0000 + n as u64);
        let rule = PalwPwuRuleV2::DerivedV1 { pwu_per_inference: leaves };
        let signature = key
            .map(|kp| {
                let message = palw_class_registration_message_v2(
                    self.network_domain,
                    class_id,
                    share,
                    0,
                    &bond,
                    artifact_root,
                    slash,
                    target,
                    &rule,
                    &canonical,
                );
                libcrux_ml_dsa::ml_dsa_87::sign(
                    &kp.signing_key,
                    message.as_byte_slice(),
                    PALW_CLASS_REGISTRATION_V2_MLDSA87_CONTEXT,
                    [9u8; 32],
                )
                .expect("sign")
                .as_ref()
                .to_vec()
            })
            .unwrap_or_default();
        PalwConsensusObjectV2::ClassRegistered {
            class_id,
            artifact_root,
            slash_value_per_pwu: slash,
            pwu_rule: rule,
            initial_target: target,
            share_permille: share,
            activation_daa: 0,
            admission: Some(Box::new(PalwClassAdmissionCarriageV2 { profile, canonical, registrant_bond: bond, signature })),
        }
    }

    fn signed(&self, n: u32) -> kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2 {
        self.registration(
            n,
            self.params.min_grantable_share_permille(),
            self.registrant,
            Some(crate::consensus::test_consensus::TestConsensus::palw_v2_harness_keypair()),
        )
    }

    /// A registration by the second bond, signed with its own key.
    fn by_other(&self, n: u32, share: u16) -> kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2 {
        self.registration(
            n,
            share,
            self.other.0,
            Some(crate::consensus::test_consensus::TestConsensus::palw_v2_registry_keypair(self.other.1)),
        )
    }

    /// The fixture's state with the second bond's collateral set to `collateral`.
    fn with_other_at(&self, collateral: u64) -> kaspa_consensus_core::palw_state_v2::PalwChainStateV2 {
        let mut carriage = kaspa_consensus_core::palw_state_v2::PalwStateCarriageV2::from_state(&self.state);
        carriage.bonds.get_mut(&self.other.0).unwrap().collateral = collateral;
        carriage.into_state(&self.params, None).expect("consistent")
    }

    fn accepted(
        &self,
        state: &kaspa_consensus_core::palw_state_v2::PalwChainStateV2,
        objects: Vec<kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2>,
    ) -> Vec<kaspa_consensus_core::palw_state_v2::PalwConsensusObjectV2> {
        self.ctx.consensus.virtual_processor().palw_v2_accepted_objects_for_tests(
            state,
            &self.params,
            &self.point,
            objects,
            self.point.block,
        )
    }
}

/// **Review of #12: the walk's counter is the only guard between a fifth bought registration and a
/// disqualified block, and it counts exactly four.**
///
/// The per-object rehearsal folds each object on a fresh `TransitionBuilder`, whose
/// `class_registrations` is always zero, so it never sees the fold's
/// `ClassRegistrationsPerBlockExceeded`; five signed registrations each rehearse clean. Past the
/// fence the walk must accept exactly the first four in order, a stranger's unsigned copy must not
/// take a slot, and what it accepts must fold — while the same four plus the fifth does not.
/// Below the fence every registration the gate admits is accepted, as before.
#[tokio::test]
async fn fix12_review_the_walk_accepts_four_bought_registrations_and_the_fold_takes_them() {
    use kaspa_consensus_core::palw_state_v2::{PALW_CLASS_REGISTRATION_MAX_PER_BLOCK_V1, PalwStateV2Error};
    let f = fix12_walk_fixture(true).await;
    let vp = f.ctx.consensus.virtual_processor();
    let signed: Vec<_> = (0..5u32).map(|i| f.signed(2_000 + i)).collect();
    // A stranger's carrier naming the registrant, with no signature: first in line.
    let unsigned = f.registration(2_100, f.params.min_grantable_share_permille(), f.registrant, None);
    let mut objects = vec![unsigned];
    objects.extend(signed.iter().cloned());
    let accepted = f.accepted(&f.state, objects);
    assert_eq!(PALW_CLASS_REGISTRATION_MAX_PER_BLOCK_V1, 4);
    assert_eq!(accepted, signed[..4].to_vec(), "exactly the first four signed registrations, in order");
    vp.palw_v2_fold_accepted_for_tests(&f.state, &f.params, &f.point, &accepted).expect("what the walk accepts, the fold applies");
    let refused = vp.palw_v2_fold_accepted_for_tests(&f.state, &f.params, &f.point, &signed);
    assert!(
        matches!(refused, Err(PalwStateV2Error::ClassRegistrationsPerBlockExceeded { max: 4, .. })),
        "the fifth would disqualify the block — which is why the walk must drop it: {refused:?}"
    );

    // Below the fence: no cap, all five accepted (the unsigned one is refused by the gate as ever).
    let dormant = fix12_walk_fixture(false).await;
    let signed: Vec<_> = (0..5u32).map(|i| dormant.signed(2_000 + i)).collect();
    let mut objects = vec![dormant.registration(2_100, dormant.params.min_grantable_share_permille(), dormant.registrant, None)];
    objects.extend(signed.iter().cloned());
    assert_eq!(dormant.accepted(&dormant.state, objects), signed, "below the fence the walk is what it was");
}

/// **Review of #12: an object certain to be refused takes no registration slot.**
///
/// Before this review a slot was charged to any SIGNED registration and kept whatever happened
/// next, so four objects per block that the fold or the gate were certain to refuse censored every
/// honest registration behind them: a floor bond's registrations it cannot pay the 1 MSK burn for
/// (`ClassRegistrationBurnUnaffordable`, nothing ever burned), replays of registrations already on
/// chain (`DuplicateClass`; the signature binds no nonce, so a stranger relays them), and copies
/// signed at a stale target (the gate's first refusal). All of them now fail before the slot, and
/// the four honest registrations behind twelve such objects are all carried.
///
/// Fails without the fix: the floor bond's four registrations take the four slots and nothing
/// honest is carried.
#[tokio::test]
async fn fix12_review_registrations_certain_to_be_refused_take_no_slot() {
    let f = fix12_walk_fixture(true).await;
    // The second bond at the registration floor: it can sign, it cannot pay the burn.
    let state = f.with_other_at(f.floor);
    let unaffordable: Vec<_> = (0..4u32).map(|i| f.by_other(3_000 + i, f.params.min_grantable_share_permille())).collect();
    for object in &unaffordable {
        assert!(
            f.ctx
                .consensus
                .virtual_processor()
                .palw_v2_validate_objects(&state, &f.params, &f.point, std::slice::from_ref(object))
                .is_ok(),
            "the premise: signed, and the gate admits it — only the burn refuses it"
        );
    }
    // A registration already on chain, replayed four times.
    let landed = f.signed(3_100);
    let on_chain = f
        .ctx
        .consensus
        .virtual_processor()
        .palw_v2_fold_accepted_for_tests(&state, &f.params, &f.point, std::slice::from_ref(&landed))
        .expect("the original lands");
    // Signed by the registrant at a target the chain does not offer (a copy from before a retarget).
    let chain_target = f.state.class_target(&f.params.base_class_id()).unwrap().target;
    let stale: Vec<_> = (0..4u32)
        .map(|i| {
            f.registration_at(
                3_200 + i,
                f.params.min_grantable_share_permille(),
                f.registrant,
                Some(crate::consensus::test_consensus::TestConsensus::palw_v2_harness_keypair()),
                chain_target - 1,
            )
        })
        .collect();
    let honest: Vec<_> = (0..4u32).map(|i| f.signed(3_300 + i)).collect();
    let mut objects = unaffordable.clone();
    objects.extend(std::iter::repeat_n(landed.clone(), 4));
    objects.extend(stale);
    objects.extend(honest.iter().cloned());
    // The next block, on the state the original landed in.
    let next = kaspa_consensus_core::palw_state_v2::PalwBlockContextV2 {
        block: kaspa_hashes::Hash64::from_u64_word(0xF12_B10C),
        daa_score: f.point.daa_score + 1,
        blue_score: f.point.blue_score + 1,
        subsidy: 0,
    };
    let accepted =
        f.ctx.consensus.virtual_processor().palw_v2_accepted_objects_for_tests(&on_chain, &f.params, &next, objects, next.block);
    assert_eq!(accepted, honest, "the four honest registrations behind twelve certain refusals are all carried");
}

/// **Review of #12: a registrant whose registration the gate refused takes no further slot in the
/// block.** What the pre-slot checks cannot see is the graph gate itself — that is the CPU the slot
/// exists to bound — so a registrant that can afford the burn can still sign a registration the
/// fold would take and make it fail the gate. It spends one slot per block for that, not four.
#[tokio::test]
async fn fix12_review_a_gate_refused_registrant_spends_one_slot_a_block() {
    let f = fix12_walk_fixture(true).await;
    let state = f.with_other_at(1_000 * 100_000_000);
    // Share 0 on a class a certified family covers: the fold takes it, the gate refuses it.
    let refused_by_gate: Vec<_> = (0..4u32).map(|i| f.by_other(4_000 + i, 0)).collect();
    assert!(
        f.ctx
            .consensus
            .virtual_processor()
            .palw_v2_validate_objects(&state, &f.params, &f.point, std::slice::from_ref(&refused_by_gate[0]))
            .is_err(),
        "the premise: the gate refuses it"
    );
    let honest: Vec<_> = (0..4u32).map(|i| f.signed(4_100 + i)).collect();
    let mut objects = refused_by_gate;
    objects.extend(honest.iter().cloned());
    let accepted = f.accepted(&state, objects);
    assert_eq!(accepted, honest[..3].to_vec(), "the refused registrant spent one slot; the honest registrant keeps three");
}

// ---- testnet-12: the execution lane end to end, from a floor attempt to a paid round block ----
// Test-only: the scenario lives in `tests/t12_round_lane_e2e.rs` beside this file, as a child of
// this module so it reuses `TestContext` and the harness identities.
mod t12_clock_floor;
// ADR-0165 (the Useful Work Transition): the slow REAL attempt on testnet-12's own GHOSTDAG — what colours it, and what carries its tick.
mod t12_real_share;
// ADR-0170 (the seed anchor as a window): with floors held and REAL attempts flowing, a Candidate class is admitted within two periods — and not without the window.
mod t12_anchor_window;
// 2026-09-25 question: can a heartbeat miner's private fork carry a double spend? Two nodes, one
// released private branch, the victim's sink and blue work measured (a probe; no rule changes) — and,
// below it, the regressions of the absorb hole F1's post-launch fence closes (ADR-0105 §11,
// `Params::palw_heartbeat_transparent_same_chain`; `hb_regression_*`).
mod hb_fork_choice_probe;
// ADR-0152 v3.1 H-1 (P2-9 review, finding 5): the node's H-1 gate asks the fold about a carrier
// before this node admits, relays, spares or mines it.
mod t12_h1_carrier_gate;
mod t12_held_leaf_challenge_gate;
// RFC-0007 Part I (tags 91, 92): the verification vertex and its equivocation at the gate.
mod t12_vertex_gate;
mod t12_mesh_gate;
mod t12_offence_attribution_gate;
// ADR-0152 v3.1's v22 skeleton: the declared objects and offence kinds, dropped at acceptance and
// refused by the fold until their owners land them.
mod t12_rcore_skeleton_gate;
// ADR-0152 v3.1 S-6: the per-bond share in the producer's own pre-check and the free-prompt price.
mod t12_rcore_s6_producer_share;
// Lane sink (post-launch): a testnet-12 chain crossing the model sink binding — an unbound sink valid
// in the block below the fence, refused from it; a bound buy valid on both sides; the released rule
// and the armed one agreeing on every block below it.
mod t12_model_sink_bound_fence;
// RFC-0002 Phase F: one IR class registration a block reaches admission v10 — the walk drops a second
// by name before any slot or fee, and the fold refuses a second as its second lock.
mod t12_tir_registration_cap;
// G14 lane D: a model registration on the REAL consensus path against the offline gate (preflight parity, adversarial
// registrations, mempool -> template -> fold -> persisted tip -> ConsensusApi reads, replay and reorg).
mod g14_registration_e2e;
// G14 lane D phase 2: the kernel route folded into PalwChainStateV2 -- a covered lie convicted by a fresh outsider through the real node path.
mod g14_kernel_route_e2e;
// Lane LG14-A: the legacy V2 route under G14 -- a bond registered after genesis reserves, localizes and convicts a lie every seat
// signed Valid (before and after Final), defaults a withheld unit, is dismissed on an honest claim, survives restart / reorg / replay.
mod lg14a_legacy_filer_e2e;
// RFC-0004 Part II: computation specifications with typed roots on the real node -- Weights byte for byte, Memory, Retrieval,
// Composite, each lie convicted by an outsider and each withholding a default.
mod r4x_typed_roots_e2e;
// RFC-0002 Phase F's second IR fence: the IR step-leaf DA demand at the gate.
mod t12_tir_da_step_gate;
// LG14-B (RFC-0014 §4–§5 on the legacy V2 route): tags 157–159 dropped by name below `palw_legacy_held_da_v2`, signed past it.
mod t12_legacy_held_da_gate;
// RFC-0004 A4/A5: the material objects' and the candidate's signatures at the gate, and a licence
// through the walk and the fold, with real card and rights-holder signatures.
mod t12_improve_material_gate;
// RFC-0004 Phase F: pipeline-claim data availability (tag 83) at the gate — refused below palw_improvement_v1,
// signed by its accuser, a unit inside some pipeline execution.
mod t12_pipeline_da_gate;
// ADR-0152 v3.1 S-7: the reporter's commitment (tag 53) and reveal (tag 54) at the gate, the walk
// and the fold past `palw_rcore_plus`, with real card signatures.
mod t12_rcore_s7_reporter_gate;
// ADR-0152 SR-10: the processor's gate routes a set on a licensed claim to the V3 supplementary door
// past `palw_rcore_plus`, and nothing below it (M4 review, finding 1).
mod t12_rcore_sr10_door_gate;
mod t12_round_lane_e2e;
// RFC-0008 v2: the EXEC payload through the real pipeline — the weightless carriage, the anchor, the slice ledgers, the gates.
mod t12_exec_v2_carriage;
// The 2026-09-26 testnet-12 IBD stall from DAA 316: a round lane ties on blue work, so blue-work
// order is not topological; the node's sync paths order parents first (node-only).
mod ibd_parents_first;
// Post-launch lane accept-order (`palw_lane_accept_parents_first`): a merging block applies a tied round
// lane parents-first past the fence, exactly as before below it; a round block carries no EVM payload.
mod lane_accept_parents_first;
// The 2026-09-26 testnet-12 split at DAA 198: a producer's in-process block with a stale cached
// coinbase id forks that producer off the network; ids re-derived at submission keep it on.
mod t12_split_stale_coinbase_id;
// ADR-0152 M4: the stake-weighted draw where the chain draws — the one resolver (SW-1) and the
// one-state, bind-only-in-the-anchor-block derivation (SW-8, T89) on a real testnet-12 chain.
mod t12_stake_draw_integration;
// audit/claim-capacity (2026-09-26): the bond x class claim-capacity profiler (ignored measurement runs).
mod t12_claim_capacity;
// ADR-0160 lane verify (F-B batch licence, F-R room v2): the fences crossed on a real testnet-12 chain,
// and the ×10 step measured in the capacity harness.
mod t12_capacity_verify;
// Lane F1 (the 2026-09-25 sweep's V03/V05): the registry-resilience fence armed on a copy of
// testnet-12 and crossed by a real chain — the processor's mirror, a floor claim unchanged across the
// height, and the no-capable-panel re-anchor at a real anchor block.
mod t12_registry_resilience;
// Lane F2 (post-launch, 2026-09-27): the floor-refusal retry armed on a copy of testnet-12 and crossed by a
// real chain — the draw points the processor carries, and a floor-refused claim re-anchored at a real
// anchor block and bound at the next one.
mod t12_floor_refusal_retry;
// Post-launch lane bind-deadlock (`palw_anchor_at_ceiling`): a producer at its exposure ceiling mines
// no attempt, so nothing anchors its claims — measured on the released rule and closed past the fence.
mod t12_bind_deadlock;
// Lane F1 (post-launch): a testnet-12 chain crossing the panel-seed fence — the block below it, the
// anchor attempt's execution commitment past it, and a second node that agrees.
mod t12_panel_seed_fence;
// Lane A (post-launch): a testnet-12 chain crossing the operator-anchor fence — below it the released
// chain, past it only an operator's attempt anchors a panel, and a slot only non-operators reach voids at
// the bind window's backstop.
mod t12_operator_anchor_fence;
// RFC-0010 (the permissionless Panel's production fold): a testnet-12 chain crossing a bypassed (never armable) fence — the V3 claim bound
// on a heartbeat, lane A draining the legacy claim, IBD and reorg of the engine state.
mod t12_permissionless_panel_e2e;
// Lane BUDGET (ADR-0176): the bond budget through the real pipeline on testnet-12 (a bypassed, never armable fence) — equal ceilings for
// a fast and a slow producer, ρ ×1/×100/×1000, no recovery before accepted + W, IBD, reorg and restart.
mod budget_e2e;
// Lane V02 (post-launch, 2026-09-26): `palw_final_lock_full_collateral` crossed on a real chain — lock-heavy
// seats bind from the height and void their anchor below it.
mod t12_final_lock_full_collateral_fence;
// ADR-0152 v2 F2's acceptance suite (spec §3.6): a false Valid on a real producer-built claim,
// through the gate, the acceptance walk and the fold.
mod t46_false_valid_real_claim;
// ADR-0160 S-T5 (lane shadow): the capacity shadow read through the consensus API on a live-like
// testnet-12 chain driven by the capacity harness.
mod t12_capacity_shadow;
// RFC-0009 stage D (lane C1): the node proves the PALW state its header commits, a client checks it against the block it pinned.
mod t12_state_proof;
// RFC-0009 stage C (lane C1): public receipt redemption (V4) with the miner and the builder different bonds, on the processor's own methods.
mod rfc9_redemption_v4;
// ADR-0152 Phase 2, P2-1: B-3's vesting term at every UTXO site (T23 processor half, T05 bond half).
mod p2_b3_vesting_payee_gate;
// ADR-0152 Phase 2, P2-2: the mint path on real testnet-12 blocks (T58, T03, T47, T25, T05, T29).
mod p2_mint_path;
// Lane maturity (post-launch, 2026-09-26): ADR-0065 D1 brought forward — a bond registered at DAA 13
// is drawable below the fence, and past it only once its own window has run; the genesis seats carry
// every claim across it.
mod t12_seat_maturity_fence;
// testnet-12's post-launch release (int-4): EVERY fence of PALW_T12_POST_LAUNCH_FENCES_V1 at one
// height, crossed by one chain with the clock running — the combined crossing no lane ran alone.
mod t12_post_launch_fences_combined;
// testnet-12's int-13 list (armed explicitly at a test height; the DAA-9,000 flag day was cancelled by the user on 2026-10-08): the four tier-1 fences of PALW_T12_INT13_FENCES_V1 at one height over the
// whole compressed release, crossed by one chain with the clock running — below the fence a released node, past it the list live, a second
// node and a restart across the fence agreeing, the fork id keeping and refusing the released build.
mod t12_int13_flag_day_crossing;
// RFC-0009 mandatory adversarial test 4 at chain-block level (lane C1r2, fence 4 of the int-13 list): the miner's free-prompt claim is
// verified from independent DA providers, reaches Final, and ANOTHER builder's PFS4 block redeems it into the miner's payout while the
// miner is offline — single use, a reorg, a V3 counterfactual twin and a replaying node, all through the real pipeline.
mod rfc9_v4_chain_e2e;
// Lane F2-lock (post-launch, 2026-09-27): `palw_final_lock_life_retro` crossed on a real chain — the crossing
// block re-dates the long post-Final seat locks to max(F + 1,000, H), a Final past it dates exactly.
mod t12_f2_lock_redate_crossing;
// ADR-0152 §8.2 / T53 (P2-12): what a testnet-12 drill chain produces — a registration and its
// carrier, an attempt, a conviction, a coinbase — replayed into public testnet-12, refused.
mod t53_drill_isolation;
// A-2 uniformity (the A2U review): every lifecycle kind and header form the live testnet-12 build cannot decode is, below its owning
// fence, judged as that build judges it — the same verdicts, skips, refusals, roots and UTXO set on an unarmed and an armed-far node.
mod t12_a2u_new_kinds_uniform;

// RFC-0012: the private zero-DNS acceptance matrix (lane X12). It drives the EVM lane (deposits, sells, withdrawals), so it builds
// with the `evm` feature only, like `p2_evm_twin`.
#[cfg(feature = "evm")]
mod rfc12_zero_dns_matrix;
// RFC-0012 wave 2 (C1 a real claim to `Final` with the lane on, C2 a pruned join with EVM state): `evm` feature only, like the matrix.
#[cfg(feature = "evm")]
mod rfc12_c_items;

/// **MSK-26A (2026-09 pre-freeze security review): a slash applied on unchecked evidence**, end to
/// end through `validate_and_insert_block`: a forged slashing evidence rides in a side block `M`
/// that the honest virtual MERGES (M has lower blue work than the sink, so it is never
/// chain-validated and its own body is never genuineness-checked), then an honest template `C`
/// merges it. Pins the shipped (dormant) behaviour, the armed fix, the genuine-evidence control,
/// the mixed-order case (a forgery sorted ahead of a genuine equivocation must not choose the
/// reporter payout or the victim epoch), and the node-side mempool refusal.
mod msk26a_slash_genuineness {
    use super::*;
    use kaspa_consensus_core::{
        Hash64,
        config::params::ForkActivation,
        dns_finality::{DNS_PAYLOAD_VERSION_V1, SlashingEvidencePayload},
        tx::{MutableTransaction, ScriptPublicKey},
    };

    struct World {
        ctx: TestContext,
        honest: dns_harness::HarnessValidator,
        atk: dns_harness::HarnessValidator,
        bond_outpoint: TransactionOutpoint,
        target_daa: u64,
        side_parent: BlockHash,
        k_funds: Vec<(TransactionOutpoint, u64, u64)>,
        a_funds: Vec<(TransactionOutpoint, u64, u64)>,
        k_payload: [u8; 64],
        a_payload: [u8; 64],
    }

    fn paid(b: &Block, spk: &ScriptPublicKey) -> (TransactionOutpoint, u64, u64) {
        let cb = &b.transactions[0];
        let (i, o) = cb.outputs.iter().enumerate().find(|(_, o)| o.script_public_key == *spk).expect("coinbase pays the key");
        (TransactionOutpoint::new(cb.id(), i as u32), o.value, b.header.daa_score)
    }

    async fn world(fence: Option<ForkActivation>) -> World {
        let config = ConfigBuilder::new(MAINNET_PARAMS)
            .skip_proof_of_work()
            .edit_consensus_params(|p| {
                p.max_block_parents = 4;
                p.mergeset_size_limit = 10;
                p.coinbase_maturity = 2;
                let mut dns = DEVNET_PARAMS.dns_params.clone().unwrap();
                dns.dns_activation_daa_score = 0;
                dns.pos_v2_activation_daa_score = 0;
                dns.epoch_length_blocks = 2;
                dns.reward_uniqueness_window_blocks = 50;
                dns.max_reorg_horizon_blocks = 2;
                dns.attestation_epoch_length_blue_score = 3;
                dns.attestation_lag_blue_score = 2;
                dns.attestation_anchor_backoff_blue_score = 1;
                dns.stake_score_window_blue_score = 10_000;
                p.dns_params = Some(dns);
                p.palw_slashing_evidence_utxo_genuine = fence;
            })
            .build();
        let mut ctx = TestContext::new(TestConsensus::new(&config));
        let honest = dns_harness::harness_validator([0x42u8; 32]);
        let atk = dns_harness::harness_validator([0x77u8; 32]);
        let k_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&honest.pubkey).as_bytes();
        let a_payload: [u8; 64] = kaspa_hashes::blake2b_512_address_payload(&atk.pubkey).as_bytes();
        let k_spk = p2pkh_mldsa87_spk(&k_payload);
        let a_spk = p2pkh_mldsa87_spk(&a_payload);
        let k_miner = MinerData::new(k_spk.clone(), vec![]);
        let a_miner = MinerData::new(a_spk.clone(), vec![]);
        // A block's coinbase pays its selected parent's miner, so the funding is one block behind.
        ctx.mine_block(k_miner.clone(), vec![]).await;
        let h1 = ctx.mine_block(k_miner.clone(), vec![]).await;
        let h2 = ctx.mine_block(k_miner.clone(), vec![]).await;
        let h3 = ctx.mine_block(a_miner.clone(), vec![]).await;
        let x1 = ctx.mine_block(a_miner.clone(), vec![]).await;
        let x2 = ctx.mine_block(a_miner.clone(), vec![]).await;
        let x3 = ctx.mine_block(new_miner_data(), vec![]).await;
        let k_funds = vec![paid(&h1, &k_spk), paid(&h2, &k_spk), paid(&h3, &k_spk)];
        let a_funds = vec![paid(&x1, &a_spk), paid(&x2, &a_spk), paid(&x3, &a_spk)];
        for _ in 0..5 {
            ctx.mine_block(new_miner_data(), vec![]).await;
        }
        let storage = ctx.consensus.params().storage_mass_parameter;
        let (op, value, daa) = k_funds[0];
        let (bond_tx, _, _) = dns_harness::funded_signed_bond_tx(honest.seed, op, value, daa, value - 100_000, 0, storage);
        let bond_outpoint = TransactionOutpoint::new(bond_tx.id(), 0);
        let bond_block = ctx.mine_block(new_miner_data(), vec![bond_tx]).await;
        assert_eq!(ctx.consensus.block_status(bond_block.header.hash), BlockStatus::StatusUTXOValid);
        let mut buried = Vec::new();
        for _ in 0..6 {
            buried.push(ctx.mine_block(new_miner_data(), vec![]).await);
        }
        let target_daa = buried[1].header.daa_score;
        // M hangs off the sink's grandparent: strictly lower blue work than the sink, so the sink
        // search never pops it (never chain-validated) and the virtual keeps it as a merge parent.
        let side_parent = buried[buried.len() - 3].header.hash;
        World { ctx, honest, atk, bond_outpoint, target_daa, side_parent, k_funds, a_funds, k_payload, a_payload }
    }

    /// Two attestations for the honest bond carrying the honest validator's id, signed by the
    /// ATTACKER's key (the attacker cannot sign as the validator) — structurally valid evidence.
    fn forged(w: &World, epoch: u64, reporter: [u8; 64]) -> SlashingEvidencePayload {
        let net = w.ctx.consensus.params().genesis.hash;
        let mut a = dns_harness::build_signed_attestation(
            &w.atk,
            net.as_byte_slice(),
            w.bond_outpoint,
            epoch,
            Hash64::from_bytes([0x5a; 64]),
            w.target_daa,
            Hash64::default(),
        );
        let mut b = dns_harness::build_signed_attestation(
            &w.atk,
            net.as_byte_slice(),
            w.bond_outpoint,
            epoch,
            Hash64::from_bytes([0x9b; 64]),
            w.target_daa,
            Hash64::default(),
        );
        a.validator_id = w.honest.validator_id;
        b.validator_id = w.honest.validator_id;
        SlashingEvidencePayload {
            version: DNS_PAYLOAD_VERSION_V1,
            bond_outpoint: w.bond_outpoint,
            attestation_a: a,
            attestation_b: b,
            reporter_reward_spk_payload: reporter,
        }
    }

    /// A GENUINE equivocation by the bonded validator (it really signed both).
    fn genuine(w: &World, epoch: u64, reporter: [u8; 64]) -> SlashingEvidencePayload {
        let net = w.ctx.consensus.params().genesis.hash;
        let a = dns_harness::build_signed_attestation(
            &w.honest,
            net.as_byte_slice(),
            w.bond_outpoint,
            epoch,
            Hash64::from_bytes([0xa1; 64]),
            w.target_daa,
            Hash64::default(),
        );
        let b = dns_harness::build_signed_attestation(
            &w.honest,
            net.as_byte_slice(),
            w.bond_outpoint,
            epoch,
            Hash64::from_bytes([0xb2; 64]),
            w.target_daa,
            Hash64::default(),
        );
        SlashingEvidencePayload {
            version: DNS_PAYLOAD_VERSION_V1,
            bond_outpoint: w.bond_outpoint,
            attestation_a: a,
            attestation_b: b,
            reporter_reward_spk_payload: reporter,
        }
    }

    fn evidence_tx(w: &World, funder: [u8; 32], fund: (TransactionOutpoint, u64, u64), ev: SlashingEvidencePayload) -> Transaction {
        let storage = w.ctx.consensus.params().storage_mass_parameter;
        dns_harness::funded_signed_slashing_evidence_tx(funder, fund.0, fund.1, fund.2, ev, storage)
    }

    /// Insert side block M (utxo-invalid coinbase, never chain-validated) carrying `txs`, then mine
    /// an honest template C that merges it. Returns (M, C).
    async fn merge_side_block(w: &mut World, txs: Vec<Transaction>) -> (BlockHash, Block) {
        w.ctx.simulated_time += w.ctx.consensus.params().target_time_per_block();
        let mut m = w.ctx.consensus.build_block_with_parents_and_transactions(blockhash::NONE, vec![w.side_parent], txs);
        m.header.timestamp = w.ctx.simulated_time;
        m.header.nonce = w.ctx.simulated_time;
        m.header.finalize();
        let m_hash = m.header.hash;
        w.ctx.validate_and_insert_block(m.to_immutable()).await;
        assert!(w.ctx.consensus.get_virtual_parents().contains(&m_hash), "the honest virtual merges M");
        let c = w.ctx.mine_block(new_miner_data(), vec![]).await;
        assert!(c.header.direct_parents().contains(&m_hash), "the honest template C merges M");
        assert_eq!(w.ctx.consensus.block_status(c.header.hash), BlockStatus::StatusUTXOValid, "C is UTXO-valid");
        assert_eq!(w.ctx.consensus.get_sink(), c.header.hash);
        (m_hash, c)
    }

    fn utxos(w: &World) -> std::collections::HashMap<TransactionOutpoint, kaspa_consensus_core::tx::UtxoEntry> {
        w.ctx.consensus.get_virtual_utxos(None, 100_000, false).into_iter().collect()
    }

    fn registry_slashed(w: &World) -> Option<Option<u64>> {
        w.ctx.consensus.virtual_processor().initial_active_bond_view().get(&w.bond_outpoint).map(|r| r.slashed_at_daa_score)
    }

    async fn forged_only(fence: Option<ForkActivation>) -> (bool, Option<(u64, ScriptPublicKey)>, Option<Option<u64>>) {
        let mut w = world(fence).await;
        let tx = evidence_tx(&w, w.atk.seed, w.a_funds[0], forged(&w, 1, w.a_payload));
        let id = tx.id();
        assert!(utxos(&w).contains_key(&w.bond_outpoint), "the honest bond's stake exists before");
        merge_side_block(&mut w, vec![tx]).await;
        let u = utxos(&w);
        let mint = u.get(&TransactionOutpoint::new(id, 0)).map(|e| (e.amount, e.script_public_key.clone()));
        (u.contains_key(&w.bond_outpoint), mint, registry_slashed(&w))
    }

    /// (1) The failure on the shipped behaviour (fence dormant = 0e8ec984e's code path).
    #[tokio::test]
    async fn dormant_a_merged_forged_evidence_burns_the_honest_stake_and_pays_the_forger() {
        let (bond_present, mint, registry) = forged_only(None).await;
        eprintln!("DORMANT: bond_utxo_present={bond_present} mint={mint:?} registry_slashed_at={registry:?}");
        assert!(!bond_present, "shipped: the honest bond's staked output-0 is removed by forged evidence");
        assert!(mint.is_some(), "shipped: the forger is minted a reporter reward");
        assert_eq!(registry, Some(None), "while the registry still reads the bond unslashed");
    }

    /// (1') The fix, armed: the same attack is a no-op.
    #[tokio::test]
    async fn armed_a_merged_forged_evidence_burns_nothing() {
        let (bond_present, mint, registry) = forged_only(Some(ForkActivation::always())).await;
        eprintln!("ARMED: bond_utxo_present={bond_present} mint={mint:?} registry_slashed_at={registry:?}");
        assert!(bond_present, "armed: the honest bond's stake stays");
        assert!(mint.is_none(), "armed: no reporter mint");
        assert_eq!(registry, Some(None));
    }

    /// Control: armed, a GENUINE equivocation merged the same way still slashes (no false negative).
    #[tokio::test]
    async fn armed_a_merged_genuine_evidence_still_slashes() {
        let mut w = world(Some(ForkActivation::always())).await;
        let tx = evidence_tx(&w, w.honest.seed, w.k_funds[1], genuine(&w, 1, w.k_payload));
        let id = tx.id();
        merge_side_block(&mut w, vec![tx]).await;
        let u = utxos(&w);
        eprintln!(
            "ARMED GENUINE: bond_utxo_present={} mint={:?} registry_slashed_at={:?}",
            u.contains_key(&w.bond_outpoint),
            u.get(&TransactionOutpoint::new(id, 0)).map(|e| e.amount),
            registry_slashed(&w)
        );
        assert!(!u.contains_key(&w.bond_outpoint), "a genuine merged equivocation still slashes the UTXO");
        assert!(u.contains_key(&TransactionOutpoint::new(id, 0)), "and pays its reporter");
        assert!(matches!(registry_slashed(&w), Some(Some(_))), "and the registry agrees");
    }

    /// (2) Regression for the MSK-26A follow-up: resolution keeps the FIRST evidence naming a bond,
    /// and that tx supplies the reporter payload, the mint outpoint and the victim epoch. A forged
    /// tx placed ahead of a genuine one in the same mergeset must decide none of them — armed, the
    /// unproved tx is dropped BEFORE resolution, so the genuine tx is the effect.
    #[tokio::test]
    async fn armed_a_forged_evidence_ahead_of_a_genuine_one_neither_takes_the_mint_nor_picks_the_epoch() {
        let mut w = world(Some(ForkActivation::always())).await;
        let forged_tx = evidence_tx(&w, w.atk.seed, w.a_funds[0], forged(&w, 99, w.a_payload));
        let genuine_tx = evidence_tx(&w, w.honest.seed, w.k_funds[1], genuine(&w, 1, w.k_payload));
        let (fid, gid) = (forged_tx.id(), genuine_tx.id());

        // Pure-function view of exactly what `apply_slashing_side_effects` computes past the fence.
        {
            use kaspa_consensus_core::dns_finality::resolve_slashing_side_effects;
            let view = w.ctx.consensus.virtual_processor().initial_active_bond_view();
            let txs = vec![forged_tx.clone(), genuine_tx.clone()];
            let daa = w.ctx.consensus.get_virtual_daa_score();
            let window = w.ctx.consensus.params().dns_params.clone().unwrap().evidence_window_blocks;
            let net = w.ctx.consensus.params().genesis.hash;
            // What the by-bond filter computed: the forged tx wins the dedup and survives.
            let mut by_bond = resolve_slashing_side_effects(&txs, &view, daa, 1000, 4000, 4000);
            let proved = crate::pipeline::virtual_processor::utxo_validation::proved_slash_targets(&txs, &view, net, daa, window);
            by_bond.retain(|e| proved.contains(&e.bond_outpoint));
            assert_eq!(by_bond.len(), 1);
            assert_eq!(by_bond[0].slashing_tx_id, fid, "the by-bond filter lets the forgery choose (the bug this pins)");
            // What the fix computes: only proved txs reach resolution.
            let proved_txs =
                crate::pipeline::virtual_processor::utxo_validation::proved_slashing_evidence_txs(&txs, &view, net, daa, window);
            assert_eq!(proved_txs.iter().map(|t| t.id()).collect::<Vec<_>>(), vec![gid], "only the genuine tx is proved");
            let effects = resolve_slashing_side_effects(&proved_txs, &view, daa, 1000, 4000, 4000);
            eprintln!(
                "PURE: effects={} slashed_epoch={} slashing_tx_is_genuine={} reporter_is_honest={}",
                effects.len(),
                effects[0].slashed_epoch,
                effects[0].slashing_tx_id == gid,
                effects[0].reporter_output.as_ref().map(|o| o.script_public_key == p2pkh_mldsa87_spk(&w.k_payload)).unwrap_or(false)
            );
            assert_eq!(effects.len(), 1);
            assert_eq!(effects[0].slashed_epoch, 1, "the victim epoch is the SIGNED epoch of the genuine evidence");
            assert_eq!(effects[0].slashing_tx_id, gid);
            assert_eq!(
                effects[0].reporter_output.as_ref().map(|o| o.script_public_key.clone()),
                Some(p2pkh_mldsa87_spk(&w.k_payload)),
                "the genuine reporter is the one paid"
            );
        }

        merge_side_block(&mut w, vec![forged_tx, genuine_tx]).await;
        let u = utxos(&w);
        let forged_mint = u.get(&TransactionOutpoint::new(fid, 0)).map(|e| e.amount);
        let genuine_mint = u.get(&TransactionOutpoint::new(gid, 0)).map(|e| (e.amount, e.script_public_key.clone()));
        eprintln!(
            "ARMED MIXED: bond_utxo_present={} forged_mint={forged_mint:?} genuine_mint={genuine_mint:?} registry_slashed_at={:?}",
            u.contains_key(&w.bond_outpoint),
            registry_slashed(&w)
        );
        assert!(!u.contains_key(&w.bond_outpoint), "the genuine equivocation slashes");
        assert_eq!(forged_mint, None, "the forger is minted nothing");
        assert_eq!(
            genuine_mint.map(|(_, spk)| spk),
            Some(p2pkh_mldsa87_spk(&w.k_payload)),
            "the reporter reward is minted at the GENUINE tx, to its reporter"
        );
        assert!(matches!(registry_slashed(&w), Some(Some(_))), "and the registry agrees");
    }

    /// (3) The node-only half: the mempool refuses the forged evidence and admits the genuine one.
    #[tokio::test]
    async fn node_mempool_refuses_forged_admits_genuine() {
        let w = world(None).await;
        let forged_tx = evidence_tx(&w, w.atk.seed, w.a_funds[0], forged(&w, 1, w.a_payload));
        let genuine_tx = evidence_tx(&w, w.honest.seed, w.k_funds[1], genuine(&w, 1, w.k_payload));
        let mempool = |tx: &Transaction| {
            let mut m = MutableTransaction::from_tx(tx.clone());
            w.ctx.consensus.validate_mempool_transaction(&mut m, &Default::default())
        };
        let f = mempool(&forged_tx);
        let g = mempool(&genuine_tx);
        eprintln!("MEMPOOL: forged={f:?} genuine={g:?}");
        assert!(matches!(f, Err(kaspa_consensus_core::errors::tx::TxRuleError::PalwSlashingEvidenceNotGenuine(_))));
        assert!(g.is_ok());
    }
}

/// **RFC-0004 A6: the processor's gates for the evaluation court (spec 17 §17.8.6)** — pinned on the source for the
/// reason the other gates are (P-B3's): deleting a gate leaves every behavioural test that drives only the core's own
/// checks green. Below `palw_improvement_v1` an evaluation proof or a dissection move of an evaluation claim is dropped
/// by name by the acceptance walk, first and charged nothing, refused at the close gate, at the one-move accusation's
/// gate and at the root claim's; above it the root claim is admitted by the k-ary court's fence, the responder's
/// signature, the ruleset's arity and the finalize at the court's limits.
#[test]
fn the_processor_gates_the_evaluation_courts_objects_below_palw_improvement_v1() {
    let source = include_str!("processor.rs");
    assert!(
        source.contains("palw_object_is_eval_v1(&object) && !self.palw_improvement_at(point.daa_score)"),
        "the acceptance walk drops an evaluation court object by name below the fence"
    );
    // The CourtClosed proof filter, the close gate and the one-move accusation's gate.
    let gates = source.matches("proof.is_eval_v1() && !self.palw_improvement_at(point.daa_score)").count();
    assert_eq!(gates, 3, "the close filter, the close gate and the accusation's gate");
    // The evaluation root claim: the fence, the k-ary court, the responder's signature, the arity and the finalize.
    let start = source.find("Obj::CourtEvalRootClaimed {").expect("the evaluation root claim's arm");
    let rest = &source[start..];
    let end = rest.find("Obj::CourtTirDissected {").expect("the arm ends where F7's round begins");
    let arm = &rest[..end];
    for needle in [
        "self.palw_improvement_at(point.daa_score)",
        "palw_tir_dissection_move_is_admissible_v1(",
        "check_court_eval_root_claim_acceptance_v1(",
        "check_court_eval_root_claim_admits_v1(",
        "derived.dissection_arity()",
    ] {
        assert!(arm.contains(needle), "the evaluation root claim's arm asks {needle}");
    }
    // The object has a name in the processor's own listing.
    assert!(source.contains("O::CourtEvalRootClaimed { .. } => \"CourtEvalRootClaimed\""));
}

/// **The merge-depth predicate the round lane's template asks is the validator's** (the 2026-10-03 execution-lane wedge).
///
/// A tip older than the merge-depth window that no chain block ever merged made every round template parent on it,
/// and the header stage refused every block with `ViolatingBoundedMergeDepth` — 10,106 times on b0, the lane's only 8k
/// producer. `round_adapt_block_template` now drops a tip whose merge `BlockDepthManager::merge_breaking_reds` names,
/// the very function `check_bounded_merge_depth` and the virtual's parent selection run. This is the DAG of
/// `bounded_merge_depth_test` (a stale side chain against a long selected chain), asking the predicate where the
/// header stage's verdict is known: stale tip → named (and refused), kosherized tip → empty (and accepted).
#[tokio::test]
async fn the_round_templates_merge_depth_predicate_names_the_stale_tip_the_validator_refuses() {
    let mut params = DEVNET_PARAMS;
    params.evm_activation_daa_score = u64::MAX;
    let config = ConfigBuilder::new(params)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.ghostdag_k = 5;
            p.merge_depth = 7;
        })
        .build();
    let consensus = TestConsensus::new(&config);
    let wait_handles = consensus.init();
    let genesis = config.genesis.hash;

    let mut selected_chain = vec![genesis];
    for i in 1..(config.merge_depth + 3) {
        let hash: BlockHash = (i + 1).into();
        consensus.add_header_only_block_with_parents(hash, vec![*selected_chain.last().unwrap()]).await.unwrap();
        selected_chain.push(hash);
    }
    let mut stale_chain = vec![genesis];
    for i in 1..(config.merge_depth + 2) {
        let hash: BlockHash = (i + config.merge_depth + 3).into();
        consensus.add_header_only_block_with_parents(hash, vec![*stale_chain.last().unwrap()]).await.unwrap();
        stale_chain.push(hash);
    }
    let services = &consensus.services;
    let pruning_point = consensus.pruning_point();
    let asks = |parents: Vec<BlockHash>| {
        let data = services.ghostdag_manager.ghostdag(&parents);
        let root = services.depth_manager.calc_merge_depth_root(&data, pruning_point);
        services.depth_manager.merge_breaking_reds(&data, root)
    };

    // The stale tip beside the selected chain: red, outside the window, kosherized by nobody — named, and the validator refuses it.
    let stale = vec![stale_chain[1], *selected_chain.last().unwrap()];
    assert!(!asks(stale.clone()).is_empty(), "a stale tip no blue covers is named by the predicate");
    assert!(
        matches!(
            consensus.add_header_only_block_with_parents(100.into(), stale).await,
            Err(kaspa_consensus_core::errors::block::RuleError::ViolatingBoundedMergeDepth)
        ),
        "and the header stage refuses exactly that merge"
    );
    // The selected chain alone merges nothing red: empty, as a template with no stale tip.
    assert!(asks(vec![*selected_chain.last().unwrap()]).is_empty(), "no reds, nothing to refuse");
    // A tip a blue kosherizes is empty — and the validator accepts it (`bounded_merge_depth_test`'s kosherizing block).
    let kosherized = vec![stale_chain[stale_chain.len() - 3], selected_chain[selected_chain.len() - 3]];
    assert!(asks(kosherized.clone()).is_empty(), "within the window the predicate names nothing");
    consensus.add_header_only_block_with_parents(102.into(), kosherized).await.expect("the validator accepts what the predicate passes");

    consensus.shutdown(wait_handles);
}


/// Private fixture only: the production presets intentionally assign no retirement fence.
#[tokio::test]
async fn rfc0012_retirement_uses_incumbent_and_ignores_opposed_dns_anchor() {
    use crate::model::stores::dns_state::DnsStateStore;
    use kaspa_consensus_core::{
        config::params::{DnsBftGateV1, ForkActivation},
        dns_finality::{ActiveBondView, DnsHealth, DnsReorgOutcome, DnsRolloutStage, DnsState, StakeScore},
        palw_mode_v2::PalwConsensusMode,
        palw_native_settlement_v1::{PalwDnsRetirementV1, PalwSettlementPolicyV1},
    };
    let catalog = palw_v2_test_catalog();
    let bundle = palw_v2_test_bundle(&catalog);
    // Validated WITHOUT the retirement, which is set afterwards: the release's validation requires `palw_fork_choice_rule_e_v1` armed
    // at or below it (ADR-0175), a fence this fixture does not arm; the test is about the retirement's own behaviour.
    let mut config = ConfigBuilder::new(MAINNET_PARAMS)
        .skip_proof_of_work()
        .edit_consensus_params(|p| {
            p.palw_consensus_mode = PalwConsensusMode::ConsensusV2(bundle.clone());
            *p = p.clone().with_palw_v2_cadence();
            p.dns_params.as_mut().unwrap().full_reward_split_daa_score = 0;
            p.dns_bft_gate = Some(DnsBftGateV1 {
                activation: ForkActivation::new(1),
                t_leak_daa: 50,
                reentry_final_depth_daa: 10,
                min_retained_validators: 4,
            });
        })
        .build();
    config.params.palw_dns_retirement = Some(PalwDnsRetirementV1 {
        activation: ForkActivation::new(5),
        settlement: PalwSettlementPolicyV1 {
            settled_anchor_depth: 2,
            unique_mature_work: 20,
            max_operator_permille: 1000,
            max_class_permille: 1000,
        },
        legacy_evidence_horizon_daa: 10,
    });
    let mut ctx = TestContext::new(TestConsensus::new(&config));
    for _ in 0..16 {
        ctx.build_block_template_row(0..1).validate_and_insert_row().await.assert_valid_utxo_tip();
    }
    let vp = ctx.consensus.virtual_processor();
    let sink = ctx.consensus.get_sink();
    let chain: Vec<_> = vp
        .reachability_service
        .default_backward_chain_iterator(sink)
        .map(|h| (h, vp.headers_store.get_daa_score(h).unwrap()))
        .collect();
    let below = chain.iter().find(|(_, d)| *d < 5 && *d >= 1).unwrap().0;
    let candidate = chain.last().unwrap().0;
    let anchor = chain[1];
    let write = |confirmed, daa| {
        vp.dns_state_store
            .write()
            .set(DnsState {
                selected_chain_anchor: sink,
                anchor_daa_score: daa,
                work_depth: Default::default(),
                stake_depth: StakeScore(0),
                last_dns_confirmed_anchor: confirmed,
                last_dns_confirmed_anchor_daa_score: anchor.1,
                rollout_stage: DnsRolloutStage::Active,
                validator_set_commitment: Default::default(),
                health: DnsHealth::Active,
            })
            .unwrap()
    };
    write(Default::default(), chain[0].1);
    let baseline = vp.dns_reorg_outcome(candidate, sink, &ActiveBondView::default());
    write(anchor.0, chain[0].1);
    assert_eq!(vp.dns_bft_gate_refusal(candidate, sink), None);
    assert_eq!(vp.dns_reorg_outcome(candidate, sink, &ActiveBondView::default()), baseline);
    assert_ne!(baseline, DnsReorgOutcome::HardCheckpointReject);
    assert!(vp.dns_reorg_outcome(sink, sink, &ActiveBondView::default()).is_accept());
    // A below-fence incumbent still applies its historical BFT rule, even if its candidate is above it.
    assert_eq!(vp.dns_bft_gate_refusal(candidate, below), Some(DnsReorgOutcome::HardCheckpointReject));
    let split = vp.fee_split_at(5).unwrap();
    assert_eq!((split.subsidy_worker_base_bps, split.subsidy_worker_inclusion_bps, split.subsidy_validator_bps), (9200, 800, 0));
    assert_eq!((split.normal_fee_worker_bps, split.finality_fee_worker_bps), (10000, 10000));
    assert_eq!(vp.palw_escrow_carve_at(5, 5).unwrap().worker_carve_permille(), 920);
    assert_eq!(vp.palw_escrow_carve_at(4, 5), vp.palw_escrow_carve_at(4, 4), "no retrospective increase of an old earning");
    let state = vp.palw_candidate_state_v2(sink).unwrap();
    let subsidy = vp.coinbase_manager.calc_block_subsidy(chain[0].1);
    assert_eq!(
        vp.palw_v2_escrow_withheld_at(&state, sink, chain[0].1),
        kaspa_consensus_core::palw_native_settlement_v1::native_worker_base_v1(subsidy),
        "the removed validator allocation cannot become an immediate miner windfall"
    );
    // Persisted DNS-safe pointers must never become native-safe by reopening an old store.
    use crate::model::stores::evm::EvmCanonicalHeadsStore;
    use kaspa_consensus_core::{
        api::ConsensusApi,
        evm::CanonicalEvmHeads,
        palw_native_settlement_v1::{NativeSettlementSnapshotV1, SettlementStopV1},
    };
    let consensus = ctx.consensus.consensus_clone();
    let zero = BlockHash::default();
    consensus.storage.evm_heads_store.write().set(CanonicalEvmHeads { latest: zero, safe: sink, finalized: sink }).unwrap();
    let cleared = consensus.get_evm_canonical_heads().unwrap().unwrap();
    assert!(cleared.safe_head().is_none() && cleared.finalized_head().is_none());
    let mut status = NativeSettlementSnapshotV1 {
        version: 1,
        ruleset_id: config.params.consensus_params_id(),
        policy_id: config.params.palw_dns_retirement.unwrap().settlement.id(),
        generation: sink,
        retirement_daa: 5,
        frontier: None,
        latest: None,
        safe: None,
        finalized: None,
        depth: 0,
        unique_work: "0".into(),
        stop: Some(SettlementStopV1::MissingHistory),
    };
    let publish = |s| {
        let mut batch = rocksdb::WriteBatch::default();
        consensus.storage.evm_heads_store.write().set_native_batch(&mut batch, Some(s)).unwrap();
        vp.db.write(batch).unwrap();
    };
    publish(status.clone());
    assert_eq!(consensus.get_native_settlement_snapshot().unwrap(), Some(status.clone()));
    status.stop = Some(SettlementStopV1::FinalizedConflict);
    publish(status.clone());
    let conflict = vp.native_evm_settlement_snapshot(sink);
    assert_eq!(conflict.stop, Some(SettlementStopV1::FinalizedConflict));
    publish(conflict);
    assert_eq!(
        vp.native_evm_settlement_snapshot(sink).stop,
        Some(SettlementStopV1::FinalizedConflict),
        "an absent safe/finalized publication cannot erase a prior conflict on the next commit"
    );
    status.stop = Some(SettlementStopV1::MissingHistory);
    status.generation = candidate;
    publish(status);
    assert!(consensus.get_native_settlement_snapshot().is_err(), "a reorg/restart never reuses another generation's evidence");
    let validator = &vp.transaction_validator;
    use kaspa_consensus_core::{errors::tx::TxRuleError, subnets::*, tx::Transaction};
    for id in [SUBNETWORK_ID_STAKE_BOND, SUBNETWORK_ID_STAKE_ATTESTATION_SHARD, SUBNETWORK_ID_STAKE_PRECOMMIT] {
        let tx = Transaction::new(0, vec![], vec![], 0, id.clone(), 0, vec![]);
        assert!(validator.check_dns_retirement(&tx, 4).is_ok());
        assert!(matches!(validator.check_dns_retirement(&tx, 5), Err(TxRuleError::DnsParticipationRetired(_))));
        assert!(matches!(
            vp.classify_attestation_shard_for_template(&tx, &ActiveBondView::default(), 5),
            super::utxo_validation::AttestationShardDecision::Drop {
                reason: super::utxo_validation::AttestationDropReason::DnsRetired,
                ..
            }
        ));
    }
    for id in [SUBNETWORK_ID_STAKE_UNBOND, SUBNETWORK_ID_PALW_COMMITMENT, SUBNETWORK_ID_PALW_RECEIPT] {
        assert!(validator.check_dns_retirement(&Transaction::new(0, vec![], vec![], 0, id.clone(), 0, vec![]), 5).is_ok());
    }
}
