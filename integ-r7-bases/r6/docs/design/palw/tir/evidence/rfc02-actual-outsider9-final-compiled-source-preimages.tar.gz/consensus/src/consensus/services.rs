use super::storage::ConsensusStorage;
use crate::{
    config::Config,
    model::{
        services::{reachability::MTReachabilityService, relations::MTRelationsService, statuses::MTStatusesService},
        stores::{
            DB, block_window_cache::BlockWindowCacheStore, daa::DbDaaStore, depth::DbDepthStore, ghostdag::DbGhostdagStore,
            headers::DbHeadersStore, headers_selected_tip::DbHeadersSelectedTipStore, past_pruning_points::DbPastPruningPointsStore,
            pruning::DbPruningStore, pruning_samples::DbPruningSamplesStore, reachability::DbReachabilityStore,
            relations::DbRelationsStore, selected_chain::DbSelectedChainStore, statuses::DbStatusesStore,
        },
    },
    processes::{
        block_depth::BlockDepthManager, coinbase::CoinbaseManager, ghostdag::protocol::GhostdagManager,
        parents_builder::ParentsManager, pruning::PruningPointManager, pruning_proof::PruningProofManager, sync::SyncManager,
        transaction_validator::TransactionValidator, traversal_manager::DagTraversalManager, window::SampledWindowManager,
    },
};
use kaspa_consensus_core::config::params::ForkActivation;
use kaspa_consensus_core::mass::MassCalculator;
use kaspa_txscript::caches::TxScriptCacheCounters;
use std::sync::{Arc, atomic::AtomicBool};

pub type DbGhostdagManager =
    GhostdagManager<DbGhostdagStore, MTRelationsService<DbRelationsStore>, MTReachabilityService<DbReachabilityStore>, DbHeadersStore>;

pub type DbDagTraversalManager = DagTraversalManager<DbGhostdagStore, DbReachabilityStore, MTRelationsService<DbRelationsStore>>;

pub type DbWindowManager = SampledWindowManager<DbGhostdagStore, BlockWindowCacheStore, DbHeadersStore, DbDaaStore>;

pub type DbSyncManager = SyncManager<
    MTRelationsService<DbRelationsStore>,
    DbReachabilityStore,
    DbGhostdagStore,
    DbSelectedChainStore,
    DbHeadersSelectedTipStore,
    DbPruningStore,
    DbStatusesStore,
>;

pub type DbPruningPointManager = PruningPointManager<
    DbGhostdagStore,
    DbReachabilityStore,
    DbHeadersStore,
    DbPastPruningPointsStore,
    DbHeadersSelectedTipStore,
    DbPruningSamplesStore,
>;
pub type DbBlockDepthManager = BlockDepthManager<DbDepthStore, DbReachabilityStore, DbGhostdagStore, DbHeadersStore>;
pub type DbParentsManager = ParentsManager<DbHeadersStore, DbReachabilityStore, MTRelationsService<DbRelationsStore>>;

pub struct ConsensusServices {
    // Underlying storage
    _storage: Arc<ConsensusStorage>,

    // Services and managers
    pub statuses_service: MTStatusesService<DbStatusesStore>,
    pub relations_service: MTRelationsService<DbRelationsStore>,
    pub reachability_service: MTReachabilityService<DbReachabilityStore>,
    pub window_manager: DbWindowManager,
    pub dag_traversal_manager: DbDagTraversalManager,
    pub ghostdag_manager: DbGhostdagManager,
    pub coinbase_manager: CoinbaseManager,
    pub pruning_point_manager: DbPruningPointManager,
    pub pruning_proof_manager: Arc<PruningProofManager>,
    pub parents_manager: DbParentsManager,
    pub sync_manager: DbSyncManager,
    pub depth_manager: DbBlockDepthManager,
    pub mass_calculator: MassCalculator,
    pub transaction_validator: TransactionValidator,
}

impl ConsensusServices {
    pub fn new(
        db: Arc<DB>,
        storage: Arc<ConsensusStorage>,
        config: Arc<Config>,
        tx_script_cache_counters: Arc<TxScriptCacheCounters>,
        is_consensus_exiting: Arc<AtomicBool>,
    ) -> Arc<Self> {
        let params = &config.params;

        let statuses_service = MTStatusesService::new(storage.statuses_store.clone());
        let relations_service = MTRelationsService::new(storage.relations_store.clone());
        let reachability_service = MTReachabilityService::new(storage.reachability_store.clone());
        let dag_traversal_manager = DagTraversalManager::new(
            params.genesis.hash,
            storage.ghostdag_store.clone(),
            relations_service.clone(),
            reachability_service.clone(),
        );
        let window_manager = SampledWindowManager::new(
            &params.genesis,
            storage.ghostdag_store.clone(),
            storage.headers_store.clone(),
            storage.daa_excluded_store.clone(),
            storage.block_window_cache_for_difficulty.clone(),
            storage.block_window_cache_for_past_median_time.clone(),
            params.max_difficulty_target,
            params.target_time_per_block(),
            params.difficulty_window_size,
            params.min_difficulty_window_size.min(params.difficulty_window_size),
            params.difficulty_sample_rate,
            params.past_median_time_window_size,
            params.past_median_time_sample_rate,
            params.palw_difficulty_priced_rows.unwrap_or(ForkActivation::never()),
            params.palw_receipt_rows_unpriced.unwrap_or(ForkActivation::never()),
            // ADR-0125: round blocks are outside every block's DAA set past the lane's fence.
            params.palw_execution_lane_fence().map(|lane| lane.activation),
            params.palw_single_lottery,
            // ADR-0138: past this fence only a `bits`-priced block advances the DAA score.
            params.palw_anchor_clock,
            // ADR-0142: past this one the heartbeat lane earns its exemption only at or past the
            // cursor, so the score is bounded in wall clock rather than in chain blocks.
            params.palw_clock_cursor,
            // The 2026-09-24 heartbeat audit's H3/H5: the stamp rules the header stage reads.
            params.palw_clock_floor,
            // ADR-0165: past this fence an attempt-lane block is a clock tick source.
            params.palw_real_clock_tick_v1,
        );
        let depth_manager = BlockDepthManager::new(
            params.merge_depth(),
            params.finality_depth(),
            params.genesis.hash,
            storage.depth_store.clone(),
            reachability_service.clone(),
            storage.ghostdag_store.clone(),
            storage.headers_store.clone(),
        );
        let ghostdag_manager = GhostdagManager::new(
            params.genesis.hash,
            params.ghostdag_k(),
            storage.ghostdag_store.clone(),
            relations_service.clone(),
            storage.headers_store.clone(),
            reachability_service.clone(),
            // ADR-0060 as ADR-0066 fenced it: heartbeat blocks weigh ε exactly where the lane is
            // open, which is a `ConsensusV2` network whose `palw_heartbeat` fence is in force.
            params.palw_heartbeat_lane_fence(),
            // ADR-0068 Phase 1 (F2): attempt blocks weigh the network constant under this fence.
            params.palw_attempt_work_fence(),
            // ADR-0105: a heartbeat never turns a bonded block red, past this fence.
            crate::processes::ghostdag::protocol::HeartbeatTransparency::from_params(params),
            // ADR-0125: a round block is never a selected parent and always red, past this fence.
            params.palw_execution_lane_fence().map(|lane| lane.activation),
        );

        let coinbase_manager = CoinbaseManager::new(
            params.coinbase_payload_script_public_key_max_len,
            params.max_coinbase_payload_len,
            params.deflationary_phase_daa_score,
            params.pre_deflationary_phase_base_subsidy,
            params.target_time_per_block_history(),
        )
        // RFC-0008 v2: the anchor-trailer readings exist only where the EXEC payload is armed.
        .with_exec_v2_armed(params.palw_exec_payload_v2_fence().is_some());

        let mass_calculator = MassCalculator::new(
            params.mass_per_tx_byte,
            params.mass_per_script_pub_key_byte,
            params.mass_per_sig_op,
            params.storage_mass_parameter,
        );

        let transaction_validator = TransactionValidator::new(
            params.max_tx_inputs,
            params.max_tx_outputs,
            params.max_signature_script_len,
            params.max_script_public_key_len,
            params.coinbase_payload_script_public_key_max_len,
            params.coinbase_maturity(),
            params.mergeset_size_limit(),
            tx_script_cache_counters,
            mass_calculator.clone(),
            params.pq_enforcement,
            params.pq_activation_daa_score,
            params.palw_panel_da_admissible(),
            params.palw_prompt_ids_form_v1(),
            // **ADR-0087 Decision 6 (mainnet audit 2026-09-06, M-9): the resolved fence.**
            // `palw_model_market.is_some()` was the only `is_some()` read of this fence in the
            // tree — every other consumer goes through `palw_model_market_active_at` — and it made
            // a build that merely SCHEDULES the market relax a consensus transaction rule from
            // genesis. `palw_model_market_fence()` folds in the ConsensusV2 mode condition and is
            // the one place the market is decided (`params.rs:2592`).
            params.palw_model_market_fence(),
            // **ADR-0018 §E's payout bounds, height-free** (mainnet audit 2026-09-06, H-3). The
            // isolation cap is context-free by contract; the builders ask the height-indexed
            // question at the block's own DAA, which is strictly stronger.
            params.palw_validator_payout_bounds_declared(),
            // **A-2 (mainnet audit 2026-09-11), height-free**: a ruleset that declares the audit
            // fence tolerates an undecodable/unknown-version 0x4b payload at isolation (the fold
            // skips it at every height anyway); one that does not keeps refusing it as today.
            params.palw_audit_2026_09_11_fence().is_some(),
            // **ADR-0119 Decision 6: the held regime's fence**, resolved — isolation's work-leaves cap
            // asks `.is_some()`, the header-context door asks the height.
            params.palw_held_context_fence(),
        )
        // ADR-0125: the lane's payee outputs widen the coinbase cap where the lane is configured.
        .with_round_lane_declared(params.palw_execution_lane_fence().is_some())
        .with_receipt_v4_declared(params.palw_receipt_spend_v4_fence().is_some())
        // ADR-0152-adjacent (Activation Pool): the activation sink's two doors, where the ruleset
        // declares the pool (testnet-12 alone).
        .with_activation_pool_fence(params.palw_activation_pool_fence().map(|pool| pool.activation))
        // RFC-0004 (spec 17 §17.11.1): the improvement sink's two doors, where the ruleset arms the
        // improvement fence. `None` on every shipped preset.
        .with_improvement_fence(params.palw_improvement_v1_fence().map(|fence| fence.activation))
        // Lane sink (the model sink binding, post-launch): past its height an unbound model sink is
        // refused in the header context. `None` on every shipped preset until the operator arms it.
        .with_model_sink_bound_fence(params.palw_model_sink_bound_fence())
        // RFC-0001 §A.4 (FP Job V4): the V4 job's two doors, where the ruleset carries the decode-rules
        // fence. `None` on every shipped preset, which keeps each network's transaction validity as is.
        .with_dns_retirement(params.palw_dns_retirement)
        // A-2 uniformity: a lifecycle kind the live build cannot decode meets its own stateless rule only past its owning fence.
        .with_lifecycle_kind_fences(params.palw_lifecycle_kind_fences_v1())
        .with_fp_decode_rules_fence(params.palw_fp_decode_rules_fence())
        // RFC-0003 §I.4.4 (the tensor claim, FP job version 10): its two doors, where the ruleset carries
        // `palw_fp_job_v5`. `None` on every shipped preset.
        .with_fp_job_v5_fence(params.palw_fp_job_v5_fence())
        // RFC-0001 §2.6 stage 2 (the prefix-state claim, FP job version 11): its two doors, where the ruleset carries
        // `palw_fp_prefix_state`. `None` on every shipped preset.
        .with_fp_prefix_state_fence(params.palw_fp_prefix_state_fence())
        // RFC-0001 §2.6 stage 2b: the inherited-prefix claim's fence. `None` on every shipped preset.
        .with_fp_prefix_inherit_fence(params.palw_fp_prefix_inherit_fence())
        // ADR-0096 Decision 8 and RFC-0001 §2.5: the constrained claim's fences. `None` on every shipped preset.
        .with_fp_decode_constraint_fence(params.palw_fp_decode_constraint_fence())
        .with_fp_constraint_v2_fence(params.palw_fp_constraint_v2_fence());

        let pruning_point_manager = PruningPointManager::new(
            params.pruning_depth(),
            params.finality_depth(),
            params.genesis.hash,
            reachability_service.clone(),
            storage.ghostdag_store.clone(),
            storage.headers_store.clone(),
            storage.past_pruning_points_store.clone(),
            storage.headers_selected_tip_store.clone(),
            storage.pruning_samples_store.clone(),
        );

        let parents_manager = ParentsManager::new(
            params.max_block_level,
            params.genesis.hash,
            storage.headers_store.clone(),
            reachability_service.clone(),
            relations_service.clone(),
        );

        let pruning_proof_manager = Arc::new(
            PruningProofManager::new(
            db,
            &storage,
            parents_manager.clone(),
            reachability_service.clone(),
            ghostdag_manager.clone(),
            dag_traversal_manager.clone(),
            window_manager.clone(),
            params.max_block_level,
            params.genesis.hash,
            // PR-8.6: Layer 0 PoW per-network domain separation tag.
            params.net.to_string().into_bytes(),
            params.pruning_proof_m,
            params.anticone_finalization_depth(),
            params.ghostdag_k(),
            params.skip_proof_of_work,
            params.pow_blake2b_sha3_activation,
            params.pow_palw_activation,
            params.palw_block_commitment,
            params.pow_palw_ollama_activation,
            params.palw_consensus_mode.required_algo_id(),
            params.palw_consensus_mode.clone(),
            params.palw_heartbeat_lane_fence(),
            params.palw_attempt_work_fence(),
            // ADR-0105: the coloring rule at every proof level, building and validating alike.
            crate::processes::ghostdag::protocol::HeartbeatTransparency::from_params(params),
            params.palw_attempt_activation,
            // ADR-0125: the round lane's fence, for proof GHOSTDAG and the proof header gate alike.
            params.palw_execution_lane_fence().map(|lane| lane.activation),
            // ADR-0132 S (H-1 of the 2026-09-18 audit): a proof's post-fence attempt headers carry
            // no Layer-0 work, so the proof's PoW check reads the same fence the pipeline does.
            params.palw_single_lottery,
            is_consensus_exiting,
        )
        // A-2 uniformity: a header carriage form added after the live build is read as that build reads it below its fence.
        .with_header_forms(params.palw_header_form_fences_v1()),
        );

        let sync_manager = SyncManager::new(
            params.mergeset_size_limit(),
            reachability_service.clone(),
            dag_traversal_manager.clone(),
            storage.ghostdag_store.clone(),
            storage.selected_chain_store.clone(),
            storage.headers_selected_tip_store.clone(),
            storage.pruning_point_store.clone(),
            storage.statuses_store.clone(),
        );
        // **RFC-0008 v2 (sync): the EXEC blocks a chain block's anchor covers**, so that IBD lists and requests them although no block
        // names them as a parent. Installed only where the payload is armed.
        let sync_manager = if let Some(exec_v2_fence) = params.palw_exec_payload_v2_fence() {
            use crate::model::stores::{
                acceptance_data::AcceptanceDataStoreReader, ghostdag::GhostdagStoreReader as _, headers::HeaderStoreReader,
                relations::RelationsStoreReader,
            };
            use kaspa_consensus_core::BlockHash;
            let members = {
                let acceptance_data_store = storage.acceptance_data_store.clone();
                let ghostdag_store = storage.ghostdag_store.clone();
                Arc::new(move |chain_block: BlockHash| -> Vec<BlockHash> {
                    let (Ok(acceptance), Ok(data)) = (acceptance_data_store.get(chain_block), ghostdag_store.get_data(chain_block))
                    else {
                        return Vec::new();
                    };
                    acceptance
                        .iter()
                        .map(|entry| entry.block_hash)
                        .filter(|block| {
                            *block != data.selected_parent
                                && !data.mergeset_blues.contains(block)
                                && !data.mergeset_reds.contains(block)
                        })
                        .collect()
                }) as crate::processes::sync::ExecHook
            };
            let children = {
                let relations_service = relations_service.clone();
                let headers_store = storage.headers_store.clone();
                let bound = params.palw_execution_lane_fence().map(|lane| lane.max_per_mergeset as usize).unwrap_or(0);
                Arc::new(move |from: BlockHash| -> Vec<BlockHash> {
                    let lane_id = kaspa_consensus_core::pow_layer0::POW_ALGO_ID_PALW_ROUND_V1;
                    let mut found: Vec<BlockHash> = Vec::new();
                    let mut queue = vec![from];
                    while let Some(current) = queue.pop() {
                        let Ok(children) = relations_service.get_children(current) else { continue };
                        for child in children.read().iter().copied() {
                            if found.len() >= bound || found.contains(&child) {
                                continue;
                            }
                            // Lane blocks of the v2 era only: below the fence a round block reaches a syncee through the mergeset
                            // that names it, and the list stays the one the build before RFC-0008 v2 served (the X8R review).
                            if headers_store
                                .get_header(child)
                                .is_ok_and(|header| header.pow_algo_id == lane_id && exec_v2_fence.is_active(header.daa_score))
                            {
                                found.push(child);
                                queue.push(child);
                            }
                        }
                    }
                    found
                }) as crate::processes::sync::ExecHook
            };
            sync_manager.with_exec_hooks(members, children)
        } else {
            sync_manager
        };

        Arc::new(Self {
            _storage: storage,
            statuses_service,
            relations_service,
            reachability_service,
            window_manager,
            dag_traversal_manager,
            ghostdag_manager,
            coinbase_manager,
            pruning_point_manager,
            pruning_proof_manager,
            parents_manager,
            sync_manager,
            depth_manager,
            mass_calculator,
            transaction_validator,
        })
    }
}
