# MISAKA — RFC0042 R2 / Panel証拠生成・Miner対話応答

**Draft / Review Required。Runtime未変更、実LLM未計測、mainnet未有効化。**

[RFC0042本文](docs/rfc/0042-positive-court-full-coverage.md)を同じ番号で書き直しました。証拠生成の計算はPanelが担い、Minerは通常推論・結果commit・上限付きdata応答、Nodeは独立検査・裁定を担います。

## 変更の中心

Minerの結果commitから新規の全trace生成義務を外し、Panelが自分で再計算した証拠用traceへ署名する構造です。確率型はそのPanel witnessを未知乱数の前に固定します。全必須関係の検査を少数サンプルに弱めていません。

Minerへの要求はcanonical data key/rangeで集約し、全Panelの累積bytes/work/round/費用に上限を設けます。証拠生成用計算の押戻しは禁止します。Panelの偽witnessや放棄をMinerの計算不正・資料不提出に転嫁しません。

モデルをNodeが事前保有する必要はありませんが、必要weightは公開資料として必要です。Minerだけが保有するcold caseでは大量供給が必要になり得ます。Minerの軽量化、Panelの収支、Nodeの総検査費用は別々に実測する有効化条件です。

## 文書

- [RFC0042 R2](docs/rfc/0042-positive-court-full-coverage.md)
- [ADR0210 R2](docs/adr/0210-positive-court-without-model-prepossession.md)
- [旧案との変更点](docs/design/palw/positive-court/REVISION-R2.md)
- [既存実装との対応確認](docs/design/palw/positive-court/IMPLEMENTATION-ALIGNMENT.md)
- [三者別の実測票](docs/design/palw/positive-court/MEASUREMENT.md)
- [方針差分](docs/design/palw/positive-court/POLICY-DELTA.md) / [統合先](docs/design/palw/positive-court/INTEGRATION.md)
- [今回実行した検査と限界](VALIDATION.md)

## 取り込み

このZIPは文書・参照モデルの変更セットで、フルrepositoryではありません。rootのREADME/VALIDATION/MANIFESTをrepository rootへ丸ごと上書きしないでください。

**前回のRFC0042パッケージを導入済み:** `rfc042-r2.patch`を使用。

```sh
git apply --check /path/to/rfc042-r2.patch
git apply /path/to/rfc042-r2.patch
```

**元の添付 `misakas-main (1)(1).zip` 相当でRFC0042未導入:** `rfc042-r2-from-upload.patch`を使用。二つのpatchを連続適用しません。

```sh
git apply --check /path/to/rfc042-r2-from-upload.patch
git apply /path/to/rfc042-r2-from-upload.patch
```

どちらも元資料に対してcheckと適用、生成後のbyte照合を実施しました。作業中branchの差分、別の番号予約、index変更がある場合はmerge reviewが必要です。既存のRFC15本/ADR50本整理を採用したtreeでは、RFC-v2-0014 / ADR-v2-0038へ本改訂を統合し、原文対応表とhashをそのtreeで更新します。v2本文・対応表を今回自動更新したものではありません。

## 参照モデル

```sh
python -m unittest discover -s tools/positive_court -p 'test_*.py' -v
```

42件。2×2整数計算の小例で、実署名、TIR、LLM、P2P、実永続化、Freivalds、性能認定は実装していません。以前のR1参照モデルをR2の署名帰属・状態モデルへ置き換えています。Python試験合格を実Nodeの五条件達成と読み替えないでください。
