# RFC0042 R2 — 検査結果と未検証範囲

確認日: 2026-10-31。状態: Draft。具体的なruntime・wire・高さ・mainnet承認は未変更。

## 実行した検査

| 検査 | 結果 | 範囲 |
|---|---|---|
| R2参照Python | **42 tests PASS** | 小さいexact整数program。Minerの結果commit、Panel witness生成、Node全被覆検査 |
| 正直Miner＋悪意Panel | PASS（toy） | 偽中間値・偽tokenのwitness拒否でMinerを有罪にしない |
| 誤ったMiner output | PASS（toy） | Nodeの全exact再実行後の終端不一致でのみclaim反証 |
| 対話・資料応答 | PASS（toy） | data認証、全Panel予算、重複要求集約、禁止する証拠生成要求、provider応答 |
| 不提出分離 | PASS（toy） | Miner応答済み後のPanel放棄、private ACK不要、機会がない場合の不帰責 |
| 信用・支払 | PASS（toy） | 未検証・部分検査・署名だけは不可。Gate C等の追加条件、一回支払 |
| docsの既存検査器 | **新規問題0** | 既知の参照欠落43件は維持。全参照が健全になった意味ではない |
| 前回パッケージからのR2差分 | **check・適用・byte一致** | 元の`documentation.patch`から再現したR1 treeで確認 |
| 元ZIPからのR2差分 | **check・適用・byte一致** | 元添付の文書treeへ新規導入 |
| 差分適用後の再試験 | 各treeで42件PASS | 2回の実行を84種類の独立試験とは数えない |
| Rust/TOML変更 | **0** | patch対象を確認。runtime実装を変更していない |

ログ: [reference-tests.log](evidence/reference-tests.log)、[機械可読summary](evidence/validation-summary.json)、[docs結果](evidence/validated-r2-docs.json)。

## 試験が示さないこと

参照モデルは実際のTIRやLLMではない。actor署名の認証、admission・carrier包含・service opportunity等は外から与える仮定。budgetのscalar bytes/roundは説明用で、codecやMerkle proofの実bytesではない。checkpoint任意モード、overlap range union、未知乱数の生成/候補選別、全network公平性、reorg/IBDの実processはこのtoyでは検証していない。

42件の中には25通りの入力と正誤outputを反復する一つの小範囲検査があるが、LLM全範囲や暗号健全性の証明ではない。snapshot検査もPython状態のcopyだけで、永続化/再起動の証拠ではない。

Rust build/test、multi-node E2E、実LLM、最低構成hardware、費用/採算、実乱数source、mainnet有効化は未実行。既存実装の対応確認は指定したkernel経路の静的確認であり、全laneの完成判定ではない。

## 未承認値

[measurement template](docs/design/palw/positive-court/measurement-record.template.json)の本番値は未設定のまま。mainnetで許容できるMiner/Panel/Node profileを1つも認定していない。A01〜A12を満たす同一候補での実証が必要。

## 配布整合性

`MANIFEST.json`は自己参照を除く配布fileのSHA-256を記載。ZIPのCRC、展開後の全file digest、展開後の42件試験を追加確認する。元ZIPは変更していない。
