"""Toy R2 role tests. NOT Rust/E2E/real-LLM or economic certification."""
import copy
from dataclasses import fields, replace
from itertools import product
import unittest

from interactive_reference import (Miner, Panel, Node, RequestBook, ResponsePolicy, ResultCommit,
                                   PLAN, MODEL_KEYS, INPUT_KEYS, execute)
from primitives import Refused, MerkleData


def setup(output=None, policy=None):
    miner = Miner(dict(w00=2, w01=-1, w10=1, w11=3), dict(x0=4, x1=2))
    commit = miner.infer_commit()
    if output is not None:
        commit = replace(commit, output=output)
    book = RequestBook(commit, policy or ResponsePolicy())
    return miner, commit, book


def request_all(miner, book):
    for group, kind, keys in [('model', 'ARTIFACT_RANGE', MODEL_KEYS), ('inputs', 'INPUT_RANGE', INPUT_KEYS)]:
        for key in keys:
            request = book.request(kind, group, key)
            miner.respond(book, request)


def local_source(miner):
    return {**{'model:'+k: miner.model.opening(k) for k in MODEL_KEYS},
            **{'inputs:'+k: miner.inputs.opening(k) for k in INPUT_KEYS}}


def consume(node, witness):
    node.accept_witness(witness)
    for relation in PLAN:
        if not node.submit(relation, witness.packet(relation)):
            return False
    return True


class R2Tests(unittest.TestCase):
    def test_miner_commit_has_no_trace_root(self):
        self.assertNotIn('trace', {f.name for f in fields(ResultCommit)})
        self.assertNotIn('trace_root', {f.name for f in fields(ResultCommit)})

    def test_miner_has_no_witness_builder(self):
        miner, _, _ = setup()
        self.assertFalse(hasattr(miner, 'build_witness'))
        self.assertFalse(hasattr(miner, 'trace'))

    def test_interactive_happy_path(self):
        miner, commit, book = setup(); request_all(miner, book)
        panel = Panel(); witness = panel.build(commit, book.responses); node = Node(commit)
        self.assertTrue(consume(node, witness))
        self.assertEqual(node.finish(), 'PositivePassed')
        self.assertEqual((miner.inference_calls, panel.reexecutions, panel.witness_builds), (1, 1, 1))

    def test_panel_local_model_needs_no_miner_request(self):
        miner, commit, _ = setup(); witness = Panel().build(commit, local_source(miner)); node = Node(commit)
        self.assertTrue(consume(node, witness)); node.finish()
        self.assertEqual(miner.responses, 0)

    def test_node_starts_without_model_data(self):
        _, commit, _ = setup(); node = Node(commit)
        self.assertFalse(hasattr(node, 'model'))
        self.assertEqual(node.derived, {})

    def test_bad_panel_trace_is_not_miner_fault(self):
        miner, commit, _ = setup()
        witness = Panel('bad-panel').build(commit, local_source(miner), malicious_trace={'z0':999})
        node = Node(commit); self.assertFalse(consume(node, witness))
        self.assertEqual(node.witness_state, 'WitnessRejected')
        self.assertFalse(node.miner_fault); self.assertEqual(node.status, 'PositivePending')

    def test_fake_late_intermediate_not_miner_fault(self):
        miner, commit, _ = setup()
        witness = Panel().build(commit, local_source(miner), malicious_trace={'y1':999})
        node = Node(commit); self.assertFalse(consume(node, witness)); self.assertFalse(node.miner_fault)

    def test_bad_panel_token_not_miner_fault(self):
        miner, commit, _ = setup()
        witness = Panel().build(commit, local_source(miner), malicious_trace={'token':0})
        node = Node(commit); self.assertFalse(consume(node, witness)); self.assertFalse(node.miner_fault)

    def test_wrong_miner_result_exactly_refuted(self):
        miner, commit, _ = setup(output=0)
        witness = Panel().build(commit, local_source(miner)); node = Node(commit)
        self.assertTrue(consume(node, witness)); self.assertEqual(node.finish(), 'ClaimRefuted')
        self.assertTrue(node.miner_fault)

    def test_all_collude_fake_trace_cannot_pass(self):
        miner, commit, _ = setup(output=0)
        witness = Panel('colluder').build(commit, local_source(miner), malicious_trace={'z1':0, 'y1':0, 'token':0})
        node = Node(commit); self.assertFalse(consume(node, witness)); self.assertFalse(node.credit_ready(quorum=True))

    def test_last_relation_missing_is_not_pass(self):
        miner, commit, _ = setup(); witness = Panel().build(commit, local_source(miner)); node = Node(commit)
        node.accept_witness(witness)
        for relation in PLAN[:-1]: node.submit(relation, witness.packet(relation))
        with self.assertRaises(Refused): node.finish()
        self.assertFalse(node.credit_ready(quorum=True))

    def test_skip_relation(self):
        miner, commit, _ = setup(); witness = Panel().build(commit, local_source(miner)); node = Node(commit)
        node.accept_witness(witness)
        with self.assertRaises(Refused): node.submit('dot1', witness.packet('dot1'))
        self.assertEqual(node.cursor, 0)

    def test_duplicate_relation(self):
        miner, commit, _ = setup(); witness = Panel().build(commit, local_source(miner)); node = Node(commit)
        node.accept_witness(witness); node.submit('dot0', witness.packet('dot0'))
        with self.assertRaises(Refused): node.submit('dot0', witness.packet('dot0'))
        self.assertEqual(node.cursor, 1)

    def test_malformed_opening_does_not_advance_or_blame(self):
        miner, commit, _ = setup(); witness = Panel().build(commit, local_source(miner)); node = Node(commit)
        node.accept_witness(witness); packet = witness.packet('dot0')
        packet['model:w00'] = replace(packet['model:w00'], value=77)
        with self.assertRaises(Refused): node.submit('dot0', packet)
        self.assertEqual(node.cursor, 0); self.assertFalse(node.miner_fault)

    def test_wrong_model_rejected(self):
        miner, commit, _ = setup(); source = local_source(miner)
        source['model:w00'] = MerkleData(dict(w00=88)).opening('w00')
        with self.assertRaises(Refused): Panel().build(commit, source)

    def test_wrong_input_rejected(self):
        miner, commit, _ = setup(); source = local_source(miner)
        source['inputs:x0'] = MerkleData(dict(x0=999)).opening('x0')
        with self.assertRaises(Refused): Panel().build(commit, source)

    def test_witness_different_claim(self):
        miner, commit, _ = setup(); witness = Panel().build(replace(commit, output=0), local_source(miner))
        with self.assertRaises(Refused): Node(commit).accept_witness(witness)

    def test_witness_different_network(self):
        miner, commit, _ = setup(); witness = Panel().build(replace(commit, network='other'), local_source(miner))
        with self.assertRaises(Refused): Node(commit).accept_witness(witness)

    def test_witness_cannot_change_while_checking(self):
        miner, commit, _ = setup(); witness = Panel().build(commit, local_source(miner)); node = Node(commit)
        node.accept_witness(witness)
        with self.assertRaises(Refused): node.accept_witness(witness)

    def test_panel_takeover_after_rejection(self):
        miner, commit, _ = setup(); source = local_source(miner); node = Node(commit)
        bad = Panel('bad').build(commit, source, malicious_trace={'z0':999})
        self.assertFalse(consume(node, bad))
        good = Panel('good').build(commit, source)
        self.assertTrue(consume(node, good)); self.assertEqual(node.finish(), 'PositivePassed')
        self.assertFalse(node.miner_fault)

    def test_candidates_bounded_across_panels(self):
        miner, commit, _ = setup(); source = local_source(miner); node = Node(commit, max_candidates=1)
        self.assertFalse(consume(node, Panel('p1').build(commit, source, malicious_trace={'z0':999})))
        with self.assertRaises(Refused): node.accept_witness(Panel('p2').build(commit, source))

    def test_response_duplicates_coalesce_across_panels(self):
        miner, _, book = setup()
        a = book.request('ARTIFACT_RANGE','model','w00', panel='one', nonce=1)
        b = book.request('ARTIFACT_RANGE','model','w00', panel='two', nonce=999)
        self.assertEqual(a,b); self.assertEqual(book.unique_bytes,8); self.assertEqual(len(book.requests),1)
        self.assertTrue(miner.respond(book,a)); self.assertFalse(miner.respond(book,b))
        self.assertEqual(miner.responses,1)

    def test_all_panel_round_budget(self):
        _, _, book = setup(policy=ResponsePolicy(max_rounds=1))
        book.request('ARTIFACT_RANGE','model','w00',panel='p1')
        with self.assertRaises(Refused): book.request('ARTIFACT_RANGE','model','w01',panel='p2')
        self.assertEqual(len(book.requests),1)

    def test_all_panel_byte_budget_atomic(self):
        _, _, book = setup(policy=ResponsePolicy(max_unique_bytes=8))
        book.request('ARTIFACT_RANGE','model','w00')
        with self.assertRaises(Refused): book.request('INPUT_RANGE','inputs','x0')
        self.assertEqual(book.unique_bytes,8); self.assertEqual(len(book.requests),1)

    def test_witness_generation_request_forbidden(self):
        _, _, book = setup()
        for kind in ('BUILD_WITNESS','REBUILD_FULL_TRACE','MAKE_FREIVALDS_PROJECTION'):
            with self.subTest(kind=kind), self.assertRaises(Refused): book.request(kind,'model','w00')
        self.assertEqual(book.requests,{})

    def test_optional_checkpoint_not_forced(self):
        _, _, book = setup()
        with self.assertRaises(Refused): book.request('SAVED_CHECKPOINT','checkpoint','z0')
        self.assertFalse(book.missing())

    def test_unknown_range_no_obligation(self):
        _, _, book = setup()
        with self.assertRaises(Refused): book.request('ARTIFACT_RANGE','model','w999')
        self.assertEqual(book.requests,{})

    def test_provider_can_respond_without_miner(self):
        miner, _, book = setup(); key = book.request('ARTIFACT_RANGE','model','w00')
        self.assertTrue(book.accept_response(key, miner.model.opening('w00'),1))
        self.assertEqual(miner.responses,0); self.assertEqual(book.missing(),set())

    def test_canonical_fallback_needs_no_panel_ack(self):
        miner, _, book = setup(); key = book.request('ARTIFACT_RANGE','model','w00')
        miner.respond(book,key)
        self.assertFalse(book.delivery_default(10,signed_duty=True,rooted_notice=True,service_opportunity=True))

    def test_response_at_cutoff_rejected(self):
        miner, _, book = setup(); key = book.request('ARTIFACT_RANGE','model','w00')
        with self.assertRaises(Refused): miner.respond(book,key,at=10)
        self.assertIn(key,book.missing())

    def test_forged_data_response_not_accepted(self):
        miner, _, book = setup(); key = book.request('ARTIFACT_RANGE','model','w00')
        with self.assertRaises(Refused): book.accept_response(key,replace(miner.model.opening('w00'),value=999),1)
        self.assertIn(key,book.missing())

    def test_no_default_from_private_timeout(self):
        _, _, book = setup(); book.request('ARTIFACT_RANGE','model','w00')
        self.assertFalse(book.delivery_default(11,signed_duty=True,rooted_notice=False,service_opportunity=True))

    def test_no_default_without_service_opportunity(self):
        _, _, book = setup(); book.request('ARTIFACT_RANGE','model','w00')
        self.assertFalse(book.delivery_default(11,signed_duty=True,rooted_notice=True,service_opportunity=False))

    def test_qualified_data_default(self):
        _, _, book = setup(); book.request('ARTIFACT_RANGE','model','w00')
        self.assertTrue(book.delivery_default(11,signed_duty=True,rooted_notice=True,service_opportunity=True))

    def test_panel_abandonment_not_miner_default(self):
        miner, commit, book = setup(); request_all(miner,book); node=Node(commit); node.expire(20)
        self.assertEqual(node.status,'EndedUnverified'); self.assertFalse(node.miner_fault)
        self.assertFalse(book.delivery_default(21,signed_duty=True,rooted_notice=True,service_opportunity=True))

    def test_quorum_alone_never_passes(self):
        _, commit, _ = setup(); self.assertFalse(Node(commit).credit_ready(quorum=True))

    def test_pass_still_requires_every_gate(self):
        miner,commit,_=setup();node=Node(commit);consume(node,Panel().build(commit,local_source(miner)));node.finish()
        for args in [dict(quorum=False),dict(quorum=True,dependencies=False),dict(quorum=True,pending_fraud=True),dict(quorum=True,mature=False)]:
            with self.subTest(args=args): self.assertFalse(node.credit_ready(**args))
        self.assertTrue(node.credit_ready(quorum=True))

    def test_payment_once(self):
        miner,commit,_=setup();node=Node(commit);consume(node,Panel().build(commit,local_source(miner)));node.finish()
        self.assertTrue(node.pay_once(quorum=True));self.assertFalse(node.pay_once(quorum=True))

    def test_expiry_never_pass(self):
        _,commit,_=setup();node=Node(commit);node.expire(20)
        self.assertFalse(node.credit_ready(quorum=True));self.assertFalse(node.miner_fault)

    def test_finish_at_cutoff_not_pass(self):
        miner,commit,_=setup();node=Node(commit);consume(node,Panel().build(commit,local_source(miner)))
        with self.assertRaises(Refused): node.finish(20)

    def test_snapshot_of_toy_book_preserves_budget(self):
        _,_,book=setup(policy=ResponsePolicy(max_rounds=1));book.request('ARTIFACT_RANGE','model','w00')
        restored=copy.deepcopy(book)
        with self.assertRaises(Refused):restored.request('ARTIFACT_RANGE','model','w01')
        # This tests in-memory reference state only, NOT actual persistence.

    def test_small_exhaustive_inputs_and_output_refutation(self):
        for x0,x1 in product(range(-2,3),repeat=2):
            with self.subTest(x0=x0,x1=x1):
                miner=Miner(dict(w00=2,w01=-1,w10=1,w11=3),dict(x0=x0,x1=x1));commit=miner.infer_commit()
                source=local_source(miner);good=Node(commit)
                self.assertTrue(consume(good,Panel().build(commit,source)));self.assertEqual(good.finish(),'PositivePassed')
                badcommit=replace(commit,output=1-commit.output);bad=Node(badcommit)
                self.assertTrue(consume(bad,Panel().build(badcommit,source)));self.assertEqual(bad.finish(),'ClaimRefuted')

if __name__ == '__main__':
    unittest.main(verbosity=2)
