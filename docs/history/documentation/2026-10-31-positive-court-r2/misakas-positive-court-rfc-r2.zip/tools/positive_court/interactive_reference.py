"""Executable SMALL example of RFC0042 R2's role/provenance rules.

NOT production protocol code. The toy program is 2x2 integer dense -> ReLU ->
argmax, verified exhaustively. Authentication of actor signatures, admission,
block ordering and qualified service facts are explicit external assumptions.
No real TIR/LLM, wire, network, randomness, Freivalds, fee ledger or persistence.
The byte/round budget uses synthetic units, NOT mainnet performance values.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Mapping
import json
from primitives import MerkleData, Opening, Refused, authenticate, checked_i64, digest

PLAN = ('dot0', 'dot1', 'relu0', 'relu1', 'select')
MODEL_KEYS = ('w00', 'w01', 'w10', 'w11')
INPUT_KEYS = ('x0', 'x1')
PROGRAM = 'toy-dense2-relu-argmax-v1'


def execute(weights: Mapping[str, int], inputs: Mapping[str, int]) -> dict[str, int]:
    """Panel/Node reference arithmetic; output does not assert GPU provenance."""
    z = [checked_i64(sum(checked_i64(weights[f'w{i}{j}'] * inputs[f'x{j}'])
                         for j in range(2))) for i in range(2)]
    y = [max(0, a) for a in z]
    return dict(z0=z[0], z1=z[1], y0=y[0], y1=y[1], token=0 if y[0] >= y[1] else 1)


@dataclass(frozen=True)
class ResultCommit:
    model_root: bytes
    input_root: bytes
    output: int
    miner: str = 'miner'
    network: str = 'toy-network'
    ruleset: str = 'toy-r2-exact'
    program: str = PROGRAM

    @property
    def identity(self) -> bytes:
        values = [self.model_root.hex(), self.input_root.hex(), self.output,
                  self.miner, self.network, self.ruleset, self.program]
        return digest(b'toy/result/r2\0', json.dumps(values, separators=(',', ':')).encode())


class Miner:
    """Inference/result + data responses; NO witness-generation API."""
    def __init__(self, weights: Mapping[str, int], inputs: Mapping[str, int]):
        self.model, self.inputs = MerkleData(weights), MerkleData(inputs)
        self.inference_calls = 0
        self.responses = 0

    def infer_commit(self) -> ResultCommit:
        self.inference_calls += 1
        # Normal inference may internally compute intermediates; it does NOT
        # persist or commit a proof trace/tree for the court.
        output = execute(self.model.rows, self.inputs.rows)['token']
        return ResultCommit(self.model.root, self.inputs.root, output)

    def respond(self, book: 'RequestBook', key: str, at: int = 1) -> bool:
        request = book.requests.get(key)
        if request is None:
            raise Refused('not an admitted request')
        group, name = key.split(':', 1)
        data = self.model if group == 'model' else self.inputs
        accepted = book.accept_response(key, data.opening(name), at)
        self.responses += int(accepted)
        return accepted


@dataclass(frozen=True)
class ResponsePolicy:
    max_rounds: int = 6
    max_unique_bytes: int = 48  # synthetic scalar-value bytes; excludes real codec
    cutoff: int = 10


@dataclass
class RequestBook:
    commit: ResultCommit
    policy: ResponsePolicy = field(default_factory=ResponsePolicy)
    requests: dict[str, tuple[str, str]] = field(default_factory=dict)
    responses: dict[str, Opening] = field(default_factory=dict)
    unique_bytes: int = 0

    def request(self, kind: str, group: str, name: str, *, panel: str = 'panel',
                nonce: int = 0) -> str:
        # Identity/nonce deliberately do NOT create a fresh budget or request.
        del panel, nonce
        allowed = {'model': ('ARTIFACT_RANGE', MODEL_KEYS), 'inputs': ('INPUT_RANGE', INPUT_KEYS)}
        if group not in allowed or kind != allowed[group][0] or name not in allowed[group][1]:
            raise Refused('not an admissible DATA request; witness/projection requests forbidden')
        key = f'{group}:{name}'
        if key in self.requests:
            return key
        if len(self.requests) + 1 > self.policy.max_rounds:
            raise Refused('all-panel round budget')
        if self.unique_bytes + 8 > self.policy.max_unique_bytes:
            raise Refused('all-panel unique-data budget')
        self.requests[key] = (group, name)
        self.unique_bytes += 8
        return key

    def accept_response(self, key: str, opening: Opening, at: int) -> bool:
        if key not in self.requests or at >= self.policy.cutoff:
            raise Refused('unadmitted or late response')
        group, name = self.requests[key]
        root = self.commit.model_root if group == 'model' else self.commit.input_root
        authenticate(root, name, opening)  # before any state mutation
        if key in self.responses:
            return False
        self.responses[key] = opening
        return True

    def missing(self) -> set[str]:
        return set(self.requests) - set(self.responses)

    def delivery_default(self, at: int, *, signed_duty: bool, rooted_notice: bool,
                         service_opportunity: bool) -> bool:
        return (at >= self.policy.cutoff and bool(self.missing()) and signed_duty
                and rooted_notice and service_opportunity)


@dataclass
class Witness:
    claim_id: bytes
    author: str
    trace: MerkleData
    source: dict[str, Opening]

    def packet(self, relation: str) -> dict[str, Opening]:
        result = {}
        if relation.startswith('dot'):
            i = int(relation[-1])
            for key in (f'model:w{i}0', f'model:w{i}1', 'inputs:x0', 'inputs:x1'):
                result[key] = self.source[key]
            key = f'z{i}'
        elif relation.startswith('relu'):
            key = f'y{relation[-1]}'
        elif relation == 'select':
            key = 'token'
        else:
            raise Refused('unknown relation')
        result['witness:' + key] = self.trace.opening(key)
        return result


class Panel:
    def __init__(self, identity: str = 'panel'):
        self.identity = identity
        self.reexecutions = 0
        self.witness_builds = 0

    def build(self, commit: ResultCommit, source: Mapping[str, Opening],
              *, malicious_trace: Mapping[str, int] | None = None) -> Witness:
        if commit.program != PROGRAM:
            raise Refused('unsupported program')
        weights, inputs = {}, {}
        try:
            for name in MODEL_KEYS:
                weights[name] = authenticate(commit.model_root, name, source['model:' + name])
            for name in INPUT_KEYS:
                inputs[name] = authenticate(commit.input_root, name, source['inputs:' + name])
        except KeyError as exc:
            raise Refused('missing data') from exc
        trace = execute(weights, inputs)
        self.reexecutions += 1
        if malicious_trace is not None:  # adversarial test injection only
            trace.update(malicious_trace)
        self.witness_builds += 1
        return Witness(commit.identity, self.identity, MerkleData(trace), dict(source))


@dataclass
class Node:
    commit: ResultCommit
    cutoff: int = 20
    max_candidates: int = 2
    status: str = 'PositivePending'
    witness_state: str = 'None'
    cursor: int = 0
    derived: dict[str, int] = field(default_factory=dict)
    fixed_witness_root: bytes | None = None
    witness_author: str | None = None
    attempts: int = 0
    miner_fault: bool = False
    paid: bool = False

    def accept_witness(self, witness: Witness, at: int = 1) -> None:
        if self.status != 'PositivePending' or at >= self.cutoff:
            raise Refused('claim is closed')
        if self.commit.program != PROGRAM or witness.claim_id != self.commit.identity:
            raise Refused('wrong claim/network/ruleset/program')
        if self.witness_state not in ('None', 'WitnessRejected'):
            raise Refused('fixed witness cannot be replaced')
        if self.attempts >= self.max_candidates:
            raise Refused('candidate budget')
        self.fixed_witness_root = witness.trace.root
        self.witness_author = witness.author
        self.attempts += 1
        self.witness_state = 'Checking'
        self.cursor = 0
        self.derived.clear()

    def submit(self, relation: str, packet: Mapping[str, Opening], at: int = 2) -> bool:
        if self.status != 'PositivePending' or self.witness_state != 'Checking' or at >= self.cutoff:
            raise Refused('not checking or late')
        if self.cursor >= len(PLAN) or relation != PLAN[self.cursor]:
            raise Refused('gap/duplicate/out-of-order relation')

        def get(group: str, name: str) -> int:
            roots = {'model': self.commit.model_root, 'inputs': self.commit.input_root,
                     'witness': self.fixed_witness_root}
            try:
                return authenticate(roots[group], name, packet[f'{group}:{name}'])
            except KeyError as exc:
                raise Refused('missing material') from exc

        if relation.startswith('dot'):
            i = int(relation[-1])
            expected = checked_i64(sum(checked_i64(get('model', f'w{i}{j}') * get('inputs', f'x{j}'))
                                      for j in range(2)))
            name = f'z{i}'
        elif relation.startswith('relu'):
            i = int(relation[-1])
            expected, name = max(0, self.derived[f'z{i}']), f'y{i}'
        else:
            expected = 0 if self.derived['y0'] >= self.derived['y1'] else 1
            name = 'token'
        proposed = get('witness', name)
        if proposed != expected:
            self.witness_state = 'WitnessRejected'
            # The authenticated trace was authored by PANEL, not Miner.
            # No miner misconduct is inferred from this failure.
            return False
        self.derived[name] = expected
        self.cursor += 1
        return True

    def finish(self, at: int = 3) -> str:
        if self.status != 'PositivePending' or self.witness_state != 'Checking' or at >= self.cutoff:
            raise Refused('closed or late')
        if self.cursor != len(PLAN):
            raise Refused('full coverage required')
        self.witness_state = 'Complete'
        if self.derived['token'] != self.commit.output:
            # ALL relations were verified EXACTLY from authenticated inputs.
            self.status = 'ClaimRefuted'
            self.miner_fault = True
        else:
            self.status = 'PositivePassed'
        return self.status

    def expire(self, at: int) -> None:
        if at < self.cutoff or self.status != 'PositivePending':
            raise Refused('not an expirable pending claim')
        self.status = 'EndedUnverified'

    def credit_ready(self, *, quorum: bool, dependencies: bool = True,
                     pending_fraud: bool = False, mature: bool = True) -> bool:
        return (self.status == 'PositivePassed' and self.cursor == len(PLAN)
                and quorum and dependencies and not pending_fraud and mature)

    def pay_once(self, **gates: bool) -> bool:
        if not self.credit_ready(**gates):
            raise Refused('all credit gates must hold')
        if self.paid:
            return False
        self.paid = True
        return True
