"""Toy Merkle/arithmetic primitives for RFC0042 R2. NOT a MISAKA implementation.

All inputs, fees, capacity units and hashes here are toy values. Signatures,
network consensus, real TIR, block codecs, persistence and LLM performance are
not implemented. A trusted claim-root binding is an explicit input assumption.
The verifier starts with roots, not a local model; witnesses reveal the values.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Mapping, Sequence


class Refused(ValueError):
    """A bounded, non-attributing input refusal in the reference model."""


def digest(domain: bytes, payload: bytes) -> bytes:
    return hashlib.sha256(domain + len(payload).to_bytes(8, 'big') + payload).digest()


def leaf_hash(key: str, value: int) -> bytes:
    if type(value) is not int or not -(1 << 63) <= value < (1 << 63):
        raise Refused('value must be a signed 64-bit integer')
    payload = json.dumps([key, 'i64', value], separators=(',', ':')).encode()
    return digest(b'toy/leaf/v1\0', payload)


def checked_i64(value: int) -> int:
    if not -(1 << 63) <= value < (1 << 63):
        raise Refused('arithmetic overflow')
    return value


def parent_hash(left: bytes, right: bytes) -> bytes:
    return digest(b'toy/node/v1\0', left + right)


@dataclass(frozen=True)
class Opening:
    key: str
    value: int
    index: int
    count: int
    siblings: tuple[bytes, ...]


class MerkleData:
    """Toy indexed Merkle table; not the repository's wire format or hash."""
    def __init__(self, rows: Mapping[str, int]):
        if not rows or len(rows) > 64:
            raise Refused('toy table size')
        self.keys = tuple(sorted(rows))
        self.rows = dict(rows)
        leaves = [leaf_hash(k, rows[k]) for k in self.keys]
        self.levels = [leaves]
        while len(leaves) > 1:
            leaves = [parent_hash(leaves[i], leaves[min(i + 1, len(leaves) - 1)])
                      for i in range(0, len(leaves), 2)]
            self.levels.append(leaves)
        self.root = digest(b'toy/root/v1\0', len(self.keys).to_bytes(8, 'big') + leaves[0])

    def opening(self, key: str) -> Opening:
        index = self.keys.index(key)
        pos = index
        siblings = []
        for level in self.levels[:-1]:
            sibling = pos ^ 1
            siblings.append(level[sibling] if sibling < len(level) else level[pos])
            pos //= 2
        return Opening(key, self.rows[key], index, len(self.keys), tuple(siblings))


def authenticate(root: bytes, expected_key: str, op: Opening) -> int:
    if op.key != expected_key or not 1 <= op.count <= 64 or not 0 <= op.index < op.count:
        raise Refused('wrong key or index/count')
    depth = (op.count - 1).bit_length()
    if len(op.siblings) != depth or depth > 6:
        raise Refused('wrong proof size')
    value = leaf_hash(op.key, op.value)
    pos, count = op.index, op.count
    for sibling in op.siblings:
        if len(sibling) != 32:
            raise Refused('wrong hash length')
        if pos % 2 == 0:
            if pos + 1 == count and sibling != value:
                raise Refused('noncanonical padding')
            value = parent_hash(value, sibling)
        else:
            value = parent_hash(sibling, value)
        pos //= 2
        count = (count + 1) // 2
    actual = digest(b'toy/root/v1\0', op.count.to_bytes(8, 'big') + value)
    if actual != root:
        raise Refused('opening does not match pinned root')
    return op.value


