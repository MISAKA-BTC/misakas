//!
//! # Consensus Core
//!
//! This crate implements primitives used in the Kaspa node consensus processing.
//!

extern crate alloc;
extern crate core;
extern crate self as consensus_core;

pub mod palw_mergeset_v1;
pub mod palw_native_readiness_v1;
pub mod palw_native_settlement_v1;
pub mod palw_panel_beacon_v1;
pub mod palw_permissionless_panel_v1;

use std::collections::{HashMap, HashSet};
use std::hash::{BuildHasher, Hasher};

pub use kaspa_hashes::Hash;
// PR-9.5f: companion re-export so downstream crates (rpc/grpc, wallet,
// rpc-service) that depend on consensus-core but not directly on
// kaspa-hashes can name the 64-byte type as `kaspa_consensus_core::Hash64`,
// mirroring the long-standing `kaspa_consensus_core::Hash` path.
pub use kaspa_hashes::Hash64;
// kaspa-pq Selected-Parent EVM Lane (ADR-0020): the 32-byte Ethereum-compatible
// hash used by the EVM execution lane (state/tx/receipts roots, EVM block hash).
pub use kaspa_hashes::EvmH256;

// ---------------------------------------------------------------------
// kaspa-pq Phase 9 (PR-9.5b): consensus-identity semantic aliases.
//
// The Hash → Hash64 cascade (ADR-0008 / docs/hash64-migration-inventory.md)
// stages width changes per identity. This module introduces NAMES for
// each identity, all pointing at the upstream 32-byte `Hash` /
// `kaspa_hashes::Hash32` today. PR-9.5c onward flips individual
// aliases to `kaspa_hashes::Hash64` one identity at a time:
//
//   PR-9.5c    TransactionId, TransactionHash, MerkleHash, MerkleRoot,
//              AcceptedIdMerkleRoot                       → Hash64
//   PR-9.5d    Header.pow_algo_id field (PR-8.4)          → (additive)
//   PR-9.5e    BlockHash + PruningPoint (both are block-hash
//              identities) and every user — the header, stores,
//              GHOSTDAG, reachability, pruning, relations  → Hash64
//
// kaspa-pq (ADR-0004 / design §12): UtxoCommitment is 64-byte
// (BLAKE2b-512 of the LtHash state) like every other PQ consensus
// identity. It is an accumulator commitment, not a block-hash
// identity, so it is never keyed into a BlockHashMap.
//
// `LegacyHash32` is the **stable** 32-byte name — it is the alias
// that NEVER widens. Use it in source that wants to be explicit
// about staying 32 B (RNG seeds, debug fingerprints, cache keys
// that are not on the consensus surface). The `algo_id = 1`
// kHeavyHash L1 inner-loop seed (PR-8.5 / PR-9.3 §"l1_seed32") is
// the canonical example.
//
// Adding aliases here is **purely additive**: no existing call
// site changes, no type-system pressure, no breaking semantics.
// The actual width flips happen in PR-9.5c onward when individual
// alias bodies switch from `kaspa_hashes::Hash32` to
// `kaspa_hashes::Hash64`.
// ---------------------------------------------------------------------

/// Stable 32-byte hash alias for surface that **does not** widen to
/// `Hash64` under ADR-0008. Use this for RNG seeds, debug
/// fingerprints, and cache keys that are not part of the consensus
/// identity surface. The `algo_id = 1` kHeavyHash L1 seed
/// (`l1_seed32`, PR-9.3) is the canonical caller.
pub type LegacyHash32 = kaspa_hashes::Hash32;

/// Block identity — the header hash returned by `Block::hash()` and
/// stored in `Header::hash`. **Flipped to `Hash64` in PR-9.5e**
/// (ADR-0008): the identity digest is now produced by the keyed
/// BLAKE2b-512 `BlockHash64` hasher (crypto/hashes/src/hashers.rs).
/// Keys `BlockHashMap` / `BlockHashSet` and flows through every
/// store, GHOSTDAG, reachability and pruning structure.
pub type BlockHash = kaspa_hashes::Hash64;

/// Transaction id — the `TransactionId` returned by the upstream
/// `TransactionHasher` flow (txid). **Flipped to `Hash64` in
/// PR-9.5c** per ADR-0008 §"Full Hash64 consensus identity"; the
/// underlying digest is now produced by the keyed BLAKE2b-512
/// `TransactionId64` hasher from PR-9.2 / crypto/hashes/src/hashers.rs.
pub type TransactionId = kaspa_hashes::Hash64;

/// Full-content transaction hash — distinct from [`TransactionId`]
/// (which omits witness data per upstream Kaspa convention).
/// **Flipped to `Hash64` in PR-9.5c**; underlying hasher is the
/// keyed BLAKE2b-512 `TransactionHash64`.
pub type TransactionHash = kaspa_hashes::Hash64;

/// Generic merkle-tree node hash (intermediate digest along a
/// merkle path). **Flipped to `Hash64` in PR-9.5c**; underlying
/// hasher is the keyed BLAKE2b-512 `MerkleBranchHash64`.
pub type MerkleHash = kaspa_hashes::Hash64;

/// Merkle root over a block's transaction id list
/// (`Header::hash_merkle_root`). **Flipped to `Hash64` in PR-9.5c**.
pub type MerkleRoot = kaspa_hashes::Hash64;

/// Merkle root over a block's accepted-transaction-id list
/// (`Header::accepted_id_merkle_root`). **Flipped to `Hash64` in
/// PR-9.5c**; underlying hasher is the keyed BLAKE2b-512
/// `AcceptedIdMerkleBranchHash64`.
pub type AcceptedIdMerkleRoot = kaspa_hashes::Hash64;

/// Pruning-point block hash (`Header::pruning_point`). This is a
/// **block-hash identity** (it references the pruning-point block),
/// so it **flipped to `Hash64` in PR-9.5e** together with
/// [`BlockHash`] — a 32-byte pruning point could not key the
/// Hash64 block stores.
pub type PruningPoint = kaspa_hashes::Hash64;

pub mod acceptance_data;
pub mod api;
pub mod block;
pub mod blockhash;
pub mod blockstatus;
pub mod coinbase;
pub mod config;
pub mod constants;
pub mod daa_score_timestamp;
/// ADR-0128 — DNS validators vote BFT by bonded stake, and that vote decides the stake reorg gate:
/// the quorum, the counted set and its leak, the snapshot commitment, the lock chain and the
/// precommit duty, as pure functions of what the virtual processor's walk verified.
pub mod dns_bft_v1;
/// kaspa-pq Phase 10 (PR-10.3): DNS Probabilistic Finality Overlay
/// type stubs (see docs/adr/0009-dns-probabilistic-finality.md).
/// Carries the type surface only; consensus rule implementations
/// (StakeScore aggregation, reorg gate) land in PR-10.4
/// onward once Phases 1–9 stabilise.
pub mod dns_finality;
pub mod errors;
/// kaspa-pq Selected-Parent EVM Lane (ADR-0020): EVM execution-lane consensus
/// types (block-body payload, executor-output header, EVM-domain newtypes).
/// Types only; the revm executor lives behind the `evm` cargo feature (P2).
pub mod evm;
/// ADR-0072 SA-2: the fork-id handshake — what a node has crossed, and what it will cross next.
pub mod fork_id_v1;
pub mod hashing;
pub mod header;
pub mod mass;
pub mod merkle;
pub mod mining_rules;
pub mod mldsa87_primitives;
pub mod muhash;
pub mod network;
/// ADR-0152-adjacent (user decision 2026-09-25): the Activation Pool and the listing rules it rides
/// on (R1, R2), behind `Params::palw_activation_pool`.
pub mod palw_activation_pool_v1;
pub mod palw_admission_v2;
/// MISAKA PALW adversarial suite (§12 gate / v0.1 §29 gate 4): a permanent red-team harness of
/// executable attacks against the Layer-1 machinery — reassociation, FMA smuggling,
/// transcendental substitution, manufactured mismatch, cross-class collusion, flash-attention
/// re-enable, non-finite smuggling, domain bridges, kernel-id forgery, layer-kind confusion,
/// routing-key relabeling, ready-set forgery, unchecked-credit refusal (ADR-0034).
/// Test-only — gated by the `#[cfg(test)]` below, like every other module here. The file used
/// to repeat it as `#![cfg(test)]`, which is the same statement twice.
#[cfg(test)]
pub mod palw_adversarial;
/// ADR-0160 lane liab (testnet-12, post-launch): aggregate bond liability — one shared pool per bond,
/// forfeited whole on an intent-class conviction, frozen on the first conviction, and the seat side
/// re-priced by the ramp factor. Consensus-inert while `Params::palw_capacity_aggregate_liability` is
/// `None` (every shipped preset).
pub mod palw_aggregate_liability_v1;
/// ADR-0146: the committed search that reports the worst reward-per-MAC the derivation
/// permits. No coefficient table, no fence — `cargo test palw_arbitrage_search` is the program.
pub mod palw_arbitrage_search_v1;
pub mod palw_artifact;
pub mod palw_attempt_rules_v1;
pub mod palw_attempt_v2;
/// ADR-0082 Decision 2 / U-03: the dissection as a court phase, and its window gate.
pub mod palw_attn_court_v1;
/// ADR-0082 Decisions 2–3: the history dissection's objects, fold and round arithmetic.
pub mod palw_attn_dissect;
pub mod palw_attn_responder_v1;
pub mod palw_backend;
pub mod palw_base0;
pub mod palw_base0_a16;
pub mod palw_base0_ops;
pub mod palw_base0_profile;
/// ADR-0160 stage 2 lane Q: the audit door (F-Q, `Params::palw_capacity_audit_door`) — a credited
/// claim reaches `Final` only with `k_aud` operator receipts from outside its panel.
pub mod palw_audit_door_v1;
/// ADR-0160 lane verify V1: the batch licence (F-B, `Params::palw_capacity_batch_licence`) — one
/// signature per seat window, a Merkle path per claim, the coverage funnel unchanged.
pub mod palw_batch_licence_v1;
/// MISAKA PALW bisection ladder (ADR-0027 §1's degraded path): the pure state machine that
/// forces incremental disclosure when a miner withholds state — pinned midpoints, monotonic
/// rung deadlines, attributable no-show offenses, log-bounded convergence to the terminal
/// one-step check. Land-stage, consensus-inert.
pub mod palw_bisect;
/// MISAKA PALW ADR-0038 land-stage modules: block-work identity/signature binding, DAG-native
/// verification receipts, the receipt-licensed weight ramp, per-class difficulty domains,
/// the coinbase-carried block commitment, the budgeted credit batch, and the Track-D catalog
/// coverage gate. All consensus-inert — nothing in validation, fork choice or the header
/// pipeline consumes any of it until the ADR-0038 change set wires and activates together.
pub mod palw_block_commitment;
/// **ADR-0145 §1–§5: a claim's work is DERIVED from the graph and the execution, never declared.**
/// The 2026-09-19 reward audit measured 7.8× the fork-choice weight for identical arithmetic
/// because `pwu_per_inference` counts a canonical job the registrant writes while an attempt past
/// `Params::palw_prefill_draw` runs a different one. Behind `Params::palw_canonical_work`, `None`
/// on every preset.
pub mod palw_canonical_work_v1;
/// ADR-0160 — the reference formulas of claim-capacity separation (staged weight and the per-bond
/// cap, `m_c`, the seat repricing, the §5 targets). Pure; called by no consensus rule until a
/// capacity lane's fence arms (`palw_capacity_shadow_is_node_only` enforces it).
pub mod palw_capacity_formulas_v1;
pub mod palw_seat_availability_v1;
/// ADR-0160 §6.3 / §7.5 — shadow accounting: what the capacity formulas would reserve, weigh and
/// allow for every live claim and bond, next to today's values. Node-only (`getPalwCapacityShadow`,
/// kaspad's interval log); no consensus rule reads it.
pub mod palw_capacity_shadow_v1;
pub mod palw_class_identity_v1;
/// MISAKA PALW chain carriage v1 (ADR-0029): the Stage-0 magic envelope, the five payload
/// bodies, their caps, and the stateless validators that become the Stage-1 admission
/// validators verbatim. Land-stage, consensus-inert — the Stage-0 consumer is an external
/// watcher; no transaction validation or store reads any of it.
pub mod palw_carriage;
pub mod palw_catalog_coverage;
pub mod palw_chain_weight;
/// ADR-0103 Decision 1 — a checkpoint's chunk is tried against the cache-write rows it claims to
/// hold, in one move. A consensus object behind `Params::palw_held_context`, `None` everywhere.
pub mod palw_checkpoint_court_v1;
pub mod palw_class_admission_v2;
pub mod palw_class_daa;
/// ADR-0152 §4-quater — class-derived verification deadlines behind
/// `Params::palw_class_verify_deadline`: the constants, the measured-row type and the two pure
/// derivations of `D(c)` (the state-reading half is in `palw_state_v2`). `None` on every preset but
/// testnet-12.
pub mod palw_class_verify_deadline_v1;
pub mod palw_clock_cursor_v1;
pub mod palw_context_ladder;
/// ADR-0077 SA-4: the court's turn deadline is a slashing rule, so it is DERIVED from what an
/// honest responder needs — one interval of replay plus `2 x NETWORK_DELAY_BOUND` — and every
/// shipped class row of every preset that carries a V2 bundle is asserted against it. Changes no
/// shipped constant; it relates two numbers that had never appeared in one expression.
pub mod palw_court_deadline;
pub mod palw_court_v2;
/// Reserved encoding of the retired V1 credit parameters; no executable credit gate.
pub mod palw_credit;
pub mod palw_credit_batch;
pub mod palw_decode_constraint_v1;
pub mod palw_decode_pipeline_v4;
pub mod palw_embedding_pool_v1;
pub mod palw_decode_select_v2;
pub mod palw_derived_v1;
pub mod palw_dispute;
/// ADR-0069: end-to-end adjudicability — the half of "can this class be prosecuted" that coverage
/// does not answer. Static adjudicability says the adjudicator can re-execute every kernel the
/// graph reaches; this says a real backend can actually PLAY the dispute, proven by re-running the
/// shipped court over a drill's planted faults. Weight requires both.
pub mod palw_e2e_adjudicability;
/// **The economic locus census** (ADR-0080 Decision 3, narrowed): which quantities on the
/// free-prompt path are priced in LEAVES and survive restructuring, and which are priced per
/// claim or per block and do not. A doc comment with a test suite attached; no rule, no state,
/// no caller. Read it before proposing that one answer become several claims.
pub mod palw_economic_compute_v1;
pub mod palw_economic_safety_v1;
pub mod palw_economic_locus_v1;
pub mod palw_economic_payout_v1;
pub mod palw_economics_ledger_v1;
/// ADR-0160 lane escrow (testnet-12, post-launch): past `Params::palw_capacity_escrow_at_licence` the
/// bond holds `m_c` in a claim's escrow slot instead of `E`, and an unconvicted void keeps the claim's
/// commitment for `h_obl`. Consensus-inert while the fence is `None` (every shipped preset).
pub mod palw_escrow_funding_v2;
/// Node-only reads of the execution lane for explorers (lane SCAN): the round-block ledger and the
/// executions the sink state holds. No consensus rule.
pub mod palw_exec_view_v1;
/// ADR-0125 — the execution lane's round rules (a second, a seed, capped quotas, alternating
/// permits) as pure functions; consensus-inert until the lane that reads them is built.
pub mod palw_execution_lane_v1;
/// RFC-0008 v2: the unified EXEC lane's wire layer — one versioned envelope, two exclusive subtypes (`EXEC_TX`, `EXEC_SLICE`); dormant behind `palw_exec_payload_v2`.
pub mod palw_exec_v2;
/// RFC-0008 v2: the weightless carriage — the anchor trailer, the closure of lane heads, the covered-set root; dormant behind `palw_exec_payload_v2`.
pub mod palw_exec_v2_anchor;
/// RFC-0008 v2 amendment 1: the slice verification route — a slice is verified, convicted or defaulted through the G14 kernel route.
pub mod palw_exec_v2_verify;
/// RFC-0008 v2: the work-slice ledgers (`WorkSliceUse`, `RootWorkBudget`, `JobWorkUse`), the canonical plan, the admission refusals and the root's one settlement; dormant behind `palw_exec_payload_v2`.
pub mod palw_work_slice_v2;
/// Spend-once execution-round quanta: 1 verified CanonicalWork → N unique permit tickets.
pub mod palw_execution_quanta_v1;
pub mod palw_exposure;
pub mod palw_facts;
/// ADR-0152 v3.1 N10 / §7.3 P2-8c: the node's half of `PanelFalseValidV2` (node policy, never validity).
pub mod palw_false_valid_filing_v1;
pub mod palw_fork_authority_v2;
pub mod palw_fork_choice;
pub mod palw_fp_admission_v3;
pub mod palw_fp_beacon_v3;
pub mod palw_fp_devnet_v3;
pub mod palw_fp_execution_v3;
pub mod palw_fp_interval_v1;
pub mod palw_fp_objects_v3;
pub mod palw_fp_v4_vectors;
pub mod palw_freeprompt_v3;
pub mod palw_genesis_v2;
pub mod palw_heartbeat_v1;
/// ADR-0152 v3.1 H-1 — the lifecycle objects a heartbeat must be able to carry: the one list the
/// miner's carrier lane and the relay's exemption read (P2-9). Node policy; no rule reads it.
pub mod palw_heartbeat_carriers_v1;
/// The 2026-09-25 model-registry review, M1 — a possession proof whose row is about to lapse outranks
/// the court queue at the seat and holds a carrier's place in the pool and the template. Node
/// policy past R-core+; no rule reads it.
pub mod palw_readiness_escalation_v1;
/// ADR-0103 — the context is held off the chain: the seat's interval of positions, its route, its
/// width and its fetch, as pure functions. Consensus-inert.
pub mod palw_held_context_v1;
/// ADR-0103 Decision 4 — a data-availability accusation names a prompt tile, a state chunk or a
/// step range, and is answered by that unit and its path. Behind `Params::palw_held_context`.
pub mod palw_held_da_v1;
/// ADR-0152 v3.1 §3.11 (DA-1…DA-9, M3) — the data-availability court past `Params::palw_rcore_plus`:
/// sessions in side maps, drawn units, any locked signer answers, seat-only pause credit.
pub mod palw_da_rcore_v1;
/// Lane B of the panel-seed stopgap (2026-09-26): what an operator's non-seat data-availability
/// filer reads of the tip — node policy's read, never a rule.
pub mod palw_operator_da_v1;
pub mod palw_job_identity;
pub mod palw_job_ledger;
pub mod palw_job_panel;
/// MISAKA PALW asynchronous job state machine (ADR-0037 Decision 2): the closed, monotone
/// per-job status algebra and the `PalwJobStateV3` object that replaces the per-block
/// challenge-horizon walk on value networks. Encodes I8 (refutation locks, never destroys),
/// I9 (only exact conviction or objective no-show destroys), I10 (`Unadjudicable` slashes
/// no one, credits nothing, freezes the class). Consensus-inert — nothing constructs it on
/// any shipped network; the Track-C change set is its first consumer.
pub mod palw_job_state;
/// Kimi K3 native geometry, integer ops, tokenizer and artifact identity. Not a genesis class.
/// Its kernels sit in the fenced catalog so `court_catalog_root` does not move.
pub mod palw_kimi_k3_artifact_v1;
pub mod palw_kimi_k3_foundation_v1;
pub mod palw_kimi_k3_ops;
pub mod palw_kimi_k3_profile;
pub mod palw_kimi_k3_tokenizer_v1;
/// ADR-0133 S3: post-execution random layer/position sampling, behind `Params::palw_verification_s3`.
pub mod palw_layer_sample_v3;
/// ADR-0111 — a seat may demand the committed leaf it needs to judge: the seat's assigned
/// intervals and the interval that owns a leaf, as pure functions of the binding — the bound a
/// held DA demand for a leaf's evidence is admitted under.
pub mod palw_leaf_evidence_v1;
pub mod palw_weight_block_v1;
/// MISAKA PALW execution-commitment legs v1 (ADR-0027 consequences): the activation and
/// checkpoint commitments. Land-stage, consensus-inert.
pub mod palw_legs;
pub mod palw_lifecycle_objects_v2;
/// ADR-0099 Decision 1 — a model is a manifest, and the Measured Model Artifact is what the
/// network makes of it: the deterministic half any node recomputes and refuses by the field, the
/// self-reported half carried and labelled. Consensus-inert.
pub mod palw_measured_model_v1;
pub mod palw_mode_v2;
pub mod palw_model_benefits_v1;
/// ADR-0097 — a model's fit is a lookup: every wall a class meets on a ruleset, named with its
/// number, from the predicates admission and the court already run. Consensus-inert (a report).
pub mod palw_model_fit_v1;
pub mod palw_model_lines_v1;
pub mod palw_model_market_v1;
pub mod palw_model_registry_v1;
/// Model-add tracking: machine-readable refusal codes and the constructed→folded pipeline.
pub mod palw_model_registration_v1;
/// ADR-0152 v2 F2: one adjudicator for a false `Valid`, bound to the claim's committed root —
/// called by the processor and the fold alike. Consensus-inert until
/// `Params::palw_offence_attribution` is Some.
pub mod palw_offence_attribution_v1;
/// ADR-0144 §9: objective-offence identity, PanelFalseValid payloads, and the processor's
/// cryptographic gate. Consensus-inert until `Params::palw_objective_offence` is Some.
pub mod palw_offence_v1;
/// Lane A (testnet-12, post-launch stopgap, 2026-09-26): past `Params::palw_operator_anchor` only an
/// attempt produced by an operator (genesis) bond may anchor a claim's panel. Consensus-inert while the
/// fence is `None` (every shipped preset).
pub mod palw_operator_anchor_v1;
/// ADR-0133 S2: optimistic licence from the full-replay seat, behind `Params::palw_verification_s2`.
pub mod palw_optimistic_licence_v2;
/// ADR-0077 Decision 16 (P-16): `PanelDa`, the privacy mode whose prompt stays off chain — and
/// ADR-0077 SA-5, which says what arming it does NOT buy.
pub mod palw_panel_da_v1;
/// ADR-0124 — the panel is paid out of the claim's own reward, a seat holds exposure while it
/// judges, and a claim is paid for the compute it certifies: the three pure rules, and nothing
/// that reads a fence.
pub mod palw_panel_economy_v1;
pub mod palw_panel_v2;
/// Operator/RPC view of panel seats, class readiness, and per-claim assignments.
/// Seat counts stay distinct (`bonded` / `ready` / `selected` / `validReceipt`); a hold has a reason code.
pub mod palw_panel_view_v1;
/// ADR-0144 §9: slashable panel VAR that cannot be counted twice. Pure functions of consensus
/// facts; the fold in `palw_state_v2` is the writer, behind the same fence.
pub mod palw_panel_var_v1;
pub mod palw_producer_v2;
/// ADR-0081 Decision 3 — the one decision of ADR-0081 that survives its refutation: the
/// prompt's token ids as a tiled Merkle root, so a gather proves ONE id instead of carrying
/// all of them. Dormant (`Params::palw_prompt_ids_merkle` is `None` on every preset).
pub mod palw_prompt_ids_v1;
pub mod palw_pwu;
pub mod palw_qwen25_profile;
pub mod palw_qwen36_ops;
pub mod palw_qwen36_profile;
pub mod palw_refusal_v1;
pub mod palw_rc_identity_v2;
pub mod palw_receipt;
/// MISAKA PALW canonical reference arithmetic v1 (ADR-0027 §2): integer soft-float
/// adjudication maths. Land-stage, consensus-inert.
pub mod palw_reference;
pub mod palw_registry;
/// ADR-0152 v3.1 Phase 2, P2-8b / P2-8d: the replay-mismatch contradiction builder — a seat's own
/// replay against the claim's served capture, bisected to the first divergent step and held to the
/// fold's own predicates. Node policy's read-side builder; nothing here is read by the fold.
pub mod palw_replay_refute_v1;
/// ADR-0151 follow-up, item 1: what a ROLE needs to execute a class — the one working-set
/// derivation the producer, the panel and the court read; node-local capacity, never a chain fact.
pub mod palw_resource_profile_v1;
/// ADR-0145 §8: the reward properties, each stated as something an attacker cannot do, plus the
/// 2026-09-19 audit's five counterexamples as in-tree fixtures. Test-only — gated by the
/// `#[cfg(test)]` below, like `palw_adversarial`.
#[cfg(test)]
pub mod palw_reward_properties_v1;
pub mod palw_reward_v2;
/// MISAKA PALW re-verification routing (ADR-0034): the four execution-class families, five
/// model bands, and the binding-aware eligibility/coverage machinery. Consensus-inert —
/// computed and logged only; no verdict, credit or acceptance path reads any of it, and the
/// module exposes no crediting API at all (`FINALIZED_WITHOUT_REPLAY` is untypable).
pub mod palw_routing;
pub mod palw_rule_manifest_v1;
/// MISAKA PALW challenge scheduling (ADR-0028): assignment tickets, DAA windows and the
/// Stage-0 shadow ledger that measures `P_check`, no-show and replay cost. Land-stage,
/// consensus-inert — computed and logged only; nothing consumes it.
pub mod palw_schedule;
/// ADR-0098 — the panel's coverage of one claim, measured with the draw the seats run
/// (ADR-0077 Decision 8): the number ADR-0081 Decision 8 asked for and never took. A report.
pub mod palw_seat_coverage_v1;
/// ADR-0133 S1 runtime: map a V2 segment onto the decode-call window a checkpoint resume covers.
pub mod palw_segment_resume_v1;
/// ADR-0101 — a membership is proven by the chain and served by anyone: the signed service
/// descriptor and the check a client runs against chain facts. Consensus-inert.
pub mod palw_service_descriptor_v1;
/// ADR-0127 Decision 3 — the settlement read: whether the transactions accepted at a DAA score are
/// settled, and their settlement depth in `Final` anchors, from the sink's PALW state alone. Also
/// home to Decision 7's guard over the settlement path's sources. A read; no rule.
pub mod palw_settlement_v1;
/// ADR-0099 Decision 5, built by ADR-0100 — the one-move court: the accusation a shard seat files
/// at a named leaf, its session id, its verdict. A consensus object behind
/// `Params::palw_shard_court`, `None` on every shipped preset.
pub mod palw_shard_court_v1;
/// ADR-0100 Decision 4 — licensing per shard: the part, the per-shard quorum and the progress, as
/// pure functions. Consensus-inert; the fold is the ADR's stated next step.
pub mod palw_shard_licensing_v1;
/// ADR-0099 Decision 3 — a shard is a capability a bond declares, and the panel is drawn per
/// shard. Consensus-inert.
pub mod palw_shard_panel_v1;
/// ADR-0099 Decision 2 — a seat holds a shard, not the model: the plan (contiguous layer ranges,
/// derived), what a shard costs a seat, and the two transfer forms. Consensus-inert.
pub mod palw_shard_plan_v1;
/// MISAKA PALW-S slash objects (ADR-0027): unilateral, objectively-checkable evidence.
/// Land-stage, consensus-inert — no slashing is enabled by this module existing.
pub mod palw_slash;
/// MISAKA PALW checkpoint state chunk map (ADR-0030 §3): the DERIVED byte layout of the
/// deterministic-integer family's replay state, and the `state_chunk_map_id` that names it.
/// Land-stage: a map, not a capture — nothing here reads an engine or writes a checkpoint.
pub mod palw_state_chunk_map;
pub mod palw_state_v2;
/// MISAKA PALW step function v1 (ADR-0030): the frozen operator taxonomy, the shape-profile
/// v3 schema and identity, and the step-index bijection a one-step refutation names steps
/// with. Land-stage, consensus-inert — every profile VALUE is registration-measured; only
/// the schema and the enumeration are pinned here.
pub mod palw_step;
/// MISAKA PALW execution-commitment v2 (ADR-0030 §3): the step leg, KV aux chunks, and the
/// chunked checkpoint leg — a NEW scheme family; v1 and its goldens do not move. Land-stage,
/// consensus-inert.
pub mod palw_step_leg;
/// MISAKA PALW `ExecutionStepRefutationV1` (ADR-0027 §1 / ADR-0030 §4): the arithmetic
/// one-step conviction — canonical-input derivation, the kernel-program catalog, and the
/// three-way verdict (convicted / NoFaultFound / unadjudicable). Land-stage, consensus-inert.
pub mod palw_step_refute;
/// RFC-0002 Phase F: PALW-TIR v1 on chain — the dormant `palw_tir_v1` fence and the network's IR constants.
pub mod palw_tir_v1;
/// RFC-0003: generative model classes on chain — the dormant `palw_gen_v1` fence and the network's generative constants.
pub mod palw_gen_v1;
/// RFC-0003: a generative class — a pipeline of PALW-TIR version-2 programs — its identity, its registration carriage and its preflight.
pub mod palw_gen_class_v1;
/// RFC-0003 §I.0: the generative job `PalwGenJobV1` (an image, an embedding) — its identity and its acceptance by name.
pub mod palw_gen_job_v1;
/// RFC-0003: the generative court's own questions — R's inputs recomputed from the job, PALW-TIR-33 on edges, the output digest (fault 21).
pub mod palw_gen_court_v1;
/// RFC-0003 §I.2.3: the one step tree of a pipeline claim — every stage's leaves, stage-major.
pub mod palw_gen_step_v1;
/// RFC-0003: the pipeline inventory — the artifact layout a generative class's `artifact_root` commits to, and the court's authenticated params.
pub mod palw_gen_artifact_v1;
/// RFC-0003: the generative court's consensus objects — a pipeline claim's binding and its two closes.
pub mod palw_gen_close_price_v1;
pub mod palw_gen_close_v1;
/// RFC-0003 activation step 4: the pipeline admission — the gate a generative class registration passes, its builder and the node's preflight.
pub mod palw_gen_admission_v1;
/// RFC-0003 §II.2.1: the worker and the panel of a pipeline class — a V5 job run into the step tree, and a seat's replay.
pub mod palw_gen_worker_v1;
/// RFC-0003 §II.2.1 (RFC-0001's lane): FP Job V5 — a V4 job with image inputs, for a vision-language class; dormant behind `palw_fp_job_v5`.
pub mod palw_fp_job_v5;
pub mod palw_gen_range_twin_v1;
/// RFC-0011 §15.7: the kernel route's fence `palw_probabilistic_constraints_v1` — dormant, no height, refused when armed.
pub mod palw_probabilistic_constraints_v1;
/// RFC-0004 Part II: the typed-roots fence `palw_typed_roots_v1` — dormant, no height, refused when armed.
pub mod palw_typed_roots_v1;
/// ECON's M*-49 verifier pay and the held default share: the fence `palw_verifier_pay_v1` — dormant, no height, refused when armed.
pub mod palw_verifier_pay_v1;
/// G14 lane D: the kernel route's consensus state, messages and interim policy (fence `palw_probabilistic_constraints_v1`).
pub mod palw_kernel_route_v1;
/// G14 lane D phase 3: the onboarding objects (artifact binding and its refutation, the kernel binding, the conformance commitment,
/// the signed registration envelope) and the activation gate they feed — rows in the kernel route's aux tables.
pub mod palw_onboarding_v1;
mod palw_onboarding_tile_v3;
/// G14 onboarding P0: conformance evidence on chain (tag 109) — the evidence core shared with the runtime pack, the network's
/// interim challenge policy, the fold's judgement of posted evidence and of a refutation, and the fresh verifier.
pub mod palw_conformance_evidence_v1;
/// RFC-0015: the Panel=0 (`OptimisticPublicVerification`) fence `palw_panel_free_v1` — dormant, no height, refused when armed.
pub mod palw_panel_free_v1;
/// The OPV ↔ PALW Work Beacon startup cycle, closed: the complete-check bootstrap, derived OPV eligibility, the effective bits of a
/// passed attempt, and the dependency graph (`docs/design/palw/opv-beacon-bootstrap.md`) — dormant with the kernel route's fences.
pub mod palw_opv_bootstrap_v1;
/// RFC-0001 §2.6 stage 2: FP job version 11 — the prefix-state receipt; dormant behind `palw_fp_prefix_state`.
pub mod palw_fp_prefix_v1;
/// RFC-0001 §2.9: the job's tokenizer must be the class's listed one; dormant behind `palw_fp_tokenizer_match`.
pub mod palw_fp_tokenizer_v1;
/// RFC-0001 §2.5: the decode constraint's second subset and automaton bounds; dormant behind `palw_fp_constraint_v2`.
pub mod palw_fp_constraint_v2;
/// RFC-0001 §2.10 (ADR-0163): the adapter class listing; dormant behind `palw_adapter_class_v1`.
pub mod palw_adapter_class_v1;
pub mod palw_fp_constraint_job_v1;
/// RFC-0002 Phase F: the second IR fence (`palw_tir_fence2`) — H7's box-demand row, the `Select`-arm work credit and the IR DA units `TirStepLeaf` and `TirStepNode`.
pub mod palw_tir_fence2_v1;
/// ADR-0165, the Useful Work Transition: the base floor as a reserve (`palw_floor_reserve_v1`) and the attempt lane as a clock tick source (`palw_real_clock_tick_v1`).
pub mod palw_real_share_v1;
/// ADR-0170, the seed anchor as a window: a merged admitted attempt anchors, the anchor survives span boundaries, and the admission jury and the schedule seeding read the latest anchor of `S − 24 … S − 1` (`palw_anchor_window_v1`).
pub mod palw_anchor_window_v1;
/// RFC-0009 stage C: public receipt redemption (`palw_receipt_spend_v4`, DORMANT): the V4 spend envelope, its admission and the reward split.
pub mod palw_receipt_v4;
/// RFC-0009 stage B: the canonical evidence manifest and the checks a claim's material is held to.
pub mod palw_evidence_v1;
/// RFC-0009 stage B: the provider challenge court (`palw_evidence_court_v1`, DORMANT, not yet folded into the chain state).
pub mod palw_evidence_court_v1;
/// Lane DA16 (RFC-0014 §16, RFC-0009 §4): public material units — what an artifact leaf, a bound kernel row or a claim position is checked
/// against (always the chain's root), the artifact manifest, and a binding confirmed or refuted from the bytes. Since ADR-0177 the
/// ARTIFACT half is NON-CONSENSUS (optional off-chain tooling; no fold arm reads it); only `ClaimPosition` is a court unit.
pub mod palw_public_material_v1;
/// Lane DA16 (RFC-0009 §4.2): the provider court on the kernel route — leases, unit challenges, answers, the DA transfer, its rows and its
/// fence `palw_provider_court_v1` (dormant, refused when armed).
pub mod palw_provider_court_v1;
/// Lane BUDGET (ADR-0176 / ADR-0177): the bond budget (Q/B/R/F reserved at acceptance, consumed by every reward writer, released only at
/// `accepted_daa + W`) and the model-bond allocation — fences `palw_bond_budget_v1` and `palw_model_bond_allocation_v1` (dormant, refused
/// when armed).
pub mod palw_bond_budget_v1;
/// Lane DA16: the court scope (ADR-0177 D2, RFC-0014 §16.4) — what a court may demand (claim-specific units only), what a verifier
/// supplies from its own copy against the registered root, the node-level model-bytes masks and the cumulative bound.
pub mod palw_court_scope_v1;
/// **Lane LG14-B (RFC-0014 §4–§5): the legacy V2 route's public descent and held/fused DA units** — tags 157–159 behind the dormant
/// fence `palw_legacy_held_da_v2` (refused when armed).
pub mod palw_legacy_held_da_v2;
/// Lane INTF (ADR-0032's 2026-10-10 amendment): the PALW reporter share, 10% below and 49% at or past the dormant fence
/// `palw_reporter_share_v2` (refused when armed) — R-1 fixed at the conviction's close, DA-6 at the session's open.
pub mod palw_reporter_share_v2;
/// Lane LG14-A (RFC-0014 §6–§8 on the legacy V2 Panel route): the non-seat dispute reservation (tags 154–155) that holds a claim's ends
/// to the claim's own hard deadline, the reserved DA budget, direct proofs over open sessions, and the common filer's pure half — fence
/// `palw_legacy_public_filer_v1` (dormant, refused when armed).
pub mod palw_legacy_public_filer_v1;
/// RFC-0009 stage D: a light client's proof of one bond/class/claim against a pinned block's committed state root.
pub mod palw_state_proof_v1;
/// Lane PA: the 2026-10-04 audit's consensus fixes behind one dormant fence (`palw_audit_1004_v1`).
pub mod palw_audit_1004_v1;
/// Lane MU (ADR-0173): the dormant Validation + Activation skeleton (no state, no object, no fence read).
pub mod palw_root_activation_v1;
/// RFC-0004: the Model Improvement Protocol — the dormant `palw_improvement_v1` fence and its constants.
pub mod palw_improve_v1;
/// RFC-0004: the protocol's state-side types (policy, lines, epochs, candidates, evaluation, promotion, rewards).
pub mod palw_improve_state_v1;
/// RFC-0004 §7.2 (A6): the evaluation job family — the job, its derived context, its binding, its table and the outcomes a missing evaluation takes.
pub mod palw_improve_eval_v1;
pub mod palw_improve_node_v1;
/// RFC-0004 §7.2 (A6): the evaluation court — the binding the chain holds to the claim, and the closes proofs 13–15 carry (spec 17 §17.8.6).
pub mod palw_improve_eval_court_v1;
/// RFC-0004 §6.3: a candidate's artifact reference and the composite artifact root (the candidates lane's).
pub mod palw_improve_artifact_v1;
/// RFC-0004 §6: the candidate's wire payload (the candidates lane's).
pub mod palw_improve_candidate_v1;
/// RFC-0004 §5, §9, §10: the material's wire payloads (the candidates lane's).
pub mod palw_improve_material_v1;
/// **RFC-0004 §3 / spec 17 §17.4: the policy check, the owner's policy message and an example policy.**
pub mod palw_improve_policy_v1;
/// **RFC-0004 §7.5 / spec 17 §17.9: promotion — the pinned sign table, the counts and the decision.**
pub mod palw_improve_promotion_v1;
/// **RFC-0004 §4 / spec 17 §17.5–§17.8: the epoch's pure functions — times, the material tree, the seed, the draw.**
pub mod palw_improve_epoch_v1;
/// **RFC-0004 §8.5 / spec 17 §17.11.1: the improvement sink a sponsor's deposit pays into, and its binding.**
pub mod palw_improve_pool_v1;
/// RFC-0003 §I.4: the tensor claim on the free-prompt lane — FP job version 10; dormant behind `palw_fp_job_v5` over `palw_gen_v1`.
pub mod palw_gen_claim_v1;
/// RFC-0003 §I.4.7: a pipeline claim accused in one move (the generative twin of `palw_tir_one_move_v1`) — dormant behind `palw_gen_v1`.
pub mod palw_gen_one_move_v1;
/// RFC-0003 §I.4.7, decision 22: the held leaf challenge — a named-leaf challenge with the declaration of its close, so a lie at a leaf whose close exceeds one carrier is convictable under the held regime; dormant behind `palw_held_close_chunks_v1`.
pub mod palw_held_close_v1;
/// RFC-0007 Part I and Part III (spec 18): verification vertices, licence by tally, equivocation, `Held` leaves and the security parameters — dormant behind `palw_verification_vertex_v1`.
pub mod palw_vertex_v1;
/// RFC-0007 Part II (consensus half), Part IV.1 and Part IV.2 (spec 18): the witness manifest, the global audit mesh with its traps, and staged (capped) onboarding — each dormant behind its own fence.
pub mod palw_mesh_v1;
/// RFC-0002 Part II §II.7.5 Proposal A: the class-seating fence (`palw_class_seating`) — its terms, value, entry and refusals; dormant.
pub mod palw_class_seating_fence_v1;
/// RFC-0002 Phase H (mainnet): `palw_tir_only_v1` — the IR is the admission path for new classes; implemented, dormant, armed nowhere.
pub mod palw_tir_only_v1;
/// RFC-0002 Phase F (F3): the TIR inventory — the artifact layout an IR class's `artifact_root` commits to.
pub mod palw_tir_artifact_v1;
pub mod palw_model_artifact_v2;
pub mod palw_model_conformance_v2;
pub mod palw_model_vector_v2;
pub mod palw_flat_model_vector_v3;
pub mod palw_flat_model_seal_v6;
pub mod palw_flat_model_vector_v7;
pub mod palw_flat_model_vector_da_v7;
pub mod palw_flat_model_vector_da_v3;
pub mod palw_model_vector_da_v2;
/// RFC-0002 Phase F step F6: admission v10 — the gate an IR class registration passes, its builder and the node's preflight.
pub mod palw_tir_admission_v1;
/// RFC-0002 Phase F step F6: an IR class's attempt job — the canonical job, the yardstick context and the job an anchor names (J5).
pub mod palw_tir_attempt_v1;
/// RFC-0002 Phase F step F6: the IR family certifier — drill evidence graded by the shipped IR court into a family over the program's primitives.
pub mod palw_tir_certify_v1;
/// RFC-0002 Phase F step F2: an IR class — the program, its commitment layout, its identity and its registration carriage.
pub mod palw_tir_class_v1;
/// RFC-0002 Phase F step F5: the IR court — one committed leaf adjudicated by demand evaluation of its cone, PALW-TIR-33, logits consistency and the decode-token door.
pub mod palw_tir_court_v1;
/// RFC-0002 Phase F step F6: the IR one-move court — an IR claim accused at a named leaf and decided in one move.
pub mod palw_tir_one_move_v1;
/// RFC-0002 Phase F step F7: the generic history dissection of an IR class — every reduction over H of the disputed cone, folded exactly.
pub mod palw_tir_dissect_v1;
/// RFC-0002 Phase F step F7 (PALW-TIR-38): the carried size of every terminal close of an IR class — the court's own read set, priced as carried.
pub mod palw_tir_close_size_v1;
/// RFC-0002 Phase F (PALW-TIR-38, `palw_tir_fence2`): the range twin of the close sizing — the element twin's read sets over ranges.
pub mod palw_tir_close_range_v1;
/// RFC-0004 §6.3 (PALW-MIP-15): composite artifacts — a candidate as its parent plus an adapter section, the parent never re-committed; sub-root openings, the composite and family rules, admission.
pub mod palw_improve_composite_v1;
/// RFC-0003 / RFC-0004 (Phase F, spec 17 §17.14): pipeline-claim data availability — the DA units, answers and demand for a
/// pipeline claim's stage trees, by hash arithmetic over the claim's committed roots; dormant behind `palw_improvement_v1`.
pub mod palw_pipeline_da_v1;
/// RFC-0002 Phase F step F4: the step space of an IR class — commit-point tiles, Fixed-state checkpoints and history tiles as step leaves, in closed form.
pub mod palw_tir_step_v1;
/// RFC-0002 Phase F step F8: an IR class's canonical work vector, classified and priced by structure alone.
pub mod palw_tir_work_v1;
/// RFC-0006: layer-sharded panels for IR classes — the plan, the partition, the cells, the V4 receipt, the recount, the fence.
pub mod palw_tir_shard_v1;
/// RFC-0006 per-segment pricing (agent SHARD): the dormant fence `palw_tir_shard_segment_v2` and the resident table, the price share
/// `max(work, resident)` and the seat need it puts in force.
pub mod palw_tir_shard_segment_v2;
/// RFC-0006 × G14 (agent SHARD): the non-seat cell watcher's targets — every shard of a live claim drawn per shard that a bond does
/// not seat, as a watch duty (pure over the tip state; node policy).
pub mod palw_tir_shard_watch_v1;
pub mod palw_terminal;
/// MISAKA PALW canonical transcendentals (ADR-0031): transcriptions of the SPECIFIC exp/log
/// algorithms the pinned classes run (ggml's vector polynomial; glibc 2.39's expf/logf in
/// both contraction variants), written in ruleset-v2 arithmetic. Land-stage, consensus-inert;
/// exact-bits validation against the class binaries is the registration gate.
pub mod palw_transcendental;
/// MISAKA PALW full-logits trace scheme v2 (docs/palw-full-logits-trace-v2-design.md):
/// Land-stage types, domains and preimage layouts only. Consensus-inert by design —
/// nothing in validation, fork choice or the header pipeline may consume it until the
/// staged activations pass their gates. `palw_execution_algo_id = 2` in here is a
/// PALW-internal namespace, NOT the header-level `pow_algo_id = 2` (historical Argon2id).
pub mod palw_v2;
pub mod palw_verification_profile_v1;
pub mod palw_verification_v2;
/// ADR-0160 stage 2 lane S: the issuance slots (F-S, `Params::palw_capacity_issuance_slots`) —
/// outstanding, burst and rate caps at the step's ρ; queue bounds, never the safety.
pub mod palw_issuance_slots_v1;
pub mod palw_network_room_v1;
pub mod palw_capacity_s567_v1;
/// ADR-0160 lane verify V2: room v2 (F-R, `Params::palw_capacity_verify_room`) — the measured `k = 2`
/// capacity, the stake-proportional bond share, the floor's seat-capital room.
pub mod palw_verify_capacity_v1;
/// ADR-0152 V-1…V-8, read side: `getPalwVesting` (op 199) and claim row v3 (phase2-plan P2-10).
pub mod palw_vesting_read_v1;
pub mod palw_vesting_v1;
pub mod palw_weight;
/// ADR-0160 F-W (lane cap-weight): staged claim weight and the per-bond weight cap (J-1).
pub mod palw_weight_cap_v1;
pub mod palw_work_target_v1;
/// kaspa-pq Phase 8 (PR-8.3): Layer 0 PoW finalizer + difficulty-lift
/// helpers (see docs/adr/0007-layered-pow.md). Self-contained; the
/// PoW-validation wiring step is PR-8.6.
pub mod pow_layer0;
pub mod pruning;
pub mod sign;
pub mod sortable_block;
pub mod subnets;
pub mod token;
/// Parents-first ordering for the node's sync paths (the round lane makes blue work non-strict).
pub mod topological_order;
pub mod trusted;
pub mod tx;
pub mod utxo;
pub mod vlt;

/// Integer type for accumulated PoW of blue blocks.
///
/// kaspa-pq Phase 8 (PR-8.5) widened this from `Uint192` to `Uint576`
/// per ADR-0007 §"Width chain": the 576-bit width is one machine word
/// above the 512-bit PoW comparison domain (`Uint512`), so a 2^64
/// window of maximum-work blocks accumulates without overflow. The
/// previous upstream comment ("no more than 2^192 work overall") is
/// retained as historical context but no longer drives the type
/// choice — the Layer 0 PoW domain does.
pub type BlueWorkType = kaspa_math::Uint576;

/// The extends directly from the expectation above about having no more than
/// 2^128 work in a single block
pub const MAX_WORK_LEVEL: BlockLevel = 128;

/// The type used to represent the GHOSTDAG K parameter
pub type KType = u16;

/// Map from Block hash to K type
pub type HashKTypeMap = std::sync::Arc<BlockHashMap<KType>>;

/// This HashMap skips the hashing of the key and uses the key directly as the hash.
/// Should only be used for block hashes that have correct DAA,
/// otherwise it is susceptible to DOS attacks via hash collisions.
pub type BlockHashMap<V> = HashMap<BlockHash, V, BlockHasher>;

/// Same as `BlockHashMap` but a `HashSet`.
pub type BlockHashSet = HashSet<BlockHash, BlockHasher>;

pub trait HashMapCustomHasher {
    fn new() -> Self;
    fn with_capacity(capacity: usize) -> Self;
}

// HashMap::new and HashMap::with_capacity are only implemented on Hasher=RandomState
// to avoid type inference problems, so we need to provide our own versions.
impl<V> HashMapCustomHasher for BlockHashMap<V> {
    #[inline(always)]
    fn new() -> Self {
        Self::with_hasher(BlockHasher::new())
    }
    #[inline(always)]
    fn with_capacity(cap: usize) -> Self {
        Self::with_capacity_and_hasher(cap, BlockHasher::new())
    }
}

impl HashMapCustomHasher for BlockHashSet {
    #[inline(always)]
    fn new() -> Self {
        Self::with_hasher(BlockHasher::new())
    }
    #[inline(always)]
    fn with_capacity(cap: usize) -> Self {
        Self::with_capacity_and_hasher(cap, BlockHasher::new())
    }
}

#[derive(Default, Debug)]
pub struct ChainPath {
    pub added: Vec<BlockHash>,
    pub removed: Vec<BlockHash>,
}

/// PR-9.5e: the 64-byte `BlockHash` (`Hash64`) writes 8 u64s via its
/// `StdHash` impl; we keep only the last word as the in-memory map
/// hash (same prefix trick the 32-byte `Hash` used with 4 words).
#[derive(Default, Clone, Copy)]
pub struct BlockHasher(u64);

impl BlockHasher {
    #[inline(always)]
    pub const fn new() -> Self {
        Self(0)
    }
}

impl Hasher for BlockHasher {
    #[inline(always)]
    fn finish(&self) -> u64 {
        self.0
    }
    #[inline(always)]
    fn write_u64(&mut self, v: u64) {
        self.0 = v;
    }
    #[cold]
    fn write(&mut self, _: &[u8]) {
        unimplemented!("use write_u64")
    }
}

impl BuildHasher for BlockHasher {
    type Hasher = Self;

    #[inline(always)]
    fn build_hasher(&self) -> Self::Hasher {
        Self(0)
    }
}

pub type BlockLevel = u8;

#[cfg(test)]
mod tests {
    use super::BlockHasher;
    use crate::BlockHash;
    use std::hash::{Hash as _, Hasher as _};
    #[test]
    fn test_block_hasher() {
        // PR-9.5e: `BlockHash` is now the 64-byte `Hash64`, whose
        // `StdHash` writes 8 little-endian u64 words; the hasher
        // keeps the last (8th).
        let hash = BlockHash::from_le_u64([1, 2, 3, 4, 5, 6, 7, 8]);
        let mut hasher = BlockHasher::default();
        hash.hash(&mut hasher);
        assert_eq!(hasher.finish(), 8);
    }
}

pub mod palw_flat_model_vector_v9;
pub mod palw_flat_model_vector_da_v9;
