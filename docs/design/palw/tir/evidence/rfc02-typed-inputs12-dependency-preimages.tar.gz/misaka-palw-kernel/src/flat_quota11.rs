//! Opt-in persisted quota transitions for explicitly funded native subjects.
//!
//! All twenty-one axes use cumulative conservative allowances, including the
//! payload/storage axes: these are neither process RSS nor a live-disk lease.
//! A native consumer must authenticate the network policy, trusted chain epoch,
//! class and input bindings, original coin funding and action authorization.
//! This module supplies no coin, reward, availability or execution-Final right.
//! Expensive failed attempts keep their receipt. Unused guarantees are not
//! refunded at close; interval rollover expires them but retains subject roots.
use crate::{
    flat_court9::complete_scope_api_bounds_v9,
    flat_resources10::{ResourceAxisV10, ResourceQuantitiesV10, derive_flat_resources_v10},
    flat_scope9::flat_resource_scope_v9,
    hash::{Digest, object_id},
    seg_encoder::EncoderBindingV1,
    trace::ParamCommitmentsV1,
};
use borsh::{BorshDeserialize, BorshSerialize};
use misaka_palw_tir::program::TirProgramV1;
use std::{collections::BTreeMap, io::Cursor};

pub const QUOTA_AXES_V11: usize = 21;
pub const FUTURE_ACTION_KINDS_V11: usize = 6;
pub const ACTION_OUTER_ALLOWANCE_V11: u64 = 16 << 10;
pub const MAX_DA_REQUEST_BYTES_V11: u64 = 1024;
pub const MAX_DA_ANSWER_BYTES_V11: u64 = 16 << 10;
pub const MAX_FIXED_ACTION_BYTES_V11: u64 = 256;
const QUOTA_ACTOR_ROW_BYTES_V11: u64 = 64 + 2 * 21 * 16;
const QUOTA_SUBJECT_ROW_BYTES_V11: u64 = 64 + 2 + 11 * 64 + 4 + 8 + 8 + 3 * 21 * 16 + 6 * 4 + 1;
const QUOTA_STATE_FIXED_BYTES_V11: u64 = 64 + 64 + 8 + 8 + 4 * 21 * 16 + 4 + 4;

#[derive(Clone, Debug, Default, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct QuotaQuantitiesV11(pub [u128; QUOTA_AXES_V11]);
impl From<&ResourceQuantitiesV10> for QuotaQuantitiesV11 {
    fn from(value: &ResourceQuantitiesV10) -> Self {
        Self(value.0)
    }
}
impl QuotaQuantitiesV11 {
    pub fn get(&self, axis: ResourceAxisV10) -> u128 {
        self.0[axis as usize]
    }
    fn set(&mut self, axis: ResourceAxisV10, value: u128) {
        self.0[axis as usize] = value;
    }
    pub fn checked_add(&self, rhs: &Self) -> Result<Self, String> {
        let mut value = Self::default();
        for (out, (a, b)) in value.0.iter_mut().zip(self.0.iter().zip(rhs.0.iter())) {
            *out = a.checked_add(*b).ok_or("quota addition overflow")?;
        }
        Ok(value)
    }
    pub fn checked_sub(&self, rhs: &Self) -> Result<Self, String> {
        let mut value = Self::default();
        for (out, (a, b)) in value.0.iter_mut().zip(self.0.iter().zip(rhs.0.iter())) {
            *out = a.checked_sub(*b).ok_or("subject guarantee exhausted")?;
        }
        Ok(value)
    }
    fn checked_mul(&self, times: u32) -> Result<Self, String> {
        let mut value = Self::default();
        for (out, a) in value.0.iter_mut().zip(self.0.iter()) {
            *out = a.checked_mul(times as u128).ok_or("quota multiplication overflow")?;
        }
        Ok(value)
    }
    fn within(&self, cap: &Self) -> Result<(), String> {
        for axis in ResourceAxisV10::ALL {
            if self.get(axis) > cap.get(axis) {
                return Err(format!("quota cap exceeded: {axis:?}"));
            }
        }
        Ok(())
    }
}

/// Fixed compiled action grammar, arithmetic and guarantee semantics. A native
/// configuration supplies the network domain and caps, never an action carrier.
pub fn quota_ruleset_id_v11() -> Digest {
    object_id(
        b"misaka-palw/kernel/resource-quota-ruleset/v11",
        &(
            crate::flat_scope9::flat_court_set_id_v9(),
            QUOTA_AXES_V11 as u32,
            FUTURE_ACTION_KINDS_V11 as u32,
            ACTION_OUTER_ALLOWANCE_V11,
            MAX_DA_REQUEST_BYTES_V11,
            MAX_DA_ANSWER_BYTES_V11,
            MAX_FIXED_ACTION_BYTES_V11,
            b"cumulative21;baseline-once;used+reserved;deadline-in-one-interval;block-holds-remaining;failed-attempts-spent;no-terminal-refund".to_vec(),
        ),
    )
}

#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct QuotaPolicyV11 {
    pub version: u16,
    pub enabled: bool,
    pub network_domain: Digest,
    pub ruleset_digest: Digest,
    pub interval_daa: u64,
    pub plan: QuotaQuantitiesV11,
    pub block: QuotaQuantitiesV11,
    pub actor: QuotaQuantitiesV11,
    pub network: QuotaQuantitiesV11,
    pub max_subjects: u32,
    pub max_actors: u32,
    /// Metadata, request, answer, court, chunk, close attempts respectively.
    /// Invalid expensive bodies consume their corresponding prepaid slot.
    pub future_attempts: [u32; FUTURE_ACTION_KINDS_V11],
}
impl QuotaPolicyV11 {
    pub fn root(&self) -> Digest {
        object_id(b"misaka-palw/kernel/resource-quota-policy/v11", self)
    }
    pub fn check(&self) -> Result<(), String> {
        if self.version != 11 || self.ruleset_digest != quota_ruleset_id_v11() || self.interval_daa == 0 {
            return Err("invalid fixed quota policy".into());
        }
        if !self.enabled {
            return Err("native quota policy is dormant".into());
        }
        if self.max_subjects == 0 || self.max_actors == 0 || self.future_attempts[5] == 0 {
            return Err("quota policy lacks bounded subjects/actors/close".into());
        }
        self.future_attempts.iter().try_fold(1u32, |n, count| n.checked_add(*count)).ok_or("quota attempt count overflow")?;
        Ok(())
    }
}

/// The constructor derives the interval quotient. The native caller must use
/// its actual chain context; a user's claimed block/DAA is not a trusted epoch.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct TrustedEpochV11 {
    pub block_hash: Digest,
    pub block_daa: u64,
    pub network_interval: u64,
}
impl TrustedEpochV11 {
    pub fn from_chain(policy: &QuotaPolicyV11, block_hash: Digest, block_daa: u64) -> Result<Self, String> {
        policy.check()?;
        Ok(Self { block_hash, block_daa, network_interval: block_daa / policy.interval_daa })
    }
    fn check(&self, policy: &QuotaPolicyV11) -> Result<(), String> {
        if self.network_interval != self.block_daa / policy.interval_daa {
            return Err("quota epoch interval differs from trusted DAA".into());
        }
        Ok(())
    }
    fn interval_end(&self, policy: &QuotaPolicyV11) -> Result<u64, String> {
        self.network_interval
            .checked_add(1)
            .and_then(|v| v.checked_mul(policy.interval_daa))
            .ok_or("quota interval end overflow".into())
    }
}

#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct SubjectBindingV11 {
    pub version: u16,
    pub policy_root: Digest,
    pub class_id: Digest,
    pub class_scope9_root: Digest,
    pub program_root: Digest,
    pub parameter_root: Digest,
    pub job_id: Digest,
    pub job_input_root: Digest,
    pub resource10_root: Digest,
    pub quota_plan_root: Digest,
    pub actual_positions: u32,
    pub requester: Digest,
    pub producer: Digest,
    pub admitted_interval: u64,
    /// Includes proof/DA/chunk/retention and any post-Final liability period.
    pub deadline_daa: u64,
}
impl SubjectBindingV11 {
    pub fn root(&self) -> Digest {
        object_id(b"misaka-palw/kernel/resource-quota-subject/v11", self)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub enum QuotaActionKindV11 {
    BaselineJob,
    Metadata,
    DARequest,
    DAAnswer,
    Court,
    Chunk,
    Close,
}
impl QuotaActionKindV11 {
    fn future_index(self) -> Option<usize> {
        match self {
            Self::BaselineJob => None,
            Self::Metadata => Some(0),
            Self::DARequest => Some(1),
            Self::DAAnswer => Some(2),
            Self::Court => Some(3),
            Self::Chunk => Some(4),
            Self::Close => Some(5),
        }
    }
}

/// Constructors are the only authority for quantities. This type deliberately
/// has no wire deserializer or public quantity fields.
#[derive(Clone, Debug)]
pub struct DerivedQuotaActionV11 {
    kind: QuotaActionKindV11,
    resource_root: Digest,
    class_scope_root: Digest,
    positions: u32,
    quantities: QuotaQuantitiesV11,
}
impl DerivedQuotaActionV11 {
    pub fn kind(&self) -> QuotaActionKindV11 {
        self.kind
    }
    pub fn quantities(&self) -> &QuotaQuantitiesV11 {
        &self.quantities
    }
}

/// Internally checked metadata, not an execution or availability certificate.
/// The native route must predebit bounded decode and scope derivation before
/// calling this factory; later actions need not rederive the reference vector.
pub struct CheckedJobQuotaPlanV11 {
    program_root: Digest,
    parameter_root: Digest,
    resource_root: Digest,
    class_scope_root: Digest,
    positions: u32,
    baseline: QuotaQuantitiesV11,
    action_envelopes: [QuotaQuantitiesV11; FUTURE_ACTION_KINDS_V11],
    action_carrier_caps: [u64; FUTURE_ACTION_KINDS_V11],
}
/// A native admission creates this record internally and commits its root in
/// the authenticated job. It is not a wire-supplied price certificate.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct QuotaPlanRecordV11 {
    pub version: u16,
    pub program_root: Digest,
    pub parameter_root: Digest,
    pub resource_root: Digest,
    pub class_scope_root: Digest,
    pub positions: u32,
    pub baseline: QuotaQuantitiesV11,
    pub action_envelopes: [QuotaQuantitiesV11; FUTURE_ACTION_KINDS_V11],
    pub action_carrier_caps: [u64; FUTURE_ACTION_KINDS_V11],
}
impl QuotaPlanRecordV11 {
    pub fn root(&self) -> Digest {
        object_id(b"misaka-palw/kernel/resource-quota-plan/v11", self)
    }
}
impl CheckedJobQuotaPlanV11 {
    pub fn record(&self) -> QuotaPlanRecordV11 {
        QuotaPlanRecordV11 {
            version: 11,
            program_root: self.program_root,
            parameter_root: self.parameter_root,
            resource_root: self.resource_root,
            class_scope_root: self.class_scope_root,
            positions: self.positions,
            baseline: self.baseline.clone(),
            action_envelopes: self.action_envelopes.clone(),
            action_carrier_caps: self.action_carrier_caps,
        }
    }
    /// The expected root must come from the authenticated native job/state row,
    /// whose admission independently derived this exact record. The caller must
    /// never take it from the action body or an unauthenticated price declaration.
    pub fn restore(record: &QuotaPlanRecordV11, expected_root: &Digest) -> Result<Self, String> {
        if record.version != 11 || record.positions == 0 || record.root() != *expected_root {
            return Err("stored quota plan differs from admitted root".into());
        }
        Ok(Self {
            program_root: record.program_root,
            parameter_root: record.parameter_root,
            resource_root: record.resource_root,
            class_scope_root: record.class_scope_root,
            positions: record.positions,
            baseline: record.baseline.clone(),
            action_envelopes: record.action_envelopes.clone(),
            action_carrier_caps: record.action_carrier_caps,
        })
    }
    pub fn resource_root(&self) -> Digest {
        self.resource_root
    }
    pub fn class_scope_root(&self) -> Digest {
        self.class_scope_root
    }
    pub fn baseline(&self) -> DerivedQuotaActionV11 {
        DerivedQuotaActionV11 {
            kind: QuotaActionKindV11::BaselineJob,
            resource_root: self.resource_root,
            class_scope_root: self.class_scope_root,
            positions: self.positions,
            quantities: self.baseline.clone(),
        }
    }
    /// The native codec enforces this cap before body allocation/decoding. The
    /// same envelope is prepaid even for a smaller or subsequently invalid body.
    pub fn action_carrier_cap(&self, kind: QuotaActionKindV11) -> Result<u64, String> {
        Ok(self.action_carrier_caps[kind.future_index().ok_or("baseline has no future carrier")?])
    }
    pub fn action(&self, kind: QuotaActionKindV11, carrier: &[u8]) -> Result<DerivedQuotaActionV11, String> {
        let index = kind.future_index().ok_or("use baseline constructor")?;
        if carrier.len() as u128 > self.action_carrier_caps[index] as u128 {
            return Err("quota action carrier exceeds independently derived bound".into());
        }
        Ok(DerivedQuotaActionV11 {
            kind,
            resource_root: self.resource_root,
            class_scope_root: self.class_scope_root,
            positions: self.positions,
            quantities: self.action_envelopes[index].clone(),
        })
    }
    fn guarantee(&self, policy: &QuotaPolicyV11) -> Result<QuotaQuantitiesV11, String> {
        self.action_envelopes
            .iter()
            .zip(policy.future_attempts)
            .try_fold(QuotaQuantitiesV11::default(), |q, (action, count)| q.checked_add(&action.checked_mul(count)?))
    }
}

fn action_envelope(metadata_work: u128, bytes: u64, court: Option<(u64, u64, u64)>) -> Result<QuotaQuantitiesV11, String> {
    let mut q = QuotaQuantitiesV11::default();
    let bytes = bytes as u128;
    let copies = bytes.checked_mul(3).ok_or("quota carrier copies overflow")?;
    let storage = bytes.checked_add(16 << 10).ok_or("quota carrier storage overflow")?;
    for (axis, quantity) in [
        (ResourceAxisV10::ScalarSteps, bytes.checked_mul(16).ok_or("quota scalar cost overflow")?),
        (ResourceAxisV10::IndexSteps, bytes.checked_mul(16).ok_or("quota index cost overflow")?),
        (ResourceAxisV10::ValidatedElements, bytes),
        (ResourceAxisV10::CopiedReferenceBytes, copies),
        (ResourceAxisV10::TraceHashBytes, copies),
        (ResourceAxisV10::ContainerAllocatorAllowance, storage),
        (ResourceAxisV10::StoredEvidenceBytes, bytes),
        (ResourceAxisV10::DeliveryBytes, bytes),
        (ResourceAxisV10::ReplyCalls, 1),
        (ResourceAxisV10::Attempts, 1),
        (ResourceAxisV10::MetadataWork, metadata_work),
        (ResourceAxisV10::OwnedPeakBytes, copies.checked_add(storage).ok_or("quota carrier peak overflow")?),
    ] {
        q.set(axis, quantity);
    }
    if let Some((work, filing, scratch)) = court {
        q.set(ResourceAxisV10::CourtWork, work as u128);
        q.set(ResourceAxisV10::CourtBytes, filing as u128);
        q.set(ResourceAxisV10::CourtScratchBytes, scratch as u128);
        q.set(
            ResourceAxisV10::OwnedPeakBytes,
            q.get(ResourceAxisV10::OwnedPeakBytes).checked_add(scratch as u128).ok_or("quota court peak overflow")?,
        );
    }
    Ok(q)
}

pub fn derive_job_quota_plan_v11(
    program: &TirProgramV1,
    pc: &ParamCommitmentsV1,
    class_max_positions: u32,
    actual_positions: u32,
    encoder: Option<&EncoderBindingV1>,
) -> Result<CheckedJobQuotaPlanV11, String> {
    if actual_positions == 0 || actual_positions > class_max_positions {
        return Err("quota job extent exceeds admitted class".into());
    }
    let plan = derive_flat_resources_v10(program, pc, actual_positions, encoder)?;
    let class_scope = flat_resource_scope_v9(program, class_max_positions, encoder).map_err(|e| format!("{e:?}"))?;
    let court = complete_scope_api_bounds_v9(&plan.court).map_err(|e| format!("{e:?}"))?;
    // The assembled proof limit comes from the independently derived header,
    // including a fixed bounded outer carrier; it is not an unguarded 1MiB.
    let assembled = court.filing_bytes.checked_add(ACTION_OUTER_ALLOWANCE_V11).ok_or("quota filing bound overflow")?;
    let metadata_carrier = (program.encode().len() as u64)
        .checked_add((pc.by_instance.len() as u64).checked_mul(80).ok_or("quota PC carrier overflow")?)
        .and_then(|b| b.checked_add(ACTION_OUTER_ALLOWANCE_V11))
        .ok_or("quota metadata carrier overflow")?;
    let metadata = plan.vector.quantities.get(ResourceAxisV10::MetadataWork);
    let envelopes = [
        action_envelope(metadata, metadata_carrier, None)?,
        action_envelope(16 << 10, MAX_DA_REQUEST_BYTES_V11, None)?,
        action_envelope(16 << 10, MAX_DA_ANSWER_BYTES_V11, None)?,
        action_envelope(metadata, assembled, Some((court.work, court.filing_bytes, court.scratch_bytes)))?,
        action_envelope(metadata, assembled, Some((court.work, court.filing_bytes, court.scratch_bytes)))?,
        action_envelope(16 << 10, MAX_FIXED_ACTION_BYTES_V11, None)?,
    ];
    Ok(CheckedJobQuotaPlanV11 {
        // Native classes use the frozen program-byte root. The resource vector
        // also commits its separate domain10 semantic program digest internally.
        program_root: crate::public::program_root_v1(&program.encode()),
        parameter_root: pc.root(),
        resource_root: plan.vector.root(),
        class_scope_root: class_scope.root(),
        positions: actual_positions,
        baseline: QuotaQuantitiesV11::from(&plan.vector.quantities),
        action_envelopes: envelopes,
        action_carrier_caps: [
            metadata_carrier,
            MAX_DA_REQUEST_BYTES_V11,
            MAX_DA_ANSWER_BYTES_V11,
            assembled,
            assembled,
            MAX_FIXED_ACTION_BYTES_V11,
        ],
    })
}

/// Ordinary class/admission metadata has no claim on another subject's mature
/// guarantee. The native route still prepays structural decode before this
/// bounded canonical-program factory and authenticates the charging actor.
pub struct DerivedOrdinaryMetadataV11 {
    quantities: QuotaQuantitiesV11,
}
impl DerivedOrdinaryMetadataV11 {
    pub fn quantities(&self) -> &QuotaQuantitiesV11 {
        &self.quantities
    }
}
pub fn derive_ordinary_metadata_v11(program: &TirProgramV1, pc: &ParamCommitmentsV1) -> Result<DerivedOrdinaryMetadataV11, String> {
    let bytes =
        crate::flat_court4::size_with_limit(program, misaka_palw_tir::program::MAX_PROGRAM_BYTES as u64).map_err(|e| e.to_string())?;
    let structural = crate::ledger::flat_candidate7::flat_candidate_registration_work_v7(bytes as usize, pc.by_instance.len())
        .ok_or("quota ordinary structural work overflow")?;
    let metadata =
        crate::ledger::flat_candidate7::flat_candidate_metadata_work_v7(program).ok_or("quota ordinary metadata work overflow")?;
    let carrier = bytes
        .checked_add((pc.by_instance.len() as u64).checked_mul(80).ok_or("quota ordinary carrier overflow")?)
        .and_then(|b| b.checked_add(ACTION_OUTER_ALLOWANCE_V11))
        .ok_or("quota ordinary carrier overflow")?;
    Ok(DerivedOrdinaryMetadataV11 { quantities: action_envelope(structural as u128 + metadata as u128, carrier, None)? })
}

#[derive(Clone, Debug, Default, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct QuotaIntervalSummaryV11 {
    pub consumed: QuotaQuantitiesV11,
    pub reserved: QuotaQuantitiesV11,
}
impl QuotaIntervalSummaryV11 {
    fn total(&self) -> Result<QuotaQuantitiesV11, String> {
        self.consumed.checked_add(&self.reserved)
    }
    fn admit(&self, baseline: &QuotaQuantitiesV11, guarantee: &QuotaQuantitiesV11, cap: &QuotaQuantitiesV11) -> Result<Self, String> {
        let value = Self { consumed: self.consumed.checked_add(baseline)?, reserved: self.reserved.checked_add(guarantee)? };
        value.total()?.within(cap)?;
        Ok(value)
    }
    fn consume(&self, delta: &QuotaQuantitiesV11, cap: &QuotaQuantitiesV11) -> Result<Self, String> {
        let value = Self { consumed: self.consumed.checked_add(delta)?, reserved: self.reserved.checked_sub(delta)? };
        value.total()?.within(cap)?;
        Ok(value)
    }
}
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct QuotaSubjectSummaryV11 {
    pub binding: SubjectBindingV11,
    pub committed: QuotaQuantitiesV11,
    pub consumed: QuotaQuantitiesV11,
    pub guarantee_remaining: QuotaQuantitiesV11,
    pub future_attempts_used: [u32; FUTURE_ACTION_KINDS_V11],
    pub closed: bool,
}
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct QuotaStateV11 {
    policy_root: Digest,
    epoch: TrustedEpochV11,
    block: QuotaIntervalSummaryV11,
    network: QuotaIntervalSummaryV11,
    actors: BTreeMap<Digest, QuotaIntervalSummaryV11>,
    subjects: BTreeMap<Digest, QuotaSubjectSummaryV11>,
}
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize)]
pub struct QuotaReceiptV11 {
    pub policy_root: Digest,
    pub epoch: TrustedEpochV11,
    pub subject_binding: Digest,
    pub kind: QuotaActionKindV11,
    pub consumed: QuotaQuantitiesV11,
    pub added_guarantee: QuotaQuantitiesV11,
    pub remaining_guarantee: QuotaQuantitiesV11,
}
impl QuotaStateV11 {
    /// Reject map counts, truncated rows, duplicate/noncanonical ordering and
    /// excess bytes before constructing map entries. The policy is trusted
    /// network configuration; its fixed counts bound snapshot allocation.
    pub fn from_bytes(policy: &QuotaPolicyV11, bytes: &[u8]) -> Result<Self, String> {
        policy.check()?;
        let maximum = QUOTA_STATE_FIXED_BYTES_V11
            .checked_add(
                QUOTA_ACTOR_ROW_BYTES_V11.checked_mul(policy.max_actors as u64).ok_or("quota snapshot actor extent overflow")?,
            )
            .and_then(|n| n.checked_add(QUOTA_SUBJECT_ROW_BYTES_V11.checked_mul(policy.max_subjects as u64)?))
            .ok_or("quota snapshot maximum extent overflow")?;
        if bytes.len() as u128 > maximum as u128 {
            return Err("quota snapshot exceeds fixed policy extent".into());
        }
        fn read<T: BorshDeserialize>(reader: &mut Cursor<&[u8]>) -> Result<T, String> {
            T::deserialize_reader(reader).map_err(|e| format!("malformed quota snapshot: {e}"))
        }
        fn check_rows(reader: &Cursor<&[u8]>, count: u32, cap: u32, width: u64) -> Result<(), String> {
            if count > cap
                || (count as u64)
                    .checked_mul(width)
                    .is_none_or(|n| n > (reader.get_ref().len() as u64).saturating_sub(reader.position()))
            {
                return Err("quota snapshot map exceeds bounded available rows".into());
            }
            Ok(())
        }
        let mut reader = Cursor::new(bytes);
        let policy_root = read(&mut reader)?;
        let epoch = read(&mut reader)?;
        let block = read(&mut reader)?;
        let network = read(&mut reader)?;
        let actor_count: u32 = read(&mut reader)?;
        check_rows(&reader, actor_count, policy.max_actors, QUOTA_ACTOR_ROW_BYTES_V11)?;
        let mut actors = BTreeMap::new();
        let mut previous = None;
        for _ in 0..actor_count {
            let key: Digest = read(&mut reader)?;
            if previous.is_some_and(|old| old >= key) {
                return Err("quota snapshot actor keys are not canonical".into());
            }
            previous = Some(key);
            actors.insert(key, read(&mut reader)?);
        }
        let subject_count: u32 = read(&mut reader)?;
        check_rows(&reader, subject_count, policy.max_subjects, QUOTA_SUBJECT_ROW_BYTES_V11)?;
        let mut subjects = BTreeMap::new();
        previous = None;
        for _ in 0..subject_count {
            let key: Digest = read(&mut reader)?;
            if previous.is_some_and(|old| old >= key) {
                return Err("quota snapshot subject keys are not canonical".into());
            }
            previous = Some(key);
            subjects.insert(key, read(&mut reader)?);
        }
        if reader.position() != bytes.len() as u64 {
            return Err("quota snapshot has trailing bytes".into());
        }
        let state = Self { policy_root, epoch, block, network, actors, subjects };
        state.check_restored(policy)?;
        Ok(state)
    }
    pub fn new(policy: &QuotaPolicyV11, epoch: TrustedEpochV11) -> Result<Self, String> {
        policy.check()?;
        epoch.check(policy)?;
        Ok(Self {
            policy_root: policy.root(),
            epoch,
            block: QuotaIntervalSummaryV11::default(),
            network: QuotaIntervalSummaryV11::default(),
            actors: BTreeMap::new(),
            subjects: BTreeMap::new(),
        })
    }
    pub fn root(&self) -> Digest {
        object_id(b"misaka-palw/kernel/resource-quota-state/v11", self)
    }
    pub fn block(&self) -> &QuotaIntervalSummaryV11 {
        &self.block
    }
    pub fn network(&self) -> &QuotaIntervalSummaryV11 {
        &self.network
    }
    pub fn actor(&self, actor: &Digest) -> Option<&QuotaIntervalSummaryV11> {
        self.actors.get(actor)
    }
    pub fn subject(&self, job: &Digest) -> Option<&QuotaSubjectSummaryV11> {
        self.subjects.get(job)
    }
    /// A persisted consensus row is bounded by this fixed policy. Deserializers
    /// used for untrusted snapshots must additionally cap map counts before
    /// allocation; ordinary Borsh allocation is not a wire preflight guard.
    pub fn check_restored(&self, policy: &QuotaPolicyV11) -> Result<(), String> {
        policy.check()?;
        self.epoch.check(policy)?;
        if self.policy_root != policy.root()
            || self.subjects.len() > policy.max_subjects as usize
            || self.actors.len() > policy.max_actors as usize
        {
            return Err("restored quota policy/count mismatch".into());
        }
        self.block.total()?.within(&policy.block)?;
        self.network.total()?.within(&policy.network)?;
        let mut reserved = QuotaQuantitiesV11::default();
        let mut actor_reserved: BTreeMap<Digest, QuotaQuantitiesV11> = BTreeMap::new();
        let mut actor_subject_consumed: BTreeMap<Digest, QuotaQuantitiesV11> = BTreeMap::new();
        for (key, subject) in &self.subjects {
            if *key != subject.binding.job_id || subject.binding.version != 11 || subject.binding.policy_root != self.policy_root {
                return Err("restored quota subject identity mismatch".into());
            }
            if subject.consumed.checked_add(&subject.guarantee_remaining)? != subject.committed {
                return Err("restored quota subject conservation mismatch".into());
            }
            subject.committed.within(&policy.plan)?;
            if subject.future_attempts_used.iter().zip(policy.future_attempts).any(|(used, cap)| *used > cap) {
                return Err("restored quota attempts exceeded".into());
            }
            if subject.binding.admitted_interval == self.epoch.network_interval {
                if subject.binding.deadline_daa >= self.epoch.interval_end(policy)? {
                    return Err("restored quota liability crosses interval".into());
                }
                reserved = reserved.checked_add(&subject.guarantee_remaining)?;
                let old = actor_reserved.get(&subject.binding.producer).cloned().unwrap_or_default();
                actor_reserved.insert(subject.binding.producer, old.checked_add(&subject.guarantee_remaining)?);
                let old = actor_subject_consumed.get(&subject.binding.producer).cloned().unwrap_or_default();
                actor_subject_consumed.insert(subject.binding.producer, old.checked_add(&subject.consumed)?);
            }
        }
        if self.block.reserved != reserved || self.network.reserved != reserved {
            return Err("restored quota lost a subject guarantee".into());
        }
        let mut actor_consumed = QuotaQuantitiesV11::default();
        for (key, actor) in &self.actors {
            actor.total()?.within(&policy.actor)?;
            actor_consumed = actor_consumed.checked_add(&actor.consumed)?;
            actor_subject_consumed.remove(key).unwrap_or_default().within(&actor.consumed)?;
            if actor.reserved != actor_reserved.remove(key).unwrap_or_default() {
                return Err("restored actor guarantee differs from subjects".into());
            }
        }
        if !actor_reserved.is_empty() || !actor_subject_consumed.is_empty() {
            return Err("restored quota subject lacks actor summary".into());
        }
        if actor_consumed != self.network.consumed {
            return Err("restored network consumption differs from actors".into());
        }
        self.block.consumed.within(&self.network.consumed)?;
        Ok(())
    }
    fn check_context(&self, policy: &QuotaPolicyV11, epoch: &TrustedEpochV11) -> Result<(bool, bool), String> {
        policy.check()?;
        epoch.check(policy)?;
        if policy.root() != self.policy_root {
            return Err("persisted quota policy cannot change".into());
        }
        if epoch.block_hash == self.epoch.block_hash {
            if epoch != &self.epoch {
                return Err("same quota block has changed trusted identity".into());
            }
            return Ok((false, false));
        }
        if epoch.block_daa < self.epoch.block_daa || epoch.network_interval < self.epoch.network_interval {
            return Err("quota epoch did not advance".into());
        }
        Ok((true, epoch.network_interval != self.epoch.network_interval))
    }
    /// Paid ordinary preparation uses only unreserved capacity. No subject is
    /// created and no mature court/DA/chunk guarantee is consumed by a flood.
    pub fn debit_ordinary(
        &mut self,
        policy: &QuotaPolicyV11,
        epoch: &TrustedEpochV11,
        actor: Digest,
        action: &DerivedOrdinaryMetadataV11,
    ) -> Result<(), String> {
        let (new_block, new_interval) = self.check_context(policy, epoch)?;
        let actor_old = if new_interval { None } else { self.actors.get(&actor) };
        if actor_old.is_none() && (if new_interval { 0 } else { self.actors.len() }) >= policy.max_actors as usize {
            return Err("quota interval actor count exceeded".into());
        }
        let mut block = if new_interval {
            QuotaIntervalSummaryV11::default()
        } else if new_block {
            QuotaIntervalSummaryV11 { consumed: QuotaQuantitiesV11::default(), reserved: self.block.reserved.clone() }
        } else {
            self.block.clone()
        };
        let mut network = if new_interval { QuotaIntervalSummaryV11::default() } else { self.network.clone() };
        let mut actor_next = actor_old.cloned().unwrap_or_default();
        for (summary, cap) in [(&mut block, &policy.block), (&mut network, &policy.network), (&mut actor_next, &policy.actor)] {
            summary.consumed = summary.consumed.checked_add(&action.quantities)?;
            summary.total()?.within(cap)?;
        }
        if new_interval {
            self.actors.clear();
        }
        self.actors.insert(actor, actor_next);
        self.block = block;
        self.network = network;
        self.epoch = epoch.clone();
        Ok(())
    }
    /// Authenticated native consumers call before body decoding or callbacks,
    /// then persist the receipt even when the expensive action is dismissed.
    /// Summary changes are atomic on arithmetic, cap and binding failures.
    pub fn debit(
        &mut self,
        policy: &QuotaPolicyV11,
        epoch: &TrustedEpochV11,
        binding: &SubjectBindingV11,
        plan: &CheckedJobQuotaPlanV11,
        action: &DerivedQuotaActionV11,
    ) -> Result<QuotaReceiptV11, String> {
        let (new_block, new_interval) = self.check_context(policy, epoch)?;
        if binding.version != 11
            || binding.policy_root != self.policy_root
            || binding.resource10_root != plan.resource_root
            || binding.class_scope9_root != plan.class_scope_root
            || binding.actual_positions != plan.positions
            || binding.program_root != plan.program_root
            || binding.parameter_root != plan.parameter_root
            || binding.quota_plan_root != plan.record().root()
            || action.resource_root != plan.resource_root
            || action.class_scope_root != plan.class_scope_root
            || action.positions != plan.positions
        {
            return Err("quota subject/action differs from independently checked job/class plan".into());
        }
        if binding.admitted_interval != epoch.network_interval
            || binding.deadline_daa < epoch.block_daa
            || binding.deadline_daa >= epoch.interval_end(policy)?
        {
            return Err("quota subject liability crosses or outlives its fixed interval".into());
        }
        let old = self.subjects.get(&binding.job_id);
        if let Some(old) = old {
            if old.binding != *binding {
                return Err("quota subject binding cannot be rebound".into());
            }
            if old.closed {
                return Err("quota subject is already closed".into());
            }
        }
        let initial = action.kind == QuotaActionKindV11::BaselineJob;
        if initial != old.is_none() {
            return Err("quota baseline must be reserved exactly once before future actions".into());
        }
        if initial && self.subjects.len() >= policy.max_subjects as usize {
            return Err("quota retained subject count exceeded".into());
        }
        // The producer's authenticated reservation funds all action allowances.
        // Native challenger/requester coin debits remain separate subject rules.
        let actor_old = if new_interval { None } else { self.actors.get(&binding.producer) };
        if actor_old.is_none() && (if new_interval { 0 } else { self.actors.len() }) >= policy.max_actors as usize {
            return Err("quota interval actor count exceeded".into());
        }
        let block_old = if new_interval {
            QuotaIntervalSummaryV11::default()
        } else if new_block {
            QuotaIntervalSummaryV11 { consumed: QuotaQuantitiesV11::default(), reserved: self.block.reserved.clone() }
        } else {
            self.block.clone()
        };
        let network_old = if new_interval { QuotaIntervalSummaryV11::default() } else { self.network.clone() };
        let actor_old = actor_old.cloned().unwrap_or_default();
        let (subject, added, block, network, actor) = if initial {
            if action.quantities != plan.baseline {
                return Err("wrong independently derived baseline quantities".into());
            }
            let guarantee = plan.guarantee(policy)?;
            let committed = action.quantities.checked_add(&guarantee)?;
            committed.within(&policy.plan)?;
            (
                QuotaSubjectSummaryV11 {
                    binding: binding.clone(),
                    committed,
                    consumed: action.quantities.clone(),
                    guarantee_remaining: guarantee.clone(),
                    future_attempts_used: [0; FUTURE_ACTION_KINDS_V11],
                    closed: false,
                },
                guarantee.clone(),
                block_old.admit(&action.quantities, &guarantee, &policy.block)?,
                network_old.admit(&action.quantities, &guarantee, &policy.network)?,
                actor_old.admit(&action.quantities, &guarantee, &policy.actor)?,
            )
        } else {
            let mut subject = old.expect("checked existing subject").clone();
            let index = action.kind.future_index().ok_or("future action has no index")?;
            if action.quantities != plan.action_envelopes[index]
                || subject.future_attempts_used[index] >= policy.future_attempts[index]
            {
                return Err("quota action exceeds its fixed prepaid attempt count".into());
            }
            subject.future_attempts_used[index] =
                subject.future_attempts_used[index].checked_add(1).ok_or("quota subject attempt count overflow")?;
            subject.consumed = subject.consumed.checked_add(&action.quantities)?;
            subject.guarantee_remaining = subject.guarantee_remaining.checked_sub(&action.quantities)?;
            if subject.consumed.checked_add(&subject.guarantee_remaining)? != subject.committed {
                return Err("quota subject conservation mismatch".into());
            }
            subject.closed = action.kind == QuotaActionKindV11::Close;
            (
                subject,
                QuotaQuantitiesV11::default(),
                block_old.consume(&action.quantities, &policy.block)?,
                network_old.consume(&action.quantities, &policy.network)?,
                actor_old.consume(&action.quantities, &policy.actor)?,
            )
        };
        let receipt = QuotaReceiptV11 {
            policy_root: self.policy_root,
            epoch: epoch.clone(),
            subject_binding: binding.root(),
            kind: action.kind,
            consumed: action.quantities.clone(),
            added_guarantee: added,
            remaining_guarantee: subject.guarantee_remaining.clone(),
        };
        // All arithmetic and policy checks completed before touching a map.
        if new_interval {
            self.actors.clear();
        }
        self.actors.insert(binding.producer, actor);
        self.subjects.insert(binding.job_id, subject);
        self.block = block;
        self.network = network;
        self.epoch = epoch.clone();
        Ok(receipt)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::flat_court4::tests::primitive_fixture;

    fn fixture() -> (CheckedJobQuotaPlanV11, QuotaPolicyV11, TrustedEpochV11, SubjectBindingV11) {
        let (program, params, _) = primitive_fixture(11);
        let pc = ParamCommitmentsV1::of_v3(&params);
        let plan = derive_job_quota_plan_v11(&program, &pc, 3, 1, None).unwrap();
        let mut policy = QuotaPolicyV11 {
            version: 11,
            enabled: true,
            network_domain: [51; 64],
            ruleset_digest: quota_ruleset_id_v11(),
            interval_daa: 100,
            plan: QuotaQuantitiesV11::default(),
            block: QuotaQuantitiesV11::default(),
            actor: QuotaQuantitiesV11::default(),
            network: QuotaQuantitiesV11::default(),
            max_subjects: 4,
            max_actors: 4,
            future_attempts: [1, 2, 2, 2, 2, 1],
        };
        let need = plan.baseline.checked_add(&plan.guarantee(&policy).unwrap()).unwrap();
        policy.plan = need.clone();
        policy.block = need.checked_mul(4).unwrap();
        policy.actor = policy.block.clone();
        policy.network = policy.block.clone();
        let epoch = TrustedEpochV11::from_chain(&policy, [52; 64], 10).unwrap();
        let binding = SubjectBindingV11 {
            version: 11,
            policy_root: policy.root(),
            class_id: [53; 64],
            class_scope9_root: plan.class_scope_root,
            program_root: plan.program_root,
            parameter_root: plan.parameter_root,
            job_id: [54; 64],
            job_input_root: [55; 64],
            resource10_root: plan.resource_root,
            quota_plan_root: plan.record().root(),
            actual_positions: 1,
            requester: [56; 64],
            producer: [57; 64],
            admitted_interval: 0,
            deadline_daa: 99,
        };
        (plan, policy, epoch, binding)
    }
    fn future(plan: &CheckedJobQuotaPlanV11, kind: QuotaActionKindV11) -> DerivedQuotaActionV11 {
        plan.action(kind, &[0; 64]).unwrap()
    }
    fn admit(
        state: &mut QuotaStateV11,
        plan: &CheckedJobQuotaPlanV11,
        policy: &QuotaPolicyV11,
        epoch: &TrustedEpochV11,
        binding: &SubjectBindingV11,
    ) {
        state.debit(policy, epoch, binding, plan, &plan.baseline()).unwrap();
    }
    #[test]
    fn actual_class_scopes_and_rooted_stored_plan_are_independently_bound() {
        let (plan, _, _, binding) = fixture();
        let (program, params, _) = primitive_fixture(11);
        let pc = ParamCommitmentsV1::of_v3(&params);
        let actual = derive_flat_resources_v10(&program, &pc, 1, None).unwrap();
        assert_eq!(plan.resource_root, actual.vector.root());
        assert_ne!(plan.class_scope_root, actual.court.root());
        let record = plan.record();
        let restored = CheckedJobQuotaPlanV11::restore(&record, &binding.quota_plan_root).unwrap();
        assert_eq!(restored.record(), record);
        assert_eq!(restored.action(QuotaActionKindV11::Court, &[1]).unwrap().quantities, plan.action_envelopes[3]);
        for change in 0..6 {
            let mut wrong = record.clone();
            match change {
                0 => wrong.version = 10,
                1 => wrong.positions += 1,
                2 => wrong.resource_root[0] ^= 1,
                3 => wrong.class_scope_root[0] ^= 1,
                4 => wrong.action_envelopes[3].0[14] -= 1,
                _ => wrong.action_carrier_caps[4] += 1,
            }
            assert!(CheckedJobQuotaPlanV11::restore(&wrong, &binding.quota_plan_root).is_err());
        }
        assert!(derive_job_quota_plan_v11(&program, &pc, 1, 2, None).is_err());
    }
    #[test]
    fn every_axis_and_all_four_cap_scopes_are_atomic_at_baseline() {
        let (plan, policy, _, binding) = fixture();
        let need = policy.plan.clone();
        for axis in ResourceAxisV10::ALL {
            assert!(need.get(axis) > 0, "fixture must exercise {axis:?}");
            for scope in 0..4 {
                let mut p = policy.clone();
                let cap = match scope {
                    0 => &mut p.plan,
                    1 => &mut p.block,
                    2 => &mut p.actor,
                    _ => &mut p.network,
                };
                cap.set(axis, need.get(axis) - 1);
                let epoch = TrustedEpochV11::from_chain(&p, [52; 64], 10).unwrap();
                let mut b = binding.clone();
                b.policy_root = p.root();
                let mut state = QuotaStateV11::new(&p, epoch.clone()).unwrap();
                let before = state.clone();
                assert!(state.debit(&p, &epoch, &b, &plan, &plan.baseline()).is_err(), "{axis:?}/{scope}");
                assert_eq!(state, before);
            }
        }
    }
    #[test]
    fn ordinary_admission_flood_cannot_take_mature_court_da_chunk_or_close_guarantee() {
        let (plan, mut policy, _, mut binding) = fixture();
        policy.block = policy.plan.clone();
        policy.actor = policy.plan.clone();
        policy.network = policy.plan.clone();
        binding.policy_root = policy.root();
        let epoch = TrustedEpochV11::from_chain(&policy, [52; 64], 10).unwrap();
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        let total = state.network.total().unwrap();
        let (program, params, _) = primitive_fixture(11);
        let ordinary = derive_ordinary_metadata_v11(&program, &ParamCommitmentsV1::of_v3(&params)).unwrap();
        for actor in [[57; 64], [60; 64], [61; 64]] {
            let before = state.clone();
            assert!(state.debit_ordinary(&policy, &epoch, actor, &ordinary).is_err());
            assert_eq!(state, before);
        }
        for kind in [
            QuotaActionKindV11::DARequest,
            QuotaActionKindV11::DAAnswer,
            QuotaActionKindV11::Court,
            QuotaActionKindV11::Chunk,
            QuotaActionKindV11::Close,
        ] {
            state.debit(&policy, &epoch, &binding, &plan, &future(&plan, kind)).unwrap();
            assert_eq!(state.network.total().unwrap(), total);
            assert_eq!(state.block.total().unwrap(), total);
            assert_eq!(state.actor(&binding.producer).unwrap().total().unwrap(), total);
            state.check_restored(&policy).unwrap();
        }
        let closed = state.subject(&binding.job_id).unwrap();
        assert!(closed.closed);
        assert_ne!(closed.guarantee_remaining, QuotaQuantitiesV11::default());
        let before = state.clone();
        assert!(state.debit(&policy, &epoch, &binding, &plan, &future(&plan, QuotaActionKindV11::Court)).is_err());
        assert_eq!(state, before);
    }
    #[test]
    fn trusted_equal_daa_blocks_keep_interval_and_lifetime_credit_and_rollback_replays_exactly() {
        let (plan, policy, epoch, binding) = fixture();
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        let ancestor = state.clone();
        let equal_daa = TrustedEpochV11::from_chain(&policy, [62; 64], epoch.block_daa).unwrap();
        let court = future(&plan, QuotaActionKindV11::Court);
        let receipt = state.debit(&policy, &equal_daa, &binding, &plan, &court).unwrap();
        assert_eq!(state.network.total().unwrap(), ancestor.network.total().unwrap());
        assert_eq!(state.subject(&binding.job_id).unwrap().committed, ancestor.subject(&binding.job_id).unwrap().committed);
        assert_eq!(state.block.consumed, court.quantities);
        state.check_restored(&policy).unwrap();
        let descendant = state.clone();
        // Native journal rollback restores the complete ancestor state, never
        // individual quota credits. Replaying the same block reproduces roots.
        state = ancestor.clone();
        assert_eq!(state.debit(&policy, &equal_daa, &binding, &plan, &court).unwrap(), receipt);
        assert_eq!(state, descendant);
        for invalid in [
            TrustedEpochV11::from_chain(&policy, [63; 64], 9).unwrap(),
            TrustedEpochV11::from_chain(&policy, equal_daa.block_hash, 11).unwrap(),
        ] {
            let before = state.clone();
            assert!(state.debit(&policy, &invalid, &binding, &plan, &court).is_err());
            assert_eq!(state, before);
        }
    }
    #[test]
    fn interval_crossing_is_refused_and_rollover_never_rebinds_old_subject() {
        let (plan, policy, epoch, binding) = fixture();
        for deadline in [9, 100, u64::MAX] {
            let mut b = binding.clone();
            b.deadline_daa = deadline;
            let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
            let before = state.clone();
            assert!(state.debit(&policy, &epoch, &b, &plan, &plan.baseline()).is_err());
            assert_eq!(state, before);
        }
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        let old = state.subject(&binding.job_id).unwrap().clone();
        let next = TrustedEpochV11::from_chain(&policy, [64; 64], 100).unwrap();
        let (program, params, _) = primitive_fixture(11);
        let ordinary = derive_ordinary_metadata_v11(&program, &ParamCommitmentsV1::of_v3(&params)).unwrap();
        state.debit_ordinary(&policy, &next, [65; 64], &ordinary).unwrap();
        assert_eq!(state.subject(&binding.job_id).unwrap(), &old);
        assert_eq!(state.network.reserved, QuotaQuantitiesV11::default());
        assert!(state.actor(&binding.producer).is_none());
        state.check_restored(&policy).unwrap();
        let before = state.clone();
        assert!(state.debit(&policy, &next, &binding, &plan, &future(&plan, QuotaActionKindV11::Court)).is_err());
        let mut rebound = binding.clone();
        rebound.admitted_interval = 1;
        rebound.deadline_daa = 199;
        assert!(state.debit(&policy, &next, &rebound, &plan, &plan.baseline()).is_err());
        assert_eq!(state, before);
    }
    #[test]
    fn failed_expensive_attempts_stay_spent_and_oversized_carriers_refuse_before_debit() {
        let (plan, policy, epoch, binding) = fixture();
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        for used in 1..=2 {
            // The native body/court can dismiss this garbage after the prepaid
            // transition; there is no rollback/refund API for that failure.
            state.debit(&policy, &epoch, &binding, &plan, &future(&plan, QuotaActionKindV11::Court)).unwrap();
            assert_eq!(state.subject(&binding.job_id).unwrap().future_attempts_used[3], used);
        }
        let before = state.clone();
        assert!(state.debit(&policy, &epoch, &binding, &plan, &future(&plan, QuotaActionKindV11::Court)).is_err());
        let size = plan.action_carrier_cap(QuotaActionKindV11::Chunk).unwrap();
        assert!(plan.action(QuotaActionKindV11::Chunk, &vec![0; size as usize + 1]).is_err());
        assert_eq!(state, before);
        let record = plan.record();
        assert_eq!(
            record.action_carrier_caps[4],
            record.action_envelopes[4].get(ResourceAxisV10::CourtBytes) as u64 + ACTION_OUTER_ALLOWANCE_V11
        );
        assert!(record.action_carrier_caps[4] < (1 << 20) + ACTION_OUTER_ALLOWANCE_V11);
    }
    #[test]
    fn subject_input_class_actor_and_plan_bindings_cannot_change_or_duplicate_baseline() {
        let (plan, policy, epoch, binding) = fixture();
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        let before = state.clone();
        assert!(state.debit(&policy, &epoch, &binding, &plan, &plan.baseline()).is_err());
        for field in 0..14 {
            let mut bad = binding.clone();
            match field {
                0 => bad.version -= 1,
                1 => bad.policy_root[0] ^= 1,
                2 => bad.class_id[0] ^= 1,
                3 => bad.class_scope9_root[0] ^= 1,
                4 => bad.job_id[0] ^= 1,
                5 => bad.job_input_root[0] ^= 1,
                6 => bad.resource10_root[0] ^= 1,
                7 => bad.quota_plan_root[0] ^= 1,
                8 => bad.actual_positions += 1,
                9 => bad.requester[0] ^= 1,
                10 => bad.producer[0] ^= 1,
                11 => bad.admitted_interval += 1,
                12 => bad.deadline_daa -= 1,
                _ => bad.deadline_daa = 100,
            }
            assert!(state.debit(&policy, &epoch, &bad, &plan, &future(&plan, QuotaActionKindV11::Court)).is_err(), "field {field}");
            assert_eq!(state, before);
        }
    }
    #[test]
    fn duplicate_jobs_and_multiple_actors_share_caps_and_bounded_retained_counts() {
        let (plan, mut policy, _, mut binding) = fixture();
        policy.network = policy.plan.checked_mul(2).unwrap();
        binding.policy_root = policy.root();
        let epoch = TrustedEpochV11::from_chain(&policy, [52; 64], 10).unwrap();
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        let mut other = binding.clone();
        other.job_id = [66; 64];
        other.producer = [67; 64];
        admit(&mut state, &plan, &policy, &epoch, &other);
        assert_eq!(state.network.total().unwrap(), policy.network);
        let mut third = binding.clone();
        third.job_id = [68; 64];
        let before = state.clone();
        assert!(state.debit(&policy, &epoch, &third, &plan, &plan.baseline()).is_err());
        assert_eq!(state, before);
        for limit in 0..2 {
            let mut p = policy.clone();
            if limit == 0 {
                p.max_subjects = 1;
            } else {
                p.max_actors = 1;
            }
            let e = TrustedEpochV11::from_chain(&p, [52; 64], 10).unwrap();
            let mut b = binding.clone();
            b.policy_root = p.root();
            let mut state = QuotaStateV11::new(&p, e.clone()).unwrap();
            admit(&mut state, &plan, &p, &e, &b);
            let before = state.clone();
            let mut second = other.clone();
            second.policy_root = p.root();
            assert!(state.debit(&p, &e, &second, &plan, &plan.baseline()).is_err());
            assert_eq!(state, before);
        }
    }
    #[test]
    fn overflow_fixed_policy_and_restored_guarantee_tampering_refuse_atomically() {
        let (plan, policy, epoch, binding) = fixture();
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        let encoded = borsh::to_vec(&state).unwrap();
        let restored: QuotaStateV11 = borsh::from_slice(&encoded).unwrap();
        restored.check_restored(&policy).unwrap();
        assert_eq!(restored.root(), state.root());
        for field in 0..4 {
            let mut wrong = state.clone();
            match field {
                0 => wrong.network.reserved.0[0] += 1,
                1 => wrong.block.reserved.0[0] += 1,
                2 => wrong.actors.get_mut(&binding.producer).unwrap().reserved.0[0] += 1,
                _ => wrong.subjects.get_mut(&binding.job_id).unwrap().consumed.0[0] -= 1,
            }
            assert!(wrong.check_restored(&policy).is_err());
        }
        let (program, params, _) = primitive_fixture(11);
        let ordinary = derive_ordinary_metadata_v11(&program, &ParamCommitmentsV1::of_v3(&params)).unwrap();
        state.network.consumed.0[ResourceAxisV10::MetadataWork as usize] = u128::MAX;
        let before = state.clone();
        assert!(state.debit_ordinary(&policy, &epoch, binding.producer, &ordinary).is_err());
        assert_eq!(state, before);
        let mut changed_policy = policy.clone();
        changed_policy.network_domain[0] ^= 1;
        assert!(state.debit_ordinary(&changed_policy, &epoch, binding.producer, &ordinary).is_err());
        assert_eq!(state, before);
        changed_policy = policy.clone();
        changed_policy.enabled = false;
        assert!(QuotaStateV11::new(&changed_policy, epoch.clone()).is_err());
        changed_policy = policy;
        changed_policy.future_attempts[0] = u32::MAX;
        assert!(changed_policy.check().is_err());
    }
    #[test]
    fn bounded_snapshot_codec_refuses_count_floods_truncation_duplicates_and_trailing_bytes() {
        let (plan, policy, epoch, binding) = fixture();
        let mut state = QuotaStateV11::new(&policy, epoch.clone()).unwrap();
        admit(&mut state, &plan, &policy, &epoch, &binding);
        let encoded = borsh::to_vec(&state).unwrap();
        assert_eq!(QuotaStateV11::from_bytes(&policy, &encoded).unwrap(), state);
        let actor_count_offset = QUOTA_STATE_FIXED_BYTES_V11 as usize - 8;
        let subject_count_offset = actor_count_offset + 4 + QUOTA_ACTOR_ROW_BYTES_V11 as usize;
        for offset in [actor_count_offset, subject_count_offset] {
            let mut wrong = encoded.clone();
            wrong[offset..offset + 4].copy_from_slice(&u32::MAX.to_le_bytes());
            assert!(QuotaStateV11::from_bytes(&policy, &wrong).is_err());
        }
        for length in [0, actor_count_offset, subject_count_offset, encoded.len() - 1] {
            assert!(QuotaStateV11::from_bytes(&policy, &encoded[..length]).is_err());
        }
        let mut wrong = encoded.clone();
        wrong.push(0);
        assert!(QuotaStateV11::from_bytes(&policy, &wrong).is_err());
        // Two identical actor rows are not a canonical map and cannot hide
        // duplicate resources by BTreeMap's last-write-wins semantics.
        let row_begin = actor_count_offset + 4;
        let row_end = row_begin + QUOTA_ACTOR_ROW_BYTES_V11 as usize;
        let mut duplicate = encoded.clone();
        duplicate[actor_count_offset..actor_count_offset + 4].copy_from_slice(&2u32.to_le_bytes());
        duplicate.splice(row_end..row_end, encoded[row_begin..row_end].iter().copied());
        assert!(QuotaStateV11::from_bytes(&policy, &duplicate).is_err());
    }
}
