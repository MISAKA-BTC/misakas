# Misakaの設計whitepaper — PALW内部閾値beacon 追加設計

**状態: DESIGN_DIRECTION_REQUESTED / DRAFT_NOT_ACTIVATED**

PALW-TB1として、実行入力用EXECとPanel選出用PANELの未来乱数を、PALW内部の完全BGW VSS＋PQ認証私信＋公開share certificateで供給する追加設計です。Panel＋Courtを維持し、BFT台帳finalityとGroth16を追加しません。

## 読む順序

1. `Misaka_Internal_Threshold_Beacon_Design.pdf` — 全20章と参考資料、14ページの設計書。
2. 同名HTML — MathML付きの閲覧用。外部JavaScriptなし。
3. `docs/rfc/0060-palw-internal-threshold-beacon.md` — 実装規範草案。番号は提案です。
4. `docs/adr/0229-palw-internal-threshold-beacon.md` — 選択理由・境界・未有効化。
5. `docs/INTEGRATION_ADDENDUM.md` — 白書とRFC-0055〜0059へ加える文章。
6. `VALIDATION.md` — 実行結果と未検証事項、レビュー反映。
7. `reference/README.md` — 実行可能モデルの使い方と限界。

## 保証の読み方

- `n=3f+1`、私的秘密復元`t=f+1`、公開certificate `q=2f+1`を区別します。
- 一意性は完全VSSと正直holderのshare整合を前提にします。
- 予測不能性の境界は最初の正直share放出です。全員同時受信は保証しません。
- 乱数以外に、故障上限、native安定性、包含、秘密通信・署名・hashの仮定が残ります。
- 原論文の静的モデルを、量子・適応侵害・nativeとの完全な合成保証に置き換えません。
- LLMのGPU時間・電力・金銭費用の下界は、この乱数設計では証明していません。

## 再現

Python 3標準ライブラリでモデルと独立算術検査を動かせます。

```bash
cd reference
python3 test_beacon_model.py
cd ..
python3 reviews/bgw_certificate_check.py
```

29テストと103,152算術ケースは別の検査で、合算しません。`test_vectors.json`は全秘密を公開した決定論的fixtureです。本番暗号・本番鍵ではありません。空batch、batch内consumer別の永続消費、roster抽選、完全BGW、PQ通信、native合意はモデルの未実装範囲です。

## 編集・PDF再生成

編集用LaTeXを同梱しています。主原稿は`source/manuscript.md`、生成scriptは`source/build_design.py`です。scriptはpandoc、reportlab、PyMuPDF、matplotlib、Pillowを使い、同じ原稿からPDF・HTML・TeXを生成します。PDFはLaTeXをcompileした結果ではなく、reportlabによる描画です。編集用TeXはCJK対応XeLaTeX等と指定fontを用意してcompileできます。

## 来歴

原文根拠は`sources/verified_prior_snapshot/SOURCE_MANIFEST.json`に記録しました。今回取得できた旧snapshotを参照した追加設計であり、未取得の最新添付ZIP・改題済みPDFへ直接適用した差分ではありません。既存原本は変更していません。提案番号・wire tag・fenceは最新branchとの照合後に確定する必要があります。

`reviews/`は独立視点による自動設計レビューと算術検査です。人間の専門家による独立暗号監査や本番のセキュリティ認証を受けたという意味ではありません。

表題・header/footerには文書版・日付を付けていません。PALW-TB1等のscheme識別子と、DRAFT_NOT_ACTIVATEDは維持しています。
