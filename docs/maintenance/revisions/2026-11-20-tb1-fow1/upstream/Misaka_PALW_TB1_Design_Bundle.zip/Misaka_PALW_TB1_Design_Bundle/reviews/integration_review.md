# PALW 内部閾値 beacon 追加設計 — 既存仕様との統合レビュー

## 1. 調査した資料と境界

本レビューは実ファイルを読んだ範囲だけを根拠にする。読めた基準は、ワークスペースにある `implementation_audit/source`（添付 `misakas-rfc0055-0059-an1-20261118.zip` の展開先）および `tmp/an1_manuscript.txt` である。

最新ユーザー添付のメタデータには `misaka_docs_latest (2)(1).zip` と `Misaka_Design_Whitepaper.*` があるが、今回の担当時点ではローカルに見つからず、`/mnt/data` も存在しなかった。したがって、このレビューは **最新 ZIP の ADR-0228 / MOR1 本文を再読したと主張しない**。最新版を取得できた場合は、その差分に本メモを重ねる必要がある。

根拠コピーは `beacon_design/sources/verified_prior_snapshot/` にある。`SOURCE_MANIFEST.json` に元パス、サイズ、SHA-256 を記録した。コピー元は変更していない。

## 2. 採択・実装・有効化を区別する

### 2.1 BFT 禁止の原文

根拠: `docs/adr/0180-palw-only-consensus-no-bft-validators.md`「決定」「帰結」。

ADR-0180 は Accepted であり、PALW は BFT validator 集合に finality や reorg の権限を与えない。PoW(DAG)、有用計算、bond、公開証拠による裁定を基礎とし、固定 validator に合意権限を集中させない。claim ごとに選出される検証者の承認と、固定 validator による最終性は区別される。

今回のユーザーは **PALW 内部の新しい閾値 beacon の追加設計**を明示した。したがって、有限期間の share holder に乱数役務だけを与える設計草案を作る権限はある。ただし、この指示は BFT finality、DNS validator、stake による reorg 拒否権、公開 activation を導入する許可ではない。

設計書には少なくとも次を規範として書くべきである。

- share holder はブロックの正当性・canonical fork・Final・credit を投票で決定しない。
- roster / epoch / release descriptor は native の公開規則から導出する。
- 長期間固定した運営者の名簿を無説明で追加しない。参加・選出・交代・bond・役務期限・fault 仮定を明示する。
- 「Byzantine な参加者を許す暗号プロトコル」と「BFT 台帳合意」を混同しない。
- native の stable freeze を支える common-prefix / canonicality は別の前提であり、beacon が代替しない。

### 2.2 PQ-only と無効な BLS 候補

根拠: `docs/rfc/0058-staged-work-commitments-and-consensus-eligibility.md` §1.2、§6.2、`docs/adr/0226-staged-work-commitments-and-consensus-eligibility.md`「凍結原則との境界」。

旧 threshold BLS は **DISABLED** な参照候補である。BLS の一意性をそのまま現在の PALW 保証に読み替えない。ML-DSA で外側を署名しても、BLS の予測不能性が耐量子化するわけではない。

今回の設計は PQ-compatible な秘密分散・秘匿通信・認証・公開復元の具体方式を選ぶか、明示的な未完成暗号 gate を残す必要がある。普通の BLS DKG を本番案として採用済みにするのは、ユーザーが指示していない PQ 例外を追加することになる。

### 2.3 Panel + Court を維持

根拠: `docs/rfc/0059-palw-an1-input-binding-and-panel-court.md` §0、§8–10、`docs/adr/0227-palw-an1-input-binding-and-panel-court.md`「判断」。

新しい beacon の認証と、LLM 実行の正当性は別機能である。Panel の全再実行、モデル非保有 Node の有界局所裁定、単独有効反証の優先、資料 case 未解決中の成功停止を維持する。beacon の多数 share を LLM 正当性承認へ流用しない。

## 3. AN1 の乱数は二種類である

根拠: RFC-0059 §4、§5、RFC-0058 §16.4、RFC-0056 §17.1–17.2。

| 目的 | 乱数より前に固定するもの | 乱数に依存するもの |
| --- | --- | --- |
| 実行入力用 `R_exec` / `sigma` | owner、全 nonce 候補、model/job/profile、target、会計・容量・期限、登録集合 | `s = H_attempt(Enc(C,sigma))`、正規実 token 入力、実行結果と trace |
| Panel 選出用 `R_panel` | Miner の署名済み元 claim / 三 Root、受理集合、pool snapshot、抽選規則・義務・期限 | Panel 抽選、必要に応じた個人 challenge |

AN1 の Ticket は `H_ticket(Enc(s,Rx,Ry,Rtau))`。旧 SWC1 の第三の `R_ticket` を AN1 に重ねない。実行 seed の domain を変えて Panel seed を作っても、実行 seed 公開後の未来未知性は得られない。

### 3.1 循環参照を避ける

RFC-0059 §2.2 は、C / RegKey 自体を leaf に含む freeze root を同じ C へ戻してはならないと規定する。新しい descriptor でも同じである。

推奨の型分離は、事前登録で `beacon_scheme / schedule / logical_round / roster_epoch` を固定し、登録集合閉鎖後の `FreezeId / closed_set_root` を native の独立 record として束縛すること。未知の実 seed、未生成 trace Root、当該 C を含む集合 Root を C の生成に要求しない。

### 3.2 一般公開時刻だけでは不十分

RFC-0059 §4 の要求は、攻撃者が最初に beacon を得る時点より前の freeze である。ユーザーが求める新方式には、公開予定時刻より早い share 収集、共謀、秘密通信漏洩、snapshot fork を含む earliest-access 境界が必要。

実行用と Panel 用の seed を同時に復元可能な一つの事前秘密から出す場合、実行用公開後に Panel 用も分かる経路を排除しなければならない。単なる domain 分離をその証明にしてはならない。

## 4. 必須の接続箇所

| 文書 | 既存の節 | 追加すべき内容 |
| --- | --- | --- |
| RFC-0055 | 共通資源・calendar・保護された control / negative 容量 | beacon 配布、secret-share 配送、complaint、recovery、終端、保持、native journal の上界。既受理 Court の予約を食い潰さない |
| RFC-0056 | §17.1–17.3、§17.6 | 2つの正式な beacon ref、release 前 freeze、認証成功時のみ入力導出 / Panel 選出、最早 / 最遅 release、Unavailable の定義、共通 TimingPlan |
| RFC-0057 | §4、§5、§17 | PositiveNonce は正規 Panel seed 全体へ結合。ActionNonce / negative / 資料要求 / 応答 / 終端に新 beacon 待ちを追加しない |
| RFC-0058 | §6、§16.4 | 新方式が満たす能力契約を新 RFC 参照として追加。旧 BLS DISABLED の履歴は残す。AN1 には §16 の2段階だけを適用 |
| RFC-0059 | §2、§4、§10、§15 | concrete beacon scheme と descriptor、native release gate、2つの独立 secret、失敗終端、reorg / import 境界、activation 証拠 |
| ADR-0180 | 採択済み原文の履歴 | 原文の上書き不要。新 ADR で「乱数役務に限定し finality / reorg 権限を与えない」と接続 |
| ADR-0185 | paid checker / opt-in seal-reveal の scope | 旧 route は drain / 履歴互換を維持。新 AN1 beacon の自動 fallback にしない |
| ADR-0226 | 無効な BLS 候補 | 新 ADR で具体的に置き換える範囲を宣言。BFT / PQ 例外採択済みとしない |
| ADR-0227 | AN1 と2つの freeze | 新規 beacon の scheme だけを追加。Panel / Court、入力、費用定理の境界は維持 |
| 白書 | 旧稿第2、4、14、16、18章 | 登録 ref、時系列図、条件付き予測不能性、閾値と corruption budget、不可避な停止 / 先行取得、activation gate を具体化 |

### 4.1 native ref の幅を保持

RFC-0057 §4 は既存 native beacon digest が 64 bytes であることと、CPN1 自作 H256 が 32 bytes であることを区別している。新 32-byte seed を使うなら新しい型・codec として登録する。旧 64-byte seed を先頭32bytesへ黙って切り詰める adapter にしない。

### 4.2 救済を乱数停止に巻き込まない

RFC-0056 §17.3、RFC-0057 §4 / §17、RFC-0059 §8.2 は、新規受理が止まっても既受理 negative、資料要求、応答、終端を元予約と原期限で処理することを要求する。新閾値 beacon が止まった際に、これらまで新しい D / Ticket / seed / ExecCredit を待たせる設計は不適合。

### 4.3 reorg と branch の扱い

RFC-0058 §6.3 と RFC-0059 §10 は、stable-control-anchor を未検証の対象仕事へ循環依存させず、noncanonical になった stage の成功再使用を禁止する。既知 seed へ新しい登録集合や Panel pool を結合して再開してはならない。

新方式には、share release 以降に秘密を「未公開」に戻せないこと、正規 reorg の DB undo と実世界の情報漏洩は異なることを追記すべき。secret を一度公開した後にその round を別 freeze へ再割当することは禁止する。制約を跨ぐ reorg は新規仕事を停止し、明示した未成功終端 / recovery 規則を使う。

## 5. 既存 seal-reveal を新方式と誤認しない

ADR-0185 の scope は RFC-0007 paid claim checker lock と、追記された v4/v5 opt-in / Panel v5 beacon である。source の Final を待たない sealed commitment を使い、withheld / forfeited は veto、source 不足は Unavailable としている。

最初の固定 seed bootstrap は予測可能であり、その claim は EXEC credit を得ない。これは新 AN1 用の「予測不能な genesis beacon」が完成している証拠ではない。

同 ADR に「少なくとも一つ honest source」「withholding は attempt 全体の veto」とあるが、本レビューはそれを最新方式の無条件 unbiasedness 定理へ拡張しない。output-conditioned abort と retry の扱いは別に分析が必要。

新方式の bootstrap は、初回 roster と initial randomness の trust assumption を明記する必要がある。初回の roster を自分が生成する未知乱数で選ぶ循環や、許可されていない外部 beacon への依存を作らない。

## 6. 番号監査

読み込めた `implementation_audit/source/docs/rfc/` には RFC-0059 まで、`docs/adr/` には ADR-0227 までの主文書がある。RFC-0060 / ADR-0229 の主パスはこの snapshot 内には存在しない。

ただし会話上の最新情報は ADR-0228（MOR1）を含む。これは最新 ZIP が未取得のため今回再読していない。したがって **RFC-0060 / ADR-0229 は提案番号**として使うのが安全であり、最新 ZIP / 外部 branch / remote の衝突がないと断言しない。今回成果物で wire tag、fence、高さ、runtime enum の番号を RFC 番号から自動割当しない。

現行入口 RFC-v2 20本 / ADR-v2 50本は旧資料内では固定の統合体系である。新設計は後続 RFC / ADR として追加し、既存番号を再利用・削除・再採番しない。

## 7. 承認の扱い

`docs/governance/design-freeze.md` は新 RFC + ADR による変更記録を要求する。今回の「新閾値 beacon を導入する方針で追加設計して」というユーザー指示は、具体的な提案を作る十分な根拠であり、作成前に同じ許可を聞き直す理由はない。

一方、初めて書く暗号方式の正式採択・完全実装・公開 activation を成功扱いにしない。提出する新文書の状態は、例えば **DESIGN_DIRECTION_REQUESTED / DRAFT_NOT_ACTIVATED** とし、実装・性能・障害注入・独立暗号監査・native 統合の gate を示す。

## 8. 設計完成時の整合確認リスト

1. 実行用 / Panel 用の独立した未知秘密、用途・round・freeze の型と因果順序が明示されている。
2. share holder が台帳 finality を決めず、native が一意に認証できる。
3. roster / corrupt threshold / withholding / adaptive corruption / key refresh / erasure の前提が本文と定理で一致する。
4. DKG / share 配布の未解決問題を「BFT不使用」の一言で隠さない。
5. 別 key、別 round、別 roster、別 subset、別 freeze、同一秘密の別 domain による retry 経路がない。
6. 原 deadline と予約、2つの freeze、既受理 negative の進行を保持する。
7. 旧 BLS と seal-reveal の履歴と実装状況を新保証へ読み替えない。
8. toy test と production cryptographic implementation / PQ security proof / native deployment を区別する。
9. 乱数の安全性から LLM 費用下界、全 Panel の本人労働、DAG common prefix を導かない。

