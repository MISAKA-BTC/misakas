# PALW-TB1 主稿 最終プロトコル査読

対象：`beacon_design/manuscript.md`。本文は変更していない。

## 判定

**追加設計草案としての公開を妨げる致命的な論理矛盾は確認しなかった。**

本番有効化は依然不可。草案自身が列挙するBGW実装、native broadcast・時刻・安定化の写像、PQ合成、適応侵害評価、通信・容量計測は未完である。以下の「有効化を阻止する条件」は、その未完を撤回してよいという意味ではない。

## A. 重要な点が適切に記載されている

- EXECとPANELは別secret、多項式、私信session、公開share、release gateを用いる。EXECのdomain再hashを未来乱数としない。
- 最初の正直share受信が予測不能性の境界であることを明記している。t=f+1における先行復元を隠していない。
- Full BGW VSSを前提として、q=2f+1点certificateの一意性を、異なるdegree-f多項式の一致点数から正しく説明している。
- holderは自分のshare値へ署名し、最初の候補polyへの投票を固定しない。
- Q全体を復元し、dealer除外、旧seed、block hash、旧seal-reveal、別roundへのsilent fallbackを禁止している。
- staticとadaptive/mobile、BFT台帳権限とByzantine-tolerant秘密分散、正常な停止と公開出力の条件付きbiasを分けている。
- bootstrap rosterの信頼条件、lotのSybil限界、追加offline余裕が無い最悪ケース、公開済み情報とundoの非対称性を明記している。
- current beaconを要求するcontrol carrierに同じbeaconを必須とする循環を禁止している。
- 本番実装・暗号・native進行を検査モデルで検証したと表示していない。

## B. 草案公開前に推奨する改善

### B1. 空batchと次roster選出の動作を明記

第6節では前epoch PANEL値を次roster選出へ再利用する。第9節ではOriginal集合のfreeze後にPANELを公開する。Originalが0件の場合でも、予定時刻にcanonicalな空集合をfreezeし、必要なEXEC前提を満たす通常roundならPANELを公開する、と明示すると曖昧さがなくなる。そうしないと、無取引期間に次rosterの選出まで止まる実装を誘発する。

推奨追記：『Originalが0件でも予定された閉鎖を実行し、空集合を一意に符号化する。準備・前段・native安定化等の条件を満たすscheduled PANEL roundは、consumer数に依存せず公開する。前段不成立時は既定の失敗・recovery規則に従い、別seedを代用しない。』

### B2. `CONSUMED` とbatch共有を整合させる

第7節では一つのroundを多数claimで共有するが、第14節の単一状態 `CONSUMED` は一回利用でround全体を消費する実装とも読める。

推奨追記：『各consumerの使用は、freeze済みconsumer IDごとの使用記録と元slotの原子的消費で管理する。最初のconsumerが乱数を使った時点で他のfreeze済みconsumerを拒否しない。roundのCONSUMEDは規定の対象処理・保存状態の終了を表す。新consumerの後付けは不可。』

### B3. 検査件数を最終resultsに同期

査読時点で `test_beacon_model.py` に第29テストが追加され、本文は28件のままだった。最終実行結果・README・白書・RFC付属説明を同じ値へ揃える。175/21は内部検査として別テスト件数に合算しない現在の説明を維持する。

### B4. 検査モデルの認証fixtureの強さを明記

モデルのauth fixtureは全正当shareのdigestを知っており、本番で腐敗holderが偽shareへ有効署名できる状況より強い。現在の『本番暗号ではない』という注意は適切だが、偽poly拒否のテストをq点安全性そのものの実証として読ませない方がよい。

可能なら、f個の任意の有効認証点を許しても偽polyがq個の支持を集められない最大一致例を別に検査する。これは任意多項式に対する数学的証明の代用ではない。未追加でも、現fixtureの範囲が明記されていれば草案公開の妨げにはならない。

### B5. Readyのtranscript rootの範囲

第8節の『完全な公開transcript』は、Ready自身を含む自己参照rootではなく、VSSの完了までのcanonical record集合であることをwire仕様で固定する。QualRootがReady集合を含める場合も、VSS transcript rootとの階層を分ける。現文章は自然に解釈できるが、実装時の一意性のため明文化が望ましい。

## C. 有効化を阻止する条件（草案の既存gateを維持）

### C1. native broadcast / 同期 / phase closure

原典Protocol 5.6は同期したprivate channelとauthenticated broadcastのモデルで論じられている。PALWのnative recordへ写像する際、正直者が同じphase受付集合、欠落、期限、確定transcriptを認識する契約が未実装なら、Full VSSの定理を適用できない。署名だけでbroadcastを実装したことにしない。現在の第8・9・16・18節が適切に未完条件としている。

### C2. malformed messageの写像

原典の内部手順には高次多項式のtruncation等がある。一方、wire codecは非canonical値や過大recordを拒否する。外側のcodec拒否を、内部VSSのどのmissing/invalid-message分岐へ写像するかは明確にする必要がある。『原典の全分岐を採用』だけで、異なるネットワーク異常処理まで自動的に証明されたとはしない。

### C3. private-to-publicのprivacy

complaintや訂正で公開してよい情報を原典に限定する。過大recordや欠落の救済のためにhonest row/columnを追加公開する改変は、未来seedを早期に復元できる原因になる。悪意fのモデルで、honest dealerの材料が実装上追加漏洩しないことを負例と全分岐で確認する必要がある。

### C4. fork / reorg / cold import

深いreorg後のローカル曝露journalだけでは、新規Nodeが過去の秘密流出を知る保証を得ない。現在の第15節がこの点を明示している。エポック停止範囲・再開nativeイベント・新材料・新登録の手続が未定義なら再開を有効にしない。既知seedを新対象に再利用する救済は禁止を維持する。

### C5. control進行の独立性と資金終端

予約されたcontrol recordの形式だけでchain growthは得られない。旧経路をdrainし新beaconを停止した状態でも、VSS phase・share・case・取消を運ぶcarrierが成立し、期限内包含可能であることを既存nativeに対して検証する。native自体が止まった時、壁時計だけで返金が確実に行えるとも書かない。現稿はそのような確実性を主張していない。

## D. 確認した一次資料

Asharov–Lindell, ECCC TR11-036 rev5、Protocol 5.6、Theorem 5.7、同期channel・静的悪意者モデル、および§6.2の並行VSSに関する注意を一次PDFで確認した。

URL: https://eccc.weizmann.ac.il/report/2011/036/revision/5/download/

参照取得: `turn986824273view0`, `turn256045362view0`, `turn498847455view0`。

本レビューは本稿のプロトコル構造・説明上の境界を確認したものであり、完全な新しい暗号合成証明や本番実装監査を行ったものではない。
