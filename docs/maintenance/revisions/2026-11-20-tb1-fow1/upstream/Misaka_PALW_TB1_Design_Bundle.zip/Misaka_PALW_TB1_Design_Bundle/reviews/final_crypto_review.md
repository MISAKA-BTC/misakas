# PALW-TB1 主稿の最終暗号レビュー

対象: `beacon_design/manuscript.md`、20章の主稿。主稿は直接変更していない。

## 総合判定

**DRAFT_NOT_ACTIVATEDの追加設計書として、採用方向と条件付きの一意性論証は整合する。直ちに破綻する数学的矛盾は確認していない。** 本番実装・有効化の判定ではない。下記H1は過剰な定理表示を避けるため本文を補強することを推奨する。未実装のVSS/native写像、量子・適応・並行合成は、本文が既に指定した有効化gateとして維持する。

## Blocking

### B0 — この草案の公表を止める数学上の欠陥は未発見

この判定は「乱数予測問題が無条件に解決」「実装可能性を完全検証」「本番安全」と同義ではない。基礎となるVSS、秘密通信、nativeの共通履歴、roster腐敗上限を外した安全性は成立しない。

## High

### H1 — §12.3のε_modelは、具体的な安全性定理との区別を強くする

現式 `Pr[Guess(sigma)] <= 2^-256 + epsilon_model` は、epsilonに全問題が含まれる。本文は無条件・量子の定理でないと注意しており誤った断定には至っていないが、「利得を各要素の失敗確率へ帰着する」という説明だけでは実際のreductionを示したようにも読める。

推奨する補強:

- これは実装済みTB1-BGW-PQの具体的security boundではなく、満たすべき合成contract／理想モデルでの条件付き形式であると明記する。
- 暗号のdistinguishing advantageと、native／roster等のbad-event確率を区別する。
- 理想的な秘密channel、完全BGW、正直dealerの一様なF_p上の秘密、独立した古典random oracleを仮定する場合、未知secretを含む出力入力を先に照会する項をq_H/pの形で別に示せる。ただしrushing、固定Q、公開前の全view、session合成を含む実験を定義する必要がある。
- これをQROMへ同じ式で流用しない。実際のSHAKE256、ML-KEM、ML-DSA、AEAD、nativeとの合成は未認定とする。

### H2 — 準備時timeoutのprivacyは実装gateとして確実に保持する

§8の「欠落と不一致の区別」「便宜全公開禁止」は重要であり正しい。原典の同期private-channel実験からnative phaseへの写像はまだ仕様レベルである。未取得資料を0等へ置換して不一致申告を行い、正直dealerに正直recipientの行・列を公開させる経路を許してはならない。

本文はこの義務を既に明示しているので、草案のblockingとはしない。将来「全てfail closedだから通信条件不要」と短縮しないこと。complete BGWに任意のtimeoutや省略を追加した版は、原典の定理そのものではない。

## Clarification

### C1 — §14の不正shareの客観証拠

署名付きshare方式では、個々のshareにPVSS復号proofはない。他holderとの相違、または最初のt点から導いた候補多項式から外れるだけでは不正と断定できない。

slash根拠は、同じ文脈・同indexでの二重署名、または成立したq点certificateの多項式との不一致を示す署名付きshare等に限定するとよい。最後までcertificateが成立しない状況で候補多項式に反対したpartyを罰してはならない。

### C2 — CSPRNGと完全一様分布

§5の「CSPRNGから独立一様」は実装目標としては分かるが、厳密には一様な乱数テープの理想モデルと、CSPRNGを使う実装の擬似乱数仮定を分ける。一様なbit列に対するrejection samplingは有限体への剰余偏りを除去するが、低entropyのseedを高entropyへ変えるものではない。§12.1のentropy／合成仮定に接続するとよい。

### C3 — transcript rootとReadyの意味

§8でReadyが完全VSSの代用品でないと明記した点は適切である。q件のReadyを束ねる際は、同一の最終phase-close、Q候補、公開transcript、suite、rosterが識別子へ入ることが重要。個々のholderのローカル受信完了をnativeの共通phase完了と混同しない。

### C4 — 統合試験の対象範囲

§19のfixtureは、正しいshare値を事前に知るhash認証として実装されているため、最大f人が自分の正しい鍵で偽値を署名する能力を直接再現しない。独立した有限体検査 `reviews/bgw_certificate_check.py` がこの数学的境界を補う。103,152ケースの結果はBGW／PQ／ネットワークの成功件数に加算せず、補間・公開定足数の検査として別記する。

## 合格と判断した中核点

1. **閾値の分離:** n=64,f=21,t=22,q=43はn=3f+1に整合する。公開認証qは私的復元時刻を遅くしないことを明記している。
2. **有限体:** p=2^521−1、66byte固定、値域0<=x<pというcodecは一貫する。t=f+1係数の次数f多項式に対する一意性を使える。
3. **偽多項式排除:** 真多項式と異なるdegree<=f候補は高々f個の正直点とf個の悪性点しか集められず、2f<qで拒否できる。
4. **Q:** 完全VSSが終了し正直shareが揃ったdealerを公開前に固定し、全Qを復元する。last dealerによる公開拒否でsubset乱数へ切り替えない。
5. **二つの未来性:** EXECとPANELに独立の秘密材料を用い、各用途の最初の正直shareより前にconsumer文脈を固定する。既知seedの再hashを未来乱数と扱っていない。
6. **同期差:** 正式受理までの一様な秘匿や全員同時受信を主張していない。
7. **BFT境界:** holderにcanonical fork／claim Finalの投票権を与えず、native broadcastの安定性を別仮定にしている。
8. **循環:** control carrierが生成中のbeaconや未発行AN1 creditを必要としないことを規定し、native自体のchain-growth証明とは区別している。
9. **static/adaptive:** 原典の適応安全性の訂正を踏まえ、static theoremからmobile securityを導いていない。
10. **PQ:** BLSを排除し、情報理論的VSSとPQ通信・認証を区別する。本番の耐量子合成を完成済みとしていない。
11. **情報はundoできない:** 深いreorgと既知秘密をfail closedの表現だけで解決したとせず、cold importの限界まで記載している。
12. **原典と新設計:** 参考資料末尾で、PALW識別子・公開順序・q点certificate・移行は本追加設計であることを明記している。

## 文献確認の限界

原典BGWのProtocol 5.6、刊行版§5.4／§6.2とNotes1を確認した。原典のVSSの完全証明を再証明したレビューではない。特定のPQ channel実装、native consensus、randomness generation機器を監査していない。格子PVSS探索結果は本稿の主定理の根拠にはしていない。
