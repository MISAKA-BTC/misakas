# 検証・レビュー・未実装境界

## 1. 実行した検査

| 対象 | 結果 | 実際の範囲 |
| --- | --- | --- |
| Python参照モデル | 29 tests PASS、失敗0・エラー0 | 状態機械、canonical context、有限体補間、q点certificate、失敗終端 |
| 閾値補間 | 5 dealer × 35 subset = 175通りで一致 | 上記29テスト内部。別件数へ加算しない |
| 5-of-7公開certificate | 21 subsetで同出力 | 上記29テスト内部。別件数へ加算しない |
| 独立多項式検査 | 103,152ケース、偽poly支持最大4 | 有限体17、f=2、q=5。不正holderは偽値へ有効署名できると仮定 |
| qを4へ下げた境界 | 偽certificateを許す反例を確認 | 正しいqの必要性を調べる算術例 |
| PDF | 14ページ、9種類の数式、描画エラー0 | 全ページを描画して配置確認。最終変更の参照ページも再確認 |
| ページ境界 | 本文・画像のページ外bboxなし | 自動補助検査。目視を代替しない |
| PDF表題・metadata | 表題一致、可視版・日付なし、有効なCreationDate/ModDateは空 | scheme名とDRAFT_NOT_ACTIVATEDは維持 |

検査結果のJSONとコードhashは`reference/results.json`、公開fixtureは`reference/test_vectors.json`、独立算術結果は`reviews/bgw_certificate_check.json`、PDF生成結果は`verification/`にあります。

## 2. 数学的検査の限界

主モデルの認証fixtureは、全ての秘密と正当shareを知る生成器を使っています。誤値を本人の正しい署名で出す悪意holderの能力を再現しません。独立算術scriptではその能力を認め、偽多項式と全腐敗集合を列挙してq点境界を確認します。

両方とも、完全BGW、ML-KEM、ML-DSA、量子安全性、適応侵害、real RNG、実ネットワーク、native consensus、DB journal、実LLMを検証していません。テスト件数を合算して安全性の強さを表現しません。

## 3. レビューで発見・反映した点

| 指摘 | 最終処理 |
| --- | --- |
| 公式発表前にf share＋一つの正直shareで先行復元可能 | freezeを最初の正直share放出より前に安定化。実行窓も最遅配信から予約 |
| qによるcertificate一意性を単なる集合交差で説明できない | 真Pと偽Pの一致点数の上界で論証 |
| 最初に一致した候補polyへの投票ロックが活性を壊す | holderは自身のshareだけを署名し、候補への投票をしない |
| 元参照モデルが秘密の剰余和をhashしていた | 全dealer列のcanonical encode→SHAKE256へ修正。第29回帰テストを追加 |
| epsilon_modelが未完の合成を隠す恐れ | 実suiteの証明ではなく条件付きcontractと明記。古典ideal RO説明と量子未完を区別 |
| VSS timeout改変による秘密漏洩 | 欠落と不一致の分離、便宜公開禁止、完全VSS/native対応をactivation gate化 |
| 不正shareの早計なslash | 二重署名または成立済みq点certificateとの矛盾に限定 |
| Ready rootが自分を含む循環 | VSS終了までのrootとphase anchorを署名し、Ready/QualRoot/Freezeを除外 |
| 空Original batchで次rosterが止まる | 予定された空集合freezeによるPANEL公開を規定 |
| batch共有とCONSUMEDの衝突 | consumer/slot別の一回性と全batch終端を分離 |
| CSPRNGと理想一様性の混同 | entropy仮定とrejection samplingの役割を分離 |

`final_crypto_review.md`と`final_protocol_review.md`は修正前の指摘を残す監査記録であり、現文書に未反映という意味ではありません。

## 4. 未完成の本番gate

1. 完全BGWの私信・交点検査・complaint・訂正・終了の実装、およびnative phaseへの安全な写像。
2. PQ認証私信、署名、suite/codec、鍵確認、nonce永続化、実wire vectors。
3. 静的な基礎定理から対象の量子・適応・並行・nativeモデルへの合成評価。
4. native stable freeze、包含、深いreorg、曝露journal、cold import、DB並行性。
5. roster支配率・bootstrap・担保と容量、攻撃下性能、空batchとconsumer別一回性の本番実装。
6. 全AN1 consumerとPanel/Court、資金・予約・終端、旧方式のdrain。
7. 独立した人間の暗号監査、実ネットワーク障害試験、正式な採番・fence・有効化判断。

既存repository全体のcheckerやRust buildを今回実行したとは主張しません。原本repositoryは変更していません。
