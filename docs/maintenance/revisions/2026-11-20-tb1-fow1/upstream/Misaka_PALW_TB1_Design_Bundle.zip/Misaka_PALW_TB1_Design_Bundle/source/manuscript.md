---
title: "Misakaの設計whitepaper"
subtitle: "PALW内部閾値beacon 追加設計書"
lang: ja
date: ""
---

# 1. 設計判断と到達点

本追加設計は **PALW-TB1** を導入し、PALW-AN1で必要な二種類の未来乱数を、PALW内部の参加者が生成する。実行入力用をEXEC、Panel選出用をPANELと呼ぶ。両者には独立した秘密材料、別の公開条件、変更不能な用途割当を与える。BFT validator、DNS-final、閾値署名による台帳の最終化は追加しない。LLM実行の検証はPanelの完全再実行とCourtの局所反証を維持する。

主方式は、完全なBGW型の検証可能秘密分散（VSS）、耐量子の認証・秘匿通信、署名付きshareによる公開復元証明の組合せである。長期BLS鍵は使わない。各roundで新しい秘密を分散するため、長期閾値署名鍵のDKGを実装したという意味でもない。

状態は **DESIGN_DIRECTION_REQUESTED / DRAFT_NOT_ACTIVATED** とする。今回完成したものは具体的な追加仕様、条件付きの論証、RFC・ADR草案、攻撃経路の検査モデルである。本番BGW実装、nativeへの統合、通信・合意の成立、耐量子の合成証明を完成済みと表示しない。

設計上の中心的な保証は、必要な文脈をfreezeした後に初めて正直な参加者が復元情報を放出し、freezeより前の乱数予測を明示した故障・暗号・通信モデルの下で防ぐことである。世界の全員が同時刻に乱数を知る保証、閾値以上の共謀を防ぐ保証、通常LLMと同額の実費を強制する保証は別問題である。

| 判断 | 今回の規定 |
| --- | --- |
| 未来乱数 | EXECとPANELの二種類。AN1へ第三のTicket乱数を追加しない |
| 生成主体 | PALW native規則で固定・交代する有限期間のshare保持者 |
| 中核暗号 | BGW VSSの完全手順、PQ認証私信、公開されたshare点の整合検査 |
| 受理根拠 | 同じ多項式に乗る十分な署名付き点。BFTのFinal投票ではない |
| 故障時 | 元roundの未成功終端。既知seedや別roundへの自動置換は禁止 |
| 実装状態 | 状態機械と有限体の検査モデルのみ実行済み。本番暗号・nativeは未実装 |

\newpage

# 2. 二種類の未来乱数と固定対象

| 乱数 | 最初の正直share公開前に固定する対象 | 公開後に行う処理 |
| --- | --- | --- |
| EXEC | owner、全nonce候補、model/job/profile、difficulty、会計・容量・原期限、登録集合、EXEC/PANELのround参照 | 正規入力導出、LLM実行、出力・trace commitment、Ticket |
| PANEL | Miner署名済みOriginal、受理済みclaim集合、候補poolと重み、抽選規則、担当数・義務・原期限 | Panelの選出、個別challengeの導出 |

EXECとPANELは同じ保持者集合を使ってもよい。ただし、秘密、多項式、私信session、公開share、round IDを共有しない。正直dealerは各用途の秘密と係数を独立に生成する。EXECの秘密を公開してもPANELの秘密が導けないことを、個々のhash値が異なるという観測で代用しない。

公開されたEXEC値を別domainでhashしても、PANELの未来未知性は得られない。domain分離は誤用・混線の防止であり、新しいentropyの供給ではない。PANEL roundは登録時のTimingPlanで決め、実行結果やPanel候補を見て選び直さない。

AN1の基本式は維持する。ここでCは事前登録した文脈、Jはjob、MとPはモデルと決定論的profileである。

$$s=H_{\mathrm{attempt}}(\mathrm{Enc}(C,\sigma_E))$$

$$x=\mathrm{InputDerive}(s,J),\qquad (y,\tau)=\mathrm{Exec}_{M,P}(x)$$

$$T=H_{\mathrm{ticket}}(\mathrm{Enc}(s,R_x,R_y,R_\tau))$$

Panelの選出は別の値を用いる。

$$\mathrm{Panel}=\mathrm{Select}(\sigma_P,\mathrm{OriginalId},\mathrm{PoolRoot},\mathrm{RuleId})$$

再署名・再包装・share証明の並べ替えから新しいTicketやPanel抽選を発生させない。仕事の一回性、slotと実計算キー等の原子的消費はRFC-0059の規則を継承する。[D3]

# 3. BFT非依存の意味と残る信頼境界

share保持者には、乱数材料の配布・検査・保持・公開という役務だけを与える。ブロックの正当性、canonical fork、reorg、claimのFinal、credit発行を投票で決める権限は与えない。BGW VSS内部の整合処理は、悪意ある参加者を扱う秘密分散プロトコルであり、新しいBFT台帳合意を導入するものではない。

一方、悪意参加者の上限、認証された私信、正直者が同じ公開記録を見る性質は必要である。native DAGが提供する安定した履歴と期限内包含をbroadcastの基盤として使う。これらをbeacon自身が証明したり、beacon委員の多数決で補ったりしない。

既存のBFT廃止方針、PQ-only、Panel＋Courtは維持する。今回ユーザーが指示した追加設計は、乱数役務に限る保持者集合の仕様化を認めるものであり、外部公開activationや未検証の本番導入を完了と扱う根拠ではない。[D1][D2][D3]

# 4. 故障モデルと二つの閾値

最初のprofileは、保持者数と故障予算を次の関係に固定する。

$$n=3f+1,\qquad t=f+1,\qquad q=n-f=2f+1$$

| 記号 | 意味 |
| --- | --- |
| n | round開始前に固定された保持者slot数 |
| f | 誤動作、秘密漏洩、停止を含む故障slotの総予算 |
| t | 正しいshareから秘密を私的に復元できる最小数 |
| q | 公開certificateで必要な、同じ多項式上の署名付きshare数 |
| Q | 準備完了したdealerの固定集合。件数はq以上 |

検査モデルはn=7、f=2、t=3、q=5を用いる。容量設計の例はn=64、f=21、t=22、q=43とする。64という値は本番の安全性・性能を実証した設定ではなく、profile採択時に容量と故障確率を評価する例である。

故障予算を、悪意f人に加えて別途何人でも正直offlineを許す予算として解釈しない。最悪ケースでf人全員が公開を拒否すると、残るn−f人の応答が必要になる。同一運営者や同一障害ドメインが複数slotを持つ場合、全slotを故障数へ数える。

基礎の条件付き論証は、batch開始前に腐敗集合が固定された静的な悪意者を対象にする。順番に端末を侵害するmobile/adaptive攻撃は別の証明義務である。瞬間の侵害数ではなく秘密保護期間全体の累積侵害を制限する運用が必要だが、その制限を書くだけで完全な適応安全性が証明されたことにはしない。原論文にも効率的simulationを伴う適応安全性について注意がある。[R1][R2]

# 5. 暗号suiteとcanonicalな値

本仕様の基礎suite名をTB1-BGW-PQとする。新たな離散対数・pairing仮定やtrusted CRSを必要とする構成を中核に置かない。耐量子という目標は、秘密分散の性質、通信暗号、署名、hash、合成のそれぞれについて評価する。

| 要素 | 草案の選択・拘束 |
| --- | --- |
| 有限体 | 素数p=2の521乗−1上の体。要素は66byteのbig-endian、0以上p未満。非canonical値を拒否 |
| 秘密と係数 | 理想では独立一様。実装は適切なentropyでseedしたCSPRNGとrejection sampling。CSPRNGの安全性を別途仮定 |
| VSS | Asharov–Lindell改訂版の§5、Protocol 5.6を省略せず採用。単なるShamir配布には置換しない |
| 認証 | ML-DSA-65。公開鍵登録、所有証明、context付き署名、長さ・正規符号化検査 |
| 私信 | ML-KEM-768に認証・鍵確認・contextを結合した暗号channelとAES-256-GCM。KEMだけで認証済みとしない |
| digest | 新TB1構造のcommitment/context digestはSHA3-512、64byte |
| 公開乱数 | 固定された全秘密列を入力とするSHAKE256の32byte出力 |
| 実行権限 | 暗号suite、codec、resource profile、wire tag、fenceの組を有効化前に固定 |

ML-KEMは鍵確立、ML-DSAは署名の標準であり、それら単独でVSSの整合性や閾値beaconを提供するわけではない。[R3][R4] transportは通信相手・purpose・round・送受信方向・sequenceを認証し、nonce再利用、再起動時のcounter巻戻し、別sessionのciphertext再利用を拒否する。実装スイートは標準の訂正情報を含め別途固定する。

rejection samplingは剰余偏りを除くが、元seedのentropyを増やさない。正直者のentropy源・RNG状態の保護と、理想的一様乱数から実装への移行を区別する。

公開の乱数値は32byte、新TB1のcontext参照は64byteとして別の型を定める。既存の64byte beacon値や参照を先頭32byteへ黙って切り詰めない。旧AN1の256bit attempt IDはそのまま使用可能だが、新BeaconRefを含む正規codecをprofileとして新規登録する。[D2][D3]

codecは固定長整数、長さ付きbyte列、tag付き構造、規定順序のvectorを使う。float、boolの整数扱い、数値文字列、重複key、無制限配列、無意味な末尾byte、可変なfield符号化を拒否する。署名は完全なcanonical messageへ掛ける。hash入力をJSON文字列連結で作らない。

# 6. 保持者の登録・選出・交代

参加者はnativeに役務leaseを登録する。leaseにはowner、ML-DSA鍵、目的別の通信鍵、担保lot、役務期限、容量約束、鍵所有証明を含める。担保lotの二重使用を拒否する。過去のPALW実績を参加条件に用いても、実績が通常LLMの実費を証明するという前提は置かない。

運用候補は、固定額の担保lotごとの抽選ticketを使い、nativeで固定したticket集合から重複なしでn slotを抽選する方式とする。アドレスを分割しても、同じ担保からticket数を増やせない。一人の実主体が多数lotを保有できる事実は残り、f以下という仮定は独立に検証する。

次epochの候補ticket集合と抽選規則は、前epochのPANEL乱数の最初の正直share公開前にfreezeする。そのPANEL値をdomain分離して次rosterの選出に使ってよい。既に公開された値を見てから候補集合を作る方式は認めない。これは第三の未来乱数を作る処理ではなく、同じ公開イベントに先立ち別の対象も固定する利用である。

当選者の辞退を理由に、都合のよい次点や別seedを試す手順は置かない。必要数が準備できなければそのepochの新規AN1受理を停止する。代替slotを設ける場合は全順位・選択規則を同じfreezeへ含め、再選別の安全性を別profileで証明する。

初回rosterはgenesisまたは明示したnative起動設定で固定する。その集合に故障上限内の正直者がいることがbootstrapの信頼条件である。初回rosterを自分がまだ生成していない乱数で選ぶ循環を作らない。固定genesis seedをEXEC用の予測不能乱数として利用しない。

秘密材料はroundごとに更新し、終了・失敗後は所定の保持・裁定期間を満たした上で消去する。未公開材料を新rosterへ移すと新旧保持者の漏洩を合算する必要があるため、TB1では未公開秘密の再共有による延命を採用しない。新rosterは新しいroundを準備する。漏洩した旧roundへ既存仕事を移してはならない。

# 7. 事前に固定する識別子

RoundRefにはchain ID、suite ID、role epoch、purpose、論理round番号、RosterRoot、ScheduleIdを含める。purposeはEXECまたはPANELだけである。これらは秘密生成・ユーザー登録の前に確定する。

VSSの各sessionはRoundRefとdealer slotに束縛する。公開通信にはphase番号、sender/receiver、単調sequenceとpayload digestを含める。準備終了後、固定dealer集合Qと完全な公開transcriptを表すQualRootを別recordで作る。

FreezeRecordはRoundRef、QualRoot、native stable anchor、対象集合Root、必要なpool/規則Root、原release期限・終端期限を束縛する。登録Cには先に決まるRoundRefを入れ、C自身をleafに含む集合Rootを同じCへ戻さない。登録集合のRootは閉鎖後のFreezeRecordで結び付ける。この分離により自己参照を避ける。

一つのRoundRefは一つの用途・一つのfreeze対象にだけ割り当てる。多数claimを一つのPANEL roundで処理する場合も、対象batch集合と全pool規則を一度だけfreezeする。claimごとの抽選はその固定対象からdomain分離して導出する。

# 8. 準備段階：完全なVSSを行う

各roster memberをdealerとして、各目的に独立の秘密zを分散する。目的別に次数f以下の秘密多項式Pを持ち、P(0)=zとする。正直dealerは独立した乱数を使う。悪意dealerの入力まで独立一様であるとは仮定しない。

採用するVSSは、二変数多項式を用いた私信配布、受信者間cross-check、complaint、規定に従う訂正・公開、整合判定を行う。詳細な分岐は原典Protocol 5.6を規範参照とする。検査モデルはこの秘密分散protocolを実装していない。[R1]

| nativeへの写像 | 必須条件 |
| --- | --- |
| 私信配布 | 認証・秘匿channelでrow/columnを送る。用途・dealer・受信者index・phaseを拘束 |
| cross-check | 完全なVSSの対応する交点を比較し、欠落と値の不一致を区別 |
| complaint | 原典が許す資料だけを公開する。欠落を0と扱った偽の不一致を作らない |
| 訂正・整合 | 正直shareを便宜的に全公開して救済しない。原典の公開・更新・不適格処理を省略しない |
| 終了 | 各正直holderの出力が一つの次数f以下の多項式上に揃うか、未準備として終了 |

公開broadcastは全正直者が同じcanonical messageを読むnative recordに写像する。署名だけでは一貫したbroadcastにならない。phaseの完了を「自分が最初に見たメッセージ」で判断せず、nativeで固定した受付集合と期限に従う。

VSSを完了したholderは、RoundRef、dealer、VSS終了までの公開transcript rootと終了phaseのanchorを含むReady recordを署名する。このrootはReady自身や後のQualRoot・FreezeRecordを含まず、自己参照を作らない。q件のReadyは完了確認の資料であり、VSS自体を代用する証明ではない。各正直holderが正しいVSS終了時だけReadyを出すという仮定、VSSの整合性、nativeの共通履歴が必要である。相異なるtranscript rootのReadyを混ぜない。

準備期限までに所定のVSS判定とReady条件を満たした全dealerを、slot index順にQへ含める。q件以上のdealerが必要であり、都合のよいsubsetだけを選ばない。Q、transcript、公開資料の可用性、容量予約をfreezeして初めてPREPAREDになる。VSSが未完了のままユーザー仕事を受理しない。

通信仮定が崩れた場合は未準備で停止する。非同期環境で任意のtimeoutを挿入してもVSSのprivacyが維持されるとは主張しない。完全なVSSとnative phaseの対応、並行session・rushingの扱いは有効化前の証明対象である。原典の高次多項式処理等と、本仕様の過大record・型違反の拒否をどう対応付けるかも明示し、原典の分岐を勝手に置換しない。原典も並行VSSを単純な独立ideal機能と同一視できない点を扱っている。[R1]

# 9. 公開順序とrelease gate

EXEC/PANELの両準備と容量予約を完了し、roundとTimingPlanを固定した後にAN1登録を受け付ける。順序は次に固定する。

| 段階 | nativeで確定する事実 |
| --- | --- |
| A | 両用途のPREPARED、固定roster・Q、固定schedule、容量と担保 |
| B | EXEC登録集合を閉鎖。全C、nonce候補、target、原期限をfreeze |
| C | Bのanchorが既定のnative安定条件を満たす。初めてEXECの正直share公開を許可 |
| D | EXEC証明を検査しsigma_Eを受理。Minerが実行しOriginalを提出 |
| E | Original集合、候補pool、抽選規則、担当義務・原期限を閉鎖・freeze |
| F | Eのanchorが安定条件を満たす。初めてPANELの正直share公開を許可 |
| G | PANEL証明からsigma_Pを受理。固定対象に対してPanelを選出 |
| H | 完全再実行、資料case、Court、成功または未成功終端 |

holderは、公開依頼者が渡すbooleanではなく、自分で検証したnative状態からgateを評価する。ローカル時計や未確定mempool受付だけで公開しない。freezeとreleaseを同じ未安定blockに置かない。実行beaconを得た後に追加した登録、PANEL share公開後に変えたpoolは拒否する。

登録・Originalが0件のbatchでも、所定の空集合Rootと原scheduleを用いてEXEC/PANELを進行できる。仕事が無いことを理由にPANELを省略し、次rosterの生成が永久に止まる構造にしない。前提となるEXECやnativeが不成立ならPANELの成功を捏造せず、未成功終端と明示的な回復へ進む。

安全性が必要なのは、最初の正直shareが攻撃者へ届く時刻より前のfreezeである。f個のshareを持つ攻撃者は、最初の正直share一つと合わせてtへ到達できる。公開certificateの完成時刻やNodeの正式受理時刻を予測不能性の境界としてはならない。

各phaseには有限の最早・最遅位置をScheduleに記録する。Originalの受付期限は、EXEC certificateが正直者へ届く最遅許容位置に、実行・送信・native包含の予約時間を加えた位置より後に置く。その後の安定化余裕を経てPANELの公開を許可する。早い私的受信と遅い公式受理の差を無視して正直Minerの計算窓を短縮しない。

公開開始後の先行受信による計算開始の有利さや、選出直後のPanelへのDoSは、このbeaconだけで消えない。ネットワーク上限・実行窓・可用性・適応攻撃の評価を別途必要とする。

nativeの進行が止まる場合、壁時計だけで成功へ遷移しない。通信・包含・安定化の上限が成立する期間をlivenessの条件にし、停止時の資金解放・取消は元予約に従う。実測なしに秒数や安定化深度kの具体安全率を捏造しない。

# 10. 署名付きshareと公開復元証明

release gateを満たしたholder iは、自分がVSSの結果として保持するshare P_d(i)を、固定Qの全dealerについて公開する。メッセージはRoundRef、QualRoot、FreezeId、holder indexとshare vectorに署名する。一つの正直holderは同じ文脈・dealer・indexについて一つの値だけを署名する。

holderに候補多項式を渡して承認投票させない。自分の点と一致した最初の偽多項式へ票が固定されると、正しい復元を妨害されるためである。署名対象はholder自身のshareであり、誰でもその公開資料から正しいcertificateを組み立てられる。

各dealerについて、Nodeは次数f以下の多項式Pと、その上にあるq個以上の相異なる保持者の署名付きshareを要求する。余分な高次係数、重複index、roster外鍵、別文脈の署名を拒否する。多項式の係数はf+1個に正規化し、各field要素の符号化も固定する。

$$\forall i\in I_d:\quad v_{d,i}=P_d(i),\qquad |I_d|\geq q$$

最初に到着したt点を無条件に正解としない。復元実装は誤り・欠落を扱うReed–Solomon decoding等で候補を求め、q個の整合する認証済み点を確認する。native検査には候補多項式と点群を与えればよく、全subsetの総当たりを要求しない。

この証明は、Nodeが秘密配布時の全私信を直接検証した証拠ではない。VSSの保証と故障上限を前提に、公開shareが拘束する値を検査するものである。LLM実行の局所反証と同じ証明体系だと説明しない。

# 11. 全dealerの復元と出力一意性

Qに入った全dealerを復元する。自分の秘密を公開しないdealerがいても、そのshareを保持する他の参加者から復元する。release後にdealerをQから除外したり、応答した人だけで乱数を作ったりしない。

dealer dの復元値をz_d=P_d(0)とし、固定slot順の全値から乱数を作る。

$$\sigma_b=\mathrm{SHAKE256}(\mathrm{Enc}(D_b,(d,z_d)_{d\in Q}),32)$$

D_bは、用途tag、RoundRef、QualRoot、FreezeId、suiteとcodecを含む固定descriptorである。signature byte、証明提出者、採用したq点のsubset、到着順、transport nonce、可変metadataを出力へ含めない。これにより同じ正しい秘密の別証明は同じ出力になる。

未知な正直dealerの秘密を含む全値列をhashする。単純なXORで悪意の関連値に相殺されないことを未検証のまま前提にする設計は避ける。ただしconcatとhashだけで任意の漏洩や適応攻撃が消えるわけではなく、VSSの秘匿性と正直dealerのentropyが必要である。

全Qについて証明が揃わなければ公開値は受理しない。期限を過ぎたらBEACON_UNAVAILABLEで未成功終端とし、Qの縮小、定数seed、block hash、旧seal-reveal、別round、別suiteへの自動fallbackを禁止する。

# 12. 条件付き安全性の論証

## 12.1 前提

対象batchの静的腐敗集合はf以下、完全なVSSは正直holder全員のshareを一つの次数f以下の多項式に揃え、正直dealerの秘密をf個以下の腐敗shareと公開準備記録から隠すとする。私信・署名・hashの想定安全性、nativeの安定履歴・包含、独立した正直乱数、正しいrelease gateを仮定する。roster侵害確率やnative再編確率は、この設計だけから数値化しない。

## 12.2 公開値の一意性

あるdealerの真の多項式をPとする。別の多項式P'はPと高々f個のindexでしか一致しない。そのためP'に乗る正直shareは高々f個である。悪意holderが全員署名しても加えられるのはf個までで、合計2f個となる。

$$P'\ne P\quad\Longrightarrow\quad \mathrm{support}(P')\leq 2f<q$$

したがってq点のcertificateを持つ候補はPに限られる。全dealerの値とcanonicalな出力hashが一意なので、別subset・別署名乱数による乱数再抽選はできない。この証明には完全VSSの前提が不可欠であり、単なる証明集合の交差に一人の正直者がいるという議論では足りない。

## 12.3 freeze以前の予測不能性

Qはq人以上を含み、故障者はf人以下なので、少なくとも一人の正直dealerを含む。その独立した秘密がVSSで隠され、最初の正直share公開までは復元閾値に達しない。hash/XOFの安全性を含む明示したモデルで、最終値を予測する利得を各構成要素の失敗確率へ帰着する。

$$\Pr[\mathrm{Guess}(\sigma_b)]\leq 2^{-256}+\varepsilon_{\mathrm{model}}$$

これは実装済みPQ suiteの定量的な安全性定理ではなく、各構成要素へ要求する条件付きの合成契約である。epsilon_modelはVSS、通信、認証、hash、native、roster、entropy、合成のadvantageまたは失敗確率を含み、それらを小さいと実証した数値は今回示していない。

より限定した古典idealモデルで、固定された公開viewに対し一つの正直な秘密zが体上で一様に隠れ、出力hashを独立のrandom oracleとする。出力の完全なpreimageを狙う異なる照会がQ_H回なら、その未知座標に当たる確率をQ_H/pで上界化できる。未照会の出力を当てる項2のマイナス256乗と合わせる。この説明は、完全VSS・ideal私信の仮定から実際の通信・hash実装へ移る証明を省略してよいという意味ではない。

実suiteでは暗号advantageとnative等のbad eventを別途加える。具体的なSHAKE256実装に対する無条件定理ではない。古典random oracleの照会境界を量子攻撃へそのまま流用しない。量子・適応・並行sessionを対象とする完全な合成評価は有効化gateとする。

## 12.4 二つ目の未来未知性

EXECを公開した後の全記録を知っていても、独立したPANEL秘密と係数がVSSで隠れている間は、PANELの値は同様に予測不能である。これが、同じ公開seedの再hashと異なる根拠である。共通RNG状態の漏洩、係数や私信鍵の再利用、将来秘密を導ける生成手順はこの前提を破る。

## 12.5 withholdingとbias

故障f以下で、n−f人の正直holderが原期限までに包含されるなら、悪意dealer本人の協力なしで全Qの復元証明を作れる。公開するかどうかで悪意者が別の有効値を選ぶ自由はない。

ネットワークやnative包含が攻撃者の都合で停止する場合まで含め、「実際に公開された値だけを条件付けても一様」とは主張しない。未成功終端は誤った成功を防ぐが、全ての選択的停止・検閲を暗号だけで排除するものではない。閾値の故障範囲内での活性と、その範囲外での安全停止を分ける。

# 13. Panel選出・Courtとの接続

pool、各候補の重み、Panel人数、除外規則、予備担当順をPANEL freezeへ含める。Selectはcanonicalな候補順とSHAKEのstreamから、modulo biasを避けるrejection samplingで重複なし抽選を行う。可変到着順や自己申告の利用可能者だけで抽選しない。

Panel辞退・無応答が起きた場合、既定の予備担当順と原予約がある場合だけそこへ進める。予備を見てから再抽選することは禁止する。必要な検証条件を満たせなければ未成功へ進む。

PositiveNonce等は正規PANEL値と元claim・個人文脈へ結び付ける。一方、有効なnegative、資料要求、取得応答、Court裁定、終端処理に新しいbeaconやTicketを要求しない。乱数生成が止まっても、既受理caseを元の容量・原期限で処理する。[D2][D3]

「一人の能動的な正直Panelが必要資料を取得・再実行し、有効反証をFinal前に届けられる」というAN1の条件は維持する。beaconのf上限は、Panelの正直者条件からは導けない。beacon certificateのshare数をLLM実行の承認票へ流用しない。

# 14. 状態機械・停止・一回性

通常遷移はPLANNED、PREPARING、PREPARED、FROZEN、RELEASING、READY、CONSUMEDの順序とする。batch共有では一つのclaimが使っただけでround全体をCONSUMEDにしない。固定対象内のconsumer/slotごとに一回消費を記録し、全対象の成功・失敗終端が確定した時にroundを閉じる。準備不成立はPREPARE_FAILED、原期限までの公開不成立はBEACON_UNAVAILABLE、公開後の拘束破損はEXPOSED_ABORTEDへ進む。いずれも成功扱いへ時間経過だけで変化させない。

| 事象 | 処理 |
| --- | --- |
| VSS不成立・容量不足 | ユーザーの新規受理前にPREPARE_FAILED |
| freeze未安定 | 正直holderはshareを出さない。期限まで安定しなければ未成功 |
| 少数holderの公開拒否 | 故障予算内なら正直holderの点から復元 |
| q点未達・全Q未達 | 原deadlineでBEACON_UNAVAILABLE。subset乱数は禁止 |
| 同じRoundRefに別Freeze | 拒否。既知乱数を新しい対象へ割り当てない |
| slot/attemptを別roundで再救済 | 拒否。同じ採掘機会を無料で再抽選しない |
| 新規の有料登録 | 新slot・新nonce・将来roundへ改めて登録可能。旧claimの復活ではない |

Fee、refund、役務報酬は事前に固定し、乱数の良し悪しに応じて変えない。客観的な不正証拠は、同一文脈・indexへの二重署名や、成立済みq点certificateが定めた多項式と署名済みshareの不一致などに限定する。最初のt点から外れた値や、未成立の候補多項式との不一致だけでslashしない。これらの証拠と通信停止の帰責を区別する。私的な早期漏洩は常に検知できるとは限らず、slashを予測不能性の根拠にしない。

# 15. reorg・情報漏洩・cold import

DBのundoで公開済み秘密を未公開に戻すことはできない。正直holderは公開済みRoundRef、FreezeId、QualRoot、share contextを耐久記録し、再起動やreorg後も別freezeへの公開を拒否する。これはローカルの防護であり、ネットワーク全体の共通prefixを代替しない。

release後にfreeze anchorが非canonicalになる深い再編は、native安定性仮定の破れとして扱う。影響した未完了attemptをEXPOSED_ABORTEDとし、新しい対象集合やpoolへ既知乱数を再使用しない。すでに漏れた秘密をfreshと宣言して再開しない。再開は新しいround・新しい材料・新しい登録と明示したrecovery規則による。

cold importでは、元のcanonical履歴、全release gate、署名・点群・多項式、Q、使用済みslotを再検証する。別forkで流出した秘密の不存在は、canonical chainだけを見た新規Nodeには証明できない。安定化深度、曝露記録の伝播、回復時の停止範囲は別のnative設計課題であり、有効化前の障害注入試験に含める。

# 16. native進行とbeaconの循環を避ける

VSS、Ready、share公開、資料case、Court、終端を運ぶcontrol容量は事前予約する。これらのcarrierが、今まさに生成中のEXEC/PANEL値、未完了のAN1 credit、未発行Ticketを要求してはならない。既存nativeの進行・課金規則で処理し、それ自体から追加のLLM creditやfork weightを発生させない。

既存nativeが新beaconを待つと全carrierが停止する構造なら、先にこの循環を解消する必要がある。単に「control laneを追加した」と書くだけで、honest包含やchain growthが保証されたことにはしない。新規採掘受付を止めても、既受理の救済・終端を通せる実装と容量証拠が必要である。

旧seal-reveal routeは元のscope・署名規則・履歴を保ってdrainする。新TB1の失敗時に自動で旧routeへ戻さない。旧BLS参照候補もDISABLEDの履歴を残し、新仕様への参照を別に付ける。[D1][D2]

# 17. 資源会計と攻撃面

本方式は署名一個のbeaconより通信量が大きい。目的ごと・dealerごとにVSSを実行するため、準備時の私信・cross-check・complaint容量を先に積む。多数claimで一つのroundを共有して償却してよいが、対象集合とpoolを公開前に完全に固定する。

容量例n=64、f=21、66byte fieldでは、各dealerが各holderへ二本のf+1係数多項式を送る部分だけで185,856byte、64dealerで11,894,784byteのfield payloadになる。これは本設計の整数計算であり、ciphertext、署名、cross-check、complaint、再送、native記録、保存複製を含まない。二用途には別の材料が必要である。

share公開はholderごとのQ全体vectorに署名して償却できる。certificateの大きさはQ件×q点に加え署名等に依存する。署名検査数、最大record、private/private-to-publicの増幅、complaint worst case、保持期間、復元CPU、native inclusion latencyを測定するまで本番throughputを主張しない。

| 攻撃・不正経路 | 対応と境界 |
| --- | --- |
| EXEC公開を見てnonce/model/jobを選ぶ | 全候補と文脈を最初の正直share公開前にfreeze |
| EXECからPANELを予測 | 独立秘密と後続公開gate。hashし直すだけの代用は禁止 |
| 一部shareを先に私的収集 | f上限と最初の正直shareより前のfreeze。公開開始後の速度差は残る |
| 最後のdealerが公開しない | 全Qの秘密を他holderから復元。dealer除外で別値を作らない |
| 偽多項式・偽share | 完全VSSとq点certificate。単なるt点の提出は受理しない |
| 署名乱数・証明subsetのgrinding | 出力に可変証明byteを含めない |
| pool/round/key/forkの後出し | 事前固定したdescriptor、native安定化、一回使用、曝露後の再割当禁止 |
| Sybil・roster支配 | lot二重使用拒否と事前抽選。実主体の故障割合上限は別の仮定 |
| 対象holderの順次侵害 | round鍵・短い保持期間・消去。適応安全性は別途証明が必要 |
| native検閲・全体停止 | 予約と救済の維持、未成功終端。暗号だけで進行を保証しない |

# 18. 実装順序と有効化条件

| 段階 | 作業 | 完了証拠 |
| --- | --- | --- |
| P0 | codec、固定ID、2種purpose、freeze/deadline、一回性をnative型へ実装 | 境界値、再送、型混乱、fork/context差替えの拒否 |
| P1 | 完全BGW VSSとPQ認証私信、公開transcript、malicious dealer処理 | 原典全分岐、通信障害、秘密漏洩、rushing・並行sessionの監査 |
| P2 | q点certificate、全Q復元、任意subset同値、RS復元 | 不正点・欠落・再署名・悪意polyに対する検証と容量計測 |
| P3 | native安定化gate、予約、carrier、cold import、DB journal | 早期公開・深いreorg・停止・再起動・全consumerの統合試験 |
| P4 | AN1のEXEC/PANEL、候補pool、Panel/Court、取消・資金処理 | 正常完了と全失敗終端、既受理negativeの生存性 |
| P5 | roster/鍵寿命/初期起動、実負荷・独立暗号監査 | fault仮定・具体suite・安全率・有効化fenceの採択資料 |

有効化には、静的モデルの証明だけを実環境へ無説明に拡張せず、対象脅威に対応した適応侵害・量子・nativeとの合成の評価が必要である。論文の存在、toyのPASS、CSPRNG統計試験は、このgateを満たす証拠ではない。

AN1のLLM費用下界は引き続き別件とする。乱数が入力へ結び付き予測しにくくなっても、cache、batch、特殊入力、別アルゴリズムによる正しい実行の安価化が排除されたことにはならない。会計は証明済みの仕事量と明示した仮定の範囲へ合わせる。

# 19. 検査モデルで確認したこと

付属Pythonモデルは、固定Q、二つの公開gate、canonical context、Shamir補間、q点certificate、終端、一回性を対象にする。実BGW配布とPQ認証は全秘密を知るfixtureで置き換えた。従って、モデル自身の秘密を攻撃者から守る実装ではない。

29テストは失敗0・エラー0だった。5dealerそれぞれの全35通りの3点subset、計175通りの補間一致、全21通りの5-of-7公開certificateの出力一致をテスト内で確認した。175と21は29件に含まれる内部検査であり、独立テスト件数として合算しない。

偽share、偽poly、誤index、別purpose、別round、freeze前公開、PANEL対象不足、Q縮小、pool差替え、別roundでの同attempt救済を拒否する経路を検査した。2holderが停止しても残り5holderで全Qを復元できる例を確認した。

限界も明示的に再現した。3人が共謀すれば秘密をgate前に復元できる。また公開済みEXEC値のhashは誰でも予測できる。これは設計条件が必要な理由を示す検査であり、その条件違反まで防いだ結果ではない。

別scriptでは体17、n=7、f=2について、全21腐敗集合と4,912個の偽多項式の組、103,152ケースを列挙した。腐敗者は任意の偽値へ有効署名できるものとし、偽多項式の支持が最大4でq=5へ届かないこと、q=4へ下げると通る反例を確認した。これは29テストと合算しない独立の算術検査である。

主モデルのauth fixtureは全ての正しいshareを知り、真のshareだけを認証するため、本物の署名より強い仮定を置く。上の独立scriptはこの制約を外して公開certificateの件数境界を検査する。

本番署名、秘匿channel、VSS complaint、nativeの実際の安定化、ネットワーク可用性、DB並行性、DAGの回復、適応侵害、量子攻撃に対する安全性は、この29件で検証していない。

# 20. 文書への反映範囲と資料の来歴

新規RFCは提案番号RFC-0060、ADRは提案番号ADR-0229として添付する。読めたsnapshot内では空き番号だが、最新branchの採番確認までは正式番号・wire tagを確定しない。既存RFC-0055〜0059に加える節案と、白書へ統合する文章も別ファイルに収録する。

今回読んだ原文は、この会話のワークスペースに残るRFC/ADR/AN1統合稿である。最新添付一覧にあるmisaka_docs_latestと改題済みMisaka_Design_Whitepaperの本文は現環境から取得できず、最新原本への直接編集・逐語差分を作ったとは表示しない。元資料は変更していない。取得できた原文のpath・hashをSOURCE_MANIFESTに記録した。

本書は「Misakaの設計whitepaper」に続く追加設計書であり、表題に文書バージョン・日付を付けない。PALW-AN1、PALW-TB1、RFC番号等は技術的な識別子として維持する。独立レビューでは、公開開始後の先行取得、二種類の閾値、VSSの完全性、偽polyへの投票ロック、公開済み秘密とreorgの扱いを重点確認し、本文へ反映した。

\newpage

# 参考資料

## 提供資料

[D1] ADR-0180「PALW-only consensus, no BFT validators」、ADR-0185「Paid lock randomness bootstrap and paid sources」。公開役務と台帳合意の境界、旧seal-revealのscopeを確認。付属SOURCE_MANIFESTで実ファイルを特定する。

[D2] RFC-0055〜0058、ADR-0226。受付、Court、二段階freeze、旧BLS候補DISABLED、既受理negativeを新beacon待ちにしない規則を確認。

[D3] RFC-0059、ADR-0227、取得済みAN1統合原稿。入力束縛、元claim、Panel＋Court、一回性、未有効化・費用下界の境界を確認。

## 外部一次資料

[R1] Gilad Asharov and Yehuda Lindell, A Full Proof of the BGW Protocol for Perfectly-Secure Multiparty Computation. ECCC TR11-036, revision 5. 特に§5、Protocol 5.6、§6.2。https://eccc.weizmann.ac.il/report/2011/036/revision/5/download/

[R2] 同論文のJournal of Cryptology公開ページ、Notes 1。完全な適応安全性に関する過去の説明の訂正。https://link.springer.com/article/10.1007/s00145-015-9214-4

[R3] NIST FIPS 203, Module-Lattice-Based Key-Encapsulation Mechanism Standard。KEMの役割とparameter sets。https://csrc.nist.gov/pubs/fips/203/final

[R4] NIST FIPS 204, Module-Lattice-Based Digital Signature Standard。署名の役割と標準。https://csrc.nist.gov/pubs/fips/204/final

[R5] Kevin Choi, Aathira Manoj and Joseph Bonneau, SoK: Distributed Randomness Beacons。予測不能性、bias、停止、secret-sharing型の区別。https://eprint.iacr.org/2023/728

[R6] Behzad Abdolmaleki et al., A Practical Framework for Lattice-Based Non-interactive Publicly Verifiable Secret Sharing。将来の効率化候補として検討したが、今回の主方式には採用しない。公開付録の安全性モデルとsetupを確認し、PALWへの適用を完成済みとしなかった。https://link.springer.com/chapter/10.1007/978-3-032-22698-3_4

本書のPALWへの接続、識別子、公開順序、q点certificate、失敗・移行規則は追加設計である。一次資料の既存定理と、本書で新たに必要とした合成・実装義務を混同しない。
