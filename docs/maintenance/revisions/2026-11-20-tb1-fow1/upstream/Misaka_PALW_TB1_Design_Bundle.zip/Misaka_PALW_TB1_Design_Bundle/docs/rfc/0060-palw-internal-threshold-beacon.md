# RFC-0060（提案番号）: PALW内部閾値beacon

**Scheme:** PALW-TB1 / TB1-BGW-PQ  
**Status:** DESIGN_DIRECTION_REQUESTED / DRAFT_NOT_ACTIVATED  
**Numbering:** 読めたsnapshot内の提案番号。最新branchとの採番照合前に正式ID・wire tag・activation fenceを割り当てない。  
**Depends on:** RFC-0055〜0059、ADR-0180、ADR-0226、ADR-0227。  
**Normative design:** `../../Misaka_Internal_Threshold_Beacon_Design.pdf` の追加設計書。

## 0. 目的と非目標

PALW-AN1のEXEC入力とPANEL選出に必要な未来乱数をPALW内部で生成する。Panel＋Courtを維持する。BFT validator finality、DNS-final、Groth16、LLM実行のSNARKを導入しない。保持者の役割は秘密分散・保管・復元資料公開であり、fork choice、reorg、Final、creditの決定権を持たない。

本RFCは新しい暗号原語を証明済みとして発明するものではない。完全なBGW VSSをPQ通信・署名とnative安定履歴へ接続する追加protocolである。本番有効化は§12の全gateを満たすまで禁止する。

## 1. 規範用語とfault model

MUST、MUST NOT、SHOULDは本RFCの実装要件を示す。

- `n = 3*f + 1`, `t = f + 1`, `q = n - f = 2*f + 1`。
- `t`は秘密を復元できる正しいshare数、`q`はnativeが公開certificateを受理するための署名付き整合点数。混同してはならない。
- `Q`は準備完了dealerの固定集合であり、`|Q| >= q`でなければPREPAREDへ進めない。
- 静的悪意者とofflineを含めた総fault budgetはf。秘密保護期間の累積侵害を無視してはならない。
- 例: `n=7,f=2,t=3,q=5`。容量候補例: `n=64,f=21,t=22,q=43`。本番parameter確定とは扱わない。
- 署名・秘匿channel・完全VSS・entropy・native stable broadcast・包含・compositionの仮定を明示する。適応侵害や量子合成へ静的な古典定理を自動拡張してはならない。

## 2. Purposeと識別子

`purpose ∈ {EXEC, PANEL}`。AN1に第三のTicket用beaconを追加してはならない。

```text
RoundRef = {
  chain_id, suite_id, role_epoch, purpose, logical_round,
  roster_root, schedule_id
}

VssSession = { RoundRef, dealer_slot }

Qualification = {
  RoundRef, ordered_dealer_slots, public_transcript_root,
  ready_records_root, resources_ref
}

FreezeRecord = {
  RoundRef, qual_root, stable_anchor,
  closed_registration_or_original_root,
  pool_root_if_panel, selection_rule_root_if_panel,
  original_timing_plan
}
```

新TB1のcontext digestは64byte、seedは32byteの異なる型である。既存64byte native beaconを32byteへ暗黙に切り詰めてはならない。chain/profile識別子の意味・幅はcanonical codecで固定する。Cには先に決まるRoundRefだけを入れ、Cを含む集合RootをC自体へ戻す自己参照を禁止する。

codecは固定長unsigned integer、長さ付きbyte列、tag付きrecord、規定順序vectorを用いる。型違反、float、boolの整数扱い、重複・逆順index、末尾byte、範囲外field、無制限vectorを拒否する。全比較は実byte列の再構成から行い、渡されたroot属性・`authenticated=true`・`stable=true`等を信用してはならない。

## 3. suite

候補suiteは以下を用いる。

| 要素 | 規定 |
| --- | --- |
| field | `p=2^521-1`、66byte big-endian、0≤value<p |
| share座標 | roster slotに対応する相異なる非0 field値。indexと鍵をnativeが固定 |
| VSS | Asharov–Lindell ECCC TR11-036 revision5 §5 Protocol5.6全部 |
| 認証 | ML-DSA-65、登録鍵の所有・署名context・canonical encodingを検査 |
| private channel | ML-KEM-768＋認証・鍵確認・目的別session＋AES-256-GCM |
| context hash | SHA3-512 |
| output | SHAKE256、32byte |

ML-KEM単独は認証channelではなく、ML-DSA署名単独はVSSではない。suiteの実際のwire、KDF、鍵確認、AEAD nonce永続化、標準errata、resource caps、test vectorsをprofileで固定するまで有効化しない。

## 4. membershipとbootstrap

1. native役務leaseにはowner、担保lot、役務期限、容量、署名鍵、用途別通信鍵、所有証明を束縛する。同じ担保lotを複数ticketに使用してはならない。
2. 次rosterの候補ticket集合・抽選規則を前epoch PANELの最初の正直share公開前にfreezeし、その値をdomain分離して重複なし抽選する。
3. アドレス分割が実主体の分散を証明するとは扱わない。同一運営主体の全slotをfault budgetへ数える。PALW実績からf上限を証明済みと推論しない。
4. 初回rosterは明示したnative起動設定で固定し、故障上限仮定を開示する。公開定数をEXECの予測不能seedとすることを禁止する。
5. 辞退・不参加を見て別seedで再選出してはならない。準備不成立はそのepochの新規AN1受理停止へ接続する。
6. 未公開秘密を別rosterへ移して保護期間を延長する再共有はTB1では採用しない。更新は新roundの新秘密で行う。

## 5. 準備phase

各dealerは各purposeに独立した一様秘密zと次数f以下の多項式Pを生成し、`P(0)=z`として完全BGW VSSを実行する。

全私信・公開messageはRoundRef、dealer、sender、recipient、phase、sequenceへ束縛する。VSSで定められた配布、cross-check、complaint、規定の公開・訂正、整合判定、outputを省略してはならない。単なるShamir配布＋多数ACKをVSSとして扱わない。

private資料の欠落は値不一致ではない。timeoutで欠落値を0に置換してcomplaintへ進めたり、正直者の全秘密資料を便宜公開して回復したりしてはならない。元protocolの安全な分岐とnative phaseの対応を実装審査する。

VSS完了後、正直holderは同一public transcript rootと終了phase anchorを含むReadyへ署名する。rootはVSS終了までを対象とし、Ready自身・QualRoot・FreezeRecordを含めない。q件の同一context Readyと所定のVSS終了判定があるdealerをqualifiedとする。ReadyはVSS実施と故障上限の仮定に依存する完了確認であり、任意の私信の正しさをNodeが直接証明したと説明してはならない。

期限内の全qualified dealerを固定順でQに含め、QualRootを作る。`|Q|<q`なら未準備で終える。Q、資料、全必要容量が確定するまでPREPAREDにならない。両purposeがPREPAREDになる前に対象ユーザー仕事を受理しない。

## 6. 二段階release gate

### 6.1 EXEC

owner、全nonce候補、model、job、profile、target、会計、容量、原期限、両RoundRef、登録集合をfreezeし、そのanchorがnative安定条件を満たした後にだけ正直shareを公開する。

### 6.2 PANEL

EXEC受理後に生成したMiner署名済みOriginal、受理集合、pool、重み、選出・予備担当規則、義務と原期限をfreezeし、後続anchorが安定した後にだけPANEL shareを公開する。

### 6.3 共通

空の登録/Original batchでも、所定の空集合Rootと原scheduleにより両purposeを実行できる。仕事件数0を理由に、次rosterへ必要なPANEL値の生成を省略しない。前提不成立時は元の未成功終端と明示回復を使う。

最初の正直share公開が予測不能性の境界である。公式公開やcertificate完成より前にf個の悪意share＋一つの正直shareで先行復元できることを認識する。freeze条件をholderがnativeから再検証する。単なるhash domain変更、外部boolean、ローカル時計、mempool受付、未安定blockをgateの代用にしてはならない。

Original受付期限は、EXEC certificateの正直者への最遅許容配信位置＋予約された実行・送信・包含時間より後に置く。PANEL releaseはその閉鎖anchorの安定化後とする。公開開始後の受信差・計算開始差・選出直後DoSを、このbeaconだけで排除したと表示しない。

## 7. 公開資料とcertificate

```text
ShareRelease = {
  RoundRef, qual_root, freeze_id, holder_slot,
  [(dealer_slot, share_value) for dealer_slot in Q],
  owner_signature
}

DealerCertificate = {
  dealer_slot, coefficients[0..f],
  supporting_share_release_refs
}

BeaconCertificate = {
  RoundRef, qual_root, freeze_id,
  certificates_for_every_dealer_in_Q
}
```

各holderは自分のshare値を署名する。候補多項式への最初の投票をロックする方式を導入してはならない。署名は可変乱数を持ってよいが、そのbyte列をseed入力に含めない。

Nodeは各dealerについて次をすべて検査する。

1. nativeに記録したRoundRef、Q、FreezeRecord、release gate、原deadlineとの一致。
2. roster内の相異なるq人以上の署名、対応index、同一context。
3. 正規係数f+1個と次数f以下、各支持点がその多項式上にあること。
4. 固定Qの全dealerを一回ずつ含むこと。
5. 資源上限、資料可用性、既使用状態、再送の同値性。

復元側は誤り・欠落に対応したReed–Solomon等を使用する。最初のt点を真として受理しない。Nodeは提出された多項式とq点の関係を直接検査できる。

## 8. 出力

`z_d=P_d(0)`とし、固定dealer順の全値を用いる。

```text
sigma = SHAKE256(
    Enc("PALW-TB1/beacon", RoundRef, QualRoot, FreezeId,
        [(dealer_slot, z_d) for dealer_slot in Q]),
    32
)
```

signature、提出者、support subset、到着順、transport nonce、可変metadataをhashしてはならない。responseしないdealerの除外、全Qを満たさない途中値、別roundへの付替えは禁止する。

EXECをPANELのentropyとして再使用しない。独立した目的別秘密と公開gateを使う。AN1 Ticket式とPanel＋Courtは維持する。

## 9. 失敗、reorg、救済

PREPARE_FAILED、BEACON_UNAVAILABLE、EXPOSED_ABORTEDは未成功終端である。定数、block hash、旧seal-reveal、別suite、別key、別roundへの自動fallbackはない。同じattemptを新roundで無償救済しない。

release済み秘密はDB undoでは消えない。holderは曝露contextを耐久保存し、別freezeへ再署名しない。深いreorgで安定性仮定が破れた場合、影響した未完了attemptを停止し、新しい材料と登録による明示的回復だけを許す。cold importだけで非canonical fork上の漏洩不存在を証明したとは扱わない。

batch共有の一回性は固定対象内consumer/slot単位で記録し、全対象が成功または失敗で終端した後にroundをCONSUMEDとする。最初のclaimによって全対象の利用を塞がない。

不正shareの処分は、同一context/index二重署名、または成立済みq点certificateのPとの不一致など、公開検証できる証拠による。未成立候補Pや最初のt点との不一致だけでslashしない。

既受理negative、資料要求・応答、Court、終端は新beaconを待たない。元予約・原期限で処理する。control carrierは現在生成中のbeaconや未発行AN1 creditに依存してはならない。

## 10. 安全性命題

完全VSSにより全honest点が真の次数f以下のPに属するとする。偽P'はPと高々f点でしか一致しないため、honest支持は高々f、悪意支持も高々f、合計2fでqへ届かない。これにより公開値の一意性が得られる。

Qに正直dealerが含まれ、その秘密がf share以下と公開viewから隠れ、正直releaseがfreeze後だけなら、freeze前の予測利得はVSS、通信、hash、native、roster等の失敗項へ帰着する。古典ROの数値境界を量子ROへ流用しない。

n−f honest holderの期限内包含があれば全Qを復元できる。範囲外のネットワーク停止、閾値以上の共謀、適応侵害、情報漏洩、native安全性破れに対する無条件の進行・予測不能性は主張しない。

## 11. 参照モデル

`../../reference/`は状態機械と有限体の補間・certificate構造を検査する。実BGW、ML-KEM、ML-DSA、native合意、DB/reorgを実装しない。資格・認証はfixtureであり、本番へ接続してはならない。

別の独立有限体検査では悪意holderが任意の偽値を正当に署名できるモデルでq点の境界を調べる。これも実ネットワークや暗号実装の検証ではない。

## 12. Activation gates

- 完全BGW protocolとnative broadcast、private channel、phase timeoutの対応証明・実装・悪意テスト。
- 具体suiteとcodec、正規wire vectors、標準訂正情報、拒否条件、全resource caps。
- 静的モデルから対象脅威への量子・適応・並行session・通信の合成評価。
- rosterの支配率・集中・担保モデル・bootstrap条件の独立評価。
- native stable freeze、深いreorg、曝露journal、cold import、再起動、全consumerの統合。
- Court/negativeを止めない容量、beacon待ち循環の不存在、有限失敗終端と資金処理。
- 独立暗号監査、負荷・障害注入試験、採番・fence・移行の明示採択。

これらを満たすまで`enabled=false`とする。LLMの実費下界は別gateであり、本RFCの乱数保証から導かない。

## 参考資料

- Asharov–Lindell, ECCC revision5 §5, Protocol5.6, §6.2: https://eccc.weizmann.ac.il/report/2011/036/revision/5/download/
- 適応安全性の訂正: https://link.springer.com/article/10.1007/s00145-015-9214-4
- NIST FIPS203: https://csrc.nist.gov/pubs/fips/203/final
- NIST FIPS204: https://csrc.nist.gov/pubs/fips/204/final
