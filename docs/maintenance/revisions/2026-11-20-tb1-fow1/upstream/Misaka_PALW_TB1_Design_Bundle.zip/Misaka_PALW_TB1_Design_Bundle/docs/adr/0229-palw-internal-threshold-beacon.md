# ADR-0229（提案番号）: PALW内部の閾値beaconで二つの未来乱数を供給する

**State:** DESIGN_DIRECTION_REQUESTED / DRAFT_NOT_ACTIVATED  
**Related:** RFC-0060（提案番号）、RFC-0055〜0059、ADR-0180/0185/0226/0227。  
**Number:** 最新branch未照合。正式採番・wire割当・公開activationは未実施。

## 背景

AN1は実行入力用の未来乱数と、その後のPanel選出用の未来乱数を要求していたが、具体的な安全な生成方式が完成していなかった。旧BLS/BFT候補はDISABLEDであり、既存のseal-revealはscopeと停止・選別分析が異なる。公開済みEXEC seedのhashからPANEL seedを作る案は未来未知性を持たない。

ユーザーは、BFTを使わないPALW内部の新しい閾値beaconを基本方針とする追加設計を明示した。本ADRはその設計方向を具体化する。過去の採択記録を遡って書き換えない。

## 判断

PALW-TB1を追加設計する。中核は完全BGW VSS、PQ認証私信、署名付きshare点による公開復元証明とする。EXEC/PANELは秘密材料・session・公開gateを別にする。

`n=3f+1`、秘密復元`t=f+1`、公開certificate `q=2f+1`を区別する。固定Qの全dealerを他holderから復元できるため、dealer本人のrevealを必須にしない。応答しないdealerを後から除く方式を採らない。

保持者には台帳finality、fork choice、reorg、claim Final、creditへの投票権を付与しない。existing nativeの安定履歴と包含を前提に用いる。別BFT consensusを内部へ隠して導入しない。

## 比較した候補

| 候補 | 判断 |
| --- | --- |
| BFT＋BLS閾値署名 | BFT非依存・PQ-onlyの方針に合わず不採用。外側のML-DSAでBLSを耐量子化できない |
| 公開済みEXEC seedのdomain分離 | 新しい未来乱数ではないため不採用 |
| 単純commit-reveal | last revealerの停止・選別を、金銭罰だけで排除できない |
| Shamir＋暗号化＋ACKのみ | 悪意dealerの不整合に対するVSSではないため不採用 |
| 格子PVSS | 将来の効率化候補。setup、具体parameter、QROM/適応/合成を未確認のまま中核にしない |
| 完全BGW VSS＋PQ通信 | 秘密分散の既存の完全手順を基礎にでき、BLS・新CRS・LLM ZKを必要としないため採用方向 |

## 重要な帰結

1. 公開certificateが揃うより先に秘密を知る参加者がいる。freezeは最初の正直share公開より前に安定させる。
2. fault budget f、bootstrap、native安定性、通信・包含の仮定は残る。「一人の正直Panel」からbeaconの安全性を導かない。
3. 新しい乱数役務のmembership、担保lot、選出・交代、容量、鍵寿命を仕様化する。恒久的な特権validatorを復活させない。
4. BGWの私信・cross-check・complaint・訂正・終了の全分岐を実装する。少数の正常系テストで省略しない。
5. 深いreorgで秘密を未公開に戻せない。曝露roundの別freezeへの再割当は禁止する。
6. 未成功終端・no fallback・救済容量維持を必須にする。beacon待ちでnative全体が進めない循環を有効化前に除く。
7. 量子・適応・nativeとの合成評価は追加義務。既存定理の静的モデルと区別する。
8. 新beaconは正しいLLM実行の費用下界を証明しない。

## 実装・有効化

今回の実装はfixtureを使う参照検査モデルのみ。本番BGW、PQ暗号、native、DB、実ネットワークの統合は未実装である。RFC-0060の全activation gatesが満たされるまで未有効化状態を維持する。
