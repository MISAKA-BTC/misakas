# 既存白書・RFCへの統合用追記

これは取得済みの旧snapshotを根拠に作成した**追加文章**であり、未取得の最新ZIPや改題済みPDFへ直接適用した差分ではない。原本は変更しない。RFC-0060/ADR-0229は提案番号であり、最新branchで採番を確認する。

## 白書の乱数生成・二段階freeze節へ

PALW-AN1の実行入力用EXEC乱数とPanel選出用PANEL乱数は、PALW内部の有限期間のshare保持者が運用するPALW-TB1から取得する。中核は完全な検証可能秘密分散と、署名付きshareによる公開復元証明である。二つの用途は独立した秘密と公開gateを持つ。EXECの公開値をhashし直してPANELの未来未知性を作ったとは扱わない。

holderはnativeに固定された対象集合と原期限を自分で検証し、そのanchorが所定の安定条件を満たしてからshareを公開する。EXECより前に登録Cと全nonce候補を、PANELより前に署名済みOriginal、pool、抽選規則をfreezeする。予測不能性の境界は最初の正直share公開であり、certificate完成や公式発表の時刻ではない。

`n=3f+1`の構成では、秘密復元閾値は`f+1`、native公開certificateは`2f+1`件の同じ多項式上の署名付きshareを必要とする。完全VSSが正直shareの整合性を保証すること、fault budget、PQ通信・署名、nativeの安定性と包含を条件とする。保持者に台帳のFinalやreorgを投票で決める権限は与えない。LLMの検証は引き続きPanel＋Courtで行う。

固定Qの全dealerを復元し、応答しないdealerを後から除外しない。乱数不成立は未成功終端となり、旧seed、block hash、別roundへ自動で切り替えない。公開済み秘密をreorgでfreshに戻すことはできないため、曝露roundの別対象への再使用を禁止する。

本方式はDRAFT_NOT_ACTIVATEDである。完全BGW、PQ通信、nativeとの合成、適応侵害、容量・障害注入、全consumerの統合評価を有効化条件とする。LLMのGPU時間・電力・金銭費用の下界は別の未解決課題である。

## RFC-0055の資源・calendar節へ

TB1を用いる受付は、VSS private/public資料、complaint、Ready、share release、復元certificate、終端、保持・journalの容量を登録前に予約する。既受理のnegative、資料case、Court、取消・終端の予約をTB1の新規準備が消費してはならない。control carrierを現在生成中の乱数や未発行AN1 creditへ循環依存させない。

## RFC-0056 §17へ

AN1登録CとTimingPlanはEXEC/PANEL双方のRoundRefを事前に固定する。両方のPREPAREDと予約が完了していることを受付条件とする。EXECのfreezeは最初の正直share公開より前にnative安定条件を満たす。原target・difficulty・会計・期限をseed判明後に選び直してはならない。TB1不成立は当該attemptの未成功終端となり、別roundで同attemptを再抽選しない。

## RFC-0057のbeacon/Court節へ

PositiveNonceと個別challengeは、認証済みの正規PANEL値、元claim、holderではなく担当Panelの文脈へ結び付ける。旧64byte native beaconと新TB1 seedを別型として扱い、暗黙の切詰めを禁止する。negative、資料要求・応答、Court、終端に新しいbeacon待ちを追加しない。TB1 share多数をLLMの正当性多数決に流用しない。

## RFC-0058 §6および§16へ

旧BFT/BLS候補DISABLEDの履歴は残す。新AN1の具体beaconはRFC-0060（提案番号）を参照する。AN1に旧SWC1の第三のTicket乱数を追加しない。stable anchor、全context、fork、key、roundを事前固定し、公開済みroundの別freezeへの再割当を拒否する。

## RFC-0059 §2/§4/§10/§15へ

BeaconRefにTB1 scheme、suite、role epoch、purpose、logical round、roster root、scheduleを追加する。QualRootと閉鎖集合のFreezeRecordは登録Cとは別のnative recordとし、自己参照を避ける。公開順序はEXECの登録freeze、EXEC release、Original/pool freeze、PANEL releaseの順序に固定する。

すべてのconsumer、cold import、credit・eligibility、DB再実行は同じBeaconCertificateと元FreezeRecordを検査する。深いreorgで安定性仮定が破れた曝露roundを新しい対象へ使ってはならない。未成功終端と既受理救済を維持する。新suiteの有効化条件を既存のAN1 gateへ追加する。

## 採択記録への接続

ADR-0180、0185、0226、0227を過去に遡って書き換えない。新ADR-0229（提案番号）に、今回のユーザー指示、乱数役務だけの権限、PQ-onlyとの整合、未実装・未有効化、旧方式のdrainとno fallbackを記録する。MOR1等の後続設計へは、最新本文を取得・照合してから統合する。
