from pathlib import Path
import json, subprocess

scratch = Path(__file__).resolve().parent
archive = (scratch/'consensus/src/pipeline/virtual_processor/processor/positive_assignment_archive.rs').read_text()
core = (scratch/'consensus/core/src/palw_positive_assignment_case_material_v2.rs').read_text()
code = '''#![allow(dead_code)]
use borsh::{BorshDeserialize, BorshSerialize};
use misaka_palw_positive_contract::{
    ContractError, identity::{CaseId, Digest}, journal::CaseJournalRecordView,
    rows::{AcceptedMaterial, AcceptedOrigin, NativeHash64},
};
#[derive(Debug)]
enum NativeAssignmentArchiveErrorV2 { Invalid(&'static str) }
'''
code += core[core.index('pub const ASSIGNED_CASE_BOUNDARY_DOMAIN_V2'):core.index('/// Exact canonical DATA recipe')]
code += core[core.index('#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]'):core.index('    pub fn from_actual_data_v2')]
code += core[core.index('    pub fn id(&self)'):core.index('    pub fn check_populated_data')] + '}\n'
code += archive[archive.index('fn exact_case_boundary_v2'):archive.index('impl VirtualStateProcessor {')]
code += archive[archive.index('    #[test]\n    fn case_boundary_is_unique'):archive.index('    #[test]\n    fn archive_store_faults')]
source = scratch/'boundary-probe.rs'
source.write_text(code)
target = Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
fp = target/'.fingerprint'
data = json.loads((fp/'misaka-palw-positive-contract-3c6e0f32d28c41f7/lib-misaka_palw_positive_contract.json').read_text())
deps = target/'deps'
extern = {'misaka_palw_positive_contract':deps/'libmisaka_palw_positive_contract-3c6e0f32d28c41f7.rlib'}
for _, name, _, fingerprint in data['deps']:
    if name in ('borsh','blake2b_simd'):
        marker, = (m for m in fp.glob('*/lib-' + name) if m.read_text() == fingerprint.to_bytes(8,'little').hex())
        extern[name] = deps / ('lib' + name + '-' + marker.parent.name.rsplit('-',1)[-1] + '.rlib')
assert extern.keys() == {'borsh','blake2b_simd','misaka_palw_positive_contract'}
rustc = Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
cmd = [str(rustc), '--edition=2024', '--test', '-L', f'dependency={deps}', str(source), '-o', str(scratch/'boundary-probe')]
for name, path in extern.items():
    cmd.extend(['--extern', f'{name}={path}'])
subprocess.run(cmd, check=True)
subprocess.run([str(scratch/'boundary-probe')],check=True)
