#![allow(dead_code)]
use borsh::{BorshDeserialize, BorshSerialize};
use misaka_palw_positive_contract::{
    ContractError, identity::{CaseId, Digest}, journal::CaseJournalRecordView,
    rows::{AcceptedMaterial, AcceptedOrigin, NativeHash64},
};
#[derive(Debug)]
enum NativeAssignmentArchiveErrorV2 { Invalid(&'static str) }
pub const ASSIGNED_CASE_BOUNDARY_DOMAIN_V2: &[u8] = b"misaka/positive/assigned-case-native-boundary/v2/r1";
pub const ASSIGNED_CASE_INPUTS_DOMAIN_V2: &[u8] = b"misaka/positive/assigned-case-populated-inputs/v2/r1";
pub const ASSIGNED_CASE_BOUNDARY_BYTES_V2: usize = 496;
fn hash<T: BorshSerialize>(domain: &[u8], value: &T) -> Digest {
    struct Writer(blake2b_simd::State);
    impl std::io::Write for Writer {
        fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
            self.0.update(bytes);
            Ok(bytes.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    let mut writer = Writer(blake2b_simd::Params::new().hash_length(64).key(domain).to_state());
    value.serialize(&mut writer).expect("native bounded canonical data");
    Digest(writer.0.finalize().as_bytes().try_into().expect("64-byte hash"))
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct AssignmentCaseBoundaryV2 {
    pub version: u16,
    pub revision: u16,
    pub case: CaseId,
    pub origin: AcceptedOrigin,
    pub selected_parent: NativeHash64,
    /// Actual native builder state immediately BEFORE this event. Root comes
    /// from the executed prefix, never from the later current P/Case snapshot.
    pub pre_event_root: Digest,
    /// Length of the native transition delta BEFORE this event checkpoint.
    pub before_delta_end: u64,
    pub populated_inputs: Digest,
    pub input_count: u32,
    pub fee: u64,
}
impl AssignmentCaseBoundaryV2 {
    pub fn id(&self) -> Digest {
        hash(ASSIGNED_CASE_BOUNDARY_DOMAIN_V2, self)
    }
    pub fn material(&self) -> AcceptedMaterial {
        AcceptedMaterial { origin: self.origin, digest: self.id() }
    }
    pub fn decode(bytes: &[u8]) -> Result<Self, ContractError> {
        if bytes.len() != ASSIGNED_CASE_BOUNDARY_BYTES_V2 {
            return Err(ContractError::NonCanonical);
        }
        let value: Self = borsh::from_slice(bytes).map_err(|_| ContractError::NonCanonical)?;
        if value.version != 2 || value.revision != 1 {
            return Err(ContractError::Version);
        }
        if value.input_count == 0 || value.pre_event_root == Digest([0; 64]) || value.populated_inputs == Digest([0; 64]) {
            return Err(ContractError::Identity);
        }
        Ok(value)
    }
}
fn exact_case_boundary_v2(record: CaseJournalRecordView<'_>) -> Result<AssignmentCaseBoundaryV2, NativeAssignmentArchiveErrorV2> {
    use NativeAssignmentArchiveErrorV2 as E;
    let header = record.header();
    let mut found = None;
    for aux in record.aux() {
        if let Ok(boundary) = AssignmentCaseBoundaryV2::decode(aux.preimage())
            && boundary.material() == aux.material()
        {
            if boundary.case != header.case || boundary.origin != header.origin {
                return Err(E::Invalid("Case boundary scope/origin differs from literal record"));
            }
            if found.replace(boundary).is_some() {
                return Err(E::Invalid("duplicate actual Case boundary"));
            }
        }
    }
    found.ok_or(E::Invalid("missing actual Case boundary"))
}

    #[test]
    fn case_boundary_is_unique_and_scoped_to_the_literal_record() {
        use misaka_palw_positive_contract::{
            CONTRACT_REVISION, CONTRACT_VERSION,
            identity::{CaseId, ChainScope, ResultId},
            journal::{CaseJournalAux, CaseJournalEventKind, CaseJournalHeader, CaseJournalLimits, CaseJournalRecord},
            rows::NativeHash64,
        };

        let origin = AcceptedOrigin {
            accepting_block: NativeHash64([1; 64]),
            carrier_block: NativeHash64([2; 64]),
            carrier_transaction: NativeHash64([3; 64]),
            accepted_tx_ordinal: 1,
            event_ordinal: 0,
            accepted_daa: 4,
            accepted_blue_score: 5,
        };
        let case = CaseId(Digest([6; 64]));
        let boundary = AssignmentCaseBoundaryV2 {
            version: 2,
            revision: 1,
            case,
            origin,
            selected_parent: NativeHash64([7; 64]),
            pre_event_root: Digest([8; 64]),
            before_delta_end: 2,
            populated_inputs: Digest([9; 64]),
            input_count: 1,
            fee: 10,
        };
        let limits = CaseJournalLimits {
            max_record_bytes: 8192,
            max_payload_bytes: 1024,
            max_aux_entries: 4,
            max_aux_preimage_bytes: 1024,
            max_total_preimage_bytes: 4096,
            max_logical_heap_bytes: 8192,
        };
        let header = CaseJournalHeader {
            version: CONTRACT_VERSION,
            revision: CONTRACT_REVISION,
            scope: ChainScope { network: Digest([10; 64]), ruleset: Digest([11; 64]), branch: Digest([12; 64]) },
            case,
            result: ResultId(Digest([13; 64])),
            sequence: 1,
            previous: Digest([0; 64]),
            origin,
            kind: CaseJournalEventKind::NativeTransaction,
        };
        let material =
            |value: AssignmentCaseBoundaryV2| CaseJournalAux { material: value.material(), preimage: borsh::to_vec(&value).unwrap() };
        let raw = |mut aux: Vec<CaseJournalAux>| {
            aux.sort_by_key(|value| borsh::to_vec(&value.material).unwrap());
            CaseJournalRecord { header, payload: vec![9], aux }.encode(limits).unwrap()
        };
        let decode = |bytes: Vec<u8>| exact_case_boundary_v2(CaseJournalRecordView::decode(&bytes, limits).unwrap());
        assert_eq!(decode(raw(vec![material(boundary)])).unwrap(), boundary);

        let mut altered = material(boundary);
        altered.preimage[4] ^= 1;
        use NativeAssignmentArchiveErrorV2 as E;
        assert!(matches!(decode(raw(vec![altered])), Err(E::Invalid("missing actual Case boundary"))));
        let wrong_case = material(AssignmentCaseBoundaryV2 { case: CaseId(Digest([20; 64])), ..boundary });
        assert!(matches!(decode(raw(vec![wrong_case])), Err(E::Invalid("Case boundary scope/origin differs from literal record"))));
        let different_prefix = material(AssignmentCaseBoundaryV2 { before_delta_end: 3, ..boundary });
        assert!(matches!(decode(raw(vec![material(boundary), different_prefix])), Err(E::Invalid("duplicate actual Case boundary"))));
    }

