
use kaspa_hashes::Hash64;
use std::collections::BTreeMap;
type TransactionOutpoint = (Hash64, u32);
fn outpoint(hash: Hash64, index: u32) -> TransactionOutpoint { (hash, index) }
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct PalwBondKeyV2(TransactionOutpoint);
const PALW_BOND_KEY_V2_MIN: PalwBondKeyV2 = PalwBondKeyV2((Hash64::from_bytes([0; 64]), 0));
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum PalwCourtSideV1 { Challenger, Executor }
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum PalwStagedCourtKeyV1 {
    Claim(Hash64),
    Owner(Hash64, PalwBondKeyV2),
    InventoryOpen(Hash64, PalwBondKeyV2),
    Inventory(Hash64),
    /// A registered TIR class's published layout (behind `palw_staged_tir_route_v1`).
    TirLayout(Hash64),
    /// Dormant versioned TIR acquisition sidecars; not legacy Owner courts.
    TirAcquisition(Hash64, PalwBondKeyV2, Hash64),
    TirRawChunk(Hash64),
    TirAcceptedBody(Hash64),
    /// Claim-wide preparation is fixed at original acceptance, not owner Open.
    TirPreparation(Hash64, Hash64),
    /// Original versioned full-allocation TIR frame; never an old ClaimBundle.
    TirClaim(Hash64),
    /// G14 R7: a staged conviction witness being assembled, per (claim, filer).
    TirWitness(Hash64, PalwBondKeyV2),
    /// RFC-0002 02-A: a registered TIR class's bound `PALWART3` container (behind `palw_tir_container_identity_v1`).
    TirContainer(Hash64),
    /// Proposed service ledger; appended tag, no existing tag changes.
    CourtService,
    /// RFC-0028 candidate prerequisite history; appended key tag 13.
    CourtDutyClock(Hash64),
    CourtSharedContext(Hash64),
    CourtSharedQuery(Hash64),
    CourtSharedIds(Hash64),
    CourtSharedStream(Hash64),
    CourtSharedChunk(Hash64, u64),
    CourtSharedResponse(Hash64, PalwBondKeyV2),
    /// RFC-0030 isolated candidate; appended key20, no old tag changes.
    CourtEndArchive(Hash64),
    CourtCloseReceipt(Hash64, PalwCourtSideV1),
    /// Private canonical numerical root, appended key22.
    CourtSharedRoot(Hash64, u64),
    CourtSharedRound(Hash64),
    CourtSharedBottom(Hash64),
    /// RFC-0034 private provenance, appended key25.
    CourtArchiveProgress(Hash64, PalwCourtSideV1),
    /// RFC-0032 A material intake (lane material-intake), appended keys 26-29.
    /// (claim, draft): one submitter's incomplete body; never a target slot.
    CourtMaterialDraft(Hash64, Hash64),
    /// (draft, offset): one retained part of a draft.
    CourtMaterialPart(Hash64, u64),
    /// (claim, target): the first complete authenticated body.
    CourtMaterial(Hash64, Hash64),
    /// (claim, submitter): derived per-claim storage reservation.
    CourtMaterialLedger(Hash64, PalwBondKeyV2),
}
fn staged_legacy_alias_subject_v2(key: PalwStagedCourtKeyV1) -> Option<Hash64> {
    use PalwStagedCourtKeyV1::*;
    match key {
        Claim(id)
        | Owner(id, _)
        | InventoryOpen(id, _)
        | Inventory(id)
        | TirAcquisition(id, _, _)
        | TirRawChunk(id)
        | TirAcceptedBody(id)
        | TirPreparation(id, _)
        | TirClaim(id)
        | TirWitness(id, _)
        | CourtDutyClock(id)
        | CourtSharedContext(id)
        | CourtSharedQuery(id)
        | CourtSharedIds(id)
        | CourtSharedStream(id)
        | CourtSharedChunk(id, _)
        | CourtSharedResponse(id, _)
        | CourtEndArchive(id)
        | CourtCloseReceipt(id, _)
        | CourtSharedRoot(id, _)
        | CourtSharedRound(id)
        | CourtSharedBottom(id)
        | CourtArchiveProgress(id, _)
        | CourtMaterialDraft(id, _)
        | CourtMaterial(id, _)
        | CourtMaterialLedger(id, _) => Some(id),
        TirLayout(_) | TirContainer(_) | CourtService | CourtMaterialPart(..) => None,
    }
}
fn has_legacy_staged_alias_v2<V>(
    rows: &std::collections::BTreeMap<PalwStagedCourtKeyV1, V>,
    subject: Hash64,
) -> bool {
    use PalwStagedCourtKeyV1 as K;
    let exact = [
        K::Claim(subject),
        K::Inventory(subject),
        K::TirRawChunk(subject),
        K::TirAcceptedBody(subject),
        K::TirClaim(subject),
        K::CourtDutyClock(subject),
        K::CourtSharedContext(subject),
        K::CourtSharedQuery(subject),
        K::CourtSharedIds(subject),
        K::CourtSharedStream(subject),
        K::CourtSharedRound(subject),
        K::CourtSharedBottom(subject),
        K::CourtEndArchive(subject),
    ];
    if exact.iter().any(|key| rows.contains_key(key)) {
        return true;
    }
    let low = Hash64::from_bytes([0; 64]);
    let high = Hash64::from_bytes([u8::MAX; 64]);
    let first_bond = PALW_BOND_KEY_V2_MIN;
    let last_bond = PalwBondKeyV2(outpoint(high, u32::MAX));
    let first_side = PalwCourtSideV1::Challenger;
    let last_side = PalwCourtSideV1::Executor;
    [
        (K::Owner(subject, first_bond), K::Owner(subject, last_bond)),
        (K::InventoryOpen(subject, first_bond), K::InventoryOpen(subject, last_bond)),
        (K::TirAcquisition(subject, first_bond, low), K::TirAcquisition(subject, last_bond, high)),
        (K::TirPreparation(subject, low), K::TirPreparation(subject, high)),
        (K::TirWitness(subject, first_bond), K::TirWitness(subject, last_bond)),
        (K::CourtSharedChunk(subject, 0), K::CourtSharedChunk(subject, u64::MAX)),
        (K::CourtSharedResponse(subject, first_bond), K::CourtSharedResponse(subject, last_bond)),
        (K::CourtCloseReceipt(subject, first_side), K::CourtCloseReceipt(subject, last_side)),
        (K::CourtSharedRoot(subject, 0), K::CourtSharedRoot(subject, u64::MAX)),
        (K::CourtArchiveProgress(subject, first_side), K::CourtArchiveProgress(subject, last_side)),
        (K::CourtMaterialDraft(subject, low), K::CourtMaterialDraft(subject, high)),
        (K::CourtMaterial(subject, low), K::CourtMaterial(subject, high)),
        (K::CourtMaterialLedger(subject, first_bond), K::CourtMaterialLedger(subject, last_bond)),
    ]
    .into_iter()
    .any(|(first, last)| rows.range(first..=last).next().is_some())
}
use PalwStagedCourtKeyV1 as K;
    #[test]
    fn staged_alias_probes_cover_subject_namespaces_and_boundaries() {
        let subject = Hash64::from_bytes([2; 64]);
        let other = Hash64::from_bytes([3; 64]);
        let high = Hash64::from_bytes([u8::MAX; 64]);
        let bond = PalwBondKeyV2(outpoint(high, u32::MAX));
        let side = PalwCourtSideV1::Executor;
        let aliases = [
            K::Claim(subject),
            K::Owner(subject, bond),
            K::InventoryOpen(subject, bond),
            K::Inventory(subject),
            K::TirAcquisition(subject, bond, high),
            K::TirRawChunk(subject),
            K::TirAcceptedBody(subject),
            K::TirPreparation(subject, high),
            K::TirClaim(subject),
            K::TirWitness(subject, bond),
            K::CourtDutyClock(subject),
            K::CourtSharedContext(subject),
            K::CourtSharedQuery(subject),
            K::CourtSharedIds(subject),
            K::CourtSharedStream(subject),
            K::CourtSharedChunk(subject, u64::MAX),
            K::CourtSharedResponse(subject, bond),
            K::CourtEndArchive(subject),
            K::CourtCloseReceipt(subject, side),
            K::CourtSharedRoot(subject, u64::MAX),
            K::CourtSharedRound(subject),
            K::CourtSharedBottom(subject),
            K::CourtArchiveProgress(subject, side),
            K::CourtMaterialDraft(subject, high),
            K::CourtMaterial(subject, high),
            K::CourtMaterialLedger(subject, bond),
        ];
        for key in aliases {
            assert_eq!(staged_legacy_alias_subject_v2(key), Some(subject));
            let rows = BTreeMap::from([(key, ())]);
            assert!(has_legacy_staged_alias_v2(&rows, subject), "{key:?}");
            assert!(!has_legacy_staged_alias_v2(&rows, other), "{key:?}");
        }
        let rows = BTreeMap::from([
            (K::TirLayout(subject), ()),
            (K::TirContainer(subject), ()),
            (K::CourtService, ()),
            (K::CourtMaterialPart(subject, 0), ()),
        ]);
        assert!(!has_legacy_staged_alias_v2(&rows, subject));
        assert!(rows.keys().all(|&key| staged_legacy_alias_subject_v2(key).is_none()));
    }
