from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
src = root / 'consensus/core/src'
fold = (src/'palw_staged_court_fold_v1.rs').read_text()
case = (src/'palw_state_v2/positive_assignment_case.rs').read_text()
keys = (src/'palw_staged_court_state_v1.rs').read_text()
key_start = keys.index('pub enum PalwStagedCourtKeyV1')
key_end = keys.index('\n}', key_start)+2
probe = '''
use kaspa_hashes::Hash64;
use std::collections::BTreeMap;
type TransactionOutpoint = (Hash64, u32);
fn outpoint(hash: Hash64, index: u32) -> TransactionOutpoint { (hash, index) }
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct PalwBondKeyV2(TransactionOutpoint);
const PALW_BOND_KEY_V2_MIN: PalwBondKeyV2 = PalwBondKeyV2((Hash64::from_bytes([0; 64]), 0));
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum PalwCourtSideV1 { Challenger, Executor }
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
'''+keys[key_start:key_end].replace('crate::palw_state_v2::','')+'\n'
start = fold.index('pub(super) fn staged_legacy_alias_subject_v2')
end = fold.index('\n}', start)+2
probe += fold[start:end].replace('pub(super) fn','fn')+'\n'
start = case.index('fn has_legacy_staged_alias_v2')
end = case.index('\n}', start)+2
probe += case[start:end].replace('crate::palw_staged_court_state_v1::','').replace('TransactionOutpoint::new(', 'outpoint(')+'\n'
start = case.index('    #[test]\n    fn staged_alias_probes_cover_subject_namespaces_and_boundaries')
end = case.index('\n    }', start)+6
probe += 'use PalwStagedCourtKeyV1 as K;\n'+case[start:end].replace(
    '        use super::super::palw_staged_court_fold_v1::staged_legacy_alias_subject_v2;\n',''
).replace('TransactionOutpoint::new(', 'outpoint(')+'\n'
path=root/'staged-probe.rs'
path.write_text(probe)
target=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug/deps')
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
binary=root/'staged-probe'
subprocess.run([str(rustc),'--edition=2024','--test','-L',f'dependency={target}','--extern',
                f'kaspa_hashes={target}/libkaspa_hashes-763ecc08d728f51f.rlib',str(path),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
