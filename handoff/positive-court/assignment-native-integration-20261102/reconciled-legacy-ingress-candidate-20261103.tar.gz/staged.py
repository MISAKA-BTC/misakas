from pathlib import Path
import difflib

root = Path(__file__).resolve().parent
src = root / 'consensus/core/src'
fold = src / 'palw_staged_court_fold_v1.rs'
original = fold.read_text()
mapping = '''/// Subject-bearing keys in the legacy alias scan. Layout, container,
/// service, and draft-part keys use other identity namespaces.
pub(super) fn staged_legacy_alias_subject_v2(key: PalwStagedCourtKeyV1) -> Option<Hash64> {
    use PalwStagedCourtKeyV1::*;
    match key {
        Claim(id)
        | Owner(id, _)
        | InventoryOpen(id, _)
        | Inventory(id)
        | TirAcquisition(id, _, _)
        | TirRawChunk(id)
        | TirAcceptedBody(id)
        | TirPreparation(id, _)
        | TirClaim(id)
        | TirWitness(id, _)
        | CourtDutyClock(id)
        | CourtSharedContext(id)
        | CourtSharedQuery(id)
        | CourtSharedIds(id)
        | CourtSharedStream(id)
        | CourtSharedChunk(id, _)
        | CourtSharedResponse(id, _)
        | CourtEndArchive(id)
        | CourtCloseReceipt(id, _)
        | CourtSharedRoot(id, _)
        | CourtSharedRound(id)
        | CourtSharedBottom(id)
        | CourtArchiveProgress(id, _)
        | CourtMaterialDraft(id, _)
        | CourtMaterial(id, _)
        | CourtMaterialLedger(id, _) => Some(id),
        TirLayout(_) | TirContainer(_) | CourtService | CourtMaterialPart(..) => None,
    }
}

'''
point = original.index('\nimpl ')
modified = original[:point] + '\n' + mapping + original[point + 1:]
old = '        self.check_archive_progress_write_v1(&key, new.as_ref())?;'
new = '''        if new.is_some()
            && let Some(subject) = staged_legacy_alias_subject_v2(key)
        {
            self.reject_positive_claim_alias_v2(subject)?;
        }
''' + old
assert modified.count(old) == 1
modified = modified.replace(old, new)
fold.write_text(modified)
case = src / 'palw_state_v2/positive_assignment_case.rs'
before = case.read_text()
after = before.replace(
    '        for key in aliases {\n',
    '        use super::super::palw_staged_court_fold_v1::staged_legacy_alias_subject_v2;\n'
    '        for key in aliases {\n'
    '            assert_eq!(staged_legacy_alias_subject_v2(key), Some(subject));\n',
).replace(
    '        assert!(!has_legacy_staged_alias_v2(&rows, subject));\n    }\n}',
    '        assert!(!has_legacy_staged_alias_v2(&rows, subject));\n'
    '        assert!(rows.keys().all(|&key| staged_legacy_alias_subject_v2(key).is_none()));\n    }\n}',
)
assert before != after
case.write_text(after)
def diff(file, a, b):
    name = file.relative_to(root)
    return ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), f'a/{name}', f'b/{name}'))
(root/'staged-claim-ingress.patch').write_text(diff(fold, original, modified) + diff(case, before, after))
