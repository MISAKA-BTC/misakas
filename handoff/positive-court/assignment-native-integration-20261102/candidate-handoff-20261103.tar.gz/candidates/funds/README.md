# Funds candidate — not applied, not compiled

Only this candidate directory was written while the actual source was frozen.
`manifest.json` records each exact source base SHA-256 and candidate SHA-256.
`base/` preserves the source copies; `funds.patch` is a unified patch against
those copies. New files have a null base hash. No Cargo command was run.

## Proposed behavior

- A tentative spend contains an exact before row, candidate tx/DAA, constrained
  op12 payload, native-derived dues and independently conserved leg projection.
  It contains no invented accepting block, accepted receipt or FundingRow with
  an invalid synthetic `last_settlement`.
- `qualify_rooted_assignment_candidate_v2` resolves the actual current rooted
  Assignment/funding and exact bounded op12. It currently returns
  `AuthenticatedNativeMoneySessionUnavailable`: no saved P flag, integer floor,
  caller boolean, arbitrary trait or public DTO creates positive authority.
- The raw op12 hook requalifies against the current builder state, CASes the
  exact old account, and uses the actual accepted origin for the new funding
  row, native once marker, settlement rows and assignment journal. Changes use
  the existing native checkpoint; an error restores every write.
- New aux140 legs/consumer/native-UTXO debit append after all existing values.
  Native money cannot be cast to an old issuance/escrow purpose. A dormant
  once engine refuses; it is never interpreted as permission to pay.
- Worker/service/burn once subjects do not change when another funding account
  is chosen. Refund tranches bind their original actual coin, source leg and
  previous refunded total. Aux151 ordinal allocation remains global across all
  accounts for one Assignment/leg/party and scans only that bounded key prefix.
- Restore checks the exact referenced aux140 marker, native debit, amount,
  DAA, purpose and account-specific subject. This is structural checking, not
  authenticated history replay or P/service entitlement.

## Integration owned by native writer

The native-writer candidate adds `mod positive_assignment_funds` and calls
`settle_positive_assignment_raw_funds_v2(ctx, action, body)` from the raw op12
dispatch. It must reexport `qualify_rooted_assignment_candidate_v2`,
`AssignmentMoneyOwnerErrorV2` and `validate_assignment_once_reference_v2` for
the concrete candidate/restore callers.

Its generated heap inventory must append the five Assignment leg names,
`AssignmentNativeUtxo` consumer and `NativeUtxo { outpoint, amount }` debit.
This candidate contains the matching wire-scanner changes and the changed
Assignment money heap visitors. Do not overwrite the native-writer candidate's
separate `generated.rs` edits with an old complete copy.

The old `assignment_settlements` extras are not independent payment authority.
Raw actions, rederived at the correct accepted object position, are the sole
settlement writer input. A mempool/template preview must use the same concrete
current-prefix resolver and must never fabricate an accepted origin.

## Tests and remaining work

Two new unit fixtures construct a real payer transaction signature for a
partial op12 and check tentative conservation, exact payload, stale before-row,
duplicate due and wrong-leg refusal. They explicitly do not claim native service
receipt acceptance. They have not been executed or compiled. The native ordinary
script validator remains mandatory; the fixture verifies the actual signing
digest/signature rather than replacing script execution.

The real authenticated P/source/duty/liability/history session remains missing.
Original accepted policy and resource preimages must be resolved from its actual
retained history before any positive authorization is constructed. The existing
raw descriptor's current policy is only a bounded decoder input, not permission
to reinterpret an old contract. Positive C/prover settlement owners and their
corresponding native integration tests are still required.

Autonomous relay and payer-independent liveness remain unresolved. This patch
supports the money guards for an ordinary payer-signed partial op12; it adds no
script bypass, pre-signed relay registry, new funding semantics or public
activation. It is not evidence that RFC-0045 is complete.
