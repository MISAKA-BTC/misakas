//! Concrete native archive data for a current-prefix assigned Case. No cache
//! status, boolean, signature-only verdict or arbitrary source creates authority.
use super::*;
use crate::tx::{Transaction, UtxoEntry};
use crate::{
    block::BlockTransactionsV3,
    palw_native_resource_v1::{NativeCoverageV1, NativeDemandLeaseV1, NativeHeapV1},
    palw_positive_assignment_material_v2::AssignmentAdmissionMaterialV2,
    palw_positive_journal_chain_v2::CaseJournalPinV2,
};
use misaka_palw_positive_contract::{assignment::rows::AssignmentRow, identity::CaseId, rows::AcceptedOrigin};
use std::sync::Arc;

pub struct NativeAcceptedCaseCarriageV2 {
    body: BlockTransactionsV3,
    index: u32,
    entries: Vec<UtxoEntry>,
    fee: u64,
    origin: AcceptedOrigin,
    selected_parent: BlockHash,
    prefix_state: Option<Arc<crate::palw_native_resource_v1::NativeChainStateV1>>,
    _lease: NativeDemandLeaseV1,
}
impl NativeAcceptedCaseCarriageV2 {
    /// DATA constructor; production callers supply actual canonical archived
    /// carrier and revalidated populated inputs. No `Full=true` flag is stored.
    pub fn from_native_history_v2(
        body: BlockTransactionsV3,
        index: u32,
        entries: Vec<UtxoEntry>,
        fee: u64,
        origin: AcceptedOrigin,
        selected_parent: BlockHash,
        lease: NativeDemandLeaseV1,
    ) -> Result<Self, NativeAssignedCaseBackingErrorV2> {
        let tx = body.get(index as usize).ok_or(NativeAssignedCaseBackingErrorV2::Origin)?;
        if tx.id().as_bytes() != origin.carrier_transaction.0 || tx.inputs.len() != entries.len() {
            return Err(NativeAssignedCaseBackingErrorV2::Origin);
        }
        Ok(Self { body, index, entries, fee, origin, selected_parent, prefix_state: None, _lease: lease })
    }
    /// Attach an ACTUAL executed-prefix owner reconstructed by the private
    /// native delta loader. The data is independently scope/head checked by
    /// the Case factory; missing original boundary is never current-state data.
    pub fn with_native_prefix_state_v2(
        mut self,
        state: Arc<crate::palw_native_resource_v1::NativeChainStateV1>,
        expected_root: Hash64,
    ) -> Result<Self, NativeAssignedCaseBackingErrorV2> {
        if self.prefix_state.is_some() || state.state_root() != expected_root {
            return Err(NativeAssignedCaseBackingErrorV2::Origin);
        }
        self.prefix_state = Some(state);
        Ok(self)
    }
    pub fn prefix_state(&self) -> Result<&PalwChainStateV2, NativeAssignedCaseBackingErrorV2> {
        self.prefix_state.as_ref().map(|state| &***state).ok_or(NativeAssignedCaseBackingErrorV2::Unavailable)
    }
    pub fn transaction(&self) -> &Transaction {
        &self.body[self.index as usize]
    }
    pub fn entries(&self) -> &[UtxoEntry] {
        &self.entries
    }
    pub fn fee(&self) -> u64 {
        self.fee
    }
    pub fn origin(&self) -> AcceptedOrigin {
        self.origin
    }
    pub fn selected_parent(&self) -> BlockHash {
        self.selected_parent
    }
}
pub struct NativeCommittedCaseRecordV2 {
    raw: Vec<u8>,
    carriage: NativeAcceptedCaseCarriageV2,
}
impl NativeCommittedCaseRecordV2 {
    pub fn from_native_history_v2(raw: Vec<u8>, carriage: NativeAcceptedCaseCarriageV2) -> Self {
        Self { raw, carriage }
    }
    pub fn raw(&self) -> &[u8] {
        &self.raw
    }
    pub fn carriage(&self) -> &NativeAcceptedCaseCarriageV2 {
        &self.carriage
    }
}
/// Complete rooted Assignment control history (Open/Bind/Join/Cancel/etc.).
/// Each carriage retains its actual executed prefix, so role eligibility is
/// resolved as of the historical event rather than from final retired flags.
pub struct NativeCommittedAssignmentRecordV2 {
    raw: Vec<u8>,
    carriage: NativeAcceptedCaseCarriageV2,
}
impl NativeCommittedAssignmentRecordV2 {
    pub fn from_native_history_v2(raw: Vec<u8>, carriage: NativeAcceptedCaseCarriageV2) -> Self {
        Self { raw, carriage }
    }
    pub fn raw(&self) -> &[u8] {
        &self.raw
    }
    pub fn carriage(&self) -> &NativeAcceptedCaseCarriageV2 {
        &self.carriage
    }
}
pub struct NativeCommittedAssignedCaseV2 {
    parent: BlockHash,
    parent_state_root: Hash64,
    assignment: AssignmentRow,
    material: AssignmentAdmissionMaterialV2,
    open_raw: Vec<u8>,
    open_carriage: NativeAcceptedCaseCarriageV2,
    pin: CaseJournalPinV2,
    records: Vec<NativeCommittedCaseRecordV2>,
    assignment_records: Vec<NativeCommittedAssignmentRecordV2>,
    _lease: NativeDemandLeaseV1,
}
impl NativeCommittedAssignedCaseV2 {
    #[allow(clippy::too_many_arguments)]
    pub fn from_native_archive_v2(
        parent: BlockHash,
        parent_state_root: Hash64,
        assignment: AssignmentRow,
        material: AssignmentAdmissionMaterialV2,
        open_raw: Vec<u8>,
        open_carriage: NativeAcceptedCaseCarriageV2,
        pin: CaseJournalPinV2,
        records: Vec<NativeCommittedCaseRecordV2>,
        assignment_records: Vec<NativeCommittedAssignmentRecordV2>,
        lease: NativeDemandLeaseV1,
    ) -> Self {
        Self {
            parent,
            parent_state_root,
            assignment,
            material,
            open_raw,
            open_carriage,
            pin,
            records,
            assignment_records,
            _lease: lease,
        }
    }
    pub fn parent(&self) -> BlockHash {
        self.parent
    }
    pub fn parent_state_root(&self) -> Hash64 {
        self.parent_state_root
    }
    pub fn assignment(&self) -> &AssignmentRow {
        &self.assignment
    }
    pub fn material(&self) -> &AssignmentAdmissionMaterialV2 {
        &self.material
    }
    pub fn open_raw(&self) -> &[u8] {
        &self.open_raw
    }
    pub fn open_carriage(&self) -> &NativeAcceptedCaseCarriageV2 {
        &self.open_carriage
    }
    pub fn pin(&self) -> &CaseJournalPinV2 {
        &self.pin
    }
    pub fn records(&self) -> &[NativeCommittedCaseRecordV2] {
        &self.records
    }
    pub fn assignment_records(&self) -> &[NativeCommittedAssignmentRecordV2] {
        &self.assignment_records
    }
}
pub enum NativeAssignedCaseBackingV2 {
    /// This says only that the exact parent had no Case. A current-prefix Case
    /// requires a genuine earlier op9 and its unpublished Case record; an empty
    /// committed history cannot be inferred from this variant.
    AbsentAtParent {
        case: CaseId,
        parent: BlockHash,
        parent_state_root: Hash64,
    },
    Committed(NativeCommittedAssignedCaseV2),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum NativeAssignedCaseBackingErrorV2 {
    Unavailable,
    Origin,
    MissingCommittedMaterial,
    Shape,
    NativeResource(crate::palw_native_resource_v1::NativeCoverageV1),
}
impl NativeHeapV1 for NativeAcceptedCaseCarriageV2 {
    fn native_heap_v1(&self, path: &str) -> NativeCoverageV1 {
        let Self { body, index: _, entries, fee: _, origin: _, selected_parent: _, prefix_state, _lease: _ } = self;
        body.native_heap_v1(path).add::<Self>(entries.native_heap_v1(path), path).add::<Self>(prefix_state.native_heap_v1(path), path)
    }
}
impl NativeHeapV1 for NativeCommittedCaseRecordV2 {
    fn native_heap_v1(&self, path: &str) -> NativeCoverageV1 {
        let Self { raw, carriage } = self;
        raw.native_heap_v1(path).add::<Self>(carriage.native_heap_v1(path), path)
    }
}
impl NativeHeapV1 for NativeCommittedAssignedCaseV2 {
    fn native_heap_v1(&self, path: &str) -> NativeCoverageV1 {
        let Self {
            parent: _,
            parent_state_root: _,
            assignment,
            material,
            open_raw,
            open_carriage,
            pin: _,
            records,
            assignment_records,
            _lease: _,
        } = self;
        assignment
            .native_heap_v1(path)
            .add::<Self>(material.native_heap_v1(path), path)
            .add::<Self>(open_raw.native_heap_v1(path), path)
            .add::<Self>(open_carriage.native_heap_v1(path), path)
            .add::<Self>(records.native_heap_v1(path), path)
            .add::<Self>(assignment_records.native_heap_v1(path), path)
    }
}
impl NativeHeapV1 for NativeAssignedCaseBackingV2 {
    fn native_heap_v1(&self, path: &str) -> NativeCoverageV1 {
        match self {
            Self::AbsentAtParent { case: _, parent: _, parent_state_root: _ } => NativeCoverageV1::zero(),
            Self::Committed(value) => value.native_heap_v1(path),
        }
    }
}

impl NativeHeapV1 for NativeCommittedAssignmentRecordV2 {
    fn native_heap_v1(&self, path: &str) -> NativeCoverageV1 {
        let Self { raw, carriage } = self;
        raw.native_heap_v1(path).add::<Self>(carriage.native_heap_v1(path), path)
    }
}
