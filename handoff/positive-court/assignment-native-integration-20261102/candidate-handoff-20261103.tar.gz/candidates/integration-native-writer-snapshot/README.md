# Native raw-action interleave candidate

Status: candidate files only, prepared 2026-11-03 JST. No Cargo or source mutation. This is not accepted native Assignment/Case execution or RFC-0045 completion.

`base-sha256.json` pins every existing source input. `files/` contains complete candidate files; `native-writer.patch` is the corresponding unified patch. `actual-source-unchanged.json` verifies all ten source inputs remained byte-identical at generation. `candidate-manifest.json` records candidate hashes and diff sizes.

## Actual path implemented by the candidate

The actual Full-validator companion moves original block transactions, validated entries, fee, actual accepted origin/ordinal, selected parent and the final composed own-output UTXO into `PositiveAssignmentRawActionV2`. It retains original transport and new real decode/owner leases. Native inputs remain data, not a prepared admission or saved success.

The private accepted-object rehearsal walks raw actions before each actual carrier ordinal against the current retained state. Rejected legacy objects do not contribute a final object slot. Every attempted raw action records its `before_object` slot; trailing actions are attempted after the last object. Semantic Assignment refusals leave ordinary accepted transactions alone, while native resource failure propagates for retry. Empty actions delegate the existing old rehearsal directly.

The final canonical builder interleaves those same raw inputs at those slots and scans/decodes/resolves each again inside `try_checkpoint`/`restore`. It never installs rows saved by the rehearsal. The schedule checks monotonically increasing native ordinals, rejects backward object slots or a slot after the final prefix, and retains real raw allocation owners throughout execution. The existing empty-schedule object loop is preserved.

Operations8–13 reach one concrete Core raw hook. Current unsigned scope/policy/preimage/registry/nonce/work-role checks use the current builder prefix. Initial metadata construction and role crypto are deliberately not performed from an unreserved resource shape. The missing native pending-fraud/complete reservation, original material/Case, joined duties and role funding owners are explicit refusals. Op12 calls the funds candidate's concrete current-prefix resolver and same-checkpoint writer. Tentative UTXO preview plans are not transferred as settlement authority; a nonempty deprecated preview extras field is rejected.

The existing A/C output collision writer now checks kind18 joined prover accounts as well as A and C, bonds and legacy escrows. Native once visitors include the funds candidate's new purpose-specific debit/consumer/legs.

## Merge dependencies

Combine the parent/root candidate first: complete `AssignmentNativePreimagesV2` includes `assignment_fees`, `physical`, `source_policy`, `case_fees`, `cancellation`, all fixed finite preimages. The raw rules descriptor copies the original complete effective rule scope, Assignment and Positive policies and native prompt form; it does not deserialize full Params or replace a signed ancestor with the current tip.

Combine the funds candidate's `palw_state_v2/positive_assignment_funds.rs`, Core funds projection/authorization changes, settlement-once types and wire visitors. Parent module registration/reexports and the exact op12 dispatch call are included here. Getter API: `action.transaction()`, `entries()`, `fee()`, `origin()`, `selected_parent()`, `current_output()`, `rules()`; rules provide `body_limits()`, `assignment_policy()`, `positive_policy()`, `native_preimages()`, `rule_scope()`, `network()`, `prompt_form()`.

Combine the rows candidate's admission-material/Open wrapper and complete native journal retention. The new raw type does not manufacture a material receipt or accepted capability. Original policy/material reconstruction still requires authenticated actual accepted bytes and independent native derivation.

## Verification and remaining work

Rustfmt parsed all complete candidate files with children skipped. Four candidate structural tests cover an actual raw-hook semantic refusal restoring exact state bytes/no delta, reverse native ordinals, a backward object slot, and old-wrapper no-drop. They intentionally use dummy script data and real local typed leases and are not Full native acceptance or funding tests. They have not been compiled or run.

The private writer still cannot admit A/C while complete all-branch/P/service/custody owners are missing. The genuine reserved construction owner is now connected: actual current-prefix registry/job/source derivation and three native role signatures run under its retained lease, with independent literal layout workspace. Real accepted carrier/node tests, all branch accounting, native selected-verifier P, real funded joins, settlement entitlement replay, DB reopen/IBD/reorg and all retained material through the same UTXO commit batch remain required.

## Retained transition material outcome and same-batch stage

The candidate now includes `positive_assignment_materials.rs`, an ephemeral output separate from canonical state/delta. A new versioned `apply_palw_transition_retained_v8` returns state, delta, legacy merged skips and a fourth `NativeRetainedV1<PositiveAssignmentMaterialOutcomeV2>`. Empty actions delegate the exact old v7 wrapper/output split. V7 rejects new raw action input and cannot silently drop nonempty material.

The builder reserves typed record slots before actions and raw buffers before encode. Only its checkpoint writer can emit a nonempty record. Emission binds actual active origin and literal native body; Open parses the distinct retained material/custody wrapper and compares its embedded op8 to the actual carrier. Records carry delta watermarks; restore drops unpublished records with reverted row entries. Final validation requires exactly one retained preimage for each new frame and an atomic matching head/Assignment event, and conversely rejects a record with no matching delta. Rehearsal validates and discards local records; final rerun creates its own actual records.

The transition construction ticket splits all four retained outputs before releasing its aggregate lease. The processor holds the material outcome plus tracked store ticket through the same existing WriteBatch as UTXO diff, state root and delta. `stage_positive_assignment_material_outcome_v2` derives exact checked storage/work/batch bounds from the actual output and delta, then calls the existing journal stager under the same PALW store write guard. Empty material cannot stage a new Assignment mutation. The funds op12 candidate was updated, with parent authorization, to emit the actual literal op12 after frame/head/account updates inside its checkpoint.

Two genuine RocksDB candidate tests add typed empty-outcome no-drop and same staged journal/UTXO/state marker batch-abort checks. Existing positive store commit/reopen coverage remains. These are storage integrity tests, not actual accepted Assignment or computation/credit tests. The four Core structural candidate tests remain unrun. Rustfmt parsed candidate files; no Cargo was invoked.

Remaining owner requirement: op12's body frame cap may be smaller than an earlier Open wrapper. The authenticated original session must supply the retained original predecessor/record cap, not borrow a later policy or invent an unlimited storage bound. Complete immutable admission reconstruction, all-branch/P/native service ownership and real accepted-node regressions remain incomplete; current missing owners produce no accepted rows or journal output.

Public presets remain None and production activation remains unapproved.
