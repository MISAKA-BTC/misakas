# Real pre-allocation owner candidate — 2026-11-03

Candidate only; no actual Rust source or Cargo execution was changed. `files/` contains4 complete files. `derivation-owner.patch` includes the change against the handed-off root resources candidate plus actual-base changes; it requires root's resources candidate first. `actual-base-only.patch` contains the2 actual-base modifications and new child module and passed `git apply --check` against the frozen checkout. Base/output SHA256 maps and copied bases are included. All4 candidate files were parsed/formatted by direct rustfmt, not compiled or tested.

The root candidate `candidates/root/consensus/core/src/palw_positive_assignment_resources_v2.rs` was edited directly with parent authorization and is mirrored under `files/`. It now adds the owner child module, explicit resource/cap/missing-lease error variants, checks Positive.funding_schedule_id against Assignment.case_fee_schedule, and changes the class raw-program clone from `Arc<Vec<u8>>` to an actual bounded owned `Vec<u8>`.

## API and lifetime

`ReservedAssignmentDerivedResourcesV2::derive(state, terms, layout, assignment_policy, positive_policy, source_policy, original_network_prompt_form, physical_max_heap_bytes)` obtains a typed predecode quote from actual registered program bytes and ORIGINAL registered max context. Before any program decode, class/layout clone, inventory construction, prompt generation or CoveragePlan, it calls the actual `reserve_native_requests_v1(total)` and requires `Some(NativeDemandLeaseV1)`. `None` returns `MissingNativeLease`; local reservation errors remain `Native(NativeCoverageV1)`; agreed policy/physical caps return `ConstructionCap`; semantic input/geometry errors keep their original variants.

The struct has private owned resources, quote and lease fields, in that drop order. It exposes `resources(&self)` and a copied allocation quote only; no Clone/Deserialize/DerefMut/into_inner/lease extraction exists. Borrowed output cannot outlive the owner. A caller that deliberately deep-clones a borrowed public DTO is creating a new allocation and needs its own owner; this API never transfers existing owned resources without their lease.

The caller must already retain the separately admitted literal layout/native transport owner. The nativewriter must keep this owner alive through all uses of its derived data and include the construction quote in the actual A money/heap accounting. The memory owner grants no accepted provenance, role eligibility, funding, P approval, future Case service, future replay custody or credit. Full all-branch resource and pending-fraud ownership remain separately unresolved.

## Audited typed requests

- Uses `source_tir_program_shape_v1`'s narrow normal-form typed program/validator profile, never the wider generic program requests containing unused cone/gate analyses.
- Names the retained source program, final CoveragePlan program and one temporary metadata/StepSpace decode validator separately; temporary/final StepSpace shapes use the existing audited helper.
- Adds `native_tir_inventory_index_requests_v1` INSIDE `palw_tir_court_v1`, where private `ParamIndexV1` is visible: exact retained params, both actual parameter-instance passes, `Vec<BTreeSet<u8>>`, per-param/block BTree node envelopes, outer layer vectors and independently growing/minimum-capacity inner vectors. Exposes the existing shape parameter-count getter in production without changing its meaning or encoded shape.
- Accounts the actual owned raw class program, class/final/temporary layout clones, existing Borsh layout writer, canonical prompt Vec, flat CanonicalWriter or Merkle leaf/current/next typed Hash64 vectors and tile/step-leaf writer scratch, retained job network buffers, context writer, fixed policy writer and inline owners. Multiplication/addition uses `TirNativeRequestsV1`, with each independent Vec's own minimum/growth policy.
- Known wide logits are refused BEFORE distinct profiled metadata allocation, matching the existing ExactStream CoveragePlan rejection. The suffix is deny-only; it does not authenticate any profile. Original canonical context/CU/tokenizer semantics are unchanged.

## Candidate regressions

`allocation::tests`:3 unit tests cover exact cap/refusal, mandatory Some lease, prompt/Hash64 scratch overflow/minimum behavior and a quote derived from a real existing tiny registered TIR fixture with required−1 and exact-required caps. `assignment_inventory_allocation_tests_v2`:2 unit tests cover independent per-param minima/reader fanout/overflow and bounding the actual retained private inventory allocation. None has been compiled or run.
