# Original admission material candidate — 2026-11-03

Candidate only. No actual Rust source was changed for this step. No Cargo invocation or passing test is claimed. All candidate Rust files were parsed/formatted with direct rustfmt. The running focused tests still refer to their independently frozen actual source snapshot.

`files/` contains complete candidate files; `rows-recovery.patch` is their unified patch against the saved `base/` files. `base-sha256.json` pins each existing base file (null means new file), `candidate-sha256.json` pins outputs. Root must merge concurrent candidate edits to module registration, NativeHeap inventory and restore calls rather than blindly replacing shared files. Root-owned dependencies are pinned separately in `dependencies-sha256.json`.

## Purpose and custody

`AssignmentAdmissionMaterialV2` is a fixed Borsh value retaining full original Assignment and Positive policies, typed native source/fee/physical/cancellation preimages, actual Gate C policy, original network/class prompt forms, the complete fixed canonical job descriptor, registered class/artifact/program/layout/tokenizer descriptor, full source and A money quote descriptors, original scope/origin and actual rooted reservation/liability references. It never contains a Result, output, Case or saved court/P verdict. The original native network bytes are fixed-bounded to 64; longer future job networks need an explicit retained codec revision.

`AssignmentRow.admission_material` binds the full material identity and original accepted origin. The registered descriptor gets its own purpose hash and must equal `row.registered_metadata`. These are fixed references within the unreleased new kind10 schema; kinds0–9, all existing r1 IDs and key142/value16384 ceilings are preserved. No additional aux kind is allocated.

The Open journal payload uses distinct internal magic `PC2AOPEN`, version/revision2/1, a bounded fixed-material extent, a bounded literal native op8 extent, and two fixed named custody-preimage extents (reservation and liability). It cannot be mistaken for the literal `[2,0,1,0,8]` transaction body. The unchanged425-byte journal header hashes the entire wrapper. The actual accepted transaction lookup MUST compare the inner native body byte-for-byte with the accepted carrier; wrapper provenance is not inferred from a manifest.

The wrapper parser borrows slices and checks every extent/aggregate before any Core material or native body decoding. Typed policies avoid opaque digest-to-policy lookups. The custody byte digests only preserve identity; the concrete native custody owner must independently decode their exact original purpose/domain, verify actual rooted receipts and restore real capacity. Local NativeDemandLease identifiers are excluded from consensus material.

An exhaustive NativeHeap field inventory and NativeWireScan preflight cover the fixed material and its complete fixed nested types before Borsh decoding; extra heap is rejected. Future field additions cannot silently introduce an unbounded collection decoder. The fixed material decoder authenticates original row IDs, full policy IDs, prices, quote and custody clocks. It never reads current Params. `check_derivation` compares independently reconstructed full native job/registered descriptor/source quote; callers must not copy manifest fields into their expected native values. Actual current state generation, accepted prefix/lineage, role signatures, registry history, real UTXOs and P/fraud/source ownership remain private native VP checks. Missing original material is unavailable; no empty/default or current-policy fallback exists.

Material and wrapper bytes must be included in original retained/replay/heap quotes. The candidate checks minimum material/wrapper accounting; full canonical rows/history/candidate/P/work reservations remain the complete native owner's responsibility. Frozen policy retention cannot by itself resolve the existing unbounded pending-fraud branch.

## Merge dependencies

1. Root's `palw_positive_assignment_resources_v2.rs` and extended `AssignmentNativePreimagesV2` candidate are required; their typed source/fee/cancellation fields, including the complete seven-rate AssignmentWorkScheduleV2, are used directly. Root's preimage type already derives both Borsh traits, so this candidate deliberately does not replace that owned file.
2. PositiveCourtPolicyV2 adds only BorshDeserialize for its existing fixed fields; existing encoded bytes remain unchanged.
3. Funds candidate exports `palw_state_v2::validate_assignment_once_reference_v2`. This candidate calls it from structural settlement restore to bind actual aux140 markers; it does not generate markers or assume receipt authority.
4. Writer rawaction must create material from its actual native facts, independently validate literal op8/three role signatures/derived catalog and prices, preserve concrete custody preimages, create the wrapper and fixed ref, and stage wrapper plus rows in the SAME native DB batch.
5. Writer/recovery factories should use original retained network prompt form and policies when reconstructing old assignments. Current intake eligibility and actual fresh-C funds remain separate current-prefix checks.

## Tests prepared

- Existing contract `assignment_rows` fixtures become distinct Open wrappers and include the new fixed reference.
- Existing actual RocksDB integrity tests use the same distinct wrapper, remaining data-only rather than native acceptance claims.
- New dedicated `consensus/core/tests/positive_assignment_material_v2.rs` target has3 data tests for later-policy substitution, source-of-bytes/custody corruption and missing material, retention shortening, fixed bounds/trailing bytes, and original job/profile changes.

The separate `derivation/` package now supplies the real pre-allocation owner for the root resources candidate; retain that owner while deriving/using job/source/plan outputs. Its additional files and source bases are separately pinned and have not been compiled or run.

These tests have not been compiled or run. They do not establish full native readiness or public activation.

Assigned Result reverse-Use restore additionally requires role_assignment exactly `{origin: A.origin, digest: A.id().0}`. This new-use convention changes no old0–9 codec bytes or ID; pointer identity alone grants no role or acceptance authority. The full original job binds job.job_id to A.id; job.assignment_id and CU remain the original canonical TIR yardstick values, retained and compared independently.
