//! Rebuildable native indexes. No canonical bytes, saved verdict or new pool cap.
//! A snapshot/import scans its actual primary maps once. Thereafter P reads are
//! independent of old S/K/V rows and registry draws never visit zero/retired bonds.
use super::*;
use crate::{
    palw_kernel_route_v1::palw_kernel_bond_id_v1,
    palw_native_resource_v1::{NativeCoverageV1, NativeDemandLeaseV1, NativeHeapV1, TirNativeRequestsV1, reserve_native_requests_v1},
    palw_positive_certification_v2::{PositiveCertificationFixedV2, PositiveCertificationVoteV2, MAX_POSITIVE_DRAW_POSITIONS_V2, MAX_POSITIVE_CERTIFICATION_ROW_BYTES_V2},
};
use borsh::{BorshDeserialize, BorshSerialize};
use misaka_palw_positive_contract::{certification::PositiveCourtVerdictV2, identity::Digest};
use std::sync::Arc;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct PositiveIndexedVerifierV2 {
    pub bond: PalwBondKeyV2,
    pub operator: [u8;64],
    pub registered_daa: u64,
    pub collateral: u64,
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct PositiveIndexBuildWorkV2 {
    pub primary_bond_visits: u64,
    pub primary_aux_visits: u64,
    pub p_vote_visits: u64,
    pub copied_index_entries: u64,
}
struct ReservedPositiveIndexV2 {
    verifiers: BTreeMap<[u8;64], PositiveIndexedVerifierV2>,
    subjects: BTreeSet<Digest>,
    liabilities: BTreeMap<PalwBondKeyV2,u128>,
    work: PositiveIndexBuildWorkV2,
    // All allocations above drop before their real memory owner.
    _lease: NativeDemandLeaseV1,
}
#[derive(Clone, Default)]
pub(crate) struct PositiveNativeIndexV2 {
    // None is permitted only on an old/no-P path before its first actual native
    // constructor. p_present prevents an unavailable cache from clearing money.
    p_present: bool,
    data: Option<Arc<ReservedPositiveIndexV2>>,
}
impl std::fmt::Debug for PositiveNativeIndexV2 {
    fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result {
        f.debug_struct("PositiveNativeIndexV2").field("p_present",&self.p_present)
            .field("entries",&self.data.as_ref().map(|d|(d.verifiers.len(),d.subjects.len(),d.liabilities.len()))).finish()
    }
}
// This is a derived cache exactly like KernelLedgerCacheV1: canonical state
// equality is independent of local owner/cache readiness. consistency() below
// compares actual index contents against the primary facts when it is present.
impl PartialEq for PositiveNativeIndexV2 { fn eq(&self,_:&Self)->bool {true} }
impl Eq for PositiveNativeIndexV2 {}
impl NativeHeapV1 for PositiveNativeIndexV2 {
    fn native_heap_v1(&self,path:&'static str)->NativeCoverageV1 {
        let Some(d)=&self.data else {return NativeCoverageV1::Bounded{bytes:0}};
        let bytes=d.verifiers.native_heap_v1(path).add::<Self>(d.subjects.native_heap_v1(path),path)
            .add::<Self>(d.liabilities.native_heap_v1(path),path);
        bytes.add::<Self>(NativeCoverageV1::Bounded{bytes:(std::mem::size_of::<ReservedPositiveIndexV2>()+2*std::mem::size_of::<usize>()) as u64},path)
    }
}
impl NativeHeapV1 for PositiveIndexedVerifierV2 {
    fn native_heap_v1(&self,_:&'static str)->NativeCoverageV1 {NativeCoverageV1::Bounded{bytes:0}}
}
fn invalid(why:&'static str)->PalwStateV2Error {PalwStateV2Error::KernelRouteRefused(why.into())}
fn missing()->PalwStateV2Error {PalwStateV2Error::NativeContextUnavailable(crate::palw_source_bootstrap_v1::PalwSourceBootstrapContextFaultV1::HistoryUnavailable)}
fn index_lease(verifiers:u64,subjects:u64,liabilities:u64)->Result<NativeDemandLeaseV1,PalwStateV2Error> {
    use crate::palw_native_resource_v1::typed::BTreeNodeEnvelopeV1;
    let mut q=TirNativeRequestsV1::new();
    q.exact_v1::<BTreeNodeEnvelopeV1<[u8;64],PositiveIndexedVerifierV2>>(verifiers).map_err(PalwStateV2Error::NativeResource)?;
    q.exact_v1::<BTreeNodeEnvelopeV1<Digest,()>>(subjects).map_err(PalwStateV2Error::NativeResource)?;
    q.exact_v1::<BTreeNodeEnvelopeV1<PalwBondKeyV2,u128>>(liabilities).map_err(PalwStateV2Error::NativeResource)?;
    q.exact_v1::<ReservedPositiveIndexV2>(1).map_err(PalwStateV2Error::NativeResource)?;
    q.exact_v1::<usize>(2).map_err(PalwStateV2Error::NativeResource)?;
    q.exact_v1::<PositiveCertificationFixedV2>(2).map_err(PalwStateV2Error::NativeResource)?;
    q.exact_v1::<PositiveCertificationVoteV2>(2).map_err(PalwStateV2Error::NativeResource)?;
    reserve_native_requests_v1(q.bytes_v1()).map_err(PalwStateV2Error::NativeResource)?.ok_or_else(missing)
}
fn verifier(key:&PalwBondKeyV2,b:&PalwBondStateV2)->Option<PositiveIndexedVerifierV2> {
    (matches!(b.status,PalwBondStatusV2::Active)&&b.collateral>0).then_some(PositiveIndexedVerifierV2{
        bond:*key,operator:b.operator_id.as_bytes(),registered_daa:b.registered_daa,collateral:b.collateral,
    })
}
/// Borrowed, fixed-size projection. All vector counts are finite before any
/// iteration; no P Vec is decoded. Missing/corrupt bytes never become no debt.
fn p_liabilities(bytes:&[u8],mut visit:impl FnMut(PalwBondKeyV2,u128)->Result<(),PalwStateV2Error>)->Result<u64,PalwStateV2Error> {
    if bytes.len()>MAX_POSITIVE_CERTIFICATION_ROW_BYTES_V2 {return Err(invalid("P index row cap"))}
    let mut raw=bytes;
    let fixed=PositiveCertificationFixedV2::deserialize(&mut raw).map_err(|_|invalid("P index fixed codec"))?;
    fixed.header.validate().map_err(|_|invalid("P index original policy"))?;
    let draw=u8::deserialize(&mut raw).map_err(|_|invalid("P index draw"))?;
    if draw==1 {
        crate::palw_positive_certification_v2::PositiveCertificationDrawMetaV2::deserialize(&mut raw).map_err(|_|invalid("P index draw meta"))?;
        let n=u32::deserialize(&mut raw).map_err(|_|invalid("P index positions"))?;
        if n>u32::from(fixed.header.policy.m)||n>u32::from(MAX_POSITIVE_DRAW_POSITIONS_V2){return Err(invalid("P index positions cap"))}
        let len=(n as usize).checked_mul(64).ok_or_else(||invalid("P index extent"))?;
        raw=raw.get(len..).ok_or_else(||invalid("P index positions extent"))?;
    } else if draw!=0 {return Err(invalid("P index draw tag"))}
    let n=u32::deserialize(&mut raw).map_err(|_|invalid("P index vote count"))?;
    if n>u32::from(fixed.header.policy.m)||n>u32::from(MAX_POSITIVE_DRAW_POSITIONS_V2){return Err(invalid("P index vote cap"))}
    for _ in 0..n {
        let vote=PositiveCertificationVoteV2::deserialize(&mut raw).map_err(|_|invalid("P index vote codec"))?;
        if fixed.liability_release.is_none() && vote.statement.verdict==PositiveCourtVerdictV2::PositiveChecked {
            let point=PalwBondKeyV2(TransactionOutpoint::new(Hash64::from_bytes(vote.bond.transaction.0),vote.bond.index));
            visit(point,u128::from(vote.liability_amount))?;
        }
    }
    if !raw.is_empty(){return Err(invalid("P index trailing bytes"))}
    Ok(u64::from(n))
}
impl PositiveNativeIndexV2 {
    pub(crate) fn ready(&self)->bool {self.data.is_some()}
    pub(crate) fn subjects(&self)->Result<impl Iterator<Item=&Digest>,PalwStateV2Error> {
        self.data.as_ref().map(|d|d.subjects.iter()).ok_or_else(missing)
    }
    pub(crate) fn verifiers(&self)->Result<impl Iterator<Item=(&[u8;64],&PositiveIndexedVerifierV2)>,PalwStateV2Error> {
        self.data.as_ref().map(|d|d.verifiers.iter()).ok_or_else(missing)
    }
    pub(crate) fn liability(&self,key:&PalwBondKeyV2)->u128 {
        match &self.data {Some(d)=>d.liabilities.get(key).copied().unwrap_or(0),None if self.p_present=>u128::MAX,None=>0}
    }
    pub(crate) fn build_work(&self)->Option<PositiveIndexBuildWorkV2>{self.data.as_ref().map(|d|d.work)}
    pub(crate) fn rebuild(state:&PalwChainStateV2)->Result<Self,PalwStateV2Error> {
        let mut work=PositiveIndexBuildWorkV2{primary_bond_visits:state.bonds.len() as u64,primary_aux_visits:state.kernel_route.as_ref().map_or(0,|r|r.aux.len() as u64),..Default::default()};
        // First borrowed count pass allocates nothing. Its actual work counts
        // must be admitted by the enclosing snapshot/transition work owner.
        let count=state.bonds.values().filter(|b|matches!(b.status,PalwBondStatusV2::Active)&&b.collateral>0).count() as u64;
        let mut subjects=0u64;let mut positive_votes=0u64;
        if let Some(route)=&state.kernel_route {for ((table,key),raw) in &route.aux {
            if *table!=136||key.first()!=Some(&b'P'){continue}
            if key.len()!=65{return Err(invalid("P index key cap"))}
            subjects=subjects.checked_add(1).ok_or_else(||invalid("P index count"))?;
            work.p_vote_visits=work.p_vote_visits.checked_add(p_liabilities(raw,|_,_|{positive_votes=positive_votes.checked_add(1).ok_or_else(||invalid("P index vote total"))?;Ok(())})?).ok_or_else(||invalid("P index work count"))?;
        }}
        let owner=index_lease(count,subjects,positive_votes)?;
        let mut d=ReservedPositiveIndexV2{verifiers:BTreeMap::new(),subjects:BTreeSet::new(),liabilities:BTreeMap::new(),work,_lease:owner};
        for (key,b) in &state.bonds {if let Some(v)=verifier(key,b) {
            if d.verifiers.insert(palw_kernel_bond_id_v1(key),v).is_some(){return Err(invalid("distinct native bonds share a kernel identity"))}
        }}
        if let Some(route)=&state.kernel_route {for ((table,key),raw) in &route.aux {
            if *table!=136||key.first()!=Some(&b'P'){continue}
            d.subjects.insert(Digest(key[1..].try_into().map_err(|_|invalid("P index key"))?));
            p_liabilities(raw,|bond,amount|{let old=d.liabilities.get(&bond).copied().unwrap_or(0);d.liabilities.insert(bond,old.checked_add(amount).ok_or_else(||invalid("P liability sum"))?);Ok(())})?;
        }}
        Ok(Self{p_present:!d.subjects.is_empty(),data:Some(Arc::new(d))})
    }
    fn copied(&self,add_verifiers:u64,add_subjects:u64,add_liabilities:u64)->Result<ReservedPositiveIndexV2,PalwStateV2Error>{
        let d=self.data.as_ref().ok_or_else(missing)?;
        let owner=index_lease((d.verifiers.len() as u64).checked_add(add_verifiers).ok_or_else(||invalid("index size"))?,(d.subjects.len() as u64).checked_add(add_subjects).ok_or_else(||invalid("index size"))?,(d.liabilities.len() as u64).checked_add(add_liabilities).ok_or_else(||invalid("index size"))?)?;
        Ok(ReservedPositiveIndexV2{verifiers:d.verifiers.clone(),subjects:d.subjects.clone(),liabilities:d.liabilities.clone(),work:PositiveIndexBuildWorkV2{copied_index_entries:(d.verifiers.len()+d.subjects.len()+d.liabilities.len()) as u64,..Default::default()},_lease:owner})
    }
    pub(crate) fn with_bond(&self,key:&PalwBondKeyV2,new:Option<&PalwBondStateV2>)->Result<Self,PalwStateV2Error>{
        let Some(existing)=&self.data else {return Ok(self.clone())};
        let id=palw_kernel_bond_id_v1(key);let next=new.and_then(|b|verifier(key,b));
        if existing.verifiers.get(&id).copied()==next{return Ok(self.clone())}
        if existing.verifiers.get(&id).is_some_and(|v|v.bond!=*key){return Err(invalid("kernel bond identity collision"))}
        let mut d=self.copied(u64::from(next.is_some()),0,0)?;
        match next {Some(v)=>{d.verifiers.insert(id,v);},None=>{d.verifiers.remove(&id);}}
        Ok(Self{p_present:self.p_present,data:Some(Arc::new(d))})
    }
    pub(crate) fn with_p(&self,key:&[u8],old:Option<&[u8]>,new:Option<&[u8]>)->Result<Self,PalwStateV2Error>{
        if key.first()!=Some(&b'P'){return Ok(self.clone())}
        if key.len()!=65{return Err(invalid("P index key"))}
        if old==new{return Ok(self.clone())}
        let mut d=self.copied(0,u64::from(new.is_some()),u64::from(MAX_POSITIVE_DRAW_POSITIONS_V2))?;
        let subject=Digest(key[1..].try_into().map_err(|_|invalid("P key"))?);
        if let Some(old)=old {p_liabilities(old,|bond,amount|{let before=d.liabilities.get(&bond).copied().ok_or_else(||invalid("missing P liability"))?;let after=before.checked_sub(amount).ok_or_else(||invalid("P liability underflow"))?;if after==0{d.liabilities.remove(&bond);}else{d.liabilities.insert(bond,after);}Ok(())})?;}
        if let Some(new)=new {d.subjects.insert(subject);p_liabilities(new,|bond,amount|{let before=d.liabilities.get(&bond).copied().unwrap_or(0);d.liabilities.insert(bond,before.checked_add(amount).ok_or_else(||invalid("P liability overflow"))?);Ok(())})?;}else{d.subjects.remove(&subject);}
        Ok(Self{p_present:!d.subjects.is_empty(),data:Some(Arc::new(d))})
    }
}
impl PalwChainStateV2 {
    pub(crate) fn positive_native_index_v2(&self)->&PositiveNativeIndexV2 {&self.positive_native_index}
}
impl TransitionBuilder<'_> {
    pub(super) fn ensure_positive_native_index_v2(&mut self)->Result<PositiveIndexBuildWorkV2,PalwStateV2Error>{
        if !self.state.positive_native_index.ready(){self.state.positive_native_index=PositiveNativeIndexV2::rebuild(&self.state)?;}
        self.state.positive_native_index.build_work().ok_or_else(missing)
    }
}
/// Import/reorg owner: an old no-P state needs no new allocator. P states MUST
/// restore their derived cache under a real owner before being made current.
pub(super) fn restore_positive_native_index_v2(state:&mut PalwChainStateV2)->Result<(),PalwStateV2Error>{
    let has_p=state.kernel_route.as_ref().is_some_and(|r|r.aux.keys().any(|(t,k)|*t==136&&k.first()==Some(&b'P')));
    state.positive_native_index=if has_p {PositiveNativeIndexV2::rebuild(state)?}else{PositiveNativeIndexV2::default()};Ok(())
}
