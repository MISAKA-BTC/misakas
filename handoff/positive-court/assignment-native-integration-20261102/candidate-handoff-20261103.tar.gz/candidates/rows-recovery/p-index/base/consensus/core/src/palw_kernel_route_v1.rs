//! **G14 lane D — the kernel route (`misaka-palw-kernel`) as consensus state: types, constants, messages, the interim policy.**
//!
//! `misaka-palw-kernel`'s [`KernelLedgerV1`] is a deterministic fold of signed public objects over bonds the consumer owns. This
//! module is the consumer's half that needs no builder: the object tags and their signatures' domains, the one mapping from a
//! V2 bond to the kernel's bond digest, the **interim** ledger policy, the state the fold keeps, and its root. The fold itself
//! (`palw_kernel_route_fold_v1`) is a child of `palw_state_v2` and reads the builder.
//!
//! # Allocation (frozen by the lead, 2026-10-08)
//!
//! object tags **110** ([`PalwConsensusObjectV2::KernelRouteV1`](crate::palw_state_v2::PalwConsensusObjectV2)) and **111**
//! (`KernelConstraintReceiptV1`), delta numbers **160** (a row) and **161** (the header), carriage tail
//! [`PALW_CARRIAGE_KERNEL_ROUTE_TAIL_V1`] `0xEC`, RPC ops 210–219, the dormant fence `palw_probabilistic_constraints_v1`
//! ([`crate::palw_probabilistic_constraints_v1`]) whose validation REFUSES every real height: nothing here can run on a network.
//!
//! # State
//!
//! `PalwChainStateV2.kernel_route: Option<PalwKernelRouteStateV1>` — `None` until the first block at or past the fence. Its rows are
//! the kernel ledger's own `(table, key) → Borsh row` map ([`misaka_palw_kernel::rows`]) plus three consensus tables the ledger
//! does not know: the bond-key map (the kernel's digest → the V2 bond), the **interim** seat assignments and the receipts counted so
//! far. The Some-only root block is `kernel-route/v1 ‖ ledger root ‖ aux root`; the ledger root equals
//! [`KernelLedgerV1::root`] of the ledger the rows describe, so a fresh verifier that rebuilds the ledger from the rows a node serves
//! checks them against the root the chain committed.

use std::collections::BTreeMap;

use borsh::{BorshDeserialize, BorshSerialize};
use misaka_palw_kernel::descriptor::{
    KernelScheduleV1, KernelStatusV1, k2_tir_v1_descriptor, k2_tir_v2_descriptor, k2_tir_v3_descriptor, k2_tir_v4_descriptor,
    k2_tir_v5_descriptor,
};
use misaka_palw_kernel::gate::ProsecutionPolicyV1;
use misaka_palw_kernel::hash::Digest;
use misaka_palw_kernel::ledger::{KernelLedgerV1, LedgerPolicyV1};
use misaka_palw_kernel::opv::OpvPolicyV1;
use misaka_palw_kernel::rows::{LedgerRowsV1, LedgerScalarsV1, config_root_of, root_of_rows};
use misaka_palw_kernel::verify::ScopeV1;

use crate::Hash64;
use crate::constants::SOMPI_PER_KASPA;
use crate::palw_state_v2::PalwBondKeyV2;

/// Local projection capacity and invalid persisted kernel rows are distinct.
/// A local reservation refusal cannot be a verdict against a block or peer.
pub type PalwKernelLedgerProjectionErrorV1 = crate::palw_native_resource_v1::NativeDecodeErrorV1<String>;

pub(crate) fn kernel_ledger_projection_state_error_v1(
    why: PalwKernelLedgerProjectionErrorV1,
    invalid: impl FnOnce(String) -> crate::palw_state_v2::PalwStateV2Error,
) -> crate::palw_state_v2::PalwStateV2Error {
    use crate::palw_native_resource_v1::NativeDecodeErrorV1;
    match why {
        NativeDecodeErrorV1::Resource(why) => crate::palw_state_v2::PalwStateV2Error::NativeResource(why),
        NativeDecodeErrorV1::Decode(why) => invalid(why),
    }
}

/// The ML-DSA-87 context a signer's bond signs a [`KernelRouteV1`](crate::palw_state_v2::PalwConsensusObjectV2) under.
pub const PALW_KERNEL_ROUTE_OBJECT_MLDSA87_CONTEXT_V1: &[u8] = b"misaka-palw/kernel-route/object/v1";
/// The domain of the signed message (network, signer, the kernel object's bytes).
pub const PALW_KERNEL_ROUTE_OBJECT_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/object-message/v1";
/// The domain of the bond-digest mapping: the kernel sees a bond only as this digest.
pub const PALW_KERNEL_ROUTE_BOND_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/bond-id/v1";
/// **INTERIM** seat assignment (not a production beacon, grindable): the seed's domain (`H(domain; claim id)`).
pub const PALW_KERNEL_ROUTE_INTERIM_ASSIGNMENT_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/interim-assignment/v1";
/// The domain of an interim seat's lottery entry.
pub const PALW_KERNEL_ROUTE_INTERIM_TICKET_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/interim-ticket/v1";
/// The domain of the interim challenge anchor and sample seed a seat's receipt is bound to.
pub const PALW_KERNEL_ROUTE_INTERIM_CHALLENGE_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/interim-challenge/v1";
/// The domain of the interim challenge policy id the ledger policy names.
pub const PALW_KERNEL_ROUTE_INTERIM_POLICY_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/interim-challenge-policy/v1";
/// The domain of a kernel payout's row key (`0xFD` prefix, keyed by payee).
pub const PALW_KERNEL_ROUTE_PAYOUT_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/payout/v1";
/// The first byte of every kernel payout row's key: `0xFD`, after the claims' escrows (uniform hashes) and BEFORE the panel seats'
/// `0xFE` and the market's `0xFF`, so a kernel payee never delays a claim's escrow and the panel's and the market's rows never
/// delay a kernel payee.
pub const PALW_KERNEL_ROUTE_PAYOUT_KEY_PREFIX_V1: u8 = 0xFD;

/// The carriage tail of the kernel route state (after Lane MU's `0xEB`).
pub const PALW_CARRIAGE_KERNEL_ROUTE_TAIL_V1: u8 = 0xEC;

/// **Auxiliary tables** (the ledger's own tables are `1..=9`, see [`misaka_palw_kernel::rows`]). Declared numbers.
pub const PALW_KERNEL_ROUTE_TABLE_BOND_KEYS_V1: u8 = 32;
pub const PALW_KERNEL_ROUTE_TABLE_ASSIGNMENTS_V1: u8 = 33;
pub const PALW_KERNEL_ROUTE_TABLE_RECEIPTS_V1: u8 = 34;
/// The block's adjudication budget already spent by earlier objects of the SAME chain block: `[] → (blue score, adjudications, court work)`.
/// Rewritten by each charged object so the budget bounds the block however the fold is split into single-object rehearsals.
pub const PALW_KERNEL_ROUTE_TABLE_BLOCK_BUDGET_V1: u8 = 35;
/// `[] -> u64`: the independently versioned commitment-only court-scope activation.
/// Kept in the authenticated auxiliary root so public reads, snapshots and reorgs use
/// the same response contract as the block fold. Absent below the fence.
pub const PALW_KERNEL_ROUTE_TABLE_COMMITMENT_SCOPE_V1: u8 = 107;

/// **C4 F-C4R3-03: the route's OWN chunk lane** — `borsh((opener bond, group)) → PalwKernelChunkGroupV1` (the lead's allocation of
/// 2026-10-08: aux tables 41–42, riding the route's `KernelRouteRow` deltas, tail `0xEC` and root block). A prosecution object larger
/// than one carrier — a `FileProof` or a position `Respond` of a real class, an onboarding refutation (tag 105) — rides
/// `KernelRouteChunkV1` (tag 113) here, never in the certification lane's `pending_chunks` (ONE network-wide table of eight groups
/// that eight junk chunks hold for 4,000 DAA). A group here is keyed by its SIGNING opener's bond, so no bond can occupy another's
/// room: every bond has [`PALW_KERNEL_CHUNK_GROUPS_PER_BOND_V1`] groups of its own, each backed by a deposit forfeited if it never
/// completes, and none outliving its target's deadline.
pub const PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1: u8 = 41;
/// Allocated beside table 41 (2026-10-08) and held unused.
pub const PALW_KERNEL_ROUTE_TABLE_RESERVED_42_V1: u8 = 42;
/// The most half-assembled groups one bond may hold open in the route's chunk lane at once.
pub const PALW_KERNEL_CHUNK_GROUPS_PER_BOND_V1: usize = 2;
/// The longest a group may stay half-assembled (it never outlives its target's deadline either).
pub const PALW_KERNEL_CHUNK_TTL_MAX_DAA_V1: u64 = 64;
/// The deposit a group's opener posts per declared part, held from its free collateral until the group completes and FORFEITED
/// (slashed, burned) if it never does: junk pays, honesty is refunded.
pub const PALW_KERNEL_CHUNK_DEPOSIT_PER_PART_SOMPI_V1: u64 = SOMPI_PER_KASPA;
/// The ML-DSA-87 context the opener's bond signs each chunk under.
pub const PALW_KERNEL_CHUNK_MLDSA87_CONTEXT_V1: &[u8] = b"misaka-palw/kernel-route/chunk/v1";
/// The domain of a chunk's signed message (network, the chunk's Borsh).
pub const PALW_KERNEL_CHUNK_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/chunk-message/v1";

/// The most seats one claim's interim assignment draws, and the per-segment quorum the tally needs.
pub const PALW_KERNEL_ROUTE_INTERIM_SEATS_V1: usize = 3;
pub const PALW_KERNEL_ROUTE_INTERIM_QUORUM_V1: u8 = 3;
/// **Panel=1** (PRINCIPLES §5, RFC-0010 §0 addendum): one assigned seat per claim, quorum 1 — selected by
/// `Params::palw_kernel_route_panel_one_v1` (dormant; the 1-seat policy was adopted on 2026-10-22). The seat's receipt
/// is one input to the claim-level verification; the public court, the challenge window and bond/slash decide a dispute exactly as
/// under 3-of-3 (a seat's signature never justifies a fault, PRINCIPLES §5).
pub const PALW_KERNEL_ROUTE_PANEL_ONE_SEATS_V1: usize = 1;
pub const PALW_KERNEL_ROUTE_PANEL_ONE_QUORUM_V1: u8 = 1;

/// **The seat policy at `daa_score`**: `(seats, quorum)`, Panel=1 from `panel_one_from` (the mirror of
/// `Params::palw_kernel_route_panel_one_v1`), the interim 3-of-3 otherwise (and always when `None`).
pub fn palw_kernel_route_seats_and_quorum_v1(panel_one_from: Option<u64>, daa_score: u64) -> (usize, u8) {
    if panel_one_from.is_some_and(|from| daa_score >= from) {
        (PALW_KERNEL_ROUTE_PANEL_ONE_SEATS_V1, PALW_KERNEL_ROUTE_PANEL_ONE_QUORUM_V1)
    } else {
        (PALW_KERNEL_ROUTE_INTERIM_SEATS_V1, PALW_KERNEL_ROUTE_INTERIM_QUORUM_V1)
    }
}

/// **What one kernel route object can be, in encoded bytes** — the bound a node with the real carriers can honour: an object rides
/// one `0x4b` carrier directly, or in `ObjectChunk`s ([`crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES`] ×
/// [`crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_COUNT`]) less the wrapper (the signer, the signature, the length prefix). The
/// registration of a class is refused unless its worst filing, response and commitments fit this
/// ([`misaka_palw_kernel::ledger::carrier_fit_v1`]).
pub const PALW_KERNEL_ROUTE_MAX_OBJECT_BYTES_V1: usize =
    crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES * crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_COUNT as usize - (16 << 10);

/// **The one mapping from a V2 bond to the kernel's bond digest** — used for the producer, the accuser, the demander and the seat
/// everywhere: `H(domain; txid ‖ index)`.
pub fn palw_kernel_bond_id_v1(bond: &PalwBondKeyV2) -> Digest {
    let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_BOND_DOMAIN_V1).to_state();
    s.update(bond.0.transaction_id.as_byte_slice());
    s.update(&bond.0.index.to_le_bytes());
    let mut out = [0u8; 64];
    out.copy_from_slice(s.finalize().as_bytes());
    out
}

/// **The message a signer's bond signs**: `H(domain; network ‖ signer ‖ len ‖ bytes)`. The network separates chains, the signer
/// the object from every other bond's, and the bytes ARE the object (strictly decoded by the consumer).
pub fn palw_kernel_route_message_v1(network_domain: Hash64, signer: &PalwBondKeyV2, bytes: &[u8]) -> Hash64 {
    let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_OBJECT_DOMAIN_V1).to_state();
    s.update(network_domain.as_byte_slice());
    s.update(signer.0.transaction_id.as_byte_slice());
    s.update(&signer.0.index.to_le_bytes());
    s.update(&(bytes.len() as u64).to_le_bytes());
    s.update(bytes);
    let mut out = [0u8; 64];
    out.copy_from_slice(s.finalize().as_bytes());
    Hash64::from_bytes(out)
}

/// **What the processor resolves from the ruleset and hands the fold** (`PalwTransitionExtrasV1::kernel_route`): `Some` exactly
/// when `palw_probabilistic_constraints_v1` is active at the block. The network and the ruleset enter the ledger policy, so an
/// object never names its own network.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct PalwKernelRouteExtrasV1 {
    pub network_domain: Hash64,
    pub ruleset_digest: Hash64,
    /// The chain's genesis hash: what an RFC-0013 conformance commitment names as `chain_genesis`.
    pub chain_genesis: Hash64,
    /// Artifact roots the consumer attests public (`KernelLedgerV1::attest_artifact`). **There is no on-chain artifact
    /// availability or conformance fact yet**, so this is empty in production and a test-only hook fills it in the E2E
    /// (`kernel_route_test_attest_artifact_v1` in the processor, `cfg(test)`): GAP — onboarding conformance + availability.
    pub attested_artifacts: Vec<Hash64>,
    /// **Test seam, `None` in production**: a smaller per-block adjudication cap than the policy's (the processor sets it only under
    /// `cfg(test)`, uniformly for every chain of a test process, so a header's policy never changes mid-chain). Lets a test exhaust the
    /// block budget with a handful of carriers instead of sixty-five.
    pub max_adjudications_per_block: Option<u32>,
    /// **Test seam, empty in production** (RFC-0008 v2, X8R): classes whose REAL attempts skip the model-registry lifecycle and room,
    /// the seating and the per-bond-share gates ([`crate::palw_state_v2`]'s `test_admitted_class_v1`). The processor fills it only
    /// under `cfg(test)` (`exec_v2_test_admit_class_v1`, height-gated like the artifact attestations) for the composed EXEC-slice ×
    /// G14 run, as the stand-in for the legacy channel's Panel admission of the session's V2 REAL root (GAP-81: an onboarded class's V2
    /// claims earn only there, and the harness cannot prove seat readiness). Only a network with the kernel route can even carry it.
    pub test_admitted_classes: Vec<Hash64>,
    /// **RFC-0015 OptimisticPublicVerification**: `Some` exactly where the network declares the OPV policy (a genesis constant — it is
    /// `Some` at every block of a chain or at none). The processor resolves it from `Params::palw_panel_free_v1`.
    pub opv: Option<PalwKernelOpvExtrasV1>,
    /// **RFC-0004 Part II**: the `palw_typed_roots_v1` fence's activation (`None`: absent) — a genesis constant of the route, like the
    /// OPV policy: from this height the route's schedule holds the typed-roots extension `K2-TR-v1` Active.
    pub typed_roots: Option<u64>,
    /// Dedicated source fence and immutable network terms; None below it and on all real presets.
    pub beacon_source: Option<crate::palw_beacon_source_opt_in_v1::PalwBeaconSourceFenceV1>,
    /// Independent monetary fence for prepaid source contracts.
    pub beacon_source_fee: Option<crate::palw_beacon_source_fee_v1::PalwBeaconSourceFeeFenceV1>,
    /// Independently fenced funded execution with immutable network terms.
    pub funded_execution: Option<crate::palw_funded_execution_v11::PalwFundedExecutionFenceV11>,
    /// Independent V2 external stage semantics and native policy.
    pub stage_execution: Option<crate::palw_flat_stage_v14::PalwStageExecutionFenceV14>,
    /// Trusted, independently fenced complete native Final profile. Never
    /// supplied by a route action, metadata acceptance or an old funded job.
    pub native_final: Option<crate::palw_native_final_v27::PalwNativeFinalFenceV27>,
    /// New stage book and full-source/temporal/court contract, independent of14.
    pub stage_execution_v28: Option<crate::palw_flat_stage_v28::PalwStageExecutionFenceV28>,
    pub native_execution39: Option<crate::palw_native_execution_v39::PalwNativeExecutionFenceV39>,
    /// Owning39 mining (stage actions 73–79), where `Params::palw_native_mining_v39` is in force at the block (with native39 and
    /// Final27). `None` on every preset: below it actions 73–79 ride unjudged and fold nothing.
    pub native_mining39: Option<crate::palw_native_mining_v39::PalwNativeMiningFenceV39>,
    /// Actual physical mass constants, resolved from Params only where a new
    /// native namespace is active. They do not assert reserved-lane readiness.
    pub native_carriage_mass: Option<crate::palw_native_carriage_v22::NativeCarriageMassParamsV22>,
    /// Original physical service declaration. The current consumer publishes
    /// only an unimplemented probe; capacity admission cannot infer a scheduler.
    pub native_carriage_service: Option<crate::palw_flat_execution_capacity_v22::NativeCarriageServiceV22>,
    /// **Lane DA16: `Params::palw_provider_court_v1`'s activation DAA, where that fence is in force at the block** (`None` below it and on
    /// every network). The provider court's objects fold only with it; a claim committed below it can never move its DA responsibility.
    pub provider_court: Option<u64>,
    /// Independently activated model-dependent response omission for new program/pipeline
    /// claims. Historical claims keep their original response contract.
    pub commitment_scope: Option<u64>,
    /// **G14R round 3: `Params::palw_verifier_pay_v1`'s activation DAA** (`None` on every network): the kernel ledger's M\*-49 and O2
    /// terms (`crate::palw_verifier_pay_v1::palw_verifier_pay_interim_policy_v1`), injected at every load — not in the header or root.
    pub verifier_pay: Option<u64>,
    /// **RFC-0002 P0 (RFC02-T): `Params::palw_model_refutation_seal_v1`'s activation DAA, where that fence is in force at the block**
    /// (`None` below it and on every network): candidate refutations only as sealed reveals (inner 36 / 37), the unsealed 23 / 27 / 32
    /// refused by name.
    pub model_refutation_seal: Option<u64>,
    /// **RFC-0002 §II.14.60: `Params::palw_window_class_v37`'s activation DAA, where that fence is in force at the block**
    /// (`None` below it and on every preset). Funded action 45 folds only with it (and Final27).
    pub window_class_v37: Option<u64>,
}

/// What the processor hands the fold for the OPV mode (RFC-0015): the network's policy and the two restrictions of the DERIVED
/// eligibility, all read from `Params::palw_panel_free_v1` ([`crate::palw_panel_free_v1::PalwPanelFreeFenceV1`]). Eligibility itself is
/// derived in the fold from chain state (`crate::palw_opv_bootstrap_v1`), never handed in.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PalwKernelOpvExtrasV1 {
    /// The OPV policy, a genesis constant of the route (the fence's terms, activating at the fence's height).
    pub policy: OpvPolicyV1,
    /// Mode-bound class ids the network denies OPV (a restriction only).
    pub denied_classes: Vec<Hash64>,
    /// The effective-bits floor a class's conformance policy must reach.
    pub min_effective_bits: u16,
    /// GAP-70: whether a sampled conformance may satisfy E6 (`false` on every network the validation admits).
    pub sampled_conformance_gates_reward: bool,
    /// **TEST SEAM, empty in every build that can run a network**: mode-bound class ids a pre-derivation mechanics test treats as
    /// eligible (the processor fills it only under `cfg(test)`, from `kernel_route_test_opv_eligible_v1`, exactly as it fills
    /// `attested_artifacts`). The bootstrap E2E uses none.
    pub test_eligible: Vec<Hash64>,
    /// **G14-for-rewards**: `Some` from the fence's activation on (`None` below it, and the gate is unarmed). See
    /// `crate::palw_opv_bootstrap_v1::palw_reward_gate_v1`.
    pub reward_gate: Option<PalwRewardGateTermsV1>,
    /// **RFC-0015 §8.3** (lead default 2026-10-15, pending user review): `true` — the processor sets it on every network that declares
    /// the OPV policy, isolated calibration and test-armed worlds included. A Panel-free claim (an OPV kernel claim, native funded /
    /// text / stage work) is then admitted only with a `palw_bond_budget_v1` reservation (class-independent `Q/B/R/F`, common hold
    /// `d + W`); unbudgeted it is refused. `false` only in fold-level fixtures that build these extras by hand.
    pub budget_required: bool,
}

/// The terms of the G14-for-rewards gate at one block (from `Params::palw_panel_free_v1`).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PalwRewardGateTermsV1 {
    /// The fence's activation: a class registered below it keeps earning through the OLD Panel route, in full; one registered at or
    /// past it earns only through the onboarding/G14 path (the user's ruling of 2026-10-09: the two reward channels never mix).
    pub fence_activation_daa: u64,
}

/// **The PALW reporter share on the kernel route, permille** (ADR-0032's 2026-10-10 amendment: 4,900 bps): what an accuser, a
/// demander or an onboarding challenger is paid of a slash the chain actually collected; the rest is burned. One constant for every
/// reporter path of the route, so the share cannot drift between them. (`palw_reporter_share_v2` is INTF's fence for the R-core rate;
/// the kernel route is dormant as a whole, so its share needs no fence of its own: it has never been in force at any other rate.)
pub const PALW_KERNEL_REPORTER_SHARE_PERMILLE_V1: u16 = 490;

/// **The INTERIM ledger policy.** Windows are short so a drill crosses them; the amounts are sompi. Values are consensus constants
/// of the (never-armed) fence, written once here: a real activation would revisit every one.
pub fn palw_kernel_route_policy_v1(network_domain: Hash64, ruleset_digest: Hash64) -> LedgerPolicyV1 {
    let policy_id = {
        let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_INTERIM_POLICY_DOMAIN_V1).to_state();
        s.update(network_domain.as_byte_slice());
        let mut out = [0u8; 64];
        out.copy_from_slice(s.finalize().as_bytes());
        out
    };
    LedgerPolicyV1 {
        network_domain: network_domain.as_bytes(),
        ruleset_digest: ruleset_digest.as_bytes(),
        challenge_policy_id: policy_id,
        // AUDIT-3 m3 (2026-10-27): 1,100 MSK since E1 (was 1,080, before that 1,000), the estimate pinned in `palw_g14_values_v1`.
        claim_collateral: crate::palw_g14_values_v1::PALW_G14_KERNEL_CLAIM_COLLATERAL_SOMPI_V1,
        demand_bond: SOMPI_PER_KASPA,
        check_window_daa: 100,
        challenge_window_daa: 50,
        court_deadline_daa: 20,
        proof_grace_daa: 10,
        liability_daa: 200,
        exit_delay_daa: 30,
        dismissed_proof_fee: SOMPI_PER_KASPA / 10,
        // ADR-0032 (2026-10-10 amendment): the PALW reporter share is 49 % (4,900 bps) of what a slash actually COLLECTED, the rest
        // burned. The route's accuser (a conviction), its demanders (a default penalty) and — at the same rate — the onboarding
        // challenger are PALW reporters, so the interim share is that ceiling, not the 500‰ it was. A self-reporter recovers at most
        // 49 %: the net loss of a convicted producer is ≥ 51 % of the collected slash, never the gross slash (ADR-0176 D6).
        accuser_reward_permille: PALW_KERNEL_REPORTER_SHARE_PERMILLE_V1,
        default_penalty: 100 * SOMPI_PER_KASPA,
        // GAP-5 (the user's ruling: user-pays escrow): the reward is paid out of the job's ESCROW, reserved from the poster's bond at
        // posting and spent once at the job's first Final — never new money.
        claim_reward: 5 * SOMPI_PER_KASPA,
        // GAP-5: posting a job burns 1 BILI beside its escrow (a self-posted job is never free), and an escrow no claim can still use
        // goes back to its poster 300 DAA after posting (past the seal TTL, the check and challenge windows and a court).
        job_fee: SOMPI_PER_KASPA,
        job_escrow_ttl_daa: 300,
        max_adjudications_per_block: 64,
        // C4 F-C4R3-05 (round 2): half of every block's court runs only a proof may spend.
        prosecution_reserve_permille: 500,
        max_court_work_per_block: 1 << 30,
        // Seal, then reveal: a claim commits over its producer's seal at least one block old; an unrevealed seal lives one check window.
        claim_seal_delay_daa: 1,
        seal_ttl_daa: 100,
        // OPV-BOOT's sealed-source beacon (v3): a claim seal holds 1 BILI until revealed, forfeited if it expires unrevealed.
        seal_deposit: SOMPI_PER_KASPA,
        prosecution: ProsecutionPolicyV1 {
            court_deadline_daa: 20,
            max_sessions_per_claim: 1 << 10,
            max_public_bytes: 1 << 40,
            max_verifier_ram: 1 << 36,
            max_retained_state: 1 << 32,
        },
    }
}

/// [`palw_kernel_route_template_v1`] over a network that declares an OPV policy.
pub fn palw_kernel_route_template_opv_v1(policy: LedgerPolicyV1, opv: Option<OpvPolicyV1>) -> KernelLedgerV1 {
    let template = palw_kernel_route_template_v1(policy);
    match opv {
        Some(p) => template.with_opv_policy(p).expect("the interim OPV policy validates against the interim ledger policy"),
        None => template,
    }
}

/// [`palw_kernel_route_template_opv_v1`] with the typed-roots extension `K2-TR-v1` Active from `typed` (RFC-0004 Part II). `None` is the
/// template byte for byte — the same schedule, the same `config_root`, the same roots.
pub fn palw_kernel_route_template_typed_v1(policy: LedgerPolicyV1, opv: Option<OpvPolicyV1>, typed: Option<u64>) -> KernelLedgerV1 {
    let mut template = palw_kernel_route_template_opv_v1(policy, opv);
    if let Some(since_daa) = typed {
        let tr = misaka_palw_kernel::spec::k2_tr_v1_descriptor();
        template.schedule = template.schedule.with(tr.digest(), KernelStatusV1::Active { since_daa });
    }
    template
}

/// The ledger configuration the fold starts every block from (policy, the schedule that arms the K2 descriptors, the descriptors
/// this binary implements). Rows are loaded over it.
pub fn palw_kernel_route_template_v1(policy: LedgerPolicyV1) -> KernelLedgerV1 {
    // K2-TIR-v4 (lane K2S, `docs/design/palw/models/k2-real-scale.md`): the real-scale suite — segmented claims, element courts, per-position
    // DA, prompt tiles; its classes register only under OptimisticPublicVerification. Like v1–v3 it is armed here and nowhere else:
    // the fence refuses every real height.
    // K2-TIR-v5 (§12 of the same design): K2-TIR-v4 for encoders and heads, ONE position whose ids are the job's; armed here only.
    let (v1, v2, v3, v4) = (k2_tir_v1_descriptor(), k2_tir_v2_descriptor(), k2_tir_v3_descriptor(), k2_tir_v4_descriptor());
    let v5 = k2_tir_v5_descriptor();
    let schedule = KernelScheduleV1::default()
        .with(v1.digest(), KernelStatusV1::Active { since_daa: 0 })
        .with(v2.digest(), KernelStatusV1::Active { since_daa: 0 })
        .with(v3.digest(), KernelStatusV1::Active { since_daa: 0 })
        .with(v4.digest(), KernelStatusV1::Active { since_daa: 0 })
        .with(v5.digest(), KernelStatusV1::Active { since_daa: 0 });
    KernelLedgerV1::genesis(policy, schedule, vec![v1, v2, v3, v4, v5]).expect("the interim kernel route policy validates")
}

/// One seat of an interim assignment.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct KernelSeatV1 {
    pub bond: PalwBondKeyV2,
    pub kernel_bond: Digest,
    pub scope: ScopeV1,
}

/// **INTERIM seat assignment of one claim** — deterministic from the chain state at its commitment, grindable, NOT a production
/// beacon: G14 must hold whatever these seats sign (the public court convicts a claim every assigned seat covered).
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct KernelAssignmentV1 {
    pub seats: Vec<KernelSeatV1>,
    pub assignment_root: Digest,
    pub challenge_anchor: Digest,
    pub sample_seed: Digest,
    /// The receipts' deadline: the end of the claim's check window.
    pub deadline_daa: u64,
    pub quorum: u8,
}

/// The consumer's part of the header: the configuration the rows were folded under. Part of the state, so a state is self-contained
/// and a fold under another policy is refused.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct PalwKernelRouteHeaderV1 {
    pub policy: LedgerPolicyV1,
    pub config_root: Digest,
    pub scalars: LedgerScalarsV1,
    /// RFC-0015: the network's OPV policy, a genesis constant (`None`: the Panel-licensed route alone, and the historical root form).
    pub opv: Option<OpvPolicyV1>,
    /// RFC-0004 Part II: the typed-roots fence's activation, a genesis constant (`None`: the route without typed roots, its historical
    /// schedule and roots).
    pub typed_roots: Option<u64>,
}

/// **The kernel route state** (module doc). `rows` are the ledger's tables; `aux` the consensus tables.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize)]
pub struct PalwKernelRouteStateV1 {
    pub header: PalwKernelRouteHeaderV1,
    pub rows: LedgerRowsV1,
    pub aux: BTreeMap<(u8, Vec<u8>), Vec<u8>>,
    /// **GAP 8: the ledger the rows describe, cached** — never state: not hashed, not encoded, not in a delta, equal for every
    /// comparison. Set by the fold's flush to exactly what [`KernelLedgerV1::from_rows`] would rebuild
    /// ([`KernelLedgerV1::as_rebuilt_from_v1`]); cleared by every other write of a ledger row or of the header (a delta applied or
    /// reverted, a row the fold writes outside its flush). A state decoded from a store, a snapshot or a carriage starts without it.
    #[borsh(skip)]
    pub ledger_cache: KernelLedgerCacheV1,
}

/// Keep the canonical field layout, but reject duplicate aux keys before a
/// BTreeMap could silently collapse them. Positive rows have fixed codec caps
/// even when a caller invokes Borsh directly (native preflight remains required
/// for aggregate reservation before untrusted intake).
impl BorshDeserialize for PalwKernelRouteStateV1 {
    fn deserialize_reader<R: std::io::Read>(reader: &mut R) -> std::io::Result<Self> {
        fn positive_blob<R: std::io::Read>(reader: &mut R, cap: usize) -> std::io::Result<Vec<u8>> {
            let length = u32::deserialize_reader(reader)? as usize;
            if length > cap {
                return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "Positive aux frame exceeds codec ceiling"));
            }
            let mut bytes = Vec::new();
            bytes
                .try_reserve_exact(length)
                .map_err(|_| std::io::Error::new(std::io::ErrorKind::OutOfMemory, "Positive aux allocation"))?;
            bytes.resize(length, 0);
            reader.read_exact(&mut bytes)?;
            Ok(bytes)
        }
        let header = PalwKernelRouteHeaderV1::deserialize_reader(reader)?;
        let rows = LedgerRowsV1::deserialize_reader(reader)?;
        let count = u32::deserialize_reader(reader)?;
        let mut aux = BTreeMap::new();
        // Positive keys must be canonical BEFORE BTreeMap can sort/collapse
        // them. Other aux tables retain their legacy ordering semantics.
        let mut previous_positive = [0u8; misaka_palw_positive_contract::rows::MAX_NATIVE_KEY_BYTES];
        let mut previous_positive_len = 0usize;
        for _ in 0..count {
            let table = u8::deserialize_reader(reader)?;
            let (key, value) = if table == misaka_palw_positive_contract::native::KERNEL_AUX_TABLE {
                let key = positive_blob(reader, misaka_palw_positive_contract::rows::MAX_NATIVE_KEY_BYTES)?;
                if previous_positive_len != 0 && key.as_slice() <= &previous_positive[..previous_positive_len] {
                    return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "noncanonical Positive aux key order"));
                }
                previous_positive[..key.len()].copy_from_slice(&key);
                previous_positive_len = key.len();
                let value = positive_blob(reader, misaka_palw_positive_contract::rows::MAX_NATIVE_ROW_BYTES)?;
                misaka_palw_positive_contract::rows::NativeRowValue::decode(&key, &value)
                    .map_err(|_| std::io::Error::new(std::io::ErrorKind::InvalidData, "Positive aux key/value mismatch"))?;
                (key, value)
            } else {
                (Vec::<u8>::deserialize_reader(reader)?, Vec::<u8>::deserialize_reader(reader)?)
            };
            if aux.insert((table, key), value).is_some() {
                return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "duplicate kernel aux key"));
            }
        }
        Ok(Self { header, rows, aux, ledger_cache: KernelLedgerCacheV1::default() })
    }
}

/// How many kernel ledger loads were served from the cache in this process (a diagnostic: the fold of a block loads the ledger once
/// per object, and every load after the block's first is a hit — GAP 8's "a cached ledger per block").
pub static PALW_KERNEL_LEDGER_CACHE_HITS_V1: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

/// The cached ledger of a [`PalwKernelRouteStateV1`] (see its `ledger_cache`). Clones share the immutable ledger; a load clones it.
#[derive(Clone, Default)]
pub struct KernelLedgerCacheV1(Option<std::sync::Arc<crate::palw_native_resource_v1::ReservedKernelLedgerV1>>, bool);

impl KernelLedgerCacheV1 {
    /// Cache clones share both immutable payload and its reservation ticket.
    pub(crate) fn native_ledger_ref_v1(&self) -> Option<&KernelLedgerV1> {
        self.0.as_ref().map(|ledger| &ledger.ledger)
    }
    pub fn get(&self) -> Result<Option<crate::palw_native_resource_v1::ReservedKernelLedgerV1>, String> {
        self.get_reserved_v1().map_err(|e| e.to_string())
    }
    fn get_reserved_v1(
        &self,
    ) -> Result<Option<crate::palw_native_resource_v1::ReservedKernelLedgerV1>, crate::palw_native_resource_v1::NativeCoverageV1> {
        if self.1 {
            return Ok(None);
        }
        self.0.as_ref().map(|ledger| ledger.try_clone_v1()).transpose()
    }
    pub fn set(&mut self, ledger: crate::palw_native_resource_v1::ReservedKernelLedgerV1) {
        self.0 = Some(std::sync::Arc::new(ledger));
        self.1 = false;
    }
    pub fn clear(&mut self) {
        self.0 = None;
        self.1 = false;
    }
    pub(crate) fn native_projection(
        &self,
    ) -> Result<Option<crate::palw_native_resource_v1::ReservedKernelLedgerV1>, crate::palw_native_resource_v1::NativeCoverageV1> {
        if !self.1 {
            return Ok(None);
        }
        self.0.as_ref().map(|ledger| ledger.try_clone_v1()).transpose()
    }
    pub(crate) fn set_native_projection(&mut self, mut ledger: crate::palw_native_resource_v1::ReservedKernelLedgerV1) {
        ledger.clear_flat_conformance_classes_v9();
        self.0 = Some(std::sync::Arc::new(ledger));
        self.1 = true;
    }
    pub fn is_set(&self) -> bool {
        self.0.is_some()
    }
}

/// A cache is never part of what a state is: every two caches compare equal.
impl PartialEq for KernelLedgerCacheV1 {
    fn eq(&self, _: &Self) -> bool {
        true
    }
}

impl Eq for KernelLedgerCacheV1 {}

impl std::fmt::Debug for KernelLedgerCacheV1 {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "KernelLedgerCacheV1(cached: {})", self.0.is_some())
    }
}

impl PalwKernelRouteStateV1 {
    pub fn new(policy: LedgerPolicyV1, opv: Option<OpvPolicyV1>, scalars: LedgerScalarsV1) -> Self {
        Self::new_typed(policy, opv, None, scalars)
    }

    /// A route state with nothing in it but its header (a delta that creates it).
    pub fn with_header(header: PalwKernelRouteHeaderV1) -> Self {
        Self { header, rows: LedgerRowsV1::new(), aux: BTreeMap::new(), ledger_cache: KernelLedgerCacheV1::default() }
    }

    /// [`Self::new`] under the typed-roots fence's activation (RFC-0004 Part II).
    pub fn new_typed(policy: LedgerPolicyV1, opv: Option<OpvPolicyV1>, typed_roots: Option<u64>, scalars: LedgerScalarsV1) -> Self {
        let template = palw_kernel_route_template_typed_v1(policy, opv, typed_roots);
        let config_root = config_root_of(&template.schedule, &template.known);
        Self {
            header: PalwKernelRouteHeaderV1 { policy, config_root, scalars, opv, typed_roots },
            rows: LedgerRowsV1::new(),
            aux: BTreeMap::new(),
            ledger_cache: KernelLedgerCacheV1::default(),
        }
    }

    /// The configuration the rows were folded under (policy, OPV policy, typed roots, schedule, descriptors).
    pub fn template(&self) -> KernelLedgerV1 {
        palw_kernel_route_template_typed_v1(self.header.policy, self.header.opv, self.header.typed_roots)
    }

    /// The ledger's root, computed from the rows alone (equal to [`KernelLedgerV1::root`] of the ledger they describe).
    pub fn ledger_root(&self) -> Hash64 {
        let h = &self.header;
        Hash64::from_bytes(root_of_rows(&h.policy, h.config_root, h.scalars, h.opv.as_ref(), &self.rows))
    }

    /// The consensus tables' root: every aux row, in key order.
    pub fn aux_root(&self) -> Hash64 {
        let mut s = blake2b_simd::Params::new().hash_length(64).key(b"misaka-palw/kernel-route/aux-root/v1").to_state();
        s.update(&(self.aux.len() as u64).to_le_bytes());
        for ((table, key), row) in &self.aux {
            s.update(&[*table]);
            s.update(&(key.len() as u32).to_le_bytes());
            s.update(key);
            s.update(&(row.len() as u32).to_le_bytes());
            s.update(row);
        }
        let mut out = [0u8; 64];
        out.copy_from_slice(s.finalize().as_bytes());
        Hash64::from_bytes(out)
    }

    /// The kernel ledger these rows describe (over the state's own configuration): the cached one when the fold left it (GAP 8: no
    /// row decoded, no program decoded, no gate recomputed), else rebuilt from the rows. In a debug build the cache is checked against
    /// the rows every time, so a write path that forgot to clear it fails the tests instead of a node.
    pub fn ledger(&self) -> Result<crate::palw_native_resource_v1::ReservedKernelLedgerV1, String> {
        self.ledger_checked_v1().map_err(|e| e.to_string())
    }

    fn commitment_scope_checked_v1(&self) -> Result<Option<u64>, PalwKernelLedgerProjectionErrorV1> {
        self.aux
            .get(&(PALW_KERNEL_ROUTE_TABLE_COMMITMENT_SCOPE_V1, Vec::new()))
            .map(|bytes| {
                borsh::from_slice(bytes).map_err(|_| {
                    crate::palw_native_resource_v1::NativeDecodeErrorV1::Decode("malformed court-scope activation".into())
                })
            })
            .transpose()
    }

    /// Preserve the reservation cause through actual native fold consumers.
    /// The string form remains for diagnostic/compatibility readers only.
    pub fn ledger_checked_v1(
        &self,
    ) -> Result<crate::palw_native_resource_v1::ReservedKernelLedgerV1, PalwKernelLedgerProjectionErrorV1> {
        use crate::palw_native_resource_v1::NativeDecodeErrorV1 as E;
        let commitment_scope = self.commitment_scope_checked_v1()?;
        let scoped = |mut ledger: crate::palw_native_resource_v1::ReservedKernelLedgerV1| -> Result<crate::palw_native_resource_v1::ReservedKernelLedgerV1, PalwKernelLedgerProjectionErrorV1> {
            ledger.set_commitment_scope_from_daa_v1(commitment_scope);
            ledger.reserve_projection_v1(self).map_err(E::Resource)?;
            self.apply_paid_claim_consumer_inputs_checked_v6(ledger.paid_consumer_projection_mut_v1())?;
            Ok(ledger)
        };
        if let Some(cached) = self.ledger_cache.get_reserved_v1().map_err(E::Resource)? {
            PALW_KERNEL_LEDGER_CACHE_HITS_V1.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            debug_assert!(
                cached.scalars() == self.header.scalars && cached.to_rows() == self.rows,
                "the cached kernel ledger is not the ledger of the rows (a write did not clear the cache)"
            );
            return scoped(cached);
        }
        let lease = crate::palw_native_resource_v1::reserve_ledger_expansion_v1(self, false).map_err(E::Resource)?;
        scoped(crate::palw_native_resource_v1::ReservedKernelLedgerV1::from_preflight_v1(
            KernelLedgerV1::from_rows(&self.template(), self.header.scalars, &self.rows).map_err(E::Decode)?,
            lease,
        ))
    }

    /// A decoded aux row.
    pub fn aux_row<T: BorshDeserialize>(&self, table: u8, key: &[u8]) -> Option<T> {
        borsh::from_slice(self.aux.get(&(table, key.to_vec()))?).ok()
    }

    /// The V2 bond a kernel bond digest stands for (the route has seen it sign or sit).
    pub fn bond_key_of(&self, kernel_bond: &Digest) -> Option<PalwBondKeyV2> {
        self.aux_row(PALW_KERNEL_ROUTE_TABLE_BOND_KEYS_V1, &borsh::to_vec(kernel_bond).expect("a digest serializes"))
    }

    /// A claim's interim assignment, while its receipts are still being counted.
    pub fn assignment_of(&self, claim: &Digest) -> Option<KernelAssignmentV1> {
        self.aux_row(PALW_KERNEL_ROUTE_TABLE_ASSIGNMENTS_V1, &borsh::to_vec(claim).expect("a digest serializes"))
    }

    /// The receipts counted so far for a claim (dropped once the claim is covered).
    pub fn receipts_of(&self, claim: &Digest) -> Vec<misaka_palw_kernel::receipt::PalwConstraintReceiptV1> {
        self.aux_row(PALW_KERNEL_ROUTE_TABLE_RECEIPTS_V1, &borsh::to_vec(claim).expect("a digest serializes")).unwrap_or_default()
    }

    /// What the route holds against a V2 bond — the ledger's reservations (a claim's collateral, a demand bond) and the deposits of
    /// its open chunk groups: the term V2's committed-collateral ledger adds, so no V2 gate counts it as free.
    pub fn reserved_of(&self, bond: &PalwBondKeyV2) -> u64 {
        self.ledger_reserved_of(bond).saturating_add(self.chunk_deposits_of_v1(bond)).saturating_add(self.signer_locks_of_v1(bond))
    }

    /// **G14 lane closure G-K4: the lowest blue score the pruning point may reach** — the first block that served material of a
    /// segmented claim that is still convictable (aux 143, `0x02`). `None`: no such material (every network below the route's fence).
    pub fn served_material_pruning_ceiling_v1(&self) -> Option<u64> {
        use crate::palw_g14_lane_closure_v1::*;
        self.aux
            .range((PALW_G14_LANE_CLOSURE_TABLE_V1, vec![PALW_SERVED_MATERIAL_PREFIX_V1])..)
            .take_while(|((table, key), _)| {
                *table == PALW_G14_LANE_CLOSURE_TABLE_V1 && key.first() == Some(&PALW_SERVED_MATERIAL_PREFIX_V1)
            })
            .filter_map(|(_, bytes)| borsh::from_slice::<PalwServedMaterialRowV1>(bytes).ok())
            .map(|row| row.first_blue_score)
            .min()
    }

    /// **G14 lane closure G-K1: the signer liability locks `bond` holds** (aux 143, `0x01 ‖ seat ‖ claim`; [`crate::palw_g14_lane_closure_v1`])
    /// — outside the ledger, like a chunk deposit, so the ledger is synced net of them and never lends them to a claim; in V2's committed
    /// ledger, so the bond cannot exit while one is held. 0 below the route's fence (no row is ever written there).
    pub fn signer_locks_of_v1(&self, bond: &PalwBondKeyV2) -> u64 {
        use crate::palw_g14_lane_closure_v1::*;
        let id = palw_kernel_bond_id_v1(bond);
        // G-K1 seat locks (`0x01`) and G-N2 native attestor locks (`0x03`): no `0x03` row exists below the mining fence.
        let mut attestor = vec![PALW_NATIVE_ATTESTOR_LOCK_PREFIX_V1];
        attestor.extend_from_slice(&id);
        [palw_kernel_signer_lock_seat_prefix_v1(&id), attestor]
            .into_iter()
            .map(|prefix| {
                self.aux
                    .range((PALW_G14_LANE_CLOSURE_TABLE_V1, prefix.clone())..)
                    .take_while(|((table, key), _)| *table == PALW_G14_LANE_CLOSURE_TABLE_V1 && key.starts_with(&prefix))
                    .filter_map(|(_, bytes)| borsh::from_slice::<PalwKernelSignerLockRowV1>(bytes).ok())
                    .map(|row| row.amount)
                    .fold(0u64, u64::saturating_add)
            })
            .fold(0u64, u64::saturating_add)
    }

    /// What the kernel LEDGER has reserved against a V2 bond (its `BondRowV1::reserved`). The ledger is synced net of everything
    /// else the bond backs — the chunk deposits included — so a deposit is never also a claim's collateral.
    pub fn ledger_reserved_of(&self, bond: &PalwBondKeyV2) -> u64 {
        let key = borsh::to_vec(&palw_kernel_bond_id_v1(bond)).expect("a digest serializes");
        self.rows
            .get(&(misaka_palw_kernel::rows::TABLE_BONDS_V1, key))
            .and_then(|b| borsh::from_slice::<misaka_palw_kernel::ledger::BondRowV1>(b).ok())
            .map(|b| b.reserved)
            .unwrap_or(0)
    }
}

/// **The payout key of a kernel payee**: `H(domain; payload)` under the `0xFD` prefix. One row per payee, accumulating (as the
/// panel's seat pay does).
pub fn palw_kernel_payout_key_v1(payload: &Hash64) -> Hash64 {
    let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_PAYOUT_DOMAIN_V1).to_state();
    s.update(payload.as_byte_slice());
    let mut out = [0u8; 64];
    out.copy_from_slice(s.finalize().as_bytes());
    out[0] = PALW_KERNEL_ROUTE_PAYOUT_KEY_PREFIX_V1;
    Hash64::from_bytes(out)
}

/// The interim challenge anchor and sample seed of a claim (grindable: derived from the claim id alone — the receipts' bindings).
pub fn palw_kernel_interim_challenge_v1(claim: &Digest) -> (Digest, Digest) {
    let derive = |tag: u8| {
        let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_INTERIM_CHALLENGE_DOMAIN_V1).to_state();
        s.update(&[tag]);
        s.update(claim);
        let mut out = [0u8; 64];
        out.copy_from_slice(s.finalize().as_bytes());
        out
    };
    (derive(0), derive(1))
}

/// **Lane ROLES (user decision 2026-10-27): the testnet-12 Panel=1 slice class's parameter root, attested public from
/// `palw_kernel_route_panel_one_v1`** (the DAA 17,000 slice fence, `PALW_T12_KERNEL_SLICE_FENCES_V1`). It is
/// `ParamCommitmentsV1::of(&wide128_v1(7).params).root()`: a synthetic fixture whose every parameter is regenerated from the seed
/// (`misaka/palw/kernel/examples/gen-wide128-palwkm.rs`), so its publication is self-evident. One fixed row; no model review or
/// judgement is made on chain (PRINCIPLES §9). Below the fence the attested set is byte-identical. Registered after genesis, the class
/// takes the 0.3 tier like every registered model. A hash is data identity only, never a proof of computation (PRINCIPLES §8).
pub const PALW_T12_KERNEL_SLICE_ATTESTED_ROOT_V1: [u8; 64] = [
    0x44, 0xc6, 0x28, 0x70, 0xde, 0xa5, 0xd1, 0x91, 0xff, 0x2b, 0xc2, 0xeb, 0x8a, 0x0a, 0x11, 0x42, 0xce, 0x40, 0x22, 0x21, 0x2e,
    0x6b, 0xe7, 0xf1, 0x9a, 0xd5, 0x89, 0x3f, 0x05, 0x2f, 0x22, 0xea, 0x7f, 0x90, 0x33, 0xda, 0xba, 0x21, 0x88, 0x5d, 0x65, 0x5e,
    0x61, 0x9a, 0xf5, 0x57, 0xab, 0x8e, 0x02, 0x09, 0x1e, 0x13, 0x9b, 0x46, 0xbb, 0x31, 0x69, 0x53, 0x53, 0x13, 0xed, 0xcb, 0x96,
    0x0e,
];

/// **lane SEED (G14 independent review MAJOR-1 / MINOR-1): the Panel=1 seed domain.** Past `palw_kernel_route_panel_one_v1` a
/// committed claim's seat draw, challenge anchor and sample seed are keyed by the claim id AND a round seed anchor (ADR-0130/ADR-0170)
/// recorded strictly after the commit — the same kind of post-commit anchor RFC-0018 Gate C draws its verifiers from — so a producer
/// that re-forms its claim id cannot know at commit which operator sits or which positions are sampled. No new randomness source.
pub const PALW_KERNEL_ROUTE_PANEL_ONE_SEED_DOMAIN_V1: &[u8] = b"misaka-palw/kernel-route/panel-one-seed/v1";

/// **Is a round seed anchor later than a commit?** `true` iff the anchor's span STARTS strictly after `committed_daa`
/// (`anchor.span × span_daa > committed_daa`), `span_daa` the lane's span length now. Then the anchor's block is strictly later than
/// the commit's, so the claim id was fixed before the anchor existed. An anchor recorded under a longer span length (before a span
/// shortening) only ever reads as older here — the predicate fails closed, never open. No anchor, no draw.
pub fn palw_kernel_panel_one_anchor_after_commit_v1(
    committed_daa: u64,
    span_daa: u64,
    anchor: Option<&crate::palw_execution_lane_v1::PalwExecSeedAnchorV1>,
) -> bool {
    anchor.is_some_and(|a| a.span.saturating_mul(span_daa.max(1)) > committed_daa)
}

/// The Panel=1 derivation `H(domain; tag ‖ claim ‖ anchor span ‖ anchor block ‖ anchor execution key)`: tag 0 the lottery seed,
/// 1 the challenge anchor, 2 the sample seed.
fn palw_kernel_panel_one_derive_v1(claim: &Digest, anchor: &crate::palw_execution_lane_v1::PalwExecSeedAnchorV1, tag: u8) -> [u8; 64] {
    let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_PANEL_ONE_SEED_DOMAIN_V1).to_state();
    s.update(&[tag]);
    s.update(claim);
    s.update(&anchor.span.to_le_bytes());
    s.update(anchor.block.as_byte_slice());
    s.update(anchor.execution_key.as_byte_slice());
    let mut out = [0u8; 64];
    out.copy_from_slice(s.finalize().as_bytes());
    out
}

/// **The Panel=1 lottery seed** of a claim under a post-commit anchor (see [`PALW_KERNEL_ROUTE_PANEL_ONE_SEED_DOMAIN_V1`]).
pub fn palw_kernel_panel_one_seed_v1(claim: &Digest, anchor: &crate::palw_execution_lane_v1::PalwExecSeedAnchorV1) -> Hash64 {
    Hash64::from_bytes(palw_kernel_panel_one_derive_v1(claim, anchor, 0))
}

/// **The Panel=1 challenge anchor and sample seed** of a claim under a post-commit anchor.
pub fn palw_kernel_panel_one_challenge_v1(
    claim: &Digest,
    anchor: &crate::palw_execution_lane_v1::PalwExecSeedAnchorV1,
) -> (Digest, Digest) {
    (palw_kernel_panel_one_derive_v1(claim, anchor, 1), palw_kernel_panel_one_derive_v1(claim, anchor, 2))
}

/// The interim lottery seed of a claim: `H("misaka-palw/kernel-route/interim-assignment/v1"; claim id)`.
pub fn palw_kernel_interim_seed_v1(claim: &Digest) -> Hash64 {
    let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_INTERIM_ASSIGNMENT_DOMAIN_V1).to_state();
    s.update(claim);
    let mut out = [0u8; 64];
    out.copy_from_slice(s.finalize().as_bytes());
    Hash64::from_bytes(out)
}

/// An interim seat's lottery key: `−log2(u) / W` (smaller wins), `u` the first 8 bytes of `H(domain; seed ‖ operator)`.
pub fn palw_kernel_interim_key_v1(seed: &Hash64, operator: &Hash64, weight: u128) -> u128 {
    let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_ROUTE_INTERIM_TICKET_DOMAIN_V1).to_state();
    s.update(seed.as_byte_slice());
    s.update(operator.as_byte_slice());
    let mut u = [0u8; 8];
    u.copy_from_slice(&s.finalize().as_bytes()[..8]);
    crate::palw_panel_v2::palw_draw_neg_log2_q64_v1(u64::from_le_bytes(u)) / weight.max(1)
}

/// The assignment root: `H(seats in order ‖ quorum)`.
pub fn palw_kernel_assignment_root_v1(seats: &[KernelSeatV1], quorum: u8) -> Digest {
    let mut s = blake2b_simd::Params::new().hash_length(64).key(b"misaka-palw/kernel-route/assignment-root/v1").to_state();
    s.update(&[quorum]);
    for seat in seats {
        s.update(&seat.kernel_bond);
        s.update(&borsh::to_vec(&seat.scope).expect("a scope serializes"));
    }
    let mut out = [0u8; 64];
    out.copy_from_slice(s.finalize().as_bytes());
    out
}

// ---- the public read model (RPC ops 210/211) ------------------------------------------------------------------------------

/// One open position demand, as a reader sees it.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct KernelDemandReadV1 {
    pub stage: u8,
    pub position: u32,
    pub demanders: u32,
    pub filed_daa: u64,
    pub deadline_daa: u64,
    /// The latest rejected response's class name (`malformed`, `wrong_root`, `fake_opening`, ...), if any.
    pub last_rejection: Option<String>,
}

/// **What public discovery returns for an OPV claim** (RFC-0015 §5): the clock facts a fresh verifier plans by.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct KernelOpvReadV1 {
    pub admitted_daa: u64,
    /// The latest DAA a fresh verifier may START from and still reach a first filing inside the window.
    pub verifier_start_cutoff_daa: u64,
    /// The earliest Final (the window's end).
    pub final_floor_daa: u64,
    /// The latest Final / decision, whatever is filed.
    pub hard_deadline_daa: u64,
    pub reservation: u64,
    pub max_gain: u64,
    /// What a Final of this claim means (never shown as a proof of correctness).
    pub statement: &'static str,
}

/// **Everything public about one claim** (nothing private exists in the route: every field is chain state): its lifecycle, the
/// public record a fresh verifier is built from, the positions served on chain, the open demands, and the interim assignment while
/// the Panel's receipts are being counted. `ledger_root` and `aux_root` anchor it to the committed state.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct KernelClaimReadV1 {
    pub claim_id: Digest,
    /// `program` or `pipeline`.
    pub kind: &'static str,
    /// How the claim's class verifies and finalizes (RFC-0015): `PanelLicensed` or `OptimisticPublicVerification`.
    pub mode: &'static str,
    /// The OPV clock facts a fresh verifier plans by (`None` for a Panel-licensed claim).
    pub opv: Option<KernelOpvReadV1>,
    /// **RFC-0015 §9 / §11.3**: the claim's settlement standing at the route's DAA (`crate::palw_kernel_settlement_v1`):
    /// `pending`, `final-revocable` (Final, still convictable: never "safe"), `settled`, `convicted` or `defaulted`.
    pub settlement: &'static str,
    /// The first DAA at which the claim is (or, absent a conviction or default, will be) settled; `None` before Final.
    pub settled_from_daa: Option<u64>,
    /// The lifecycle state, spelled out (`Final { final_daa: 7 }`, `Convicted { daa: 9 }`, ...).
    pub state: String,
    pub final_daa: Option<u64>,
    pub convicted: bool,
    pub rewarded: bool,
    pub reserved: u64,
    pub committed_daa: u64,
    pub liability_until: Option<u64>,
    pub producer_bond: Digest,
    pub job_id: Digest,
    pub class_id: Digest,
    /// `PublicClaimRecordV1::to_bytes` (program claims) or `PipelinePublicRecordV1::to_bytes`.
    pub public_record: Vec<u8>,
    /// Borsh of the class header (`EvidenceHeaderV1`) a program claim's verifier is built with (empty for a pipeline claim).
    pub record_header: Vec<u8>,
    /// `(stage, position, borsh ServedPositionV1)`.
    pub served: Vec<(u8, u32, Vec<u8>)>,
    pub demands: Vec<KernelDemandReadV1>,
    /// The interim assignment (`None` once the claim is covered or ended).
    pub seats: Vec<(PalwBondKeyV2, Digest)>,
    pub quorum: u8,
    pub assignment_deadline_daa: u64,
    pub receipts_counted: u32,
    pub ledger_root: Hash64,
    pub aux_root: Hash64,
}

/// The first table number of the route's consensus (aux) tables; the kernel ledger's own tables are numbered below it (op 211 serves
/// both, in key order, so a page is ledger rows then aux rows).
pub const PALW_KERNEL_ROUTE_FIRST_AUX_TABLE_V1: u8 = 32;

/// One page of the route's rows, in `(table, key)` order (ledger tables first, then the consensus tables).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct KernelRowsPageV1 {
    pub rows: Vec<(u8, Vec<u8>, Vec<u8>)>,
    /// The cursor to resume after (`None` at the end).
    pub next: Option<(u8, Vec<u8>)>,
    pub total_rows: u64,
}

/// One Final of the route, for a reader and for the beacon: the kernel's receipt, how the work reached Final, and — where the route
/// knows every fact the beacon needs — the borsh `AttributedWorkV1` (the `WorkFinalEventV1` and who stands behind it).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct KernelFinalReadV1 {
    pub receipt: misaka_palw_kernel::opv::FinalReceiptV1,
    /// `OptimisticUnapproved`, `PaidClaimV2`, or `PanelLicensed`. An optimistic
    /// timeout has no randomly selected verifier approval and exports no beacon event.
    pub final_path: &'static str,
    /// Borsh of `misaka_palw_challenge::AttributedWorkV1` (the event, then producer and recorded job payer; `Absent` only for a
    /// historical job without a payer row). `Some` only for a `PaidClaimV2` Final with authenticated selected approval (the RFC07
    /// adapter, `selected_approval_event_v1`); `None` for an optimistic timeout, a Panel-licensed Final, or an unapproved paid claim.
    pub event: Option<Vec<u8>>,
    pub statement: &'static str,
    /// **RFC-0015 §9 (GAP-B3)**: the claim's standing under the one kernel settlement predicate
    /// ([`crate::palw_kernel_settlement_v1`]) at the route's DAA: `final-revocable`, `settled`, `convicted` or `defaulted`. The
    /// beacon event's `claim_final` / `da_satisfied` are derived from it, so RFC-0010 V3 (`ChainPanelBeaconHistoryV1`), the v3
    /// sealed sources and every other reader see exactly what the EXEC slice and the RPC see.
    pub settlement: &'static str,
    /// **RFC07 record-only event of a Panel-licensed Final** (user decision 2026-10-17, ADR-0184): Borsh of
    /// `(FinalReceiptV1, settlement label, producer, job payer)` read from the rooted ledger rows — authenticated by the route's
    /// committed root, NEVER a beacon source and never credit (it is not in `event`, which every collector and the EXEC gate read).
    /// `None` for every other path.
    pub panel_record: Option<Vec<u8>>,
}

/// The beacon event of a selected-approved Final (RFC07 adapter): the kernel's `WorkFinalEventV1`, read through the ONE kernel
/// settlement predicate (RFC-0015 §9, GAP-B3) — a conviction withdraws the fact (`claim_final = false`), a default withdraws its
/// availability (`da_satisfied = false`) — and attributed from authenticated ledger rows (producer, and the job's permanent payer, so
/// one payer cannot fill the distinct-consumer quorum through several producers). No weight or reward: kernel claims reserve
/// B = F = 0; the event is a beacon fact only.
///
/// **A paid claim over a Panel-licensed base class exports no event (`Ok(None)`), not an error.** Its receipt is
/// `VerificationModeV1::PanelLicensed`, and `FinalReceiptV1::to_work_final_event` refuses a Panel-licensed Final that does not name
/// its Panel (`final_path(None)` is `Err`): the route does not know the licensing Panel's seed and epoch (remaining work). Before
/// this arm the `?` below turned that refusal into an `Err` of the WHOLE `finals_read_v1`, so one approved paid claim over a
/// Panel-licensed class would have failed op 212 and every beacon-source read that goes through it.
fn selected_approval_event_v1(
    ledger: &KernelLedgerV1,
    receipt: &misaka_palw_kernel::opv::FinalReceiptV1,
    settlement: crate::palw_kernel_settlement_v1::PalwKernelSettlementV1,
) -> Result<Option<Vec<u8>>, String> {
    selected_approval_work_v6(ledger, receipt, settlement)?.map(|work| borsh::to_vec(&work).map_err(|e| e.to_string())).transpose()
}

/// Same RFC07 event as the encoded compatibility reader, without a second ledger
/// projection or a serialize/decode round trip in native source consumers.
pub(crate) fn selected_approval_work_v6(
    ledger: &KernelLedgerV1,
    receipt: &misaka_palw_kernel::opv::FinalReceiptV1,
    settlement: crate::palw_kernel_settlement_v1::PalwKernelSettlementV1,
) -> Result<Option<misaka_palw_challenge::AttributedWorkV1>, String> {
    use crate::palw_kernel_settlement_v1::PalwKernelSettlementV1 as S;
    use misaka_palw_kernel::mode::VerificationModeV1;
    use misaka_palw_kernel::opv::WorkFinalContextV1;
    if receipt.mode == VerificationModeV1::PanelLicensed {
        return Ok(None);
    }
    let work = ledger.claims.get(&receipt.claim).map(|r| (r.class_binding_id, r.job_id));
    // The earliest acceptance of the work identity: the earliest commitment of any claim of the same job (a convicted or defaulted
    // earlier holder counts).
    let earliest = ledger
        .claims
        .values()
        .filter(|row| Some((row.class_binding_id, row.job_id)) == work)
        .map(|row| row.committed_daa)
        .min()
        .unwrap_or(receipt.accepted_daa);
    let ctx = WorkFinalContextV1 {
        accepted_position: earliest,
        settlement_position: receipt.final_daa,
        occurrence_index: 0,
        // Selected checkers are drawn independently of any Panel.
        validity_independent: true,
        depends_on_profiles: Vec::new(),
        panel: None,
    };
    let mut event = receipt.to_work_final_event(&ctx)?;
    match settlement {
        S::Convicted => event.claim_final = false,
        S::Defaulted => event.da_satisfied = false,
        S::FinalRevocable { .. } | S::Settled { .. } => {}
        S::Pending => event.claim_final = false,
    }
    let producer = ledger.claims.get(&receipt.claim).map(|r| r.producer).unwrap_or([0u8; 64]);
    let consumer = work
        .and_then(|(_, job)| ledger.job_poster(&job))
        .map_or(misaka_palw_challenge::RootV1::Absent, misaka_palw_challenge::RootV1::Present);
    let attributed = misaka_palw_challenge::AttributedWorkV1 {
        event,
        attribution: misaka_palw_challenge::SourceAttributionV1 { producer_id: producer, consumer_id: consumer },
    };
    Ok(Some(attributed))
}

/// **RFC07 record-only event of a Panel-licensed Final** (ADR-0184 §2): Borsh of `(FinalReceiptV1, settlement label, producer,
/// job payer)` from the rooted ledger rows, `Some` only for the `PanelLicensed` path. It is never a beacon event (`event` stays
/// `None` on that path) and never EXEC credit.
pub(crate) fn panel_record_v1(
    ledger: &KernelLedgerV1,
    receipt: &misaka_palw_kernel::opv::FinalReceiptV1,
    final_path: &'static str,
    settlement: crate::palw_kernel_settlement_v1::PalwKernelSettlementV1,
) -> Option<Vec<u8>> {
    if final_path != "PanelLicensed" {
        return None;
    }
    let work = ledger.claims.get(&receipt.claim).map(|r| (r.producer, r.job_id));
    let payer = work.and_then(|(_, job)| ledger.job_poster(&job));
    borsh::to_vec(&(receipt, settlement.label(), work.map(|(p, _)| p), payer)).ok()
}

impl PalwKernelRouteStateV1 {
    /// **The path label and the beacon event of one Final** (the RFC07 adapter's decision, apart from the ledger walk so it can be
    /// asserted on its own): an event only for a `PaidClaimV2` Final that `palw_exec_v2_selected_approval_v1` admits, never for an
    /// optimistic timeout, a Panel-licensed Final or a paid claim without its canonical approved Final.
    pub(crate) fn final_export_v1(
        &self,
        ledger: &KernelLedgerV1,
        receipt: &misaka_palw_kernel::opv::FinalReceiptV1,
        settlement: crate::palw_kernel_settlement_v1::PalwKernelSettlementV1,
    ) -> Result<(&'static str, Option<Vec<u8>>), String> {
        use misaka_palw_kernel::mode::VerificationModeV1;
        // A historical OPV Final states only that its dispute window expired.
        // Neither zero direct payout nor a matching local replay establishes
        // the selected-validator approval required for entropy/consensus credit.
        // Keep the receipt and settlement available for payment/history readers;
        // do not manufacture PanelIndependent identity from lifecycle state.
        //
        // **RFC07 selected-approval adapter.** The one authenticated source of a beacon event is a paid claim whose canonical
        // paid Final the native acceptance/restore checks admitted with the ASSIGNED positive quorum — randomly selected
        // checkers, a bound source and completed rounds (`palw_exec_v2_selected_approval_v1`, the same gate EXEC credit
        // uses). That approval rests on the selection rule and its explicit honest-fraction premise, never on a timeout, a
        // zero payout, a matching replay or an operator identity. A Panel-licensed Final still exports nothing: the route
        // does not know the licensing Panel's seed and epoch.
        Ok(match (receipt.mode, ledger.paid_claim_consumers_v2.contains_key(&receipt.claim)) {
            (_, true) => {
                let approved = crate::palw_exec_v2_verify::palw_exec_v2_selected_approval_v1(self, &Hash64::from_bytes(receipt.claim));
                ("PaidClaimV2", if approved { selected_approval_event_v1(ledger, receipt, settlement)? } else { None })
            }
            (VerificationModeV1::OptimisticPublicVerification, false) => ("OptimisticUnapproved", None),
            (VerificationModeV1::PanelLicensed, false) => ("PanelLicensed", None),
        })
    }

    /// Every historical Final in canonical order. A lifecycle timeout is readable,
    /// but cannot authorize beacon influence or substitute for selected approval.
    pub fn finals_read_v1(&self) -> Result<Vec<KernelFinalReadV1>, String> {
        let ledger = self.ledger_native_projection_v9()?;
        let mut out = Vec::new();
        for receipt in ledger.final_receipts() {
            let settlement = crate::palw_kernel_settlement_v1::palw_kernel_row_settlement_v1(&ledger, &receipt.claim, ledger.daa)
                .unwrap_or(crate::palw_kernel_settlement_v1::PalwKernelSettlementV1::Pending);
            let (final_path, event) = self.final_export_v1(&ledger, &receipt, settlement)?;
            let statement = receipt.assurance.statement();
            let panel_record = panel_record_v1(&ledger, &receipt, final_path, settlement);
            out.push(KernelFinalReadV1 { receipt, final_path, event, statement, settlement: settlement.label(), panel_record });
        }
        Ok(out)
    }

    /// **The public read of one claim** (see [`KernelClaimReadV1`]); `Ok(None)` for an unknown claim, `Err` only if the stored rows do
    /// not rebuild (corruption, not an input).
    pub fn claim_read_v1(&self, claim: &Digest) -> Result<Option<KernelClaimReadV1>, String> {
        let ledger = self.ledger_native_projection_v9()?;
        let Some(row) = ledger.claims.get(claim) else { return Ok(None) };
        let (kind, public_record, record_header) = match &row.body {
            misaka_palw_kernel::ledger::ClaimBodyV1::Program { .. } => {
                let (record, header) = ledger.public_record(claim).ok_or("a stored program claim has no public record")?;
                ("program", record.to_bytes(), borsh::to_vec(&header).map_err(|e| e.to_string())?)
            }
            misaka_palw_kernel::ledger::ClaimBodyV1::Pipeline { .. } => {
                let (record, header, binding) =
                    ledger.pipeline_public_record(claim).ok_or("a stored pipeline claim has no public record")?;
                // GAP 6 closed: the header a pipeline verifier is built with, with the class binding it checks the record against.
                ("pipeline", record.to_bytes(), borsh::to_vec(&(header, binding)).map_err(|e| e.to_string())?)
            }
            // K2-TIR-v4: the segmented record (the class's program, plan and v3 commitments, the evidence, the segment roots, the job's
            // prompt by length and root and the delivered ids); the header is the class's.
            misaka_palw_kernel::ledger::ClaimBodyV1::Segmented { .. } => {
                let record = misaka_palw_kernel::seg_ledger::SegmentedClaimRecordV1::of(&ledger, claim)
                    .ok_or("a stored segmented claim has no record")?;
                let header = ledger.classes.get(&row.class_binding_id).map(|c| c.header(row.class_binding_id)).ok_or("no class")?;
                ("segmented", record.to_bytes(), borsh::to_vec(&header).map_err(|e| e.to_string())?)
            }
            // RFC-0004 Part II: the typed claim's stored body is its public record, and the class's specification its header.
            misaka_palw_kernel::ledger::ClaimBodyV1::Spec(body) => {
                let spec = ledger.typed.classes.get(&row.class_binding_id).ok_or("a stored typed claim has no class")?;
                (
                    body.claim.kind(),
                    borsh::to_vec(body).map_err(|e| e.to_string())?,
                    borsh::to_vec(&spec.spec).map_err(|e| e.to_string())?,
                )
            }
        };
        let mut served = Vec::new();
        for ((c, stage, position), sp) in ledger.served.iter() {
            if c == claim {
                served.push((*stage, *position, borsh::to_vec(sp).map_err(|e| e.to_string())?));
            }
        }
        // A segmented claim keeps no served bytes: its served positions (and the progress of open demands) are borsh `SegProgressV1`.
        for ((c, stage, position), progress) in ledger.seg_progress.iter() {
            if c == claim {
                served.push((*stage, *position, borsh::to_vec(progress).map_err(|e| e.to_string())?));
            }
        }
        let demands = ledger
            .demands
            .iter()
            .filter(|((c, ..), _)| c == claim)
            .map(|((_, stage, position), d)| KernelDemandReadV1 {
                stage: *stage,
                position: *position,
                demanders: d.demanders.len() as u32,
                filed_daa: d.filed_daa,
                deadline_daa: d.deadline_daa,
                last_rejection: d.last_class().map(str::to_string),
            })
            .collect();
        let assignment = self.assignment_of(claim);
        let final_daa = match row.life.state {
            misaka_palw_kernel::lifecycle::ClaimStateV1::Final { final_daa } => Some(final_daa),
            _ => None,
        };
        let opv = ledger.opv_claim_view(claim).map(|v| KernelOpvReadV1 {
            admitted_daa: v.admitted_daa,
            verifier_start_cutoff_daa: v.verifier_start_cutoff_daa,
            final_floor_daa: v.final_floor_daa,
            hard_deadline_daa: v.hard_deadline_daa,
            reservation: v.reservation,
            max_gain: v.max_gain,
            statement: v.assurance.statement(),
        });
        let settlement = crate::palw_kernel_settlement_v1::palw_kernel_row_settlement_v1(&ledger, claim, ledger.daa)
            .unwrap_or(crate::palw_kernel_settlement_v1::PalwKernelSettlementV1::Pending);
        Ok(Some(KernelClaimReadV1 {
            claim_id: *claim,
            kind,
            mode: ledger.mode_of_class(&row.class_binding_id).name(),
            opv,
            settlement: settlement.label(),
            settled_from_daa: settlement.settled_from_daa(),
            state: format!("{:?}", row.life.state),
            final_daa,
            convicted: row.convicted,
            rewarded: row.rewarded,
            reserved: row.reserved,
            committed_daa: row.committed_daa,
            liability_until: row.liability_until,
            producer_bond: row.producer,
            job_id: row.job_id,
            class_id: row.class_binding_id,
            public_record,
            record_header,
            served,
            demands,
            seats: assignment.as_ref().map(|a| a.seats.iter().map(|s| (s.bond, s.kernel_bond)).collect()).unwrap_or_default(),
            quorum: assignment.as_ref().map(|a| a.quorum).unwrap_or(0),
            assignment_deadline_daa: assignment.as_ref().map(|a| a.deadline_daa).unwrap_or(0),
            receipts_counted: self.receipts_of(claim).len() as u32,
            ledger_root: self.ledger_root(),
            aux_root: self.aux_root(),
        }))
    }

    /// **A page of rows**, `(table, key, row)` in order, starting after `after` (exclusive; `None` = the beginning) and stopping once
    /// `max_bytes` of keys and rows are gathered (at least one row, so a page always makes progress). A reader that collects every page
    /// and rebuilds a ledger from them must reach [`Self::ledger_root`].
    /// **A fresh reader's copy of the route, rebuilt from op 211's pages** (G14 condition 9, RFC-0014 §3.4: a non-Panel verifier
    /// reproduces the whole post-commit path from public reads alone). `header` is op 211's Borsh header; `rows` every
    /// `(table, key, row)` of every page — the ledger's tables below [`PALW_KERNEL_ROUTE_FIRST_AUX_TABLE_V1`], the consensus (aux)
    /// tables from it. Refused unless the rows root to the served `ledger_root` and `aux_root` and no row is served twice. Every read
    /// of this type then runs on the reader's own copy, by the chain's own functions: the Final facts (`finals_read_v1`), the v3
    /// seal facts (`beacon_sealed_sources_v1`), an attempt's beacon (`attempt_beacon_v1`). (Authenticating the served roots against
    /// the chain's committed state is the state proof's job, shared by every public read.)
    pub fn from_served_rows_v1(
        header: &[u8],
        rows: impl IntoIterator<Item = (u8, Vec<u8>, Vec<u8>)>,
        ledger_root: &Hash64,
        aux_root: &Hash64,
    ) -> Result<Self, String> {
        let header: PalwKernelRouteHeaderV1 =
            borsh::from_slice(header).map_err(|e| format!("the route header does not decode: {e}"))?;
        let mut route = Self { header, rows: LedgerRowsV1::new(), aux: BTreeMap::new(), ledger_cache: KernelLedgerCacheV1::default() };
        for (table, key, row) in rows {
            let twice = if table < PALW_KERNEL_ROUTE_FIRST_AUX_TABLE_V1 {
                route.rows.insert((table, key), row).is_some()
            } else {
                route.aux.insert((table, key), row).is_some()
            };
            if twice {
                return Err(format!("a row of table {table} is served twice"));
            }
        }
        if route.ledger_root() != *ledger_root {
            return Err("the served rows do not root to the served ledger root".into());
        }
        if route.aux_root() != *aux_root {
            return Err("the served rows do not root to the served aux root".into());
        }
        crate::palw_positive_rows_v2::restore::validate_positive_aux_restore_v2(&route.aux)
            .map_err(|error| format!("inconsistent Positive aux rows: {error:?}"))?;
        Ok(route)
    }

    pub fn rows_page_v1(&self, after: Option<(u8, Vec<u8>)>, max_bytes: usize) -> KernelRowsPageV1 {
        use std::ops::Bound::{Excluded, Unbounded};
        let total_rows = (self.rows.len() + self.aux.len()) as u64;
        let start = match after {
            Some(cursor) => Excluded(cursor),
            None => Unbounded,
        };
        let mut rows = Vec::new();
        let mut bytes = 0usize;
        let mut next = None;
        // The ledger tables are numbered below the consensus tables, so the two maps concatenate in key order.
        let all = self.rows.range((start.clone(), Unbounded)).chain(self.aux.range((start, Unbounded)));
        for ((table, key), row) in all {
            if !rows.is_empty() && bytes + key.len() + row.len() > max_bytes {
                break;
            }
            bytes += key.len() + row.len();
            rows.push((*table, key.clone(), row.clone()));
            next = Some((*table, key.clone()));
        }
        // `next` is a resume point only if something follows it.
        if let Some(cursor) = &next {
            let after_last = self.rows.range((Excluded(cursor.clone()), Unbounded)).next().is_some()
                || self.aux.range((Excluded(cursor.clone()), Unbounded)).next().is_some();
            if !after_last {
                next = None;
            }
        }
        KernelRowsPageV1 { rows, next, total_rows }
    }
}

// ---- the route's own chunk lane (C4 F-C4R3-03; tag 113, aux table 41) --------------------------------------------------------------

/// **What a chunk group serves** — fixed at its first chunk, and what its TTL is bounded by: a group never outlives the last DAA at
/// which its object could still matter.
#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
#[borsh(use_discriminant = true)]
#[repr(u8)]
pub enum PalwKernelChunkTargetV1 {
    /// A kernel claim: the assembled object is a `FileProof` against it or a `Respond` to a demand on it (tag 110).
    Claim(Digest) = 0,
    /// An onboarding artifact binding: the assembled object is its refutation (tag 105).
    Binding {
        v2_class: Hash64,
        kernel_param_root: Hash64,
    } = 1,
    /// **OPV-BOOT #1: the conformance attempt of V2 class `v2_class`** — the assembled object is that class's conformance evidence
    /// (tag 109: a Post by the class's registrant, opening the group itself, or a Refute by anyone), applied by its own arm. Its
    /// deadline is OPV-BOOT's `palw_conformance_chunk_target_v1(route, v2_class, daa)` (the agreed signature: the attempt's evidence
    /// deadline for a Post, its refutation window's end for a Refute; `None` when no attempt is open).
    Conformance {
        v2_class: Hash64,
    } = 2,
    /// A protected flat reveal, opened only by its mature seal's authenticated actor.
    FlatProofV6 {
        vector: Hash64,
        actor: Digest,
    } = 3,
    FlatProofV7 {
        vector: Hash64,
        actor: Digest,
    } = 4,
    FlatProofV9 {
        vector: Hash64,
        actor: Digest,
    } = 5,
    /// An original mature paid native11 proof, with one private group per seal.
    FundedProofV11 {
        seal: Digest,
        actor: Digest,
    } = 6,
    /// Original paid typed-stage proof, independent of text native11 groups.
    StageProofV14 {
        seal: Digest,
        actor: Digest,
    } = 7,
}

/// Raw protected reveal plus the bounded signed outer envelope; never an arbitrary
/// sixteen-part object. This bounds assembly before its variable Borsh decode.
pub const PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V6: usize = misaka_palw_kernel::flat_seal6::FLAT_SEAL_MAX_PROOF_BYTES_V6 + (16 << 10);
pub const PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V9: usize = misaka_palw_kernel::flat_seal9::FLAT_SEAL_MAX_PROOF_BYTES_V9 + (16 << 10);
pub const PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V7: usize = misaka_palw_kernel::flat_seal7::FLAT_SEAL_MAX_PROOF_BYTES_V7 + (16 << 10);

/// A completing part and terminal court must fit together. Derive this upper
/// debit from fixed admitted metadata before opening/continuing a group.
pub fn protected_flat_chunk_finish_work_v6(h: &crate::palw_flat_model_vector_v3::FlatModelVectorHeaderV3) -> Option<u64> {
    let proof = usize::try_from(h.max_filing_bytes).ok()?.min(misaka_palw_kernel::flat_seal6::FLAT_SEAL_MAX_PROOF_BYTES_V6);
    let metadata = |bytes: usize| crate::palw_model_artifact_v2::model_artifact_work_v2(0, bytes.checked_add(1024)?);
    crate::palw_flat_model_vector_v3::flat_model_vector_work_v3(
        h.program_bytes_len,
        h.pc_instances,
        proof.checked_add(h.post_bytes_len as usize)?,
    )
    .and_then(|w| w.checked_add(h.max_court_work))
    .and_then(|w| w.checked_add(metadata(proof)?))
    .and_then(|w| w.checked_add(metadata(crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES + 3 * PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V6)?))
}

pub fn protected_flat_chunk_finish_work_v7(h: &crate::palw_flat_model_vector_v3::FlatModelVectorHeaderV3) -> Option<u64> {
    let proof = usize::try_from(h.max_filing_bytes).ok()?.min(misaka_palw_kernel::flat_seal7::FLAT_SEAL_MAX_PROOF_BYTES_V7);
    let metadata = |bytes: usize| crate::palw_model_artifact_v2::model_artifact_work_v2(0, bytes.checked_add(1024)?);
    crate::palw_flat_model_vector_v3::flat_model_vector_work_v3(
        h.program_bytes_len,
        h.pc_instances,
        proof.checked_add(h.post_bytes_len as usize)?,
    )
    .and_then(|w| w.checked_add(h.max_court_work))
    .and_then(|w| w.checked_add(metadata(proof)?))
    .and_then(|w| w.checked_add(metadata(crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES + 3 * PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V7)?))
}
pub fn protected_flat_chunk_cap_v9(h: &crate::palw_flat_model_vector_v3::FlatModelVectorHeaderV3) -> Option<usize> {
    usize::try_from(h.max_filing_bytes).ok()?.checked_add(16 << 10).filter(|x| *x <= PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V9)
}
pub fn protected_flat_chunk_finish_work_v9(
    route: &PalwKernelRouteStateV1,
    h: &crate::palw_flat_model_vector_v3::FlatModelVectorHeaderV3,
) -> Option<u64> {
    let proof = usize::try_from(h.max_filing_bytes).ok()?.min(misaka_palw_kernel::flat_seal9::FLAT_SEAL_MAX_PROOF_BYTES_V9);
    let metadata = |bytes: usize| crate::palw_model_artifact_v2::model_artifact_work_v2(0, bytes.checked_add(1024)?);
    crate::palw_flat_model_vector_v9::flat_model_vector_work_v9(route, &h.class, proof.checked_add(h.post_bytes_len as usize)?)
        .and_then(|w| w.checked_add(h.max_court_work))
        .and_then(|w| w.checked_add(metadata(proof)?))
        .and_then(|w| {
            w.checked_add(metadata(crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_BYTES + 3 * protected_flat_chunk_cap_v9(h)?)?)
        })
}

/// **One chunk of a prosecution object in the route's own lane** (the body of `KernelRouteChunkV1`, tag 113). `group` is
/// `palw_object_chunk_group_id_v1` of the assembled object's Borsh (a `PalwConsensusObjectV2`), the opener's bond signs every chunk
/// ([`palw_kernel_chunk_message_v1`]), and `target`/`count` are fixed by the group's first chunk.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct PalwKernelChunkV1 {
    pub opener: PalwBondKeyV2,
    pub group: Hash64,
    pub target: PalwKernelChunkTargetV1,
    pub index: u8,
    pub count: u8,
    pub bytes: Vec<u8>,
}

/// **A half-assembled group** (aux table 41): its target, its declared part count, its clock and the deposit its opener posted.
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct PalwKernelChunkGroupV1 {
    pub target: PalwKernelChunkTargetV1,
    pub count: u8,
    pub opened_daa: u64,
    /// The last DAA a part may arrive: `min(opened + PALW_KERNEL_CHUNK_TTL_MAX_DAA_V1, the target's deadline)`. Past it the group is
    /// dropped and its deposit forfeited.
    pub expires_daa: u64,
    pub deposit: u64,
    pub parts: BTreeMap<u8, Vec<u8>>,
}

/// **The message a chunk's opener signs**: `H(domain; network ‖ len ‖ borsh(chunk))` — every field, the target and the bytes included.
pub fn palw_kernel_chunk_message_v1(network_domain: Hash64, chunk: &PalwKernelChunkV1) -> Hash64 {
    let bytes = borsh::to_vec(chunk).expect("a chunk serializes");
    let mut s = blake2b_simd::Params::new().hash_length(64).key(PALW_KERNEL_CHUNK_DOMAIN_V1).to_state();
    s.update(network_domain.as_byte_slice());
    s.update(&(bytes.len() as u64).to_le_bytes());
    s.update(&bytes);
    let mut out = [0u8; 64];
    out.copy_from_slice(s.finalize().as_bytes());
    Hash64::from_bytes(out)
}

/// A group's row key: `borsh((opener, group))`.
pub fn palw_kernel_chunk_group_key_v1(opener: &PalwBondKeyV2, group: &Hash64) -> Vec<u8> {
    borsh::to_vec(&(*opener, *group)).expect("a bond key and a digest serialize")
}

/// **Cut `object` into the route lane's chunks** of at most `cap` bytes (unsigned: the opener signs each). At least one chunk, even
/// when the object fits one carrier; refused past `PALW_OBJECT_CHUNK_MAX_COUNT` chunks or a cap past one carrier.
pub fn palw_kernel_chunks_v1(
    object: &crate::palw_state_v2::PalwConsensusObjectV2,
    opener: PalwBondKeyV2,
    target: PalwKernelChunkTargetV1,
    cap: usize,
) -> Result<Vec<PalwKernelChunkV1>, String> {
    use crate::palw_state_v2::{PALW_OBJECT_CHUNK_MAX_BYTES, PALW_OBJECT_CHUNK_MAX_COUNT, palw_object_chunk_group_id_v1};
    let native = matches!(target, PalwKernelChunkTargetV1::FundedProofV11 { .. } | PalwKernelChunkTargetV1::StageProofV14 { .. });
    let count_cap = if native { 64usize } else { PALW_OBJECT_CHUNK_MAX_COUNT as usize };
    let byte_cap =
        if native { misaka_palw_kernel::flat_quota11::PROTECTED_FRAGMENT_BYTES_V11 as usize } else { PALW_OBJECT_CHUNK_MAX_BYTES };
    if cap == 0 || cap > byte_cap {
        return Err(format!("a chunk holds 1..={PALW_OBJECT_CHUNK_MAX_BYTES} bytes"));
    }
    let bytes = borsh::to_vec(object).map_err(|e| e.to_string())?;
    let count = bytes.len().div_ceil(cap).max(1);
    if count > count_cap {
        return Err(format!("{} bytes need {count} chunks of {cap}, past {PALW_OBJECT_CHUNK_MAX_COUNT}", bytes.len()));
    }
    let group = palw_object_chunk_group_id_v1(&bytes);
    Ok(bytes
        .chunks(cap)
        .enumerate()
        .map(|(i, part)| PalwKernelChunkV1 { opener, group, target, index: i as u8, count: count as u8, bytes: part.to_vec() })
        .collect())
}

/// **Is the assembled object a prosecution of the group's target?** A `KernelRouteV1` whose strictly decoded kernel object is a
/// `FileProof` against, or a `Respond` to a demand on, the target claim; a refutation (tag 105) of the target binding. Nothing else
/// rides this lane (other objects keep the certification lane's `ObjectChunk`).
pub fn palw_kernel_chunk_inner_matches_target_v1(
    inner: &crate::palw_state_v2::PalwConsensusObjectV2,
    target: &PalwKernelChunkTargetV1,
) -> bool {
    use crate::palw_state_v2::PalwConsensusObjectV2 as Obj;
    use misaka_palw_kernel::route::KernelRouteObjectV1 as K;
    match (inner, target) {
        (Obj::KernelRouteV1 { bytes, .. }, PalwKernelChunkTargetV1::Claim(id)) => {
            matches!(K::decode(bytes), Ok(K::FileProof { claim, .. } | K::Respond { claim, .. }) if claim == *id)
        }
        (
            Obj::ArtifactBindingChallengedV1 { v2_class, kernel_param_root, .. },
            PalwKernelChunkTargetV1::Binding { v2_class: class, kernel_param_root: root },
        ) => v2_class == class && kernel_param_root == root,
        (Obj::ConformanceEvidenceV1 { v2_class, .. }, PalwKernelChunkTargetV1::Conformance { v2_class: class }) => v2_class == class,
        (Obj::KernelRouteV1 { bytes, signer, .. }, PalwKernelChunkTargetV1::FlatProofV6 { vector, actor }) => {
            palw_kernel_bond_id_v1(signer) == *actor
                && matches!(K::decode(bytes), Ok(K::RevealFlatModelProofV6 { vector: id, .. }) if id == vector.as_bytes())
        }
        (Obj::KernelRouteV1 { bytes, signer, .. }, PalwKernelChunkTargetV1::FlatProofV7 { vector, actor }) => {
            palw_kernel_bond_id_v1(signer) == *actor
                && matches!(K::decode(bytes), Ok(K::RevealFlatModelProofV7 { vector: id, .. }) if id == vector.as_bytes())
        }
        (Obj::KernelRouteV1 { bytes, signer, .. }, PalwKernelChunkTargetV1::FundedProofV11 { seal, actor }) => {
            palw_kernel_bond_id_v1(signer) == *actor
                && matches!(misaka_palw_kernel::route::borrowed_native_action_v1(bytes),Ok(Some(a))
                    if a.tag==misaka_palw_kernel::route::TAG_FUNDED_EXECUTION_V11 && a.action==6 && a.body.get(..64)==Some(seal.as_slice()))
        }
        (Obj::KernelRouteV1 { bytes, signer, .. }, PalwKernelChunkTargetV1::StageProofV14 { seal, actor }) => {
            palw_kernel_bond_id_v1(signer) == *actor
                && matches!(misaka_palw_kernel::route::borrowed_native_action_v1(bytes),Ok(Some(a))
                    if a.tag==misaka_palw_kernel::route::TAG_STAGE_EXECUTION_V14 && a.action==17 && a.body.get(..64)==Some(seal.as_slice()))
        }
        (Obj::KernelRouteV1 { bytes, signer, .. }, PalwKernelChunkTargetV1::FlatProofV9 { vector, actor }) => {
            palw_kernel_bond_id_v1(signer) == *actor
                && matches!(K::decode(bytes), Ok(K::RevealFlatModelProofV9 { vector: id, .. }) if id == vector.as_bytes())
        }
        _ => false,
    }
}

/// **OPV-BOOT #1's deadline**: the agreed `palw_conformance_chunk_target_v1(route, v2_class, daa) -> Option<u64>` (the last DAA a part
/// may arrive; `None`: no attempt can take one — a complete check never needs the lane), implemented over the attempt rows in
/// [`crate::palw_onboarding_v1::palw_conformance_chunk_target_v1`] and wired here (OPVB).
pub fn palw_conformance_chunk_target_pending_v1(route: &PalwKernelRouteStateV1, v2_class: &Hash64, daa: u64) -> Option<u64> {
    crate::palw_onboarding_v1::palw_conformance_chunk_target_v1(route, v2_class, daa)
}

/// **The last DAA a proof against (or a response on) a claim in `state` could still matter** — an upper bound read from the claim
/// row and the policy: its liability horizon once Final or defaulted; before that, the latest Final its clock allows plus the
/// liability horizon. `None`: the claim is decided (convicted, timed out) and nothing it receives can change that.
pub fn palw_kernel_claim_horizon_bound_v1(
    policy: &LedgerPolicyV1,
    committed_daa: u64,
    liability_until: Option<u64>,
    state: &misaka_palw_kernel::lifecycle::ClaimStateV1,
) -> Option<u64> {
    use misaka_palw_kernel::lifecycle::ClaimStateV1 as S;
    let tail = policy.court_deadline_daa.saturating_add(policy.proof_grace_daa).saturating_add(policy.liability_daa);
    match state {
        S::Final { .. } | S::Unavailable { .. } => liability_until,
        S::TimedOut { .. } | S::Convicted { .. } => None,
        S::Checking { deadline_daa, .. } => Some(deadline_daa.saturating_add(policy.challenge_window_daa).saturating_add(tail)),
        S::ProbabilisticPass { window_end_daa, .. } | S::Challengeable { window_end_daa, .. } | S::WindowClosed { window_end_daa } => {
            Some(window_end_daa.saturating_add(tail))
        }
        S::Disputed { resume, .. } => palw_kernel_claim_horizon_bound_v1(policy, committed_daa, liability_until, resume),
        S::Committed | S::ChallengeBound { .. } => Some(
            committed_daa.saturating_add(policy.check_window_daa).saturating_add(policy.challenge_window_daa).saturating_add(tail),
        ),
    }
}

fn chunk_fixed_header_v1(bytes: &[u8]) -> Option<(u64, u64)> {
    let mut r = std::io::Cursor::new(bytes);
    let _ = PalwKernelChunkTargetV1::deserialize_reader(&mut r).ok()?;
    let count = u8::deserialize_reader(&mut r).ok()?;
    let _ = u64::deserialize_reader(&mut r).ok()?;
    let expires = u64::deserialize_reader(&mut r).ok()?;
    let deposit = u64::deserialize_reader(&mut r).ok()?;
    let parts = u32::deserialize_reader(&mut r).ok()?;
    (count > 0 && count <= crate::palw_state_v2::PALW_OBJECT_CHUNK_MAX_COUNT && parts <= count as u32).then_some((expires, deposit))
}
impl PalwKernelRouteStateV1 {
    /// One group of the route's chunk lane.
    pub fn chunk_group_v1(&self, opener: &PalwBondKeyV2, group: &Hash64) -> Option<PalwKernelChunkGroupV1> {
        self.aux_row(PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1, &palw_kernel_chunk_group_key_v1(opener, group))
    }

    /// Every half-assembled group, `(opener, group, row)`, in key order.
    pub fn chunk_groups_v1(&self) -> Vec<(PalwBondKeyV2, Hash64, PalwKernelChunkGroupV1)> {
        let t = PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1;
        self.aux
            .range((t, Vec::new())..(t + 1, Vec::new()))
            .filter_map(|((_, key), row)| {
                let (opener, group) = borsh::from_slice::<(PalwBondKeyV2, Hash64)>(key).ok()?;
                Some((opener, group, borsh::from_slice::<PalwKernelChunkGroupV1>(row).ok()?))
            })
            .collect()
    }

    /// How many groups `opener` holds open.
    pub fn chunk_groups_of_v1(&self, opener: &PalwBondKeyV2) -> usize {
        self.chunk_deposit_headers_v1(opener).count()
    }

    /// Bond-prefix reads and fixed metadata only: committed capital must not decode
    /// every actor's variable proof payload before a processing-budget reservation.
    fn chunk_deposit_headers_v1(&self, opener: &PalwBondKeyV2) -> impl Iterator<Item = u64> + '_ {
        let prefix = borsh::to_vec(opener).expect("fixed bond key");
        let t = PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1;
        self.aux.range((t, prefix.clone())..(t + 1, Vec::new())).take_while(move |((_, key), _)| key.starts_with(&prefix)).filter_map(
            |((_, key), bytes)| {
                if key.len() != 132 {
                    return None;
                }
                chunk_fixed_header_v1(bytes).map(|(_, deposit)| deposit)
            },
        )
    }

    /// The deposits `bond`'s open groups hold against its collateral (part of what V2's committed-collateral ledger and both
    /// withdrawal gates read as the route's reservation).
    pub fn chunk_deposits_of_v1(&self, bond: &PalwBondKeyV2) -> u64 {
        self.chunk_deposit_headers_v1(bond).fold(0u64, u64::saturating_add)
    }

    /// Read expiry/deposit headers without cloning proof payloads on every block.
    /// The aggregate fixed-row scan remains a separate resource requirement.
    pub fn expired_chunk_headers_v1(&self, daa: u64) -> Vec<(PalwBondKeyV2, Hash64, u64)> {
        let t = PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1;
        self.aux
            .range((t, Vec::new())..(t + 1, Vec::new()))
            .filter_map(|((_, key), bytes)| {
                let (expires, deposit) = chunk_fixed_header_v1(bytes)?;
                if daa <= expires {
                    return None;
                }
                let (opener, group) = borsh::from_slice(key).ok()?;
                Some((opener, group, deposit))
            })
            .collect()
    }

    /// **The last DAA at which an object for `target` could still change anything** (`None`: nothing can — the claim is decided or
    /// unknown, the binding refuted or unknown). A group's TTL is never longer.
    pub fn chunk_target_deadline_v1(&self, target: &PalwKernelChunkTargetV1, daa: u64) -> Option<u64> {
        match target {
            PalwKernelChunkTargetV1::Claim(id) => {
                let key = borsh::to_vec(id).expect("a digest serializes");
                let row: misaka_palw_kernel::ledger::ClaimRowV1 =
                    borsh::from_slice(self.rows.get(&(misaka_palw_kernel::rows::TABLE_CLAIMS_V1, key))?).ok()?;
                if row.convicted {
                    return None;
                }
                palw_kernel_claim_horizon_bound_v1(&self.header.policy, row.committed_daa, row.liability_until, &row.life.state)
            }
            PalwKernelChunkTargetV1::Binding { v2_class, kernel_param_root } => {
                let row = self.artifact_binding_v1(v2_class, kernel_param_root)?;
                // Refutable while `daa < final_daa`.
                (!row.refuted).then(|| row.final_daa.saturating_sub(1))
            }
            PalwKernelChunkTargetV1::Conformance { v2_class } => palw_conformance_chunk_target_pending_v1(self, v2_class, daa),
            PalwKernelChunkTargetV1::FlatProofV6 { vector, actor } => {
                let header = self.flat_model_vector_header_v3(vector)?;
                let seal = self.flat_model_seal_v6(vector, actor)?.seal;
                (self.flat_model_vector_protected_v6(vector)
                    && !header.refuted
                    && !self.flat_vector_unavailable_v3(vector)
                    && !seal.spent
                    && daa >= seal.mature_daa
                    && daa < seal.expires_daa
                    && daa < header.liability_until)
                    .then(|| seal.expires_daa.min(header.liability_until).saturating_sub(1))
            }
            PalwKernelChunkTargetV1::FlatProofV7 { vector, actor } => {
                let header = self.flat_model_vector_header_v3(vector)?;
                let seal = self.flat_model_seal_v7(vector, actor)?.seal;
                (self.flat_model_vector_protected_v7(vector)
                    && !header.refuted
                    && !self.flat_vector_unavailable_v7(vector)
                    && !seal.spent
                    && daa >= seal.mature_daa
                    && daa < seal.expires_daa
                    && daa < header.liability_until)
                    .then(|| seal.expires_daa.min(header.liability_until).saturating_sub(1))
            }
            PalwKernelChunkTargetV1::FundedProofV11 { seal, actor } => {
                let original = self.execution_seal_v11(seal)?;
                let job = self.execution_job_header_v11(&original.job_id)?;
                (original.actor == *actor
                    && !original.spent
                    && job.terminal == misaka_palw_kernel::flat_execution11::ExecutionTerminalV11::Challengeable
                    && daa >= original.mature_daa
                    && daa < original.reveal_until)
                    .then(|| original.reveal_until.saturating_sub(1))
            }
            PalwKernelChunkTargetV1::StageProofV14 { seal, actor } => self.stage_proof_deadline_v14(seal, actor, daa),
            PalwKernelChunkTargetV1::FlatProofV9 { vector, actor } => {
                let header = self.flat_model_vector_header_v3(vector)?;
                let seal = self.flat_model_seal_v9(vector, actor)?.seal;
                (self.flat_model_vector_protected_v9(vector)
                    && !header.refuted
                    && !self.flat_vector_unavailable_v9(vector)
                    && !seal.spent
                    && daa >= seal.mature_daa
                    && daa < seal.expires_daa
                    && daa < header.liability_until)
                    .then(|| seal.expires_daa.min(header.liability_until).saturating_sub(1))
            }
        }
    }

    /// **The object `chunk` completes, if it completes its group**: every part present (the stored ones and this one), coherent with
    /// the stored group, the assembled bytes hashing to the group id and decoding to one object. `None` otherwise — the fold refuses
    /// what this cannot assemble. (The acceptance layer checks the assembled object's own signature at this chunk.)
    pub fn chunk_completion_v1(&self, chunk: &PalwKernelChunkV1) -> Option<crate::palw_state_v2::PalwConsensusObjectV2> {
        if matches!(chunk.target, PalwKernelChunkTargetV1::FundedProofV11 { .. }) {
            return self.funded_proof_chunk_completion_v11(chunk);
        }
        if matches!(chunk.target, PalwKernelChunkTargetV1::StageProofV14 { .. }) {
            return None; // prepaid Stage assembly belongs to its own fold
        }
        if chunk.count == 0 || chunk.index >= chunk.count || chunk.bytes.is_empty() {
            return None;
        }
        if let PalwKernelChunkTargetV1::FlatProofV6 { vector, actor } = chunk.target {
            let header = self.flat_model_vector_header_v3(&vector)?;
            let seal = self.flat_model_seal_v6(&vector, &actor)?;
            if actor != palw_kernel_bond_id_v1(&chunk.opener)
                || seal.bond != chunk.opener
                || seal.seal.spent
                || !self.flat_model_vector_protected_v6(&vector)
                || header.refuted
                || self.flat_vector_unavailable_v3(&vector)
            {
                return None;
            }
        }
        if let PalwKernelChunkTargetV1::FlatProofV7 { vector, actor } = chunk.target {
            let header = self.flat_model_vector_header_v3(&vector)?;
            let seal = self.flat_model_seal_v7(&vector, &actor)?;
            if actor != palw_kernel_bond_id_v1(&chunk.opener)
                || seal.bond != chunk.opener
                || seal.seal.spent
                || !self.flat_model_vector_protected_v7(&vector)
                || header.refuted
                || self.flat_vector_unavailable_v7(&vector)
            {
                return None;
            }
        }
        if let PalwKernelChunkTargetV1::FlatProofV9 { vector, actor } = chunk.target {
            let header = self.flat_model_vector_header_v3(&vector)?;
            let seal = self.flat_model_seal_v9(&vector, &actor)?;
            if actor != palw_kernel_bond_id_v1(&chunk.opener)
                || seal.bond != chunk.opener
                || seal.seal.spent
                || !self.flat_model_vector_protected_v9(&vector)
                || header.refuted
                || self.flat_vector_unavailable_v9(&vector)
            {
                return None;
            }
        }
        let stored = self.chunk_group_v1(&chunk.opener, &chunk.group);
        let mut parts: BTreeMap<u8, &[u8]> = BTreeMap::new();
        if let Some(stored) = &stored {
            if stored.count != chunk.count || stored.target != chunk.target || stored.parts.contains_key(&chunk.index) {
                return None;
            }
            parts.extend(stored.parts.iter().map(|(i, p)| (*i, p.as_slice())));
        }
        parts.insert(chunk.index, chunk.bytes.as_slice());
        if parts.len() != chunk.count as usize {
            return None;
        }
        let size: usize = parts.values().map(|p| p.len()).sum();
        let proof_cap = match chunk.target {
            PalwKernelChunkTargetV1::FlatProofV6 { .. } => Some(PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V6),
            PalwKernelChunkTargetV1::FlatProofV7 { .. } => Some(PALW_FLAT_PROOF_CHUNK_MAX_BYTES_V7),
            PalwKernelChunkTargetV1::FlatProofV9 { vector, .. } => {
                Some(protected_flat_chunk_cap_v9(&self.flat_model_vector_header_v3(&vector)?)?)
            }
            _ => None,
        };
        if proof_cap.is_some_and(|cap| size > cap) {
            return None;
        }
        let mut whole = Vec::with_capacity(size);
        for i in 0..chunk.count {
            whole.extend_from_slice(parts.get(&i)?);
        }
        if crate::palw_state_v2::palw_object_chunk_group_id_v1(&whole) != chunk.group {
            return None;
        }
        borsh::from_slice(&whole).ok()
    }
}

impl PalwKernelRouteStateV1 {
    /// Native-only projection of already admitted, journaled class9 rows. Each
    /// historical registration was fully independently checked in its block.
    /// Remote snapshot consumers use ledger()/full from_rows and an external
    /// chain anchor, never this fixed-prefix operational projection.
    pub(crate) fn ledger_native_projection_v9(&self) -> Result<crate::palw_native_resource_v1::ReservedKernelLedgerV1, String> {
        self.ledger_native_projection_checked_v9().map_err(|e| e.to_string())
    }

    pub(crate) fn ledger_native_projection_checked_v9(
        &self,
    ) -> Result<crate::palw_native_resource_v1::ReservedKernelLedgerV1, PalwKernelLedgerProjectionErrorV1> {
        use crate::palw_native_resource_v1::NativeDecodeErrorV1 as E;
        use misaka_palw_kernel::{ledger::flat_candidate9::*, rows::*};
        let commitment_scope = self.commitment_scope_checked_v1()?;
        let mut count = 0usize;
        let mut bytes = 0usize;
        for ((_, _), row) in
            self.rows.range((TABLE_FLAT_CONFORMANCE_CLASSES_V9, Vec::new())..(TABLE_FLAT_CONFORMANCE_CLASSES_V9 + 1, Vec::new()))
        {
            count += 1;
            bytes = bytes.checked_add(row.len()).ok_or_else(|| E::Decode("native9 registry size overflow".into()))?;
            if count > FLAT_CANDIDATE_REGISTRY_MAX_V9
                || row.len() > FLAT_CANDIDATE_RECORD_MAX_BYTES_V9
                || bytes > FLAT_CANDIDATE_IMPORT_MAX_BYTES_V9
            {
                return Err(E::Decode("native9 admitted registry count/raw residency cap".into()));
            }
        }
        if count == 0 {
            return self.ledger_checked_v1();
        }
        if let Some(cached) = self.ledger_cache.native_projection().map_err(E::Resource)? {
            debug_assert!(cached.scalars() == self.header.scalars);
            debug_assert!(cached.flat_conformance_classes_v9.is_empty());
            debug_assert!(cached.native_candidate_count_v9() == count);
            debug_assert!(cached.to_rows().iter().all(|(k, v)| self.rows.get(k) == Some(v)));
            debug_assert_eq!(
                cached.to_rows().len(),
                self.rows.keys().filter(|(t, _)| *t != TABLE_FLAT_CONFORMANCE_CLASSES_V9).count()
            );
            PALW_KERNEL_LEDGER_CACHE_HITS_V1.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            let mut cached = cached;
            // RFC-0006: the reserved ledger is mutated only through its typed methods (no `DerefMut`).
            cached.set_commitment_scope_from_daa_v1(commitment_scope);
            cached.reserve_projection_v1(self).map_err(E::Resource)?;
            self.apply_paid_claim_consumer_inputs_checked_v6(cached.paid_consumer_projection_mut_v1())?;
            return Ok(cached);
        }
        let lease = crate::palw_native_resource_v1::reserve_ledger_expansion_v1(self, true).map_err(E::Resource)?;
        let rows: LedgerRowsV1 = self
            .rows
            .iter()
            .filter(|((table, _), _)| *table != TABLE_FLAT_CONFORMANCE_CLASSES_V9)
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect();
        let mut ledger = KernelLedgerV1::from_rows(&self.template(), self.header.scalars, &rows).map_err(E::Decode)?;
        for ((_, key), row) in
            self.rows.range((TABLE_FLAT_CONFORMANCE_CLASSES_V9, Vec::new())..(TABLE_FLAT_CONFORMANCE_CLASSES_V9 + 1, Vec::new()))
        {
            let class: Digest = borsh::from_slice(key).map_err(|e| E::Decode(e.to_string()))?;
            let owner: Digest = row
                .get(..64)
                .ok_or_else(|| E::Decode("native9 truncated admitted owner".into()))?
                .try_into()
                .map_err(|_| E::Decode("native9 owner size".into()))?;
            ledger.note_native_candidate_projection_v9(owner, class).map_err(E::Decode)?;
        }
        ledger.commitment_scope_from_daa = commitment_scope;
        self.apply_paid_claim_consumer_inputs_checked_v6(&mut ledger)?;
        Ok(crate::palw_native_resource_v1::ReservedKernelLedgerV1::from_preflight_v1(ledger, lease))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// **C4 F-C4R4-16 (ADR-0032 49 %)**: the route's interim accuser share — and so the demanders' share of a default and the
    /// onboarding challenger's — is at most 490‰; a self-reporter keeps at most 49 % of a slash, a net loss of at least 51 %.
    #[test]
    fn palw_kernel_route_the_interim_reporter_share_is_adr_0032s_49_percent() {
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        assert_eq!(p.accuser_reward_permille, 490);
        assert_eq!(crate::palw_onboarding_v1::PALW_ONBOARDING_CHALLENGER_REWARD_PERMILLE_V1, 490);
        let kept = p.claim_collateral - p.claim_collateral * u64::from(p.accuser_reward_permille) / 1000;
        assert!(kept * 100 >= p.claim_collateral * 51, "net loss {kept} of {}", p.claim_collateral);
    }

    /// **AUDIT-3 m3 / E1**: a convicted producer that is also the poster and the accuser loses, net, only the collateral kept after
    /// the 49 % share plus the BURNED parts of the reward and the V2 fee (on a post-Final conviction 90 % of each returns to the
    /// poster, `palw_kernel_uncertified_split_v1`); that is at least the external gain bound / 0.90 detection.
    #[test]
    fn palw_kernel_route_detection_loss_covers_gain_at_90_percent() {
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let kept = p.claim_collateral as u128 - p.claim_collateral as u128 * u128::from(p.accuser_reward_permille) / 1000;
        let burned = |x: u64| crate::palw_security_certification_v1::palw_kernel_uncertified_split_v1(x).0 as u128;
        let net = kept + burned(p.claim_reward) + burned(crate::palw_g14_values_v1::PALW_G14_FUNDED_FEE_SOMPI_V1);
        let gain = crate::palw_g14_values_v1::PALW_G14_KERNEL_PANEL_ONE_EXTERNAL_GAIN_BOUND_SOMPI_V1.unwrap() as u128;
        assert!(net * 90 >= gain * 100, "net loss {net} < gain {gain} / 0.90");
        assert!(net * 99 >= gain * 100);
    }

    /// **E1**: producer = poster = accuser, conviction after Final. That one party's balance, summed over every leg the rules move
    /// (collateral slashed; the reporter share paid back to it as accuser; the escrowed reward and the V2 fee it paid, split as an
    /// uncertified hold with the refund back to it as poster), falls by at least gain / 0.9. Arithmetic over the route's own policy
    /// and split function (not a node run).
    #[test]
    fn e1_self_posting_self_accusing_producer_loses_at_least_gain_over_detection() {
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let c = p.claim_collateral as i128;
        let share = c * i128::from(p.accuser_reward_permille) / 1000;
        let fee = crate::palw_g14_values_v1::PALW_G14_FUNDED_FEE_SOMPI_V1;
        let split = crate::palw_security_certification_v1::palw_kernel_uncertified_split_v1;
        let (reward_refund, fee_refund) = (split(p.claim_reward).1 as i128, split(fee).1 as i128);
        let delta = -c + share - p.claim_reward as i128 + reward_refund - fee as i128 + fee_refund;
        let gain = crate::palw_g14_values_v1::PALW_G14_KERNEL_PANEL_ONE_EXTERNAL_GAIN_BOUND_SOMPI_V1.unwrap() as i128;
        assert!(-delta * 90 >= gain * 100, "balance falls by {} < gain {gain} / 0.9", -delta);
    }

    #[test]
    fn the_interim_policy_validates_and_the_bond_digest_separates_indices() {
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        p.validate().unwrap();
        let b = |i| PalwBondKeyV2(crate::tx::TransactionOutpoint::new(crate::tx::TransactionId::from_u64_word(9), i));
        assert_ne!(palw_kernel_bond_id_v1(&b(0)), palw_kernel_bond_id_v1(&b(1)));
        let state = PalwKernelRouteStateV1::new(p, None, LedgerScalarsV1::default());
        assert_eq!(state.ledger().unwrap().root(), state.ledger_root().as_bytes(), "an empty state roots like an empty ledger");
    }

    #[test]
    fn authenticated_scope_policy_survives_public_snapshot_cache_and_reverts_with_its_aux_row() {
        let policy = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let mut state = PalwKernelRouteStateV1::new(policy, None, LedgerScalarsV1::default());
        let historical_root = state.aux_root();
        let ledger_root = state.ledger_root();
        let cached = state.ledger().unwrap().as_rebuilt_from_v1(&state.rows);
        state.ledger_cache.set(cached);
        state.aux.insert((PALW_KERNEL_ROUTE_TABLE_COMMITMENT_SCOPE_V1, Vec::new()), borsh::to_vec(&77u64).unwrap());
        assert_ne!(state.aux_root(), historical_root, "the response contract is authenticated by the route root");
        assert_eq!(state.ledger_root(), ledger_root, "consumer policy is not silently added to the historical ledger root");
        assert_eq!(state.ledger().unwrap().commitment_scope_from_daa, Some(77), "cached reads re-inject the authenticated policy");
        let restored: PalwKernelRouteStateV1 = borsh::from_slice(&borsh::to_vec(&state).unwrap()).unwrap();
        assert_eq!(restored.ledger().unwrap().commitment_scope_from_daa, Some(77));
        assert_eq!(restored.aux_root(), state.aux_root());
        state.aux.remove(&(PALW_KERNEL_ROUTE_TABLE_COMMITMENT_SCOPE_V1, Vec::new()));
        assert_eq!(state.ledger().unwrap().commitment_scope_from_daa, None, "a reverted scope row cannot survive in the cache");
        assert_eq!(state.aux_root(), historical_root);
        state.aux.insert((PALW_KERNEL_ROUTE_TABLE_COMMITMENT_SCOPE_V1, Vec::new()), vec![1]);
        assert!(state.ledger().is_err(), "a malformed policy never falls back to historical disclosure");
    }

    #[test]
    fn the_interim_opv_policy_validates_against_the_interim_ledger_policy_and_roots_like_its_ledger() {
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let opv = crate::palw_panel_free_v1::PalwPanelFreeFenceV1::at(crate::config::params::ForkActivation::new(7)).opv_policy();
        opv.validate(&p).unwrap();
        // The test node's four-adjudication block must still satisfy the OPV relations.
        let mut small = p;
        small.max_adjudications_per_block = 4;
        opv.validate(&small).unwrap();
        let state = PalwKernelRouteStateV1::new(p, Some(opv), LedgerScalarsV1::default());
        assert_eq!(
            state.ledger().unwrap().root(),
            state.ledger_root().as_bytes(),
            "an empty OPV state roots like an empty OPV ledger"
        );
        let plain = PalwKernelRouteStateV1::new(p, None, LedgerScalarsV1::default());
        assert_ne!(state.ledger_root(), plain.ledger_root(), "the OPV root form is not the historical one");
        // OPV-BOOT GAP-B1a: with tables 25 and 26 empty there is no root extension — both forms are what they were before them.
        let (opv_ledger, plain_ledger) = (state.ledger().unwrap(), plain.ledger().unwrap());
        assert!(
            opv_ledger.claim_beacon_salts.is_empty()
                && opv_ledger.forfeited_claim_seals.is_empty()
                && opv_ledger.job_posters.is_empty()
        );
        assert_eq!(state.ledger_root().as_bytes(), opv_ledger.root_parts_v2().root(), "the OPV form, unextended");
        assert_eq!(plain.ledger_root().as_bytes(), plain_ledger.root_parts().root(), "the historical form, unextended");
        // The v3 beacon's window against the interim seal TTL: OPV-BOOT's interim W = 40 needs 2·W ≤ 100.
        assert!(misaka_palw_kernel::ledger::seal_ttl_admits_beacon_window_v1(&p, 40));
        assert!(!misaka_palw_kernel::ledger::seal_ttl_admits_beacon_window_v1(&p, p.seal_ttl_daa / 2 + 1));
    }

    /// GAP 6: a pipeline claim's `record_header` is borsh `(PipelineHeaderV1, PipelineClassV1)` — the header a pipeline verifier is
    /// built with and the class binding it checks the record against.
    #[test]
    fn a_pipeline_claims_record_header_has_a_wire_form() {
        use misaka_palw_kernel::pipeline::PipelineHeaderV1;
        use misaka_palw_kernel::pipeline_public::PipelineClassV1;
        let header = PipelineHeaderV1 { network_domain: [1; 64], ruleset_digest: [2; 64], class_binding_id: [3; 64] };
        let binding = PipelineClassV1 {
            descriptor_digest: [4; 64],
            pipeline_root: [5; 64],
            plan_root: [6; 64],
            artifact_roots: vec![[7; 64]],
            decode: Some(misaka_palw_kernel::job::DecodeRuleV1::Greedy),
        };
        let bytes = borsh::to_vec(&(header, binding.clone())).unwrap();
        let back: (PipelineHeaderV1, PipelineClassV1) = borsh::from_slice(&bytes).unwrap();
        assert_eq!(back, (header, binding));
    }

    /// K2-TIR-v4 is in the route's template (armed there only) and a fresh route state's ledger is the rows' ledger, cached or not.
    #[test]
    fn the_route_template_carries_k2_tir_v4_and_the_cache_is_never_state() {
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let template = palw_kernel_route_template_v1(p);
        let v4 = misaka_palw_kernel::descriptor::k2_tir_v4_descriptor();
        assert!(template.known.iter().any(|d| d.digest() == v4.digest()));
        let v5 = misaka_palw_kernel::descriptor::k2_tir_v5_descriptor();
        assert!(template.known.iter().any(|d| d.digest() == v5.digest()) && v5.digest() != v4.digest());
        let mut state = PalwKernelRouteStateV1::new(p, None, LedgerScalarsV1::default());
        let plain = state.clone();
        let rebuilt = state.ledger().unwrap().as_rebuilt_from_v1(&state.rows);
        state.ledger_cache.set(rebuilt);
        assert_eq!(state, plain, "a cache is not part of what a state is");
        assert_eq!(borsh::to_vec(&state).unwrap(), borsh::to_vec(&plain).unwrap(), "and never encoded");
        assert_eq!(state.ledger().unwrap().root(), plain.ledger().unwrap().root());
        let decoded: PalwKernelRouteStateV1 = borsh::from_slice(&borsh::to_vec(&state).unwrap()).unwrap();
        assert!(!decoded.ledger_cache.is_set(), "a decoded state starts without it");
    }

    /// **RFC-0004 Part II**: an unarmed route (no `palw_typed_roots_v1`) has the historical schedule, `config_root` and root byte for
    /// byte; an armed one schedules `K2-TR-v1` from the fence's height and is another configuration.
    #[test]
    fn the_unarmed_typed_roots_fence_leaves_the_schedule_config_root_and_root_unchanged() {
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let opv = crate::palw_panel_free_v1::PalwPanelFreeFenceV1::at(crate::config::params::ForkActivation::new(7)).opv_policy();
        for o in [None, Some(opv)] {
            let historical = palw_kernel_route_template_opv_v1(p, o);
            let unarmed = PalwKernelRouteStateV1::new(p, o, LedgerScalarsV1::default());
            assert_eq!(unarmed.header.typed_roots, None);
            assert_eq!(
                unarmed.header.config_root,
                config_root_of(&historical.schedule, &historical.known),
                "the historical config root"
            );
            assert_eq!(unarmed.template().schedule, historical.schedule, "the historical schedule");
            assert_eq!(unarmed.ledger().unwrap().root(), historical.root(), "the historical root");
            let armed = PalwKernelRouteStateV1::new_typed(p, o, Some(11), LedgerScalarsV1::default());
            assert_ne!(armed.header.config_root, unarmed.header.config_root, "arming is another configuration");
            let l = armed.ledger().unwrap();
            assert_eq!(armed.ledger_root().as_bytes(), l.root(), "an armed state roots like its ledger");
            let tr = misaka_palw_kernel::spec::k2_tr_v1_descriptor().digest();
            assert_eq!(
                l.schedule.standing_at(&tr, 10),
                misaka_palw_kernel::descriptor::KernelStandingV1::NotActive(KernelStatusV1::Active { since_daa: 11 })
            );
            assert_eq!(l.schedule.standing_at(&tr, 11), misaka_palw_kernel::descriptor::KernelStandingV1::Active);
        }
    }

    #[test]
    fn the_tail_and_tables_are_the_allocated_ones() {
        assert_eq!(PALW_CARRIAGE_KERNEL_ROUTE_TAIL_V1, 0xEC);
        assert_eq!(
            (PALW_KERNEL_ROUTE_TABLE_BOND_KEYS_V1, PALW_KERNEL_ROUTE_TABLE_ASSIGNMENTS_V1, PALW_KERNEL_ROUTE_TABLE_RECEIPTS_V1),
            (32, 33, 34)
        );
        assert_eq!(PALW_KERNEL_ROUTE_TABLE_BLOCK_BUDGET_V1, 35);
        assert!(PALW_KERNEL_ROUTE_MAX_OBJECT_BYTES_V1 > 1_000_000);
        // C4 F-C4R3-03: the route's own chunk lane (the lead's allocation of 2026-10-08), above onboarding's 36–40.
        assert_eq!((PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1, PALW_KERNEL_ROUTE_TABLE_RESERVED_42_V1), (41, 42));
    }

    /// **lane SEED (G14 review MAJOR-1) (a), the pure half**: under Panel=1 the seat seed, challenge anchor and sample seed of a claim
    /// are functions of the claim AND a post-commit seed anchor. The same claim id under two anchors draws differently (so the claim id
    /// alone predicts nothing), the interim claim-id-only values are none of them, and an anchor not strictly later than the commit
    /// (or none) never draws.
    #[test]
    fn lane_seed_panel_one_seed_needs_a_post_commit_anchor() {
        use crate::palw_execution_lane_v1::PalwExecSeedAnchorV1;
        let claim = [0x5Au8; 64];
        let a = PalwExecSeedAnchorV1 { span: 101, block: Hash64::from_bytes([1; 64]), execution_key: Hash64::from_bytes([2; 64]) };
        let b = PalwExecSeedAnchorV1 { execution_key: Hash64::from_bytes([3; 64]), ..a };
        let c = PalwExecSeedAnchorV1 { span: 102, ..a };
        let d = PalwExecSeedAnchorV1 { block: Hash64::from_bytes([4; 64]), ..a };
        assert_eq!(palw_kernel_panel_one_seed_v1(&claim, &a), palw_kernel_panel_one_seed_v1(&claim, &a), "deterministic");
        for other in [&b, &c, &d] {
            assert_ne!(
                palw_kernel_panel_one_seed_v1(&claim, &a),
                palw_kernel_panel_one_seed_v1(&claim, other),
                "the anchor moves the seed"
            );
            assert_ne!(palw_kernel_panel_one_challenge_v1(&claim, &a), palw_kernel_panel_one_challenge_v1(&claim, other));
        }
        assert_ne!(palw_kernel_panel_one_seed_v1(&claim, &a), palw_kernel_interim_seed_v1(&claim), "not the grindable interim seed");
        let (anchor_a, sample_a) = palw_kernel_panel_one_challenge_v1(&claim, &a);
        let (anchor_i, sample_i) = palw_kernel_interim_challenge_v1(&claim);
        assert!(anchor_a != anchor_i && sample_a != sample_i && anchor_a != sample_a);
        // The claim still matters: another claim under the same anchor draws differently.
        assert_ne!(palw_kernel_panel_one_seed_v1(&claim, &a), palw_kernel_panel_one_seed_v1(&[0x5B; 64], &a));
        // The winning operator follows the anchor, not the claim id: over 64 anchors one claim id seats several operators.
        let ops: Vec<Hash64> = (0..8u8).map(|i| Hash64::from_bytes([0x10 + i; 64])).collect();
        let winners: std::collections::BTreeSet<Hash64> = (0..64u64)
            .map(|k| {
                let anchor = PalwExecSeedAnchorV1 { execution_key: Hash64::from_bytes([k as u8; 64]), ..a };
                let seed = palw_kernel_panel_one_seed_v1(&claim, &anchor);
                *ops.iter().min_by_key(|op| palw_kernel_interim_key_v1(&seed, op, 1)).unwrap()
            })
            .collect();
        assert!(winners.len() >= 4, "one claim id, many seat outcomes: {}", winners.len());
        // Anchor freshness: strictly later than the commit, in DAA, at the lane's span length.
        assert!(!palw_kernel_panel_one_anchor_after_commit_v1(100, 1, None), "no anchor, no draw");
        assert!(
            !palw_kernel_panel_one_anchor_after_commit_v1(100, 1, Some(&PalwExecSeedAnchorV1 { span: 100, ..a })),
            "the commit's own span"
        );
        assert!(
            !palw_kernel_panel_one_anchor_after_commit_v1(100, 1, Some(&PalwExecSeedAnchorV1 { span: 99, ..a })),
            "an older anchor"
        );
        assert!(palw_kernel_panel_one_anchor_after_commit_v1(100, 1, Some(&a)), "the next span's anchor");
        assert!(
            !palw_kernel_panel_one_anchor_after_commit_v1(100, 5, Some(&PalwExecSeedAnchorV1 { span: 20, ..a })),
            "span 20 starts at 100"
        );
        assert!(palw_kernel_panel_one_anchor_after_commit_v1(100, 5, Some(&PalwExecSeedAnchorV1 { span: 21, ..a })));
    }

    fn chunk_bond(i: u32) -> PalwBondKeyV2 {
        PalwBondKeyV2(crate::tx::TransactionOutpoint::new(crate::tx::TransactionId::from_u64_word(77), i))
    }

    /// **C4 F-C4R3-03 (the lane's pure half)**: the splitter, the completion (every part, the group id, coherence with the stored
    /// group), the per-opener room, the deposits that join the route's reservation, the target check and the target's deadline.
    #[test]
    fn the_routes_chunk_lane_assembles_only_coherent_groups_and_bounds_them_by_their_target() {
        use crate::palw_state_v2::PalwConsensusObjectV2 as Obj;
        use misaka_palw_kernel::route::{KernelRouteObjectV1 as K, ProsecutionV1};
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let mut state = PalwKernelRouteStateV1::new(p, None, LedgerScalarsV1::default());
        let (opener, other) = (chunk_bond(0), chunk_bond(1));
        let claim = [7u8; 64];
        let proof = K::FileProof { accuser: [1; 64], claim, proof: ProsecutionV1::Kernel(vec![9; 3000]) };
        let inner = Obj::KernelRouteV1 { bytes: proof.encode(), signer: opener, signature: vec![5; 64] };
        let target = PalwKernelChunkTargetV1::Claim(claim);
        let chunks = palw_kernel_chunks_v1(&inner, opener, target, 1024).unwrap();
        assert!(chunks.len() >= 3);
        assert!(palw_kernel_chunks_v1(&inner, opener, target, 64).is_err(), "past the chunk count");
        assert!(palw_kernel_chunk_inner_matches_target_v1(&inner, &target));
        assert!(!palw_kernel_chunk_inner_matches_target_v1(&inner, &PalwKernelChunkTargetV1::Claim([8; 64])), "another claim");
        let demand = Obj::KernelRouteV1 {
            bytes: K::FileDemand { demander: [1; 64], claim, stage: 0, position: 0 }.encode(),
            signer: opener,
            signature: vec![5; 64],
        };
        assert!(!palw_kernel_chunk_inner_matches_target_v1(&demand, &target), "a demand is not a prosecution object of this lane");
        // A lone last chunk completes nothing; with the others stored it completes exactly the object.
        let last = chunks.last().unwrap().clone();
        assert!(state.chunk_completion_v1(&last).is_none());
        let mut group =
            PalwKernelChunkGroupV1 { target, count: last.count, opened_daa: 1, expires_daa: 9, deposit: 3, parts: BTreeMap::new() };
        for c in &chunks[..chunks.len() - 1] {
            group.parts.insert(c.index, c.bytes.clone());
        }
        state.aux.insert(
            (PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1, palw_kernel_chunk_group_key_v1(&opener, &last.group)),
            borsh::to_vec(&group).unwrap(),
        );
        assert_eq!(state.chunk_completion_v1(&last), Some(inner.clone()));
        // The same bytes under another opener are another group (rooms are per bond); another target or count is incoherent.
        assert!(state.chunk_completion_v1(&PalwKernelChunkV1 { opener: other, ..last.clone() }).is_none());
        assert!(
            state
                .chunk_completion_v1(&PalwKernelChunkV1 { target: PalwKernelChunkTargetV1::Claim([8; 64]), ..last.clone() })
                .is_none()
        );
        let mut tampered = last.clone();
        tampered.bytes[0] ^= 1;
        assert!(state.chunk_completion_v1(&tampered).is_none(), "the assembled bytes must hash to the group id");
        // The open group is the opener's room and its deposit is part of what the route holds against the opener.
        assert_eq!((state.chunk_groups_of_v1(&opener), state.chunk_groups_of_v1(&other)), (1, 0));
        assert_eq!((state.reserved_of(&opener), state.ledger_reserved_of(&opener)), (3, 0));
        // An unknown claim and a refuted / unknown binding have no deadline; a claim's is its horizon bound.
        assert_eq!(state.chunk_target_deadline_v1(&target, 0), None);
        let binding =
            PalwKernelChunkTargetV1::Binding { v2_class: Hash64::from_u64_word(3), kernel_param_root: Hash64::from_u64_word(4) };
        assert_eq!(state.chunk_target_deadline_v1(&binding, 0), None);
        // OPV-BOOT #1: a conformance attempt's deadline is OPV-BOOT's (pending: no attempt is ever open here yet).
        let conformance = PalwKernelChunkTargetV1::Conformance { v2_class: Hash64::from_u64_word(3) };
        assert_eq!(state.chunk_target_deadline_v1(&conformance, 0), None);
        assert!(!palw_kernel_chunk_inner_matches_target_v1(&inner, &conformance), "a proof is not conformance evidence");
        {
            use crate::palw_conformance_evidence_v1::{ConformanceEvidenceActionV1 as A, ConformanceFaultV1 as F};
            let refute = |class: u64| Obj::ConformanceEvidenceV1 {
                v2_class: Hash64::from_u64_word(class),
                action: Box::new(A::Refute {
                    evidence_id: Hash64::from_u64_word(9),
                    fault: Box::new(F::VectorTokens { check: 0, kernel_claim: Hash64::from_u64_word(5) }),
                }),
                signer: other,
                signature: vec![5; 64],
            };
            assert!(palw_kernel_chunk_inner_matches_target_v1(&refute(3), &conformance), "the class's evidence");
            assert!(!palw_kernel_chunk_inner_matches_target_v1(&refute(4), &conformance), "another class's evidence");
            assert!(!palw_kernel_chunk_inner_matches_target_v1(&refute(3), &binding), "evidence is not a binding's refutation");
            assert!(!palw_kernel_chunk_inner_matches_target_v1(&refute(3), &target), "evidence is not a claim's prosecution");
        }
        use misaka_palw_kernel::lifecycle::ClaimStateV1 as S;
        let bound = |state: &S, liability: Option<u64>| palw_kernel_claim_horizon_bound_v1(&p, 10, liability, state);
        let tail = p.court_deadline_daa + p.proof_grace_daa + p.liability_daa;
        let pass = S::ProbabilisticPass { passed_daa: 20, window_end_daa: 70 };
        assert_eq!(bound(&pass, None), Some(70 + tail), "a passed claim: its latest Final plus the liability horizon");
        assert_eq!(bound(&S::Disputed { open: 1, resume: Box::new(pass) }, None), Some(70 + tail));
        assert_eq!(bound(&S::Checking { anchor_daa: 10, deadline_daa: 110 }, None), Some(110 + p.challenge_window_daa + tail));
        assert_eq!(
            bound(&S::Unavailable { daa: 40, producer_defaulted: true }, Some(240)),
            Some(240),
            "a defaulted claim (F-C4R3-02)"
        );
        assert_eq!(bound(&S::Final { final_daa: 60 }, Some(260)), Some(260));
        assert_eq!(bound(&S::TimedOut { daa: 111 }, None), None, "a claim that ended without passing takes nothing more");
        assert_eq!(bound(&S::Convicted { daa: 30 }, None), None);
    }

    /// **G14-B: the kernel's carriage terms are this lane's, and a maximal `Respond` (one full 1 MiB part) rides it in exactly the chunks
    /// the kernel's chunk-counting deadline counts** — reassembled from tag-113 chunks arriving one a block, inside the group's TTL and
    /// inside the demand's chunk-counted window, while the old fixed window (the base court deadline) could not hold it.
    #[test]
    fn g14b_a_maximal_respond_rides_the_chunk_lane_in_the_chunks_the_kernel_counts() {
        use crate::palw_state_v2::{PALW_OBJECT_CHUNK_MAX_BYTES, PALW_OBJECT_CHUNK_MAX_COUNT, PalwConsensusObjectV2 as Obj};
        use misaka_palw_kernel::budget as b;
        use misaka_palw_kernel::route::KernelRouteObjectV1 as K;
        // The mirrors (the kernel cannot import this crate).
        assert_eq!(b::ROUTE_CHUNK_BYTES_V1, PALW_OBJECT_CHUNK_MAX_BYTES as u64);
        assert_eq!(b::ROUTE_CHUNKS_PER_OBJECT_V1, PALW_OBJECT_CHUNK_MAX_COUNT as u64);
        assert_eq!(
            b::ROUTE_OBJECT_WRAPPER_BYTES_V1,
            (PALW_OBJECT_CHUNK_MAX_BYTES * PALW_OBJECT_CHUNK_MAX_COUNT as usize - PALW_KERNEL_ROUTE_MAX_OBJECT_BYTES_V1) as u64
        );
        assert_eq!(b::ROUTE_CHUNK_TTL_MAX_DAA_V1, PALW_KERNEL_CHUNK_TTL_MAX_DAA_V1);
        assert_eq!(b::LIFETIME_CEILING_DAA_V1, crate::palw_bond_budget_v1::PALW_BOND_BUDGET_W_MAX_DAA_V1);
        // One full chunk a block: two would exceed what testnet-12's block mass admits in transaction bytes.
        let block_bytes =
            crate::config::params::palw_t12_shipped_params().max_block_mass / crate::constants::TRANSIENT_BYTE_TO_MASS_FACTOR;
        assert!(block_bytes >= PALW_OBJECT_CHUNK_MAX_BYTES as u64 && block_bytes < 2 * PALW_OBJECT_CHUNK_MAX_BYTES as u64);
        assert_eq!(b::ROUTE_DAA_PER_CHUNK_V1, 1);

        // A maximal part, in its Respond, in its signed carrier object (an ML-DSA-87 signature's length).
        let p = palw_kernel_route_policy_v1(Hash64::from_u64_word(1), Hash64::from_u64_word(2));
        let mut state = PalwKernelRouteStateV1::new(p, None, LedgerScalarsV1::default());
        let producer = chunk_bond(0);
        let claim = [7u8; 64];
        let part = misaka_palw_kernel::seg_da::SEG_PART_BYTES_V4 as usize;
        let respond = K::Respond { claim, stage: 0, position: 8191, bytes: vec![0xA5; part] };
        let inner = Obj::KernelRouteV1 { bytes: respond.encode(), signer: producer, signature: vec![5; 4627] };
        let target = PalwKernelChunkTargetV1::Claim(claim);
        let chunks = palw_kernel_chunks_v1(&inner, producer, target, PALW_OBJECT_CHUNK_MAX_BYTES).unwrap();
        let counted = b::route_object_chunks_v1(part as u128 + b::RESPOND_ENVELOPE_BYTES_V1 as u128);
        assert_eq!(chunks.len() as u64, counted, "the lane's real chunking is the kernel's count");
        assert_eq!(counted, 11);
        assert!(palw_kernel_chunk_inner_matches_target_v1(&inner, &target));
        // The demand opens at t0; its chunk-counted window is the base deadline plus one DAA a further chunk.
        let t0 = 1_000u64;
        let window = b::response_window_daa_v1(p.court_deadline_daa, counted);
        assert_eq!(window, p.court_deadline_daa + 10);
        // The producer reacts as late as a one-carrier answer may (the base deadline), then one chunk a block.
        let opened = t0 + p.court_deadline_daa;
        let expires = opened + PALW_KERNEL_CHUNK_TTL_MAX_DAA_V1;
        let mut group = PalwKernelChunkGroupV1 {
            target,
            count: chunks[0].count,
            opened_daa: opened,
            expires_daa: expires,
            deposit: 11,
            parts: BTreeMap::new(),
        };
        let mut completed_at = None;
        for (i, c) in chunks.iter().enumerate() {
            let daa = opened + i as u64;
            assert!(daa <= expires, "every chunk inside the group's TTL");
            if let Some(object) = state.chunk_completion_v1(c) {
                assert_eq!(object, inner, "the assembled object is the Respond, byte for byte");
                completed_at = Some(daa);
                break;
            }
            group.parts.insert(c.index, c.bytes.clone());
            state.aux.insert(
                (PALW_KERNEL_ROUTE_TABLE_CHUNK_GROUPS_V1, palw_kernel_chunk_group_key_v1(&producer, &c.group)),
                borsh::to_vec(&group).unwrap(),
            );
        }
        let completed_at = completed_at.expect("the last chunk completes the group");
        assert_eq!(completed_at, t0 + window, "it lands on the chunk-counted deadline's last DAA");
        assert!(completed_at > t0 + p.court_deadline_daa, "the fixed window would have defaulted an honest producer by size alone");
    }
}

#[cfg(test)]
#[path = "palw_kernel_projection_capacity_tests.rs"]
mod projection_capacity_tests;

#[cfg(test)]
#[path = "palw_kernel_route_selected_approval_tests.rs"]
mod selected_approval_tests;
