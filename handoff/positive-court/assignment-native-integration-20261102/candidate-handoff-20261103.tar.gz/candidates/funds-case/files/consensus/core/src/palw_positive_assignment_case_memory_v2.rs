//! Native allocation-request owner for retained assigned A1/Court/source replay.
//! This is memory ownership only. It does not certify native history, source
//! delivery, computation, P, work-service opportunity, funding or credit.
//! Quotes use actual independently derived program/layout/job inventory and
//! concrete private source/A1 type sizes; encoded frame length is never a
//! multiplier for an unknown program or native state.
use crate::{
    palw_native_resource_v1::{NativeCoverageV1, NativeDemandLeaseV1, TirNativeRequestsV1, reserve_native_requests_v1},
    palw_positive_assignment_material_v2::AssignmentAdmissionMaterialV2,
    palw_positive_assignment_resources_v2::{AssignmentDerivedAllocationQuoteV2, AssignmentDerivedResourcesV2},
    palw_positive_common_replay_v2::{LocalCheckedCourtFactV2, LocalReplayEventV2},
    palw_positive_common_source_replay_v2::CommonSourceReplayStateV2,
    palw_positive_contract_v2::{CheckContext, ContractProgress, PreparedCheck},
};
use misaka_palw_positive_contract::{
    ContractError,
    identity::{Digest, EvidencePartId},
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AssignmentCaseMemoryQuoteV2 {
    /// Six coexisting CoveragePlan program/validator/step-space owners: retained
    /// preparation, old context/checker, replacement preparation/context/checker.
    /// Includes the authenticate constructor's provisional/final overlap.
    pub a1_plan_owners: u64,
    /// Eight class/layout owners, including old/new context binding, both
    /// progress identity/checker bindings and coexisting record preparation.
    pub a1_class_owners: u64,
    /// Fourteen bounded native network Vecs: six plans, six bindings and two
    /// preparations. Fixed job roots themselves are in concrete inline types.
    pub a1_job_network_owners: u64,
    pub a1_generated_owners: u64,
    pub a1_inline_owners: u64,
    /// Independent source geometry program/validation/inventory construction.
    pub source_geometry: u64,
    /// Actual private source maps/history/fee intents plus one prepare/update.
    pub source_shadow: u64,
    /// Old and replacement Court relation receipts, not canonical retention.
    pub court_receipt_workspace: u64,
    pub checked_fact_owners: u64,
    pub journal_index_and_events: u64,
    pub canonical_record_buffers: u64,
    pub part_decode_and_evaluation: u64,
    pub total_requests: u64,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum AssignmentCaseMemoryErrorV2 {
    Contract(ContractError),
    Binding,
    Overflow,
    Native(NativeCoverageV1),
    MissingNativeLease,
    Capacity { required: u64, maximum: u64 },
}
fn add(a: u64, b: u64) -> Result<u64, AssignmentCaseMemoryErrorV2> {
    a.checked_add(b).ok_or(AssignmentCaseMemoryErrorV2::Overflow)
}
fn mul(a: u64, b: u64) -> Result<u64, AssignmentCaseMemoryErrorV2> {
    a.checked_mul(b).ok_or(AssignmentCaseMemoryErrorV2::Overflow)
}
fn typed<T>(count: u64) -> Result<u64, AssignmentCaseMemoryErrorV2> {
    mul(std::mem::size_of::<T>() as u64, count)
}
impl AssignmentCaseMemoryQuoteV2 {
    /// A public quote is DATA. Caller must independently derive resources and
    /// original material; only reserve() below owns real native memory, and
    /// even that owner creates no native Case success capability.
    pub fn derive(
        resources: &AssignmentDerivedResourcesV2,
        allocation: AssignmentDerivedAllocationQuoteV2,
        original: &AssignmentAdmissionMaterialV2,
        history_events: u64,
    ) -> Result<Self, AssignmentCaseMemoryErrorV2> {
        let positive = &original.positive_policy;
        let assignment = &original.assignment_policy;
        let source = &original.native_preimages.source_policy;
        if resources.binding().terms().id() != original.assignment
            || resources.binding().job().context_hash() != original.job.context_hash
            || resources.source_quote().digest != original.source.digest
            || resources.plan().leaf_count() == 0
            || resources.plan().leaf_count() > positive.max_relations
            || history_events == 0 || history_events > u64::from(assignment.max_history_frames)
            || allocation.total_requests == 0 || allocation.total_requests > assignment.max_heap_bytes
        { return Err(AssignmentCaseMemoryErrorV2::Binding); }
        positive.validate_shape().map_err(|_| AssignmentCaseMemoryErrorV2::Binding)?;
        source.validate().map_err(|_| AssignmentCaseMemoryErrorV2::Binding)?;
        // Exhaustive private field inventories live beside their definitions;
        // adding a new owning field fails their compile until quoted explicitly.
        crate::palw_positive_contract_v2::native_assigned_cache_inventory_v2();
        crate::palw_positive_check_v2::native_assigned_cache_inventory_v2();
        let one_plan = add(allocation.final_plan_program_and_validator, allocation.final_plan_step_space)?;
        let a1_plan_owners = mul(one_plan, 6)?;
        // The structural allocation quote contains one actual owned class raw
        // program, all layout vectors and hashing writer workspace. Repeating
        // its whole class/layout component conservatively bounds each of the
        // eight actual raw-class clones without an encoded-size heuristic.
        let a1_class_owners = mul(allocation.raw_class_and_layout_owners, 8)?;
        let a1_job_network_owners = typed::<u8>(mul(crate::palw_v2::PALW_V2_MAX_NETWORK_ID_BYTES as u64, 14)?)?;
        let a1_generated_owners = typed::<u32>(mul(u64::from(original.job.exact_decode_tokens), 6)?)?;
        let a1_inline_owners = add(add(typed::<PreparedCheck>(2)?, typed::<CheckContext>(2)?)?, typed::<ContractProgress>(2)?)?;
        let source_geometry = add(allocation.source_program_and_validator, allocation.retained_inventory_and_instance_analysis)?;
        let source_shadow = CommonSourceReplayStateV2::replay_heap_requests_v2(source.limits()).map_err(AssignmentCaseMemoryErrorV2::Native)?;
        let court_receipt_workspace = typed::<EvidencePartId>(mul(positive.max_relations, 2)?)?;
        let checked_fact_owners = typed::<LocalCheckedCourtFactV2>(u64::from(positive.max_attempts))?;
        let journal_index_and_events = add(typed::<Digest>(history_events)?, typed::<LocalReplayEventV2>(history_events)?)?;
        // Archive bytes/prefix states already have independent retained native
        // owners. This is simultaneous current raw record + owned decoded body,
        // a freshly encoded journal record and a canonical compare/aux buffer.
        let canonical_record_buffers = mul(assignment.max_frame_bytes.min(positive.max_case_journal_bytes), 4)?;
        // A1's native cone decoder/evaluator is bounded by its actual part-heap
        // policy; old/new programs remain retained in the plan components above.
        let part_decode_and_evaluation = positive.max_part_heap;
        let mut quote = Self { a1_plan_owners, a1_class_owners, a1_job_network_owners, a1_generated_owners,
            a1_inline_owners, source_geometry, source_shadow, court_receipt_workspace, checked_fact_owners,
            journal_index_and_events, canonical_record_buffers, part_decode_and_evaluation, total_requests: 0 };
        quote.total_requests = [quote.a1_plan_owners, quote.a1_class_owners, quote.a1_job_network_owners,
            quote.a1_generated_owners, quote.a1_inline_owners, quote.source_geometry, quote.source_shadow,
            quote.court_receipt_workspace, quote.checked_fact_owners, quote.journal_index_and_events,
            quote.canonical_record_buffers, quote.part_decode_and_evaluation].into_iter().try_fold(0u64, add)?;
        let maximum = positive.max_case_heap_bytes.min(assignment.max_heap_bytes).min(original.native_preimages.physical.max_heap_bytes);
        if quote.total_requests > maximum { return Err(AssignmentCaseMemoryErrorV2::Capacity { required: quote.total_requests, maximum }); }
        Ok(quote)
    }
}

/// Real pinned native memory owner, never a lease-free success wrapper. It is
/// neither Clone nor Deserialize; cannot be separated from retained outputs.
/// The private Case cache owns this until every checker/source output drops.
pub(crate) struct NativeAssignedCaseMemoryV2 {
    quote: AssignmentCaseMemoryQuoteV2,
    _lease: NativeDemandLeaseV1,
}
impl NativeAssignedCaseMemoryV2 {
    pub(crate) fn reserve(
        resources: &AssignmentDerivedResourcesV2,
        allocation: AssignmentDerivedAllocationQuoteV2,
        original: &AssignmentAdmissionMaterialV2,
        history_events: u64,
    ) -> Result<Self, AssignmentCaseMemoryErrorV2> {
        let quote = AssignmentCaseMemoryQuoteV2::derive(resources, allocation, original, history_events)?;
        let mut q = TirNativeRequestsV1::new();
        q.add_v1(quote.total_requests).map_err(AssignmentCaseMemoryErrorV2::Native)?;
        let lease = reserve_native_requests_v1(q.bytes_v1()).map_err(AssignmentCaseMemoryErrorV2::Native)?
            .ok_or(AssignmentCaseMemoryErrorV2::MissingNativeLease)?;
        Ok(Self { quote, _lease: lease })
    }
    pub(crate) fn quote(&self) -> AssignmentCaseMemoryQuoteV2 { self.quote }
}
