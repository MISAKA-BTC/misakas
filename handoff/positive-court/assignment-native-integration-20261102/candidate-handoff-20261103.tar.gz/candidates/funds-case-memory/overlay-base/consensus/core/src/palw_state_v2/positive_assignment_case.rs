//! Concrete assigned Case native owner. Local A1 facts remain local until the
//! complete native archive/current prefix, original immutable admission inputs,
//! exact Case projections and the closed initial fraud topology are rebound.
//! No serialized progress, saved Pass bit, public environment or trait object
//! can construct the two capabilities in this child.
use super::*;
use crate::{
    palw_native_resource_v1::{NativeCoverageV1, NativeDemandLeaseV1, TirNativeRequestsV1, reserve_native_requests_v1},
    palw_positive_assignment_material_v2::AssignmentAdmissionMaterialV2,
    palw_positive_common_replay_v2::LocalCheckedCourtFactV2,
    palw_positive_common_source_replay_v2::CommonSourceReplayStateV2,
    palw_positive_contract_v2::PreparedCheck,
    palw_positive_court_v2::coordinator::{
        carrier::{PanelFrameAuthorityV2, PanelSignatureVerifierV2},
        contract::{ContractCourtV2, TerminalKindV2},
        tir_checker::TirCourtCheckerV2,
    },
    palw_positive_journal_chain_v2::{CaseJournalPinV2, CaseJournalSourceV2},
    palw_positive_rows_v2::{PositiveRowBundleV2, PositiveRowsV2},
    palw_security_certification_v1::PalwSecurityCertificationPolicyV1,
};
use misaka_palw_positive_contract::{
    assignment::{
        AssignmentId,
        rows::{AssignmentRow, AssignmentStatusV2},
    },
    identity::{CaseId, Digest, PUBKEY_BYTES, PrincipalId, WitnessId},
    journal::{CaseJournalEventKind, CaseJournalLimits, CaseJournalRecordView},
    messages::{ClaimStatus, MinerResultCommit, PanelWitnessCommit, WitnessStatus},
    native::NativeRowKey,
    rows::{AcceptedMaterial, AcceptedOrigin, CaseRow, JournalHeadRow, NativeRowBody},
};
use std::{cell::RefCell, rc::Rc};

fn refuse(why: impl std::fmt::Debug) -> PalwStateV2Error {
    PalwStateV2Error::KernelRouteRefused(format!("assigned Case: {why:?}"))
}
fn missing() -> PalwStateV2Error {
    PalwStateV2Error::NativeContextUnavailable(crate::palw_source_bootstrap_v1::PalwSourceBootstrapContextFaultV1::HistoryUnavailable)
}
fn required(state: &PalwChainStateV2, key: NativeRowKey) -> Result<NativeRowBody, PalwStateV2Error> {
    PositiveRowsV2::new(state).read(key).map_err(refuse)?.map(|row| row.body).ok_or_else(missing)
}
fn assignment(state: &PalwChainStateV2, id: AssignmentId) -> Result<AssignmentRow, PalwStateV2Error> {
    match required(state, NativeRowKey::Assignment(id))? {
        NativeRowBody::Assignment(row) => Ok(row),
        _ => Err(refuse("Assignment key/value")),
    }
}
fn rooted_bundle(
    state: &PalwChainStateV2,
    id: AssignmentId,
) -> Result<(AssignmentRow, PositiveRowBundleV2, CaseJournalPinV2), PalwStateV2Error> {
    let a = assignment(state, id)?;
    let AssignmentStatusV2::Consumed { case, result } = a.status else {
        return Err(refuse("Case requires consumed Assignment"));
    };
    let NativeRowBody::Result(result_row) = required(state, NativeRowKey::Result(result))? else {
        return Err(refuse("Result row"));
    };
    let bundle = PositiveRowsV2::new(state).bundle(result_row.result.claim_id()).map_err(refuse)?;
    let NativeRowBody::AssignmentUse(use_row) = required(state, NativeRowKey::AssignmentUse(id))? else {
        return Err(refuse("Use row"));
    };
    let NativeRowBody::JournalHead(head) = required(state, NativeRowKey::JournalHead(case))? else {
        return Err(refuse("Case journal"));
    };
    if bundle.case.case != case
        || bundle.result.result.id() != result
        || use_row.assignment != id
        || use_row.case != case
        || use_row.result != result
        || use_row.origin != bundle.result.origin
        || bundle.result.role_assignment != (AcceptedMaterial { origin: a.origin, digest: id.0 })
        || bundle.result.dependencies != a.dependencies
        || head.case != case
        || head.sequence == 0
        || head.history.origin != bundle.case.last_event
    {
        return Err(refuse("actual Assignment/Use/Result/Case/head links"));
    }
    let pin = CaseJournalPinV2 { scope: bundle.result.result.scope, case, result, head };
    Ok((a, bundle, pin))
}

/// No constructor outside this child. The current counter is cross-checked
/// after full replay, exact empty dependency preimage and all alias routes.
/// This is the INITIAL closed-ingress topology, never generic fraud clearance.
pub(super) struct ClosedAssignedFraudV2 {
    latest_decision_daa: u64,
    pending: bool,
}
impl ClosedAssignedFraudV2 {
    pub(super) fn has_pending(&self) -> bool {
        self.pending
    }
    pub(super) fn latest_decision_daa(&self) -> u64 {
        self.latest_decision_daa
    }
}

/// Actual retained nonserialized machine. Native writer owns this map and drops
/// it on checkpoint rollback/DB failure/reorg. `root` is refreshed only AFTER
/// successful native row/journal writes; mismatches require one cold full replay.
/// `ContractCourtV2` and `PreparedCheck` have no Deserialize path.
pub(super) struct NativeAssignedCaseCacheV2 {
    root: Hash64,
    context: PalwBlockContextV2,
    assignment: AssignmentRow,
    material: AssignmentAdmissionMaterialV2,
    pin: CaseJournalPinV2,
    prepared: PreparedCheck,
    record_limits: crate::palw_positive_contract_v2::record::RecordLimits,
    authority: NativeAssignedPanelAuthorityV2,
    court: ContractCourtV2<TirCourtCheckerV2, PanelSignatureVerifierV2<NativeAssignedPanelAuthorityV2>>,
    source: CommonSourceReplayStateV2,
    facts: Vec<LocalCheckedCourtFactV2>,
    terminal_material: Option<AcceptedMaterial>,
    positive_final: Option<AcceptedOrigin>,
    _lease: NativeDemandLeaseV1,
}

/// Private current-step role cursor. It contains an actually resolved current
/// role, never a caller pass flag or a reused admission-time author.
struct NativeAssignedPanelStepV2 {
    result: misaka_palw_positive_contract::identity::ResultId,
    author: PrincipalId,
    key: [u8; PUBKEY_BYTES],
    max_signed_bytes: u64,
    before_daa: u64,
    origin: AcceptedOrigin,
}
#[derive(Clone)]
struct NativeAssignedPanelAuthorityV2 {
    step: Rc<RefCell<Option<NativeAssignedPanelStepV2>>>,
}
impl PanelFrameAuthorityV2 for NativeAssignedPanelAuthorityV2 {
    type Error = PalwStateV2Error;
    fn authorize(&self, result: &MinerResultCommit, witness: &PanelWitnessCommit) -> Result<u64, Self::Error> {
        let step = self.step.borrow();
        let step = step.as_ref().ok_or_else(missing)?;
        if step.result != result.id()
            || step.author != witness.author
            || step.origin.accepted_daa >= step.before_daa
            || misaka_palw_positive_contract::identity::principal(&step.key) != witness.author
        {
            return Err(refuse("actual historical/current prover role"));
        }
        Ok(step.max_signed_bytes)
    }
}

/// Borrowed native capability, only extracted from this child's actual machine
/// after full source/Court replay and closed-topology checks. A later native
/// mutation invalidates the complete root pin, including same-block ordering.
pub(super) struct NativeAssignedCaseSessionV2<'a> {
    root: Hash64,
    context: PalwBlockContextV2,
    assignment: AssignmentId,
    result: &'a MinerResultCommit,
    case: CaseRow,
    head: JournalHeadRow,
    policy: &'a PalwSecurityCertificationPolicyV1,
    terminal: Option<&'a LocalCheckedCourtFactV2>,
    material: AcceptedMaterial,
    positive_final: Option<AcceptedOrigin>,
    closed: ClosedAssignedFraudV2,
}
impl NativeAssignedCaseSessionV2<'_> {
    pub(super) fn ensure_current(&self, state: &PalwChainStateV2, ctx: &PalwBlockContextV2) -> Result<(), PalwStateV2Error> {
        if state.state_root() != self.root || *ctx != self.context {
            return Err(refuse("stale native Case session"));
        }
        let (a, bundle, pin) = rooted_bundle(state, self.assignment)?;
        if bundle.result.result != *self.result
            || bundle.case != self.case
            || pin.head != self.head
            || a.id() != self.assignment
            || a.bundle.terms.branch_anchor.0 != self.result.scope.branch.0
        {
            return Err(refuse("native Case session lineage or before-row changed"));
        }
        reject_legacy_aliases(state, &a, self.result)?;
        Ok(())
    }
    pub(super) fn result(&self) -> &MinerResultCommit {
        self.result
    }
    pub(super) fn assignment(&self) -> AssignmentId {
        self.assignment
    }
    pub(super) fn checked_terminal(&self) -> Option<&LocalCheckedCourtFactV2> {
        self.terminal
    }
    pub(super) fn positive_final_origin(&self) -> Option<AcceptedOrigin> {
        self.positive_final
    }
    pub(super) fn court_material(&self) -> AcceptedMaterial {
        self.material
    }
    pub(super) fn certification_policy(&self) -> &PalwSecurityCertificationPolicyV1 {
        self.policy
    }
    pub(super) fn pending_fraud_bound(&self) -> &ClosedAssignedFraudV2 {
        &self.closed
    }
}

/// Exact native aliases must be absent in EVERY old entry surface. A zero
/// unresolved counter alone is deliberately not accepted as evidence of this.
fn reject_legacy_aliases(state: &PalwChainStateV2, a: &AssignmentRow, result: &MinerResultCommit) -> Result<(), PalwStateV2Error> {
    let claim = Hash64::from_bytes(result.claim_id().0.0);
    let job = Hash64::from_bytes(result.job.0);
    if state.claims.contains_key(&claim)
        || state.claims.values().any(|row| row.job_identity == job)
        || state.panels.contains_key(&claim)
        || state.court_sessions.contains_key(&claim)
        || state.legacy_disputes.contains_key(&claim)
        || state.panel_liabilities.contains_key(&claim)
        || state.staged_tir_by_claim.contains_key(&claim)
        || state.staged_court_service_by_claim.contains_key(&claim)
        || state.open_courts_by_claim.get(&claim).is_some_and(|n| *n != 0)
        || state.funded_escrows.values().any(|row| row.claim == claim)
    {
        return Err(refuse("legacy claim/TFO/service/funds alias is not closed initial topology"));
    }
    use crate::palw_staged_court_state_v1::PalwStagedCourtKeyV1 as K;
    if state.staged_courts.keys().any(|key| match key {
        K::Claim(id)
        | K::Inventory(id)
        | K::TirRawChunk(id)
        | K::TirAcceptedBody(id)
        | K::TirClaim(id)
        | K::CourtDutyClock(id)
        | K::CourtSharedContext(id)
        | K::CourtSharedQuery(id)
        | K::CourtSharedIds(id)
        | K::CourtSharedStream(id)
        | K::CourtSharedRound(id)
        | K::CourtSharedBottom(id)
        | K::CourtEndArchive(id) => *id == claim || *id == job,
        K::Owner(id, _)
        | K::InventoryOpen(id, _)
        | K::TirAcquisition(id, _, _)
        | K::TirPreparation(id, _)
        | K::TirWitness(id, _)
        | K::CourtSharedChunk(id, _)
        | K::CourtSharedResponse(id, _)
        | K::CourtCloseReceipt(id, _)
        | K::CourtSharedRoot(id, _)
        | K::CourtArchiveProgress(id, _)
        | K::CourtMaterialDraft(id, _)
        | K::CourtMaterial(id, _)
        | K::CourtMaterialLedger(id, _) => *id == claim || *id == job,
        // Global material parts/service and class registrations cannot be
        // interpreted as a claim alias; their referencing claim route is above.
        K::TirLayout(_) | K::TirContainer(_) | K::CourtService | K::CourtMaterialPart(_, _) => false,
    }) {
        return Err(refuse("actual staged native alias"));
    }
    let route = state.kernel_route_state_v1().ok_or_else(missing)?;
    // Real typed projection owns its native allocation/decoder; unsupported or
    // missing projection is an error, never an empty kernel ledger.
    let ledger = route.ledger_native_projection_v9().map_err(refuse)?;
    let claim = result.claim_id().0.0;
    let job = result.job.0;
    if ledger.claims.contains_key(&claim)
        || ledger.claims.values().any(|row| row.job_id == job)
        || ledger.jobs.contains_key(&job)
        || ledger.pipeline_jobs.contains_key(&job)
        || ledger.job_claims.contains_key(&job)
        || ledger.job_claims.values().any(|id| *id == claim)
        || ledger.job_escrows.contains_key(&job)
        || ledger.seals.keys().any(|(id, _)| *id == job)
        || ledger.proof_seals.keys().any(|(id, _)| *id == claim)
        || ledger.opv.claims.contains_key(&claim)
    {
        return Err(refuse("kernel job/claim/OPV alias"));
    }
    if a.bundle.terms.empty_dependencies_id() != a.dependencies.digest {
        return Err(refuse("initial assigned topology requires exact empty dependencies"));
    }
    Ok(())
}

impl NativeAssignedCaseCacheV2 {
    pub(super) fn session<'a>(
        &'a self,
        state: &PalwChainStateV2,
        ctx: &PalwBlockContextV2,
    ) -> Result<NativeAssignedCaseSessionV2<'a>, PalwStateV2Error> {
        if self.root != state.state_root() || self.context != *ctx {
            return Err(refuse("cache root/context stale; cold replay required"));
        }
        let (a, bundle, pin) = rooted_bundle(state, self.assignment.id())?;
        self.material.check_row(&a).map_err(refuse)?;
        if a != self.assignment
            || pin != self.pin
            || self.source.case_row().map_err(refuse)? != bundle.case
            || self.court.result() != &bundle.result.result
            || bundle.case.unresolved_fraud != 0
        {
            return Err(refuse("actual replay before rows disagree"));
        }
        reject_legacy_aliases(state, &a, self.court.result())?;
        let terminal = self.facts.last();
        let material = self.terminal_material.ok_or_else(missing)?;
        let fact = terminal.ok_or_else(missing)?;
        if fact.case() != pin.case
            || fact.result() != pin.result
            || fact.scope() != pin.scope
            || fact.terminal().descriptor() != bundle.case.coverage
            || bundle.case.positive_witness != (fact.terminal_kind() == TerminalKindV2::PositivePassed).then_some(fact.witness())
        {
            return Err(refuse("actual checked terminal/coverage links"));
        }
        let origin = self.positive_final.ok_or_else(missing)?;
        if origin != material.origin || origin.accepted_daa > ctx.daa_score {
            return Err(refuse("Finish material/origin"));
        }
        let latest = origin
            .accepted_daa
            .checked_add(self.material.certification_policy.prosecution_window_daa)
            .ok_or_else(|| refuse("finite actual Final prosecution"))?;
        if latest > a.bundle.terms.reserve_until_daa {
            return Err(refuse("actual Final exceeds original liability owner"));
        }
        let session = NativeAssignedCaseSessionV2 {
            root: self.root,
            context: *ctx,
            assignment: a.id(),
            result: self.court.result(),
            case: bundle.case,
            head: pin.head,
            policy: &self.material.certification_policy,
            terminal,
            material,
            positive_final: Some(origin),
            closed: ClosedAssignedFraudV2 { latest_decision_daa: latest, pending: false },
        };
        session.ensure_current(state, ctx)?;
        Ok(session)
    }
}

fn snapshot(
    court: &ContractCourtV2<TirCourtCheckerV2, PanelSignatureVerifierV2<NativeAssignedPanelAuthorityV2>>,
) -> crate::palw_positive_common_replay_v2::LocalCourtSnapshotV2 {
    crate::palw_positive_common_replay_v2::LocalCourtSnapshotV2 {
        status: court.status(),
        attempts: court.attempts(),
        cursor: court.cursor(),
        last_attempt: court.last_attempt(),
        charged_wire_bytes: court.charged_wire_bytes(),
        charged_elements: court.charged_elements(),
        charged_terms: court.charged_terms(),
        reserved_receipt_bytes: court.reserved_receipt_bytes(),
    }
}
struct NativeAssignedCourtAdvanceV2 {
    before: crate::palw_positive_common_replay_v2::LocalCourtSnapshotV2,
    after: crate::palw_positive_common_replay_v2::LocalCourtSnapshotV2,
    outcome: crate::palw_positive_common_replay_v2::LocalCourtOutcomeV2,
}

/// Resolve the literal original or accepted funded op13 role in the ACTUAL
/// prefix. Historical replay calls with carriage.prefix_state(), never a later
/// state, and a retired actor cannot buy a replacement global Court budget.
fn prover_step(
    state: &PalwChainStateV2,
    a: &AssignmentRow,
    material: &AssignmentAdmissionMaterialV2,
    author: PrincipalId,
    origin: AcceptedOrigin,
    new_candidate: bool,
) -> Result<NativeAssignedPanelStepV2, PalwStateV2Error> {
    use misaka_palw_positive_contract::assignment::{AssignmentRoleV2, rows::AssignmentRoleAuthorizationV2};
    use misaka_palw_positive_contract::rows::NativeRowValue;
    let route = state.kernel_route_state_v1().ok_or_else(missing)?;
    let mut resolved = None;
    let mut count = 0u32;
    for ((table, key), bytes) in &route.aux {
        if *table != misaka_palw_positive_contract::native::KERNEL_AUX_TABLE || key.get(4) != Some(&15) {
            continue;
        }
        let value = NativeRowValue::decode(key, bytes).map_err(refuse)?;
        let NativeRowBody::AssignmentRole(role) = value.body else {
            return Err(refuse("role key/value"));
        };
        if role.assignment != a.id() || role.role != AssignmentRoleV2::Prover {
            continue;
        }
        count = count.checked_add(1).ok_or_else(|| refuse("role count overflow"))?;
        if count > material.assignment_policy.max_role_candidates {
            return Err(refuse("bounded native role candidates"));
        }
        if misaka_palw_positive_contract::identity::principal(&role.key) != author {
            continue;
        }
        role.authenticate(a).map_err(refuse)?;
        if (new_candidate && role.retired) || role.origin.accepted_daa > origin.accepted_daa {
            return Err(refuse("role absent/retired at actual event prefix"));
        }
        let registered = state
            .bond(&PalwBondKeyV2(TransactionOutpoint::new(Hash64::from_bytes(role.bond.transaction.0), role.bond.index)))
            .ok_or_else(missing)?;
        if registered.pubkey.as_slice() != role.key.as_slice() {
            return Err(refuse("actual registered work key differs"));
        }
        let (before_daa, max_submitted_bytes) = match &role.authorization {
            AssignmentRoleAuthorizationV2::Initial => (a.prover_consent.build_before_daa, a.prover_consent.max_submitted_bytes),
            AssignmentRoleAuthorizationV2::Joined(join) => {
                let NativeRowBody::AssignmentProverFunding(funding) =
                    required(state, NativeRowKey::AssignmentProverFunding { assignment: a.id(), prover: role.bond })?
                else {
                    return Err(refuse("joined prover has no actual separate purpose account"));
                };
                funding.validate_shape().map_err(refuse)?;
                if funding.consent != *join
                    || funding.payer_key != role.key
                    || funding.payer_signature != role.signature
                    || funding.funding_origin != role.origin
                    || role.funding.is_none()
                {
                    return Err(refuse("joined role actual funding link"));
                }
                (join.service_before_daa, join.max_submitted_bytes)
            }
        };
        let max_signed_bytes = material
            .positive_policy
            .max_frame_bytes
            .checked_add(misaka_palw_positive_contract::identity::SIGNATURE_BYTES as u64)
            .filter(|n| *n <= max_submitted_bytes)
            .ok_or_else(|| refuse("original signed prover packet cap"))?;
        if origin.accepted_daa >= before_daa || resolved.is_some() {
            return Err(refuse("prover opportunity/ambiguous registered author"));
        }
        resolved = Some(NativeAssignedPanelStepV2 {
            result: match a.status {
                AssignmentStatusV2::Consumed { result, .. } => result,
                _ => return Err(refuse("unconsumed role")),
            },
            author,
            key: role.key,
            max_signed_bytes,
            before_daa,
            origin,
        });
    }
    resolved.ok_or_else(missing)
}

impl NativeAssignedCaseCacheV2 {
    /// Advances the SAME real global Court, with A1 authentication/evaluation.
    /// Caller must own event work/heap, exact current root/head and native raw
    /// acceptance. Any failure after mutation drops this cache and restores the
    /// enclosing native checkpoint; there is no reusable prepared-row DTO.
    fn advance_court(
        &mut self,
        state: &PalwChainStateV2,
        ctx: &PalwBlockContextV2,
        action: &PositiveAssignmentRawActionV2,
        body: &crate::palw_positive_court_v2::coordinator::native_body::PositiveNativeBodyV2,
    ) -> Result<NativeAssignedCourtAdvanceV2, PalwStateV2Error> {
        use crate::palw_positive_common_replay_v2::{LocalCourtErrorV2, LocalCourtOutcomeV2 as Outcome};
        use crate::palw_positive_court_v2::coordinator::{
            carrier::PanelPacketSignatureV2,
            contract::{CandidateOpenV2, CourtErrorV2},
            native_body::PositiveNativeOperationV2 as Op,
            record_ingress::preflight_witness_record_v2,
        };
        use misaka_palw_positive_contract::wire::EvidenceFrame;
        if state.state_root() != self.root
            || self.context != *ctx
            || action.origin().accepting_block.0 != ctx.block.as_bytes()
            || action.origin().accepted_daa != ctx.daa_score
            || action.origin().accepted_blue_score != ctx.blue_score
            || !canonical_equal(body, action.transaction().payload.get(3..).ok_or_else(missing)?)
        {
            return Err(refuse("actual native Case current prefix/raw operation"));
        }
        let before = snapshot(&self.court);
        let origin = action.origin();
        let semantic = |error| -> Result<Outcome, PalwStateV2Error> {
            let error = match error {
                CourtErrorV2::Check(error) => LocalCourtErrorV2::Check(error),
                CourtErrorV2::Contract(error) => LocalCourtErrorV2::Contract(error),
                CourtErrorV2::Closed => LocalCourtErrorV2::Closed,
                other => return Err(refuse(other)),
            };
            Ok(Outcome::SemanticError(error))
        };
        let outcome = match &body.operation {
            Op::WitnessCommit { witness, panel_signature, .. } => {
                let step = prover_step(state, &self.assignment, &self.material, witness.author, origin, true)?;
                let key = step.key;
                *self.authority.step.borrow_mut() = Some(step);
                let limits = self.record_limits;
                let record = preflight_witness_record_v2(self.court.result(), body, limits.max_record_bytes).map_err(refuse)?;
                let context = self
                    .prepared
                    .authenticate_record(witness.clone(), record.record_bytes(), limits, &key, panel_signature)
                    .map_err(refuse)?;
                match self.court.open_candidate(witness.clone(), &key, panel_signature, context, origin.accepted_daa) {
                    Ok(CandidateOpenV2::Opened) => Outcome::CandidateOpened,
                    Ok(CandidateOpenV2::AlreadyActive) => return Err(refuse("fully idempotent candidate has no new journal event")),
                    Err(error) => semantic(error)?,
                }
            }
            Op::ExactFrame { frame, panel_signature } => {
                let frame = EvidenceFrame::decode(frame, self.material.positive_policy.max_frame_bytes).map_err(refuse)?;
                let header = frame.header();
                let active = self.court.last_attempt().ok_or_else(|| refuse("frame without active candidate"))?;
                if header.case != self.pin.case
                    || header.result != self.pin.result
                    || header.witness != active.witness
                    || header.relation_count != 1
                    || header.first_relation != self.court.cursor()
                {
                    return Err(refuse("foreign/future/repeated exact frame"));
                }
                let NativeRowBody::Witness(witness) = required(state, NativeRowKey::Witness(active.witness))? else {
                    return Err(refuse("actual witness row"));
                };
                witness.witness.authenticate(self.court.result(), &witness.panel_key, &witness.panel_signature).map_err(refuse)?;
                let step = prover_step(state, &self.assignment, &self.material, witness.witness.author, origin, false)?;
                if step.key != witness.panel_key {
                    return Err(refuse("exact frame work key substitution"));
                }
                let signature = PanelPacketSignatureV2 { key: step.key, signature: *panel_signature };
                *self.authority.step.borrow_mut() = Some(step);
                match self.court.submit_frame(frame, &signature, origin.accepted_daa) {
                    Ok(()) => Outcome::FrameChecked,
                    Err(error) => semantic(error)?,
                }
            }
            Op::Finish { case, result, witness } => {
                if *case != self.pin.case
                    || *result != self.pin.result
                    || self.court.last_attempt().map(|a| a.witness) != Some(*witness)
                {
                    return Err(refuse("Finish exact active candidate"));
                }
                match self.court.finish(origin.accepted_daa) {
                    Ok(fact) => {
                        if self.facts.len() as u64 >= u64::from(self.material.positive_policy.max_attempts)
                            || self.facts.len() == self.facts.capacity()
                        {
                            return Err(refuse("actual finite fact capacity"));
                        }
                        let kind = fact.terminal_kind();
                        self.facts.push(fact);
                        Outcome::Finished(kind)
                    }
                    Err(error) => semantic(error)?,
                }
            }
            Op::Expire { case, result } => {
                if *case != self.pin.case || *result != self.pin.result {
                    return Err(refuse("Expire Case identity"));
                }
                match self.court.expire(origin.accepted_daa) {
                    Ok(()) => Outcome::Expired,
                    Err(error) => semantic(error)?,
                }
            }
            Op::SourceRequest { request, .. } => {
                if request.case != self.pin.case {
                    return Err(refuse("source request Case"));
                }
                Outcome::External
            }
            Op::SourceResponse { case, .. } => {
                if *case != self.pin.case {
                    return Err(refuse("source response Case"));
                }
                Outcome::External
            }
            Op::ResultAdmission { .. } => return Err(refuse("assigned admission must be genuine op9")),
            Op::PositiveCourtAttestation { .. } => return Err(refuse("P owner handles actual op7")),
        };
        *self.authority.step.borrow_mut() = None;
        let after = snapshot(&self.court);
        if matches!(outcome, Outcome::SemanticError(_)) && before == after {
            return Err(refuse("uncharged checker refusal is not a native event"));
        }
        Ok(NativeAssignedCourtAdvanceV2 { before, after, outcome })
    }
}

/// Full canonical byte comparison without an additional body/transaction Vec.
fn canonical_equal<T: borsh::BorshSerialize>(value: &T, expected: &[u8]) -> bool {
    struct Compare<'a> {
        expected: &'a [u8],
        at: usize,
    }
    impl std::io::Write for Compare<'_> {
        fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
            let end = self.at.checked_add(bytes.len()).ok_or(std::io::ErrorKind::InvalidData)?;
            if self.expected.get(self.at..end) != Some(bytes) {
                return Err(std::io::ErrorKind::InvalidData.into());
            }
            self.at = end;
            Ok(bytes.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    let mut compare = Compare { expected, at: 0 };
    borsh::to_writer(&mut compare, value).is_ok() && compare.at == expected.len()
}

/// Borrowed index over real committed archive bytes. This validates native
/// boundary/input provenance BEFORE the generic local journal checker. It never
/// treats absent/pruned data as an empty Case, and never clones global states.
struct NativeAssignedArchiveV2<'a> {
    backing: &'a NativeCommittedAssignedCaseV2,
    records: Vec<(Digest, usize)>,
    limits: CaseJournalLimits,
    _index_lease: NativeDemandLeaseV1,
}
impl<'a> NativeAssignedArchiveV2<'a> {
    fn new(backing: &'a NativeCommittedAssignedCaseV2, limits: CaseJournalLimits) -> Result<Self, PalwStateV2Error> {
        limits.validate().map_err(refuse)?;
        backing.material().check_row(backing.assignment()).map_err(refuse)?;
        let count = backing.records().len() as u64;
        if count == 0
            || count != backing.pin().head.sequence
            || count > u64::from(backing.material().assignment_policy.max_history_frames)
        {
            return Err(refuse("missing/noncomplete native Case archive"));
        }
        let mut q = TirNativeRequestsV1::new();
        q.exact_v1::<(Digest, usize)>(count).map_err(PalwStateV2Error::NativeResource)?;
        let lease = reserve_native_requests_v1(q.bytes_v1()).map_err(PalwStateV2Error::NativeResource)?.ok_or_else(|| {
            PalwStateV2Error::NativeResource(NativeCoverageV1::unsupported::<Self>(
                "assigned Case archive",
                "actual native replay index lease is absent",
            ))
        })?;
        let mut records = Vec::new();
        records.try_reserve_exact(backing.records().len()).map_err(|_| refuse("native Case index allocation"))?;
        let mut last = Digest([0; 64]);
        let mut total = 0u64;
        let mut previous_origin: Option<AcceptedOrigin> = None;
        for (index, archived) in backing.records().iter().enumerate() {
            total = total
                .checked_add(archived.raw().len() as u64)
                .filter(|n| *n <= backing.material().positive_policy.max_case_journal_bytes)
                .ok_or_else(|| refuse("actual full native Case archive bytes"))?;
            let record = CaseJournalRecordView::decode(archived.raw(), limits).map_err(refuse)?;
            let header = record.header();
            if header.sequence != index as u64 + 1
                || header.previous != last
                || header.scope != backing.pin().scope
                || header.case != backing.pin().case
                || header.result != backing.pin().result
                || header.origin != archived.carriage().origin()
            {
                return Err(refuse("actual native archive scope/link/origin"));
            }
            if let Some(prior) = previous_origin {
                let later = if prior.accepting_block == header.origin.accepting_block {
                    prior.accepted_daa == header.origin.accepted_daa
                        && prior.accepted_blue_score == header.origin.accepted_blue_score
                        && (prior.accepted_tx_ordinal, prior.event_ordinal)
                            < (header.origin.accepted_tx_ordinal, header.origin.event_ordinal)
                } else {
                    prior.accepted_blue_score < header.origin.accepted_blue_score && prior.accepted_daa <= header.origin.accepted_daa
                };
                if !later {
                    return Err(refuse("archive actual accepted-prefix ordering"));
                }
            }
            Self::check_carriage(backing, record, archived.carriage())?;
            let head = record.head();
            records.push((head, index));
            last = head;
            previous_origin = Some(header.origin);
            if index + 1 == backing.records().len()
                && (head != backing.pin().head.head
                    || record.history() != backing.pin().head.history
                    || header.previous != backing.pin().head.previous)
            {
                return Err(refuse("native archive latest pin"));
            }
        }
        records.sort_unstable_by_key(|(head, _)| *head);
        if records.windows(2).any(|w| w[0].0 == w[1].0) {
            return Err(refuse("native Case record identity collision/duplicate"));
        }
        Ok(Self { backing, records, limits, _index_lease: lease })
    }
    fn check_carriage(
        backing: &NativeCommittedAssignedCaseV2,
        record: CaseJournalRecordView<'_>,
        carriage: &NativeAcceptedCaseCarriageV2,
    ) -> Result<(), PalwStateV2Error> {
        use crate::palw_positive_assignment_case_material_v2::AssignmentCaseBoundaryV2;
        let tx = carriage.transaction();
        let h = record.header();
        if !tx.id_is_current()
            || crate::hashing::tx::id(tx).as_bytes() != h.origin.carrier_transaction.0
            || tx.subnetwork_id != crate::subnets::SUBNETWORK_ID_PALW_LIFECYCLE
            || tx.payload.get(..3) != Some(&[1, 0, 176])
            || h.origin.event_ordinal != 0
        {
            return Err(refuse("literal native carrier/origin"));
        }
        match h.kind {
            CaseJournalEventKind::NativeBody => {
                if h.sequence == 1 || tx.payload.get(3..) != Some(record.payload()) || !matches!(record.payload().get(4), Some(1..=7))
                {
                    return Err(refuse("native assigned Case body boundary"));
                }
            }
            CaseJournalEventKind::NativeTransaction => {
                if h.sequence != 1 || tx.payload.get(7) != Some(&9) || !canonical_equal(tx, record.payload()) {
                    return Err(refuse("initial Case must be genuine literal accepted op9 transaction"));
                }
            }
        }
        let mut boundary = None;
        for aux in record.aux() {
            // A bounded fixed decode is safe before choosing the exact semantic
            // domain. Arbitrary equal-length data cannot match its committed id.
            if let Ok(value) = AssignmentCaseBoundaryV2::decode(aux.preimage()) {
                if value.material() == aux.material() && value.case == h.case && value.origin == h.origin {
                    if boundary.replace(value).is_some() {
                        return Err(refuse("duplicate native Case boundary"));
                    }
                }
            }
        }
        let boundary = boundary.ok_or_else(missing)?;
        let prefix = carriage.prefix_state().map_err(|_| missing())?;
        if boundary.pre_event_root.0 != prefix.state_root().as_bytes()
            || boundary.selected_parent.0 != carriage.selected_parent().as_bytes()
        {
            return Err(refuse("native actual executed-prefix boundary root/lineage"));
        }
        boundary.check_populated_data(tx, carriage.entries(), carriage.fee()).map_err(refuse)?;
        if h.sequence == 1 {
            // The current pre-event Assignment can be cancelled/consumed only
            // after this exact op9; a final saved Use is not historical authority.
            let a = assignment(prefix, backing.assignment().id())?;
            if a.status != AssignmentStatusV2::Open
                || a.bundle != backing.assignment().bundle
                || PositiveRowsV2::new(prefix).read(NativeRowKey::Case(h.case)).map_err(refuse)?.is_some()
                || PositiveRowsV2::new(prefix).read(NativeRowKey::AssignmentUse(a.id())).map_err(refuse)?.is_some()
            {
                return Err(refuse("original op9 pre-event Assignment/Case state"));
            }
        } else {
            let (_, bundle, pin) = rooted_bundle(prefix, backing.assignment().id())?;
            if pin.head.head != h.previous
                || pin.head.sequence.checked_add(1) != Some(h.sequence)
                || bundle.result.result.id() != h.result
            {
                return Err(refuse("actual historical event prefix differs from linked Case"));
            }
        }
        Ok(())
    }
    fn archived(&self, head: Digest) -> Result<&NativeCommittedCaseRecordV2, PalwStateV2Error> {
        let at = self.records.binary_search_by_key(&head, |(id, _)| *id).map_err(|_| missing())?;
        self.backing.records().get(self.records[at].1).ok_or_else(missing)
    }
}
impl CaseJournalSourceV2 for NativeAssignedArchiveV2<'_> {
    type Error = PalwStateV2Error;
    fn with_record<T>(&self, head: Digest, max_bytes: u64, visit: impl FnOnce(&[u8]) -> T) -> Result<T, Self::Error> {
        let record = self.archived(head)?;
        if record.raw().len() as u64 > max_bytes || max_bytes > self.limits.max_record_bytes {
            return Err(refuse("native Case source byte cap"));
        }
        Ok(visit(record.raw()))
    }
}
