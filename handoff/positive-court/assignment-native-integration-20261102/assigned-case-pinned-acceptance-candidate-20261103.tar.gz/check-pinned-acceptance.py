import subprocess
from pathlib import Path

stage=Path(__file__).resolve().parent
repo=Path('/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet')
s=(stage/'consensus/src/model/stores/acceptance_data.rs').read_text()
acceptance=(repo/'consensus/core/src/acceptance_data.rs').read_text().replace('use crate::{BlockHash, tx::TransactionId};','')
codec=s[s.index('type ArchiveOriginV2'):s.index('#[cfg(test)]')]
test=s[s.index('        let block = |n|'):s.index('    }\n}',s.index('        let mut bad = raw;'))]
a=test.index('        let dir = kaspa_database')
b=test.index('        let mut bad = raw;')
test=test[:a]+test[b:]
source='''type BlockHash = kaspa_hashes::Hash64;
type TransactionId = BlockHash;
extern crate self as kaspa_consensus_core;
#[derive(Debug)]
enum StoreError { DataInconsistency(String) }
''' + acceptance + '''\n#[derive(Serialize, Deserialize)]
struct AcceptanceDataEntry(std::sync::Arc<AcceptanceData>);
use std::sync::Arc;
''' + codec + '\n#[test]\nfn bounded_acceptance_lookup_matches_persisted_bincode_ordinals() {\n' + test + '}\n'
(stage/'acceptance-probe.rs').write_text(source)
target=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
libs={name: target/'deps'/f'lib{name}-{suffix}.rlib' for name, suffix in {
    'kaspa_hashes': 'd4da608551389cda',
    'bincode': '60d0e77aaf227440',
    'serde': '5fdb58a1aadff283',
}.items()}
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
cmd=[str(rustc),'--edition=2024','--test','-L',f'dependency={target/"deps"}','-A','dead_code']
for name, lib in libs.items():
    cmd.extend(['--extern',f'{name}={lib}'])
binary=stage/'acceptance-probe'
subprocess.run([*cmd,str(stage/'acceptance-probe.rs'),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
