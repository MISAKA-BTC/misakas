from pathlib import Path
base=Path(__file__).resolve().parent/'consensus/src'
p=base/'model/stores/acceptance_data.rs'
s=p.read_text()
anchor='    pub fn insert_batch('
pos=s.index(anchor)
s=s[:pos]+'''    /// Lend the canonical persisted record without allocating its vectors or
    /// seeding the ordinary acceptance cache during a paid archive replay.
    pub(crate) fn with_accepted_archive_v2<T>(
        &self,
        accepting: BlockHash,
        maximum_bytes: u64,
        visit: impl FnOnce(AcceptanceArchiveViewV2<'_>) -> T,
    ) -> Result<T, StoreError> {
        let prefix = [u8::from(DatabaseStorePrefixes::AcceptanceData)];
        let key = kaspa_database::prelude::DbKey::new(&prefix, accepting);
        let bytes = self.db.get_pinned(&key)?.ok_or_else(|| StoreError::KeyNotFound(key))?;
        if bytes.len() as u64 > maximum_bytes {
            return Err(StoreError::LocalResourceUnavailable("acceptance archive exceeds replay byte limit".into()));
        }
        Ok(visit(AcceptanceArchiveViewV2::new(&bytes)?))
    }

'''+s[pos:]
start=s.index('/// bincode v1 fixed-int')
end=s.index('#[cfg(test)]',start)
s=s[:start]+'''type ArchiveOriginV2 = (BlockHash, AcceptedTxEntry);

/// A canonical pinned bincode record. This view never owns a decoded Vec.
pub(crate) struct AcceptanceArchiveViewV2<'a>(&'a [u8]);

impl<'a> AcceptanceArchiveViewV2<'a> {
    fn new(raw: &'a [u8]) -> Result<Self, StoreError> {
        visit_acceptance_bytes_v2(raw, |_, _| false)?;
        Ok(Self(raw))
    }

    /// The archived input may refer to a transaction earlier in the same
    /// accepting prefix. The bound is exclusive and spans all mergeset blocks.
    pub(crate) fn find_before_v2(
        &self,
        before: u32,
        transaction: kaspa_consensus_core::TransactionId,
    ) -> Result<Option<ArchiveOriginV2>, StoreError> {
        let mut found = None;
        visit_acceptance_bytes_v2(self.0, |ordinal, origin| {
            if ordinal >= u64::from(before) {
                return true;
            }
            if origin.1.transaction_id == transaction {
                found = Some(origin);
                return true;
            }
            false
        })?;
        Ok(found)
    }
}

fn accepted_origin_from_bytes_v2(raw: &[u8], ordinal: u32) -> Result<Option<ArchiveOriginV2>, StoreError> {
    let mut found = None;
    visit_acceptance_bytes_v2(raw, |at, origin| {
        if at == u64::from(ordinal) {
            found = Some(origin);
        }
        false
    })?;
    Ok(found)
}

/// bincode v1 fixed-int sequence and byte-string framing. Both BlockHash
/// and TransactionId serialize as a length-prefixed Hash64. Only a validated
/// view uses early exit, so a bad tail cannot pass an ordinal lookup.
fn visit_acceptance_bytes_v2(
    mut raw: &[u8],
    mut stop: impl FnMut(u64, ArchiveOriginV2) -> bool,
) -> Result<(), StoreError> {
    fn invalid() -> StoreError {
        StoreError::DataInconsistency("malformed accepted origin record".into())
    }
    fn take<const N: usize>(raw: &mut &[u8]) -> Result<[u8; N], StoreError> {
        let (head, tail) = raw.split_first_chunk::<N>().ok_or_else(invalid)?;
        *raw = tail;
        Ok(*head)
    }
    fn hash(raw: &mut &[u8]) -> Result<BlockHash, StoreError> {
        if u64::from_le_bytes(take(raw)?) != 64 {
            return Err(invalid());
        }
        Ok(BlockHash::from_bytes(take(raw)?))
    }

    const ENTRY_BYTES: usize = 8 + 64 + 4;
    let count = u64::from_le_bytes(take(&mut raw)?);
    let mut ordinal = 0u64;
    for _ in 0..count {
        let block = hash(&mut raw)?;
        let entries = u64::from_le_bytes(take(&mut raw)?);
        let extent = usize::try_from(entries).ok().and_then(|n| n.checked_mul(ENTRY_BYTES)).ok_or_else(invalid)?;
        let (body, tail) = raw.split_at_checked(extent).ok_or_else(invalid)?;
        raw = tail;
        for mut entry in body.chunks_exact(ENTRY_BYTES) {
            let transaction_id = hash(&mut entry)?;
            let index_within_block = u32::from_le_bytes(take(&mut entry)?);
            if stop(ordinal, (block, AcceptedTxEntry { transaction_id, index_within_block })) {
                return Ok(());
            }
            ordinal = ordinal.checked_add(1).ok_or_else(invalid)?;
        }
    }
    if !raw.is_empty() {
        return Err(invalid());
    }
    Ok(())
}

'''+s[end:]
anchor='        assert!(accepted_origin_from_bytes_v2(&raw, 3).unwrap().is_none());'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''
        let archive = AcceptanceArchiveViewV2::new(&raw).unwrap();
        assert!(archive.find_before_v2(1, block(4)).unwrap().is_none());
        let (creator, entry) = archive.find_before_v2(2, block(4)).unwrap().unwrap();
        assert_eq!((creator, entry.index_within_block), (block(2), 7));
        assert!(archive.find_before_v2(2, block(6)).unwrap().is_none());
        assert_eq!(archive.find_before_v2(3, block(6)).unwrap().unwrap().0, block(5));
        assert!(AcceptanceArchiveViewV2::new(&raw[..raw.len() - 1]).is_err());''')
anchor='        let mut bad = raw;'
assert s.count(anchor)==1
s=s.replace(anchor,'''        assert!(store.with_accepted_archive_v2(accepting, raw.len() as u64 - 1, |_| ()).is_err());
        let earlier = store
            .with_accepted_archive_v2(accepting, raw.len() as u64, |view| view.find_before_v2(2, block(4)))
            .unwrap()
            .unwrap()
            .unwrap();
        assert_eq!((earlier.0, earlier.1.index_within_block), (block(2), 7));

'''+anchor)
p.write_text(s)
p=base/'pipeline/virtual_processor/processor/positive_assignment_archive.rs'
s=p.read_text()
for old,new in [
('use kaspa_consensus_core::{\n    palw_native_resource_v1::', 'use crate::model::stores::acceptance_data::AcceptanceArchiveViewV2;\nuse kaspa_consensus_core::{\n    palw_native_resource_v1::'),
('''        let acceptance = self.acceptance_data_store.get(accepting).map_err(|_| E::Unavailable("original acceptance data"))?;
        self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::UtxoDiffs, accepting)?;
        let (entries, lease, retained_heap) = self.restore_original_archive_inputs_v2(
            &acceptance,
            origin,
            tx,
            maximum_heap,
            (size_of::<NativeAcceptedCaseCarriageV2>() + size_of::<[usize; 2]>()) as u64,
            |creator| self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::BlockTransactions, creator),
        )?;''','''        self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::UtxoDiffs, accepting)?;
        let (entries, lease, retained_heap) = self
            .acceptance_data_store
            .with_accepted_archive_v2(accepting, acceptance_bytes, |acceptance| {
                self.restore_original_archive_inputs_v2(
                    &acceptance,
                    origin,
                    tx,
                    maximum_heap,
                    (size_of::<NativeAcceptedCaseCarriageV2>() + size_of::<[usize; 2]>()) as u64,
                    |creator| self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::BlockTransactions, creator),
                )
            })
            .map_err(|_| E::Unavailable("bounded original acceptance archive"))??;'''),
('''        let acceptance = self.acceptance_data_store.get(accepting).map_err(|_| E::Unavailable("original relay acceptance data"))?;''',''),
('''        let (entries, lease, _) =
            self.restore_original_archive_inputs_v2(&acceptance, replay.origin, tx, replay.maximum_heap, 0, |creator| {
                record(&mut replay, DatabaseStorePrefixes::BlockTransactions, creator)
            })?;''','''        let (entries, lease, _) = self
            .acceptance_data_store
            .with_accepted_archive_v2(accepting, acceptance_bytes, |acceptance| {
                self.restore_original_archive_inputs_v2(&acceptance, replay.origin, tx, replay.maximum_heap, 0, |creator| {
                    record(&mut replay, DatabaseStorePrefixes::BlockTransactions, creator)
                })
            })
            .map_err(|_| E::Unavailable("bounded original relay acceptance archive"))??;'''),
]:
    assert s.count(old)==1,old
    s=s.replace(old,new)
s=s.replace('acceptance: &kaspa_consensus_core::acceptance_data::AcceptanceData,','acceptance: &AcceptanceArchiveViewV2<\'_>,')
start=s.index('        let mut ordinal = 0u64;',s.index('    fn with_prior_assignment_output_v2'))
end=s.index('\n    }',start)
s=s[:start]+'''        let Some((block, entry)) = acceptance
            .find_before_v2(origin.accepted_tx_ordinal, outpoint.transaction_id)
            .map_err(|_| E::Invalid("original acceptance archive traversal"))?
        else {
            return Ok(None);
        };
        before_read(block)?;
        let body = self.block_transactions_store.get(block).map_err(|_| E::Unavailable("earlier accepted creator body"))?;
        let tx = body.get(entry.index_within_block as usize).ok_or(E::Invalid("earlier creator index"))?;
        if !tx.id_is_current() || tx.id() != outpoint.transaction_id {
            return Err(E::Invalid("earlier accepted creator identity"));
        }
        tx.outputs
            .get(outpoint.index as usize)
            .map(|output| Some(visit(output, tx.is_coinbase())))
            .ok_or(E::Invalid("earlier creator output index"))'''+s[end:]
p.write_text(s)
