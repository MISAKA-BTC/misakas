from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
archive=(root/'consensus/src/pipeline/virtual_processor/processor/positive_assignment_archive.rs').read_text()
start=archive.index('fn case_journal_retained_quote_v2')
end=archive.index('/// The original relay registration',start)
core=root/'consensus/core/src/palw_positive_journal_chain_v2.rs'
probe=f'#[path = "{core}"]\nmod core_journal;\n'+'''
#![allow(dead_code)]
use core_journal::CaseJournalLinkQuoteV2;
use std::mem::size_of;
struct NativeCaseJournalBytesV2 { records:Vec<Vec<u8>>, work:u64, _lease:usize }
'''+archive[start:end]+'''
#[test]
fn owned_case_journal_charges_both_reads_all_hashes_and_copy() {
    let quote=CaseJournalLinkQuoteV2{
        events:2,record_reads:4,record_decodes:4,total_record_bytes:2000,hash_bytes:4000,
        index_bytes:128,retained_inline_bytes:100,decode_workspace_bytes:300,
    };
    let fixed=2*size_of::<Vec<u8>>() as u64+size_of::<NativeCaseJournalBytesV2>() as u64;
    assert_eq!(case_journal_retained_quote_v2(quote),Some((1000+fixed,7004)));
    assert_eq!(case_journal_retained_quote_v2(CaseJournalLinkQuoteV2{hash_bytes:u64::MAX,..quote}),None);
    assert_eq!(case_journal_retained_quote_v2(CaseJournalLinkQuoteV2{events:u64::MAX,..quote}),None);
}
'''
probe=probe.replace('#![allow(dead_code)]\n','')
probe='#![allow(dead_code)]\n'+probe
p=root/'probe.rs'
p.write_text(probe)
deps=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug/deps')
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
binary=root/'probe'
subprocess.run([str(rustc),'--edition=2024','--test','-L',f'dependency={deps}','--extern',
                f'misaka_palw_positive_contract={deps}/libmisaka_palw_positive_contract-3c6e0f32d28c41f7.rlib',
                str(p),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
