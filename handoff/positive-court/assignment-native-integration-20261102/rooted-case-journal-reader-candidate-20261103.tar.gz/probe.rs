#![allow(dead_code)]
#[path = "/private/tmp/misaka-a0-rooted-case-journal.1SBTWS/consensus/core/src/palw_positive_journal_chain_v2.rs"]
mod core_journal;

use core_journal::CaseJournalLinkQuoteV2;
use std::mem::size_of;
struct NativeCaseJournalBytesV2 { records:Vec<Vec<u8>>, work:u64, _lease:usize }
fn case_journal_retained_quote_v2(quote: CaseJournalLinkQuoteV2) -> Option<(u64, u64)> {
    let retained = quote
        .events
        .checked_mul(size_of::<Vec<u8>>() as u64)?
        .checked_add(quote.total_record_bytes / 2)?
        .checked_add(size_of::<NativeCaseJournalBytesV2>() as u64)?;
    let work = quote
        .record_reads
        .checked_add(quote.total_record_bytes)?
        .checked_add(quote.hash_bytes)?
        .checked_add(quote.total_record_bytes / 2)?;
    Some((retained, work))
}


#[test]
fn owned_case_journal_charges_both_reads_all_hashes_and_copy() {
    let quote=CaseJournalLinkQuoteV2{
        events:2,record_reads:4,record_decodes:4,total_record_bytes:2000,hash_bytes:4000,
        index_bytes:128,retained_inline_bytes:100,decode_workspace_bytes:300,
    };
    let fixed=2*size_of::<Vec<u8>>() as u64+size_of::<NativeCaseJournalBytesV2>() as u64;
    assert_eq!(case_journal_retained_quote_v2(quote),Some((1000+fixed,7004)));
    assert_eq!(case_journal_retained_quote_v2(CaseJournalLinkQuoteV2{hash_bytes:u64::MAX,..quote}),None);
    assert_eq!(case_journal_retained_quote_v2(CaseJournalLinkQuoteV2{events:u64::MAX,..quote}),None);
}
