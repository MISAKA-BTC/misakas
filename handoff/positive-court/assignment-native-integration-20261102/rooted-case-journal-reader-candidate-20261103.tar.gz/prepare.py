from pathlib import Path
p=Path(__file__).resolve().parent/'consensus/src/pipeline/virtual_processor/processor/positive_assignment_archive.rs'
s=p.read_text()
s=s.replace("    journal::CaseJournalRecordView,","    identity::Digest,\n    journal::CaseJournalRecordView,")
old='''    palw_positive_assignment_material_v2::{AssignmentAdmissionMaterialV2, AssignmentAdmissionMaterialViewV2},
'''
new=old+'''    palw_positive_journal_chain_v2::{
        CaseJournalChainErrorV2, CaseJournalChainLimitsV2, CaseJournalLinkQuoteV2, CaseJournalPinV2, CaseJournalVisitErrorV2,
        CheckedCaseJournalLinksV2, check_case_journal_links_v2,
    },
'''
assert s.count(old)==1
s=s.replace(old,new)
point='''/// The original relay registration pays for its bounded historical reads.'''
insert='''/// Exact journal bytes in replay order. A native carriage owner must still
/// authenticate the accepting transaction, fee, prefix and event effects.
pub(in crate::pipeline::virtual_processor) struct NativeCaseJournalBytesV2 {
    pub records: Vec<Vec<u8>>,
    pub work: u64,
    _lease: kaspa_consensus_core::palw_native_resource_v1::NativeDemandLeaseV1,
}

fn case_journal_fault_v2(error: CaseJournalChainErrorV2<StoreError>) -> NativeAssignmentArchiveErrorV2 {
    use NativeAssignmentArchiveErrorV2 as E;
    match error {
        CaseJournalChainErrorV2::Source(error) => archive_store_fault_v2(error, "rooted Case journal read"),
        CaseJournalChainErrorV2::Invalid(_) => E::Invalid("rooted Case journal identity or links"),
        CaseJournalChainErrorV2::LocalBudget(_) => E::Unavailable("rooted Case journal exceeds its original replay limits"),
    }
}

fn case_journal_retained_quote_v2(quote: CaseJournalLinkQuoteV2) -> Option<(u64, u64)> {
    let retained = quote
        .events
        .checked_mul(size_of::<Vec<u8>>() as u64)?
        .checked_add(quote.total_record_bytes / 2)?
        .checked_add(size_of::<NativeCaseJournalBytesV2>() as u64)?;
    let work = quote
        .record_reads
        .checked_add(quote.total_record_bytes)?
        .checked_add(quote.hash_bytes)?
        .checked_add(quote.total_record_bytes / 2)?;
    Some((retained, work))
}

'''+point
assert s.count(point)==1
s=s.replace(point,insert)
point='''impl VirtualStateProcessor {
    /// Re-resolve one original accepted carriage'''
insert='''impl VirtualStateProcessor {
    /// Walk a rooted Case head backwards and copy its verified raw records in
    /// execution order. Both reads are budgeted before hashing. Release the
    /// store lock before any caller reconstructs the archived native prefixes.
    pub(in crate::pipeline::virtual_processor) fn load_rooted_case_journal_bytes_v2(
        &self,
        pin: CaseJournalPinV2,
        mut limits: CaseJournalChainLimitsV2,
        maximum_heap: u64,
        maximum_work: u64,
    ) -> Result<NativeCaseJournalBytesV2, NativeAssignmentArchiveErrorV2> {
        use NativeAssignmentArchiveErrorV2 as E;
        if [maximum_heap, maximum_work].into_iter().any(|n| n == 0 || n == u64::MAX) {
            return Err(E::Invalid("Case journal limits must be finite"));
        }
        if pin.head.sequence == 0 || pin.head.sequence > limits.max_events {
            return Err(E::Invalid("Case journal head sequence is outside its original bound"));
        }
        let reads = pin.head.sequence.checked_mul(2).ok_or(E::Invalid("Case journal read count overflow"))?;
        // Two reads, four hash passes and one retained copy per unique byte.
        // Cap the shared checker's two-pass raw input before the first lookup.
        let unique_work = maximum_work.checked_sub(reads).ok_or(E::Unavailable("Case journal read work cap"))? / 7;
        let byte_work = unique_work * 2;
        limits.max_total_record_bytes = limits.max_total_record_bytes.min(byte_work);
        let index = pin.head.sequence.checked_mul(size_of::<Digest>() as u64).ok_or(E::Invalid("Case journal index overflow"))?;
        limits.max_index_bytes = limits.max_index_bytes.min(index);
        let fixed = size_of::<CheckedCaseJournalLinksV2>() as u64
            + kaspa_consensus_core::palw_native_resource_v1::positive_journal::POSITIVE_JOURNAL_DECODE_WORKSPACE_BYTES_V1 as u64;
        let scratch = index.checked_add(fixed).ok_or(E::Invalid("Case journal workspace overflow"))?;
        let remainder = maximum_heap.checked_sub(scratch).ok_or(E::Unavailable("Case journal index heap cap"))?;
        let _scratch = reserve_native_requests_v1(scratch).map_err(E::Resource)?.ok_or(E::Unavailable("Case journal index lease"))?;
        let store = self.palw_state_v2_store.read();
        let checked = check_case_journal_links_v2(&*store, pin, limits).map_err(case_journal_fault_v2)?;
        let (retained, work) = case_journal_retained_quote_v2(checked.quote()).ok_or(E::Invalid("Case journal retained quote overflow"))?;
        if retained > remainder || work > maximum_work {
            return Err(E::Unavailable("Case journal retained heap or replay work cap"));
        }
        let lease = reserve_native_requests_v1(retained).map_err(E::Resource)?.ok_or(E::Unavailable("Case journal raw records lease"))?;
        let count = usize::try_from(pin.head.sequence).map_err(|_| E::Invalid("Case journal count address space"))?;
        let mut records = Vec::new();
        records.try_reserve_exact(count).map_err(|_| E::Unavailable("Case journal record vector allocation"))?;
        if records.capacity() > count {
            return Err(E::Unavailable("Case journal record vector exceeded its lease"));
        }
        checked.visit_forward(&*store, |record| {
            let raw = record.raw_bytes();
            let mut copy = Vec::new();
            copy.try_reserve_exact(raw.len()).map_err(|_| E::Unavailable("Case journal raw record allocation"))?;
            if copy.capacity() > raw.len() {
                return Err(E::Unavailable("Case journal raw record allocation exceeded its lease"));
            }
            copy.extend_from_slice(raw);
            records.push(copy);
            Ok(())
        }).map_err(|error| match error {
            CaseJournalVisitErrorV2::Chain(error) => case_journal_fault_v2(error),
            CaseJournalVisitErrorV2::Visitor(error) => error,
        })?;
        Ok(NativeCaseJournalBytesV2 { records, work, _lease: lease })
    }

    /// Re-resolve one original accepted carriage'''
assert s.count(point)==1
p.write_text(s.replace(point,insert))
