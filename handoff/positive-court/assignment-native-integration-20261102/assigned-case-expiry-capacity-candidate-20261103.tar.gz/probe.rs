
use misaka_palw_positive_contract::messages::{ClaimStatus, WitnessStatus};

#[derive(Debug, PartialEq, Eq)]
enum CourtErrorV2 { Order, Closed, Deadline }
struct Limits { deadline:u64 }
struct Attempt { status:WitnessStatus }
struct Candidate { status:WitnessStatus, progress:Option<u8>, receipts:Vec<u8> }
struct Court {
    now:u64, limits:Limits, claim_status:ClaimStatus, candidate:Option<Candidate>, last_attempt:Option<Attempt>,
}
impl Court {
    pub(crate) fn expire_pending_v2(&mut self, now: u64) -> Result<(), CourtErrorV2> {
        if now < self.now {
            return Err(CourtErrorV2::Order);
        }
        if self.claim_status != ClaimStatus::Pending {
            return Err(CourtErrorV2::Closed);
        }
        if now < self.limits.deadline {
            return Err(CourtErrorV2::Deadline);
        }
        self.expire(now)
    }

    pub fn expire(&mut self, now: u64) -> Result<(), CourtErrorV2> {
        if now < self.now {
            return Err(CourtErrorV2::Order);
        }
        self.now = now;
        if now >= self.limits.deadline && self.claim_status == ClaimStatus::Pending {
            self.claim_status = ClaimStatus::EndedUnverified;
            if let Some(candidate) = &mut self.candidate {
                if candidate.status == WitnessStatus::Checking {
                    candidate.status = WitnessStatus::Incomplete;
                    self.last_attempt.as_mut().expect("attempt recorded").status = WitnessStatus::Incomplete;
                }
                candidate.progress = None;
                candidate.receipts = Vec::new();
            }
        }
        Ok(())
    }

}
fn court(status: ClaimStatus) -> Court {
    Court { now:20, limits:Limits {deadline:50}, claim_status:status,
            candidate:Some(Candidate {status:WitnessStatus::Checking,progress:Some(3),receipts:vec![1,2]}),
            last_attempt:Some(Attempt {status:WitnessStatus::Checking}) }
}
#[test]
fn expiry_only_records_real_terminal_transition() {
    let mut pending = court(ClaimStatus::Pending);
    assert_eq!(pending.expire_pending_v2(19), Err(CourtErrorV2::Order));
    assert_eq!(pending.expire_pending_v2(49), Err(CourtErrorV2::Deadline));
    assert_eq!(pending.now, 20);
    assert_eq!(pending.candidate.as_ref().unwrap().receipts, [1,2]);
    assert_eq!(pending.expire_pending_v2(50), Ok(()));
    assert_eq!(pending.claim_status, ClaimStatus::EndedUnverified);
    assert_eq!(pending.last_attempt.as_ref().unwrap().status, WitnessStatus::Incomplete);
    let candidate = pending.candidate.as_ref().unwrap();
    assert_eq!(candidate.progress, None);
    assert!(candidate.receipts.is_empty());
    assert_eq!(pending.expire_pending_v2(51), Err(CourtErrorV2::Closed));
    assert_eq!(pending.now, 50);
    for status in [ClaimStatus::PositivePassed, ClaimStatus::ClaimRefuted, ClaimStatus::Revoked] {
        let mut terminal = court(status);
        assert_eq!(terminal.expire_pending_v2(51), Err(CourtErrorV2::Closed));
        assert_eq!(terminal.now, 20);
        assert_eq!(terminal.claim_status, status);
    }
}
