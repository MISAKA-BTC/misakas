from pathlib import Path

root = Path(__file__).resolve().parent / 'consensus/core/src'
def replace(path, old, new):
    p = root / path
    s = p.read_text()
    assert s.count(old) == 1, (path, old)
    p.write_text(s.replace(old, new))

replace('palw_positive_court_v2/coordinator/contract.rs',
'''    pub fn expire(&mut self, now: u64) -> Result<(), CourtErrorV2<C::Error, V::Error>> {''',
'''    /// A journaled op6 requires an actual Pending to EndedUnverified
    /// transition. Ordinary clock observation uses expire or preview_expiry_v2.
    pub(crate) fn expire_pending_v2(&mut self, now: u64) -> Result<(), CourtErrorV2<C::Error, V::Error>> {
        if now < self.now {
            return Err(CourtErrorV2::Order);
        }
        if self.claim_status != ClaimStatus::Pending {
            return Err(CourtErrorV2::Closed);
        }
        if now < self.limits.deadline {
            return Err(CourtErrorV2::Deadline);
        }
        self.expire(now)
    }

    pub fn expire(&mut self, now: u64) -> Result<(), CourtErrorV2<C::Error, V::Error>> {''')
replace('palw_positive_common_replay_v2.rs',
        'match court.expire(header.origin.accepted_daa) {',
        'match court.expire_pending_v2(header.origin.accepted_daa) {')
replace('palw_state_v2/positive_assignment_case.rs',
        'match self.court.expire(origin.accepted_daa) {',
        'match self.court.expire_pending_v2(origin.accepted_daa) {')
