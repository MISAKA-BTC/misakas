from pathlib import Path
root=Path(__file__).resolve().parent/'consensus/core/src'
p=root/'palw_native_resource_v1/transition.rs'
s=p.read_text()
old='''        self.split_owner_v1(value, requests)
    }
    fn split_owner_v1<T>(&mut self, value: T, requests: u64) -> Result<NativeRetainedV1<T>, NativeCoverageV1> {
        if requests > self.requests {
            return Err(NativeCoverageV1::unsupported::<T>(
                "fresh transition output",
                "an actual output exceeds the writer's pre-construction reservations; uncovered growth cannot be approved afterwards",
            ));'''
new='''        self.split_owner_v1(value, requests, "fresh transition output")
    }
    fn split_owner_v1<T>(&mut self, value: T, requests: u64, component: &str) -> Result<NativeRetainedV1<T>, NativeCoverageV1> {
        if requests > self.requests {
            return Err(NativeCoverageV1::unsupported::<T>(
                component,
                &format!("output requires {requests} bytes; writer has {} bytes of pre-construction reservation", self.requests),
            ));'''
assert s.count(old)==1
s=s.replace(old,new)
old='''    pub(crate) fn finish_state_v1(mut self, state: PalwChainStateV2) -> Result<NativeChainStateV1, NativeCoverageV1> {
        self.take_value_v1(state)
    }'''
new='''    pub(crate) fn finish_state_v1(
        mut self,
        state: PalwChainStateV2,
        component: &str,
    ) -> Result<NativeChainStateV1, NativeCoverageV1> {
        let requests = value_requests_v1(&state)?;
        self.split_owner_v1(state, requests, component)
    }'''
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace('''        assert!(construction.split_owner_v1(0u8, 65).is_err());''','''        let failure = construction.split_owner_v1(0u8, 65, "test output").err().unwrap();
        assert!(matches!(
            failure,
            NativeCoverageV1::Unsupported { component, reason, .. }
                if component == "test output" && reason.contains("65 bytes") && reason.contains("64 bytes")
        ));''')
s=s.replace('split_owner_v1(1u8, 32)','split_owner_v1(1u8, 32, "state")').replace('split_owner_v1(2u8, 16)','split_owner_v1(2u8, 16, "delta")')
p.write_text(s)
p=root/'palw_state_v2.rs'
s=p.read_text()
old='builder.native_reservation.finish_state_v1(builder.state).map_err(PalwStateV2Error::NativeResource)'
labels=['native pre-object state', 'native single-object state', 'native single-Assignment rehearsal state', 'native relay fee-preview state']
assert s.count(old)==len(labels)
for label in labels:
 s=s.replace(old,'builder\n        .native_reservation\n        .finish_state_v1(builder.state, "'+label+'")\n        .map_err(PalwStateV2Error::NativeResource)',1)
p.write_text(s)
