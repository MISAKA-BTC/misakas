from pathlib import Path
import subprocess

stage=Path(__file__).resolve().parent
text=(stage/'consensus/core/src/palw_positive_court_v2/coordinator/contract.rs').read_text()
start=text.index('    pub(crate) fn expire_pending_v2')
end=text.index('    pub fn revoke(', start)
exact=text[start:end].replace('CourtErrorV2<C::Error, V::Error>', 'CourtErrorV2')
code='''
use misaka_palw_positive_contract::messages::{ClaimStatus, WitnessStatus};

#[derive(Debug, PartialEq, Eq)]
enum CourtErrorV2 { Order, Closed, Deadline }
struct Limits { deadline:u64 }
struct Attempt { status:WitnessStatus }
struct Candidate { status:WitnessStatus, progress:Option<u8>, receipts:Vec<u8> }
struct Court {
    now:u64, limits:Limits, claim_status:ClaimStatus, candidate:Option<Candidate>, last_attempt:Option<Attempt>,
}
impl Court {
'''+exact+'''
}
fn court(status: ClaimStatus) -> Court {
    Court { now:20, limits:Limits {deadline:50}, claim_status:status,
            candidate:Some(Candidate {status:WitnessStatus::Checking,progress:Some(3),receipts:vec![1,2]}),
            last_attempt:Some(Attempt {status:WitnessStatus::Checking}) }
}
#[test]
fn expiry_only_records_real_terminal_transition() {
    let mut pending = court(ClaimStatus::Pending);
    assert_eq!(pending.expire_pending_v2(19), Err(CourtErrorV2::Order));
    assert_eq!(pending.expire_pending_v2(49), Err(CourtErrorV2::Deadline));
    assert_eq!(pending.now, 20);
    assert_eq!(pending.candidate.as_ref().unwrap().receipts, [1,2]);
    assert_eq!(pending.expire_pending_v2(50), Ok(()));
    assert_eq!(pending.claim_status, ClaimStatus::EndedUnverified);
    assert_eq!(pending.last_attempt.as_ref().unwrap().status, WitnessStatus::Incomplete);
    let candidate = pending.candidate.as_ref().unwrap();
    assert_eq!(candidate.progress, None);
    assert!(candidate.receipts.is_empty());
    assert_eq!(pending.expire_pending_v2(51), Err(CourtErrorV2::Closed));
    assert_eq!(pending.now, 50);
    for status in [ClaimStatus::PositivePassed, ClaimStatus::ClaimRefuted, ClaimStatus::Revoked] {
        let mut terminal = court(status);
        assert_eq!(terminal.expire_pending_v2(51), Err(CourtErrorV2::Closed));
        assert_eq!(terminal.now, 20);
        assert_eq!(terminal.claim_status, status);
    }
}
'''
src=stage/'probe.rs'
src.write_text(code)
deps=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug/deps')
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
binary=stage/'probe'
subprocess.run([str(rustc),'--edition=2024','--test','-L',f'dependency={deps}','--extern',
                f'misaka_palw_positive_contract={deps}/libmisaka_palw_positive_contract-3c6e0f32d28c41f7.rlib',
                str(src),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
