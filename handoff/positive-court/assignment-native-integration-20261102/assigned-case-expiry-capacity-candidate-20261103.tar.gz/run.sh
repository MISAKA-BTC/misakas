#!/bin/bash
set -euo pipefail
base=/tmp/misaka-native-relay-linux-xfs-ingress
name=misaka-a0-native-relay-xfs-ingress
source_commit=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["base"])' "$base/manifest.json")
dock() { docker --context colima-t12-oom-build "$@"; }
cleanup() {
    if [[ -n "${monitor:-}" ]]; then kill "$monitor" 2>/dev/null || :; fi
    if dock exec "$name" test -f /build/misaka-runtime-ready >/dev/null 2>&1; then
        echo "Retaining completed build in $name for a focused retry"
    else
        dock stop --time 5 "$name" >/dev/null 2>&1 || :
        dock container rm "$name" >/dev/null 2>&1 || :
    fi
}
if dock inspect --type container "$name" >/dev/null 2>&1; then exit 2; fi
dock run -d --pull=never --name "$name" --privileged --platform linux/amd64 --memory 8500m --memory-swap 8500m --cpus 3 \
    --tmpfs /build:rw,exec,size=5g --tmpfs /test-quota:rw,exec,size=450m \
    rust:1.93.0-bookworm sleep infinity
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
(
    while sleep 5; do
        avail=$(df -k "$base" | awk 'NR==2 {print $4}')
        if [[ "$avail" -lt 1048576 ]]; then
            echo "Host free capacity ${avail} KiB is below 1048576 KiB" >&2
            dock stop --time 5 "$name" >&2 || :
            exit 1
        fi
    done
) &
monitor=$!
git rev-parse "$source_commit"
shasum -a 256 "$base/assigned-case-expiry-and-capacity.patch"
dock exec "$name" mkdir /src
git archive --format=tar "$source_commit" | dock exec -i "$name" tar --exclude=handoff -xf - -C /src
dock exec -i -w /src "$name" git apply --whitespace=error - < "$base/assigned-case-expiry-and-capacity.patch"
dock exec -i "$name" /bin/bash -s < "$base/inside.sh"
