from pathlib import Path
import json, re, subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet')
src = root / 'consensus/core/src'
route = (src/'palw_kernel_route_v1.rs').read_text()
fold = (src/'palw_kernel_route_fold_v1.rs').read_text()
tables = (repo/'misaka/palw/kernel/src/rows.rs').read_text()
vectors = json.loads((repo/'docs/design/palw/positive-court/contract-vectors-r1.json').read_text())
(root/'result-vector.bin').write_bytes(bytes.fromhex(vectors['result_borsh_hex']))
constants = '\n'.join(re.findall(r'pub const TABLE_(?:CLAIMS|JOB_CLAIMS|JOB_ESCROWS|JOBS|PIPELINE_JOBS|SEALS)_V1: u8 = \d+;',tables))
a = route.index('pub(crate) fn is_positive_result_row_v2')
b = route.index('impl BorshDeserialize for PalwKernelRouteStateV1',a)
c = fold.index('fn legacy_kernel_job_alias_v2')
d = fold.index("impl TransitionBuilder<'_>",c)
probe = '''use std::collections::{BTreeMap, BTreeSet};
use kaspa_hashes::Hash64;
use misaka_palw_positive_contract::{identity::*, messages::MinerResultCommit, native::{KERNEL_AUX_TABLE, ruleset_id}, rows::*};
extern crate self as misaka_palw_kernel;
mod rows { '''+constants+''' }
#[derive(Default)]
struct PalwKernelRouteStateV1 {
    aux: BTreeMap<(u8, Vec<u8>), Vec<u8>>,
    positive_job_results_v2: BTreeSet<(Hash64, Hash64)>,
}
'''+route[a:b]+fold[c:d]+'''
fn make_result(output: u8) -> NativeRowValue {
    let mut result: MinerResultCommit = borsh::from_slice(include_bytes!("result-vector.bin")).unwrap();
    let key = [0; PUBKEY_BYTES];
    let policy = Digest([14; 64]);
    let fired = Digest([15; 64]);
    result.scope.ruleset = ruleset_id(fired, policy);
    result.miner = principal(&key);
    result.output = Digest([output; 64]);
    let origin = AcceptedOrigin {
        accepting_block: NativeHash64([1; 64]), carrier_block: NativeHash64([2; 64]), carrier_transaction: NativeHash64([3; 64]),
        accepted_tx_ordinal: 4, event_ordinal: 5, accepted_daa: 6, accepted_blue_score: 7,
    };
    let dependencies = AcceptedMaterial { origin, digest: result.dependencies };
    NativeRowValue::new(NativeRowBody::Result(ResultRow {
        result, miner_key: key, miner_signature: [0; SIGNATURE_BYTES], origin, policy, fired_fork: fired,
        funding_scope: FundingScopeId(Digest([16; 64])), dependencies, role_assignment: dependencies,
    })).unwrap()
}
#[test]
fn exact_projection_preserves_job_on_partial_revert_and_rejects_wrong_row() {
    let one = make_result(43);
    let two = make_result(44);
    let NativeRowBody::Result(result) = &one.body else { panic!() };
    let job = Hash64::from_bytes(result.result.job.0);
    let one_key = (KERNEL_AUX_TABLE, one.body.key().encode());
    let two_key = (KERNEL_AUX_TABLE, two.body.key().encode());
    let one_bytes = one.encode().unwrap();
    let two_bytes = two.encode().unwrap();
    let mut state = PalwKernelRouteStateV1::default();
    assert!(state.update_positive_job_index_v2(&one_key, Some(&two_bytes)).is_err());
    assert!(!state.contains_positive_job_v2(job));
    for (key, bytes) in [(one_key.clone(),one_bytes),(two_key.clone(),two_bytes)] {
        state.update_positive_job_index_v2(&key, Some(&bytes)).unwrap();
        state.aux.insert(key,bytes);
        assert!(state.contains_positive_job_v2(job));
    }
    assert!(!state.contains_positive_job_v2(Hash64::from_bytes([222;64])));
    for (key, expected) in [(two_key,true),(one_key,false)] {
        state.update_positive_job_index_v2(&key,None).unwrap();
        state.aux.remove(&key);
        assert_eq!(state.contains_positive_job_v2(job),expected);
    }
}
#[test]
fn exact_kernel_job_subjects_match_canonical_row_prefixes() {
    use rows::*;
    let job = Hash64::from_bytes([17;64]);
    let other = Hash64::from_bytes([18;64]);
    let key = job.as_bytes();
    for table in [TABLE_JOBS_V1, TABLE_PIPELINE_JOBS_V1, TABLE_JOB_CLAIMS_V1, TABLE_JOB_ESCROWS_V1] {
        assert_eq!(legacy_kernel_job_alias_v2(table, &key, &[]), Some(job));
        assert_eq!(legacy_kernel_job_alias_v2(table, &key[..63], &[]), None);
    }
    let seal_key = borsh::to_vec(&(key,other.as_bytes())).unwrap();
    assert_eq!(legacy_kernel_job_alias_v2(TABLE_SEALS_V1, &seal_key, &[]), Some(job));
    let claim_prefix = borsh::to_vec(&(other.as_bytes(),other.as_bytes(),key)).unwrap();
    assert_eq!(legacy_kernel_job_alias_v2(TABLE_CLAIMS_V1, &other.as_bytes(), &claim_prefix), Some(job));
    assert_eq!(legacy_kernel_job_alias_v2(TABLE_CLAIMS_V1, &key, &claim_prefix[..191]), None);
}
'''
(root/'probe.rs').write_text(probe)
target=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug/deps')
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
args=[str(rustc),'--edition=2024','--test','-L',f'dependency={target}']
for name,suffix in {'misaka_palw_positive_contract':'3c6e0f32d28c41f7','kaspa_hashes':'763ecc08d728f51f','borsh':'c57124d88bb5020f'}.items():
    args.extend(['--extern',f'{name}={target}/lib{name}-{suffix}.rlib'])
subprocess.run([*args,str(root/'probe.rs'),'-o',str(root/'probe')],check=True)
subprocess.run([str(root/'probe')],check=True)
