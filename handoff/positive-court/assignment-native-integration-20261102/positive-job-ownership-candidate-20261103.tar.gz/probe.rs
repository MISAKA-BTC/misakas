use std::collections::{BTreeMap, BTreeSet};
use kaspa_hashes::Hash64;
use misaka_palw_positive_contract::{identity::*, messages::MinerResultCommit, native::{KERNEL_AUX_TABLE, ruleset_id}, rows::*};
extern crate self as misaka_palw_kernel;
mod rows { pub const TABLE_JOBS_V1: u8 = 4;
pub const TABLE_PIPELINE_JOBS_V1: u8 = 5;
pub const TABLE_CLAIMS_V1: u8 = 6;
pub const TABLE_JOB_CLAIMS_V1: u8 = 10;
pub const TABLE_SEALS_V1: u8 = 11;
pub const TABLE_JOB_ESCROWS_V1: u8 = 16; }
#[derive(Default)]
struct PalwKernelRouteStateV1 {
    aux: BTreeMap<(u8, Vec<u8>), Vec<u8>>,
    positive_job_results_v2: BTreeSet<(Hash64, Hash64)>,
}
pub(crate) fn is_positive_result_row_v2(table: u8, key: &[u8]) -> bool {
    table == misaka_palw_positive_contract::native::KERNEL_AUX_TABLE && key.get(4) == Some(&0)
}

fn positive_job_result_v2(result: &misaka_palw_positive_contract::rows::ResultRow) -> (Hash64, Hash64) {
    (Hash64::from_bytes(result.result.job.0), Hash64::from_bytes(result.result.id().0.0))
}

impl PalwKernelRouteStateV1 {
    pub(crate) fn contains_positive_job_v2(&self, job: Hash64) -> bool {
        self.positive_job_results_v2
            .range((job, Hash64::default())..=(job, Hash64::from_bytes([u8::MAX; 64])))
            .next()
            .is_some()
    }

    pub(crate) fn update_positive_job_index_v2(
        &mut self,
        key: &(u8, Vec<u8>),
        next: Option<&[u8]>,
    ) -> Result<(), misaka_palw_positive_contract::ContractError> {
        use misaka_palw_positive_contract::{
            ContractError,
            rows::{NativeRowBody, NativeRowValue},
        };

        if !is_positive_result_row_v2(key.0, &key.1) {
            return Ok(());
        }
        let previous = self.aux.get(key).map(Vec::as_slice);
        if previous == next {
            return Ok(());
        }
        let decode = |bytes: &[u8]| {
            let NativeRowBody::Result(row) = NativeRowValue::decode(&key.1, bytes)?.body else {
                return Err(ContractError::Identity);
            };
            Ok(positive_job_result_v2(&row))
        };
        let previous = previous.map(decode).transpose()?;
        let next = next.map(decode).transpose()?;
        if previous != next {
            if let Some(previous) = previous {
                self.positive_job_results_v2.remove(&previous);
            }
            if let Some(next) = next {
                self.positive_job_results_v2.insert(next);
            }
        }
        Ok(())
    }
}

fn legacy_kernel_job_alias_v2(table: u8, key: &[u8], value: &[u8]) -> Option<Hash64> {
    use misaka_palw_kernel::rows::{
        TABLE_CLAIMS_V1, TABLE_JOB_CLAIMS_V1, TABLE_JOB_ESCROWS_V1, TABLE_JOBS_V1, TABLE_PIPELINE_JOBS_V1, TABLE_SEALS_V1,
    };
    let subject = match table {
        TABLE_JOBS_V1 | TABLE_PIPELINE_JOBS_V1 | TABLE_JOB_CLAIMS_V1 | TABLE_JOB_ESCROWS_V1 => key,
        TABLE_SEALS_V1 => key.get(..64)?,
        // ClaimRowV1 begins with producer, class_binding_id and job_id,
        // three fixed 64-byte digests preceding the variable-sized body.
        TABLE_CLAIMS_V1 => value.get(128..192)?,
        _ => return None,
    };
    subject.try_into().ok().map(Hash64::from_bytes)
}


fn make_result(output: u8) -> NativeRowValue {
    let mut result: MinerResultCommit = borsh::from_slice(include_bytes!("result-vector.bin")).unwrap();
    let key = [0; PUBKEY_BYTES];
    let policy = Digest([14; 64]);
    let fired = Digest([15; 64]);
    result.scope.ruleset = ruleset_id(fired, policy);
    result.miner = principal(&key);
    result.output = Digest([output; 64]);
    let origin = AcceptedOrigin {
        accepting_block: NativeHash64([1; 64]), carrier_block: NativeHash64([2; 64]), carrier_transaction: NativeHash64([3; 64]),
        accepted_tx_ordinal: 4, event_ordinal: 5, accepted_daa: 6, accepted_blue_score: 7,
    };
    let dependencies = AcceptedMaterial { origin, digest: result.dependencies };
    NativeRowValue::new(NativeRowBody::Result(ResultRow {
        result, miner_key: key, miner_signature: [0; SIGNATURE_BYTES], origin, policy, fired_fork: fired,
        funding_scope: FundingScopeId(Digest([16; 64])), dependencies, role_assignment: dependencies,
    })).unwrap()
}
#[test]
fn exact_projection_preserves_job_on_partial_revert_and_rejects_wrong_row() {
    let one = make_result(43);
    let two = make_result(44);
    let NativeRowBody::Result(result) = &one.body else { panic!() };
    let job = Hash64::from_bytes(result.result.job.0);
    let one_key = (KERNEL_AUX_TABLE, one.body.key().encode());
    let two_key = (KERNEL_AUX_TABLE, two.body.key().encode());
    let one_bytes = one.encode().unwrap();
    let two_bytes = two.encode().unwrap();
    let mut state = PalwKernelRouteStateV1::default();
    assert!(state.update_positive_job_index_v2(&one_key, Some(&two_bytes)).is_err());
    assert!(!state.contains_positive_job_v2(job));
    for (key, bytes) in [(one_key.clone(),one_bytes),(two_key.clone(),two_bytes)] {
        state.update_positive_job_index_v2(&key, Some(&bytes)).unwrap();
        state.aux.insert(key,bytes);
        assert!(state.contains_positive_job_v2(job));
    }
    assert!(!state.contains_positive_job_v2(Hash64::from_bytes([222;64])));
    for (key, expected) in [(two_key,true),(one_key,false)] {
        state.update_positive_job_index_v2(&key,None).unwrap();
        state.aux.remove(&key);
        assert_eq!(state.contains_positive_job_v2(job),expected);
    }
}
#[test]
fn exact_kernel_job_subjects_match_canonical_row_prefixes() {
    use rows::*;
    let job = Hash64::from_bytes([17;64]);
    let other = Hash64::from_bytes([18;64]);
    let key = job.as_bytes();
    for table in [TABLE_JOBS_V1, TABLE_PIPELINE_JOBS_V1, TABLE_JOB_CLAIMS_V1, TABLE_JOB_ESCROWS_V1] {
        assert_eq!(legacy_kernel_job_alias_v2(table, &key, &[]), Some(job));
        assert_eq!(legacy_kernel_job_alias_v2(table, &key[..63], &[]), None);
    }
    let seal_key = borsh::to_vec(&(key,other.as_bytes())).unwrap();
    assert_eq!(legacy_kernel_job_alias_v2(TABLE_SEALS_V1, &seal_key, &[]), Some(job));
    let claim_prefix = borsh::to_vec(&(other.as_bytes(),other.as_bytes(),key)).unwrap();
    assert_eq!(legacy_kernel_job_alias_v2(TABLE_CLAIMS_V1, &other.as_bytes(), &claim_prefix), Some(job));
    assert_eq!(legacy_kernel_job_alias_v2(TABLE_CLAIMS_V1, &key, &claim_prefix[..191]), None);
}
