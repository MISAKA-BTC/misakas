from pathlib import Path
root = Path(__file__).resolve().parent / 'consensus/core/src'

def edit(path, old, new):
    p = root/path
    s = p.read_text()
    assert s.count(old)==1,(path,old,s.count(old))
    p.write_text(s.replace(old,new))

edit('palw_state_v2/positive_assignment_case.rs',
'''    /// A rooted Positive claim index owns this claim identity. Check at the''',
'''    pub(super) fn reject_positive_job_alias_v2(&self, job: Hash64) -> Result<(), PalwStateV2Error> {
        if self.state.kernel_route.as_ref().is_some_and(|route| route.contains_positive_job_v2(job)) {
            return Err(refuse("legacy ingress overlaps a rooted Positive job"));
        }
        Ok(())
    }

    /// A rooted Positive claim index owns this claim identity. Check at the''')
edit('palw_state_v2/positive_assignment.rs',
'''        super::positive_assignment_case::reject_legacy_aliases(&self.state, expected, &plan.result.result)?;
''','''        super::positive_assignment_case::reject_legacy_aliases(&self.state, expected, &plan.result.result)?;
        let job = Hash64::from_bytes(plan.result.result.job.0);
        if self.state.kernel_route.as_ref().is_some_and(|route| route.contains_positive_job_v2(job)) {
            return Err(refusal("Positive job already owns a Result at this prefix"));
        }
''')
edit('palw_state_v2/transition_builder.rs',
'''        if new.is_some() {
            self.reject_positive_claim_alias_v2(key)?;
        }''','''        if let Some(claim) = &new {
            self.reject_positive_claim_alias_v2(key)?;
            self.reject_positive_job_alias_v2(claim.job_identity)?;
        }''')
edit('palw_staged_court_fold_v1.rs',
'''            self.reject_positive_claim_alias_v2(subject)?;
''','''            self.reject_positive_claim_alias_v2(subject)?;
            self.reject_positive_job_alias_v2(subject)?;
''')
edit('palw_kernel_route_fold_v1.rs',
'''impl TransitionBuilder<'_> {
    /// **The one writer of the kernel route's rows**''',
'''fn legacy_kernel_job_alias_v2(table: u8, key: &[u8], value: &[u8]) -> Option<Hash64> {
    use misaka_palw_kernel::rows::{
        TABLE_CLAIMS_V1, TABLE_JOB_CLAIMS_V1, TABLE_JOB_ESCROWS_V1, TABLE_JOBS_V1, TABLE_PIPELINE_JOBS_V1, TABLE_SEALS_V1,
    };
    let subject = match table {
        TABLE_JOBS_V1 | TABLE_PIPELINE_JOBS_V1 | TABLE_JOB_CLAIMS_V1 | TABLE_JOB_ESCROWS_V1 => key,
        TABLE_SEALS_V1 => key.get(..64)?,
        // ClaimRowV1 begins with producer, class_binding_id and job_id,
        // three fixed 64-byte digests preceding the variable-sized body.
        TABLE_CLAIMS_V1 => value.get(128..192)?,
        _ => return None,
    };
    subject.try_into().ok().map(Hash64::from_bytes)
}

impl TransitionBuilder<'_> {
    /// **The one writer of the kernel route's rows**''')
edit('palw_kernel_route_fold_v1.rs',
'''        if let Some(value) = new.as_deref()
            && let Some(claim) = legacy_kernel_claim_alias_v2(table, &key, value)
        {
            self.reject_positive_claim_alias_v2(claim)?;
        }''','''        if let Some(value) = new.as_deref() {
            if let Some(claim) = legacy_kernel_claim_alias_v2(table, &key, value) {
                self.reject_positive_claim_alias_v2(claim)?;
            }
            if let Some(job) = legacy_kernel_job_alias_v2(table, &key, value) {
                self.reject_positive_job_alias_v2(job)?;
            }
        }''')
edit('palw_positive_rows_v2/tests.rs',
'''#[test]
fn fixed_enum_memory_is_charged_per_short_row_and_exact_limits_are_enforced()''',
'''#[test]
fn positive_job_projection_tracks_result_install_remove_and_cold_decode() {
    use crate::Hash64;
    use misaka_palw_positive_contract::native::KERNEL_AUX_TABLE;
    let (_, result, ..) = signed_bundle();
    let job = Hash64::from_bytes(result.result.job.0);
    let value = NativeRowValue::new(NativeRowBody::Result(result)).unwrap();
    let key = (KERNEL_AUX_TABLE, value.body.key().encode());
    let bytes = value.encode().unwrap();
    let mut route = empty_route();
    let original = borsh::to_vec(&route).unwrap();
    assert!(!route.contains_positive_job_v2(job));
    assert!(route.update_positive_job_index_v2(&key, Some(&[0])).is_err());
    assert!(!route.contains_positive_job_v2(job));

    route.update_positive_job_index_v2(&key, Some(&bytes)).unwrap();
    route.aux.insert(key.clone(), bytes.clone());
    assert!(route.contains_positive_job_v2(job));
    assert!(!route.contains_positive_job_v2(Hash64::from_bytes([u8::MAX; 64])));
    let committed = borsh::to_vec(&route).unwrap();
    let mut restored: crate::palw_kernel_route_v1::PalwKernelRouteStateV1 = borsh::from_slice(&committed).unwrap();
    assert!(restored.contains_positive_job_v2(job));
    assert_eq!(restored.aux_root(), route.aux_root());
    restored.update_positive_job_index_v2(&key, None).unwrap();
    restored.aux.remove(&key);
    assert!(!restored.contains_positive_job_v2(job));
    assert_eq!(borsh::to_vec(&restored).unwrap(), original);
}

#[test]
fn fixed_enum_memory_is_charged_per_short_row_and_exact_limits_are_enforced()''')
