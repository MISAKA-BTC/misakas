from pathlib import Path
root = Path(__file__).resolve().parent / 'consensus/core/src'

def transform(path, pairs):
    p=root/path
    content=p.read_text()
    for old,new,expected in pairs:
        assert content.count(old)==expected,(path,old,content.count(old),expected)
        content=content.replace(old,new)
    p.write_text(content)

route='palw_kernel_route_v1.rs'
field='    pub aux: BTreeMap<(u8, Vec<u8>), Vec<u8>>,\n'
transform(route,[
    (field, field+'''    /// Derived from canonical Result rows on write and restore. The canonical
    /// aux rows alone are serialized and hashed.
    #[borsh(skip)]
    pub(crate) positive_job_results_v2: std::collections::BTreeSet<(Hash64, Hash64)>,
''',1),
    ('        let mut aux = BTreeMap::new();\n','        let mut aux = BTreeMap::new();\n        let mut positive_job_results_v2 = std::collections::BTreeSet::new();\n',1),
    ('''                misaka_palw_positive_contract::rows::NativeRowValue::decode(&key, &value)
                    .map_err(|_| std::io::Error::new(std::io::ErrorKind::InvalidData, "Positive aux key/value mismatch"))?;
''','''                let row = misaka_palw_positive_contract::rows::NativeRowValue::decode(&key, &value)
                    .map_err(|_| std::io::Error::new(std::io::ErrorKind::InvalidData, "Positive aux key/value mismatch"))?;
                if let misaka_palw_positive_contract::rows::NativeRowBody::Result(result) = row.body {
                    positive_job_results_v2.insert(positive_job_result_v2(&result));
                }
''',1),
    ('Ok(Self { header, rows, aux, ledger_cache: KernelLedgerCacheV1::default() })',
     'Ok(Self { header, rows, aux, positive_job_results_v2, ledger_cache: KernelLedgerCacheV1::default() })',1),
    ('aux: BTreeMap::new(), ledger_cache: KernelLedgerCacheV1::default()',
     'aux: BTreeMap::new(), positive_job_results_v2: Default::default(), ledger_cache: KernelLedgerCacheV1::default()',2),
    ('            aux: BTreeMap::new(),\n','            aux: BTreeMap::new(),\n            positive_job_results_v2: Default::default(),\n',1),
    ('                route.aux.insert((table, key), row).is_some()',
     '''                let key = (table, key);
                route.update_positive_job_index_v2(&key, Some(&row)).map_err(|error| format!("invalid Positive Result row: {error:?}"))?;
                route.aux.insert(key, row).is_some()''',1),
    ('impl BorshDeserialize for PalwKernelRouteStateV1 {','''/// Result is the first key kind in the frozen aux151 wire namespace.
pub(crate) fn is_positive_result_row_v2(table: u8, key: &[u8]) -> bool {
    table == misaka_palw_positive_contract::native::KERNEL_AUX_TABLE && key.get(4) == Some(&0)
}

fn positive_job_result_v2(result: &misaka_palw_positive_contract::rows::ResultRow) -> (Hash64, Hash64) {
    (Hash64::from_bytes(result.result.job.0), Hash64::from_bytes(result.result.id().0.0))
}

impl PalwKernelRouteStateV1 {
    pub(crate) fn contains_positive_job_v2(&self, job: Hash64) -> bool {
        self.positive_job_results_v2
            .range((job, Hash64::default())..=(job, Hash64::from_bytes([u8::MAX; 64])))
            .next()
            .is_some()
    }

    pub(crate) fn update_positive_job_index_v2(
        &mut self,
        key: &(u8, Vec<u8>),
        next: Option<&[u8]>,
    ) -> Result<(), misaka_palw_positive_contract::ContractError> {
        use misaka_palw_positive_contract::{
            ContractError,
            rows::{NativeRowBody, NativeRowValue},
        };

        if !is_positive_result_row_v2(key.0, &key.1) {
            return Ok(());
        }
        let previous = self.aux.get(key).map(Vec::as_slice);
        if previous == next {
            return Ok(());
        }
        let decode = |bytes: &[u8]| {
            let NativeRowBody::Result(row) = NativeRowValue::decode(&key.1, bytes)?.body else {
                return Err(ContractError::Identity);
            };
            Ok(positive_job_result_v2(&row))
        };
        let previous = previous.map(decode).transpose()?;
        let next = next.map(decode).transpose()?;
        if previous != next {
            if let Some(previous) = previous {
                self.positive_job_results_v2.remove(&previous);
            }
            if let Some(next) = next {
                self.positive_job_results_v2.insert(next);
            }
        }
        Ok(())
    }
}

impl BorshDeserialize for PalwKernelRouteStateV1 {''',1),
])

transform('palw_state_v2.rs',[
    ('''    let map = if ledger_table { &mut kernel.rows } else { &mut kernel.aux };
    let k = (table, key.to_vec());
    if map.get(&k) != expected.as_ref() {
        return Err(PalwStateV2Error::DeltaMismatch("a kernel route row does not match the delta's expectation"));
    }
    match install''','''    let k = (table, key.to_vec());
    let actual = if ledger_table { kernel.rows.get(&k) } else { kernel.aux.get(&k) };
    if actual != expected.as_ref() {
        return Err(PalwStateV2Error::DeltaMismatch("a kernel route row does not match the delta's expectation"));
    }
    kernel
        .update_positive_job_index_v2(&k, install.as_deref())
        .map_err(|_| PalwStateV2Error::DeltaMismatch("a Positive Result row does not match its canonical key"))?;
    let map = if ledger_table { &mut kernel.rows } else { &mut kernel.aux };
    match install''',1),
])

transform('palw_kernel_route_fold_v1.rs',[
    ('''        let ledger_table = table < PALW_KERNEL_ROUTE_TABLE_BOND_KEYS_V1;
        if ledger_table {''','''        let map_key = (table, key);
        kernel
            .update_positive_job_index_v2(&map_key, new.as_deref())
            .map_err(|error| PalwStateV2Error::KernelRouteRefused(format!("invalid Positive Result row: {error:?}")))?;
        let ledger_table = table < PALW_KERNEL_ROUTE_TABLE_BOND_KEYS_V1;
        if ledger_table {''',1),
    ('''            Some(bytes) => map.insert((table, key.clone()), bytes.clone()),
            None => map.remove(&(table, key.clone())),''',
     '''            Some(bytes) => map.insert(map_key.clone(), bytes.clone()),
            None => map.remove(&map_key),''',1),
    ('''self.entries.push(PalwDeltaEntryV2::KernelRouteRow { table, key, old, new });''',
     '''self.entries.push(PalwDeltaEntryV2::KernelRouteRow { table, key: map_key.1, old, new });''',1),
])

transform('palw_native_resource_v1/positive_rows.rs',[
    ('let Self { header, rows, aux, ledger_cache } = self;',
     'let Self { header, rows, aux, ledger_cache, positive_job_results_v2 } = self;',3),
    ('        sum.add::<Self>(positive_aux_coverage_v1(aux, path).1, path)',
     '        sum = sum.add::<Self>(positive_job_results_v2.native_heap_v1(path), path);\n        sum.add::<Self>(positive_aux_coverage_v1(aux, path).1, path)',1),
    ('            .checked_add(ledger_cache.native_members_v1()?)',
     '            .checked_add(ledger_cache.native_members_v1()?)?\n            .checked_add(positive_job_results_v2.native_members_v1()?)',1),
    ('            super::NativeFieldInventoryV1::of("PalwKernelRouteStateV1.ledger_cache", ledger_cache),',
     '            super::NativeFieldInventoryV1::of("PalwKernelRouteStateV1.ledger_cache", ledger_cache),\n            super::NativeFieldInventoryV1::of("PalwKernelRouteStateV1.positive_job_results_v2", positive_job_results_v2),',1),
])

transform('palw_native_resource_v1/wire_kernel_aux.rs',[
    ('        misaka_palw_positive_contract::native::KERNEL_AUX_TABLE => super::positive_rows::scan_positive_aux_row_v1(key, frame)?,',
     '''        misaka_palw_positive_contract::native::KERNEL_AUX_TABLE => {
            let shape = super::positive_rows::scan_positive_aux_row_v1(key, frame)?;
            shape.allocation(
                u64::from(crate::palw_kernel_route_v1::is_positive_result_row_v2(table, key)),
                size_of::<typed::BTreeNodeEnvelopeV1<(kaspa_hashes::Hash64, kaspa_hashes::Hash64), ()>>(),
            )?
        }''',1),
])

transform('palw_state_v2/native_writers.rs',[
    ('        if retained_caller_buffers {\n', '''        q.member_if::<(Hash64, Hash64), ()>(new.is_some() && crate::palw_kernel_route_v1::is_positive_result_row_v2(table, key))?;
        if retained_caller_buffers {
''',1),
])
transform('palw_state_v2.rs',[
    ('''                        .collect(),
                    ledger_cache: Default::default(),''','''                        .collect(),
                    positive_job_results_v2: route.positive_job_results_v2.clone(),
                    ledger_cache: Default::default(),''',1),
])
