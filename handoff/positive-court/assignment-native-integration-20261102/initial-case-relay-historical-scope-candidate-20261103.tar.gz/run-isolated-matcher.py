import json, os, subprocess
from pathlib import Path

root = Path.cwd()
scratch = Path(__file__).resolve().parent
source = (scratch / 'consensus/core/src/palw_positive_assignment_funds_v2.rs').read_text()
matcher = source[source.index('pub fn check_initial_assignment_relay_target_v2'):source.index("/// Reads the carrier's own output")]
test = (scratch / 'consensus/core/tests/positive_assignment_funds_v2.rs').read_text()
fixture = root / 'misaka/palw/positive-contract/tests/support/assignment.rs'
test = test.replace('../../../misaka/palw/positive-contract/tests/support/assignment.rs', str(fixture))
test += '\nuse misaka_palw_positive_contract::{ContractError, assignment::AssignmentAdmissionBundleV2};\n' + matcher
driver = scratch / 'matcher-test.rs'
driver.write_text(test)
target = Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
fingerprints = target / '.fingerprint'
core = '89f0de62c5709f13'
fp = json.loads((fingerprints / f'kaspa-consensus-core-{core}/lib-kaspa_consensus_core.json').read_text())
rustc = Path.home() / '.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
exe = scratch / 'matcher-test'
cmd = [str(rustc), '--edition=2024', '--test', '-L', f'dependency={target / "deps"}', '--extern',
       f'kaspa_consensus_core={target / "deps" / f"libkaspa_consensus_core-{core}.rlib"}']
for name in ('misaka_palw_positive_contract', 'kaspa_hashes'):
    _, _, _, fingerprint = next(entry for entry in fp['deps'] if entry[1] == name)
    marker, = (item for item in fingerprints.glob('*/lib-' + name) if item.read_text() == fingerprint.to_bytes(8, 'little').hex())
    suffix = marker.parent.name.rsplit('-', 1)[-1]
    cmd += ['--extern', f'{name}={target / "deps" / f"lib{name}-{suffix}.rlib"}']
for native in (target / 'build').glob('*/out'):
    cmd += ['-L', f'native={native}']
subprocess.run([*cmd, str(driver), '-o', str(exe)], check=True)
subprocess.run([str(exe), '--exact', 'initial_case_relay_binds_the_exact_result_consent_and_case_coin'], check=True)
