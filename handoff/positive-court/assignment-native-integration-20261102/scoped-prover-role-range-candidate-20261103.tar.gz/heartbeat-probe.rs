use kaspa_consensus_core::{
    Hash64,
    config::params::{PALW_T12_G14_17000_FENCES_V1, palw_t12_arm_after_int13_at_v1, palw_t12_launch_params_v1},
    palw_kernel_route_v1::PalwKernelRouteExtrasV1,
    palw_mode_v2::PalwConsensusMode,
    palw_native_resource_v1::{NativeSnapshotResourceLimitsV1, arm_native_logical_limits_v1},
    palw_state_v2::{
        PalwBlockContextV2, PalwChainStateV2, PalwStateCarriageV2, PalwTransitionExtrasV1,
        apply_palw_transition_retained_v2_with_extras, palw_v2_pre_object_base_retained_v1,
    },
};

fn main() {
    let mut config = palw_t12_launch_params_v1();
    palw_t12_arm_after_int13_at_v1(&mut config, PALW_T12_G14_17000_FENCES_V1, None);
    config.evm_activation_daa_score = u64::MAX;
    config.palw_model_evm = None;
    config.palw_execution_lane = None;
    config.palw_dns_retirement = None;
    assert!(config.arm_palw_opv_mechanics_budget_v1());
    config.sync_palw_bond_budget_v1();
    let PalwConsensusMode::ConsensusV2(bundle) = &config.palw_consensus_mode else { panic!("testnet-12 mode") };
    let extras = PalwTransitionExtrasV1 {
        kernel_route: Some(PalwKernelRouteExtrasV1 {
            chain_genesis: config.genesis.hash,
            network_domain: Hash64::from_u64_word(78),
            ruleset_digest: Hash64::from_u64_word(79),
            ..Default::default()
        }),
        ..Default::default()
    };
    let point = PalwBlockContextV2 { block: config.genesis.hash, daa_score: 0, blue_score: 0, subsidy: 0 };
    let (genesis, _) = apply_palw_transition_retained_v2_with_extras(
        &PalwChainStateV2::genesis(), &bundle.state, &point, &bundle.genesis_objects, None,
        false, false, false, false, &extras,
    ).unwrap();
    let parent = (*genesis).clone();
    let pass = |tracked: bool, cold: bool| -> Vec<_> {
        let mut state = parent.clone();
        (1..=12).map(|daa| {
            if cold {
                state = PalwStateCarriageV2::from_state(&state).into_state(&bundle.state, Some(state.state_root())).unwrap();
            }
            let point = PalwBlockContextV2 {
                block: Hash64::from_u64_word(daa), daa_score: daa, blue_score: daa, subsidy: 0,
            };
            palw_v2_pre_object_base_retained_v1(&state, &bundle.state, &point, false, false, false, false, &extras)
                .unwrap_or_else(|error| panic!("pre-object DAA {daa}, tracked {tracked}, cold {cold}: {error:?}"));
            let (next, delta) = apply_palw_transition_retained_v2_with_extras(
                &state, &bundle.state, &point, &[], None, false, false, false, false, &extras,
            ).unwrap_or_else(|error| panic!("fold DAA {daa}, tracked {tracked}, cold {cold}: {error:?}"));
            state = (*next).clone();
            (state.state_root(), (*delta).clone())
        }).collect()
    };
    let baseline = pass(false, false);
    assert!(baseline == pass(false, true), "cold unmetered fold matches warm");
    let limit = 16u64 << 30;
    arm_native_logical_limits_v1(Some(NativeSnapshotResourceLimitsV1 { memory_bytes: limit, database_bytes: limit }));
    assert!(baseline == pass(true, false), "metered warm fold matches unmetered");
    assert!(baseline == pass(true, true), "metered cold fold matches unmetered");
    println!("12 testnet-12 Core folds matched pre/post metering and cold/warm carriage");
}
