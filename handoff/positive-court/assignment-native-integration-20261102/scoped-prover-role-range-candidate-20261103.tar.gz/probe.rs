fn assigned_prover_rows_v2(
    aux: &std::collections::BTreeMap<(u8, Vec<u8>), Vec<u8>>,
    prefix: Vec<u8>,
) -> impl Iterator<Item = (&[u8], &[u8])> {
    use misaka_palw_positive_contract::native::KERNEL_AUX_TABLE;

    aux.range((KERNEL_AUX_TABLE, prefix.clone())..)
        .take_while(move |((table, key), _)| *table == KERNEL_AUX_TABLE && key.starts_with(&prefix))
        .map(|((_, key), bytes)| (key.as_slice(), bytes.as_slice()))
}


use std::collections::BTreeMap;
use misaka_palw_positive_contract::{
    assignment::{AssignmentId, AssignmentRoleV2}, identity::Digest,
    native::{KERNEL_AUX_TABLE, NativeRowKey}, rows::{NativeHash64, NativeOutpoint},
};
fn role(assignment:u8, role:AssignmentRoleV2, bond:u8)->Vec<u8> {
    NativeRowKey::AssignmentRole {
        assignment:AssignmentId(Digest([assignment;64])),
        role,
        bond:NativeOutpoint {transaction:NativeHash64([bond;64]),index:u32::from(bond)},
    }.encode()
}
#[test]
fn assigned_prover_range_uses_exact_assignment_and_role_prefix() {
    use AssignmentRoleV2::*;
    let first=role(40,Prover,0);
    let last=role(40,Prover,255);
    let mut prefix=first.clone();
    prefix.truncate(prefix.len()-(64+4));
    let mut aux=BTreeMap::from([
        ((KERNEL_AUX_TABLE-1,first.clone()), vec![3]),
        ((KERNEL_AUX_TABLE,role(40,Poster,1)), vec![3]),
        ((KERNEL_AUX_TABLE,role(40,Worker,1)), vec![3]),
        ((KERNEL_AUX_TABLE,role(39,Prover,255)), vec![3]),
        ((KERNEL_AUX_TABLE,role(41,Prover,0)), vec![3]),
        ((KERNEL_AUX_TABLE+1,last.clone()), vec![3]),
        ((KERNEL_AUX_TABLE,first.clone()), vec![7]),
        ((KERNEL_AUX_TABLE,last.clone()), vec![8]),
    ]);
    assert_eq!(assigned_prover_rows_v2(&aux,prefix.clone()).collect::<Vec<_>>(),
               vec![(first.as_slice(), &[7][..]),(last.as_slice(), &[8][..])]);
    aux.insert((KERNEL_AUX_TABLE,prefix.clone()), vec![0]);
    assert_eq!(assigned_prover_rows_v2(&aux,prefix.clone()).next(),Some((prefix.as_slice(),&[0][..])));
}
