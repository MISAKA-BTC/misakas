from pathlib import Path

p=Path(__file__).resolve().parent/'consensus/core/src/palw_state_v2/positive_assignment_case.rs'
s=p.read_text()
old='''    use misaka_palw_positive_contract::rows::NativeRowValue;
    let route = state.kernel_route_state_v1().ok_or_else(missing)?;
    let mut resolved = None;
    let mut count = 0u32;
    for ((table, key), bytes) in &route.aux {
        if *table != misaka_palw_positive_contract::native::KERNEL_AUX_TABLE || key.get(4) != Some(&15) {
            continue;
        }
        let value = NativeRowValue::decode(key, bytes).map_err(refuse)?;
        let NativeRowBody::AssignmentRole(role) = value.body else {
            return Err(refuse("role key/value"));
        };
        if role.assignment != a.id() || role.role != AssignmentRoleV2::Prover {
            continue;
        }
        count = count.checked_add(1).ok_or_else(|| refuse("role count overflow"))?;
        if count > material.assignment_policy.max_role_candidates {
            return Err(refuse("bounded native role candidates"));
        }'''
new='''    use misaka_palw_positive_contract::rows::NativeRowValue;

    let route = state.kernel_route_state_v1().ok_or_else(missing)?;
    let assignment = a.id();
    let mut resolved = None;
    let mut count = 0u32;
    let mut requests = TirNativeRequestsV1::new();
    requests.exact_v1::<u8>(1024).map_err(PalwStateV2Error::NativeResource)?;
    requests.exact_v1::<u8>(misaka_palw_positive_contract::rows::MAX_NATIVE_KEY_BYTES as u64)
        .map_err(PalwStateV2Error::NativeResource)?;
    let _range_owner = reserve_native_requests_v1(requests.bytes_v1()).map_err(PalwStateV2Error::NativeResource)?.ok_or_else(|| {
        PalwStateV2Error::NativeResource(NativeCoverageV1::unsupported::<NativeRowKey>(
            "assigned Case prover role range", "actual checker is not armed",
        ))
    })?;
    let mut prefix = NativeRowKey::AssignmentRole { assignment, role: AssignmentRoleV2::Prover, bond: a.bundle.terms.prover }.encode();
    // The canonical last field is the outpoint (64-byte txid and u32 index).
    // Keep AssignmentId AND role in the prefix before entering the ordered map.
    prefix.truncate(prefix.len() - (64 + 4));
    for (key, bytes) in assigned_prover_rows_v2(&route.aux, prefix) {
        count = count.checked_add(1).ok_or_else(|| refuse("role count overflow"))?;
        if count > material.assignment_policy.max_role_candidates {
            return Err(refuse("bounded native role candidates"));
        }
        let value = NativeRowValue::decode(key, bytes).map_err(refuse)?;
        let NativeRowBody::AssignmentRole(role) = value.body else {
            return Err(refuse("role key/value"));
        };
        if role.assignment != assignment || role.role != AssignmentRoleV2::Prover {
            return Err(refuse("foreign native prover role key/value"));
        }'''
assert s.count(old)==1
s=s.replace(old,new)
old='''/// Resolve the literal original or accepted funded op13 role in the ACTUAL'''
new='''fn assigned_prover_rows_v2(
    aux: &std::collections::BTreeMap<(u8, Vec<u8>), Vec<u8>>,
    prefix: Vec<u8>,
) -> impl Iterator<Item = (&[u8], &[u8])> {
    use misaka_palw_positive_contract::native::KERNEL_AUX_TABLE;

    aux.range((KERNEL_AUX_TABLE, prefix.clone())..)
        .take_while(move |((table, key), _)| *table == KERNEL_AUX_TABLE && key.starts_with(&prefix))
        .map(|((_, key), bytes)| (key.as_slice(), bytes.as_slice()))
}

/// Resolve the literal original or accepted funded op13 role in the ACTUAL'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
