
extern crate self as misaka_palw_kernel;
mod rows { pub const TABLE_CLAIMS_V1: u8 = 6;
pub const TABLE_JOB_CLAIMS_V1: u8 = 10;
pub const TABLE_OPV_CLAIMS_V1: u8 = 14;
pub const TABLE_PROOF_SEALS_V1: u8 = 15; }
use kaspa_hashes::Hash64;
use misaka_palw_positive_contract::{identity::Digest, native::NativeRowKey};
use std::collections::BTreeMap;
#[derive(Debug)]
enum PalwStateV2Error { KernelRouteRefused, NativeResource(palw_native_resource_v1::NativeCoverageV1) }
fn refuse(_:impl std::fmt::Debug)->PalwStateV2Error { PalwStateV2Error::KernelRouteRefused }
mod palw_native_resource_v1 {
    #[derive(Debug)]
    pub struct NativeCoverageV1;
    impl NativeCoverageV1 {
        pub fn unsupported<T>(_:&str,_:&str)->Self { let _=core::marker::PhantomData::<T>; Self }
    }
    pub fn reserve_native_requests_v1(_:u64)->Result<Option<()>,NativeCoverageV1> { Ok(None) }
}
struct KernelRoute { aux:BTreeMap<(u8,Vec<u8>),Vec<u8>> }
struct State { kernel_route: Option<KernelRoute> }
struct TransitionBuilder<'a> { state:&'a State }
#[test]
fn canonical_positive_claim_key_blocks_only_its_exact_legacy_identity() {
    use misaka_palw_positive_contract::{identity::ClaimId,native::KERNEL_AUX_TABLE};
    let claim = Hash64::from_bytes([13; 64]);
    let other = Hash64::from_bytes([17; 64]);
    let key=NativeRowKey::ClaimIndex(ClaimId(Digest(claim.as_bytes()))).encode();
    let mut state=State{kernel_route:None};
    assert!(TransitionBuilder{state:&state}.reject_positive_claim_alias_v2(claim).is_ok());
    state.kernel_route=Some(KernelRoute{aux:BTreeMap::from([((KERNEL_AUX_TABLE-1,key.clone()),vec![1])])});
    assert!(TransitionBuilder{state:&state}.reject_positive_claim_alias_v2(claim).is_ok());
    state.kernel_route.as_mut().unwrap().aux.insert((KERNEL_AUX_TABLE,key),vec![1]);
    let builder=TransitionBuilder{state:&state};
    assert!(builder.reject_positive_claim_alias_v2(other).is_ok());
    for (table,key,value) in [
        (rows::TABLE_CLAIMS_V1,claim.as_bytes().to_vec(),vec![1]),
        (rows::TABLE_OPV_CLAIMS_V1,claim.as_bytes().to_vec(),vec![1]),
        (rows::TABLE_JOB_CLAIMS_V1,other.as_bytes().to_vec(),claim.as_bytes().to_vec()),
        (rows::TABLE_PROOF_SEALS_V1,[claim.as_bytes(),other.as_bytes()].concat(),vec![1]),
    ] {
        let matched=legacy_kernel_claim_alias_v2(table,&key,&value).unwrap();
        assert_eq!(matched,claim);
        assert!(matches!(builder.reject_positive_claim_alias_v2(matched),Err(PalwStateV2Error::KernelRouteRefused)));
    }
    assert!(legacy_kernel_claim_alias_v2(rows::TABLE_CLAIMS_V1,&[0],&[]).is_none());
}
fn legacy_kernel_claim_alias_v2(table: u8, key: &[u8], value: &[u8]) -> Option<Hash64> {
    use misaka_palw_kernel::rows::{TABLE_CLAIMS_V1, TABLE_JOB_CLAIMS_V1, TABLE_OPV_CLAIMS_V1, TABLE_PROOF_SEALS_V1};
    let subject = match table {
        TABLE_CLAIMS_V1 | TABLE_OPV_CLAIMS_V1 => key,
        TABLE_JOB_CLAIMS_V1 => value,
        TABLE_PROOF_SEALS_V1 => key.get(..64)?,
        _ => return None,
    };
    subject.try_into().ok().map(Hash64::from_bytes)
}

impl TransitionBuilder<'_> {
    /// A rooted Positive claim index owns this claim identity. Check at the
    /// legacy writer before it allocates or publishes a new row.
    fn reject_positive_claim_alias_v2(&self, claim: Hash64) -> Result<(), PalwStateV2Error> {
        use crate::palw_native_resource_v1::reserve_native_requests_v1;
        use misaka_palw_positive_contract::{CONTRACT_REVISION, CONTRACT_VERSION, identity::ClaimId, native::KERNEL_AUX_TABLE};

        let Some(route) = self.state.kernel_route.as_ref() else { return Ok(()) };
        if route.aux.range((KERNEL_AUX_TABLE, Vec::new())..(KERNEL_AUX_TABLE + 1, Vec::new())).next().is_none() {
            return Ok(());
        }
        let key = (CONTRACT_VERSION, CONTRACT_REVISION, NativeRowKey::ClaimIndex(ClaimId(Digest(claim.as_bytes()))));
        let len = borsh::object_length(&key).map_err(refuse)?;
        let _lease = reserve_native_requests_v1(len as u64).map_err(PalwStateV2Error::NativeResource)?;
        let mut encoded = Vec::new();
        encoded.try_reserve_exact(len).map_err(|_| {
            PalwStateV2Error::NativeResource(crate::palw_native_resource_v1::NativeCoverageV1::unsupported::<NativeRowKey>(
                "legacy claim alias key",
                "allocator refused the fixed key",
            ))
        })?;
        borsh::to_writer(&mut encoded, &key).map_err(refuse)?;
        if route.aux.contains_key(&(KERNEL_AUX_TABLE, encoded)) {
            return Err(refuse("legacy ingress overlaps a rooted Positive claim"));
        }
        Ok(())
    }
}

