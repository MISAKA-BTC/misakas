from pathlib import Path
base=Path(__file__).resolve().parent/'consensus/core/src'
def edit(path, old, new):
    p=base/path
    s=p.read_text()
    assert s.count(old)==1,(path,old)
    p.write_text(s.replace(old,new))

p='palw_state_v2/positive_assignment_case.rs'
edit(p, 'fn reject_legacy_aliases(state:', 'pub(super) fn reject_legacy_aliases(state:')
edit(p, '/// Exact native aliases must be absent in EVERY old entry surface.', '''impl TransitionBuilder<'_> {
    /// A rooted Positive claim index owns this claim identity. Check at the
    /// legacy writer before it allocates or publishes a new row.
    pub(super) fn reject_positive_claim_alias_v2(&self, claim: Hash64) -> Result<(), PalwStateV2Error> {
        use crate::palw_native_resource_v1::reserve_native_requests_v1;
        use misaka_palw_positive_contract::{
            CONTRACT_REVISION, CONTRACT_VERSION, identity::ClaimId, native::KERNEL_AUX_TABLE,
        };

        let Some(route) = self.state.kernel_route.as_ref() else { return Ok(()) };
        if route.aux.range((KERNEL_AUX_TABLE, Vec::new())..(KERNEL_AUX_TABLE + 1, Vec::new())).next().is_none() {
            return Ok(());
        }
        let key = (CONTRACT_VERSION, CONTRACT_REVISION, NativeRowKey::ClaimIndex(ClaimId(Digest(claim.as_bytes()))));
        let len = borsh::object_length(&key).map_err(refuse)?;
        let _lease = reserve_native_requests_v1(len as u64).map_err(PalwStateV2Error::NativeResource)?;
        let mut encoded = Vec::new();
        encoded.try_reserve_exact(len).map_err(|_| {
            PalwStateV2Error::NativeResource(crate::palw_native_resource_v1::NativeCoverageV1::unsupported::<NativeRowKey>(
                "legacy claim alias key", "allocator refused the fixed key",
            ))
        })?;
        borsh::to_writer(&mut encoded, &key).map_err(refuse)?;
        if route.aux.contains_key(&(KERNEL_AUX_TABLE, encoded)) {
            return Err(refuse("legacy ingress overlaps a rooted Positive claim"));
        }
        Ok(())
    }
}

/// Exact native aliases must be absent in EVERY old entry surface.''')
p='palw_state_v2/positive_assignment.rs'
edit(p, '''        plan.binding.check_result(&plan.result.result).map_err(refusal)?;
        validate_bundle(&plan.index, &plan.result, &plan.case, &plan.funding).map_err(refusal)?;''',
'''        plan.binding.check_result(&plan.result.result).map_err(refusal)?;
        validate_bundle(&plan.index, &plan.result, &plan.case, &plan.funding).map_err(refusal)?;
        super::positive_assignment_case::reject_legacy_aliases(&self.state, expected, &plan.result.result)?;''')
p='palw_state_v2/transition_builder.rs'
edit(p,'''    pub(super) fn write_claim(&mut self, key: Hash64, new: Option<PalwClaimStateV2>) -> Result<(), PalwStateV2Error> {
        if !self.state.claims''','''    pub(super) fn write_claim(&mut self, key: Hash64, new: Option<PalwClaimStateV2>) -> Result<(), PalwStateV2Error> {
        if new.is_some() {
            self.reject_positive_claim_alias_v2(key)?;
        }
        if !self.state.claims''')
p='palw_state_v2/funded_escrow.rs'
edit(p,'''    pub(super) fn install_funded_escrow_v1(&mut self, row: PalwFundedEscrowRowV1) -> Result<(), PalwStateV2Error> {
        if self.state''','''    pub(super) fn install_funded_escrow_v1(&mut self, row: PalwFundedEscrowRowV1) -> Result<(), PalwStateV2Error> {
        self.reject_positive_claim_alias_v2(row.claim)?;
        if self.state''')
p='palw_kernel_route_fold_v1.rs'
edit(p,'''        self.apply_kernel_row_v1(table, key, new);
        Ok(())
    }

    /// [`Self::write_kernel_row`]''','''        self.apply_kernel_row_v1(table, key, new)
    }

    /// [`Self::write_kernel_row`]''')
edit(p,'''        self.apply_kernel_row_v1(table, key, new);
        Ok(())
    }

    fn apply_kernel_row_v1(&mut self, table: u8, key: Vec<u8>, new: Option<Vec<u8>>) {
        let Some(kernel) = self.state.kernel_route.as_mut() else { return };''',
'''        self.apply_kernel_row_v1(table, key, new)
    }

    fn apply_kernel_row_v1(&mut self, table: u8, key: Vec<u8>, new: Option<Vec<u8>>) -> Result<(), PalwStateV2Error> {
        if let Some(value) = new.as_deref()
            && let Some(claim) = legacy_kernel_claim_alias_v2(table, &key, value)
        {
            self.reject_positive_claim_alias_v2(claim)?;
        }
        let Some(kernel) = self.state.kernel_route.as_mut() else { return Ok(()) };''')
edit(p,'''        if old != new {
            self.entries.push(PalwDeltaEntryV2::KernelRouteRow { table, key, old, new });
        }
    }

    /// **The one writer of the kernel route's header**''','''        if old != new {
            self.entries.push(PalwDeltaEntryV2::KernelRouteRow { table, key, old, new });
        }
        Ok(())
    }

    /// **The one writer of the kernel route's header**''')
anchor='impl TransitionBuilder<\'_> {\n    /// **The one writer of the kernel route\'s rows**'
edit(p,anchor,'''fn legacy_kernel_claim_alias_v2(table: u8, key: &[u8], value: &[u8]) -> Option<Hash64> {
    use misaka_palw_kernel::rows::{TABLE_CLAIMS_V1, TABLE_JOB_CLAIMS_V1, TABLE_OPV_CLAIMS_V1, TABLE_PROOF_SEALS_V1};
    let subject = match table {
        TABLE_CLAIMS_V1 | TABLE_OPV_CLAIMS_V1 => key,
        TABLE_JOB_CLAIMS_V1 => value,
        TABLE_PROOF_SEALS_V1 => key.get(..64)?,
        _ => return None,
    };
    subject.try_into().ok().map(Hash64::from_bytes)
}

'''+anchor)
