from pathlib import Path
import re
import subprocess

stage=Path(__file__).resolve().parent
repo=Path('/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet')
src=stage/'consensus/core/src'
fold=(src/'palw_kernel_route_fold_v1.rs').read_text()
case=(src/'palw_state_v2/positive_assignment_case.rs').read_text()
decl=(repo/'misaka/palw/kernel/src/rows.rs').read_text()
a=fold.index('fn legacy_kernel_claim_alias_v2')
b=fold.index("impl TransitionBuilder<'_>",a)
subjects=fold[a:b]
a=case.index("impl TransitionBuilder<'_> {\n    /// A rooted Positive")
b=case.index('/// Exact native aliases must be absent',a)
guard=case[a:b].replace('pub(super) fn reject_positive_claim_alias_v2','fn reject_positive_claim_alias_v2')
constants='\n'.join(re.findall(r'pub const TABLE_(?:CLAIMS|JOB_CLAIMS|OPV_CLAIMS|PROOF_SEALS)_V1: u8 = \d+;',decl))
parts='''
extern crate self as misaka_palw_kernel;
mod rows { '''+constants+''' }
use kaspa_hashes::Hash64;
use misaka_palw_positive_contract::{identity::Digest, native::NativeRowKey};
use std::collections::BTreeMap;
#[derive(Debug)]
enum PalwStateV2Error { KernelRouteRefused, NativeResource(palw_native_resource_v1::NativeCoverageV1) }
fn refuse(_:impl std::fmt::Debug)->PalwStateV2Error { PalwStateV2Error::KernelRouteRefused }
mod palw_native_resource_v1 {
    #[derive(Debug)]
    pub struct NativeCoverageV1;
    impl NativeCoverageV1 {
        pub fn unsupported<T>(_:&str,_:&str)->Self { let _=core::marker::PhantomData::<T>; Self }
    }
    pub fn reserve_native_requests_v1(_:u64)->Result<Option<()>,NativeCoverageV1> { Ok(None) }
}
struct KernelRoute { aux:BTreeMap<(u8,Vec<u8>),Vec<u8>> }
struct State { kernel_route: Option<KernelRoute> }
struct TransitionBuilder<'a> { state:&'a State }
#[test]
fn canonical_positive_claim_key_blocks_only_its_exact_legacy_identity() {
    use misaka_palw_positive_contract::{identity::ClaimId,native::KERNEL_AUX_TABLE};
    let claim = Hash64::from_bytes([13; 64]);
    let other = Hash64::from_bytes([17; 64]);
    let key=NativeRowKey::ClaimIndex(ClaimId(Digest(claim.as_bytes()))).encode();
    let mut state=State{kernel_route:None};
    assert!(TransitionBuilder{state:&state}.reject_positive_claim_alias_v2(claim).is_ok());
    state.kernel_route=Some(KernelRoute{aux:BTreeMap::from([((KERNEL_AUX_TABLE-1,key.clone()),vec![1])])});
    assert!(TransitionBuilder{state:&state}.reject_positive_claim_alias_v2(claim).is_ok());
    state.kernel_route.as_mut().unwrap().aux.insert((KERNEL_AUX_TABLE,key),vec![1]);
    let builder=TransitionBuilder{state:&state};
    assert!(builder.reject_positive_claim_alias_v2(other).is_ok());
    for (table,key,value) in [
        (rows::TABLE_CLAIMS_V1,claim.as_bytes().to_vec(),vec![1]),
        (rows::TABLE_OPV_CLAIMS_V1,claim.as_bytes().to_vec(),vec![1]),
        (rows::TABLE_JOB_CLAIMS_V1,other.as_bytes().to_vec(),claim.as_bytes().to_vec()),
        (rows::TABLE_PROOF_SEALS_V1,[claim.as_bytes(),other.as_bytes()].concat(),vec![1]),
    ] {
        let matched=legacy_kernel_claim_alias_v2(table,&key,&value).unwrap();
        assert_eq!(matched,claim);
        assert!(matches!(builder.reject_positive_claim_alias_v2(matched),Err(PalwStateV2Error::KernelRouteRefused)));
    }
    assert!(legacy_kernel_claim_alias_v2(rows::TABLE_CLAIMS_V1,&[0],&[]).is_none());
}
'''
probe=stage/'probe.rs'
probe.write_text(parts+subjects+guard)
target=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
libs={name: target/'deps'/f'lib{name}-{suffix}.rlib' for name,suffix in {
    'misaka_palw_positive_contract':'3c6e0f32d28c41f7',
    'kaspa_hashes':'763ecc08d728f51f',
    'borsh':'c57124d88bb5020f',
}.items()}
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
cmd=[str(rustc),'--edition=2024','--test','-L',f'dependency={target/"deps"}','-A','dead_code']
for name,lib in libs.items():
    cmd.extend(['--extern',f'{name}={lib}'])
binary=stage/'probe'
subprocess.run([*cmd,str(probe),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
