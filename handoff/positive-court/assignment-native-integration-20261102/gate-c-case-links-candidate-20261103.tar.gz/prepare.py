from pathlib import Path
base = Path(__file__).resolve().parent / 'consensus/core/src'
def replace(file, old, new):
    path = base / file
    source = path.read_text()
    assert source.count(old) == 1, (file, old)
    path.write_text(source.replace(old, new))

p = 'palw_positive_certification_v2.rs'
replace(p, 'pub fn positive_certification_policy_id_v2', '''/// Point lookup in the shared S/K/V/N/P table. Own the temporary key
/// before allocation; the returned bytes remain borrowed from rooted state.
pub(crate) fn positive_certification_row_bytes_v2(
    state: &PalwChainStateV2,
    subject: Digest,
) -> Result<Option<&[u8]>, crate::palw_native_resource_v1::NativeCoverageV1> {
    use crate::palw_native_resource_v1::{NativeCoverageV1, TirNativeRequestsV1, reserve_native_requests_v1};

    let Some(route) = state.kernel_route_state_v1() else { return Ok(None) };
    let mut requests = TirNativeRequestsV1::new();
    requests.exact_v1::<u8>(65)?;
    let _key_lease = reserve_native_requests_v1(requests.bytes_v1())?.ok_or_else(|| {
        NativeCoverageV1::unsupported::<Vec<u8>>("P row lookup", "actual checker is not armed")
    })?;
    let key = (POSITIVE_CERTIFICATION_TABLE_V2, positive_certification_key_v2(subject));
    Ok(route.aux.get(&key).map(Vec::as_slice))
}
pub fn positive_certification_policy_id_v2''')
replace(p, '/// Failure-only pure projection.', '''/// Only an exact Case can terminate its P subject. A different Result can
/// share the CaseId, since CaseId does not bind output.
pub(crate) fn positive_certification_case_live_v2(
    header: &PositiveCertificationHeaderV2,
    case: &CaseRow,
) -> Result<bool, ContractError> {
    use misaka_palw_positive_contract::messages::ClaimStatus;

    if case.case != header.case
        || case.result != header.result
        || case.coverage.scope != header.scope
        || case.liability != header.liability
    {
        return Err(ContractError::Identity);
    }
    Ok(!matches!(case.status, ClaimStatus::ClaimRefuted | ClaimStatus::Revoked | ClaimStatus::EndedUnverified))
}

/// Failure-only pure projection.''')
replace(p, '''    let route = state.kernel_route_state_v1().ok_or(PositivePSourceErrorV2::Unavailable)?;
    let bytes = route
        .aux
        .range((136, Vec::new())..(137, Vec::new()))
        .find(|((_, key), _)| key.as_slice() == rowkey)
        .map(|(_, bytes)| bytes)
        .ok_or(PositivePSourceErrorV2::Unavailable)?;
    let shape =
        crate::palw_native_resource_v1::preflight_native_value_v1::<PositiveCertificationRowV2>(bytes.as_slice(), bytes.len() as u64)''',
'''    let bytes = positive_certification_row_bytes_v2(state, subject)
        .map_err(PositivePSourceErrorV2::Native)?
        .ok_or(PositivePSourceErrorV2::Unavailable)?;
    let shape =
        crate::palw_native_resource_v1::preflight_native_value_v1::<PositiveCertificationRowV2>(bytes, bytes.len() as u64)''')
replace(p, '''    if matches!(
        bundle.case.status,
        misaka_palw_positive_contract::messages::ClaimStatus::ClaimRefuted
            | misaka_palw_positive_contract::messages::ClaimStatus::Revoked
            | misaka_palw_positive_contract::messages::ClaimStatus::EndedUnverified
    ) {
        return Err(PositivePSourceErrorV2::Closed);
    }
    if &bundle.result.result != result || bundle.result.origin != h.commit_origin {
        return Err(PositivePSourceErrorV2::Binding);
    }''',
'''    if &bundle.result.result != result || bundle.result.origin != h.commit_origin {
        return Err(PositivePSourceErrorV2::Binding);
    }
    if !positive_certification_case_live_v2(h, &bundle.case).map_err(|_| PositivePSourceErrorV2::Binding)? {
        return Err(PositivePSourceErrorV2::Closed);
    }''')
p = 'palw_state_v2/positive_assignment_certification.rs'
replace(p, '''fn raw(state: &PalwChainStateV2, subject: Digest) -> Option<&[u8]> {
    let key = key(subject);
    let route = state.kernel_route_state_v1()?;
    route.aux.range((136, Vec::new())..(137, Vec::new())).find(|((_, k), _)| k.as_slice() == key).map(|(_, v)| v.as_slice())
}
fn read(state: &PalwChainStateV2, subject: Digest, pool: u64) -> Result<OwnedP, PalwStateV2Error> {
    let bytes = raw(state, subject).ok_or_else(|| refuse("missing P row"))?;''',
'''fn read(state: &PalwChainStateV2, subject: Digest, pool: u64) -> Result<OwnedP, PalwStateV2Error> {
    let bytes = positive_certification_row_bytes_v2(state, subject)
        .map_err(PalwStateV2Error::NativeResource)?
        .ok_or_else(|| refuse("missing P row"))?;''')
replace(p, '''    Ok(case.result == h.result
        && !matches!(case.status, ClaimStatus::ClaimRefuted | ClaimStatus::Revoked | ClaimStatus::EndedUnverified))''',
'''    positive_certification_case_live_v2(h, &case).map_err(refuse)''')
replace(p, 'if raw(&self.state, subject).is_some() {',
    'if positive_certification_row_bytes_v2(&self.state, subject).map_err(PalwStateV2Error::NativeResource)?.is_some() {')
p = 'palw_positive_rows_v2/tests.rs'
replace(p, '/// Real signatures over a chosen literal relation count.', '''#[test]
fn p_terminal_case_requires_its_exact_result_scope_and_liability() {
    use crate::{
        palw_positive_certification_v2::{
            PositiveCertificationHeaderV2, positive_certification_case_live_v2, positive_certification_policy_id_v2,
        },
        palw_security_certification_v1::PalwSecurityCertificationPolicyV1,
    };

    let (_, result, mut case, _, _, _) = signed_bundle();
    let r = &result.result;
    let policy = PalwSecurityCertificationPolicyV1 {
        m: 1,
        k: 1,
        veto: 0,
        anchor_delay_spans: 1,
        attest_window_daa: 5,
        prosecution_window_daa: 19,
        certify_by_daa: 7,
        verifier_maturity_daa: 3,
        verifier_min_collateral_sompi: 1,
        draws_per_epoch: 4,
        epoch_daa: 11,
    };
    let header = PositiveCertificationHeaderV2 {
        version: 2,
        revision: 1,
        assignment: misaka_palw_positive_contract::assignment::AssignmentId(d(81)),
        subject: misaka_palw_positive_contract::native::certification_subject(r),
        claim: r.claim_id(),
        result: r.id(),
        case: r.case_id(),
        scope: r.scope,
        policy,
        policy_id: positive_certification_policy_id_v2(&policy),
        commit_origin: result.origin,
        committed_span: Some(2),
        worker: NativeOutpoint { transaction: NativeHash64([82; 64]), index: 0 },
        worker_operator: d(83),
        worker_key: result.miner_key,
        worker_gain: 100,
        liability: case.liability,
    };
    assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(true));
    for status in [ClaimStatus::ClaimRefuted, ClaimStatus::Revoked, ClaimStatus::EndedUnverified] {
        case.status = status;
        assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(false));
        let mut other_output = r.clone();
        other_output.output = d(85);
        assert_eq!(other_output.case_id(), r.case_id());
        assert_ne!(other_output.id(), r.id());
        let other = CaseRow {
            result: other_output.id(),
            coverage: CoverageDescriptor { result: other_output.id(), ..case.coverage },
            ..case
        };
        assert_eq!(positive_certification_case_live_v2(&header, &other), Err(ContractError::Identity));
        let other = CaseRow {
            coverage: CoverageDescriptor { scope: ChainScope { branch: d(86), ..r.scope }, ..case.coverage },
            ..case
        };
        assert_eq!(positive_certification_case_live_v2(&header, &other), Err(ContractError::Identity));
        let other = CaseRow { liability: material_at(99), ..case };
        assert_eq!(positive_certification_case_live_v2(&header, &other), Err(ContractError::Identity));
    }
}

/// Real signatures over a chosen literal relation count.''')
