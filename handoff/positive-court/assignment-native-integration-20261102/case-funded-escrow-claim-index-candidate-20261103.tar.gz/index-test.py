from pathlib import Path

stage = Path(__file__).resolve().parent
source = (stage/'consensus/core/src/palw_state_v2/funded_escrow.rs').read_text()
implementation = source[source.index('impl PalwChainStateV2 {'):source.index("impl TransitionBuilder<'_> {")]
(stage/'index-test.rs').write_text("""
use std::collections::{BTreeMap, BTreeSet};
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct Hash64([u8; 64]);
impl Hash64 { fn from_bytes(bytes: [u8; 64]) -> Self { Self(bytes) } }
#[derive(Clone, Copy)]
struct PalwFundedEscrowRowV1 { claim: Hash64, settled: bool }
#[derive(Default)]
struct PalwChainStateV2 {
    funded_escrows: BTreeMap<Hash64, PalwFundedEscrowRowV1>,
    funded_escrows_by_claim: BTreeSet<(Hash64, Hash64)>,
}
""" + "mod implementation { use super::*; " + implementation + "}\n" + """
#[test]
fn ordered_lookup_preserves_two_contracts_and_replay_undo() {
    let low = Hash64([0; 64]);
    let high = Hash64([u8::MAX; 64]);
    let claim = Hash64([11; 64]);
    let neighbor = Hash64([12; 64]);
    let mut state = PalwChainStateV2::default();
    assert!(!state.has_funded_escrow_for_claim_v1(claim));
    let open = PalwFundedEscrowRowV1 { claim, settled: false };
    let settled = PalwFundedEscrowRowV1 { claim, settled: true };
    state.replace_funded_escrow_v1(low, Some(open));
    state.replace_funded_escrow_v1(high, Some(open));
    state.replace_funded_escrow_v1(low, Some(settled));
    assert!(state.funded_escrows[&low].settled);
    state.replace_funded_escrow_v1(low, None);
    assert!(state.has_funded_escrow_for_claim_v1(claim));
    state.replace_funded_escrow_v1(high, None);
    assert!(!state.has_funded_escrow_for_claim_v1(claim));
    state.replace_funded_escrow_v1(low, Some(settled));
    assert!(state.has_funded_escrow_for_claim_v1(claim));
    assert!(!state.has_funded_escrow_for_claim_v1(neighbor));
    state.replace_funded_escrow_v1(low, Some(PalwFundedEscrowRowV1 { claim: neighbor, settled: false }));
    assert!(!state.has_funded_escrow_for_claim_v1(claim));
    assert!(state.has_funded_escrow_for_claim_v1(neighbor));
}
""")
