from pathlib import Path

core = Path(__file__).resolve().parent / 'consensus/core/src'

def edit(path, old, new):
    p = core / path
    s = p.read_text()
    assert s.count(old) == 1, (path, s.count(old), old)
    p.write_text(s.replace(old, new))

edit('palw_state_v2.rs', '    funded_escrows: BTreeMap<Hash64, crate::palw_funded_escrow_v1::PalwFundedEscrowRowV1>,\n',
    '    funded_escrows: BTreeMap<Hash64, crate::palw_funded_escrow_v1::PalwFundedEscrowRowV1>,\n'
    '    // Derived from every retained escrow, including settled rows awaiting retirement.\n'
    '    funded_escrows_by_claim: BTreeSet<(Hash64, Hash64)>,\n')
edit('palw_state_v2.rs', '        PalwDeltaEntryV2::FundedEscrow { key, old, new } => swap_write!(state.funded_escrows, key, old, new),',
    '''        PalwDeltaEntryV2::FundedEscrow { key, old, new } => {
            let (expected, install) = if revert { (new, old) } else { (old, new) };
            expect_matches(&state.funded_escrows.get(key).copied(), expected)?;
            state.replace_funded_escrow_v1(*key, *install);
        }''')
edit('palw_state_v2.rs', '            funded_escrows: self.funded_escrows,\n',
    '            funded_escrows_by_claim: self.funded_escrows.iter().map(|(id, row)| (row.claim, *id)).collect(),\n'
    '            funded_escrows: self.funded_escrows,\n')
edit('palw_state_v2/chain_state.rs', '            funded_escrows: BTreeMap::new(),\n',
    '            funded_escrows: BTreeMap::new(),\n            funded_escrows_by_claim: BTreeSet::new(),\n')
edit('palw_state_v2/funded_escrow.rs', "impl TransitionBuilder<'_> {",
    '''impl PalwChainStateV2 {
    pub(super) fn has_funded_escrow_for_claim_v1(&self, claim: Hash64) -> bool {
        let first = (claim, Hash64::from_bytes([0; 64]));
        let last = (claim, Hash64::from_bytes([u8::MAX; 64]));
        self.funded_escrows_by_claim.range(first..=last).next().is_some()
    }

    pub(super) fn replace_funded_escrow_v1(&mut self, key: Hash64, new: Option<PalwFundedEscrowRowV1>) {
        let old = match new {
            Some(row) => self.funded_escrows.insert(key, row),
            None => self.funded_escrows.remove(&key),
        };
        let old_claim = old.map(|row| row.claim);
        let new_claim = new.map(|row| row.claim);
        if old_claim != new_claim {
            if let Some(claim) = old_claim {
                self.funded_escrows_by_claim.remove(&(claim, key));
            }
            if let Some(claim) = new_claim {
                self.funded_escrows_by_claim.insert((claim, key));
            }
        }
    }
}

impl TransitionBuilder<'_> {''')
edit('palw_state_v2/funded_escrow.rs', '''        match new {
            Some(row) => self.state.funded_escrows.insert(key, row),
            None => self.state.funded_escrows.remove(&key),
        };
        self.entries.push''', '''        if self.native_writers_tracking_v1() {
            let install = old.is_none() && new.is_some();
            let mut quote = native_writers::NativeWriteQuoteV1::new("native funded escrow writer");
            quote.member_if::<Hash64, PalwFundedEscrowRowV1>(install)?.member_if::<(Hash64, Hash64), ()>(install)?.slots(1)?;
            self.admit_native_write_v1(quote)?;
        }
        self.state.replace_funded_escrow_v1(key, new);
        self.entries.push''')
edit('palw_state_v2/positive_assignment_case.rs', 'state.funded_escrows.values().any(|row| row.claim == claim)',
    'state.has_funded_escrow_for_claim_v1(claim)')
edit('palw_native_resource_v1/private/palw_state_v2.rs', 'tir_designated, funded_escrows, d2_readiness',
    'tir_designated, funded_escrows, funded_escrows_by_claim, d2_readiness')
edit('palw_native_resource_v1/wire_generated.rs',
    'BTreeMap<crate::Hash64, crate::palw_funded_escrow_v1::PalwFundedEscrowRowV1>, crate::palw_court_model_scope_routes_v1::readiness_disclosure::PalwD2ReadinessRegistryV1',
    'BTreeMap<crate::Hash64, crate::palw_funded_escrow_v1::PalwFundedEscrowRowV1>, BTreeSet<(crate::Hash64, crate::Hash64)>, crate::palw_court_model_scope_routes_v1::readiness_disclosure::PalwD2ReadinessRegistryV1')
edit('palw_native_resource_v1/private/wire_carriage.rs', '    let n = count("legacy_disputes", false)?;\n    sum = sum\n',
    '    let n = count("funded_escrows", false)?;\n'
    '    sum = sum.allocation(\n'
    '        n,\n'
    '        std::mem::size_of::<crate::palw_native_resource_v1::typed::BTreeNodeEnvelopeV1<(crate::Hash64, crate::Hash64), ()>>(),\n'
    '    )?;\n'
    '    let n = count("legacy_disputes", false)?;\n    sum = sum\n')
edit('palw_state_v2/funded_escrow.rs', '        let install_delta = delta(b.entries.clone());\n',
    '        let install_delta = delta(b.entries.clone());\n'
    '        assert!(installed.has_funded_escrow_for_claim_v1(row().claim));\n'
    '        assert!(!installed.has_funded_escrow_for_claim_v1(h(50_000)));\n'
    '        let replayed = apply_delta_v2(&parent, &install_delta, &p).unwrap();\n'
    '        assert!(replayed.has_funded_escrow_for_claim_v1(row().claim));\n')
edit('palw_state_v2/funded_escrow.rs', '        assert!(before.funded_escrows_v1().is_empty());\n',
    '        assert!(settled.has_funded_escrow_for_claim_v1(row().claim));\n'
    '        assert!(undone.has_funded_escrow_for_claim_v1(row().claim));\n'
    '        assert!(!before.has_funded_escrow_for_claim_v1(row().claim));\n'
    '        assert!(before.funded_escrows_v1().is_empty());\n')
edit('palw_state_v2/funded_escrow.rs', '        assert!(s4.funded_escrows_v1().is_empty());\n',
    '        assert!(s4.funded_escrows_v1().is_empty());\n'
    '        assert!(!s4.has_funded_escrow_for_claim_v1(open_row().claim));\n')
edit('palw_state_v2/funded_escrow.rs', '            assert_eq!(&back.funded_escrows, state.funded_escrows_v1());\n',
    '            assert_eq!(&back.funded_escrows, state.funded_escrows_v1());\n'
    '            let restored = back.into_state(&p, Some(state.state_root())).unwrap();\n'
    '            assert_eq!(restored.has_funded_escrow_for_claim_v1(open_row().claim), !state.funded_escrows_v1().is_empty());\n'
    '            assert_eq!(borsh::to_vec(&PalwStateCarriageV2::from_state(&restored)).unwrap(), bytes);\n')
edit('palw_state_v2/tests.rs', '        funded_escrows: _,\n',
    '        funded_escrows: _,\n        funded_escrows_by_claim: _,\n')
