import json
import os
import subprocess
from pathlib import Path

scratch = Path(__file__).resolve().parent
core = scratch / 'consensus/core'
target = Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
fp = target / '.fingerprint'
data = json.loads((fp / 'kaspa-consensus-core-aba71521b8b2830a/test-lib-kaspa_consensus_core.json').read_text())
extern = {}
for _, name, _, fingerprint in data['deps']:
    if name == 'build_script_build':
        continue
    marker, = (m for m in fp.glob('*/lib-' + name) if m.read_text() == fingerprint.to_bytes(8, 'little').hex())
    suffix = marker.parent.name.rsplit('-', 1)[-1]
    base = target / 'deps' / ('lib' + name + '-' + suffix)
    extern[name] = next(str(base.with_suffix(ext)) for ext in ('.rmeta', '.dylib', '.rlib') if base.with_suffix(ext).exists())

rustc = Path.home() / '.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
env = os.environ | {'CARGO_MANIFEST_DIR': '/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet/consensus/core', 'CARGO': str(rustc.with_name('cargo')), 'CARGO_PKG_VERSION': '1.1.0', 'CARGO_PKG_NAME': 'kaspa-consensus-core'}
common = [str(rustc), '--edition=2024', '--emit=metadata', '-L', f'dependency={target / "deps"}', '-L', f'dependency={scratch}']
for name, path in extern.items():
    common.extend(['--extern', f'{name}={path}'])
for feature in json.loads(data['features']):
    common.extend(['--cfg', f'feature="{feature}"'])
subprocess.run([*common, '--test', '--crate-name', 'kaspa_consensus_core', '-C', 'metadata=funded_escrow_index_tests', '-o', str(scratch / 'funded-escrow-index-tests.rmeta'), str(core / 'src/lib.rs')], env=env, check=True)
print('Core unit-test source metadata passed', flush=True)
