from pathlib import Path
import json
import os
import runpy

out = Path('/tmp/misaka-case-relay-bound-slot-integrated')
previous = json.loads(Path('/tmp/misaka-native-relay-final/funded-native-relay-runtime.json').read_text())
env = dict(previous['extra_environment'])
env['PATH'] = '/tmp/misaka-native-relay-libcxx/bin' + os.pathsep + os.environ['PATH']
run = runpy.run_path('handoff/positive-court/legacy-native-history-20261102/operator-scripts/native-history-controller-20261102.py')['run']
run.__globals__['out'] = out
common = ['--message-format=json-render-diagnostics', '--offline', '--locked']
cases = [
    ('bound-slot-clippy', ['cargo', 'clippy', *common, '-p', 'misaka-palw-positive-contract', '-p', 'kaspa-consensus-core', '-p', 'kaspa-consensus', '--lib', '--', '-D', 'warnings'], 1800),
    ('bound-slot-core-test-check', ['cargo', 'check', *common, '-p', 'kaspa-consensus-core', '--test', 'positive_assignment_funds_v2', '--test', 'positive_funding_relay_v2'], 900),
]
for label, command, timeout in cases:
    result = run(label, command, timeout, 1100 * 1024**2, 20 * 1024**3, env)
    if result['exit_code'] != 0:
        raise SystemExit(1)
