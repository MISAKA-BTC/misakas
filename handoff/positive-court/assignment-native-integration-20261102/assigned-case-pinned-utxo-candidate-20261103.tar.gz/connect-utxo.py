from pathlib import Path
p=Path(__file__).resolve().parent/'consensus/src/pipeline/virtual_processor/processor/positive_assignment_archive.rs'
s=p.read_text()
s=s.replace('use crate::model::stores::acceptance_data::AcceptanceArchiveViewV2;',
            'use crate::model::stores::{acceptance_data::AcceptanceArchiveViewV2, utxo_diffs::UtxoArchiveViewV2};')
s=s.replace('        utxo_diffs::UtxoDiffsStoreReader,\n','')
def edit(old,new):
    global s
    assert s.count(old)==1, old
    s=s.replace(old,new)
edit('impl VirtualStateProcessor {','''fn utxo_diff_scans_v2(inputs: u64) -> Result<u64, NativeAssignmentArchiveErrorV2> {
    // Validate once, then price both passes for every requested outpoint.
    inputs.checked_mul(2).and_then(|n| n.checked_add(1)).ok_or(NativeAssignmentArchiveErrorV2::Invalid("UTXO replay work overflow"))
}

impl VirtualStateProcessor {''')
a=s.index('        self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::UtxoDiffs, accepting)?;')
b=s.index('        if !boundary.check_populated_data',a)
s=s[:a]+'''        let scans = utxo_diff_scans_v2(tx.inputs.len() as u64)?;
        let (entries, lease, retained_heap) = self
            .utxo_diffs_store
            .with_utxo_archive_v2(accepting, remaining_work / scans, |diff, diff_bytes| {
                charge_archive_work_v2(&mut remaining_work, diff_bytes * scans)?;
                self.acceptance_data_store
                    .with_accepted_archive_v2(accepting, acceptance_bytes, |acceptance| {
                        self.restore_original_archive_inputs_v2(
                            (&acceptance, &diff),
                            origin,
                            tx,
                            maximum_heap,
                            (size_of::<NativeAcceptedCaseCarriageV2>() + size_of::<[usize; 2]>()) as u64,
                            |creator| self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::BlockTransactions, creator),
                        )
                    })
                    .map_err(|_| E::Unavailable("bounded original acceptance archive"))?
            })
            .map_err(|_| E::Unavailable("bounded original UTXO archive"))??;
'''+s[b:]
a=s.index('        record(&mut replay, DatabaseStorePrefixes::UtxoDiffs, accepting)?;')
b=s.index('        let populated =',a)
s=s[:a]+'''        let scans = utxo_diff_scans_v2(tx.inputs.len() as u64)?;
        replay.charge(1, 0)?;
        let (entries, lease, _) = self
            .utxo_diffs_store
            .with_utxo_archive_v2(accepting, replay.remaining_work / scans, |diff, diff_bytes| {
                replay.charge(0, diff_bytes * scans)?;
                self.acceptance_data_store
                    .with_accepted_archive_v2(accepting, acceptance_bytes, |acceptance| {
                        self.restore_original_archive_inputs_v2((&acceptance, &diff), replay.origin, tx, replay.maximum_heap, 0, |creator| {
                            record(&mut replay, DatabaseStorePrefixes::BlockTransactions, creator)
                        })
                    })
                    .map_err(|_| E::Unavailable("bounded original relay acceptance archive"))?
            })
            .map_err(|_| E::Unavailable("bounded original relay UTXO archive"))??;
'''+s[b:]
edit('''        acceptance: &AcceptanceArchiveViewV2<'_>,
        origin: AcceptedOrigin,
        tx: &kaspa_consensus_core::tx::Transaction,''','''        (acceptance, diff): (&AcceptanceArchiveViewV2<'_>, &UtxoArchiveViewV2<'_>),
        origin: AcceptedOrigin,
        tx: &kaspa_consensus_core::tx::Transaction,''')
edit('''        let accepting = BlockHash::from_bytes(origin.accepting_block.0);
        let diff = self.utxo_diffs_store.get(accepting).map_err(|_| E::Unavailable("original accepted UTXO delta"))?;
        // First pass''','''        // First pass''')
edit('''            let bytes = if let Some(entry) = diff.remove.get(&input.previous_outpoint) {
                entry.script_public_key.script().len() as u64''','''            let bytes = if let Some(entry) =
                diff.find_removed_v2(input.previous_outpoint).map_err(|_| E::Invalid("original removed input archive"))?
            {
                entry.script.len() as u64''')
edit('''            let entry = if let Some(entry) = diff.remove.get(&input.previous_outpoint) {
                entry.clone()''','''            let entry = if let Some(entry) =
                diff.find_removed_v2(input.previous_outpoint).map_err(|_| E::Invalid("original removed input archive"))?
            {
                entry.to_entry_v2()''')
p.write_text(s)
