import subprocess
from pathlib import Path

stage=Path(__file__).resolve().parent
target=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
command=[str(rustc),'--edition=2024','--test','-L',f'dependency={target/"deps"}','-A','dead_code']
for name,suffix in {
    'kaspa_hashes':'763ecc08d728f51f',
    'kaspa_database':'2cf8dbfd3147b2cd',
    'kaspa_utils':'7c08fdf7b89aee32',
    'rocksdb':'9c33cc0b2d1a5c0a',
    'serde':'3c85614f91e7b472',
    'bincode':'48eb714cc5ca0815',
    'smallvec':'ea6614286116d54b',
}.items():
    command.extend(['--extern',f'{name}={target}/deps/lib{name}-{suffix}.rlib'])
for build_output in (target/'build').glob('*/out'):
    if any(build_output.glob('*.a')):
        command.extend(['-L',f'native={build_output}'])
repo=Path('/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet')
source=(stage/'utxo-wire-types.rs').read_text()
lib=(repo/'consensus/core/src/lib.rs').read_text()
start=lib.index('pub struct BlockHasher')
start=lib.rfind('#[derive',0,start)
end=lib.index('\n#[cfg(test)]',start)
hasher=lib[start:end]
wrapper=stage/'utxo-db-wrapper.rs'
store=stage/'consensus/src/model/stores/utxo_diffs.rs'
wrapper.write_text('''extern crate self as kaspa_consensus_core;
pub type BlockHash = kaspa_hashes::Hash64;
pub type TransactionId = BlockHash;
use std::hash::{BuildHasher, Hasher};
''' + hasher + '\n' + source + '\n' + f'#[path = "{store}"] mod store;\n')
binary=stage/'utxo-db-regression'
subprocess.run([*command,str(wrapper),'-o',str(binary)],check=True)
subprocess.run([str(binary),'--test-threads=1'],check=True)
