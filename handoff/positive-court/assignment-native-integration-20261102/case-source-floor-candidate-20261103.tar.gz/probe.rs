
use misaka_palw_positive_contract::{identity::{CaseId,Digest}, messages::{AggregateBudget,MinerServiceContract}};
#[derive(Debug,PartialEq,Eq)]
enum AssignmentHorizonErrorV2 { Overflow, Window, Budget }
struct AssignmentGateCClockV2 { commit_daa:u64, latest_failed_attestation_decision_daa:u64 }
struct AssignmentHorizonSpecV2 {
    refund_before_daa:u64, court_before_daa:u64, latest_result_before_daa:u64,
    minimum_source_rounds:u64, minimum_unique_source_bytes:u64, minimum_transmitted_source_bytes:u64,
}
impl AssignmentHorizonSpecV2 {
    pub(crate) fn check_case_source_floor_v2(
        &self,
        service: &MinerServiceContract,
        gate_c: &AssignmentGateCClockV2,
        refund_window_daa: u64,
        attempts: u32,
    ) -> Result<(), AssignmentHorizonErrorV2> {
        let retained_until = self.refund_before_daa.checked_sub(refund_window_daa).ok_or(AssignmentHorizonErrorV2::Overflow)?;
        let source_before = self.court_before_daa.max(gate_c.latest_failed_attestation_decision_daa);
        if gate_c.commit_daa >= self.latest_result_before_daa
            || service.deadline < source_before
            || service.budget.retention_until < retained_until
        {
            return Err(AssignmentHorizonErrorV2::Window);
        }
        let budget = &service.budget;
        if budget.rounds < self.minimum_source_rounds
            || budget.unique_source_bytes < self.minimum_unique_source_bytes
            || budget.transmitted_bytes < self.minimum_transmitted_source_bytes
            || budget.retained_bytes < self.minimum_unique_source_bytes
            || budget.witness_attempts != attempts
        {
            return Err(AssignmentHorizonErrorV2::Budget);
        }
        Ok(())
    }


}
#[test]
fn literal_c_source_floors_cover_case_and_actual_gate_c_cutoffs() {
    use AssignmentHorizonErrorV2::{Budget, Overflow, Window};
    let quote=AssignmentHorizonSpecV2 {
        refund_before_daa:180,court_before_daa:145,latest_result_before_daa:130,
        minimum_source_rounds:8,minimum_unique_source_bytes:3200,minimum_transmitted_source_bytes:8000,
    };
    let early=AssignmentGateCClockV2{commit_daa:101,latest_failed_attestation_decision_daa:135};
    let late=AssignmentGateCClockV2{commit_daa:129,latest_failed_attestation_decision_daa:163};
    let d=Digest([3;64]);
    let service=MinerServiceContract{
        version:2,revision:1,case:CaseId(d),source_catalog:d,provider_delegations:d,funding_consent:d,
        deadline:163,budget:AggregateBudget {
            rounds:8,unique_source_bytes:3200,transmitted_bytes:8000,retained_bytes:3200,retention_until:170,
            additional_work:9,fee:10,witness_attempts:2,
        }
    };
    let check=|s:&MinerServiceContract,c:&AssignmentGateCClockV2| quote.check_case_source_floor_v2(s,c,10,2);
    assert_eq!(check(&service,&late),Ok(()));
    assert_eq!(check(&MinerServiceContract{deadline:145,..service},&early),Ok(()));
    assert_eq!(check(&MinerServiceContract{deadline:144,..service},&early),Err(Window));
    assert_eq!(check(&MinerServiceContract{deadline:162,..service},&late),Err(Window));
    let after=AssignmentGateCClockV2{commit_daa:130,..late};
    assert_eq!(check(&service,&after),Err(Window));
    for budget in [
        AggregateBudget{rounds:7,..service.budget},
        AggregateBudget{unique_source_bytes:3199,..service.budget},
        AggregateBudget{transmitted_bytes:7999,..service.budget},
        AggregateBudget{retained_bytes:3199,..service.budget},
        AggregateBudget{witness_attempts:1,..service.budget},
    ] {
        assert_eq!(check(&MinerServiceContract{budget,..service},&late),Err(Budget));
    }
    let budget=AggregateBudget{retention_until:169,..service.budget};
    assert_eq!(check(&MinerServiceContract{budget,..service},&late),Err(Window));
    assert_eq!(quote.check_case_source_floor_v2(&service,&late,181,2),Err(Overflow));
}
