from pathlib import Path
root=Path(__file__).resolve().parent/'consensus/core/src'
p=root/'palw_positive_assignment_horizon_v2.rs'
s=p.read_text().replace('    messages::SourceKind,','    messages::{MinerServiceContract, SourceKind},')
needle='''impl AssignmentHorizonSpecV2 {
    /// Pure quote.'''
replacement='''impl AssignmentHorizonSpecV2 {
    /// The literal C service must supply the minimum signed A envelope.
    /// Use the actual accepted Result clock for the exclusive source cutoff.
    /// The original retention floor persists even if C arrives early.
    pub(crate) fn check_case_source_floor_v2(
        &self,
        service: &MinerServiceContract,
        gate_c: &AssignmentGateCClockV2,
        refund_window_daa: u64,
        attempts: u32,
    ) -> Result<(), AssignmentHorizonErrorV2> {
        let retained_until = self.refund_before_daa.checked_sub(refund_window_daa).ok_or(AssignmentHorizonErrorV2::Overflow)?;
        let source_before = self.court_before_daa.max(gate_c.latest_failed_attestation_decision_daa);
        if gate_c.commit_daa >= self.latest_result_before_daa
            || service.deadline < source_before
            || service.budget.retention_until < retained_until
        {
            return Err(AssignmentHorizonErrorV2::Window);
        }
        let budget = &service.budget;
        if budget.rounds < self.minimum_source_rounds
            || budget.unique_source_bytes < self.minimum_unique_source_bytes
            || budget.transmitted_bytes < self.minimum_transmitted_source_bytes
            || budget.retained_bytes < self.minimum_unique_source_bytes
            || budget.witness_attempts != attempts
        {
            return Err(AssignmentHorizonErrorV2::Budget);
        }
        Ok(())
    }

    /// Pure quote.'''
assert s.count(needle)==1
p.write_text(s.replace(needle,replacement))
p=root/'palw_state_v2/positive_assignment.rs'
s=p.read_text()
needle='''            || plan.case.unresolved_fraud != 0
            || plan.result.policy != expected.positive_policy'''
replacement='''            || plan.case.unresolved_fraud != 0
            || plan.case.maturity_daa < origin.accepted_daa
            || plan.case.maturity_daa >= expected.bundle.terms.reserve_until_daa
            || plan.result.policy != expected.positive_policy'''
assert s.count(needle)==1
s=s.replace(needle,replacement)
needle='''        let horizon = assignment_horizon_v2(rules, bundle, source, prover, resources, row.origin.accepted_daa)?;
        let relay = if'''
replacement='''        let horizon = assignment_horizon_v2(rules, bundle, source, prover, resources, row.origin.accepted_daa)?;
        let gate_c = rules.gate_c_clock(ctx.daa_score).map_err(refusal)?;
        horizon
            .check_case_source_floor_v2(
                &payload.service,
                &gate_c,
                rules.assignment_policy().refund_window_daa,
                rules.positive_policy().max_attempts,
            )
            .map_err(refusal)?;
        let relay = if'''
assert s.count(needle)==1
s=s.replace(needle,replacement)
needle='''            || payload.basis.required_capital < horizon.case_money.capital
            || budget.rounds < horizon.minimum_source_rounds
            || budget.unique_source_bytes < horizon.minimum_unique_source_bytes
            || budget.transmitted_bytes < horizon.minimum_transmitted_source_bytes
        {
            return Err(refusal("Case funding or source budgets do not cover the original native quote"));
        }'''
replacement='''            || payload.basis.required_capital < horizon.case_money.capital
        {
            return Err(refusal("Case funding does not cover the original native quote"));
        }'''
assert s.count(needle)==1
p.write_text(s.replace(needle,replacement))
