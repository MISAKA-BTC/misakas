set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends xfsprogs python3-minimal
scratch=$(mktemp -d /tmp/misaka-native-xfs.XXXXXX)
loop=''
cleanup() {
    if mountpoint -q "$scratch/fs"; then umount "$scratch/fs"; fi
    if [ -n "$loop" ]; then losetup -d "$loop"; fi
    rm -f "$scratch/backing.img"
    rmdir "$scratch/fs" "$scratch"
}
mkdir "$scratch/fs"
trap cleanup EXIT
truncate -s 320M "$scratch/backing.img"
loop=$(losetup --find --show "$scratch/backing.img")
mkfs.xfs -f "$loop" >/dev/null
mount -o prjquota "$loop" "$scratch/fs"
mkdir "$scratch/fs/db"
xfs_quota -x -c "project -s -p $scratch/fs/db 4197" "$scratch/fs"
xfs_quota -x -c 'limit -p bhard=16m 4197' "$scratch/fs"
python3 - "$loop" "$scratch/fs/db" <<'PY'
import ctypes, errno, fcntl, os, struct, sys
device, directory = sys.argv[1:]
libc = ctypes.CDLL(None, use_errno=True)
fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
attributes = bytearray(28)
fcntl.ioctl(fd, 0x801c581f, attributes, True)
os.close(fd)
flags, _, _, project = struct.unpack_from('<IIII', attributes)
assert flags & 0x200 and project == 4197, (flags, project)
def read_project(code, project_id, size, version):
    buffer = ctypes.create_string_buffer(size)
    buffer[0] = bytes([version])
    if libc.quotactl(code, device.encode(), project_id, ctypes.byref(buffer)) != 0:
        raise OSError(ctypes.get_errno(), 'read-only Linux project quota probe')
    return buffer.raw
status = read_project(((ord('X') << 8 | 8) << 8) | 2, 0, 160, 1)
assert status[0] == 1 and struct.unpack_from('<H', status, 2)[0] & 0x30 == 0x30, status[:8]
quota = read_project(((ord('X') << 8 | 3) << 8) | 2, project, 112, 0)
assert quota[0] == 1 and quota[1] & 2
assert struct.unpack_from('<I', quota, 4)[0] == project
assert struct.unpack_from('<Q', quota, 8)[0] * 512 == 16 << 20
# Equal-sized control outside the limited project rules out a full device.
with open(os.path.dirname(directory) + '/unlimited-control', 'wb', buffering=0) as control:
    os.posix_fallocate(control.fileno(), 0, 32 << 20)
with open(directory + '/limit-probe', 'wb', buffering=0) as probe:
    os.posix_fallocate(probe.fileno(), 0, 8 << 20)
    measured = read_project(((ord('X') << 8 | 3) << 8) | 2, project, 112, 0)
    assert struct.unpack_from('<Q', measured, 40)[0] * 512 >= 8 << 20
    try:
        os.posix_fallocate(probe.fileno(), 8 << 20, 24 << 20)
    except OSError as error:
        assert error.errno in (errno.EDQUOT, errno.ENOSPC), error
        print(f'XFS enforced project 4197 at 16 MiB and returned errno {error.errno}; the 32 MiB unquoted control succeeded')
    else:
        raise AssertionError('kernel did not reject a reservation over the project limit')

PY
