import json
import os
import subprocess
from pathlib import Path

scratch = Path(__file__).resolve().parent
core = scratch / 'misaka/palw/positive-contract'
target = Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
fp = target / '.fingerprint'
data = json.loads((fp / 'misaka-palw-positive-contract-9831a09b2a75c09a/lib-misaka_palw_positive_contract.json').read_text())
extern = {}
for _, name, _, fingerprint in data['deps']:
    if name == 'build_script_build':
        continue
    marker, = (m for m in fp.glob('*/lib-' + name) if m.read_text() == fingerprint.to_bytes(8, 'little').hex())
    suffix = marker.parent.name.rsplit('-', 1)[-1]
    base = target / 'deps' / ('lib' + name + '-' + suffix)
    extern[name] = next(str(base.with_suffix(ext)) for ext in ('.rmeta', '.dylib', '.rlib') if base.with_suffix(ext).exists())

rustc = Path.home() / '.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
env = os.environ | {'CARGO_MANIFEST_DIR': '/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet/misaka/palw/positive-contract', 'CARGO': str(rustc.with_name('cargo')), 'CARGO_PKG_VERSION': '1.1.0'}
common = [str(rustc), '--edition=2024', '--emit=metadata', '-L', f'dependency={target / "deps"}', '-L', f'dependency={scratch}']
for name, path in extern.items():
    common.extend(['--extern', f'{name}={path}'])
for feature in json.loads(data['features']):
    common.extend(['--cfg', f'feature="{feature}"'])

contract = scratch / 'libmisaka_palw_positive_contract-case_relay_atomic.rmeta'
subprocess.run([*common, '--crate-name', 'misaka_palw_positive_contract', '--crate-type', 'rlib', '-C', 'metadata=case_relay_atomic', '-o', str(contract), str(core / 'src/lib.rs')], env=env, check=True)
