from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'consensus/src/model/stores/block_transactions.rs'
s=p.read_text()
s='''use kaspa_consensus_core::{
    palw_native_resource_v1::{NativeDemandLeaseV1, reserve_native_requests_v1},
    subnets::SUBNETWORK_ID_SIZE,
};
'''+s
i=s.index('    pub fn insert_batch(')
s=s[:i]+'''    /// Borrow the existing block body and decode only the accepted transaction
    /// after checking its typed allocation bound. Do not populate the cache.
    pub(crate) fn archive_transaction_v2(
        &self,
        block: BlockHash,
        index: u32,
        maximum_bytes: u64,
        maximum_heap: u64,
    ) -> Result<(ArchivedTransactionV2, u64), StoreError> {
        let prefix = [u8::from(DatabaseStorePrefixes::BlockTransactions)];
        let key = kaspa_database::prelude::DbKey::new(&prefix, block);
        let raw = self.db.get_pinned(&key)?.ok_or_else(|| StoreError::KeyNotFound(key))?;
        let bytes = raw.len() as u64;
        if bytes > maximum_bytes {
            return Err(StoreError::LocalResourceUnavailable("block archive exceeds replay byte limit".into()));
        }
        let (wire, heap) = archived_transaction_wire_v2(&raw, index)?.ok_or_else(|| {
            StoreError::DataInconsistency("accepted transaction index outside archived block".into())
        })?;
        if heap > maximum_heap {
            return Err(StoreError::LocalResourceUnavailable("archived transaction exceeds replay heap limit".into()));
        }
        let lease = reserve_native_requests_v1(heap)
            .map_err(|e| StoreError::LocalResourceUnavailable(e.to_string()))?
            .ok_or_else(|| StoreError::LocalResourceUnavailable("archive transaction allocator is not armed".into()))?;
        let transaction = bincode::deserialize(wire)?;
        Ok((ArchivedTransactionV2 { transaction, heap, lease }, bytes))
    }

'''+s[i:]
i=s.index('#[cfg(test)]')
s=s[:i]+'''pub(crate) struct ArchivedTransactionV2 {
    pub transaction: Transaction,
    pub heap: u64,
    pub lease: NativeDemandLeaseV1,
}

/// Scan the existing bincode BlockBody/Transaction representations. Counts
/// cannot allocate or advance past a complete field. Even when the selected
/// transaction comes first, validate the rest of the stored framing.
fn archived_transaction_wire_v2(raw: &[u8], index: u32) -> Result<Option<(&[u8], u64)>, StoreError> {
    fn invalid() -> StoreError {
        StoreError::DataInconsistency("malformed archived block transactions".into())
    }
    fn take<'a>(raw: &mut &'a [u8], count: usize) -> Result<&'a [u8], StoreError> {
        let (head, tail) = raw.split_at_checked(count).ok_or_else(invalid)?;
        *raw = tail;
        Ok(head)
    }
    fn count(raw: &mut &[u8]) -> Result<u64, StoreError> {
        Ok(u64::from_le_bytes(take(raw, 8)?.try_into().map_err(|_| invalid())?))
    }
    fn blob(raw: &mut &[u8]) -> Result<u64, StoreError> {
        let size = count(raw)?;
        take(raw, usize::try_from(size).map_err(|_| invalid())?)?;
        Ok(size)
    }
    fn hash(raw: &mut &[u8]) -> Result<(), StoreError> {
        if blob(raw)? != 64 {
            return Err(invalid());
        }
        Ok(())
    }
    fn grow(heap: &mut u64, count: u64, unit: usize) -> Result<(), StoreError> {
        *heap = count.checked_mul(unit as u64).and_then(|n| n.checked_mul(2)).and_then(|n| heap.checked_add(n)).ok_or_else(invalid)?;
        Ok(())
    }

    let mut cursor = raw;
    let transactions = count(&mut cursor)?;
    let mut selected = None;
    for position in 0..transactions {
        let start = cursor;
        take(&mut cursor, 2)?; // version
        let mut heap = size_of::<Transaction>() as u64;
        let inputs = count(&mut cursor)?;
        grow(&mut heap, inputs, size_of::<TransactionInput>())?;
        for _ in 0..inputs {
            hash(&mut cursor)?;
            take(&mut cursor, 4)?; // outpoint index
            grow(&mut heap, blob(&mut cursor)?, 1)?;
            take(&mut cursor, 8 + 1)?; // sequence and sigops
        }
        let outputs = count(&mut cursor)?;
        grow(&mut heap, outputs, size_of::<TransactionOutput>())?;
        for _ in 0..outputs {
            take(&mut cursor, 8 + 2)?; // amount and script version
            grow(&mut heap, blob(&mut cursor)?, 1)?;
        }
        take(&mut cursor, 8 + SUBNETWORK_ID_SIZE + 8)?; // lock, subnetwork and gas
        grow(&mut heap, blob(&mut cursor)?, 1)?;
        take(&mut cursor, 8)?; // mass
        hash(&mut cursor)?; // cached id; caller revalidates the actual transaction
        if position == u64::from(index) {
            selected = Some((&start[..start.len() - cursor.len()], heap));
        }
    }
    if !cursor.is_empty() {
        return Err(invalid());
    }
    Ok(selected)
}

'''+s[i:]
p.write_text(s)
p=root/'consensus/core/src/palw_state_v2/positive_assignment_backing.rs'
s=p.read_text().replace('    block::BlockTransactionsV3,\n','')
s=s.replace('    body: BlockTransactionsV3,\n    index: u32,','    transaction: Transaction,\n    _transaction_lease: NativeDemandLeaseV1,')
s=s.replace('        body: BlockTransactionsV3,\n        index: u32,','        transaction: Transaction,\n        transaction_lease: NativeDemandLeaseV1,')
s=s.replace('''        let tx = body.get(index as usize).ok_or(NativeAssignedCaseBackingErrorV2::Origin)?;
        if tx.id().as_bytes() != origin.carrier_transaction.0 || tx.inputs.len() != entries.len()''','''        if transaction.id().as_bytes() != origin.carrier_transaction.0 || transaction.inputs.len() != entries.len()''')
s=s.replace('Ok(Self { body, index, entries, fee, origin, selected_parent, prefix_state: None, _lease: lease })',
'''Ok(Self { transaction, _transaction_lease: transaction_lease, entries, fee, origin, selected_parent, prefix_state: None, _lease: lease })''')
s=s.replace('&self.body[self.index as usize]','&self.transaction')
s=s.replace('let Self { body, index: _, entries, fee: _, origin: _, selected_parent: _, prefix_state, _lease: _ } = self;',
'''let Self { transaction, _transaction_lease: _, entries, fee: _, origin: _, selected_parent: _, prefix_state, _lease: _ } = self;''')
s=s.replace('body.native_heap_v1(path).add::<Self>(entries.native_heap_v1(path), path)',
'transaction.native_heap_v1(path).add::<Self>(entries.native_heap_v1(path), path)')
p.write_text(s)
