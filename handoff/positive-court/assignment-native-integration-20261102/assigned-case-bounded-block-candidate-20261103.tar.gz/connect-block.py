from pathlib import Path
p=Path(__file__).resolve().parent/'consensus/src/pipeline/virtual_processor/processor/positive_assignment_archive.rs'
s=p.read_text()
s=s.replace('acceptance_data::AcceptanceArchiveViewV2, utxo_diffs::UtxoArchiveViewV2', 'acceptance_data::AcceptanceArchiveViewV2, block_transactions::ArchivedTransactionV2, utxo_diffs::UtxoArchiveViewV2')
s=s.replace('block_transactions::BlockTransactionsStoreReader, ', '')
def edit(old,new):
    global s
    assert s.count(old)==1, old
    s=s.replace(old,new)
a=s.index('        self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::BlockTransactions, carrier_block)?;')
b=s.index('        if tx.is_coinbase()',a)
s=s[:a]+'''        let carrier = self.read_archive_transaction_v2(carrier_block, accepted.index_within_block, maximum_heap, &mut remaining_work)?;
        let maximum_heap =
            maximum_heap.checked_sub(carrier.heap).ok_or(E::Unavailable("archived carrier exhausted replay heap"))?;
        let tx = &carrier.transaction;
'''+s[b:]
edit('''|creator| {
                                self.charge_archive_record_v2(&mut remaining_work, DatabaseStorePrefixes::BlockTransactions, creator)
                            },''',
'''|creator, index, heap| self.read_archive_transaction_v2(creator, index, heap, &mut remaining_work),''')
edit('''NativeAcceptedCaseCarriageV2::from_native_history_v2(body, index, entries, actual_fee, origin, selected_parent, lease)''',
'''NativeAcceptedCaseCarriageV2::from_native_history_v2(carrier.transaction, carrier.lease, entries, actual_fee, origin, selected_parent, lease)''')
a=s.index('        let record = |replay: &mut RelayCarrierReplayV2')
b=s.index('        if tx.is_coinbase()',a)
s=s[:a]+'''        replay.charge(1, 0)?;
        let carrier = self.read_archive_transaction_v2(carrier, replay.index, replay.maximum_heap, &mut replay.remaining_work)?;
        let input_heap =
            replay.maximum_heap.checked_sub(carrier.heap).ok_or(E::Unavailable("archived relay carrier exhausted replay heap"))?;
        let tx = &carrier.transaction;
'''+s[b:]
edit('''                            replay.maximum_heap,
                            0,
                            |creator| record(&mut replay, DatabaseStorePrefixes::BlockTransactions, creator),''',
'''                            input_heap,
                            0,
                            |creator, index, heap| {
                                replay.charge(1, 0)?;
                                self.read_archive_transaction_v2(creator, index, heap, &mut replay.remaining_work)
                            },''')
edit('''        drop(lease);
        self.replay_original_relay_payer_v2(replay)''','''        drop(lease);
        drop(carrier);
        self.replay_original_relay_payer_v2(replay)''')
a=s.index('    fn charge_archive_record_v2(')
b=s.index('    fn restore_original_archive_inputs_v2(',a)
s=s[:a]+'''    fn read_archive_transaction_v2(
        &self,
        block: BlockHash,
        index: u32,
        maximum_heap: u64,
        remaining_work: &mut u64,
    ) -> Result<ArchivedTransactionV2, NativeAssignmentArchiveErrorV2> {
        use NativeAssignmentArchiveErrorV2 as E;
        // Charge both the block framing scan and the selected decode before
        // allocating the selected transaction.
        let (transaction, extent) = self.block_transactions_store
            .archive_transaction_v2(block, index, *remaining_work / 2, maximum_heap)
            .map_err(|error| match error {
                kaspa_database::prelude::StoreError::DataInconsistency(_) => E::Invalid("archived transaction framing"),
                _ => E::Unavailable("bounded archived transaction"),
            })?;
        charge_archive_work_v2(remaining_work, extent * 2)?;
        Ok(transaction)
    }

'''+s[b:]
# Other methods continue to use DbKey and store prefixes for exact relay delta checks.
edit('''        mut before_creator: impl FnMut(BlockHash) -> Result<(), NativeAssignmentArchiveErrorV2>,''',
'''        mut load_creator: impl FnMut(BlockHash, u32, u64) -> Result<ArchivedTransactionV2, NativeAssignmentArchiveErrorV2>,''')
edit('''self.with_prior_assignment_output_v2(acceptance, origin, input.previous_outpoint, &mut before_creator, |output, _| {''',
'''self.with_prior_assignment_output_v2(acceptance, origin, input.previous_outpoint, maximum_heap, &mut load_creator, |output, _| {''')
edit('''                    &mut before_creator,
                    |output, coinbase|''',
'''                    maximum_heap - heap,
                    &mut load_creator,
                    |output, coinbase|''')
edit('''        before_read: &mut impl FnMut(BlockHash) -> Result<(), NativeAssignmentArchiveErrorV2>,''',
'''        maximum_heap: u64,
        load_creator: &mut impl FnMut(BlockHash, u32, u64) -> Result<ArchivedTransactionV2, NativeAssignmentArchiveErrorV2>,''')
edit('''        before_read(block)?;
        let body = self.block_transactions_store.get(block).map_err(|_| E::Unavailable("earlier accepted creator body"))?;
        let tx = body.get(entry.index_within_block as usize).ok_or(E::Invalid("earlier creator index"))?;''',
'''        let creator = load_creator(block, entry.index_within_block, maximum_heap)?;
        let tx = &creator.transaction;''')
if s.count('DatabaseStorePrefixes')==1:
    s=s.replace('use kaspa_database::{prelude::DbKey, registry::DatabaseStorePrefixes};\n','')
p.write_text(s)
