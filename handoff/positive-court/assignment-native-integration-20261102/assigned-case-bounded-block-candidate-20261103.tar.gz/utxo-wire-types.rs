mod tx {
    use crate::BlockHash;
    use serde::{Deserialize, Serialize, Serializer};
    use smallvec::SmallVec;

    type ScriptVec = SmallVec<[u8; 35]>;
    #[derive(Clone, Debug, PartialEq, Eq, Deserialize)]
    pub struct ScriptPublicKey {
        version: u16,
        script: ScriptVec,
    }
    impl ScriptPublicKey {
        pub fn new(version: u16, script: ScriptVec) -> Self {
            Self { version, script }
        }
    }
    impl Serialize for ScriptPublicKey {
        fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
            #[derive(Serialize)]
            struct Compact<'a> {
                version: u16,
                script: &'a [u8],
            }
            Compact { version: self.version, script: &self.script }.serialize(serializer)
        }
    }

    #[derive(Clone, Copy, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
    pub struct TransactionOutpoint {
        transaction_id: BlockHash,
        index: u32,
    }
    impl TransactionOutpoint {
        pub fn new(transaction_id: BlockHash, index: u32) -> Self {
            Self { transaction_id, index }
        }
    }

    #[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
    pub struct UtxoEntry {
        amount: u64,
        script_public_key: ScriptPublicKey,
        block_daa_score: u64,
        is_coinbase: bool,
    }
    impl UtxoEntry {
        pub fn new(amount: u64, script_public_key: ScriptPublicKey, block_daa_score: u64, is_coinbase: bool) -> Self {
            Self { amount, script_public_key, block_daa_score, is_coinbase }
        }
    }
}
mod utxo {
    pub mod utxo_diff {
        use crate::tx::{TransactionOutpoint, UtxoEntry};
        use serde::{Deserialize, Serialize};
        use std::collections::HashMap;
        #[derive(Clone, Default, Serialize, Deserialize)]
        pub struct UtxoDiff {
            pub add: HashMap<TransactionOutpoint, UtxoEntry>,
            pub remove: HashMap<TransactionOutpoint, UtxoEntry>,
        }
        impl kaspa_utils::mem_size::MemSizeEstimator for UtxoDiff {}
    }
}
