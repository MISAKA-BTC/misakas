from pathlib import Path
import subprocess

stage=Path(__file__).resolve().parent
source=(stage/'consensus/src/model/stores/block_transactions.rs').read_text()
scanner=source[source.index('fn archived_transaction_wire_v2'):source.index('#[cfg(test)]')]
test=source[source.index('    #[test]\n    fn archive_selects_literal'):]
test=test[:test.rfind('}')]
wire=(stage/'utxo-wire-types.rs').read_text().split('mod utxo {')[0]
wire=wire.replace('    use crate::BlockHash;', '''    use crate::{BlockHash, SUBNETWORK_ID_SIZE};
    use std::sync::atomic::{AtomicU64, Ordering};''')
wire=wire.rstrip()[:-1]+'''
    #[derive(Debug, Serialize, Deserialize, Clone, PartialEq, Eq)]
    pub struct TransactionInput {
        previous_outpoint: TransactionOutpoint,
        signature_script: Vec<u8>,
        sequence: u64,
        sig_op_count: u8,
    }
    impl TransactionInput {
        pub fn new(previous_outpoint: TransactionOutpoint, signature_script: Vec<u8>, sequence: u64, sig_op_count: u8) -> Self {
            Self { previous_outpoint, signature_script, sequence, sig_op_count }
        }
    }
    #[derive(Debug, Serialize, Deserialize, Clone, PartialEq, Eq)]
    pub struct TransactionOutput {
        value: u64,
        script_public_key: ScriptPublicKey,
    }
    impl TransactionOutput {
        pub fn new(value: u64, script_public_key: ScriptPublicKey) -> Self { Self { value, script_public_key } }
    }
    #[derive(Debug, Serialize, Deserialize)]
    struct TransactionMass(AtomicU64);
    impl Clone for TransactionMass {
        fn clone(&self) -> Self { Self(AtomicU64::new(self.0.load(Ordering::SeqCst))) }
    }
    impl PartialEq for TransactionMass {
        fn eq(&self, other: &Self) -> bool { self.0.load(Ordering::SeqCst) == other.0.load(Ordering::SeqCst) }
    }
    impl Eq for TransactionMass {}
    #[derive(Debug, Serialize, Deserialize, Clone, PartialEq, Eq)]
    pub struct Transaction {
        version: u16,
        inputs: Vec<TransactionInput>,
        outputs: Vec<TransactionOutput>,
        lock_time: u64,
        subnetwork_id: [u8; SUBNETWORK_ID_SIZE],
        gas: u64,
        payload: Vec<u8>,
        mass: TransactionMass,
        id: BlockHash,
    }
    impl Transaction {
        pub fn new(version: u16, inputs: Vec<TransactionInput>, outputs: Vec<TransactionOutput>, lock_time: u64,
                   subnetwork_id: [u8; SUBNETWORK_ID_SIZE], gas: u64, payload: Vec<u8>) -> Self {
            Self { version, inputs, outputs, lock_time, subnetwork_id, gas, payload,
                mass: TransactionMass(AtomicU64::new(0)), id: BlockHash::from_bytes([version as u8; 64]) }
        }
        pub fn set_mass(&self, mass: u64) { self.mass.0.store(mass, Ordering::SeqCst); }
    }
}
'''
wrapper=stage/'block-archive-probe.rs'
wrapper.write_text('''
use serde::Serialize;
type BlockHash = kaspa_hashes::Hash64;
const SUBNETWORK_ID_SIZE: usize = 20;
const SUBNETWORK_ID_NATIVE: [u8; 20] = [0; 20];
#[derive(Debug)]
enum StoreError { DataInconsistency(String) }
use tx::{Transaction, TransactionInput, TransactionOutput, TransactionOutpoint, ScriptPublicKey};
#[derive(Serialize)]
struct BlockBody(Vec<Transaction>);
'''+wire+scanner+test)
target=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
command=[str(rustc),'--edition=2024','--test','-L',f'dependency={target/"deps"}','-A','dead_code']
for name,suffix in {'kaspa_hashes':'763ecc08d728f51f','serde':'3c85614f91e7b472','bincode':'48eb714cc5ca0815','smallvec':'ea6614286116d54b'}.items():
    command.extend(['--extern',f'{name}={target}/deps/lib{name}-{suffix}.rlib'])
binary=stage/'block-archive-probe'
subprocess.run([*command,str(wrapper),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
