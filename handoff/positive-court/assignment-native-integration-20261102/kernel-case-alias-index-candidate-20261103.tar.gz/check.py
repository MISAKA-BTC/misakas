from pathlib import Path
import subprocess

stage=Path(__file__).resolve().parent
s=(stage/'consensus/core/src/palw_kernel_route_v1.rs').read_text()
a=s.index('struct KernelCaseAliasesV2 {')
b=s.index('impl KernelLedgerCacheV1 {',a)
index=s[a:b]
h='''
use std::collections::BTreeMap;
type Digest = [u8; 64];
struct Claim { job_id: Digest }
#[derive(Default)]
struct Opv { claims: BTreeMap<Digest, ()> }
#[derive(Default)]
struct KernelLedgerV1 {
    claims: BTreeMap<Digest, Claim>,
    job_claims: BTreeMap<Digest, Digest>,
    jobs: BTreeMap<Digest, ()>,
    pipeline_jobs: BTreeMap<Digest, ()>,
    job_escrows: BTreeMap<Digest, ()>,
    seals: BTreeMap<(Digest, Digest), ()>,
    proof_seals: BTreeMap<(Digest, Digest), ()>,
    opv: Opv,
}
mod palw_native_resource_v1 {
    #[derive(Debug)]
    pub struct NativeCoverageV1;
    impl NativeCoverageV1 {
        pub fn overflow<T>(_: &str) -> Self { let _ = core::marker::PhantomData::<T>; Self }
        pub fn unsupported<T>(_: &str, _: &str) -> Self { let _ = core::marker::PhantomData::<T>; Self }
    }
    pub struct NativeDemandLeaseV1;
    pub struct TirNativeRequestsV1(u64);
    impl TirNativeRequestsV1 {
        pub fn new() -> Self { Self(0) }
        pub fn exact_v1<T>(&mut self, n:u64) -> Result<(), NativeCoverageV1> {
            self.0 += n * core::mem::size_of::<T>() as u64;
            Ok(())
        }
        pub fn bytes_v1(&self) -> u64 { self.0 }
    }
    pub fn reserve_native_requests_v1(_:u64) -> Result<Option<NativeDemandLeaseV1>, NativeCoverageV1> {
        Ok(Some(NativeDemandLeaseV1))
    }
    pub mod typed {
        pub struct BTreeNodeEnvelopeV1<K,V>(K,V);
    }
}
#[test]
fn aliases_match_all_old_relationships_and_respect_key_roles() {
    let id = |n| [n; 64];
    let mut ledger = KernelLedgerV1::default();
    ledger.claims.insert(id(1), Claim { job_id: id(2) });
    ledger.claims.insert(id(3), Claim { job_id: id(2) });
    ledger.job_claims.insert(id(4), id(5));
    ledger.jobs.insert(id(6), ());
    ledger.pipeline_jobs.insert(id(7), ());
    ledger.job_escrows.insert(id(8), ());
    ledger.seals.insert((id(9), id(14)), ());
    ledger.proof_seals.insert((id(10), id(15)), ());
    ledger.opv.claims.insert(id(11), ());
    let aliases = KernelCaseAliasesV2::build(&ledger).unwrap();
    for n in 0..=16 {
        for m in 0..=16 {
            let claim = id(n);
            let job = id(m);
            let previous = ledger.claims.contains_key(&claim)
                || ledger.claims.values().any(|row| row.job_id == job)
                || ledger.jobs.contains_key(&job)
                || ledger.pipeline_jobs.contains_key(&job)
                || ledger.job_claims.contains_key(&job)
                || ledger.job_claims.values().any(|owner| *owner == claim)
                || ledger.job_escrows.contains_key(&job)
                || ledger.seals.keys().any(|(candidate,_)| *candidate == job)
                || ledger.proof_seals.keys().any(|(candidate,_)| *candidate == claim)
                || ledger.opv.claims.contains_key(&claim);
            assert_eq!(aliases.contains(&claim, &job), previous, "claim {n}, job {m}");
        }
    }
}
'''
probe=stage/'kernel-index-probe.rs'
probe.write_text(h+index)
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
binary=stage/'kernel-index-probe'
subprocess.run([str(rustc),'--edition=2024','--test','-A','dead_code',str(probe),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
