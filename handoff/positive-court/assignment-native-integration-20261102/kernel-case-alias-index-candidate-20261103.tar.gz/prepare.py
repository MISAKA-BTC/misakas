from pathlib import Path
base=Path(__file__).resolve().parent/'consensus/core/src'
def edit(path, old, new):
    p=base/path
    s=p.read_text()
    assert s.count(old)==1, (path,old)
    p.write_text(s.replace(old,new))
p='palw_kernel_route_v1.rs'
edit(p,'''pub struct KernelLedgerCacheV1(Option<std::sync::Arc<crate::palw_native_resource_v1::ReservedKernelLedgerV1>>, bool);''','''pub struct KernelLedgerCacheV1(
    Option<std::sync::Arc<crate::palw_native_resource_v1::ReservedKernelLedgerV1>>,
    bool,
    std::sync::OnceLock<std::sync::Arc<KernelCaseAliasesV2>>,
);

/// Exact subject membership derived from the same authenticated ledger
/// projection used by Case closure. Never serialized or used as evidence.
struct KernelCaseAliasesV2 {
    claims: std::collections::BTreeSet<[u8; 64]>,
    jobs: std::collections::BTreeSet<[u8; 64]>,
    lease: crate::palw_native_resource_v1::NativeDemandLeaseV1,
}

impl KernelCaseAliasesV2 {
    fn build(ledger: &KernelLedgerV1) -> Result<Self, crate::palw_native_resource_v1::NativeCoverageV1> {
        use crate::palw_native_resource_v1::{NativeCoverageV1, TirNativeRequestsV1, reserve_native_requests_v1, typed::BTreeNodeEnvelopeV1};
        let context = "kernel Case alias index";
        let members = [
            ledger.claims.len(), ledger.claims.len(), ledger.jobs.len(), ledger.pipeline_jobs.len(),
            ledger.job_claims.len(), ledger.job_claims.len(), ledger.job_escrows.len(),
            ledger.seals.len(), ledger.proof_seals.len(), ledger.opv.claims.len(),
        ].into_iter().try_fold(0u64, |n, len| n.checked_add(len as u64))
            .ok_or_else(|| NativeCoverageV1::overflow::<Self>(context))?;
        let mut requests = TirNativeRequestsV1::new();
        requests.exact_v1::<BTreeNodeEnvelopeV1<[u8; 64], ()>>(members)?;
        requests.exact_v1::<Self>(1)?;
        requests.exact_v1::<usize>(2)?; // shared owner
        let lease = reserve_native_requests_v1(requests.bytes_v1())?
            .ok_or_else(|| NativeCoverageV1::unsupported::<Self>(context, "actual checker is not armed"))?;

        let mut claims = std::collections::BTreeSet::new();
        let mut jobs = std::collections::BTreeSet::new();
        // Extend one member at a time so the admitted tree bound also covers
        // construction without a temporary sorted collection.
        for (&claim, row) in &ledger.claims {
            claims.insert(claim);
            jobs.insert(row.job_id);
        }
        for (&job, &claim) in &ledger.job_claims {
            jobs.insert(job);
            claims.insert(claim);
        }
        for &claim in ledger.opv.claims.keys().chain(ledger.proof_seals.keys().map(|(claim, _)| claim)) {
            claims.insert(claim);
        }
        for &job in ledger.jobs.keys().chain(ledger.pipeline_jobs.keys()).chain(ledger.job_escrows.keys())
            .chain(ledger.seals.keys().map(|(job, _)| job)) {
            jobs.insert(job);
        }
        Ok(Self { claims, jobs, lease })
    }
    fn contains(&self, claim: &[u8; 64], job: &[u8; 64]) -> bool {
        self.claims.contains(claim) || self.jobs.contains(job)
    }
}
''')
edit(p,'''    pub fn clear(&mut self) {
        self.0 = None;
        self.1 = false;
    }''','''    pub fn clear(&mut self) {
        self.0 = None;
        self.1 = false;
        self.2 = std::sync::OnceLock::new();
    }
    pub(crate) fn case_alias_heap_v2(&self) -> u64 {
        self.2.get().map_or(0, |index| index.lease.memory_v1())
    }''')
edit(p,'''    pub fn set(&mut self, ledger: crate::palw_native_resource_v1::ReservedKernelLedgerV1) {
        self.0''','''    pub fn set(&mut self, ledger: crate::palw_native_resource_v1::ReservedKernelLedgerV1) {
        self.2 = std::sync::OnceLock::new();
        self.0''')
edit(p,'''        ledger.clear_flat_conformance_classes_v9();
        self.0''','''        ledger.clear_flat_conformance_classes_v9();
        self.2 = std::sync::OnceLock::new();
        self.0''')
edit(p,'''    pub(crate) fn ledger_native_projection_checked_v9(''','''    pub(crate) fn has_legacy_case_alias_v2(
        &self,
        claim: &[u8; 64],
        job: &[u8; 64],
    ) -> Result<bool, PalwKernelLedgerProjectionErrorV1> {
        if let Some(index) = self.ledger_cache.2.get() {
            return Ok(index.contains(claim, job));
        }
        let ledger = self.ledger_native_projection_checked_v9()?;
        let index = KernelCaseAliasesV2::build(&ledger)
            .map_err(crate::palw_native_resource_v1::NativeDecodeErrorV1::Resource)?;
        let aliased = index.contains(claim, job);
        // A concurrent initializer sees the same immutable rows. In the race
        // the duplicate reservation is returned by dropping the losing Arc.
        let _ = self.ledger_cache.2.set(std::sync::Arc::new(index));
        Ok(aliased)
    }

    pub(crate) fn ledger_native_projection_checked_v9(''')
p='palw_state_v2/positive_assignment_case.rs'
edit(p,'''    // Real typed projection owns its native allocation/decoder; unsupported or
    // missing projection is an error, never an empty kernel ledger.
    let ledger = route
        .ledger_native_projection_checked_v9()
        .map_err(|why| crate::palw_kernel_route_v1::kernel_ledger_projection_state_error_v1(why, |_| missing()))?;
    let claim = result.claim_id().0.0;
    let job = result.job.0;
    if ledger.claims.contains_key(&claim)
        || ledger.claims.values().any(|row| row.job_id == job)
        || ledger.jobs.contains_key(&job)
        || ledger.pipeline_jobs.contains_key(&job)
        || ledger.job_claims.contains_key(&job)
        || ledger.job_claims.values().any(|id| *id == claim)
        || ledger.job_escrows.contains_key(&job)
        || ledger.seals.range((job, [0; 64])..=(job, [u8::MAX; 64])).next().is_some()
        || ledger.proof_seals.range((claim, [0; 64])..=(claim, [u8::MAX; 64])).next().is_some()
        || ledger.opv.claims.contains_key(&claim)
    {''','''    if route.has_legacy_case_alias_v2(&claim.as_bytes(), &job.as_bytes())
        .map_err(|why| crate::palw_kernel_route_v1::kernel_ledger_projection_state_error_v1(why, |_| missing()))?
    {''')
p='palw_native_resource_v1/typed.rs'
edit(p,'''        self.native_ledger_ref_v1().map_or_else(NativeCoverageV1::zero, |ledger| {
            ledger.native_heap_v1(path).add::<Self>(
                NativeCoverageV1::Bounded {
                    bytes: (size_of::<crate::palw_native_resource_v1::ReservedKernelLedgerV1>() + size_of::<[usize; 3]>()) as u64,
                },
                path,
            )
        })''','''        self.native_ledger_ref_v1().map_or_else(NativeCoverageV1::zero, |ledger| {
            ledger.native_heap_v1(path).add::<Self>(
                NativeCoverageV1::Bounded {
                    bytes: (size_of::<crate::palw_native_resource_v1::ReservedKernelLedgerV1>() + size_of::<[usize; 3]>()) as u64,
                },
                path,
            )
        }).add::<Self>(NativeCoverageV1::Bounded { bytes: self.case_alias_heap_v2() }, path)''')
