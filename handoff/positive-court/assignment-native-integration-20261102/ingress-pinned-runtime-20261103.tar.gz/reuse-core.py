from pathlib import Path
import json, os, runpy, subprocess
out = Path(__file__).resolve().parent
build = json.loads((out / 'ingress-claim-runtime.json').read_text())
run = runpy.run_path('handoff/positive-court/legacy-native-history-20261102/operator-scripts/native-history-controller-20261102.py')['run']
run.__globals__['out'] = out
assert run.__globals__['snapshot']() == build['source_before'] == build['source_after']
assert build['exit_code'] == 0 and not build['remaining_pg_members']
events = [json.loads(l) for l in (out / 'ingress-claim-runtime.log').read_text().splitlines() if l.startswith('{')]
artifact, = [e for e in events if e.get('target', {}).get('name') == 'kaspa_consensus_core' and e.get('executable')]
exe = Path(artifact['executable'])
sha = run.__globals__['sha']
pin = sha(exe)
for label, test in [
    ('ingress-job-runtime-pinned', 'positive_job_projection_tracks_result_install_remove_and_cold_decode'),
    ('ingress-staged-runtime-pinned', 'staged_alias_probes_cover_subject_namespaces_and_boundaries'),
    ('ingress-legacy-index-runtime-pinned', 'native_claim_job_lookup_tracks_repeated_jobs_and_delta_undo'),
    ('ingress-gate-c-runtime-pinned', 'p_terminal_case_requires_its_exact_result_scope_and_liability'),
]:
    result = run(label, [str(exe), test, '--test-threads=1'], 120, 750 * 1024**2, 20 * 1024**3, build['extra_environment'])
    assert result['exit_code'] == 0 and result['test_counts'] == [(1, 0, 0)], label
    assert sha(exe) == pin
(out / 'ingress-core-runtime-binary.json').write_text(json.dumps({'path': str(exe), 'sha256': pin, 'profile': artifact['profile']}, indent=2) + '\n')
