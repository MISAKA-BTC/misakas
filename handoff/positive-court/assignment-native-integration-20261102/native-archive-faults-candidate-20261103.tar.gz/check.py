from pathlib import Path
import subprocess

stage=Path(__file__).resolve().parent
s=(stage/'positive_assignment_archive.rs').read_text()
start=s.index('#[derive(Debug)]\npub(in crate::pipeline::virtual_processor) enum NativeAssignmentArchiveErrorV2')
end=s.index('/// The original relay registration',start)
fault=s[start:end].replace('pub(in crate::pipeline::virtual_processor) ', '')
a=s.index("impl RelayCarrierReplayV2<'_> {")
b=s.index('/// Mutable projection',a)
charge=s[a:b].replace("impl RelayCarrierReplayV2<'_> {", "impl RelayCarrierReplayV2 {")
test=s[s.index('#[cfg(test)]\nmod archive_fault_tests'):]
fixture='''
use kaspa_database::prelude::StoreError;
type BlockHash = kaspa_hashes::Hash64;
#[derive(Debug)]
struct NativeCoverageV1;
impl NativeCoverageV1 {
    fn unsupported<T>(_component: &str, _reason: &str) -> Self {
        let _ = core::marker::PhantomData::<T>;
        Self
    }
}
struct VirtualStateProcessor;
struct RelayCarrierReplayV2 { remaining_reads: u64, remaining_work: u64 }

#[test]
fn over_budget_does_not_partially_debit_replay() {
    let mut replay = RelayCarrierReplayV2 { remaining_reads: 7, remaining_work: 10 };
    assert!(matches!(replay.charge(5, 11), Err(NativeAssignmentArchiveErrorV2::Unavailable(_))));
    assert_eq!((replay.remaining_reads, replay.remaining_work), (7, 10));
    assert!(matches!(replay.charge(8, 1), Err(NativeAssignmentArchiveErrorV2::Unavailable(_))));
    assert_eq!((replay.remaining_reads, replay.remaining_work), (7, 10));
    replay.charge(7, 10).unwrap();
    assert_eq!((replay.remaining_reads, replay.remaining_work), (0, 0));
}
'''
wrapper=stage/'archive-fault-probe.rs'
wrapper.write_text(fixture+fault+charge+test)
target=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug')
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
command=[str(rustc),'--edition=2024','--test','-L',f'dependency={target/"deps"}','-A','dead_code']
for name,suffix in {'kaspa_hashes':'763ecc08d728f51f','kaspa_database':'2cf8dbfd3147b2cd','bincode':'48eb714cc5ca0815'}.items():
    command.extend(['--extern',f'{name}={target}/deps/lib{name}-{suffix}.rlib'])
binary=stage/'archive-fault-probe'
subprocess.run([*command,str(wrapper),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
