from pathlib import Path
p=Path(__file__).resolve().parent/'positive_assignment_archive.rs'
s=p.read_text()
def edit(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old)
    s=s.replace(old,new)
edit('use misaka_palw_positive_contract::{','use kaspa_database::prelude::StoreError;\nuse misaka_palw_positive_contract::{')
edit('    Resource(NativeCoverageV1),\n}\n/// The original relay registration','''    Resource(NativeCoverageV1),
}

fn archive_store_fault_v2(error: StoreError, component: &'static str) -> NativeAssignmentArchiveErrorV2 {
    use NativeAssignmentArchiveErrorV2 as E;
    match error {
        StoreError::DataInconsistency(_) | StoreError::DeserializationError(_) => E::Invalid(component),
        StoreError::LocalResourceUnavailable(why) => {
            E::Resource(NativeCoverageV1::unsupported::<VirtualStateProcessor>(component, &why))
        }
        _ => E::Unavailable(component),
    }
}

/// The original relay registration''')
edit('''        self.remaining_reads = self.remaining_reads.checked_sub(reads).ok_or(E::Invalid("relay replay read cap"))?;
        self.remaining_work = self.remaining_work.checked_sub(work).ok_or(E::Invalid("relay replay work cap"))?;''','''        let remaining_reads = self.remaining_reads.checked_sub(reads).ok_or(E::Unavailable("relay replay read cap"))?;
        let remaining_work = self.remaining_work.checked_sub(work).ok_or(E::Unavailable("relay replay work cap"))?;
        self.remaining_reads = remaining_reads;
        self.remaining_work = remaining_work;''')
for msg in [
    'bounded original acceptance data','bounded original acceptance archive','bounded original UTXO archive',
    'bounded original relay acceptance archive','bounded original relay UTXO archive',
    'bounded original relay payer delta','rooted original Open bytes','Case relay original Open bytes',
]:
    edit(f'.map_err(|_| E::Unavailable("{msg}"))',f'.map_err(|error| archive_store_fault_v2(error, "{msg}"))')
edit('.map_err(|_| NativeAssignmentArchiveErrorV2::Unavailable("bounded original native delta"))',
    '.map_err(|error| archive_store_fault_v2(error, "bounded original native delta"))')
edit('        use NativeAssignmentArchiveErrorV2 as E;\n        // Charge both the block framing scan',
    '        // Charge both the block framing scan')
edit('''            .map_err(|error| match error {
                kaspa_database::prelude::StoreError::DataInconsistency(_) => E::Invalid("archived transaction framing"),
                _ => E::Unavailable("bounded archived transaction"),
            })?;''','''            .map_err(|error| archive_store_fault_v2(error, "bounded archived transaction"))?;''')
s+='''

#[cfg(test)]
mod archive_fault_tests {
    use super::*;

    #[test]
    fn archive_store_faults_distinguish_corruption_capacity_and_missing_record() {
        const COMPONENT: &str = "fixture history";
        use NativeAssignmentArchiveErrorV2 as E;
        assert!(matches!(
            archive_store_fault_v2(StoreError::DataInconsistency("bad framing".into()), COMPONENT),
            E::Invalid(COMPONENT)
        ));
        assert!(matches!(
            archive_store_fault_v2(StoreError::DeserializationError(Box::new(bincode::ErrorKind::Custom("bad wire".into()))), COMPONENT),
            E::Invalid(COMPONENT)
        ));
        assert!(matches!(
            archive_store_fault_v2(StoreError::LocalResourceUnavailable("heap cap".into()), COMPONENT),
            E::Resource(_)
        ));
        let key = kaspa_database::prelude::DbKey::new(&[0], BlockHash::from_bytes([0; 64]));
        assert!(matches!(archive_store_fault_v2(StoreError::KeyNotFound(key), COMPONENT), E::Unavailable(COMPONENT)));
    }
}
'''
p.write_text(s)
