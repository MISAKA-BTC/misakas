#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends xfsprogs clang libclang-dev protobuf-compiler pkg-config
apt-get clean
rm -rf /var/lib/apt/lists/*
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_DIR=/build RAYON_NUM_THREADS=1
uname -m
rustc --version
ulimit -s
cd /src
sha256sum Cargo.lock
mkdir -p /test-quota/fs
loop=''
cleanup() {
    if mountpoint -q /test-quota/fs; then umount /test-quota/fs; fi
    if [[ -n "$loop" ]]; then losetup -d "$loop"; fi
}
trap cleanup EXIT
truncate -s 320M /test-quota/xfs.img
loop=$(losetup --find --show /test-quota/xfs.img)
mkfs.xfs -f "$loop" >/dev/null
mount -o prjquota "$loop" /test-quota/fs
mkdir /test-quota/fs/test
xfs_quota -x -c 'project -s -p /test-quota/fs/test 4197' /test-quota/fs
xfs_quota -x -c 'limit -p bhard=128m 4197' /test-quota/fs
xfs_quota -x -c 'report -p -h' /test-quota/fs
df -h /src /build
cargo test --locked -p kaspa-consensus --lib --no-run
export TMPDIR=/test-quota/fs/test
cargo test --offline --locked -p kaspa-consensus --lib -- positive_initial_relay_burns_once_through_the_native_node --nocapture --test-threads=1
