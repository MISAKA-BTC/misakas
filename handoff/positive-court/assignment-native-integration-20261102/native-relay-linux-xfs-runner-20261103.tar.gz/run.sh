#!/bin/bash
set -euo pipefail
base=/tmp/misaka-native-relay-linux-xfs
name=misaka-a0-native-relay-xfs-45927210f
source_commit=45927210f
dock() { docker --context colima-t12-oom-build "$@"; }
minimum_kib=1048576
cleanup() {
    if [[ -n "${monitor:-}" ]]; then kill "$monitor" 2>/dev/null || :; fi
    dock rm -f "$name" >/dev/null 2>&1 || :
}
if dock inspect --type container "$name" >/dev/null 2>&1; then exit 2; fi
dock run -d --name "$name" --privileged --platform linux/amd64 --memory 8500m --memory-swap 8500m --cpus 3 \
    --tmpfs /build:rw,exec,size=5g --tmpfs /test-quota:rw,exec,size=450m \
    rust:1.93.0-bookworm sleep infinity
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
(
    while sleep 5; do
        avail=$(df -k "$base" | awk 'NR==2 {print $4}')
        if [[ "$avail" -lt "$minimum_kib" ]]; then
            echo "Host free capacity ${avail} KiB is below ${minimum_kib} KiB" >&2
            dock stop --time 5 "$name" >&2 || :
            exit 1
        fi
    done
) &
monitor=$!
git rev-parse "$source_commit"
dock exec "$name" mkdir /src
git archive --format=tar "$source_commit" | dock exec -i "$name" tar --exclude=handoff -xf - -C /src
dock exec -i "$name" /bin/bash -s < "$base/inside.sh"
