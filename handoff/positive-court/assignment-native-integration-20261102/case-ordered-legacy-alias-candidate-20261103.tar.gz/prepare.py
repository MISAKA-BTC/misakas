from pathlib import Path

s=Path(__file__).resolve().parent
p=s/'consensus/core/src/palw_state_v2/positive_assignment_case.rs'
src=p.read_text()
helper=src[src.index('fn has_legacy_staged_alias_v2'):src.index('/// Exact native aliases must be absent')]
test=src[src.index('#[cfg(test)]\nmod tests'):]
keys=Path('consensus/core/src/palw_staged_court_state_v1.rs').read_text()
keys=keys[keys.index('pub enum PalwStagedCourtKeyV1'):keys.index('#[derive(Clone, Debug, PartialEq',keys.index('pub enum PalwStagedCourtKeyV1'))]
keys=keys.replace('crate::palw_state_v2::PalwCourtSideV1','PalwCourtSideV1')
driver='''// Order-only isolated harness. Core's actual key variant declaration is
// copied below. Removed serialization and application fields are irrelevant
// to the comparisons under test.
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct Hash64([u8; 64]);
impl Hash64 { const fn from_bytes(bytes: [u8;64]) -> Self { Self(bytes) } }
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct TransactionOutpoint { pub transaction_id: Hash64, pub index: u32 }
impl TransactionOutpoint { const fn new(transaction_id: Hash64, index: u32) -> Self { Self { transaction_id, index } } }
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct PalwBondKeyV2(pub TransactionOutpoint);
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum PalwCourtSideV1 { Challenger, Executor }
pub const PALW_BOND_KEY_V2_MIN: PalwBondKeyV2 =
    PalwBondKeyV2(TransactionOutpoint::new(Hash64::from_bytes([0; 64]), 0));
mod palw_staged_court_state_v1 {
    use super::{Hash64, PalwBondKeyV2, PalwCourtSideV1};
    #[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
''' + keys + '}\n' + helper + test
(s/'alias-test.rs').write_text(driver)
