from pathlib import Path
base=Path(__file__).resolve().parent/'consensus/core/src'
def edit(path, old, new):
    p=base/path
    s=p.read_text()
    assert s.count(old)==1, (path,old)
    p.write_text(s.replace(old,new))

edit('palw_state_v2.rs','    claims: BTreeMap<Hash64, PalwClaimStateV2>,\n',
'''    claims: BTreeMap<Hash64, PalwClaimStateV2>,
    // Derived nonzero job identities, including claims retained after termination.
    claims_by_job: BTreeSet<(Hash64, Hash64)>,
''')
edit('palw_state_v2.rs','        PalwDeltaEntryV2::Claim { key, old, new } => swap_write!(state.claims, key, old, new),',
'''        PalwDeltaEntryV2::Claim { key, old, new } => {
            let (expected, install) = if revert { (new, old) } else { (old, new) };
            if state.claims.get(key) != expected.as_ref() {
                return Err(PalwStateV2Error::DeltaMismatch("an entry's old value is not this state's value"));
            }
            state.replace_claim_row_v2(*key, install.clone());
        }''')
edit('palw_state_v2.rs','            claims: self.claims,\n',
'''            claims_by_job: self.claims.iter().filter_map(|(id, claim)| {
                (claim.job_identity != ZERO_HASH64).then_some((claim.job_identity, *id))
            }).collect(),
            claims: self.claims,
''')
edit('palw_state_v2/chain_state.rs','            claims: BTreeMap::new(),\n',
    '            claims: BTreeMap::new(),\n            claims_by_job: BTreeSet::new(),\n')
edit('palw_state_v2/chain_state.rs','    pub fn claim(&self, id: &Hash64)',
'''    pub(super) fn has_claim_for_job_v2(&self, job: Hash64) -> bool {
        if job == ZERO_HASH64 {
            return self.claims.len() > self.claims_by_job.len();
        }
        let last = Hash64::from_bytes([u8::MAX; 64]);
        self.claims_by_job.range((job, ZERO_HASH64)..=(job, last)).next().is_some()
    }

    pub(super) fn replace_claim_row_v2(&mut self, key: Hash64, new: Option<PalwClaimStateV2>) -> Option<PalwClaimStateV2> {
        let new_job = new.as_ref().map(|row| row.job_identity).filter(|job| *job != ZERO_HASH64);
        let old = match new {
            Some(row) => self.claims.insert(key, row),
            None => self.claims.remove(&key),
        };
        let old_job = old.as_ref().map(|row| row.job_identity).filter(|job| *job != ZERO_HASH64);
        if old_job != new_job {
            if let Some(job) = old_job {
                self.claims_by_job.remove(&(job, key));
            }
            if let Some(job) = new_job {
                self.claims_by_job.insert((job, key));
            }
        }
        old
    }

    pub fn claim(&self, id: &Hash64)''')
edit('palw_state_v2/chain_state.rs','''        match claim {
            Some(claim) => self.claims.insert(claim_id, claim),
            None => self.claims.remove(&claim_id),
        };''','''        self.replace_claim_row_v2(claim_id, claim);''')
edit('palw_state_v2/chain_state.rs','        self.claims.insert(claim_id, claim);',
'''        self.replace_claim_row_v2(claim_id, Some(claim));''')
edit('palw_state_v2/transition_builder.rs','''        self.reserve_map_journal_v1(&key, &new, !self.state.claims.contains_key(&key), "native claims writer")?;''',
'''        self.reserve_map_journal_v1(&key, &new, !self.state.claims.contains_key(&key), "native claims writer")?;
        let new_job_membership = new.as_ref().is_some_and(|claim| {
            claim.job_identity != ZERO_HASH64
                && self.state.claims.get(&key).is_none_or(|old| old.job_identity != claim.job_identity)
        });
        self.reserve_index_members_v1::<(Hash64, Hash64), ()>(u64::from(new_job_membership), "native claim job index")?;''')
edit('palw_state_v2/transition_builder.rs','''        let old = match &new {
            Some(record) => self.state.claims.insert(key, record.clone()),
            None => self.state.claims.remove(&key),
        };''','''        let old = self.state.replace_claim_row_v2(key, new.clone());''')
edit('palw_state_v2/positive_assignment_case.rs','state.claims.values().any(|row| row.job_identity == job)',
     'state.has_claim_for_job_v2(job)')
edit('palw_native_resource_v1/private/palw_state_v2.rs','capabilities, claims, panels',
     'capabilities, claims, claims_by_job, panels')
edit('palw_native_resource_v1/wire_generated.rs',
     'BTreeMap<crate::Hash64, crate::palw_state_v2::PalwClaimStateV2>, BTreeMap<crate::Hash64, crate::palw_state_v2::PalwPanelStateV2>',
     'BTreeMap<crate::Hash64, crate::palw_state_v2::PalwClaimStateV2>, BTreeSet<(crate::Hash64, crate::Hash64)>, BTreeMap<crate::Hash64, crate::palw_state_v2::PalwPanelStateV2>')
edit('palw_native_resource_v1/private/wire_carriage.rs','''    let n = count("court_sessions", false)?;
    sum = sum.allocation(n, std::mem::size_of::<crate::palw_native_resource_v1::typed::BTreeNodeEnvelopeV1<crate::Hash64, u32>>())?;''',
'''    let n = count("claims", false)?;
    sum = sum.allocation(
        n,
        std::mem::size_of::<crate::palw_native_resource_v1::typed::BTreeNodeEnvelopeV1<(crate::Hash64, crate::Hash64), ()>>(),
    )?;
    let n = count("court_sessions", false)?;
    sum = sum.allocation(n, std::mem::size_of::<crate::palw_native_resource_v1::typed::BTreeNodeEnvelopeV1<crate::Hash64, u32>>())?;''')
