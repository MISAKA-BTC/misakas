from pathlib import Path
import subprocess

stage=Path(__file__).resolve().parent
src=stage/'consensus/core/src'
chain=(src/'palw_state_v2/chain_state.rs').read_text()
methods=chain[chain.index('    pub(super) fn has_claim_for_job_v2'):chain.index('    pub fn claim(&self, id:')]
parent=(src/'palw_state_v2.rs').read_text()
a=parent.index('        PalwDeltaEntryV2::Claim { key, old, new } => {')
b=parent.index('        PalwDeltaEntryV2::Payout',a)
apply=parent[a:b]
case=(src/'palw_state_v2/positive_assignment_case.rs').read_text()
a=case.index('    #[test]\n    fn native_claim_job_lookup_tracks')
b=case.index('    #[test]\n    fn staged_alias',a)
test=case[a:b].replace(
    'let unset = <PalwClaimStateV2 as borsh::BorshDeserialize>::deserialize(&mut &[0u8; 8192][..]).unwrap();',
    'let unset = PalwClaimStateV2 { job_identity: ZERO_HASH64 };'
)
code='''
use std::collections::{BTreeMap, BTreeSet};
use kaspa_hashes::Hash64;
const ZERO_HASH64: Hash64 = Hash64::from_bytes([0; 64]);
#[derive(Clone, Debug, PartialEq, Eq)]
struct PalwClaimStateV2 { job_identity: Hash64 }
#[derive(Default)]
struct PalwChainStateV2 {
    claims: BTreeMap<Hash64, PalwClaimStateV2>,
    claims_by_job: BTreeSet<(Hash64, Hash64)>,
}
impl PalwChainStateV2 {
    fn genesis() -> Self { Self::default() }
    fn state_root(&self) -> BTreeMap<Hash64, PalwClaimStateV2> { self.claims.clone() }
}
enum PalwDeltaEntryV2 { Claim { key: Hash64, old: Option<PalwClaimStateV2>, new: Option<PalwClaimStateV2> } }
#[derive(Debug)]
enum PalwStateV2Error { DeltaMismatch(&'static str) }
mod implementation {
use super::*;
impl PalwChainStateV2 {
''' + methods + '''
}
pub(super) fn apply_delta_entry(state: &mut PalwChainStateV2, entry: &PalwDeltaEntryV2, revert: bool) -> Result<(), PalwStateV2Error> {
match entry {
''' + apply + '''
}
Ok(())
}
}
use implementation::apply_delta_entry;
''' + test
probe=stage/'index-probe.rs'
probe.write_text(code)
deps=Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug/deps')
hashes=deps/'libkaspa_hashes-763ecc08d728f51f.rlib'
rustc=Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
binary=stage/'index-probe'
subprocess.run([str(rustc),'--edition=2024','--test','-A','dead_code','-L',f'dependency={deps}','--extern',f'kaspa_hashes={hashes}',str(probe),'-o',str(binary)],check=True)
subprocess.run([str(binary)],check=True)
