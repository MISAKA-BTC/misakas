from pathlib import Path
base=Path(__file__).resolve().parent/'consensus/core/src'
p=base/'palw_state_v2.rs'
s=p.read_text()
s=s.replace('        let mut state = PalwChainStateV2 {','''        let mut claims_by_job = BTreeSet::new();
        for (id, claim) in &self.claims {
            if claim.job_identity != ZERO_HASH64 {
                claims_by_job.insert((claim.job_identity, *id));
            }
        }
        let mut funded_escrows_by_claim = BTreeSet::new();
        for (id, row) in &self.funded_escrows {
            funded_escrows_by_claim.insert((row.claim, *id));
        }
        let mut state = PalwChainStateV2 {''')
s=s.replace('''            claims_by_job: self.claims.iter().filter_map(|(id, claim)| {
                (claim.job_identity != ZERO_HASH64).then_some((claim.job_identity, *id))
            }).collect(),''','''            claims_by_job,''')
s=s.replace('''            funded_escrows_by_claim: self.funded_escrows.iter().map(|(id, row)| (row.claim, *id)).collect(),''',
            '''            funded_escrows_by_claim,''')
p.write_text(s)
p=base/'palw_state_v2/positive_assignment_case.rs'
s=p.read_text()
a='    #[test]\n    fn staged_alias_probes_cover_subject_namespaces_and_boundaries()'
assert s.count(a)==1
s=s.replace(a,'''    #[test]
    fn native_claim_job_lookup_tracks_repeated_jobs_and_delta_undo() {
        let job = Hash64::from_bytes([3; 64]);
        let other = Hash64::from_bytes([4; 64]);
        let first = ZERO_HASH64;
        let last = Hash64::from_bytes([u8::MAX; 64]);
        let mut state = PalwChainStateV2::genesis();
        let initial_root = state.state_root();
        let unset = <PalwClaimStateV2 as borsh::BorshDeserialize>::deserialize(&mut &[0u8; 8192][..]).unwrap();
        assert_eq!(unset.job_identity, ZERO_HASH64);
        let mut named = unset.clone();
        named.job_identity = job;

        let one = PalwDeltaEntryV2::Claim { key: first, old: None, new: Some(unset.clone()) };
        let two = PalwDeltaEntryV2::Claim { key: last, old: None, new: Some(named.clone()) };
        let rename = PalwDeltaEntryV2::Claim { key: first, old: Some(unset), new: Some(named.clone()) };
        let remove = PalwDeltaEntryV2::Claim { key: last, old: Some(named), new: None };
        apply_delta_entry(&mut state, &one, false).unwrap();
        assert!(state.has_claim_for_job_v2(ZERO_HASH64));
        apply_delta_entry(&mut state, &two, false).unwrap();
        apply_delta_entry(&mut state, &rename, false).unwrap();
        apply_delta_entry(&mut state, &remove, false).unwrap();
        assert!(state.has_claim_for_job_v2(job));
        assert!(!state.has_claim_for_job_v2(ZERO_HASH64));
        assert!(!state.has_claim_for_job_v2(other));

        apply_delta_entry(&mut state, &remove, true).unwrap();
        apply_delta_entry(&mut state, &rename, true).unwrap();
        assert!(state.has_claim_for_job_v2(ZERO_HASH64));
        assert!(state.has_claim_for_job_v2(job));
        apply_delta_entry(&mut state, &two, true).unwrap();
        assert!(!state.has_claim_for_job_v2(job));
        apply_delta_entry(&mut state, &one, true).unwrap();
        assert!(!state.has_claim_for_job_v2(ZERO_HASH64));
        assert_eq!(state.state_root(), initial_root);
    }

'''+a)
p.write_text(s)
