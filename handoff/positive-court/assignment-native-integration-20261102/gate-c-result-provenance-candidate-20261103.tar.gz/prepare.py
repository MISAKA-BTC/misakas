from pathlib import Path
root = Path(__file__).resolve().parent / 'consensus/core/src'
def change(file, old, new):
 p=root/file
 s=p.read_text()
 assert s.count(old)==1,(file,old,s.count(old))
 p.write_text(s.replace(old,new))

change('palw_positive_certification_v2.rs',
'''/// Failure-only pure projection. Positive certification requires the concrete''',
'''/// Bind the certification header to the original accepted Result row and
/// its current Case. The Case status is independent of identity here.
pub(crate) fn check_positive_certification_result_links_v2(
    header: &PositiveCertificationHeaderV2,
    result: &ResultRow,
    case: &CaseRow,
) -> Result<(), ContractError> {
    positive_certification_case_live_v2(header, case)?;
    let commit = &result.result;
    if header.commit_origin != result.origin
        || header.assignment.0 != result.role_assignment.digest
        || header.worker_key != result.miner_key
        || header.subject != misaka_palw_positive_contract::native::certification_subject(commit)
        || header.claim != commit.claim_id()
        || header.result != commit.id()
        || header.case != commit.case_id()
        || header.scope != commit.scope
    {
        return Err(ContractError::Identity);
    }
    Ok(())
}

/// Failure-only pure projection. Positive certification requires the concrete''')

f='palw_state_v2/positive_assignment_certification.rs'
change(f,
'''        session.ensure_current(&self.state, ctx)?;
        let subject = certification_subject(session.result());
        let mut owned = read(&self.state, subject, 0)?;
        let row = &mut owned.row;
        check_session(self, ctx, row, session)?;''',
'''        let subject = certification_subject(session.result());
        let mut owned = read(&self.state, subject, 0)?;
        let row = &mut owned.row;
        let case = check_session(self, ctx, row, session)?;''')
change(f,
'''            let case = PositiveRowsV2::new(&self.state).bundle(row.fixed.header.claim).map_err(refuse)?.case;
            if ctx.daa_score >= prosecution && ctx.daa_score >= case.maturity_daa {''',
'''            if ctx.daa_score >= prosecution && ctx.daa_score >= case.maturity_daa {''')
change(f,
'''        session.ensure_current(&self.state, ctx)?;
        let closed = session.pending_fraud_bound();''',
'''        let closed = session.pending_fraud_bound();''')
change(f,
'''        if session.assignment() != row.fixed.header.assignment || session.result().id() != row.fixed.header.result {
            return Err(refuse("foreign native closure session"));
        }
        let bundle = PositiveRowsV2::new(&self.state).bundle(row.fixed.header.claim).map_err(refuse)?;
        if ctx.daa_score < bundle.case.maturity_daa || bundle.case.unresolved_fraud != 0 {
            return Err(refuse("actual native Case remains liable"));
        }
        if matches!(bundle.case.status, ClaimStatus::ClaimRefuted | ClaimStatus::Revoked) {
            return Err(unavailable("actual P attestor deterministic charge owner missing; no release"));
        }
        if !matches!(bundle.case.status, ClaimStatus::PositivePassed | ClaimStatus::EndedUnverified) {''',
'''        let case = bound_session_case(self, ctx, row, session)?;
        if ctx.daa_score < case.maturity_daa || case.unresolved_fraud != 0 {
            return Err(refuse("actual native Case remains liable"));
        }
        if matches!(case.status, ClaimStatus::ClaimRefuted | ClaimStatus::Revoked) {
            return Err(unavailable("actual P attestor deterministic charge owner missing; no release"));
        }
        if !matches!(case.status, ClaimStatus::PositivePassed | ClaimStatus::EndedUnverified) {''')
change(f,
'''fn check_session(
    builder: &TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    row: &PositiveCertificationRowV2,
    session: &NativeAssignedCaseSessionV2,
) -> Result<(), PalwStateV2Error> {
    session.ensure_current(&builder.state, ctx)?;
    let h = &row.fixed.header;
    if &h.policy != session.certification_policy() {
        return Err(refuse("P policy differs from original authenticated native admission"));
    }
    row.authenticate_votes(session.result()).map_err(refuse)?;
    if session.assignment() != h.assignment
        || session.result().id() != h.result
        || session.result().case_id() != h.case
        || session.result().scope != h.scope
    {
        return Err(refuse("foreign native checked session"));
    }
    let fact''',
'''fn bound_session_case(
    builder: &TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    row: &PositiveCertificationRowV2,
    session: &NativeAssignedCaseSessionV2,
) -> Result<CaseRow, PalwStateV2Error> {
    let (assignment, bundle) = session.ensure_current(&builder.state, ctx)?;
    let h = &row.fixed.header;
    if &h.policy != session.certification_policy() {
        return Err(refuse("P policy differs from original authenticated native admission"));
    }
    if session.assignment() != h.assignment
        || h.worker != assignment.bundle.terms.worker
        || h.worker_key != assignment.worker_key
        || h.worker_gain != assignment.bundle.terms.worker_reward
    {
        return Err(refuse("P worker or Assignment differs from the native checked session"));
    }
    check_positive_certification_result_links_v2(h, &bundle.result, &bundle.case).map_err(refuse)?;
    row.authenticate_votes(session.result()).map_err(refuse)?;
    Ok(bundle.case)
}

fn check_session(
    builder: &TransitionBuilder<'_>,
    ctx: &PalwBlockContextV2,
    row: &PositiveCertificationRowV2,
    session: &NativeAssignedCaseSessionV2,
) -> Result<CaseRow, PalwStateV2Error> {
    let case = bound_session_case(builder, ctx, row, session)?;
    let h = &row.fixed.header;
    let fact''')
change(f,
'''    let bundle = PositiveRowsV2::new(&builder.state).bundle(h.claim).map_err(refuse)?;
    if bundle.case.positive_witness != Some(fact.witness())
        || bundle.case.coverage != fact.terminal().descriptor()
        || bundle.case.witness_status != WitnessStatus::Complete
        || bundle.case.status != ClaimStatus::PositivePassed''',
'''    if case.positive_witness != Some(fact.witness())
        || case.coverage != fact.terminal().descriptor()
        || case.witness_status != WitnessStatus::Complete
        || case.status != ClaimStatus::PositivePassed''')
change(f,
'''    if closed.has_pending() || bundle.case.unresolved_fraud != 0 {
        return Err(refuse("native case has pending fraud"));
    }
    Ok(())''',
'''    if closed.has_pending() || case.unresolved_fraud != 0 {
        return Err(refuse("native case has pending fraud"));
    }
    Ok(case)''')
change(f,
'''    check_session(builder, ctx, row, session)?;
    if !row.fixed.outcome''',
'''    let case = check_session(builder, ctx, row, session)?;
    if !row.fixed.outcome''')
change(f,
'''    let bundle = PositiveRowsV2::new(&builder.state).bundle(row.fixed.header.claim).map_err(refuse)?;
    let prosecution''',
'''    let prosecution''')
change(f,
'''    if ctx.daa_score < bundle.case.maturity_daa || ctx.daa_score < prosecution {''',
'''    if ctx.daa_score < case.maturity_daa || ctx.daa_score < prosecution {''')

change('palw_state_v2/positive_assignment_case.rs',
'''    pub(super) fn ensure_current(&self, state: &PalwChainStateV2, ctx: &PalwBlockContextV2) -> Result<(), PalwStateV2Error> {''',
'''    pub(super) fn ensure_current(
        &self,
        state: &PalwChainStateV2,
        ctx: &PalwBlockContextV2,
    ) -> Result<(AssignmentRow, PositiveRowBundleV2), PalwStateV2Error> {''')
change('palw_state_v2/positive_assignment_case.rs',
'''        reject_legacy_aliases(state, &a, self.result)?;
        Ok(())''',
'''        reject_legacy_aliases(state, &a, self.result)?;
        Ok((a, bundle))''')
