
#![allow(dead_code)]
use borsh::{BorshSerialize, BorshDeserialize};
use misaka_palw_positive_contract::{ContractError, assignment::AssignmentId, identity::*, messages::*, rows::*};
#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct PalwSecurityCertificationPolicyV1 {
    pub m: u16,
    pub k: u16,
    /// Negative positions at which a claim is vetoed; `0` disables the veto (the adopted m-of-k rule; a veto is proposal U-6).
    pub veto: u16,
    pub anchor_delay_spans: u64,
    pub attest_window_daa: u64,
    pub prosecution_window_daa: u64,
    /// From the commit: the latest DAA a draw may happen at; past it the claim is `Expired`.
    pub certify_by_daa: u64,
    pub verifier_maturity_daa: u64,
    pub verifier_min_collateral_sompi: u64,
    pub draws_per_epoch: u32,
    pub epoch_daa: u64,
}
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct PositiveCertificationHeaderV2 {
    pub version: u16,
    pub revision: u16,
    pub assignment: AssignmentId,
    pub subject: Digest,
    pub claim: ClaimId,
    pub result: ResultId,
    pub case: CaseId,
    pub scope: ChainScope,
    pub policy: PalwSecurityCertificationPolicyV1,
    pub policy_id: Digest,
    pub commit_origin: AcceptedOrigin,
    pub committed_span: Option<u64>,
    pub worker: NativeOutpoint,
    pub worker_operator: Digest,
    pub worker_key: [u8; PUBKEY_BYTES],
    pub worker_gain: u64,
    pub liability: AcceptedMaterial,
}
pub(crate) fn p_hash<T: BorshSerialize>(domain: &[u8], value: &T) -> Digest {
    struct Writer(blake2b_simd::State);
    impl std::io::Write for Writer {
        fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
            self.0.update(b);
            Ok(b.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    let mut w = Writer(blake2b_simd::Params::new().hash_length(64).key(domain).to_state());
    value.serialize(&mut w).expect("canonical P data serializes");
    Digest(w.0.finalize().as_bytes().try_into().expect("64"))
}
pub fn positive_certification_policy_id_v2(policy: &PalwSecurityCertificationPolicyV1) -> Digest {
    p_hash(b"misaka/positive/certification-policy/v2/r1", policy)
}
pub(crate) fn positive_certification_case_live_v2(
    header: &PositiveCertificationHeaderV2,
    case: &CaseRow,
) -> Result<bool, ContractError> {
    use misaka_palw_positive_contract::messages::ClaimStatus;

    if case.case != header.case
        || case.result != header.result
        || case.coverage.scope != header.scope
        || case.liability != header.liability
    {
        return Err(ContractError::Identity);
    }
    Ok(!matches!(case.status, ClaimStatus::ClaimRefuted | ClaimStatus::Revoked | ClaimStatus::EndedUnverified))
}

/// Bind the certification header to the original accepted Result row and
/// its current Case. The Case status is independent of identity here.
pub(crate) fn check_positive_certification_result_links_v2(
    header: &PositiveCertificationHeaderV2,
    result: &ResultRow,
    case: &CaseRow,
) -> Result<(), ContractError> {
    positive_certification_case_live_v2(header, case)?;
    let commit = &result.result;
    if header.commit_origin != result.origin
        || header.assignment.0 != result.role_assignment.digest
        || header.worker_key != result.miner_key
        || header.subject != misaka_palw_positive_contract::native::certification_subject(commit)
        || header.claim != commit.claim_id()
        || header.result != commit.id()
        || header.case != commit.case_id()
        || header.scope != commit.scope
    {
        return Err(ContractError::Identity);
    }
    Ok(())
}

fn d(n: u8) -> Digest {
    Digest([n; 64])
}
fn origin() -> AcceptedOrigin {
    AcceptedOrigin {
        accepting_block: NativeHash64([1; 64]),
        carrier_block: NativeHash64([2; 64]),
        carrier_transaction: NativeHash64([3; 64]),
        accepted_tx_ordinal: 4,
        event_ordinal: 5,
        accepted_daa: 6,
        accepted_blue_score: 7,
    }
}
fn origin_at(event_ordinal: u32) -> AcceptedOrigin {
    // All fixture events share one actual accepting block and therefore the
    // same native DAA/blue-score coordinates. Only event order advances.
    AcceptedOrigin { event_ordinal, ..origin() }
}
fn material_at(event_ordinal: u32) -> AcceptedMaterial {
    AcceptedMaterial { origin: origin_at(event_ordinal), digest: d(8) }
}
fn material() -> AcceptedMaterial {
    material_at(origin().event_ordinal)
}
fn coverage() -> CoverageRow {
    CoverageRow {
        witness: WitnessId(d(1)),
        case: CaseId(d(2)),
        result: ResultId(d(3)),
        plan: PlanId(d(4)),
        mandatory_relations: 10,
        next_relation: 0,
        frame_bytes: 0,
        signatures: 0,
        elements: 0,
        terms: 0,
        state: CoverageState::Checking,
        last_event: origin(),
    }
}
fn signed_bundle() -> (ClaimIndexRow, ResultRow, CaseRow, FundingRow, WitnessRow, CoverageRow) {
    signed_bundle_for_relations(10)
}

#[test]
fn p_terminal_case_requires_its_exact_result_scope_and_liability() {

    let (_, result, mut case, _, _, _) = signed_bundle();
    let r = &result.result;
    let policy = PalwSecurityCertificationPolicyV1 {
        m: 1,
        k: 1,
        veto: 0,
        anchor_delay_spans: 1,
        attest_window_daa: 5,
        prosecution_window_daa: 19,
        certify_by_daa: 7,
        verifier_maturity_daa: 3,
        verifier_min_collateral_sompi: 1,
        draws_per_epoch: 4,
        epoch_daa: 11,
    };
    let header = PositiveCertificationHeaderV2 {
        version: 2,
        revision: 1,
        assignment: misaka_palw_positive_contract::assignment::AssignmentId(result.role_assignment.digest),
        subject: misaka_palw_positive_contract::native::certification_subject(r),
        claim: r.claim_id(),
        result: r.id(),
        case: r.case_id(),
        scope: r.scope,
        policy,
        policy_id: positive_certification_policy_id_v2(&policy),
        commit_origin: result.origin,
        committed_span: Some(2),
        worker: NativeOutpoint { transaction: NativeHash64([82; 64]), index: 0 },
        worker_operator: d(83),
        worker_key: result.miner_key,
        worker_gain: 100,
        liability: case.liability,
    };
    assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(true));
    assert_eq!(check_positive_certification_result_links_v2(&header, &result, &case), Ok(()));
    let mut foreign = header.clone();
    foreign.commit_origin.accepted_tx_ordinal += 1;
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
    foreign = header.clone();
    foreign.assignment = misaka_palw_positive_contract::assignment::AssignmentId(d(81));
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
    foreign = header.clone();
    foreign.worker_key[0] ^= 1;
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
    foreign = header.clone();
    foreign.subject = d(84);
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
    for status in [ClaimStatus::ClaimRefuted, ClaimStatus::Revoked, ClaimStatus::EndedUnverified] {
        case.status = status;
        assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(false));
        assert_eq!(check_positive_certification_result_links_v2(&header, &result, &case), Ok(()));
        let mut other_output = r.clone();
        other_output.output = d(85);
        assert_eq!(other_output.case_id(), r.case_id());
        assert_ne!(other_output.id(), r.id());
        let other =
            CaseRow { result: other_output.id(), coverage: CoverageDescriptor { result: other_output.id(), ..case.coverage }, ..case };
        assert_eq!(positive_certification_case_live_v2(&header, &other), Err(ContractError::Identity));
        let other =
            CaseRow { coverage: CoverageDescriptor { scope: ChainScope { branch: d(86), ..r.scope }, ..case.coverage }, ..case };
        assert_eq!(positive_certification_case_live_v2(&header, &other), Err(ContractError::Identity));
        let other = CaseRow { liability: material_at(99), ..case };
        assert_eq!(positive_certification_case_live_v2(&header, &other), Err(ContractError::Identity));
    }
}

/// Real signatures over a chosen literal relation count. Large counts are
/// hostile DTO fixtures, not admitted execution profiles or native quotes.
fn signed_bundle_for_relations(mandatory: u64) -> (ClaimIndexRow, ResultRow, CaseRow, FundingRow, WitnessRow, CoverageRow) {
    use libcrux_ml_dsa::ml_dsa_87::*;
    use misaka_palw_positive_contract::funding::*;
    let json: serde_json::Value =
        serde_json::from_str(include_str!("/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet/docs/design/palw/positive-court/contract-vectors-r1.json")).unwrap();
    let hex = json["result_borsh_hex"].as_str().unwrap();
    let bytes: Vec<u8> = (0..hex.len()).step_by(2).map(|i| u8::from_str_radix(&hex[i..i + 2], 16).unwrap()).collect();
    let mut r: MinerResultCommit = borsh::from_slice(&bytes).unwrap();
    let miner = generate_key_pair([1; 32]);
    let payer = generate_key_pair([2; 32]);
    let panel = generate_key_pair([3; 32]);
    let policy = d(31);
    let fired_fork = d(32);
    r.scope.ruleset = misaka_palw_positive_contract::native::ruleset_id(fired_fork, policy);
    r.miner = principal(miner.verification_key.as_ref());
    r.dependencies = material().digest;
    let mut service = MinerServiceContract {
        version: 2,
        revision: 1,
        case: r.case_id(),
        source_catalog: d(33),
        provider_delegations: d(34),
        budget: AggregateBudget {
            rounds: 2,
            unique_source_bytes: 8192,
            transmitted_bytes: 16384,
            additional_work: 8,
            retained_bytes: 4096,
            retention_until: 60,
            fee: 5,
            witness_attempts: 2,
        },
        funding_consent: d(0),
        deadline: 50,
    };
    let basis = FundingPlanBasis {
        profile: CheckProfile::ExactStreamV1,
        derivation: d(35),
        mandatory_relations: mandatory,
        source_catalog: service.source_catalog,
        resource_quote: d(36),
        policy,
        schedule: d(37),
        required_fee: 10,
        required_capital: 20,
    };
    let consent = FundingConsent {
        version: 2,
        revision: 1,
        case: r.case_id(),
        scope: funding_scope(&r, &service, &basis),
        payer: principal(payer.verification_key.as_ref()),
        max_fees: 12,
        max_locked: 100,
        funding_output_index: 1,
        refund_payload: d(38),
        admission_expiry: 40,
    };
    service.funding_consent = consent.id().0;
    r.service_contract = service.id();
    let result = ResultRow {
        miner_signature: *sign(&miner.signing_key, &r.id().0.0, RESULT_SIGN_CONTEXT, [0; 32]).unwrap().as_ref(),
        miner_key: *miner.verification_key.as_ref(),
        origin: origin(),
        policy,
        fired_fork,
        funding_scope: consent.scope,
        dependencies: material(),
        role_assignment: material(),
        result: r.clone(),
    };
    let point = NativeOutpoint { transaction: origin().carrier_transaction, index: 1 };
    let leg = |amount| BalanceLeg { initial: amount, paid: 0, refunded: 0, burned: 0, remaining: amount };
    let funding = FundingRow {
        payer_signature: *sign(&payer.signing_key, &consent.id().0.0, FUNDING_SIGN_CONTEXT, [0; 32]).unwrap().as_ref(),
        payer_key: *payer.verification_key.as_ref(),
        consent,
        basis,
        funding_origin: origin(),
        original_outpoint: point,
        current_outpoint: Some(point),
        initial_locked: 35,
        fee: leg(10),
        capital: leg(20),
        surplus: leg(5),
        liability: material(),
        last_settlement: Some(material()),
    };
    let plan = coverage_plan_id(&r, basis.profile, basis.derivation, mandatory).unwrap();
    let w = PanelWitnessCommit {
        version: 2,
        revision: 1,
        scope: r.scope,
        case: r.case_id(),
        result: r.id(),
        author: principal(panel.verification_key.as_ref()),
        attempt: 0,
        profile: basis.profile,
        plan,
        execution_record: d(40),
        provenance: d(41),
        candidate_output: r.output,
    };
    let witness = WitnessRow {
        panel_signature: *sign(&panel.signing_key, &w.id().0.0, WITNESS_SIGN_CONTEXT, [0; 32]).unwrap().as_ref(),
        panel_key: *panel.verification_key.as_ref(),
        witness: w.clone(),
        origin: origin_at(6),
        record_header: material(),
        generated_tokens: material(),
        role_assignment: material(),
    };
    let case = CaseRow {
        case: r.case_id(),
        result: r.id(),
        service,
        coverage: CoverageDescriptor {
            scope: r.scope,
            result: r.id(),
            plan,
            profile: basis.profile,
            mandatory_relations: mandatory,
            reserved_elements: 100,
            reserved_terms: 200,
            max_part_bytes: 10000,
        },
        status: ClaimStatus::PositivePassed,
        miner_data: MinerDataStatus::Pending,
        witness_status: WitnessStatus::Complete,
        positive_witness: Some(w.id()),
        usage: AggregateUsage {
            unique_source_bytes: 4096,
            transmitted_bytes: 4096,
            additional_work: 1,
            witness_attempts: 1,
            ..AggregateUsage::default()
        },
        reservation: material(),
        liability: material(),
        maturity_daa: 100,
        unresolved_fraud: 0,
        last_event: origin_at(19),
    };
    let coverage = CoverageRow {
        witness: w.id(),
        case: r.case_id(),
        result: r.id(),
        plan,
        mandatory_relations: mandatory,
        next_relation: mandatory,
        frame_bytes: 1373u64.checked_mul(mandatory).unwrap_or(u64::MAX),
        signatures: mandatory,
        elements: 100,
        terms: 200,
        state: CoverageState::Matched,
        last_event: origin_at(16),
    };
    (ClaimIndexRow { claim: r.claim_id(), result: r.id(), case: r.case_id() }, result, case, funding, witness, coverage)
}

