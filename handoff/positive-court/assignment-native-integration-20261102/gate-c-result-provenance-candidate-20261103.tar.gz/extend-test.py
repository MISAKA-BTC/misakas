from pathlib import Path
p=Path(__file__).resolve().parent/'consensus/core/src/palw_positive_rows_v2/tests.rs'
s=p.read_text()
s=s.replace('''            PositiveCertificationHeaderV2, positive_certification_case_live_v2, positive_certification_policy_id_v2,
''','''            PositiveCertificationHeaderV2, check_positive_certification_result_links_v2, positive_certification_case_live_v2,
            positive_certification_policy_id_v2,
''',1)
s=s.replace('assignment: misaka_palw_positive_contract::assignment::AssignmentId(d(81)),','assignment: misaka_palw_positive_contract::assignment::AssignmentId(result.role_assignment.digest),',1)
s=s.replace('''    assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(true));
''','''    assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(true));
    assert_eq!(check_positive_certification_result_links_v2(&header, &result, &case), Ok(()));
    let mut foreign = header.clone();
    foreign.commit_origin.accepted_tx_ordinal += 1;
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
    foreign = header.clone();
    foreign.assignment = misaka_palw_positive_contract::assignment::AssignmentId(d(81));
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
    foreign = header.clone();
    foreign.worker_key[0] ^= 1;
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
    foreign = header.clone();
    foreign.subject = d(84);
    assert_eq!(check_positive_certification_result_links_v2(&foreign, &result, &case), Err(ContractError::Identity));
''',1)
s=s.replace('''        assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(false));
''','''        assert_eq!(positive_certification_case_live_v2(&header, &case), Ok(false));
        assert_eq!(check_positive_certification_result_links_v2(&header, &result, &case), Ok(()));
''',1)
p.write_text(s)
