import json
import os
import re
import subprocess
from pathlib import Path

stage = Path(__file__).resolve().parent
repo = Path('/Users/wata/.codex/worktrees/positive-court-a0/MISAKA-testnet')
src = stage/'consensus/core/src'
cert = (src/'palw_positive_certification_v2.rs').read_text()
base = (src/'palw_security_certification_v1.rs').read_text()
tests = (src/'palw_positive_rows_v2/tests.rs').read_text()

def cut(source, start, stop):
    return source[source.index(start):source.index(stop, source.index(start))]

policy = re.search(r'pub struct PalwSecurityCertificationPolicyV1 \{[^}]+\}', base).group()
header = cut(cert, '#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]\npub struct PositiveCertificationHeaderV2', 'impl PositiveCertificationHeaderV2')
hashing = cut(cert, 'pub(crate) fn p_hash', 'pub fn positive_certification_key_v2')
policy_id = re.search(r'pub fn positive_certification_policy_id_v2\([^}]+\}', cert).group()
guard = cut(cert, 'pub(crate) fn positive_certification_case_live_v2', '/// Failure-only pure projection.')
fixture = cut(tests, 'pub(super) fn d(', 'pub(super) fn row_kind(').replace('pub(super) fn ', 'fn ')
fixture = fixture.replace('../../../../docs/', str(repo/'docs') + '/')
combined = """
#![allow(dead_code)]
use borsh::{BorshSerialize, BorshDeserialize};
use misaka_palw_positive_contract::{ContractError, assignment::AssignmentId, identity::*, messages::*, rows::*};
""" + '#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]\n' + policy + '\n' + header + hashing + policy_id + '\n' + guard + fixture
combined = re.sub(r'    use crate::\{\n        palw_positive_certification_v2::\{.*?\n    \};\n', '', combined, count=1, flags=re.S)
(stage/'case-regression.rs').write_text(combined)

deps = Path('/Users/wata/Downloads/MISAKA-testnet/target/positive-legacy-native-fresh-20261102/debug/deps')
fp = deps.parent/'.fingerprint'
needed = {'misaka_palw_positive_contract','borsh','libcrux_ml_dsa','serde_json','blake2b_simd'}
for manifest in fp.glob('kaspa-consensus-core-*/test-lib-kaspa_consensus_core.json'):
    extern = {}
    for _, name, _, digest in json.loads(manifest.read_text())['deps']:
        if name not in needed:
            continue
        for m in fp.glob('*/lib-'+name):
            if m.read_text() == digest.to_bytes(8,'little').hex():
                rlib = deps/('lib'+name+'-'+m.parent.name.rsplit('-',1)[-1]+'.rlib')
                if rlib.exists():
                    extern[name] = rlib
    if set(extern) == needed:
        break
else:
    raise RuntimeError('matching linked Contract/fixture dependencies unavailable')
rustc = Path.home()/'.rustup/toolchains/1.93.0-aarch64-apple-darwin/bin/rustc'
args = [str(rustc),'--edition=2024','--test','-L',f'dependency={deps}']
for name, rlib in extern.items():
    args.extend(['--extern',f'{name}={rlib}'])
binary = stage/'case-regression'
subprocess.run([*args, str(stage/'case-regression.rs'), '-o', str(binary)],
               env=os.environ | {'CARGO_MANIFEST_DIR':str(repo/'consensus/core'), 'CARGO':str(rustc.with_name('cargo')), 'CARGO_PKG_NAME':'kaspa-consensus-core'},check=True)
subprocess.run([str(binary)],check=True)
